# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
from resources.lib.converter import run_main_menu_loop

if __name__ == "__main__":
    try:
        # Startet die Hauptschleife in der converter.py
        run_main_menu_loop()
    except Exception as e:
        # Fehlermeldung im Titan-Style anzeigen
        xbmcgui.Dialog().notification(
            "Titan Converter",
            f"Fehler: {str(e)}",
            xbmcgui.NOTIFICATION_ERROR,
            8000
        )
        # Fehler im Kodi-Log protokollieren
        xbmc.log(f"[script.portal.mac.converter] Fatal error: {str(e)}", xbmc.LOGERROR)