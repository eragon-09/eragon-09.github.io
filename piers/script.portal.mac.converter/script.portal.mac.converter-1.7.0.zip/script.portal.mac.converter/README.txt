Portal MAC Converter (Kodi 21)

Änderungen:
- Addon umbenannt in **Portal MAC Manager**
- Addon-ID: script.portal_mac_manager
- Nummerierungen (1., 2., 3.) aus Haupt- und Untermenüs entfernt
- Funktional identisch zu v1.4.0

Funktionen:
- TXT → JSON Konvertierung
- Mehrfachauswahl
- Portal-Duplikat-Erkennung
- Automatische Backups
- Löschen von IN / OUT / BACKUP Dateien
