# -*- coding: utf-8 -*-
"""Titan Smart TV Plus - ausgelagerte gemeinsame Logik.

Wird bewusst in den gemeinsamen Addon-Kontext geladen, damit die bestehende
Provider-/Kodi-Logik unveraendert bleibt.
"""

def fav_key(ch):
    return (f"{ch.get('name','')}|{ch.get('url','')}").strip()


def load_favs():
    return read_json(FAV_FILE, [])


def save_favs(favs):
    seen = set()
    out = []
    for c in favs:
        k = fav_key(c)
        if k in seen:
            continue
        seen.add(k)
        out.append(c)
    write_json(FAV_FILE, out)


def is_fav(ch, favs):
    k = fav_key(ch)
    return any(fav_key(x) == k for x in favs)


def _fav_get_epg(c):
    """
    Laedt aktuelles EPG fuer einen Favoriten-Eintrag live aus dem jeweiligen Cache.
    Gibt epg_item-Dict {now, next} zurueck oder None.
    Arbeitet generisch ueber den Source-*Typ* (nicht die ID), damit z.B. Plex
    unabhaengig davon funktioniert, ob gerade die JSON-Region-Quelle oder eine
    eigene M3U/EPG-URL konfiguriert ist.
    """
    src_id = c.get("source_id", "")
    ch_id  = (c.get("channel_id") or c.get("tvgid") or "").strip()
    src    = get_source(src_id)
    if not src or not ch_id:
        return None

    src_type = src.get("type", "")

    # --- JSON-Quellen (Pluto, Samsung, Plex-Region): aus gecachtem Channel-Dict ---
    if src_type == "json":
        region  = (src.get("region") or "de").lower()
        cpath   = cache_path("json", src.get("url", "") + region)
        cached  = read_json(cpath, {})
        for ch in cached.get("channels", []):
            if ch.get("channel_id") == ch_id or ch.get("tvgid") == ch_id:
                now_item  = ch.get("epg_now")
                next_item = ch.get("epg_next")
                if now_item or next_item:
                    return {"now": now_item, "next": next_item}
        return None

    # --- Rakuten: aus EPG-Cache ---
    if src_type == "rktv_live":
        epg_data   = _rktv_preserve(RKTV_EPG_FILE, max(1, get_rktv_epg_cache_seconds() // 3600))
        if not epg_data:
            return None
        now_utc = datetime.utcnow()
        for item in epg_data.get("data", []):
            if item.get("id") != ch_id:
                continue
            now_item  = None
            next_item = None
            for elem in item.get("live_programs", []):
                start = _rktv_parse_dt(elem.get("starts_at", ""))
                end   = _rktv_parse_dt(elem.get("ends_at", ""))
                if start is None or end is None:
                    continue
                if start <= now_utc < end:
                    now_item = {"title": elem.get("title") or "",
                                "start": int(start.replace(tzinfo=timezone.utc).timestamp()),
                                "stop": int(end.replace(tzinfo=timezone.utc).timestamp()),
                                "desc": elem.get("description") or elem.get("summary") or ""}
                elif start > now_utc and next_item is None:
                    next_item = {"title": elem.get("title") or "",
                                 "start": int(start.replace(tzinfo=timezone.utc).timestamp()),
                                 "stop": int(end.replace(tzinfo=timezone.utc).timestamp()),
                                 "desc": elem.get("description") or elem.get("summary") or ""}
                if now_item and next_item:
                    break
            if now_item or next_item:
                return {"now": now_item, "next": next_item}
        return None

    # --- Plex DE (gebuendelte Liste): aus EPG-Grid-Cache ---
    if src_type == "plex_de_static":
        epg_map = read_json(cache_path("plexepg", "de"), {}).get("epg_map") or {}
        return epg_map.get(ch_id)

    # --- M3U-Quellen (Germany 1-3, eigene Plex-Quelle): aus XMLTV-Index-Cache ---
    if src_type == "m3u":
        epg_url = (src.get("epg") or "").strip()
        if not epg_url:
            return None
        _, _, idx_p = _epg_paths(epg_url)
        if not xbmcvfs.exists(idx_p):
            return None
        cached  = read_json(idx_p, {})
        epg_map = cached.get("epg_map") or {}
        return epg_map.get(ch_id)

    return None


def view_favorites():
    favs = load_favs()
    xbmcplugin.setPluginCategory(HANDLE, "Favoriten")

    if not favs:
        li = xbmcgui.ListItem(colorize("Keine Favoriten vorhanden", COLOR_FAV))
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": ""}), li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
        return

    show_epg   = ADDON.getSetting("show_epg_in_label") != "false"
    total      = len(favs)

    for idx, c in enumerate(favs):
        base_name = c.get("name", "Channel")
        label     = colorize(base_name, COLOR_FAV)

        # EPG live aus Cache nachladen
        epg_item = _fav_get_epg(c) if show_epg else None
        now_str, next_str, plot, now_time, now_colored = epg_label_parts(epg_item)

        if show_epg and now_colored:
            label = f"{label}  {now_colored}"

        li = xbmcgui.ListItem(label)
        li.setProperty("IsPlayable", "true")

        if next_str:
            li.setLabel2(next_str)

        title_for_skins = base_name
        if now_str:
            title_for_skins = f"{base_name}  {now_str}"
        set_video_info(li, title_for_skins, plot)

        logo = (c.get("logo") or "").strip()
        fav_src = get_source(c.get("source_id", ""))
        if logo and not (fav_src and fav_src.get("type") == "m3u"):
            # Auch M3U-Favoriten verwenden die direkte Logo-URL.
            logo = get_logo_local(logo, force=False)
        set_art(li, logo)

        # Kontextmenü: Entfernen + Reihenfolge
        key = quote_plus(fav_key(c))
        cm  = [("Favorit entfernen",
                "RunPlugin(%s)" % build_url({"action": "fav_del", "key": key}))]
        if idx > 0:
            cm.append(("Nach oben",
                        "RunPlugin(%s)" % build_url({"action": "fav_up", "key": key})))
        if idx < total - 1:
            cm.append(("Nach unten",
                        "RunPlugin(%s)" % build_url({"action": "fav_down", "key": key})))
        li.addContextMenuItems(cm)

        if fav_src and fav_src.get("type") == "plex_de_static":
            play_url = build_url({"action": "play_plex",
                                  "channel_id": quote_plus(c.get("channel_id", "")),
                                  "part_url": quote_plus(c.get("url", "")),
                                  "name": quote_plus(base_name), "plot": quote_plus(plot)})
        else:
            play_url = build_url({"action": "play", "url": quote_plus(c.get("url", "")),
                                  "name": quote_plus(base_name), "plot": quote_plus(plot)})
        xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)

