# -*- coding: utf-8 -*-
"""Ausgelagerte Provider-Implementierung."""

# ----------------------------------------------------------
# Rakuten TV Live - Hilfsfunktionen
# (portiert aus plugin.video.rakuten.de, angepasst fuer Titan)
# ----------------------------------------------------------

def _rktv_clean_umlaut(s):
    """Umlaute normalisieren fuer Sortierung (aus Rakuten common.py)."""
    if s:
        for pair in (('ä','ae'),('Ä','Ae'),('ü','ue'),('Ü','Ue'),('ö','oe'),('Ö','Oe'),('ß','ss')):
            s = s.replace(*pair)
        s = s.strip()
    return s or ""


def _rktv_preserve(store, timing, facts=None):
    """
    Lesen/Schreiben von gzip-gecachten JSON-Daten.
    timing=0: immer frisch lesen (kein TTL).
    timing=N: N Stunden TTL.
    Identisch zu preserve() aus Rakuten common.py.
    """
    if facts is not None:
        with gzip.open(xbmcvfs.translatePath(store), 'wt', encoding='utf-8') as f:
            json.dump(facts, f, indent=2, sort_keys=True)
        return None
    else:
        local = xbmcvfs.translatePath(store)
        if xbmcvfs.exists(store) and os.path.exists(local) and os.stat(local).st_size > 0:
            now_ts = time.time()
            file_exp = (os.path.getmtime(local) + 3600 * int(timing)) if int(timing) != 0 else 0
            if int(timing) == 0 or now_ts < file_exp:
                with gzip.open(local, 'rt', encoding='utf-8') as f:
                    return json.load(f)
            else:
                xbmcvfs.delete(store)
        return None


def _rktv_get_signatures():
    """
    Erzeugt/erneuert UUID-Session-Tokens alle 2 Stunden.
    Identisch zu getSignatures() aus Rakuten navigator.py.
    """
    s = read_json(RKTV_SETTINGS_FILE, {})
    next_run_str = s.get("next_process", "2000-01-01 00:00:00")
    try:
        next_run = datetime.strptime(next_run_str[:19], "%Y-%m-%d %H:%M:%S")
    except Exception:
        next_run = datetime(2000, 1, 1)

    if datetime.now() > next_run or s.get("device_uid", "unknown") == "unknown":
        s["next_process"] = str(datetime.now() + timedelta(hours=2))[:19]
        s["device_serial"] = str(uuid.uuid4())
        s["device_uid"] = str(uuid.uuid4())
        s["publisher_provided_id"] = str(uuid.uuid4())
        write_json(RKTV_SETTINGS_FILE, s)
        log(f"[Rakuten Live] Session-Tokens erneuert")
    return s


def _rktv_get_content(url, method="GET", params=None, json_data=None, timeout=30):
    """HTTP-Request gegen die Rakuten Gizmo-API."""
    try:
        r = requests.request(
            method, url,
            params=params,
            headers=RKTV_HEAD,
            json=json_data,
            verify=True,
            timeout=timeout,
            allow_redirects=True,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log(f"[Rakuten Live] API-Fehler: {url} -> {e}", xbmc.LOGERROR)
        return {}


def _rktv_get_specifications(page=1):
    """Parameter der Rakuten-Web-Live-TV-Abfrage fuer die gewaehlte Region."""
    return {
        "classification_id": RKTV_CLASSIFY,
        "device_identifier": "web",
        "device_stream_audio_quality": "2.0",
        "device_stream_hdr_type": "NONE",
        "device_stream_video_quality": "FHD",
        "locale": RKTV_LOCALE,
        "market_code": RKTV_MARKET,
        "page": str(page),
        "per_page": "25",
    }


def _rktv_get_epg_specifications(page=1):
    """Rakuten-Live-Abfrage mit EPG-Zeitfenster wie in der Light-Version.

    Rakuten liefert ``live_programs`` nur, wenn ein explizites EPG-Fenster
    mit UTC-ISO-Zeiten und den passenden Epoch-Millisekunden angefordert wird.
    Das Fenster umfasst 2 Stunden Vergangenheit + 4 Stunden Zukunft.
    """
    now_utc = datetime.now(timezone.utc)
    start_dt = (now_utc - timedelta(hours=2)).replace(minute=0, second=0, microsecond=0)
    end_dt = (now_utc + timedelta(hours=4)).replace(minute=0, second=0, microsecond=0)

    utc_start = start_dt.strftime("%Y-%m-%dT%H:00:00.000Z")
    utc_end = end_dt.strftime("%Y-%m-%dT%H:00:00.000Z")
    epoch_start = int(start_dt.timestamp() * 1000)
    epoch_end = int(end_dt.timestamp() * 1000)

    params = _rktv_get_specifications(page)
    # EPG wird mit derselben regionalen Klassifikation wie die Senderliste
    # angefordert.
    # Das originale RakutenTV-German-Addon fordert bis zu 200 Sender pro Seite
    # inklusive live_programs an. Das reduziert die Live-TV-Abfrage in der Regel
    # auf eine einzige HTTP-Runde; Pagination bleibt als Fallback erhalten.
    params["classification_id"] = RKTV_CLASSIFY
    params.update({
        "epg_duration_minutes": "360",
        "epg_starts_at": utc_start,
        "epg_starts_at_timestamp": str(epoch_start),
        "epg_ends_at": utc_end,
        "epg_ends_at_timestamp": str(epoch_end),
        "per_page": "25",
    })
    return params


def _rktv_load_all_live_channels(force=False):
    """Lädt alle Seiten der aktuellen Rakuten-Live-TV-Liste.

    Die komplette Senderantwort wird separat gecacht. Dadurch kann Kodi nach
    dem Beenden eines Streams die bestehende Liste sofort wieder aufbauen,
    ohne Rakuten erneut abzufragen.
    """
    ttl_hours = get_rktv_cache_seconds() // 3600 or 1
    cached = _rktv_preserve(RKTV_LIVE_DATA_FILE, ttl_hours)
    if cached and not force and isinstance(cached, dict) and cached.get("data"):
        log(f"[Rakuten Live] LIVE CACHE HIT: {len(cached.get('data') or [])} Sender")
        return cached

    channels = []
    page = 1
    total_pages = 1
    while page <= total_pages and page <= 20:
        data = _rktv_get_content(f"{RKTV_API}/live_channels", params=_rktv_get_specifications(page))
        batch = data.get("data", []) if isinstance(data, dict) else []
        if not batch:
            break
        channels.extend(batch)
        pagination = (data.get("meta") or {}).get("pagination") or {}
        try:
            total_pages = int(pagination.get("total_pages") or 1)
        except Exception:
            total_pages = 1
        page += 1

    result = {"data": channels, "meta": {"pagination": {"page": 1, "count": len(channels), "per_page": len(channels), "total_pages": 1}}}
    if channels:
        _rktv_preserve(RKTV_LIVE_DATA_FILE, ttl_hours, result)
    return result

def _rktv_load_epg_live_channels():
    """Laedt Rakuten-Sender + EPG. Seite 1 bestimmt die Pagination,
    Folgeseiten werden begrenzt parallel geladen (Fire-TV-freundlich)."""
    params = _rktv_get_epg_specifications(1)
    log(
        "[Rakuten Live] EPG-Fenster: "
        f"{params.get('epg_starts_at')} bis {params.get('epg_ends_at')} "
        f"(classification={params.get('classification_id')}, per_page={params.get('per_page')})"
    )
    first = _rktv_get_content(f"{RKTV_API}/live_channels", params=params)
    channels = list(first.get("data", []) if isinstance(first, dict) else [])
    pagination = (first.get("meta") or {}).get("pagination") or {} if isinstance(first, dict) else {}
    try:
        total_pages = min(10, int(pagination.get("total_pages") or 1))
    except Exception:
        total_pages = 1

    if total_pages > 1:
        def fetch_page(page):
            data = _rktv_get_content(f"{RKTV_API}/live_channels", params=_rktv_get_epg_specifications(page))
            return page, (data.get("data", []) if isinstance(data, dict) else [])
        # Wenige Worker: schneller als seriell, ohne kleine Fire-TV-Geraete zu belasten.
        with ThreadPoolExecutor(max_workers=min(4, total_pages - 1)) as pool:
            futures = [pool.submit(fetch_page, page) for page in range(2, total_pages + 1)]
            pages = {}
            for future in as_completed(futures):
                try:
                    page, batch = future.result()
                    pages[page] = batch
                except Exception as exc:
                    log(f"[Rakuten Live] EPG-Seite fehlgeschlagen: {exc}", xbmc.LOGWARNING)
            for page in range(2, total_pages + 1):
                channels.extend(pages.get(page, []))

    return {
        "data": channels,
        "meta": {"pagination": {"page": 1, "count": len(channels), "per_page": 25, "total_pages": 1}},
    }


def _rktv_parse_dt(s):
    """Parst aktuelle Rakuten-Zeitstempel inkl. Z/Zeitzonenoffset korrekt nach UTC (naiv)."""
    if not s:
        return None
    try:
        value = str(s).strip()
        # Python fromisoformat versteht +02:00; Z wird portabel in +00:00 umgewandelt.
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return dt
    except Exception:
        try:
            return datetime.strptime(str(s)[:19], "%Y-%m-%dT%H:%M:%S")
        except Exception:
            return None

def _rktv_get_schedules(programs):
    """
    EPG-Text fuer einen Sender aufbauen.
    Identisch zu getSchedules() aus Rakuten navigator.py.
    """
    guide = ""
    now = datetime.utcnow()
    for elem in programs:
        start = _rktv_parse_dt(elem.get("starts_at", ""))
        end   = _rktv_parse_dt(elem.get("ends_at", ""))
        if start is None or end is None:
            continue
        if end <= now:
            continue
        title    = elem.get("title") or ""
        episode  = elem.get("subtitle") or ""
        episode  = episode if len(episode) > 5 else None
        desc     = "[CR]"
        raw_desc = elem.get("description") or ""
        if raw_desc and len(raw_desc) > 10 and "info not available" not in raw_desc.lower() and title.lower() != raw_desc.lower():
            raw_desc = raw_desc.replace("\n", "").strip()
            desc = (raw_desc[:300] + "...[CR][CR]") if len(raw_desc) > 300 else (raw_desc + "[CR][CR]")
        # _rktv_parse_dt liefert UTC. Fuer die Anzeige wieder in Kodi-Systemzeit umrechnen.
        start_local = start.replace(tzinfo=timezone.utc).astimezone()
        end_local = end.replace(tzinfo=timezone.utc).astimezone()
        if episode:
            guide += f"[{start_local.strftime('%H:%M')}-{end_local.strftime('%H:%M')}] {title} - {episode}[CR]{desc}"
        else:
            guide += f"[{start_local.strftime('%H:%M')}-{end_local.strftime('%H:%M')}] {title}[CR]{desc}"
    return guide


# ----------------------------------------------------------
# Rakuten TV Live - Haupt-Views
# ----------------------------------------------------------

def rktv_load_categories(force=False):
    """
    Lädt Rakuten Live direkt aus der aktuellen /live_channels-Antwort.
    Kategorien werden aus labels.tags erzeugt; nur DEU-Sender werden aufgenommen.
    """
    cached = _rktv_preserve(RKTV_CHANNEL_FILE, get_rktv_cache_seconds() // 3600 or 1)
    if cached and not force:
        return cached

    use_epg = epg_enabled("rakuten_live")
    log("[Rakuten Live] Lade aktuelle Live-Sender/EPG (Web-API)" if use_epg else "[Rakuten Live] Lade aktuelle Live-Sender ohne EPG (Web-API)")
    # Mit aktiviertem EPG spart die kombinierte Antwort eine zweite API-Runde.
    # Ist EPG deaktiviert, wird bewusst nur die schlankere Senderabfrage genutzt.
    data = rktv_load_epg(force=force) if use_epg else _rktv_load_all_live_channels(force=force)
    channels = data.get("data", []) if isinstance(data, dict) else []
    if not channels and use_epg:
        # EPG darf nie Voraussetzung fuer die Senderliste sein.
        log("[Rakuten Live] Kombinierte EPG-Abfrage fehlgeschlagen - Sender-Fallback", xbmc.LOGWARNING)
        data = _rktv_load_all_live_channels(force=force)
        channels = data.get("data", []) if isinstance(data, dict) else []
    if not channels:
        return {}

    categories = {"LIVE TV | Alle (DE)": []}
    for item in channels:
        langs = ((item.get("labels") or {}).get("languages") or [])
        lang_ids = [str(x.get("id", "")).upper() for x in langs if isinstance(x, dict)]
        if "DEU" not in lang_ids:
            continue
        cid = item.get("id")
        if not cid:
            continue
        categories["LIVE TV | Alle (DE)"].append(cid)
        tags = ((item.get("labels") or {}).get("tags") or [])
        for tag in tags:
            name = tag.get("name") if isinstance(tag, dict) else None
            if name:
                categories.setdefault(name, []).append(cid)

    categories = {k: v for k, v in categories.items() if v}
    _rktv_preserve(RKTV_CHANNEL_FILE, get_rktv_cache_seconds() // 3600 or 1, categories)
    log(f"[Rakuten Live] {len(categories.get('LIVE TV | Alle (DE)', []))} deutsche Sender geladen")
    return categories

def _rktv_epg_has_programs(data):
    """True, wenn der Cache wirklich aktuelle Rakuten-Programmdaten enthaelt."""
    if not isinstance(data, dict):
        return False
    channels = data.get("data") or []
    return any(isinstance(ch, dict) and ch.get("live_programs") for ch in channels)

def rktv_load_epg(force=False):
    """Laedt Rakuten-EPG und verwirft alte Sender-Caches ohne live_programs.

    Builds vor 1.16.1 speicherten die Live-Senderantwort bereits in derselben
    Cache-Datei. Nach einem Add-on-Update blieb dieser Profil-Cache erhalten.
    Dadurch konnte v1.16.0 einen formal gueltigen, aber EPG-losen Alt-Cache
    wiederverwenden.
    """
    rktv_epg_hours = max(1, get_rktv_epg_cache_seconds() // 3600)
    cached = _rktv_preserve(RKTV_EPG_FILE, rktv_epg_hours)
    if cached and not force and _rktv_epg_has_programs(cached):
        count = sum(1 for ch in (cached.get("data") or []) if ch.get("live_programs"))
        log(f"[Rakuten Live] EPG CACHE HIT: {count} Sender mit Programmdaten")
        # Ein vorhandener EPG-Cache ist zugleich ein gueltiger Live-Senderdatensatz.
        # Falls der separate Live-Cache fehlt, ohne Netzwerkanfrage wiederherstellen.
        if not _rktv_preserve(RKTV_LIVE_DATA_FILE, get_rktv_cache_seconds() // 3600 or 1):
            _rktv_preserve(RKTV_LIVE_DATA_FILE, get_rktv_cache_seconds() // 3600 or 1, cached)
        return cached

    if cached and not _rktv_epg_has_programs(cached):
        log("[Rakuten Live] Alter EPG-Cache ohne live_programs erkannt - lade neu", xbmc.LOGWARNING)

    # Wichtig: Die normale Senderabfrage enthaelt kein live_programs. Fuer das EPG
    # wird daher bewusst die separate Anfrage mit dem Light-Addon-Zeitfenster benutzt.
    data = _rktv_load_epg_live_channels()
    if data.get("data"):
        with_epg = sum(1 for ch in data["data"] if ch.get("live_programs"))
        total_programs = sum(len(ch.get("live_programs") or []) for ch in data["data"])
        log(f"[Rakuten Live] EPG frisch geladen: {with_epg} Sender / {total_programs} Programme")
        # Nur Antworten mit echtem EPG als EPG-Cache persistieren.
        if with_epg:
            _rktv_preserve(RKTV_EPG_FILE, rktv_epg_hours, data)
            # Dieselbe Antwort ist zugleich eine vollstaendige Senderliste.
            # Dadurch ist _rktv_load_all_live_channels() danach ein Cache-Hit.
            _rktv_preserve(RKTV_LIVE_DATA_FILE, get_rktv_cache_seconds() // 3600 or 1, data)
        else:
            log("[Rakuten Live] EPG-Antwort enthaelt keine live_programs", xbmc.LOGWARNING)
    return data or {}



# ----------------------------------------------------------
# Rakuten VoD – Genres & Kategorien & Inhaltslisten
# (portiert aus navigator.py: listGenres / listRecords / listBroadcasts)
# ----------------------------------------------------------

def _rktv_parse_item(item):
    """
    Extrahiert die wesentlichen Metadaten eines VoD-Items aus dem API-Response.
    Gibt ein flaches Dict zurueck das set_video_info() und set_art() direkt nutzen koennen.
    """
    slug    = item.get("id", "")
    species = item.get("type", "")          # "movies" | "tv_shows"
    title   = (item.get("title") or item.get("display_name") or "")
    plot    = (item.get("plot") or item.get("short_plot") or "")
    year    = item.get("year")
    duration = item.get("duration")         # Minuten fuer Filme
    try:
        duration = int(duration) * 60 if duration else None
    except Exception:
        duration = None

    genre = ""
    if isinstance(item.get("genres"), list):
        genre = " / ".join(sorted(g.get("name", "") for g in item["genres"] if g.get("name")))

    images  = item.get("images") or {}
    thumb   = (images.get("snapshot") or images.get("snapshot_webp") or "")
    poster  = (images.get("artwork") or images.get("artwork_webp") or "")
    fanart  = thumb  # snapshot als Fanart

    # Erste Staffel-ID fuer TV-Serien
    seasons = item.get("seasons") or []
    season_id = seasons[0].get("id", "") if seasons else ""

    # Kaufpflicht pruefen (nur AVOD-Inhalte zeigen)
    labels = item.get("labels") or {}
    purchase_types = labels.get("purchase_types") or []
    is_paid = bool(purchase_types and purchase_types[0].get("kind", "avod") != "avod")

    return {
        "slug": slug, "species": species, "title": title, "plot": plot,
        "year": year, "duration": duration, "genre": genre,
        "thumb": thumb, "poster": poster, "fanart": fanart,
        "season_id": season_id, "is_paid": is_paid,
    }


def _rktv_vod_load_categories(force=False):
    """
    Laedt die VoD-Kategorienliste von /skeleton/gardens/avod-fast.
    Cache-TTL: 24h (identisch zum Original).
    Gibt dict {slug: name} zurueck.
    """
    cached = _rktv_preserve(RKTV_VOD_CAT_FILE, 24)
    if cached and not force:
        return cached

    log("[Rakuten VoD] Lade Kategorieliste von API")
    data = _rktv_get_content(f"{RKTV_API}/skeleton/gardens/avod-fast",
                             params=RKTV_PARAMS_USER)
    categories = {}
    for rec in (data.get("data") or {}).get("lists", []):
        ct  = rec.get("content_type", "")
        rid = rec.get("id", "")
        if ct in ("Movie", "TvShow") and rid.startswith(("free", "rakuten")):
            if rid == "free-all-movies":
                continue
            name = rec.get("name") or rid
            # "KOSTENLOS | " / "Kostenlose " Prefix entfernen wie im Original
            name = re.sub(r"(KOSTENLOS \| |Kostenslose |Kostenlose )", "", name).strip()
            categories[rid] = name

    if categories:
        _rktv_preserve(RKTV_VOD_CAT_FILE, 24, categories)
    return categories


def view_rktv_vod_main():
    """
    Rakuten VoD Hauptmenü: VoD-Kategorien + Genres als zwei Unterpunkte.
    """
    rktv_icon = get_source_icon("rakuten_live")

    items = [
        ("  Alle kostenlosen Filme & Serien", "rktv_vod_categories", {}),
        ("  Genres & Stimmungen",             "rktv_genres",         {}),
    ]
    for label, action, kwargs in items:
        url = build_url({"action": action, **kwargs})
        li  = xbmcgui.ListItem(colorize(label, COLOR_GROUP))
        li.setArt({"icon": rktv_icon, "thumb": rktv_icon, "fanart": rktv_icon})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)


def view_rktv_genres():
    """
    Genres & Stimmungen von /banner_lists/896.
    Entspricht listGenres() aus dem Original.
    """
    p = ProgressDialog(enabled=True)
    p.open("Lade Genres …")
    try:
        p.update(30, "Lade Genres …")
        data = _rktv_get_content(f"{RKTV_API}/banner_lists/896",
                                 params=RKTV_PARAMS_USER)
        banners = (data.get("data") or {}).get("banners", [])
        if not banners:
            notify("Keine Genres gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(80, "Baue Menü …")
        for item in sorted(banners,
                           key=lambda x: _rktv_clean_umlaut(x.get("display_title", "")).lower()):
            target = item.get("target") or {}
            # Nur garden-Eintraege, awards/pride ueberspringen (wie Original)
            if target.get("type", "gardens") != "gardens":
                continue
            if target.get("id", "") in ("awards-season", "pride"):
                continue

            title  = item.get("display_title", "")
            gid    = target.get("id", "")
            thumb  = (item.get("image") or item.get("image_webp") or "")
            fanart = (item.get("background_image") or item.get("background_image_webp") or thumb)

            if not title or not gid:
                continue

            url = build_url({"action": "rktv_vod_records",
                             "slug": quote_plus(gid),
                             "pic":  quote_plus(thumb),
                             "fan":  quote_plus(fanart)})
            li = xbmcgui.ListItem(colorize(title, COLOR_GROUP))
            li.setArt({"icon": thumb, "thumb": thumb, "fanart": fanart})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_rktv_vod_categories():
    """
    VoD-Kategorien (Alle kostenlosen Filme & Serien).
    Entspricht listRecords(slug='avod-fast') aus dem Original.
    """
    p = ProgressDialog(enabled=True)
    p.open("Lade VoD-Kategorien …")
    try:
        p.update(30, "Lade Kategorien …")
        cats = _rktv_vod_load_categories()
        if not cats:
            notify("Keine VoD-Kategorien gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(80, "Baue Menü …")
        rktv_icon = get_source_icon("rakuten_live")
        for slug, name in cats.items():
            url = build_url({"action": "rktv_vod_list",
                             "slug": quote_plus(slug),
                             "name": quote_plus(name),
                             "page": "1"})
            li = xbmcgui.ListItem(colorize(name, COLOR_GROUP))
            li.setArt({"icon": rktv_icon, "thumb": rktv_icon, "fanart": rktv_icon})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_rktv_vod_records(slug, pic, fan):
    """
    Unterkategorien eines Genres laden (identisch zu listRecords fuer Genre-Slugs).
    Gibt entweder direkt die Senderliste oder eine Kategorienliste aus.
    """
    p = ProgressDialog(enabled=True)
    p.open("Lade Genre-Kategorien …")
    try:
        p.update(20, "Lade Kategorien …")
        all_cats = _rktv_vod_load_categories()

        p.update(50, "Lade Genre-Inhalt …")
        data = _rktv_get_content(f"{RKTV_API}/skeleton/gardens/{slug}",
                                 params=RKTV_PARAMS_USER)
        lists = (data.get("data") or {}).get("lists", [])

        collage = []
        for item in lists:
            ct  = item.get("content_type", "")
            rid = item.get("id", "")
            if ct not in ("Movie", "TvShow"):
                continue
            if not rid.startswith(("free", "rakuten")):
                continue
            if rid == "free-all-movies":
                continue
            name = all_cats.get(rid)
            if not name:
                continue
            collage.append((name, rid))

        p.update(80, "Baue Menü …")
        if len(collage) == 1:
            # Nur eine Kategorie -> direkt zur Liste
            p.close()
            return view_rktv_vod_list(collage[0][1], collage[0][0], 1)

        for name, rid in collage:
            url = build_url({"action": "rktv_vod_list",
                             "slug": quote_plus(rid),
                             "name": quote_plus(name),
                             "page": "1"})
            li = xbmcgui.ListItem(colorize(name, COLOR_GROUP))
            li.setArt({"icon": pic, "thumb": pic, "fanart": fan})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

        if not collage:
            notify("Keine Inhalte gefunden", True, 5000)

        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_rktv_vod_list(slug, name, page=1):
    """
    Inhaltsliste einer VoD-Kategorie (/lists/{slug}/contents).
    Entspricht listBroadcasts() aus dem Original.
    Nur AVOD-Inhalte (keine Kaufpflicht), Seitennavigation bei >50 Eintraegen.
    """
    PER_PAGE = 50
    p = ProgressDialog(enabled=True)
    p.open(f"Lade {name} …")
    try:
        p.update(20, "Lade Inhalte …")
        params = {**RKTV_PARAMS_WEB, "page": str(page), "per_page": str(PER_PAGE)}
        data   = _rktv_get_content(f"{RKTV_API}/lists/{slug}/contents", params=params)
        items  = data.get("data") or []

        if not items:
            notify("Keine Inhalte gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(60, "Baue Liste …")
        found = 0
        for item in items:
            meta = _rktv_parse_item(item)
            if meta["is_paid"]:
                continue
            found += 1

            title  = meta["title"]
            plot   = meta["plot"]
            thumb  = meta["thumb"]
            poster = meta["poster"]
            fanart = meta["fanart"]

            label = colorize(title, COLOR_CHANNEL)
            if meta["year"]:
                label = f"{label}  [COLOR lightgray]({meta['year']})[/COLOR]"

            li = xbmcgui.ListItem(label)

            if meta["species"] == "movies":
                # Film → direkt spielbar (Schritt 2)
                li.setProperty("IsPlayable", "true")
                try:
                    tag = li.getVideoInfoTag()
                    tag.setTitle(title)
                    tag.setPlot(plot)
                    tag.setMediaType("movie")
                    if meta["year"]:
                        tag.setYear(int(meta["year"]))
                    if meta["genre"]:
                        tag.setGenres([meta["genre"]])
                    if meta["duration"]:
                        tag.setDuration(meta["duration"])
                except Exception:
                    li.setInfo("video", {"title": title, "plot": plot, "mediatype": "movie"})

                li.setArt({"thumb": thumb, "poster": poster, "fanart": fanart,
                           "icon": thumb, "landscape": thumb})

                play_url = build_url({"action": "rktv_vod_play",
                                      "slug":    quote_plus(meta["slug"]),
                                      "species": "movies",
                                      "name":    quote_plus(title),
                                      "thumb":   quote_plus(thumb)})
                xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)

            elif meta["species"] == "tv_shows":
                # Serie → Staffeln (Schritt 2)
                try:
                    tag = li.getVideoInfoTag()
                    tag.setTitle(title)
                    tag.setPlot(plot)
                    tag.setMediaType("tvshow")
                    if meta["year"]:
                        tag.setYear(int(meta["year"]))
                    if meta["genre"]:
                        tag.setGenres([meta["genre"]])
                except Exception:
                    li.setInfo("video", {"title": title, "plot": plot, "mediatype": "tvshow"})

                li.setArt({"thumb": thumb, "poster": poster, "fanart": fanart,
                           "icon": thumb, "landscape": thumb})

                seasons_url = build_url({"action": "rktv_vod_seasons",
                                         "slug":   quote_plus(meta["season_id"] or meta["slug"]),
                                         "name":   quote_plus(title),
                                         "thumb":  quote_plus(thumb)})
                xbmcplugin.addDirectoryItem(HANDLE, seasons_url, li, isFolder=True)

        # Seitennavigation
        pagination  = (data.get("meta") or {}).get("pagination") or {}
        total_pages = pagination.get("total_pages")
        try:
            total_pages = int(total_pages)
        except Exception:
            total_pages = 0

        if found > 0 and total_pages > page:
            next_url = build_url({"action": "rktv_vod_list",
                                  "slug": quote_plus(slug),
                                  "name": quote_plus(name),
                                  "page": str(page + 1)})
            li_next = xbmcgui.ListItem(
                colorize(f"  Weiter → Seite {page + 1}", COLOR_ACTION))
            li_next.setArt({"icon": get_source_icon("rakuten_live")})
            xbmcplugin.addDirectoryItem(HANDLE, next_url, li_next, isFolder=True)

        if found == 0:
            notify("Keine kostenlosen Inhalte in dieser Kategorie", True, 5000)

        xbmcplugin.setContent(HANDLE, "movies")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_rktv_vod_seasons(slug, name, thumb):
    """
    Staffelliste einer TV-Serie laden (/seasons/{slug}).
    Bei nur einer Staffel direkt zu den Episoden springen.
    Entspricht listSeasons() aus dem Original.
    """
    p = ProgressDialog(enabled=True)
    p.open(f"Lade Staffeln: {name} …")
    try:
        p.update(30, "Lade Staffeln …")
        data = _rktv_get_content(f"{RKTV_API}/seasons/{slug}",
                                 params=RKTV_PARAMS_PACK)
        season_data = data.get("data") or {}

        # Aktuelle Staffel + weitere Staffeln (other_seasons)
        all_seasons = [season_data]
        other = season_data.get("other_seasons") or []
        if other:
            all_seasons += other

        # Nur gültige Staffeln mit ID
        collage = [(s.get("id", ""), s) for s in all_seasons if s.get("id")]

        if not collage:
            notify(f"Keine Staffeln gefunden für: {name}", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        # Nur eine Staffel → direkt zu Episoden
        if len(collage) == 1:
            p.close()
            return view_rktv_vod_episodes(collage[0][0], name, thumb)

        p.update(80, "Baue Staffelliste …")
        for seid, sdata in collage:
            images  = sdata.get("images") or {}
            s_thumb = (images.get("snapshot") or images.get("snapshot_webp") or thumb)
            s_poster= (images.get("artwork")  or images.get("artwork_webp")  or thumb)
            s_fan   = s_thumb

            # Staffelnummer aus Titel extrahieren
            s_title = sdata.get("title") or sdata.get("display_name") or name
            s_plot  = (sdata.get("plot") or sdata.get("short_plot") or "")
            s_year  = sdata.get("year")

            label = colorize(s_title, COLOR_CHANNEL)

            li = xbmcgui.ListItem(label)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(s_title)
                tag.setPlot(s_plot)
                tag.setMediaType("season")
                if s_year:
                    tag.setYear(int(s_year))
            except Exception:
                li.setInfo("video", {"title": s_title, "plot": s_plot})

            li.setArt({"thumb": s_thumb, "poster": s_poster,
                       "fanart": s_fan, "icon": s_thumb})

            ep_url = build_url({"action": "rktv_vod_episodes",
                                "slug":  quote_plus(seid),
                                "name":  quote_plus(s_title),
                                "thumb": quote_plus(s_thumb)})
            xbmcplugin.addDirectoryItem(HANDLE, ep_url, li, isFolder=True)

        xbmcplugin.setContent(HANDLE, "seasons")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_rktv_vod_episodes(slug, name, thumb):
    """
    Episodenliste einer Staffel (/seasons/{slug}).
    Entspricht listEpisodes() aus dem Original.
    """
    p = ProgressDialog(enabled=True)
    p.open(f"Lade Episoden: {name} …")
    try:
        p.update(30, "Lade Episoden …")
        data     = _rktv_get_content(f"{RKTV_API}/seasons/{slug}",
                                     params=RKTV_PARAMS_PACK)
        season   = data.get("data") or {}
        episodes = season.get("episodes") or []

        if not episodes:
            notify(f"Keine Episoden gefunden für: {name}", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        # Show-Level Metadaten als Fallback
        show_images  = season.get("images") or {}
        show_fanart  = (show_images.get("snapshot") or show_images.get("snapshot_webp") or thumb)
        show_poster  = (show_images.get("artwork")  or show_images.get("artwork_webp")  or thumb)

        p.update(70, "Baue Episodenliste …")
        for ep in episodes:
            ep_id      = ep.get("id", "")
            ep_title   = ep.get("title") or ep.get("display_name") or ""
            ep_plot    = (ep.get("plot") or ep.get("short_plot") or "")
            ep_season  = ep.get("season_number")
            ep_num     = ep.get("number")
            ep_dur_s   = ep.get("duration_in_seconds")
            try:
                ep_dur_s = int(ep_dur_s)
            except Exception:
                ep_dur_s = None

            ep_images  = ep.get("images") or {}
            ep_thumb   = (ep_images.get("snapshot") or ep_images.get("snapshot_webp") or thumb)

            # Audio-/Untertitel-Info aus view_options für Plot
            streams = []
            vo = ep.get("view_options") or {}
            private = (vo.get("private") or {}).get("streams") or []
            for s in private:
                streams += s.get("audio_languages") or []

            # Label: S01E02 Titel
            if ep_season and ep_num:
                label = colorize(
                    f"S{int(ep_season):02d}E{int(ep_num):02d} {ep_title}", COLOR_CHANNEL)
            else:
                label = colorize(ep_title, COLOR_CHANNEL)

            li = xbmcgui.ListItem(label)
            li.setProperty("IsPlayable", "true")

            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(ep_title)
                tag.setPlot(ep_plot)
                tag.setMediaType("episode")
                if ep_season:
                    tag.setSeason(int(ep_season))
                if ep_num:
                    tag.setEpisode(int(ep_num))
                if ep_dur_s:
                    tag.setDuration(ep_dur_s)
                tag.setTvShowTitle(name)
            except Exception:
                li.setInfo("video", {"title": ep_title, "plot": ep_plot,
                                     "mediatype": "episode"})

            li.setArt({"thumb": ep_thumb, "poster": show_poster,
                       "fanart": show_fanart, "icon": ep_thumb})

            play_url = build_url({"action": "rktv_vod_play",
                                  "slug":    quote_plus(ep_id),
                                  "species": "episodes",
                                  "seid":    quote_plus(slug),
                                  "name":    quote_plus(ep_title),
                                  "thumb":   quote_plus(ep_thumb)})
            xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)

        xbmcplugin.setContent(HANDLE, "episodes")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def _widevine_ok():
    """
    Prüft via inputstreamhelper ob Widevine einsatzbereit ist.
    Falls nicht, bietet inputstreamhelper den Download automatisch an.
    Gibt True zurück wenn Widevine vorhanden und inputstream.adaptive OK.
    """
    try:
        import inputstreamhelper
        helper = inputstreamhelper.Helper("mpd", drm="com.widevine.alpha")
        if helper.check_inputstream():
            log("[Widevine] inputstreamhelper: OK")
            return True
        # check_inputstream() gibt False zurück wenn Widevine fehlt
        # und hat ggf. bereits den Download-Dialog gezeigt
        log("[Widevine] inputstreamhelper: Widevine nicht bereit", xbmc.LOGWARNING)
        return False
    except Exception as e:
        log(f"[Widevine] inputstreamhelper Fehler: {e}", xbmc.LOGWARNING)
        # Fallback: manuellen Dialog zeigen
        _prompt_widevine_manual()
        return False


def _prompt_widevine_manual():
    """
    Fallback-Dialog wenn inputstreamhelper nicht verfügbar ist.
    Öffnet direkt die inputstream.adaptive Einstellungen.
    """
    go = xbmcgui.Dialog().yesno(
        "Widevine CDM fehlt",
        "Für Rakuten VoD wird die Widevine-DRM-Bibliothek benötigt.\n\n"
        "Diese kann über [B]inputstream.adaptive[/B] kostenlos installiert werden.\n\n"
        "Jetzt die Einstellungen von inputstream.adaptive öffnen?",
        nolabel="Abbrechen",
        yeslabel="Einstellungen öffnen",
    )
    if go:
        xbmc.executebuiltin("Addon.OpenSettings(inputstream.adaptive)")


def view_rktv_vod_play(slug, species, name, thumb, seid=""):
    """
    VoD-Wiedergabe via DASH + Widevine DRM.
    Entspricht playVideo() aus dem Original.
    - Filme:    /movies/{slug}  → view_options.private.streams
    - Episoden: /seasons/{seid} → episode.view_options.private.streams
    """
    # Widevine vor allem anderen prüfen (via inputstreamhelper)
    if not _widevine_ok():
        log("[Rakuten VoD] Widevine nicht verfügbar — Abbruch", xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    sigs = _rktv_get_signatures()
    if species == "movies":
        target = f"{RKTV_API}/movies/{slug}"
    else:
        target = f"{RKTV_API}/seasons/{seid}"

    data = _rktv_get_content(target, params=RKTV_PARAMS_PACK)
    if not data:
        notify("Inhalt nicht verfügbar", True, 6000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # Streams-Array aus der richtigen Stelle holen
    if species == "movies":
        private = (data.get("data") or {}).get("view_options", {}).get(
            "private", {}).get("streams", [])
    else:
        episodes = (data.get("data") or {}).get("episodes", [])
        ep = next((e for e in episodes if e.get("id") == slug), None)
        if not ep:
            notify("Episode nicht gefunden", True, 6000)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        private = (ep.get("view_options") or {}).get("private", {}).get("streams", [])

    # Sprachen sammeln (bei 2 Streams deduplizieren wie Original)
    audio_langs = []
    subid_langs = []
    if len(private) == 1:
        audio_langs = private[0].get("audio_languages") or []
        subid_langs = private[0].get("subtitle_languages") or []
    elif len(private) >= 2:
        seen_a, seen_s = set(), set()
        for stream in private:
            for lang in (stream.get("audio_languages") or []):
                lid = lang.get("id", "")
                if lid not in seen_a:
                    seen_a.add(lid)
                    audio_langs.append(lang)
            for sub in (stream.get("subtitle_languages") or []):
                lid = sub.get("id", "")
                if lid not in seen_s:
                    seen_s.add(lid)
                    subid_langs.append(sub)

    audio_langs.sort(key=lambda x: _rktv_clean_umlaut(x.get("name", "")))
    subid_langs.sort(key=lambda x: _rktv_clean_umlaut(x.get("name", "")))

    # --- Schritt 2: Sprachauswahl ---
    audio_names = [f"[B]{l.get('name', '')}[/B]" for l in audio_langs]
    audio_codes = [l.get("id", "MIS") for l in audio_langs]

    # Deutsch bevorzugen, sonst ersten Eintrag nehmen
    audio_result = "DEU"
    if audio_codes:
        audio_result = "DEU" if "DEU" in audio_codes else audio_codes[0]
        # Dialog nur wenn mehr als eine Sprache verfügbar
        if len(audio_codes) > 1:
            plain_names = [re.sub(r"\[/?B\]", "", n) for n in audio_names]
            presel = audio_codes.index("DEU") if "DEU" in audio_codes else 0
            chosen = xbmcgui.Dialog().select(
                "Audiosprache wählen", plain_names, preselect=presel)
            if chosen >= 0:
                audio_result = audio_codes[chosen]

    log(f"[Rakuten VoD] Starte: {name} | Audio: {audio_result} | Species: {species}")

    # --- Schritt 3: Stream-URL von API holen ---
    payload = {
        "audio_language":           audio_result,
        "audio_quality":            "2.0",
        "classification_id":        RKTV_CLASSIFY,
        "content_id":               slug,
        "content_type":             species,
        "device_make":              "chrome",
        "device_model":             "GENERIC",
        "device_serial":            "not implemented",
        "device_stream_video_quality": "FHD",
        "device_uid":               sigs.get("device_uid", "unknown"),
        "hdr_type":                 "NONE",
        "player":                   "web:DASH-CENC:WVM",
        "publisher_provided_id":    sigs.get("publisher_provided_id", "unknown"),
        "video_type":               "stream",
        "subtitle_formats":         ["vtt"],
        "subtitle_language":        "MIS",
        "support_closed_captions":  True,
        "strict_video_quality":     False,
    }

    args_params = {
        "classification_id":  RKTV_CLASSIFY,
        "device_identifier":  "web",
        "market_code":        RKTV_MARKET,
    }

    stream_data = _rktv_get_content(
        f"{RKTV_API}/avod/streamings",
        method="POST",
        params=args_params,
        json_data=payload,
        timeout=30,
    )

    stream_infos = (stream_data.get("data") or {}).get("stream_infos") or []
    if not stream_infos:
        log(f"[Rakuten VoD] Keine Stream-URL für {slug}", xbmc.LOGERROR)
        notify("Stream nicht verfügbar", True, 8000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    final_url = stream_infos[0].get("url", "")
    drm_url   = stream_infos[0].get("license_url")

    # Untertitel aus stream_infos (vtt)
    all_subs  = [s for s in (stream_infos[0].get("all_subtitles") or [])
                 if s.get("format") == "vtt"]

    sub_url = None
    # Deutschen Untertitel bevorzugen, sonst nichts setzen
    for sub in all_subs:
        if sub.get("language", "") == "DEU" and sub.get("url"):
            sub_url = sub["url"]
            break

    log(f"[Rakuten VoD] DASH-URL: {final_url} | DRM: {'ja' if drm_url else 'nein'}")

    # --- Schritt 4: ListItem aufbauen ---
    li = xbmcgui.ListItem(name, path=final_url)
    li.setProperty("IsPlayable", "true")

    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(name)
        tag.setMediaType("movie" if species == "movies" else "episode")
    except Exception:
        li.setInfo("video", {"title": name})

    if thumb:
        li.setArt({"thumb": thumb, "icon": thumb})

    # --- Schritt 5: inputstream.adaptive + Widevine DRM konfigurieren ---
    try:
        ia = xbmcaddon.Addon("inputstream.adaptive")
        ia_ver_raw = ia.getAddonInfo("version")
        log(f"[Rakuten VoD] inputstream.adaptive {ia_ver_raw}")

        li.setMimeType("application/dash+xml")
        li.setContentLookup(False)
        li.setProperty("inputstream", "inputstream.adaptive")

        drm_headers = {
            "User-Agent": RKTV_AGENT,
            "Referer":    RKTV_BASE_URL,
            "Content-Type": "text/html",
        }

        # Gemeinsame DRM-Konfiguration für Kodi 19 (Matrix), 20 (Nexus) und
        # 21 (Omega). Die klassischen ISA-Eigenschaften werden bis Kodi 21
        # unterstützt und vermeiden eine harte Abhängigkeit von ISA >= 21.5.0.
        li.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
        if drm_url:
            li.setProperty("inputstream.adaptive.license_key",
                           f"{drm_url}|{urlencode(drm_headers)}|R{{SSM}}|")

        if RKTV_KODI_GE20:
            li.setProperty("inputstream.adaptive.manifest_headers",
                           f"User-Agent={RKTV_AGENT}")

        if sub_url:
            li.setSubtitles([sub_url])

        xbmcplugin.setResolvedUrl(HANDLE, True, li)

        # Untertitel aktivieren falls gesetzt
        if sub_url:
            for _ in range(50):
                if xbmc.Player().isPlaying():
                    xbmc.Player().showSubtitles(True)
                    break
                xbmc.sleep(200)

    except Exception as e:
        log(f"[Rakuten VoD] inputstream.adaptive Fehler: {e}", xbmc.LOGERROR)
        notify("inputstream.adaptive nicht verfügbar", True, 6000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def view_rktv_categories():
    """Zeigt die Rakuten-Live-Kategorien (entspricht listCategoriesTV)."""
    cat_ttl = get_rktv_cache_seconds() // 3600 or 1
    cached_cats = _rktv_preserve(RKTV_CHANNEL_FILE, cat_ttl)
    cache_ready = bool(cached_cats)
    if cache_ready:
        log("[Rakuten Live] Kategorien aus Cache - kein Lade-Dialog")
    p = ProgressDialog(enabled=not cache_ready)
    p.open("Lade Rakuten Live TV …")
    try:
        p.update(20, "Lade Kategorien …")
        cats = rktv_load_categories()
        if not cats:
            notify("Keine Kategorien gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(90, "Baue Menü …")
        src_icon = get_source_icon("rakuten_live")
        all_live_name = "LIVE TV | Alle (DE)"
        category_names = list(cats.keys())
        category_names.sort(key=lambda name: (0 if name == all_live_name else 1, name.casefold()))
        for cat_name in category_names:
            label = colorize(cat_name, COLOR_GROUP)
            url = build_url({"action": "rktv_channels", "cat": quote_plus(cat_name)})
            li = xbmcgui.ListItem(label)
            li.setArt({"icon": src_icon, "thumb": src_icon, "fanart": src_icon})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_rktv_channels(cat_name):
    """
    Zeigt Sender einer Kategorie mit EPG.
    Entspricht listChannelsTV() aus Rakuten navigator.py.

    Sind Senderliste, Kategorien und EPG noch im Cache, wird die Ansicht ohne
    Dialog sofort wiederhergestellt. Das ist insbesondere der normale Weg,
    wenn man einen laufenden Rakuten-Sender beendet und zu Kodi zurückkehrt.
    """
    cat_ttl = get_rktv_cache_seconds() // 3600 or 1
    epg_ttl = max(1, get_rktv_epg_cache_seconds() // 3600)
    cached_cats = _rktv_preserve(RKTV_CHANNEL_FILE, cat_ttl)
    cached_live = _rktv_preserve(RKTV_LIVE_DATA_FILE, cat_ttl)
    cached_epg = _rktv_preserve(RKTV_EPG_FILE, epg_ttl)
    use_epg = epg_enabled("rakuten_live")
    cache_ready = bool(
        cached_cats and cat_name in cached_cats
        and isinstance(cached_live, dict) and cached_live.get("data")
        and (not use_epg or _rktv_epg_has_programs(cached_epg))
    )
    if cache_ready:
        log(f"[Rakuten Live] Senderansicht aus Cache: {cat_name} - kein Lade-Dialog")

    p = ProgressDialog(enabled=not cache_ready)
    p.open(f"Lade {cat_name} …")
    try:
        p.update(10, "Lade Kategorien …")
        cats = rktv_load_categories()
        channel_ids = cats.get(cat_name, [])
        if not channel_ids:
            notify("Keine Sender in dieser Kategorie", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(35, "Lade Sender …")
        # Die funktionierende Web-API-Senderliste ist die primaere Quelle.
        # Ein EPG-Fehler darf diese Liste niemals mehr leeren.
        base_data = _rktv_load_all_live_channels()
        all_channels = base_data.get("data", []) if isinstance(base_data, dict) else []

        epg_channels_data = []
        if use_epg:
            p.update(45, "Lade EPG …")
            epg_data = rktv_load_epg()
            epg_channels_data = epg_data.get("data", []) if isinstance(epg_data, dict) else []

        # EPG optional per Channel-ID auf die bereits geladenen Sender mergen.
        epg_by_id = {str(ch.get("id")): ch for ch in epg_channels_data if isinstance(ch, dict) and ch.get("id") is not None}
        if epg_by_id:
            merged = []
            for ch in all_channels:
                if not isinstance(ch, dict):
                    continue
                epg_ch = epg_by_id.get(str(ch.get("id")))
                if epg_ch and epg_ch.get("live_programs"):
                    ch = dict(ch)
                    ch["live_programs"] = epg_ch.get("live_programs") or []
                merged.append(ch)
            all_channels = merged
        elif use_epg:
            log("[Rakuten Live] EPG nicht verfuegbar - zeige Sender ohne EPG", xbmc.LOGWARNING)

        epg_channels = sum(1 for ch in all_channels if isinstance(ch, dict) and ch.get("live_programs"))
        log(f"[Rakuten Live] Senderansicht: {len(all_channels)} Sender, {epg_channels} mit EPG")

        show_epg = use_epg and ADDON.getSetting("show_epg_in_label") != "false"

        p.update(70, "Baue Senderliste …")
        collage = []
        for item in all_channels:
            if item.get("id", "") not in channel_ids:
                continue
            cid   = item["id"]
            name  = item["title"]
            lang  = item["labels"]["languages"][0]["id"]
            logo  = (item["images"].get("artwork") or item["images"].get("artwork_webp") or "")
            progs = item.get("live_programs", [])
            guides = _rktv_get_schedules(progs)

            # now/next direkt aus live_programs bestimmen (UTC-Vergleich)
            now_utc = datetime.utcnow()
            now_item = None
            next_item = None
            for elem in progs:
                start = _rktv_parse_dt(elem.get("starts_at", ""))
                end   = _rktv_parse_dt(elem.get("ends_at", ""))
                if start is None or end is None:
                    continue
                if start <= now_utc < end:
                    now_item = {
                        "title": elem.get("title") or "",
                        "start_dt": start,
                        "end_dt": end,
                        "desc": elem.get("description") or elem.get("subtitle") or "",
                    }
                elif start > now_utc and next_item is None:
                    next_item = {
                        "title": elem.get("title") or "",
                        "start_dt": start,
                        "end_dt": end,
                        "desc": elem.get("description") or elem.get("subtitle") or "",
                    }
                if now_item and next_item:
                    break

            collage.append((cid, name, lang, guides, logo, now_item, next_item))

        collage.sort(key=lambda x: _rktv_clean_umlaut(x[1]).lower())

        favs = load_favs()
        show_chnos = ADDON.getSetting("show_chnos") != "false"
        for display_chno, (cid, name, lang, guides, logo, now_item, next_item) in enumerate(collage, start=1):
            # Rakuten liefert keine klassische Sendernummer. Fuer dieselbe
            # Darstellung wie bei Pluto/Samsung/Plex/Free-TV wird nur das
            # sichtbare Label nummeriert; die Rakuten-ID und Wiedergabelogik
            # bleiben unveraendert.
            label = colorize(f"{display_chno} | {name}", COLOR_CHANNEL) if show_chnos else colorize(name, COLOR_CHANNEL)


            # Rakuten-Datumswerte in dasselbe Epoch-Format umsetzen, das
            # Plex/Pluto/Samsung/M3U bereits fuer epg_label_parts verwenden.
            def _rktv_common_item(item):
                if not item:
                    return None
                st = item.get("start_dt")
                en = item.get("end_dt")
                return {
                    "title": item.get("title") or "",
                    "start": int(st.replace(tzinfo=timezone.utc).timestamp()) if st else None,
                    "stop": int(en.replace(tzinfo=timezone.utc).timestamp()) if en else None,
                    "desc": item.get("desc") or "",
                }

            epg_item = {"now": _rktv_common_item(now_item), "next": _rktv_common_item(next_item)}
            now_str, next_str, plot, now_range, now_colored = epg_label_parts(epg_item)
            if not plot and guides:
                plot = guides.replace("[CR]", "\n")

            if show_epg and now_colored:
                label = f"{label}  {now_colored}"

            li = xbmcgui.ListItem(label)
            li.setProperty("IsPlayable", "true")
            if next_str:
                li.setLabel2(next_str)

            title_for_skins = name
            if now_str:
                title_for_skins = f"{name}  {now_str}"
            set_video_info(li, title_for_skins, plot)

            if logo:
                logo_local = get_logo_local(logo, force=False)
                set_art(li, logo_local or logo)

            ch_dict = {"name": name, "url": f"rktv://{cid}", "logo": logo,
                       "group": cat_name, "tvgid": cid, "tvgname": name, "channel_id": cid,
                       "rktv_lang": lang, "source_id": "rakuten_live"}
            if is_fav(ch_dict, favs):
                cm = [("Favorit entfernen", "RunPlugin(%s)" % build_url(
                    {"action": "fav_del", "key": quote_plus(fav_key(ch_dict))}))]
            else:
                payload = quote_plus(json.dumps(ch_dict, ensure_ascii=False))
                cm = [("Zu Favoriten", "RunPlugin(%s)" % build_url(
                    {"action": "fav_add", "data": payload}))]
            li.addContextMenuItems(cm)

            play_url = build_url({
                "action": "rktv_play",
                "slug": quote_plus(cid),
                "lang": quote_plus(lang),
                "name": quote_plus(name),
                "pic":  quote_plus(logo),
                "plot": quote_plus(guides),
            })
            xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)

        if not collage:
            notify("Keine Sender gefunden", True, 5000)

        xbmcplugin.setContent(HANDLE, "episodes")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def play_rktv_live(slug, lang, name, pic, plot):
    """
    Spielt einen Rakuten-Live-Sender ab.
    Identisch zu playLive(ACTION='RKTV') aus Rakuten navigator.py.
    """
    slug  = unquote_plus(slug)
    lang  = unquote_plus(lang)
    name  = unquote_plus(name)
    pic   = unquote_plus(pic)
    plot  = unquote_plus(plot)

    sigs = _rktv_get_signatures()

    payload = {
        "audio_language":           lang,
        "audio_quality":            "2.0",
        "classification_id":        RKTV_CLASSIFY,
        "content_id":               slug,
        "content_type":             "live_channels",
        "device_make":              "chrome",
        "device_model":             "GENERIC",
        "device_serial":            "not implemented",
        "device_stream_video_quality": "FHD",
        "device_uid":               sigs.get("device_uid", "unknown"),
        "device_year":              1970,
        "hdr_type":                 "NONE",
        "player":                   "web:HLS-NONE:NONE",
        "video_type":               "stream",
        "publisher_provided_id":    sigs.get("publisher_provided_id", "unknown"),
        "strict_video_quality":     False,
        "subtitle_formats":         ["vtt"],
        "subtitle_language":        "MIS",
        "support_closed_captions":  True,
        "support_thumbnails":       True,
    }

    data = _rktv_get_content(
        f"{RKTV_API}/avod/streamings",
        method="POST",
        params=RKTV_PARAMS_PACK,
        json_data=payload,
        timeout=30,
    )

    stream_infos = (data.get("data") or {}).get("stream_infos", [])
    if not stream_infos:
        log(f"[Rakuten Live] Keine Stream-URL fuer {slug}", xbmc.LOGERROR)
        notify("Stream nicht verfuegbar (Geoblocking oder API-Fehler)", True, 8000)
        return

    final_url = f"{stream_infos[0]['url']}|User-Agent={quote_plus(RKTV_AGENT)}&Referer={RKTV_BASE_URL}"
    log(f"[Rakuten Live] HLS-Stream: {final_url}")

    li = xbmcgui.ListItem(name, path=final_url)
    li.setProperty("IsPlayable", "true")
    set_video_info(li, name, "")
    if pic:
        set_art(li, pic)

    # inputstream.adaptive fuer HLS
    try:
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setProperty("inputstream", "inputstream.adaptive")
        if RKTV_KODI_LE20:
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
        if RKTV_KODI_GE20:
            li.setProperty("inputstream.adaptive.manifest_headers", f"User-Agent={RKTV_AGENT}")
        else:
            li.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={RKTV_AGENT}")
        # Hinweis: Rakuten Live TV liefert unverschluesseltes HLS - keine DRM-Property noetig.
    except Exception as e:
        log(f"[Rakuten Live] inputstream.adaptive nicht verfuegbar: {e}", xbmc.LOGWARNING)

    # setResolvedUrl statt xbmc.Player().play() - verhindert Endlosschleife im Playlist-Player
    WIN.setProperty(RETURN_FROM_PLAY_FLAG, "1")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

