# -*- coding: utf-8 -*-
"""Ausgelagerte Provider-Implementierung."""

# ----------------------------------------------------------
# Natives JSON-Format laden (Pluto TV / Samsung TV Plus)
# Entspricht _data() + _app_data() im originalen SlyGuy-Addon
# ----------------------------------------------------------

def parse_epg_from_programs(programs):
    """
    Liest EPG direkt aus programs[]-Array des JSON (identisch zur SlyGuy-Logik).
    Format: [[unix_timestamp_start, "Titel"], ...]
    Gibt (now_item, next_item) als Dicts zurueck.
    """
    if not programs:
        return None, None

    now_ts = int(time.time())
    now_item = None
    next_item = None

    for i, row in enumerate(programs):
        if not row or len(row) < 2:
            continue
        start = row[0]
        stop = programs[i + 1][0] if i + 1 < len(programs) else start + 3600
        title = row[1] or ""

        if start <= now_ts < stop:
            now_item = {"start": start, "stop": stop, "title": title}
        elif start > now_ts and next_item is None:
            next_item = {"start": start, "stop": stop, "title": title}
            break

    return now_item, next_item


def load_json_channels(source, force=False):
    """
    Laedt .channels.json.gz von i.mjh.nz.
    EPG wird direkt aus programs[]-Array gelesen (wie SlyGuy-Original).
    """
    src_url = source.get("url", "")
    region = (source.get("region") or "de").lower()
    sid = source.get("id", "")
    if sid == "pluto":
        cache_sec = get_pluto_cache_seconds()
    elif sid == "samsung":
        cache_sec = get_samsung_cache_seconds()
    else:
        # Plex (und ggf. weitere zukuenftige JSON-Quellen) nutzen den
        # allgemeinen M3U-Senderlisten-Cache.
        cache_sec = get_m3u_cache_seconds()
    cpath = cache_path("json", src_url + region)

    if not force and xbmcvfs.exists(cpath):
        cached = read_json(cpath, {})
        if cached.get("ts") and (time.time() - cached["ts"]) <= cache_sec:
            log(f"JSON CACHE HIT [{sid}] channels={len(cached.get('channels', []))}")
            return cached.get("channels", []), cached.get("slug", "")

    log(f"JSON FETCH [{sid}] url={src_url}")
    try:
        r = requests.get(src_url, headers=HEADERS, timeout=35)
        r.raise_for_status()
        raw = r.content
        if src_url.endswith(".gz") or (len(raw) >= 2 and raw[:2] == b"\x1f\x8b"):
            raw = gzip.decompress(raw)
        data = json.loads(raw.decode("utf-8"))
    except Exception as e:
        log(f"JSON load failed [{sid}]: {e}", xbmc.LOGERROR)
        # Bei einem temporaeren Provider-/Netzfehler lieber den letzten
        # vorhandenen Stand zeigen als eine leere Senderliste.
        stale = read_json(cpath, {}) if xbmcvfs.exists(cpath) else {}
        if stale.get("channels"):
            log(f"JSON STALE CACHE FALLBACK [{sid}] channels={len(stale.get('channels', []))}", xbmc.LOGWARNING)
            return stale.get("channels", []), stale.get("slug", "")
        notify("Kanal-Daten konnten nicht geladen werden (siehe Log)", True, 6000)
        return [], ""

    slug_template = data.get("slug", "")
    regions_data = data.get("regions", {})

    if region not in regions_data:
        log(f"JSON [{sid}] Region '{region}' nicht angeboten - kein Regions-Fallback", xbmc.LOGWARNING)
        show_region_unavailable_dialog()
        return [], slug_template
    selected_regions = {region: regions_data[region]}

    seen_ids = set()
    channels = []

    for reg_code, reg_data in selected_regions.items():
        reg_name = reg_data.get("name", reg_code)
        reg_channels = reg_data.get("channels", {})

        for ch_id, ch in reg_channels.items():
            if ch_id in seen_ids:
                continue
            if ch.get("license_url"):
                continue
            seen_ids.add(ch_id)

            playback_tpl = source.get("playback_url", "")
            if "{slug}" in playback_tpl:
                ch_slug = slug_template.format(id=ch_id) if slug_template else ch_id
                stream_url = playback_tpl.format(slug=ch_slug)
            else:
                stream_url = playback_tpl.format(id=ch_id)
            stream_url = stream_url.replace("{PSID}", PLUTO_DEVICE_ID).replace("%7BPSID%7D", PLUTO_DEVICE_ID)

            # EPG nur verarbeiten, wenn es fuer diese Quelle aktiviert ist.
            if epg_enabled(sid):
                epg_now, epg_next = parse_epg_from_programs(ch.get("programs", []))
            else:
                epg_now, epg_next = None, None

            channels.append({
                "name":      ch.get("name", ch_id),
                "url":       stream_url,
                "logo":      ch.get("logo", ""),
                "group":     ch.get("group", reg_name),
                "tvgid":     ch_id,
                "tvgname":   ch.get("name", ""),
                "channel_id": ch_id,
                "chno":      ch.get("chno", 9999),
                "epg_now":   epg_now,
                "epg_next":  epg_next,
            })

    channels.sort(key=lambda c: (c.get("chno", 9999), (c.get("name") or "").lower()))
    write_json_compact(cpath, {"ts": time.time(), "channels": channels, "slug": slug_template})
    log(f"JSON LOADED [{sid}] region={region} channels={len(channels)}")
    return channels, slug_template


FREE_DE_GROUP_MAP = {
    "general": "Allgemein",
    "entertainment": "Unterhaltung",
    "news": "Nachrichten",
    "business": "Wirtschaft",
    "documentary": "Dokus & Wissen",
    "education": "Bildung & Wissen",
    "science": "Dokus & Wissen",
    "culture": "Kultur",
    "movies": "Filme",
    "movie": "Filme",
    "series": "Serien",
    "comedy": "Unterhaltung",
    "kids": "Kinder & Familie",
    "family": "Kinder & Familie",
    "music": "Musik",
    "sports": "Sport",
    "sport": "Sport",
    "auto": "Auto & Motor",
    "travel": "Reisen",
    "outdoor": "Natur & Outdoor",
    "nature": "Natur & Outdoor",
    "lifestyle": "Lifestyle",
    "cooking": "Kochen",
    "food": "Kochen",
    "weather": "Wetter",
    "legislative": "Politik",
    "government": "Politik",
    "regional": "Regional",
    "local": "Regional",
    "shop": "Shopping",
    "religious": "Religion",
    "undefined": "Weitere Sender",
}


