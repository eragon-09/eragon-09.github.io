# -*- coding: utf-8 -*-
"""Titan Smart TV Plus - ausgelagerte gemeinsame Logik.

Wird bewusst in den gemeinsamen Addon-Kontext geladen, damit die bestehende
Provider-/Kodi-Logik unveraendert bleibt.
"""

def fmt_time(epoch):
    if not epoch:
        return ""
    dt = datetime.fromtimestamp(int(epoch), tz=timezone.utc).astimezone()
    return dt.strftime("%H:%M")


def epg_label_parts(epg_item):
    """Einheitliche Titan-EPG-Darstellung fuer alle Provider.

    Rueckgabe bleibt kompatibel mit den bisherigen Aufrufern:
    now_str, next_str, plot, now_time, now_colored
    """
    if not epg_item:
        return "", "", "", "", ""

    now = epg_item.get("now") or {}
    nxt = epg_item.get("next") or {}

    def _range(item):
        if not item:
            return ""
        st = fmt_time(item.get("start"))
        en = fmt_time(item.get("stop") or item.get("end"))
        if st and en:
            return f"{st} – {en}"
        return st or en

    now_title = (now.get("title") or "").strip()
    next_title = (nxt.get("title") or "").strip()
    now_range = _range(now)
    next_range = _range(nxt)

    now_str = f"{now_range} · {now_title}".strip(" ·") if now_title else ""
    next_str = f"{next_range} · {next_title}".strip(" ·") if next_title else ""

    # Player-Info kompakt: Titel links, Zeitblock dahinter. Die Restlaufzeit
    # der aktuellen Sendung uebernimmt nach Moeglichkeit die Akzentfarbe
    # des aktiven Kodi-Skins. Kein JETZT/DANACH-Praefix.
    def _skin_accent_color():
        # Skins benennen ihre Akzentfarbe leider nicht einheitlich. Die
        # gaengigsten Skin.String-Werte zuerst pruefen; ansonsten Kodi's
        # skin-eigenen Farbnamen "button_focus" verwenden.
        for label in (
            "Skin.String(AccentColor)",
            "Skin.String(HighlightColor)",
            "Skin.String(color)",
            "Skin.String(Color)",
        ):
            try:
                value = (xbmc.getInfoLabel(label) or "").strip()
            except Exception:
                value = ""
            if value and re.match(r"^(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8}|[A-Za-z_][A-Za-z0-9_]*)$", value):
                return value
        return "button_focus"

    def _duration_minutes(item):
        try:
            st = int(item.get("start") or 0)
            en = int(item.get("stop") or item.get("end") or 0)
            if st and en > st:
                return max(1, int(round((en - st) / 60.0)))
        except Exception:
            pass
        return 0

    def _remaining_minutes(item):
        try:
            en = int(item.get("stop") or item.get("end") or 0)
            if en:
                return max(0, int((en - time.time() + 59) // 60))
        except Exception:
            pass
        return 0

    plot_lines = []
    if now_title:
        rest = _remaining_minutes(now)
        rest_txt = f"+{rest} min" if rest else ""
        rest_colored = f"[COLOR {_skin_accent_color()}]{rest_txt}[/COLOR]" if rest_txt else ""
        timing = now_range
        if timing and rest_colored:
            timing += f" · {rest_colored}"
        current_line = f"[B]{now_title}[/B]  {timing}".strip()
        plot_lines.append(current_line)
    if next_title:
        duration = _duration_minutes(nxt)
        duration_txt = f"{duration} min" if duration else ""
        timing = next_range
        if timing and duration_txt:
            timing += f" · {duration_txt}"
        next_line = f"{next_title}  {timing}".strip()
        plot_lines.append(next_line)

    now_colored = ""
    if now_title:
        time_part = f"[COLOR lightgray]{now_range}[/COLOR] " if now_range else ""
        now_colored = f"{time_part}[COLOR FFFFBF00]{now_title}[/COLOR]"

    return now_str, next_str, "\n".join(plot_lines), now_range, now_colored

