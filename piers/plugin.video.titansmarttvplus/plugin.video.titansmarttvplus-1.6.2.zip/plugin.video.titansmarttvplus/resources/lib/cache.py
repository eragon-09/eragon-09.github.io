# -*- coding: utf-8 -*-
"""Titan Smart TV Plus - ausgelagerte gemeinsame Logik.

Wird bewusst in den gemeinsamen Addon-Kontext geladen, damit die bestehende
Provider-/Kodi-Logik unveraendert bleibt.
"""

# Einheitliche Aktualisierungsintervalle. Der letzte Wert entspricht
# "Nur manuell" und ist absichtlich praktisch unbegrenzt; Force-Reload und
# Cache-Loeschen funktionieren weiterhin sofort.
_CACHE_INTERVAL_MAP = [15*60, 30*60, 3600, 3*3600, 6*3600, 12*3600, 24*3600, 48*3600, 10**12]


def _get_cache_seconds(setting_id, default_idx):
    try:
        idx = int(ADDON.getSetting(setting_id) or str(default_idx))
        return _CACHE_INTERVAL_MAP[min(max(idx, 0), len(_CACHE_INTERVAL_MAP)-1)]
    except Exception:
        return _CACHE_INTERVAL_MAP[default_idx]


def get_pluto_cache_seconds():
    return _get_cache_seconds("cache_pluto_interval", 4)

def get_samsung_cache_seconds():
    return _get_cache_seconds("cache_samsung_interval", 4)

def get_rktv_cache_seconds():
    return _get_cache_seconds("cache_rktv_interval", 4)

def get_rktv_epg_cache_seconds():
    return _get_cache_seconds("cache_rktv_epg_interval", 2)

def get_plex_epg_cache_seconds():
    return _get_cache_seconds("cache_plex_epg_interval", 4)

def get_pluto_vod_cache_seconds():
    return _get_cache_seconds("cache_pluto_vod_interval", 5)

def get_m3u_cache_seconds(source_id="free_de"):
    sid = (source_id or "free_de").strip().lower()
    setting = "cache_free_de2_interval" if sid.endswith("2") else "cache_free_de_interval"
    return _get_cache_seconds(setting, 5)

def get_epg_cache_seconds(source_id="free_de"):
    sid = (source_id or "free_de").strip().lower()
    setting = "cache_free_de2_epg_interval" if sid.endswith("2") else "cache_free_de_epg_interval"
    return _get_cache_seconds(setting, 5)
