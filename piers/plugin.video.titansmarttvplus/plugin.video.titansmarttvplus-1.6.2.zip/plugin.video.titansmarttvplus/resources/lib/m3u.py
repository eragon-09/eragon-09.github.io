# -*- coding: utf-8 -*-
"""Titan Smart TV Plus - ausgelagerte gemeinsame Logik.

Wird bewusst in den gemeinsamen Addon-Kontext geladen, damit die bestehende
Provider-/Kodi-Logik unveraendert bleibt.
"""

def _free_de_group_name(raw_group):
    """Uebersetzt/vereinheitlicht iptv-org-Gruppen fuer die Kodi-Ansicht."""
    g = (raw_group or "").strip()
    if not g:
        return "Weitere Sender"
    low = g.lower()
    # iptv-org kann mehrere Begriffe oder leicht abweichende Gruppennamen nutzen.
    for key, title in FREE_DE_GROUP_MAP.items():
        if key in low:
            return title
    return g


def curate_free_de_channels(channels, source_id="free_de"):
    """Kuratierte deutschsprachige Free-TV-Liste: sauber gruppiert und dedupliziert."""
    out = []
    seen_urls = set()
    seen_ids = set()
    for ch in channels or []:
        name = (ch.get("name") or "").strip()
        url = (ch.get("url") or "").strip()
        if not name or not url:
            continue

        # Duplikate innerhalb der aggregierten Sprachliste entfernen. tvg-id ist
        # bevorzugt, URL dient als zusaetzliche Absicherung.
        cid = (ch.get("channel_id") or ch.get("tvgid") or "").strip().lower()
        url_key = url.lower()
        if url_key in seen_urls:
            continue
        if cid and cid in seen_ids:
            continue
        seen_urls.add(url_key)
        if cid:
            seen_ids.add(cid)

        item = dict(ch)
        item["group"] = _free_de_group_name(item.get("group"))
        out.append(item)

    # Interessante/gaengige Bereiche zuerst; unbekannte Gruppen bleiben erhalten.
    order = {
        "Allgemein": 10, "Nachrichten": 20, "Regional": 30,
        "Filme": 40, "Serien": 50, "Unterhaltung": 60,
        "Dokus & Wissen": 70, "Bildung & Wissen": 75,
        "Sport": 80, "Auto & Motor": 90, "Musik": 100,
        "Kinder & Familie": 110, "Kultur": 120, "Reisen": 130,
        "Natur & Outdoor": 140, "Lifestyle": 150, "Kochen": 160,
        "Wirtschaft": 170, "Politik": 180, "Wetter": 190,
        "Religion": 900, "Shopping": 910, "Weitere Sender": 999,
    }
    out.sort(key=lambda c: (order.get(c.get("group"), 500), (c.get("group") or "").lower(), (c.get("name") or "").lower()))
    log(f"FREE {str(source_id).replace('free_', '').upper()} curated channels={len(out)}")
    return out


def load_channels(source, force=False):
    """Einheitlicher Loader: gibt (channels, m3u_text) zurueck."""
    if source.get("type") == "pluto_native":
        return load_pluto_live_channels(force=force), ""
    if source.get("type") == "json":
        channels, _ = load_json_channels(source, force=force)
        return channels, ""
    elif source.get("type") == "plex_de_static":
        return load_plex_de_static(), ""
    elif source.get("type") == "rktv_live":
        return [], ""  # wird nie direkt aufgerufen; view_rktv_* uebernehmen
    else:
        text = load_m3u_text(source, force=force)
        channels, _ = parse_m3u(text, source.get("name", ""))
        if source.get("id") == "free_de" or source.get("curated"):
            channels = curate_free_de_channels(channels, source.get("id", "free_de"))
        return channels, text


EXTM3U_EPG_RE = re.compile(r'(?:url-tvg|x-tvg-url)\s*=\s*"([^"]+)"', re.IGNORECASE)


LOGO_RE = re.compile(r'tvg-logo="([^"]+)"', re.IGNORECASE)


GROUP_RE = re.compile(r'group-title="([^"]+)"', re.IGNORECASE)


TVGID_RE = re.compile(r'tvg-id="([^"]+)"', re.IGNORECASE)


TVGNAME_RE = re.compile(r'tvg-name="([^"]+)"', re.IGNORECASE)


CHANNELID_RE = re.compile(r'channel-id="([^"]+)"', re.IGNORECASE)


def load_m3u_text(source, force=False):
    started = time.time()
    source_id = (source.get("id") or "m3u").strip() or "m3u"
    url = (source.get("url") or "").strip()
    if not url:
        return ""
    cpath = cache_path("m3u", url)

    cache_secs = get_m3u_cache_seconds(source_id)
    if (not force) and cache_secs > 0 and xbmcvfs.exists(cpath):
        cache = read_json(cpath, {})
        ts = cache.get("ts", 0)
        if ts and (time.time() - ts) <= cache_secs:
            text = cache.get("text", "")
            log(f"[M3U:{source_id}] CACHE HIT bytes={len(text.encode('utf-8', 'ignore'))} ms={int((time.time()-started)*1000)}")
            return text

    try:
        r = requests.get(url, headers=HEADERS, timeout=35)
        r.raise_for_status()
        txt = r.text
        if cache_secs > 0:
            write_json(cpath, {"ts": time.time(), "text": txt})
        log(f"[M3U:{source_id}] FETCH OK bytes={len(txt.encode('utf-8', 'ignore'))} ms={int((time.time()-started)*1000)}")
        return txt
    except Exception as e:
        log(f"M3U load failed: {url} -> {e}", xbmc.LOGERROR)
        stale = read_json(cpath, {}) if xbmcvfs.exists(cpath) else {}
        if stale.get("text"):
            log(f"M3U STALE CACHE FALLBACK: {url}", xbmc.LOGWARNING)
            return stale.get("text", "")
        notify("M3U Fehler (siehe Log)", True, 6000)
        return ""


def parse_m3u(text, default_group):
    started = time.time()
    channels = []
    epg_url = ""

    if not text:
        return channels, epg_url

    lines = text.splitlines()

    for ln in lines[:15]:
        ln = (ln or "").strip()
        if ln.startswith("#EXTM3U"):
            m = EXTM3U_EPG_RE.search(ln)
            if m:
                epg_url = (m.group(1) or "").strip()
            break

    name = ""
    logo = ""
    group = default_group
    tvgid = ""
    tvgname = ""
    channel_id = ""

    for line in lines:
        line = (line or "").strip()
        if not line:
            continue
        if line.startswith("#EXTINF"):
            m = re.search(r",(.*)$", line)
            name = m.group(1).strip() if m else "Channel"
            lm = LOGO_RE.search(line)
            logo = lm.group(1).strip() if lm else ""
            gm = GROUP_RE.search(line)
            group = gm.group(1).strip() if gm else default_group
            im = TVGID_RE.search(line)
            tvgid = im.group(1).strip() if im else ""
            nm = TVGNAME_RE.search(line)
            tvgname = nm.group(1).strip() if nm else ""
            cm = CHANNELID_RE.search(line)
            channel_id = cm.group(1).strip() if cm else ""
        elif not line.startswith("#"):
            channels.append(
                {
                    "name": name or "Channel",
                    "url": line,
                    "logo": logo,
                    "group": group or default_group,
                    "tvgid": tvgid,
                    "tvgname": tvgname,
                    "channel_id": channel_id,
                }
            )

    log(f"[M3U] PARSED channels={len(channels)} ms={int((time.time()-started)*1000)}")
    return channels, epg_url


def _epg_paths(epg_url):
    """
    Liefert (meta_p, xml_p, idx_p) fuer eine EPG-URL.
    Pfade werden ausschliesslich ueber den SHA1-Hash der URL gebildet (nicht
    ueber die Source-ID) - dadurch teilen sich mehrere Quellen mit identischer
    EPG-URL (z.B. Germany 1-3, die alle standardmaessig xmltv.info/de/epg.xml
    nutzen) automatisch denselben Cache statt dreifach zu laden/parsen.
    """
    h = sha1(epg_url)
    meta_p = EPG_DIR + f"meta_{h}.json"
    xml_p  = EPG_DIR + f"epg_{h}.xml"
    idx_p  = EPG_DIR + f"index_{h}.json"
    return meta_p, xml_p, idx_p


def _epg_name_key(value):
    """Normalisiert Sendernamen fuer einen vorsichtigen XMLTV-Fallback."""
    value = (value or "").strip().lower()
    if not value:
        return ""
    # IPTV-EPG.org verwendet Display-Namen wie "DE - 3sat".
    value = re.sub(r"^de\s*-\s*", "", value, flags=re.I)
    # Typische iptv-org-Zusaetze entfernen, z.B. "(720p)" oder "[Geo-blocked]".
    value = re.sub(r"\[[^\]]*\]", " ", value)
    value = re.sub(r"\((?:\d{3,4}p|fhd|uhd|hd|sd|4k)\)", " ", value, flags=re.I)
    value = value.replace("+", " plus ")
    value = value.replace("&", " und ")
    value = re.sub(r"\b(?:hd|uhd|fhd|sd|4k)\b", " ", value, flags=re.I)
    value = value.replace("ß", "ss")
    value = value.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue")
    return re.sub(r"[^a-z0-9]+", "", value)


def _resolve_m3u_epg(channel, epg_map):
    """EPG ueber ID, Sendernamen und normalisierte XMLTV-ID aufloesen."""
    ids = []
    for cid in (channel.get("channel_id"), channel.get("tvgid")):
        cid = (cid or "").strip()
        if cid:
            # iptv-org Varianten wie DasErste.de@HD, 3sat.de@SD oder
            # Sender.de@DACH auf die XMLTV-Basis-ID reduzieren.
            base_id = cid.split("@", 1)[0].strip()
            ids.extend((cid, cid.lower(), base_id, base_id.lower()))
    for cid in ids:
        if epg_map.get(cid):
            return epg_map.get(cid), cid

    keys = []
    for name in (channel.get("tvgname"), channel.get("name")):
        key = _epg_name_key(name)
        if key:
            keys.append(key)

    for key in keys:
        item = epg_map.get("__name__:" + key)
        if item:
            return item, "__name__:" + key

    # EPG-IDs wie DasErste.de / ZDF.de ebenfalls gegen den M3U-Namen testen.
    for eid, item in epg_map.items():
        if not item or eid.startswith("__name__:"):
            continue
        base = eid.rsplit(".", 1)[0] if "." in eid else eid
        if _epg_name_key(base) in keys:
            return item, eid
    return None, ""


def _build_epg_bundle_m3u_single(source, m3u_text="", force=False):
    """
    XMLTV-EPG-Parser fuer M3U-Quellen (Germany 1-3).
    JSON-Quellen (Pluto, Samsung, Plex) nutzen parse_epg_from_programs() stattdessen.
    """
    import xml.etree.ElementTree as ET

    source_id = (source.get("id") or "unknown").strip() or "unknown"
    build_started = time.time()

    epg_url = (source.get("epg") or "").strip()
    if not epg_url:
        _, epg_in_m3u = parse_m3u(m3u_text, source.get("name", ""))
        epg_url = (epg_in_m3u or "").strip()

    if not epg_url:
        log(f"EPG URL missing [{source_id}]", xbmc.LOGWARNING)
        return {}, {}

    meta_p, xml_p, idx_p = _epg_paths(epg_url)

    # Verarbeiteter EPG-Cache: moderne Indizes enthalten einen kompakten
    # Programmplan. Daraus werden Jetzt/Naechste in wenigen Millisekunden neu
    # berechnet, ohne die grosse XMLTV-Datei erneut zu parsen. Alte Indizes
    # bleiben aus Kompatibilitaetsgruenden 15 Minuten nutzbar.
    if (not force) and xbmcvfs.exists(idx_p):
        cached = read_json(idx_p, {})
        cache_age = time.time() - cached.get("ts", 0) if cached.get("ts") else 10**18
        schedule_map = cached.get("schedule_map") or {}
        if schedule_map and cache_age <= get_epg_cache_seconds(source_id):
            epg_map = _epg_map_from_schedule(
                schedule_map, cached.get("alias_map") or {}
            )
            icon_map = cached.get("icon_map") or {}
            if epg_map:
                log(f"[EPG:{source_id}] PROCESSED CACHE HIT items={len(epg_map)} ms={int((time.time()-build_started)*1000)}")
                return epg_map, icon_map
        elif cache_age <= 15 * 60:
            epg_map  = cached.get("epg_map") or {}
            icon_map = cached.get("icon_map") or {}
            if epg_map:
                log(f"EPG INDEX CACHE HIT [{source_id}] items={len(epg_map)}")
                return epg_map, icon_map

    # XML laden / cachen. Abgelaufene XML-Daten werden wirklich erneuert;
    # bei einem Netzfehler bleibt die alte Datei als Fallback erhalten.
    have_xml = xbmcvfs.exists(meta_p) and xbmcvfs.exists(xml_p)
    meta = read_json(meta_p, {}) if have_xml else {}
    xml_fresh = bool(
        (not force) and have_xml and meta.get("ts")
        and (time.time() - meta["ts"]) <= get_epg_cache_seconds(source_id)
    )
    if not xml_fresh:
        old_xml_p = xml_p if xbmcvfs.exists(xml_p) else ""
        fetched = False
        for attempt in (1, 2):
            try:
                r = requests.get(epg_url, headers=HEADERS, timeout=60)
                r.raise_for_status()
                data = r.content
                if data[:2] == b"\x1f\x8b":
                    xml_bytes = gzip.decompress(data)
                elif data[:6] == b"\xfd7zXZ\x00":
                    # Rytec AT/CH wird als XZ ausgeliefert. lzma ist Bestandteil
                    # von Python 3/Kodi 19-21; andere EPG-Formate bleiben unveraendert.
                    import lzma
                    xml_bytes = lzma.decompress(data)
                else:
                    xml_bytes = data
                _, xml_target_p, _ = _epg_paths(epg_url)
                local_xml = xbmcvfs.translatePath(xml_target_p)
                with open(local_xml, "wb") as fh:
                    fh.write(xml_bytes)
                xml_p = xml_target_p
                write_json(meta_p, {"ts": time.time(), "url": epg_url, "bytes": len(xml_bytes)})
                log(f"[EPG:{source_id}] FETCH OK bytes={len(xml_bytes)} ms={int((time.time()-build_started)*1000)}")
                fetched = True
                break
            except Exception as e:
                log(f"EPG load attempt {attempt} failed [{source_id}]: {e}", xbmc.LOGERROR)
                time.sleep(0.8)
        if not fetched and old_xml_p:
            xml_p = old_xml_p
            log(f"EPG STALE CACHE FALLBACK [{source_id}]", xbmc.LOGWARNING)

    if not xml_p or not xbmcvfs.exists(xml_p):
        log(f"EPG xml missing [{source_id}]", xbmc.LOGERROR)
        return {}, {}

    now_epoch = int(datetime.now(timezone.utc).timestamp())
    icon_map = {}
    channel_names = {}
    now_map  = {}
    next_map = {}
    schedule_map = {}
    schedule_from = now_epoch - 2 * 3600
    schedule_until = now_epoch + 24 * 3600

    local = xbmcvfs.translatePath(xml_p)
    try:
        with open(local, "rb") as fh:
            for _, el in ET.iterparse(fh, events=("end",)):
                if el.tag == "channel":
                    cid = el.attrib.get("id", "")
                    if cid:
                        names = []
                        for dn in el.findall("display-name"):
                            if dn is not None and dn.text:
                                n = dn.text.strip()
                                if n:
                                    names.append(n)
                        if names:
                            channel_names[cid] = names
                        ic = el.find("icon")
                        if ic is not None:
                            src = (ic.attrib.get("src") or "").strip()
                            if src:
                                icon_map[cid] = src
                    el.clear()
                elif el.tag == "programme":
                    cid       = el.attrib.get("channel", "")
                    raw_start = el.attrib.get("start", "")
                    raw_stop  = el.attrib.get("stop", "")
                    start_e   = _xmltv_to_epoch(raw_start)
                    stop_e    = _xmltv_to_epoch(raw_stop)
                    title_el  = el.find("title")
                    title     = title_el.text.strip() if title_el is not None and title_el.text else ""
                    desc_el   = el.find("desc")
                    desc      = desc_el.text.strip() if desc_el is not None and desc_el.text else ""
                    if cid and start_e is not None:
                        item = {"start": start_e, "stop": stop_e, "title": title, "desc": desc}
                        effective_stop = stop_e if stop_e is not None else (start_e + 21600)
                        if effective_stop >= schedule_from and start_e <= schedule_until:
                            schedule_map.setdefault(cid, []).append(item)
                        if start_e <= now_epoch and (stop_e is None or now_epoch < stop_e):
                            cur = now_map.get(cid)
                            stop_cmp = stop_e if stop_e else (start_e + 21600)
                            if not cur or stop_cmp < cur.get("stop", 10**18):
                                now_map[cid] = item
                        elif start_e > now_epoch and cid not in next_map:
                            next_map[cid] = item
                    el.clear()
    except Exception as e:
        log(f"EPG parse error [{source_id}]: {e}", xbmc.LOGERROR)
        return {}, icon_map

    epg_map = {k: {"now": now_map.get(k), "next": next_map.get(k)}
               for k in set(list(now_map) + list(next_map))}
    real_epg_count = len(epg_map)

    # IPTV-EPG und M3U verwenden nicht immer dieselbe ID. Deshalb zusaetzlich
    # eindeutige XMLTV-display-name-Aliase bereitstellen.
    name_candidates = {}
    for cid, names in channel_names.items():
        item = epg_map.get(cid)
        if not item:
            continue
        for name in names:
            key = _epg_name_key(name)
            if key:
                name_candidates.setdefault(key, []).append(item)
    alias_map = {}
    for key, items in name_candidates.items():
        if len(items) == 1:
            epg_map["__name__:" + key] = items[0]
            # Den eindeutigen Kanal fuer spaetere Jetzt/Naechste-Neuberechnung merken.
            for cid, candidate in epg_map.items():
                if not cid.startswith("__name__:") and candidate is items[0]:
                    alias_map[key] = cid
                    break

    # Ein kurzfristig leerer Provider-Snapshot darf einen funktionierenden
    # Index nicht zerstoeren (im Log von v1.17.2 trat channels=0 auf).
    if real_epg_count == 0 and xbmcvfs.exists(idx_p):
        old_idx = read_json(idx_p, {})
        old_map = old_idx.get("epg_map") or {}
        if old_map:
            log(f"EPG EMPTY REBUILD - keep previous index [{source_id}]", xbmc.LOGWARNING)
            return old_map, (old_idx.get("icon_map") or icon_map)

    try:
        write_json_compact(idx_p, {"ts": time.time(), "epg_map": epg_map, "icon_map": icon_map, "schedule_map": schedule_map, "alias_map": alias_map})
    except Exception:
        pass

    log(f"[EPG:{source_id}] BUILT channels={real_epg_count} aliases={len(epg_map)-real_epg_count} icons={len(icon_map)} ms={int((time.time()-build_started)*1000)}")
    if DEBUG_EPG_NOTIFY:
        notify(f"{source_id}: EPG {len(epg_map)}", err=False, ms=1800)
    return epg_map, icon_map


def _epg_map_from_schedule(schedule_map, alias_map=None):
    """Erzeugt aktuelles Jetzt/Naechste aus dem kompakten verarbeiteten Cache."""
    now_epoch = int(datetime.now(timezone.utc).timestamp())
    epg_map = {}
    for cid, programmes in (schedule_map or {}).items():
        current = None
        nxt = None
        for item in programmes or []:
            start = item.get("start")
            stop = item.get("stop")
            if start is None:
                continue
            if start <= now_epoch and (stop is None or now_epoch < stop):
                current = item
            elif start > now_epoch:
                nxt = item
                break
        if current or nxt:
            epg_map[cid] = {"now": current, "next": nxt}
    for key, cid in (alias_map or {}).items():
        if cid in epg_map:
            epg_map["__name__:" + key] = epg_map[cid]
    return epg_map


def _xmltv_to_epoch(s):
    """Kompakter XMLTV-Zeitparser: '20260327200000 +0100' -> Unix-Timestamp."""
    if not s:
        return None
    s = s.strip()
    try:
        m = re.match(r"(\d{14})\s*([+-]\d{4})?", s)
        if not m:
            return None
        naive = datetime.strptime(m.group(1), "%Y%m%d%H%M%S")
        tz_str = m.group(2) or "+0000"
        sign = 1 if tz_str[0] == "+" else -1
        tz_off = timedelta(hours=int(tz_str[1:3]), minutes=int(tz_str[3:5])) * sign
        aware = naive.replace(tzinfo=timezone(tz_off))
        return int(aware.astimezone(timezone.utc).timestamp())
    except Exception:
        return None


def build_epg_bundle_m3u(source, m3u_text="", force=False):
    """Primaeren XMLTV-Feed nutzen; Fallbacks nur bei echtem Primaerausfall."""
    primary_map, primary_icons = _build_epg_bundle_m3u_single(source, m3u_text, force=force)
    if primary_map:
        if source.get("epg_fallbacks"):
            log("EPG FALLBACK SKIP [%s] primary_ok=%d" % (source.get("id", "?"), len(primary_map)))
        return primary_map, primary_icons

    fallbacks = source.get("epg_fallbacks") or []
    if isinstance(fallbacks, str):
        fallbacks = [fallbacks]
    for idx, fallback_url in enumerate(fallbacks, start=1):
        fallback_url = (fallback_url or "").strip()
        if not fallback_url:
            continue
        fb_source = dict(source)
        fb_source["id"] = "%s_fb%d" % (source.get("id", "m3u"), idx)
        fb_source["epg"] = fallback_url
        fb_source.pop("epg_fallbacks", None)
        try:
            fb_map, fb_icons = _build_epg_bundle_m3u_single(fb_source, m3u_text, force=force)
            if fb_map:
                log("EPG FALLBACK USED [%s] items=%d" % (source.get("id", "?"), len(fb_map)))
                return fb_map, fb_icons
        except Exception as exc:
            log("EPG FALLBACK failed [%s] %s" % (source.get("id", "?"), exc), xbmc.LOGWARNING)
    return {}, {}

