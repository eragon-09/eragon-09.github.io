# -*- coding: utf-8 -*-
import sys
import os
import re
import json
import gzip
import hashlib
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from calendar import timegm as TGM
from urllib.parse import urlencode, parse_qsl, quote_plus, unquote_plus

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests
import xml.etree.ElementTree as ET
import xbmcaddon

# ==========================================================
# Titan Smart TV Plus (Kodi 19-21) - default.py
#
# Diagnose-Logging für EPG:
# - "EPG OK [...] bytes=..."
# - "EPG INDEX BUILT [...] epg_map=... names=... icons=... programmes=... start_ok=... now=... next=..."
# - Wenn start_ok=0: loggt Beispiele der "start" Strings
#
# WICHTIGER Fix (Order-Bug):
# - XML wird über einen expliziten File-Handle geparst (with open(...)),
#   damit nach der ersten Quelle keine offenen Handles das weitere Parsing blockieren.
# ==========================================================

ADDON_ID = "plugin.video.titansmarttvplus"
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else 1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""

ADDON_PATH = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/")
MEDIA_DIR = os.path.join(ADDON_PATH, "resources", "media")

PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/")
FAV_FILE = PROFILE + "favorites.json"
LOGO_DIR = PROFILE + "logos/"
EPG_DIR = PROFILE + "epg/"
PLEX_AUTH_FILE = PROFILE + "plex_auth.json"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
HEADERS = {"User-Agent": UA}

COLOR_GROUP = None  # Gruppen im Kodi-Standardweiß
COLOR_CHANNEL = None  # Sendernamen im Kodi-Standardweiß
COLOR_FAV = "gold"
COLOR_ACTION = "lightgray"

ALL_GROUP = "__ALL__"

WIN = xbmcgui.Window(10000)
RETURN_FROM_PLAY_FLAG = "TITAN_RETURN_FROM_PLAY"

# Pluto: Geraete-UUID einmalig aus MAC-Adresse ableiten (identisch zum SlyGuy-Addon)
_PLUTO_UUID_NS = "122e1611-0232-4336-bf43-e054c8ecd0d5"
PLUTO_DEVICE_ID = str(uuid.uuid3(uuid.UUID(_PLUTO_UUID_NS), str(uuid.getnode())))

UA_PLUTO = "otg/1.5.1 (AppleTv Apple TV 4; tvOS16.0; appletv.client) libcurl/7.58.0 OpenSSL/1.0.2o zlib/1.2.11 clib/1.8.56"

# ----------------------------------------------------------
# Region / Anbieterland
# ----------------------------------------------------------
REGION_MAP = {0: "de", 1: "at", 2: "ch"}
REGION_LABELS = {"de": "DE", "at": "AT", "ch": "CH"}
REGION_DISPLAY_NAMES = {"de": "Deutschland (DE)", "at": "Österreich (AT)", "ch": "Schweiz (CH)"}

def get_provider_region():
    """Vom Benutzer gewaehltes Anbieterland. Aendert niemals IP/Standort.

    Kodi-Versionen/Settings-Dialoge koennen bei Legacy-Selects entweder den
    Index oder den sichtbaren Wert zurueckgeben. Beides wird deshalb sauber
    ausgewertet, damit DE/AT/CH im Hauptmenue immer der Auswahl entspricht.
    """
    raw = (ADDON.getSetting("provider_region") or "0").strip()
    try:
        idx = int(raw)
        if idx in REGION_MAP:
            return REGION_MAP[idx]
    except Exception:
        pass

    value = raw.casefold()
    if value in ("de", "deutschland", "deutschland (de)") or "(de)" in value:
        return "de"
    if value in ("at", "österreich", "oesterreich", "österreich (at)", "oesterreich (at)") or "(at)" in value:
        return "at"
    if value in ("ch", "schweiz", "schweiz (ch)") or "(ch)" in value:
        return "ch"

    log(f"Unbekannter provider_region-Wert '{raw}' - verwende DE als sicheren Standard", xbmc.LOGWARNING)
    return "de"

# ----------------------------------------------------------
# Rakuten TV Live / VoD - regionale Provider-Parameter
# Es wird ausschliesslich die vom Benutzer gewaehlte Anbieterregion an
# Rakuten uebergeben. IP/Standort und Geo-Pruefungen werden nicht veraendert.
# ----------------------------------------------------------
RKTV_API       = "https://gizmo.rakuten.tv/v3"
RKTV_BASE_URL  = "https://www.rakuten.tv/"
RKTV_REGION_CONFIG = {
    # DE bleibt auf der in Titan bereits bewaehrten Konfiguration.
    "de": {"market": "de", "classification": "30",  "locale": "de",    "accept_language": "de-DE,de;q=0.9,en;q=0.8"},
    # Rakuten-Marktparameter fuer Oesterreich und Schweiz.
    "at": {"market": "at", "classification": "300", "locale": "de-AT", "accept_language": "de-AT,de;q=0.9,en;q=0.8"},
    "ch": {"market": "ch", "classification": "319", "locale": "de-CH", "accept_language": "de-CH,de;q=0.9,en;q=0.8"},
}
# Die regionsabhaengige Rakuten-Konfiguration wird erst nach
# Initialisierung von ADDON aufgebaut (siehe unten).



def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[Titan Smart TV Plus] {msg}", level)


def notify(msg, err=False, ms=3500):
    xbmcgui.Dialog().notification(
        "Titan Smart TV Plus",
        msg,
        xbmcgui.NOTIFICATION_ERROR if err else xbmcgui.NOTIFICATION_INFO,
        ms,
    )


DEFAULT_SETTINGS = {
    "provider_region":       "0",    # 0=DE, 1=AT, 2=CH
    "region_setup_done":     "false",
    "channel_sort":          "0",    # 0=M3U-Reihenfolge, 1=Alphabetisch
    "show_chnos":            "true",
    "show_epg_in_label":     "true",
    "enable_epg_plex":       "true",
    "enable_epg_pluto":      "true",
    "enable_epg_samsung":    "true",
    "enable_epg_rakuten":    "true",
    "enable_epg_free_de":    "true",
    "enable_epg_free_de2":   "true",
    "show_favorites":        "true",
    "cache_pluto_interval":       "4",  # 6h
    "cache_samsung_interval":     "4",  # 6h
    "cache_rktv_interval":        "4",  # 6h
    "cache_rktv_epg_interval":    "2",  # 1h
    "cache_plex_epg_interval":    "4",  # 6h
    "cache_free_de_interval":     "5",  # 12h
    "cache_free_de_epg_interval": "5",  # 12h
    "cache_free_de2_interval":    "5",  # 12h
    "cache_free_de2_epg_interval":"5",  # 12h
    "cache_pluto_vod_interval":   "5",  # 12h
    "debug_epg_notify":      "false",
    "alt_user_agent":        "true",
    "cache_logos":           "true",
    "plex_german_only":      "true",
    "plex_vod_german_only":  "true",
    "germany_m3u_url":       "https://iptv-org.github.io/iptv/languages/deu.m3u",
    "germany_epg_url":       "https://iptv-epg.org/files/epg-de.xml",
    "germany2_m3u_url":      "https://github.com/PrinzMichiDE/iptv-kodi-german/raw/refs/heads/master/ip-tv-german.m3u",
    "germany2_epg_url":      "https://xmltv.info/de/epg.xml",
}


class SafeAddon:
    def __init__(self):
        self._addon = None
        try:
            self._addon = xbmcaddon.Addon()
        except Exception as e:
            log(f"xbmcaddon.Addon() failed: {e}", xbmc.LOGERROR)
            self._addon = None

    def getSetting(self, key):
        try:
            if self._addon:
                return self._addon.getSetting(key)
        except Exception as e:
            log(f"getSetting('{key}') failed: {e}", xbmc.LOGWARNING)
        return DEFAULT_SETTINGS.get(key, "")

    def setSetting(self, key, value):
        try:
            if self._addon:
                self._addon.setSetting(key, str(value))
                return True
        except Exception as e:
            log(f"setSetting('{key}') failed: {e}", xbmc.LOGWARNING)
        return False


ADDON = SafeAddon()


# Rakuten-Region erst jetzt aus den Kodi-Settings lesen.
# Dadurch ist ADDON garantiert initialisiert, bevor get_provider_region() darauf zugreift.
_RKTV_REGION = get_provider_region()
_RKTV_CFG     = RKTV_REGION_CONFIG.get(_RKTV_REGION, RKTV_REGION_CONFIG["de"])
RKTV_MARKET   = _RKTV_CFG["market"]
RKTV_CLASSIFY = _RKTV_CFG["classification"]
RKTV_LOCALE   = _RKTV_CFG["locale"]
RKTV_AGENT     = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
RKTV_HEAD = {
    "User-Agent": RKTV_AGENT,
    "Origin": RKTV_BASE_URL[:-1],
    "Referer": RKTV_BASE_URL,
    "Accept-Language": _RKTV_CFG["accept_language"],
    "Accept-Encoding": "gzip",
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/json; charset=utf-8",
}
RKTV_PARAMS_WEB = {
    "classification_id": RKTV_CLASSIFY,
    "device_identifier": "web",
    "device_stream_audio_quality": "2.0",
    "device_stream_hdr_type": "NONE",
    "device_stream_video_quality": "FHD",
    "locale": RKTV_LOCALE,
    "market_code": RKTV_MARKET,
}
RKTV_PARAMS_PACK = {**RKTV_PARAMS_WEB, **{"disable_dash_legacy_packages": "false"}}
RKTV_PARAMS_USER = {**RKTV_PARAMS_WEB, **{"live_channel_support": "false", "user_status": "visitor"}}
RKTV_KODI_GE20  = int(xbmc.getInfoLabel("System.BuildVersion")[0:2]) >= 20
RKTV_KODI_LE20  = int(xbmc.getInfoLabel("System.BuildVersion")[0:2]) <= 20

_RKTV_CACHE_SUFFIX  = RKTV_MARKET.upper()
RKTV_CHANNEL_FILE   = PROFILE + f"rktv_channels_{_RKTV_CACHE_SUFFIX}.gz"
RKTV_LIVE_DATA_FILE = PROFILE + f"rktv_live_data_{_RKTV_CACHE_SUFFIX}.gz"
RKTV_EPG_FILE       = PROFILE + f"rktv_epg_{_RKTV_CACHE_SUFFIX}.gz"
RKTV_VOD_CAT_FILE   = PROFILE + f"rktv_vod_cats_{_RKTV_CACHE_SUFFIX}.gz"
RKTV_SETTINGS_FILE  = PROFILE + "rktv_settings.json"
EPG_CACHE_SECONDS = 6 * 60 * 60



def clear_region_runtime_cache():
    """Entfernt nur regionsabhaengige JSON-Provider-Caches; Konten/Favoriten bleiben erhalten."""
    try:
        _dirs, files = xbmcvfs.listdir(PROFILE)
        for name in files:
            if name.startswith("json_") and name.endswith(".json"):
                xbmcvfs.delete(PROFILE + name)
    except Exception as e:
        log(f"Region cache clear failed: {e}", xbmc.LOGWARNING)


def ensure_region_setup():
    """Einmalige, bewusste Regionswahl. Abbruch laesst den Assistenten beim naechsten Start erneut erscheinen."""
    if ADDON.getSetting("region_setup_done") == "true":
        return True

    dlg = xbmcgui.Dialog()
    dlg.ok(
        "Willkommen bei Titan Smart TV Plus",
        "Bitte wähle jetzt deine Anbieterregion.\n\n"
        "Die Auswahl bestimmt, welche vom jeweiligen Anbieter unterstützten regionalen Senderlisten und VoD-Angebote verwendet werden. "
        "IP-Adresse, Standort und Geo-Prüfungen der Anbieter werden nicht verändert."
    )
    choice = dlg.select(
        "Region / Anbieterland",
        ["Deutschland (DE)", "Österreich (AT)", "Schweiz (CH)"],
        preselect=-1
    )
    if choice not in REGION_MAP:
        notify("Bitte beim nächsten Start eine Region auswählen.", False, 4500)
        return False

    if not ADDON.setSetting("provider_region", str(choice)):
        notify("Region konnte nicht gespeichert werden.", True, 5000)
        return False
    ADDON.setSetting("region_setup_done", "true")
    clear_region_runtime_cache()
    notify(f"Anbieterregion: {REGION_LABELS[REGION_MAP[choice]]}", False, 3000)
    return True


def epg_enabled(source_id):
    """EPG pro Live-TV-Quelle separat schaltbar; Standard bleibt aktiviert."""
    setting_map = {
        "plex": "enable_epg_plex",
        "pluto": "enable_epg_pluto",
        "samsung": "enable_epg_samsung",
        "rakuten_live": "enable_epg_rakuten",
        "free_de": "enable_epg_free_de",
        "free_at": "enable_epg_free_de",
        "free_ch": "enable_epg_free_de",
        "free_de2": "enable_epg_free_de2",
        "free_at2": "enable_epg_free_de2",
        "free_ch2": "enable_epg_free_de2",
    }
    key = setting_map.get(source_id)
    return True if not key else ADDON.getSetting(key) != "false"

# Aus Settings abgeleitete Laufzeit-Flags (nach ADDON-Init)
DEBUG_EPG_NOTIFY = ADDON.getSetting("debug_epg_notify") == "true"
CACHE_LOGOS      = ADDON.getSetting("cache_logos") != "false"
ALT_UA_PLUTO     = ADDON.getSetting("alt_user_agent") != "false"

def _load_lib_code(relative_path):
    """Laedt ausgelagerte Addon-Logik in den bewaehrten gemeinsamen Kontext."""
    path = os.path.join(ADDON_PATH, "resources", "lib", relative_path)
    with open(path, "r", encoding="utf-8") as fh:
        code = compile(fh.read(), path, "exec")
    exec(code, globals())


def _load_provider_code(filename):
    _load_lib_code(os.path.join("providers", filename))


PLEX_DE_CHANNELS_FILE = os.path.join(ADDON_PATH, "resources", "plex_de_channels.json")



# Provider ausgelagert: plex.py
_load_provider_code("plex.py")

def build_sources():
    """Quellen fuer das gewaehlte Anbieterland; ohne Standort-Vortaeuschung."""
    region = get_provider_region()
    rlabel = REGION_LABELS.get(region, region.upper())
    sources = [
        {
            "id": "plex",
            "name": "Plex Live TV",
            "type": "plex_de_static",
        },
        {
            "id": "pluto",
            "name": f"Pluto TV ({rlabel})",
            "type": "pluto_native",
            "region": region,
        },
        {
            "id": "samsung",
            "name": f"Samsung TV Plus ({rlabel})",
            "type": "json",
            "url": "https://i.mjh.nz/SamsungTVPlus/.channels.json.gz",
            "region": region,
            "playback_url": "https://jmp2.uk/{slug}",
        },
    ]
    # Freies TV ist KEIN GEO-Provider. Die ausgewaehlte Region bestimmt nur
    # automatisch, welche oeffentliche iptv-org-Laenderplaylist angezeigt wird.
    # Standort/IP werden nicht veraendert; einzelne Streams koennen weiterhin
    # ihre eigenen Verfuegbarkeitsregeln anwenden.
    free_id = f"free_{region}"
    free_country_url = f"https://iptv-org.github.io/iptv/countries/{region}.m3u"

    # Regionale Free-TV-EPG-Quelle automatisch an die beim Start/Settings
    # gewaehlte Region koppeln. DE bleibt unveraendert; fuer AT/CH werden die
    # oeffentlichen Rytec-Basislisten verwendet. Die alternativen Hosts dienen
    # nur als Ausfall-Fallback derselben EPG-Daten und veraendern keine Region.
    free_epg = ""
    free_epg_fallbacks = []
    if region == "at":
        free_epg = "http://www.xmltvepg.nl/rytecAT_Basic.xz"
        free_epg_fallbacks = [
            "http://rytecepg.wanwizard.eu/rytecAT_Basic.xz",
            "http://epg.vuplus-community.net/rytecAT_Basic.xz",
        ]
    elif region == "ch":
        free_epg = "http://www.xmltvepg.nl/rytecCH_Basic.xz"
        free_epg_fallbacks = [
            "http://rytecepg.wanwizard.eu/rytecCH_Basic.xz",
            "http://epg.vuplus-community.net/rytecCH_Basic.xz",
        ]

    sources.append({
        "id": free_id,
        "name": f"Freies TV ({rlabel})",
        "type": "m3u",
        "url": free_country_url,
        "epg": free_epg,
        "epg_fallbacks": free_epg_fallbacks,
        "curated": True,
    })
    # Zweiter Free-TV-Punkt bleibt wie in den frueheren Builds erhalten.
    # Er zeigt eine deutschsprachige oeffentliche Alternativliste; auch hier
    # werden weder Standort noch Provider-Geo-Pruefungen manipuliert.
    sources.append({
        "id": f"free_{region}2",
        "name": f"Freies TV 2 ({rlabel})",
        "type": "m3u",
        "url": "https://iptv-org.github.io/iptv/languages/deu.m3u",
        "epg": free_epg,
        "epg_fallbacks": free_epg_fallbacks,
        "curated": True,
    })
    # Rakuten wird mit den zur ausgewaehlten Region passenden Marktparametern
    # geladen. Die Provider-Seite entscheidet weiterhin ueber Verfuegbarkeit.
    sources.append({"id": "rakuten_live", "name": f"Rakuten TV Live ({rlabel})", "type": "rktv_live"})
    return sources


SOURCES = build_sources()


def get_channel_sort_mode():
    try:
        return int(ADDON.getSetting("channel_sort") or "0")
    except Exception:
        return 0


# Mapping: select-Index -> Sekunden


# Gemeinsamer Cache-Code ausgelagert
_load_lib_code("cache.py")


# Provider ausgelagert: pluto.py
_load_provider_code("pluto.py")

def colorize(txt, color):
    if not txt:
        return txt
    if not color:
        return txt
    return f"[COLOR {color}]{txt}[/COLOR]"


# Mapping von source_id auf Icon-Dateiname (ermoeglicht originale Icons)
SOURCE_ICON_MAP = {
    "rakuten_live": "rakuten_live.png",
    "pluto":        "pluto.png",
    "samsung":      "samsung.png",
}

def get_source_icon(source_id: str) -> str:
    if not source_id:
        source_id = "default"
    # Bevorzuge original-Icon falls vorhanden
    fname = SOURCE_ICON_MAP.get(source_id, f"{source_id}.png")
    icon_path = os.path.join(MEDIA_DIR, fname)
    if xbmcvfs.exists(icon_path):
        return icon_path
    # Fallback auf generischen Namen
    fallback = os.path.join(MEDIA_DIR, f"{source_id}.png")
    if xbmcvfs.exists(fallback):
        return fallback
    return os.path.join(MEDIA_DIR, "default.png")


def get_menu_icon(key: str) -> str:
    return get_source_icon(key or "default")


class ProgressDialog:
    def __init__(self, title="Titan Smart TV Plus", enabled=True):
        self.title = title
        self.enabled = bool(enabled)
        self.dlg = None
        self._open = False

    def open(self, message="Bitte warten …"):
        if not self.enabled:
            return
        try:
            self.dlg = xbmcgui.DialogProgress()
            self.dlg.create(self.title, message)
            self._open = True
        except Exception:
            self.dlg = None
            self._open = False

    def update(self, percent, message=None):
        if not self.enabled or not self._open or not self.dlg:
            return
        try:
            if message is None:
                self.dlg.update(int(percent))
            else:
                self.dlg.update(int(percent), message)
        except Exception:
            pass

    def iscanceled(self):
        if not self.enabled:
            return False
        try:
            return bool(self.dlg and self.dlg.iscanceled())
        except Exception:
            return False

    def close(self):
        if not self.enabled:
            return
        if self.dlg:
            try:
                self.dlg.close()
            except Exception:
                pass
        self._open = False


def sha1(s):
    return hashlib.sha1(s.encode("utf-8", "ignore")).hexdigest()


def ensure_dirs():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)
    if not xbmcvfs.exists(LOGO_DIR):
        xbmcvfs.mkdirs(LOGO_DIR)
    if not xbmcvfs.exists(EPG_DIR):
        xbmcvfs.mkdirs(EPG_DIR)


def build_url(q):
    return BASE_URL + "?" + urlencode(q)


def cache_path(prefix, key):
    return PROFILE + f"{prefix}_{sha1(key)}.json"


def read_text(path):
    f = xbmcvfs.File(path)
    try:
        d = f.read()
        return d.decode("utf-8", "replace") if isinstance(d, (bytes, bytearray)) else d
    finally:
        f.close()


def write_text(path, txt):
    f = xbmcvfs.File(path, "w")
    try:
        f.write(txt)
    finally:
        f.close()


def write_bytes(path, bts):
    f = xbmcvfs.File(path, "wb")
    try:
        f.write(bts)
    finally:
        f.close()


def read_json(path, default):
    if not xbmcvfs.exists(path):
        return default
    try:
        return json.loads(read_text(path) or "")
    except Exception:
        return default


def write_json(path, data):
    write_text(path, json.dumps(data, ensure_ascii=False, indent=2))


def write_json_compact(path, data):
    write_text(path, json.dumps(data, ensure_ascii=False, separators=(",", ":")))


def get_source(source_id):
    for s in SOURCES:
        if s.get("id") == source_id:
            return s
    return None


def logo_local_path(url):
    return LOGO_DIR + sha1(url) + ".png"


def get_logo_local(url, force=False):
    if not url or not isinstance(url, str):
        return ""
    url = url.strip()
    if not url:
        return ""
    if not url.startswith("http"):
        return url

    if not CACHE_LOGOS:
        return url

    p = logo_local_path(url)
    if (not force) and xbmcvfs.exists(p):
        return p

    try:
        r = requests.get(url, headers=HEADERS, timeout=20)
        if getattr(r, "status_code", None) in (401, 403):
            log(f"Logo blocked (HTTP {r.status_code}): {url}", xbmc.LOGWARNING)
            return ""
        r.raise_for_status()
        data = r.content
        if data and len(data) > 100:
            write_bytes(p, data)
            return p
    except Exception as e:
        log(f"Logo download failed: {url} -> {e}", xbmc.LOGERROR)
    return ""


def clear_logo_cache():
    try:
        _dirs, files = xbmcvfs.listdir(LOGO_DIR)
        for fn in files:
            try:
                xbmcvfs.delete(LOGO_DIR + fn)
            except Exception:
                pass
        notify("Provider-Logo-Cache geleert.")
    except Exception as e:
        log(f"Logo cache clear error: {e}", xbmc.LOGERROR)
        notify("Provider-Logo-Cache konnte nicht geleert werden.", True, 5000)


# Provider ausgelagert: rakuten.py
_load_provider_code("rakuten.py")


# Provider ausgelagert: pluto_samsung.py
_load_provider_code("pluto_samsung.py")


# Gemeinsame M3U-, EPG- und Favoritenlogik ausgelagert
_load_lib_code("m3u.py")
_load_lib_code("epg.py")
_load_lib_code("favorites.py")


def kodi_has_addon(addon_id):
    """Prüft, ob ein optionales Kodi-Addon installiert/aktiv ist."""
    try:
        return bool(xbmc.getCondVisibility(f"System.HasAddon({addon_id})"))
    except Exception:
        try:
            xbmcaddon.Addon(addon_id)
            return True
        except Exception:
            return False


def set_video_info(li, title, plot=""):
    # getVideoInfoTag ist auf neueren Kodi-Versionen bevorzugt; setInfo bleibt
    # der kompatible Fallback für Matrix/ältere Python-API-Ausprägungen.
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        if plot:
            tag.setPlot(plot)
    except Exception:
        info = {"title": title}
        if plot:
            info["plot"] = plot
        li.setInfo("video", info)


def set_art(li, logo):
    if not logo:
        return
    li.setArt(
        {"thumb": logo, "icon": logo, "poster": logo, "banner": logo, "landscape": logo, "fanart": logo, "clearlogo": logo}
    )
    li.setProperty("fanart_image", logo)


def add_dir(label, action, icon=None, **kwargs):
    # _icon erlaubt Gruppen-Eintraegen ein eigenes Quellenicon mitzugeben
    _icon = kwargs.pop("_icon", None)
    url = build_url({"action": action, **kwargs})
    li = xbmcgui.ListItem(label)
    effective_icon = _icon or icon
    if effective_icon:
        li.setArt({"icon": effective_icon, "thumb": effective_icon, "fanart": effective_icon})
        li.setProperty("fanart_image", effective_icon)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def view_root():
    """Startansicht. Region steuert nur offiziell/sauber abbildbare Quellen."""
    xbmcplugin.setPluginCategory(HANDLE, "Titan Smart TV Plus")
    region = get_provider_region()
    rlabel = REGION_LABELS.get(region, region.upper())

    if ADDON.getSetting("show_favorites") != "false":
        add_dir(colorize("  Favoriten", COLOR_FAV), "favorites", icon=get_menu_icon("favorites"))

    # Plex bestimmt die tatsaechliche Inhaltsverfuegbarkeit selbst anhand des
    # realen Nutzerstandorts. Das Addon veraendert diesen Standort nicht.
    plex_icon = get_source_icon("plex")
    for label, action in (("Plex Live TV", "source"), ("Plex VoD", "plex_vod_main")):
        li = xbmcgui.ListItem(colorize(f"  {label}", COLOR_GROUP))
        li.setArt({"icon": plex_icon, "thumb": plex_icon, "fanart": plex_icon})
        url = build_url({"action": action, **({"id": "plex"} if action == "source" else {})})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    pluto_icon = get_source_icon("pluto")
    li = xbmcgui.ListItem(colorize(f"  Pluto TV ({rlabel})", COLOR_GROUP))
    li.setArt({"icon": pluto_icon, "thumb": pluto_icon, "fanart": pluto_icon})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": "source", "id": "pluto"}), li, isFolder=True)
    li = xbmcgui.ListItem(colorize("  Pluto VoD (Region durch Pluto)", COLOR_GROUP))
    li.setArt({"icon": pluto_icon, "thumb": pluto_icon, "fanart": pluto_icon})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": "pluto_vod_genres"}), li, isFolder=True)

    samsung_icon = get_source_icon("samsung")
    li = xbmcgui.ListItem(colorize(f"  Samsung TV Plus ({rlabel})", COLOR_GROUP))
    li.setArt({"icon": samsung_icon, "thumb": samsung_icon, "fanart": samsung_icon})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": "source", "id": "samsung"}), li, isFolder=True)

    # Rakuten unterstuetzt DE/AT/CH. Live und VoD verwenden die jeweils
    # ausgewaehlte Rakuten-Marktregion; Geo-Pruefungen bleiben beim Provider.
    rakuten_icon = get_source_icon("rakuten_live")
    for base_label, action in (("Rakuten TV Live", "rktv_categories"), ("Rakuten VoD", "rktv_vod_main")):
        li = xbmcgui.ListItem(colorize(f"  {base_label} ({rlabel})", COLOR_GROUP))
        li.setArt({"icon": rakuten_icon, "thumb": rakuten_icon, "fanart": rakuten_icon})
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": action}), li, isFolder=True)

    # Freies TV liegt ausserhalb der GEO-Providerlogik. Die Region waehlt
    # lediglich automatisch die passende oeffentliche Laender-M3U aus.
    free_id = f"free_{region}"
    free_icon = get_source_icon("free_de")
    li = xbmcgui.ListItem(colorize(f"  Freies TV ({rlabel})", COLOR_GROUP))
    li.setArt({"icon": free_icon, "thumb": free_icon, "fanart": free_icon})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": "source", "id": free_id}), li, isFolder=True)

    li = xbmcgui.ListItem(colorize(f"  Freies TV 2 ({rlabel})", COLOR_GROUP))
    li.setArt({"icon": free_icon, "thumb": free_icon, "fanart": free_icon})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": "source", "id": f"free_{region}2"}), li, isFolder=True)

    if plex_is_logged_in():
        add_dir(colorize("  Plex-Konto trennen", COLOR_ACTION), "plex_logout", icon=get_menu_icon("plex"))
    else:
        add_dir(colorize("  Bei Plex anmelden", COLOR_ACTION), "plex_login", icon=get_menu_icon("plex"))
    add_dir(colorize("  Provider-Logo-Cache leeren", COLOR_ACTION), "logos_clear", icon=get_menu_icon("logos_clear"))
    add_dir(colorize("  EPG neu laden", COLOR_ACTION), "epg_reload_pick_source", icon=get_menu_icon("epg_reload_pick_source"))
    add_dir(colorize("  M3U Cache leeren", COLOR_ACTION), "reload_pick_source", icon=get_menu_icon("reload_pick_source"))
    xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)

def show_region_unavailable_dialog():
    """Verstaendlicher Hinweis bei regional nicht angebotenen Inhalten."""
    region = get_provider_region()
    region_name = REGION_DISPLAY_NAMES.get(region, region.upper())
    xbmcgui.Dialog().ok(
        "Titan Smart TV Plus – Inhalt nicht verfügbar",
        f"Die gewünschten Inhalte sind für die ausgewählte Region {region_name} derzeit nicht verfügbar."
    )


def view_region_info():
    show_region_unavailable_dialog()


def list_groups(chans):
    groups = {}
    for c in chans:
        g = (c.get("group") or "Sonstige").strip() or "Sonstige"
        groups[g] = groups.get(g, 0) + 1
    return sorted(groups.items(), key=lambda x: x[0].lower())


def _source_channel_cache_ready(src):
    """True, wenn die Senderliste ohne Netzabruf verfuegbar ist."""
    if not src:
        return False
    stype = src.get("type")
    if stype == "plex_de_static":
        return True
    if stype == "pluto_native":
        return pluto_live_cache_ready()
    if stype == "json":
        src_url = src.get("url", "")
        region = (src.get("region") or "de").lower()
        sid = src.get("id", "")
        ttl = get_pluto_cache_seconds() if sid == "pluto" else (get_samsung_cache_seconds() if sid == "samsung" else get_m3u_cache_seconds(sid))
        cp = cache_path("json", src_url + region)
        cached = read_json(cp, {}) if xbmcvfs.exists(cp) else {}
        return bool(cached.get("channels") and cached.get("ts") and (time.time() - cached["ts"]) <= ttl)
    if stype == "m3u":
        url = (src.get("url") or "").strip()
        if not url:
            return False
        cp = cache_path("m3u", url)
        cached = read_json(cp, {}) if xbmcvfs.exists(cp) else {}
        return bool(cached.get("text") and cached.get("ts") and (time.time() - cached["ts"]) <= get_m3u_cache_seconds(src.get("id", "free_de")))
    return False


def _source_epg_cache_ready(src):
    """True, wenn EPG ohne Netzabruf nutzbar ist. JSON/Plex sind bereits lokal."""
    if not src:
        return False
    if not epg_enabled(src.get("id", "")):
        return True
    stype = src.get("type")
    if stype in ("json", "plex_de_static", "pluto_native"):
        return True
    if stype != "m3u":
        return True
    epg_url = (src.get("epg") or "").strip()
    if not epg_url:
        return True
    meta_p, xml_p, idx_p = _epg_paths(epg_url)
    # Ein frischer Index ist optimal; eine frische XML-Datei reicht ebenfalls,
    # weil dann nur lokal neu geparst werden muss.
    if xbmcvfs.exists(idx_p):
        idx = read_json(idx_p, {})
        if idx.get("ts"):
            age = time.time() - idx["ts"]
            if idx.get("schedule_map") and age <= get_epg_cache_seconds(src.get("id", "free_de")):
                return True
            if idx.get("epg_map") and age <= 15 * 60:
                return True
    if xbmcvfs.exists(meta_p) and xbmcvfs.exists(xml_p):
        meta = read_json(meta_p, {})
        if meta.get("ts") and (time.time() - meta["ts"]) <= get_epg_cache_seconds(src.get("id", "free_de")):
            return True
    return False


def view_source(source_id):
    src = get_source(source_id)
    if not src:
        notify("Quelle nicht gefunden", True, 4000)
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
        return

    cache_ready = _source_channel_cache_ready(src)
    p = ProgressDialog(enabled=not cache_ready)
    p.open("Lade Sender …")
    try:
        p.update(10, "Lade Senderliste …")
        chans, _ = load_channels(src, force=False)
        if p.iscanceled():
            xbmcplugin.endOfDirectory(HANDLE, False, cacheToDisc=False)
            return

        if not chans:
            notify("Keine Sender gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(60, "Baue Gruppenliste …")
        src_icon = get_source_icon(source_id)
        add_dir(colorize("Alle Sender", COLOR_GROUP), "group", id=source_id, group=ALL_GROUP, _icon=src_icon)

        groups = list_groups(chans)
        total = max(len(groups), 1)
        for i, (g, count) in enumerate(groups, start=1):
            if p.iscanceled():
                xbmcplugin.endOfDirectory(HANDLE, False, cacheToDisc=False)
                return
            pct = 60 + int(35 * (i / total))
            p.update(pct, "Baue Gruppenliste …")
            add_dir(colorize(f"{g} ({count})", COLOR_GROUP), "group", id=source_id, group=quote_plus(g), _icon=src_icon)

        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_group(source_id, group):
    src = get_source(source_id)
    if not src:
        notify("Quelle nicht gefunden", True, 4000)
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
        return

    from_playback = (WIN.getProperty(RETURN_FROM_PLAY_FLAG) == "1")
    if from_playback:
        WIN.clearProperty(RETURN_FROM_PLAY_FLAG)

    # Display-Settings
    source_epg_enabled = epg_enabled(source_id)
    show_epg   = source_epg_enabled and ADDON.getSetting("show_epg_in_label") != "false"
    show_chnos = ADDON.getSetting("show_chnos") != "false"
    is_json    = src.get("type") in ("json", "plex_de_static", "pluto_native")

    cache_ready = _source_channel_cache_ready(src) and _source_epg_cache_ready(src)
    if cache_ready:
        log(f"[{source_id}] Senderansicht aus Cache - kein Lade-Dialog")
    p = ProgressDialog(enabled=(not from_playback and not cache_ready))
    p.open("Lade Sender …")

    try:
        p.update(5, "Lade Senderliste …")
        chans, m3u_text = load_channels(src, force=False)
        if p.iscanceled():
            xbmcplugin.endOfDirectory(HANDLE, False, cacheToDisc=False)
            return

        if not chans:
            notify("Keine Sender gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        if group == ALL_GROUP:
            filtered = chans
        else:
            grp = unquote_plus(group)
            filtered = [c for c in chans if (c.get("group") or "").strip() == grp]

        # EPG laden: JSON-Quellen haben EPG bereits im Channel-Dict,
        # M3U-Quellen brauchen den XMLTV-Parser
        epg_map  = {}
        icon_map = {}
        if not is_json and source_epg_enabled:
            p.update(40, "Lade EPG …")
            # Beim Ruecksprung aus der Wiedergabe darf die Senderansicht nicht
            # auf Netzwerk-EPG warten. Fuer Freies TV verwenden wir dann nur
            # bereits vorhandenen EPG-Cache; fehlt er, wird die Liste sofort
            # ohne EPG aufgebaut.
            if from_playback and source_id.startswith("free_") and not _source_epg_cache_ready(src):
                log(f"[{source_id}] Rueckkehr aus Wiedergabe: EPG-Netzabruf uebersprungen")
                epg_map, icon_map = {}, {}
            else:
                epg_map, icon_map = build_epg_bundle_m3u(src, m3u_text, force=False)
            if not epg_map:
                log(f"{src.get('id','?')}: EPG leer (siehe Log)", xbmc.LOGWARNING)

        p.update(55, "Sortiere Sender …")
        if get_channel_sort_mode() == 1:
            filtered.sort(key=lambda c: (c.get("name") or "").lower())

        favs  = load_favs()
        total = max(len(filtered), 1)

        epg_match_count = 0
        for idx, c in enumerate(filtered, start=1):
            if p.iscanceled():
                xbmcplugin.endOfDirectory(HANDLE, False, cacheToDisc=False)
                return
            if idx == 1 or idx % 25 == 0 or idx == total:
                p.update(60 + int(38 * (idx / total)), f"Lade Sender … ({idx}/{total})")

            base_name = c.get("name", "Channel")
            chno      = c.get("chno")

            # Einheitliche Nummerndarstellung fuer alle Live-Provider:
            # Wenn der Provider eine echte Sendernummer liefert (z.B. Pluto/
            # Samsung), bleibt diese erhalten. Plex und Free-TV liefern keine
            # chno-Angabe; dort verwenden wir ausschliesslich fuer die Anzeige
            # die aktuelle Listenposition. Playback, IDs, EPG-Zuordnung und
            # Sortierung bleiben dadurch unveraendert.
            display_chno = chno if (chno and chno != 9999) else idx
            if show_chnos:
                label = colorize(f"{display_chno} | {base_name}", COLOR_CHANNEL)
            else:
                label = colorize(base_name, COLOR_CHANNEL)

            # EPG auflösen: JSON direkt aus Dict, M3U aus epg_map
            if not source_epg_enabled:
                epg_item = None
            elif is_json:
                epg_item = {"now": c.get("epg_now"), "next": c.get("epg_next")} if (c.get("epg_now") or c.get("epg_next")) else None
            else:
                epg_item, epg_key = _resolve_m3u_epg(c, epg_map)
                if epg_item:
                    epg_match_count += 1

            now_str, next_str, plot, now_time, now_colored = epg_label_parts(epg_item)
            if not plot:
                plot = c.get("plot_static", "")

            if show_epg and now_colored:
                label = f"{label}  {now_colored}"

            li = xbmcgui.ListItem(label)
            li.setProperty("IsPlayable", "true")
            if next_str:
                li.setLabel2(next_str)

            title_for_skins = base_name
            if now_str:
                title_for_skins = f"{base_name}  {now_str}"
            set_video_info(li, title_for_skins, plot)

            logo = (c.get("logo") or "").strip()
            if not logo and not is_json:
                cid = (c.get("channel_id") or c.get("tvgid") or "").strip()
                logo = (icon_map.get(cid) or "").strip()
            if logo and src.get("type") != "m3u":
                # Provider-Logos duerfen weiterhin optional lokal gecacht werden.
                # M3U-Logos werden dagegen immer als direkte tvg-logo/XMLTV-URL
                # an Kodi uebergeben; Kodi uebernimmt seinen eigenen Bildcache.
                logo = get_logo_local(logo, force=False)
            set_art(li, logo)

            if is_fav(c, favs):
                cm = [("Favorit entfernen", "RunPlugin(%s)" % build_url({"action": "fav_del", "key": quote_plus(fav_key(c))}))]
            else:
                c_with_src = dict(c, source_id=source_id)
                payload = quote_plus(json.dumps(c_with_src, ensure_ascii=False))
                cm = [("Zu Favoriten", "RunPlugin(%s)" % build_url({"action": "fav_add", "data": payload}))]
            li.addContextMenuItems(cm)

            if src.get("type") == "plex_de_static":
                now_cm_url = build_url({"action": "plex_now_playing",
                                        "part_url": quote_plus(c.get("url", "")),
                                        "name": quote_plus(base_name)})
                li.addContextMenuItems([("Jetzt laeuft anzeigen", "RunPlugin(%s)" % now_cm_url)])

            if src.get("type") == "plex_de_static":
                play_url = build_url({"action": "play_plex",
                                      "channel_id": quote_plus(c.get("channel_id", "")),
                                      "part_url": quote_plus(c.get("url", "")),
                                      "name": quote_plus(base_name), "plot": quote_plus(plot)})
            else:
                play_url = build_url({"action": "play", "url": quote_plus(c.get("url", "")), "name": quote_plus(base_name), "plot": quote_plus(plot)})
            xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)

        xbmcplugin.setContent(HANDLE, "episodes")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def play_stream(url, name, plot=""):
    WIN.setProperty(RETURN_FROM_PLAY_FLAG, "1")

    stream_url = unquote_plus(url)
    name = unquote_plus(name)
    plot = unquote_plus(plot) if plot else ""

    # Samsung TV Plus wird in der Senderliste ueber kurze jmp2.uk/stvp-* URLs
    # geliefert. Diese leiten auf das eigentliche HLS-Manifest weiter. Wenn die
    # Kurz-URL direkt an Kodi geht, wird sie mangels .m3u8-Endung als MPEG-TS
    # behandelt. Das kann nach wenigen Sekunden zu Buffer-Timeouts fuehren.
    # Deshalb die Weiterleitung vor dem Start aufloesen und Kodi das echte HLS
    # Manifest uebergeben.
    if "jmp2.uk/stvp-" in stream_url.lower():
        try:
            r = requests.get(stream_url, headers=HEADERS, timeout=20, allow_redirects=True, stream=True)
            r.raise_for_status()
            resolved = r.url or stream_url
            r.close()
            if resolved != stream_url:
                log(f"[Samsung] Stream aufgeloest: {stream_url} -> {resolved}")
                stream_url = resolved
        except Exception as e:
            log(f"[Samsung] Stream-Aufloesung fehlgeschlagen, nutze Kurz-URL: {e}", xbmc.LOGWARNING)

    extra_headers = ""
    if "provider.plex.tv" in stream_url or "epg.provider.plex.tv" in stream_url:
        # Plex' CDN verlangt offenbar Referer/Origin - ohne diese Header liefert
        # der Server einen HTTP-Fehlerstatus (siehe CCurlFile::Stat error(22)).
        extra_headers = (
            f"&Referer={quote_plus('https://watch.plex.tv/')}"
            f"&Origin={quote_plus('https://watch.plex.tv')}"
        )

    playback_url = stream_url + f"|User-Agent={quote_plus(UA)}{extra_headers}"

    li = xbmcgui.ListItem(name, path=playback_url)
    li.setProperty("IsPlayable", "true")
    set_video_info(li, name, "")

    # FFmpeg Direct verbessert Live-TV/Timeshift, ist aber optional. Ohne das
    # Binary-Addon kann Kodi HLS/MPEG-TS weiterhin nativ öffnen.
    if kodi_has_addon("inputstream.ffmpegdirect"):
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
        li.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        li.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
        li.setProperty("inputstream.ffmpegdirect.playback_as_live", "true")
        li.setProperty("inputstream.ffmpegdirect.chunk_size", "20971520")
        li.setProperty("inputstream.ffmpegdirect.buffer_mode", "full")
        li.setProperty("inputstream.ffmpegdirect.cache", "false")
        li.setProperty("inputstream.ffmpegdirect.seekable", "true")
        li.setProperty("inputstream.ffmpegdirect.scalevideo", "false")
        li.setProperty("inputstream.ffmpegdirect.codec_whitelist", "ALL")
        li.setProperty("inputstream.ffmpegdirect.protocol_whitelist", "http,https,tcp")
        li.setProperty("inputstream.ffmpegdirect.max_bandwidth", "0")
        li.setProperty("inputstream.ffmpegdirect.ignore_ts", "true")
        li.setProperty("inputstream.ffmpegdirect.user_agent", UA)
        if extra_headers:
            li.setProperty(
                "inputstream.ffmpegdirect.manifest_headers",
                f"Referer=https://watch.plex.tv/&Origin=https://watch.plex.tv",
            )
            li.setProperty(
                "inputstream.ffmpegdirect.stream_headers",
                f"Referer=https://watch.plex.tv/&Origin=https://watch.plex.tv",
            )

        if ".m3u8" in stream_url:
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setProperty("inputstream.ffmpegdirect.mime_type", "application/vnd.apple.mpegurl")
            li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
        else:
            li.setMimeType("video/mp2t")
            li.setProperty("inputstream.ffmpegdirect.mime_type", "video/mp2t")
            li.setProperty("inputstream.ffmpegdirect.manifest_type", "mpegts")
    else:
        log("inputstream.ffmpegdirect nicht verfügbar - native Kodi-Wiedergabe")
        if ".m3u8" in stream_url:
            li.setMimeType("application/vnd.apple.mpegurl")
        else:
            li.setMimeType("video/mp2t")

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _pick_source(title="Quelle auswählen"):
    labels = []
    ids = []
    for s in SOURCES:
        labels.append(s.get("name") or s.get("id"))
        ids.append(s.get("id"))
    if not labels:
        notify("Keine Quellen konfiguriert", err=True)
        return None
    idx = xbmcgui.Dialog().select(title, labels)
    if idx < 0:
        return None
    return get_source(ids[idx])


def view_reload_pick_source():
    s = _pick_source("Cache leeren – Quelle wählen")
    if not s:
        return
    src_type = s.get("type", "m3u")
    if src_type == "plex_de_static":
        cpath = cache_path("plexepg", "de")
        if xbmcvfs.exists(cpath):
            xbmcvfs.delete(cpath)
        notify("Plex (DE): EPG-Cache geleert - wird beim nächsten Öffnen neu geladen")
        view_root()
        return
    if src_type == "json":
        region = (s.get("region") or "de").lower()
        cpath = cache_path("json", s.get("url", "") + region)
    else:
        url = (s.get("url") or "").strip()
        if not url:
            notify("Quelle hat keine URL", err=True)
            return
        cpath = cache_path("m3u", url)
    try:
        if xbmcvfs.exists(cpath):
            xbmcvfs.delete(cpath)
            notify("Cache geleert")
        else:
            notify("Kein Cache vorhanden")
    except Exception as e:
        log(f"Cache delete failed: {e}", xbmc.LOGERROR)
        notify("Cache konnte nicht gelöscht werden", err=True)
    view_root()


def view_epg_reload_pick_source():
    s = _pick_source("EPG neu laden – Quelle wählen")
    if not s:
        return

    source_id = (s.get("id") or "unknown").strip() or "unknown"
    epg_url = (s.get("epg") or "").strip()
    if not epg_url:
        notify("Keine EPG-URL gefunden", err=True)
        view_root()
        return

    meta_p, xml_p, idx_p = _epg_paths(epg_url)
    try:
        if xbmcvfs.exists(meta_p):
            xbmcvfs.delete(meta_p)
        if xbmcvfs.exists(xml_p):
            xbmcvfs.delete(xml_p)
        if xbmcvfs.exists(idx_p):
            xbmcvfs.delete(idx_p)
        notify(f"EPG-Cache geleert ({source_id})")
    except Exception as e:
        log(f"EPG cache delete failed: {e}", xbmc.LOGERROR)
        notify("EPG-Cache konnte nicht gelöscht werden", err=True)

    view_root()


def router(paramstring):
    try:
        params = dict(parse_qsl(paramstring[1:])) if paramstring and paramstring.startswith("?") else {}
        action = params.get("action")

        if action == "source":
            view_source(params.get("id", ""))
        elif action == "group":
            sid = params.get("id", "")
            grp = params.get("group", ALL_GROUP)
            view_group(sid, grp)
        elif action == "favorites":
            view_favorites()
        elif action == "logos_clear":
            clear_logo_cache()
            view_root()
        elif action == "reload_pick_source":
            view_reload_pick_source()
        elif action == "epg_reload_pick_source":
            view_epg_reload_pick_source()
        elif action == "fav_add":
            favs = load_favs()
            ch = json.loads(unquote_plus(params.get("data", "")))
            favs.append(ch)
            save_favs(favs)
            notify("Favorit hinzugefügt")
            xbmcplugin.endOfDirectory(HANDLE, True, updateListing=False, cacheToDisc=False)
        elif action == "fav_del":
            key = unquote_plus(params.get("key", ""))
            favs = [x for x in load_favs() if fav_key(x) != key]
            save_favs(favs)
            notify("Favorit entfernt")
            xbmcplugin.endOfDirectory(HANDLE, True, updateListing=True, cacheToDisc=False)
        elif action == "fav_up":
            key  = unquote_plus(params.get("key", ""))
            favs = load_favs()
            idx  = next((i for i, x in enumerate(favs) if fav_key(x) == key), -1)
            if idx > 0:
                favs[idx - 1], favs[idx] = favs[idx], favs[idx - 1]
                save_favs(favs)
            xbmc.executebuiltin("Container.Refresh")
        elif action == "fav_down":
            key  = unquote_plus(params.get("key", ""))
            favs = load_favs()
            idx  = next((i for i, x in enumerate(favs) if fav_key(x) == key), -1)
            if 0 <= idx < len(favs) - 1:
                favs[idx], favs[idx + 1] = favs[idx + 1], favs[idx]
                save_favs(favs)
            xbmc.executebuiltin("Container.Refresh")
        elif action == "play":
            play_stream(params.get("url", ""), params.get("name", "Stream"), params.get("plot", ""))
        elif action == "play_plex":
            play_plex_channel(params.get("channel_id", ""), params.get("name", "Stream"),
                               params.get("plot", ""), params.get("part_url", ""))
        elif action == "plex_now_playing":
            view_plex_now_playing(params.get("part_url", ""), params.get("name", ""))
        elif action == "plex_vod_more_info":
            view_plex_vod_more_info(params.get("public_url", ""), params.get("name", ""))
        elif action == "plex_login":
            plex_login_flow()
            view_root()
        elif action == "plex_logout":
            plex_logout()
            view_root()
        elif action == "rktv_categories":
            view_rktv_categories()
        elif action == "rktv_channels":
            view_rktv_channels(unquote_plus(params.get("cat", "")))
        elif action == "rktv_vod_main":
            view_rktv_vod_main()
        elif action == "rktv_genres":
            view_rktv_genres()
        elif action == "rktv_vod_categories":
            view_rktv_vod_categories()
        elif action == "rktv_vod_records":
            view_rktv_vod_records(
                unquote_plus(params.get("slug", "")),
                unquote_plus(params.get("pic", "")),
                unquote_plus(params.get("fan", "")),
            )
        elif action == "rktv_vod_list":
            view_rktv_vod_list(
                unquote_plus(params.get("slug", "")),
                unquote_plus(params.get("name", "")),
                int(params.get("page", "1")),
            )
        elif action == "rktv_vod_seasons":
            view_rktv_vod_seasons(
                unquote_plus(params.get("slug", "")),
                unquote_plus(params.get("name", "")),
                unquote_plus(params.get("thumb", "")),
            )
        elif action == "rktv_vod_episodes":
            view_rktv_vod_episodes(
                unquote_plus(params.get("slug", "")),
                unquote_plus(params.get("name", "")),
                unquote_plus(params.get("thumb", "")),
            )
        elif action == "rktv_vod_play":
            view_rktv_vod_play(
                unquote_plus(params.get("slug", "")),
                params.get("species", "movies"),
                unquote_plus(params.get("name", "")),
                unquote_plus(params.get("thumb", "")),
                unquote_plus(params.get("seid", "")),
            )
        elif action == "rktv_play":
            play_rktv_live(
                params.get("slug", ""),
                params.get("lang", "DEU"),
                params.get("name", ""),
                params.get("pic", ""),
                params.get("plot", ""),
            )
        elif action == "region_info":
            view_region_info()
        elif action == "pluto_vod_genres":
            view_pluto_vod_genres()
        elif action == "pluto_vod_list":
            view_pluto_vod_list(unquote_plus(params.get("cat_id", "")))
        elif action == "pluto_vod_seasons":
            view_pluto_vod_seasons(
                unquote_plus(params.get("series_id", "")),
                unquote_plus(params.get("name", "")),
                unquote_plus(params.get("plot", "")),
                unquote_plus(params.get("poster", "")),
            )
        elif action == "pluto_vod_play":
            view_pluto_vod_play(
                params.get("url", ""),
                params.get("name", "Stream"),
                params.get("plot", ""),
            )
        elif action == "plex_vod_main":
            view_plex_vod_main()
        elif action == "plex_vod_genres":
            view_plex_vod_genres()
        elif action == "plex_vod_collections":
            view_plex_vod_collections()
        elif action == "plex_vod_hub":
            view_plex_vod_hub(params.get("section", "movies"), params.get("hub", "popular"))
        elif action == "plex_vod_children":
            view_plex_vod_children(
                params.get("rating_key", ""),
                unquote_plus(params.get("name", "")),
                params.get("level", "season"),
            )
        elif action == "plex_vod_play":
            view_plex_vod_play(
                params.get("rating_key", ""),
                params.get("name", "Stream"),
                params.get("plot", ""),
            )
        else:
            view_root()

    except Exception as e:
        log("Router crash: " + repr(e), xbmc.LOGERROR)
        log(traceback.format_exc(), xbmc.LOGERROR)
        notify("Fehler im Addon (Details im Kodi-Log)", err=True, ms=6000)
        try:
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
        except Exception:
            pass


if __name__ == "__main__":
    ensure_dirs()
    param = sys.argv[2] if len(sys.argv) > 2 else ""
    if ensure_region_setup():
        router(param)
    else:
        try:
            xbmcplugin.endOfDirectory(HANDLE, False, cacheToDisc=False)
        except Exception:
            pass
