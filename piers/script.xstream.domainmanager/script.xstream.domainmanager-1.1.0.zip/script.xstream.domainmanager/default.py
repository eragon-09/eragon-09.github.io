# -*- coding: utf-8 -*-
from resources.lib.manager import run  # noqa

if __name__ == "__main__":
    run()
