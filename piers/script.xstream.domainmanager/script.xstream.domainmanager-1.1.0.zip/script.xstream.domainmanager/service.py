# -*- coding: utf-8 -*-
import xbmc

monitor = xbmc.Monitor()

# Kodi braucht oft ein paar Sekunden nach Start, damit alle Pfade/Addons sauber verfügbar sind
if monitor.waitForAbort(10):
    raise SystemExit

from resources.lib.manager import handle_first_install_and_autostart  # noqa: E402

try:
    handle_first_install_and_autostart()
except Exception as e:
    xbmc.log(f"[script.xstream.domainmanager] service.py error: {e}", xbmc.LOGERROR)
