- First-run wizard now continues directly into the main menu in the same plugin invocation; removed the temporary Container.Update restart that exposed Kodi's file-folder view.
# Changelog

## 2.5.0
- VOD-Bereich stabilisiert: fehlende Portaldaten, Artwork, Seitennavigation und Streamfehler werden robuster behandelt.
### Added
- Modernisierte Architektur
- Netzwerk- und Service-Konsolidierung
- Performance-Optimierungen
- Stabilitätsverbesserungen
- Experimenteller, portalübergreifender Genre-Filter für VOD-Kategorien (nutzt vorhandene Film-Metadaten, keine spezielle Portal-API).
- Ländergruppen-Eintrag in „VOD - Favoriten dieser Kategorie“ umbenannt.
- VOD-Kategorien enthalten nun „Neu hinzugefügt“ neben Favoriten, Suche, Genre- und Jahresfilter.

## 2.5.0 Runtime reload patch
- Fixed first-time "Meine Sender" synchronization loop caused by stale service-side Kodi settings.
- The background service now reloads portal/MAC values directly from persisted userdata settings.
- Added immediate settings-change reload and quiet polling without repeated empty-setting errors.
