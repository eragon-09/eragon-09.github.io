# -*- coding: utf-8 -*-
"""Global Back-key dispatcher for Titan live TV playback.

The add-on keymap consumes Back in FullscreenVideo.  During Titan live TV it
opens the add-on-owned favorite zapper.  For other videos it returns to the
home window while playback continues, matching Kodi's common fullscreen Back
behaviour without recursively dispatching the mapped Back action.
"""
from __future__ import absolute_import, division, unicode_literals

import time
import xbmc
import xbmcgui

ADDON_ID = 'plugin.video.titanmacvodedition'
HOME_WINDOW_ID = 10000
PROP_LIVE = 'TitanMacVOD.LivePlayback'
PROP_LOCK = 'TitanMacVOD.ZapperOpening'
PROP_LAST = 'TitanMacVOD.ZapperLastOpen'


def _home():
    return xbmcgui.Window(HOME_WINDOW_ID)


def _is_titan_live(player):
    home = _home()
    if home.getProperty(PROP_LIVE) == '1':
        return True
    try:
        path = player.getPlayingFile() or ''
    except Exception:
        path = ''
    return path.startswith('plugin://{}/'.format(ADDON_ID))


def main():
    player = xbmc.Player()
    if not player.isPlayingVideo() or not _is_titan_live(player):
        # Avoid Action(Back): it would hit this add-on keymap again.  Going to
        # Home reproduces the normal Kodi/Aeon-Nox fullscreen Back result while
        # leaving unrelated playback running.
        xbmc.executebuiltin('ActivateWindow(Home)')
        return

    home = _home()
    if home.getProperty(PROP_LOCK) == '1':
        return

    now = time.time()
    try:
        last = float(home.getProperty(PROP_LAST) or '0')
    except Exception:
        last = 0.0
    if now - last < 0.45:
        return

    home.setProperty(PROP_LOCK, '1')
    home.setProperty(PROP_LAST, str(now))
    try:
        from lib.favorite_zapper import show_favorite_zapper
        show_favorite_zapper()
    finally:
        home.clearProperty(PROP_LOCK)


if __name__ == '__main__':
    main()
