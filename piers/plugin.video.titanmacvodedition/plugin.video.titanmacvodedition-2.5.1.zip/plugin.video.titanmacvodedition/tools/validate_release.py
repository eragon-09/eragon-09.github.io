#!/usr/bin/env python3
"""Offline release validation for the Titan Kodi add-on.

This script intentionally does not import Kodi modules. It validates the
packaged source tree before a ZIP is published.
"""
from __future__ import annotations

import argparse
import ast
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ADDON_ID = "plugin.video.titanmacvodedition"
REQUIRED_FILES = (
    "addon.xml",
    "addon_entry.py",
    "service_entry.py",
    "lib/addon.py",
    "lib/api.py",
    "lib/auth.py",
    "lib/core_entry.py",
    "lib/portal_manager.py",
    "lib/xmltv.py",
    "resources/settings.xml",
)
EPG_MARKERS = (
    "lib/xmltv.py",
    "resources/lists/tv_spielfilm.txt",
)


def fail(message: str) -> None:
    print(f"FEHLER: {message}", file=sys.stderr)
    raise SystemExit(1)


def validate(root: Path, expected_version: str | None) -> str:
    missing = [name for name in REQUIRED_FILES if not (root / name).is_file()]
    if missing:
        fail("Pflichtdateien fehlen: " + ", ".join(missing))

    try:
        addon_tree = ET.parse(root / "addon.xml")
        ET.parse(root / "resources/settings.xml")
    except ET.ParseError as exc:
        fail(f"Ungültiges XML: {exc}")

    addon = addon_tree.getroot()
    if addon.attrib.get("id") != ADDON_ID:
        fail(f"Unerwartete Add-on-ID: {addon.attrib.get('id')!r}")
    version = addon.attrib.get("version", "").strip()
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        fail(f"Ungültige Versionsnummer: {version!r}")
    if expected_version and version != expected_version:
        fail(f"Version {version} entspricht nicht {expected_version}")

    history = (root / "HISTORY.md").read_text(encoding="utf-8")
    if not history.startswith(f"# {version}\n"):
        fail("HISTORY.md beginnt nicht mit der aktuellen Version")

    epg_missing = [name for name in EPG_MARKERS if not (root / name).is_file()]
    if epg_missing:
        fail("EPG-Komponenten fehlen: " + ", ".join(epg_missing))

    cache_files = [p for p in root.rglob("*") if p.name == "__pycache__" or p.suffix in {".pyc", ".pyo"}]
    if cache_files:
        fail("Cachedateien im Paket: " + ", ".join(str(p.relative_to(root)) for p in cache_files[:5]))

    python_files = sorted(root.rglob("*.py"))
    for path in python_files:
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (SyntaxError, UnicodeDecodeError) as exc:
            fail(f"Python-Prüfung fehlgeschlagen für {path.relative_to(root)}: {exc}")

    print(f"OK: {ADDON_ID} {version}")
    print(f"OK: {len(python_files)} Python-Dateien syntaktisch geprüft")
    print("OK: XML, Pflichtdateien und EPG-Komponenten vorhanden")
    print("OK: Keine Python-Cachedateien enthalten")
    return version


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=Path(__file__).resolve().parents[1], type=Path)
    parser.add_argument("--version", dest="expected_version")
    args = parser.parse_args()
    validate(args.root.resolve(), args.expected_version)


if __name__ == "__main__":
    main()
