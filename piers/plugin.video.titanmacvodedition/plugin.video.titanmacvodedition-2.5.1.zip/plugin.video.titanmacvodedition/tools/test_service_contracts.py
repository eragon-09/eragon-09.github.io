#!/usr/bin/env python3
"""Static compatibility checks for the ChannelService façade.

The test intentionally parses the source instead of importing it, so it runs
outside Kodi without xbmc/xbmcgui stubs.
"""
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SERVICES = ROOT / "lib" / "services.py"
EXPECTED = {
    "compact_now_label",
    "extract_now_next",
    "next_label2",
    "now_label2",
    "resolve_channel_ids",
    "strip_kodi_markup",
    "create_live_channel_item",
    "numbered_channel_label",
    "resolve_channel_logo",
}


def main() -> int:
    tree = ast.parse(SERVICES.read_text(encoding="utf-8"), filename=str(SERVICES))
    channel_class = next(
        (node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "ChannelService"),
        None,
    )
    if channel_class is None:
        raise AssertionError("ChannelService class is missing")

    methods = {
        node.name: node
        for node in channel_class.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    missing = EXPECTED.difference(methods)
    if missing:
        raise AssertionError("Missing ChannelService methods: {}".format(", ".join(sorted(missing))))

    for name in sorted(EXPECTED):
        method = methods[name]
        if method.args.vararg is None or method.args.kwarg is None:
            raise AssertionError("{} must accept *args and **kwargs".format(name))
        calls = [node for node in ast.walk(method) if isinstance(node, ast.Call)]
        if len(calls) != 1 or not isinstance(calls[0].func, ast.Name) or calls[0].func.id != name:
            raise AssertionError("{} must directly forward to the helper with the same name".format(name))
        call = calls[0]
        if not any(isinstance(arg, ast.Starred) for arg in call.args):
            raise AssertionError("{} does not forward *args".format(name))
        if not any(keyword.arg is None for keyword in call.keywords):
            raise AssertionError("{} does not forward **kwargs".format(name))

    print("ChannelService compatibility contract: OK ({} methods)".format(len(EXPECTED)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
