"""Skin-neutral helpers for live-TV EPG labels and channel identifiers."""
from __future__ import absolute_import, unicode_literals

import re

from .live_constants import (CHANNEL_LABEL_MAX_VISIBLE_LENGTH,
                             EPG_TITLE_MAX_LENGTH,
                             SECONDARY_LABEL_MAX_LENGTH)


def strip_kodi_markup(value):
    try:
        text = str(value or '')
        text = text.replace('[B]', '').replace('[/B]', '')
        text = re.sub(r'\[COLOR(?:=|\s)[^\]]*\]', '', text, flags=re.IGNORECASE)
        text = re.sub(r'\[/COLOR\]', '', text, flags=re.IGNORECASE)
        return text.strip()
    except Exception:
        return str(value or '').strip()


def extract_now_next(epg_text):
    try:
        if not epg_text or 'Keine Informationen' in str(epg_text):
            return '', ''
        lines = [line.strip() for line in str(epg_text).split('\n') if line.strip()]
        return (lines[0] if lines else '', lines[1] if len(lines) > 1 else '')
    except Exception:
        return '', ''


def resolve_channel_ids(channel):
    """Return stable, de-duplicated EPG identifier candidates."""
    candidates = []
    for value in (channel or {}).get('epg_candidates') or []:
        value = str(value or '').strip()
        if value and value not in candidates:
            candidates.append(value)
    for field in ('id', 'epg_id', 'ch_id', 'channel_id', 'xmltv_id', 'tvg_id'):
        value = str((channel or {}).get(field) or '').strip()
        if value and value not in candidates:
            candidates.append(value)
    return candidates


def _shorten_title(title, limit=EPG_TITLE_MAX_LENGTH):
    title = strip_kodi_markup(title)
    if limit and len(title) > limit:
        return title[:max(1, limit - 1)].rstrip() + '…'
    return title


def compact_now_label(channel_name, now_line, max_visible=CHANNEL_LABEL_MAX_VISIBLE_LENGTH,
                      max_title=EPG_TITLE_MAX_LENGTH):
    """Return ``Sender • HH:MM–HH:MM Titel`` without empty separators."""
    channel_name = str(channel_name or '').strip()
    now_clean = strip_kodi_markup(now_line)
    if not now_clean:
        return channel_name

    match = re.match(r'^\s*(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*:\s*(.*)$', now_clean)
    if match:
        start, end, title = match.groups()
        time_part = '{}–{}'.format(start, end)
    else:
        time_part = ''
        title = now_clean

    title = _shorten_title(title, max_title)
    prefix = '{}  [COLOR=yellow]• {}[/COLOR]'.format(channel_name, time_part) if time_part else '{}  [COLOR=yellow]•[/COLOR]'.format(channel_name)
    suffix = (' ' + title) if title else ''

    # Preserve channel and complete time range; shorten only the programme title.
    visible_prefix = strip_kodi_markup(prefix)
    room = max_visible - len(visible_prefix) - (1 if title else 0)
    if title and room > 0 and len(title) > room:
        title = title[:max(1, room - 1)].rstrip() + '…'
        suffix = ' ' + title
    return prefix + suffix


def compact_now_suffix(now_line, max_title=EPG_TITLE_MAX_LENGTH):
    """Return a compact suffix suitable for add-on-owned zapper XML."""
    formatted = compact_now_label('', now_line, max_visible=999, max_title=max_title).strip()
    return formatted


def now_label2(now_line, max_len=SECONDARY_LABEL_MAX_LENGTH):
    now_clean = strip_kodi_markup(now_line)
    if not now_clean:
        return ''
    text = '[COLOR=yellow]• Jetzt:[/COLOR] {}'.format(now_clean)
    return text if len(strip_kodi_markup(text)) <= max_len else strip_kodi_markup(text)[:max_len - 1] + '…'


def next_label2(next_line, max_len=SECONDARY_LABEL_MAX_LENGTH):
    next_clean = strip_kodi_markup(next_line)
    if not next_clean:
        return ''
    text = '[COLOR=cyan]Danach:[/COLOR] {}'.format(next_clean)
    return text if len(strip_kodi_markup(text)) <= max_len else strip_kodi_markup(text)[:max_len - 1] + '…'
