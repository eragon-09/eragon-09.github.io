# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

"""Portal import, backup, restore and manual editing workflows."""
import datetime
import json
import os
import re
import tempfile
import zipfile
from urllib.parse import urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .constants import PORTAL_SCHEMA_VERSION

TITLE = 'Titan Portalverwaltung'
from .portal_manager_data import (ADDON_ID, DATA_DIR, STATE_PATH, MAC_RE, _ensure_dir, _read, _write,
                                  _log, _parse_date, _portal_id, load_portals,
                                  normalize_portal_url, parse_txt_multi, save_portal, _clean_portal_for_storage)
from .portal_manager_status import days_left, portal_statistics

def update_portal(portal):
    path = portal.get('_path') or '{}/{}.json'.format(DATA_DIR, _portal_id(portal.get('portal','')))
    clean = _clean_portal_for_storage(portal)
    _write(path, json.dumps(clean, indent=2, ensure_ascii=False))

def delete_portal(portal):
    path = portal.get('_path')
    return bool(path and xbmcvfs.delete(path))

def _scan_import_issues(content):
    """Count malformed MAC/date lines without rejecting otherwise valid files."""
    invalid_macs = 0
    invalid_dates = 0
    for line in (content or '').replace('\x00', '').splitlines():
        low = line.lower()
        if 'mac' in low and ':' in line and not MAC_RE.search(line):
            invalid_macs += 1
        if re.search(r'exp(?:ire|iry|iration)?|ablauf(?:datum)?|gueltig|gültig|valid(?:ity)?|datum|bis', line, re.I) and not _parse_date(line):
            # Ignore pure headings such as "Expiry".
            if any(ch.isdigit() for ch in line):
                invalid_dates += 1
    return invalid_macs, invalid_dates

def preview_import(paths):
    """Parse selected files without writing and return a compact import preview."""
    preview = {'files': len(paths), 'readable': 0, 'portals': set(), 'macs': 0,
               'invalid_macs': 0, 'invalid_dates': 0, 'errors': []}
    for path in paths:
        fn = os.path.basename(path)
        try:
            content = _read(path)
            bad_mac, bad_date = _scan_import_issues(content)
            preview['invalid_macs'] += bad_mac
            preview['invalid_dates'] += bad_date
            records = parse_txt_multi(content, fn)
            preview['readable'] += 1
            for record in records:
                preview['portals'].add(record.get('portal'))
                preview['macs'] += len(record.get('macs', []))
        except Exception as exc:
            preview['errors'].append('{}: {}'.format(fn, exc))
    preview['portal_count'] = len(preview.pop('portals'))
    return preview

def confirm_import_preview(paths):
    preview = preview_import(paths)
    text = ('Importvorschau\n\n{} TXT-Dateien\n{} lesbar\n{} Portale\n{} MAC-Adressen\n\n'
            '{} ungültige MAC-Zeilen\n{} ungültige Datumszeilen').format(
        preview['files'], preview['readable'], preview['portal_count'], preview['macs'],
        preview['invalid_macs'], preview['invalid_dates'])
    if preview['errors']:
        text += '\n\nNicht lesbar:\n' + '\n'.join(preview['errors'][:6])
    if not preview['readable']:
        xbmcgui.Dialog().ok(TITLE, text)
        return False
    return xbmcgui.Dialog().yesno(TITLE, text + '\n\nAuswahl jetzt importieren?')

def export_backup():
    """Export portal JSON files and manager state to a user-selected ZIP."""
    target_dir = xbmcgui.Dialog().browse(0, 'Zielordner für Portal-Sicherung', 'files', '', False, False, '')
    if not target_dir:
        return False
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = 'titan_portal_backup_{}.zip'.format(stamp)
    target = _join_vfs_path(target_dir, filename)
    local_target = xbmcvfs.translatePath(target) or target
    os.makedirs(os.path.dirname(local_target), exist_ok=True)
    portals = load_portals()
    manifest = {
        'addon': ADDON_ID, 'created': datetime.datetime.now().replace(microsecond=0).isoformat(),
        'schema': 2, 'portal_count': len(portals),
        'mac_count': sum(len(p.get('macs', [])) for p in portals)
    }
    addon = xbmcaddon.Addon(id=ADDON_ID)
    manifest['active_portal'] = addon.getSetting('server_address')
    manifest['active_mac'] = addon.getSetting('mac_address')
    with zipfile.ZipFile(local_target, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('manifest.json', json.dumps(manifest, indent=2, ensure_ascii=False))
        for portal in portals:
            clean = _clean_portal_for_storage(portal)
            zf.writestr('portals/{}.json'.format(_portal_id(clean.get('portal', ''))),
                        json.dumps(clean, indent=2, ensure_ascii=False))
        if xbmcvfs.exists(STATE_PATH):
            zf.writestr('portal_manager_state.json', _read(STATE_PATH))
    xbmcgui.Dialog().ok(TITLE, 'Sicherung erstellt:\n\n{}\n\n{} Portale gesichert.'.format(filename, len(portals)))
    return True

def restore_backup():
    """Validate and merge a previously exported portal backup."""
    selected = xbmcgui.Dialog().browse(1, 'Portal-Sicherung auswählen', 'files', '.zip', False, False, '')
    if not selected:
        return False
    local = xbmcvfs.translatePath(selected) or selected
    valid = []
    state_text = None
    manifest = {}
    try:
        with zipfile.ZipFile(local, 'r') as zf:
            if 'manifest.json' in zf.namelist():
                manifest = json.loads(zf.read('manifest.json').decode('utf-8'))
            for name in zf.namelist():
                if name.startswith('portals/') and name.lower().endswith('.json'):
                    data = json.loads(zf.read(name).decode('utf-8'))
                    data['portal'] = normalize_portal_url(data.get('portal', ''))
                    if not data['portal'] or not isinstance(data.get('macs', []), list):
                        raise ValueError('Ungültige Portaldatei: {}'.format(name))
                    valid.append(data)
                elif name == 'portal_manager_state.json':
                    state_text = zf.read(name).decode('utf-8')
                    json.loads(state_text)
    except Exception as exc:
        xbmcgui.Dialog().ok(TITLE, 'Sicherung ist ungültig oder beschädigt:\n\n{}'.format(exc))
        return False
    if not valid:
        xbmcgui.Dialog().ok(TITLE, 'Die Sicherung enthält keine gültigen Portale.')
        return False
    if not xbmcgui.Dialog().yesno(TITLE, '{} Portale aus der Sicherung zusammenführen?\n\nBestehende Portale bleiben erhalten; neue MACs und Ablaufdaten werden ergänzt.'.format(len(valid))):
        return False
    macs = 0
    for data in valid:
        _path, merged = save_portal(data)
        macs += len(merged.get('macs', []))
    if state_text:
        _write(STATE_PATH, state_text)
    xbmcgui.Dialog().ok(TITLE, 'Wiederherstellung abgeschlossen.\n\n{} Portale verarbeitet\n{} MAC-Einträge vorhanden'.format(len(valid), macs))
    return True

def _import_paths(paths):
    stats = {'files_found': len(paths), 'files_ok': 0, 'files_skipped': 0,
             'portals_seen': set(), 'new_portals': 0, 'updated_portals': 0,
             'new_macs': 0, 'updated_macs': 0, 'duplicates': 0,
             'invalid_macs': 0, 'invalid_dates': 0, 'errors': []}
    for path in paths:
        fn = os.path.basename(path)
        try:
            content = _read(path)
            bad_mac, bad_date = _scan_import_issues(content)
            stats['invalid_macs'] += bad_mac
            stats['invalid_dates'] += bad_date
            records = parse_txt_multi(content, fn)
            stats['files_ok'] += 1
            for data in records:
                existing = next((p for p in load_portals(import_legacy=False) if p.get('portal') == data.get('portal')), None)
                before = {m.get('mac','').upper(): m.get('exp','') for m in (existing or {}).get('macs', [])}
                if existing:
                    stats['updated_portals'] += 1
                else:
                    stats['new_portals'] += 1
                _path, merged = save_portal(data)
                stats['portals_seen'].add(data.get('portal'))
                for m in data.get('macs', []):
                    mac = m.get('mac','').upper()
                    if mac in before:
                        if m.get('exp') and m.get('exp') != before.get(mac):
                            stats['updated_macs'] += 1
                        else:
                            stats['duplicates'] += 1
                    else:
                        stats['new_macs'] += 1
        except Exception as exc:
            stats['files_skipped'] += 1
            stats['errors'].append('{}: {}'.format(fn, exc))
            _log('TXT übersprungen {}: {}'.format(fn, exc), xbmc.LOGWARNING)
    stats['portals'] = len(stats.pop('portals_seen'))
    return stats

def _show_import_summary(stats):
    text = ('{} TXT-Dateien gefunden\n{} verarbeitet\n{} übersprungen\n\n'
            '{} Portale erkannt\n{} neue MACs\n{} Ablaufdaten aktualisiert\n{} Dubletten übersprungen\n\n{} ungültige MAC-Zeilen\n{} ungültige Datumszeilen').format(
        stats['files_found'], stats['files_ok'], stats['files_skipped'], stats['portals'],
        stats['new_macs'], stats['updated_macs'], stats['duplicates'],
        stats.get('invalid_macs', 0), stats.get('invalid_dates', 0))
    if stats.get('errors'):
        text += '\n\nNicht erkannt:\n' + '\n'.join(stats['errors'][:8])
    xbmcgui.Dialog().ok(TITLE, text)

def import_txt_file():
    selected = xbmcgui.Dialog().browse(1, 'TXT-Datei auswählen', 'files', '.txt', False, False, '')
    if not selected or not selected.lower().endswith('.txt'):
        return 0, 0
    stats = _import_paths([selected])
    _show_import_summary(stats)
    return stats['portals'], stats['new_macs']

def _join_vfs_path(folder, filename):
    """Join Kodi/VFS paths without assuming a slash style."""
    try:
        return xbmcvfs.joinPath(folder, filename)
    except (AttributeError, TypeError):
        return folder.rstrip('/\\') + '/' + filename

def _list_txt_files(folder):
    """Return ``(display_name, readable_path)`` pairs for TXT files.

    Kodi's VFS folder browser can return a local Windows path that
    ``xbmcvfs.listdir`` does not enumerate on every platform. Therefore the
    VFS result is preferred and a translated local ``os.listdir`` is used as
    fallback when it is empty or fails.
    """
    found = []
    vfs_error = None

    try:
        _dirs, files = xbmcvfs.listdir(folder)
        for filename in files or []:
            if filename.lower().endswith('.txt'):
                found.append((filename, _join_vfs_path(folder, filename)))
    except Exception as exc:
        vfs_error = exc
        _log('VFS-Ordner konnte nicht gelesen werden {}: {}'.format(folder, exc), xbmc.LOGWARNING)

    if not found:
        try:
            local_folder = xbmcvfs.translatePath(folder) or folder
            if os.path.isdir(local_folder):
                for filename in os.listdir(local_folder):
                    full_path = os.path.join(local_folder, filename)
                    if os.path.isfile(full_path) and filename.lower().endswith('.txt'):
                        found.append((filename, full_path))
        except Exception as exc:
            _log('Lokaler TXT-Fallback fehlgeschlagen {}: {}'.format(folder, exc), xbmc.LOGWARNING)
            if vfs_error is None:
                vfs_error = exc

    # De-duplicate case-insensitively and keep deterministic alphabetical order.
    unique = {}
    for filename, path in found:
        unique.setdefault(filename.lower(), (filename, path))
    result = sorted(unique.values(), key=lambda item: item[0].lower())
    return result, vfs_error

def import_txt_selection():
    """Select one or more portal TXT files directly in Kodi's file browser.

    ``browseMultiple`` displays the files immediately and uses the active
    Kodi skin's normal selection highlighting.  This avoids the confusing
    empty folder-only browser used by the previous implementation.  A
    compatibility fallback is kept for Kodi builds without browseMultiple.
    """
    dialog = xbmcgui.Dialog()
    paths = []

    try:
        selected = dialog.browseMultiple(
            1, 'Portal-TXT auswählen', 'files', '.txt', False, False, '')
        if selected:
            paths = [path for path in selected if str(path).lower().endswith('.txt')]
    except (AttributeError, TypeError):
        # Older Kodi builds: choose one visible TXT file as the folder anchor,
        # then show the folder contents in a Kodi multi-select dialog.
        anchor = dialog.browse(
            1, 'Eine Portal-TXT aus dem Ordner auswählen', 'files', '.txt',
            False, False, '')
        if not anchor:
            return 0, 0
        folder = os.path.dirname(anchor.rstrip('/\\'))
        txt_entries, read_error = _list_txt_files(folder)
        if not txt_entries:
            message = 'Im ausgewählten Ordner wurden keine Portal-TXT-Dateien gefunden.'
            if read_error:
                message += '\n\nOrdnerfehler: {}'.format(read_error)
            dialog.ok(TITLE, message)
            return 0, 0
        labels = [entry[0] for entry in txt_entries]
        selected_indices = dialog.multiselect('Portal-TXT auswählen', labels, preselect=[])
        if selected_indices is None:
            return 0, 0
        paths = [txt_entries[index][1] for index in selected_indices
                 if 0 <= index < len(txt_entries)]

    # Some Kodi file systems may return duplicates or non-TXT entries despite
    # the mask.  Normalize and sort without changing the selected paths.
    unique = {}
    for path in paths:
        text = str(path)
        if text.lower().endswith('.txt'):
            unique.setdefault(text.lower(), text)
    paths = sorted(unique.values(), key=lambda value: os.path.basename(value).lower())

    if not paths:
        dialog.notification(TITLE, 'Keine TXT-Datei ausgewählt.',
                            xbmcgui.NOTIFICATION_INFO, 3000)
        return 0, 0

    if not confirm_import_preview(paths):
        return 0, 0

    stats = _import_paths(paths)
    _show_import_summary(stats)
    return stats['portals'], stats['new_macs']

def import_txt_folder():
    """Backward-compatible alias for the new multiple-selection import."""
    return import_txt_selection()

def add_manual_portal():
    url = xbmcgui.Dialog().input('Portal-URL eingeben', type=xbmcgui.INPUT_ALPHANUM)
    url = normalize_portal_url(url)
    if not url:
        return None
    mac = xbmcgui.Dialog().input('MAC-Adresse (optional)', type=xbmcgui.INPUT_ALPHANUM).strip().upper()
    macs = [{'mac': mac, 'exp': ''}] if MAC_RE.fullmatch(mac) else []
    data = {'schema': PORTAL_SCHEMA_VERSION, 'portal': url, 'name': urlparse(url).hostname or url, 'source_file': 'manual', 'last_import': datetime.datetime.now().replace(microsecond=0).isoformat(), 'active_mac': mac if macs else '', 'auto_mac': True, 'macs': macs}
    return save_portal(data)[1]

