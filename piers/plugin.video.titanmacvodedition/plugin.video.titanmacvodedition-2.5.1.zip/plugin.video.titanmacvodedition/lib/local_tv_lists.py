"""Backward-compatible interface for ordered local Live-TV lists.

Implementation is organized in ``lib.local_tv`` by responsibility.
"""

from __future__ import absolute_import, division, unicode_literals

from .local_tv.storage import *
from .local_tv.groups import *
from .local_tv.matching import *
from .local_tv.catalog import *
from .local_tv.sync import *
from .local_tv.packages import *
from .local_tv import core as _core

_empty_data = _core._empty_data
_read_json = _core._read_json
_atomic_write = _core._atomic_write
_new_id = _core._new_id
_channel_record_from_name = _core._channel_record_from_name
_channel_record = _core._channel_record
_mapping_identity_keys = _core._mapping_identity_keys
_mapping_payload = _core._mapping_payload
_normalize_match_text = _core._normalize_match_text
_channel_alias_database_path = _core._channel_alias_database_path
_load_channel_aliases = _core._load_channel_aliases
_alias_lookup_tables = _core._alias_lookup_tables
_identity_without_aliases = _core._identity_without_aliases
_quality_neutral_search_term = _core._quality_neutral_search_term
_quality_sort_key = _core._quality_sort_key
_active_country_tokens = _core._active_country_tokens
_search_portal_channels = _core._search_portal_channels
_best_automatic_match = _core._best_automatic_match
_catalog_identity_index = _core._catalog_identity_index
_safe_filename = _core._safe_filename
_group_txt = _core._group_txt

