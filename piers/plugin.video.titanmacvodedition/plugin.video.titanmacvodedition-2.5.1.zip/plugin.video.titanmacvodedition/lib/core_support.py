# -*- coding: utf-8 -*-
"""Shared support helpers for :mod:`lib.core_entry`.

This module contains the side-effect-light path, JSON, validation and legacy
settings helpers formerly embedded in ``core_entry.py``.  Function names and
behaviour are intentionally preserved for backwards compatibility.
"""
from __future__ import absolute_import, division, unicode_literals

import datetime
import json
import os
import random
import re
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional
from urllib.parse import urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .loggers import Logger

STALKER_ID = "plugin.video.titanmacvodedition"
TITLE = "Titan Core Mod"
DATA_ID = "script.portal.mac.converter"
PORTAL_DIR_CANDIDATES = [
    "special://profile/addon_data/%s/2_JSON_Export" % DATA_ID,
    "special://userdata/addon_data/%s/2_JSON_Export" % DATA_ID,
    "special://home/userdata/addon_data/%s/2_JSON_Export" % DATA_ID,
    "special://home/addon_data/%s/2_JSON_Export" % DATA_ID,
    "special://profile/addon_data/%s/portal_mac_list_out" % DATA_ID,
    "special://userdata/addon_data/%s/portal_mac_list_out" % DATA_ID,
]
LOCAL_TOKEN_DIR = "special://profile/addon_data/%s" % STALKER_ID
LOCAL_TOKEN_PATH = "%s/last_local_selection.json" % LOCAL_TOKEN_DIR
PVR_DIR_CANDIDATES = [
    "special://profile/addon_data/pvr.stalker",
    "special://userdata/addon_data/pvr.stalker",
]
_URL_RE = re.compile(r"^https?://", re.I)
_MAC_RE = re.compile(r"^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")

def _log(msg, level=xbmc.LOGINFO):
    if level == xbmc.LOGERROR:
        Logger.error(msg)
    elif level == xbmc.LOGWARNING:
        Logger.warn(msg)
    elif level == xbmc.LOGDEBUG:
        Logger.debug(msg)
    else:
        Logger.info(msg)


def _val_error(msg: str):
    xbmcgui.Dialog().ok(TITLE, msg)


def _exists(path: str) -> bool:
    try:
        if xbmcvfs.exists(path):
            return True
        fs = xbmcvfs.translatePath(path)
        return bool(fs) and os.path.exists(fs)
    except Exception:
        return False


def _ensure_dir(special_dir: str):
    try:
        if not xbmcvfs.exists(special_dir):
            xbmcvfs.mkdirs(special_dir)
    except Exception:
        fs = xbmcvfs.translatePath(special_dir)
        if fs and not os.path.exists(fs):
            os.makedirs(fs, exist_ok=True)


def _read_text(path: str) -> str:
    try:
        f = xbmcvfs.File(path, "r")
        data = f.read()
        f.close()
        return data
    except Exception:
        return ""


def _write_text(path: str, data: str):
    fs_path = xbmcvfs.translatePath(path)
    parent = os.path.dirname(fs_path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    f = xbmcvfs.File(path, "w")
    f.write(data)
    f.close()


def _cachebust(url: str) -> str:
    sep = '&' if '?' in url else '?'
    return "%s%sts=%d" % (url, sep, random.randrange(1_000_000_000))


def _is_valid_url(u: str) -> bool:
    try:
        return isinstance(u, str) and u.lower().startswith(("http://", "https://")) and "://" in u and len(u.split("://", 1)[1]) > 0
    except Exception:
        return False


def _hostname_from_url(url: str) -> str:
    try:
        return urlparse(url).hostname or url
    except Exception:
        return url or "—"


def _hostname_from_filename(filename: str) -> str:
    if filename and filename.lower().endswith(".json"):
        return filename[:-5]
    return filename or "—"


def _days_left(exp_str: str):
    if not exp_str:
        return None
    try:
        exp_date = datetime.datetime.strptime(exp_str, "%Y-%m-%d").date()
        return (exp_date - datetime.date.today()).days
    except Exception:
        return None


def _exp_display(exp_str: str) -> str:
    days = _days_left(exp_str)
    if days is None:
        return "[COLOR grey]kein Datum[/COLOR]"
    try:
        dt = datetime.datetime.strptime(exp_str, "%Y-%m-%d")
        readable = dt.strftime("%d.%m.%Y")
    except Exception:
        readable = exp_str

    if days > 60:
        color = "lime"
    elif days > 30:
        color = "orange"
    else:
        color = "red"
    return "[COLOR %s]bis %s[/COLOR]" % (color, readable)


def _mac_desc(mac: str, exp_str: str) -> str:
    return "%s  %s" % (mac, _exp_display(exp_str)) if exp_str else "%s  [COLOR grey]kein Datum[/COLOR]" % mac



# -----------------------------
# Local switcher helpers
# -----------------------------
def _resolve_portal_dir() -> Optional[str]:
    for p in PORTAL_DIR_CANDIDATES:
        if _exists(p):
            _log("Lokaler Portal-Ordner gefunden: %s" % p)
            return p
    return None


def _valid_macs(cfg) -> List[Dict[str, str]]:
    today = datetime.date.today()
    out = []
    for m in cfg.get("macs", []):
        if isinstance(m, dict):
            mac = (m.get("mac") or "").strip()
            exp = (m.get("exp") or "").strip()
            if not mac or not _MAC_RE.match(mac):
                continue
            if exp:
                try:
                    if datetime.datetime.strptime(exp, "%Y-%m-%d").date() < today:
                        continue
                except Exception:
                    pass
            out.append({"mac": mac, "exp": exp})
        elif isinstance(m, str):
            s = m.strip()
            if s and _MAC_RE.match(s):
                out.append({"mac": s, "exp": ""})
    return out


def _load_local_cfg(portal_dir: str, filename: str):
    try:
        raw = _read_text("%s/%s" % (portal_dir, filename))
        cfg = json.loads(raw)
        url = (cfg.get("portal") or "").strip()
        if not url:
            return None, "Feld 'portal' fehlt"
        macs = _valid_macs(cfg)
        if not macs:
            return None, "Keine gültigen oder nicht abgelaufenen MACs"
        cfg["_portal"] = url
        cfg["_macs"] = macs
        cfg["_hostname"] = _hostname_from_url(url)
        return cfg, None
    except Exception as e:
        return None, str(e)


def _load_all_local_cfgs(portal_dir: str):
    try:
        _dirs, files = xbmcvfs.listdir(portal_dir)
    except Exception:
        return [], [], []
    files = sorted(f for f in files if f.lower().endswith(".json"))
    labels = []
    cfgs = []
    for fn in files:
        cfg, err = _load_local_cfg(portal_dir, fn)
        hostname = _hostname_from_filename(fn)
        if cfg:
            labels.append("%s  [COLOR grey](%d MACs)[/COLOR]" % (hostname, len(cfg["_macs"])))
            cfgs.append(cfg)
        else:
            labels.append("[COLOR orange]%s – %s[/COLOR]" % (hostname, err))
            cfgs.append(None)
    return files, labels, cfgs


def _save_local_token(selected_file: Optional[str], selected_portal_url: Optional[str], selected_mac: Optional[str], selected_mac_exp: Optional[str] = None):
    try:
        _ensure_dir(LOCAL_TOKEN_DIR)
        _write_text(
            LOCAL_TOKEN_PATH,
            json.dumps({
                "selected_file": selected_file or "",
                "selected_portal_url": selected_portal_url or "",
                "selected_mac": selected_mac or "",
                "selected_mac_exp": selected_mac_exp or "",
            }, indent=2),
        )
    except Exception as e:
        _log("Konnte lokalen Token nicht speichern: %s" % e, xbmc.LOGWARNING)


def _load_local_token(portal_dir: Optional[str]):
    if not portal_dir or not _exists(LOCAL_TOKEN_PATH):
        return None
    try:
        data = json.loads(_read_text(LOCAL_TOKEN_PATH) or "{}")
        sf = (data.get("selected_file") or "").strip()
        sm = (data.get("selected_mac") or "").strip()
        sme = (data.get("selected_mac_exp") or "").strip()
        if not sf:
            return None
        cfg, _ = _load_local_cfg(portal_dir, sf)
        if not cfg:
            return None
        return {
            "selected_file": sf,
            "selected_portal_url": cfg["_portal"],
            "selected_mac": sm or None,
            "selected_mac_exp": sme or None,
            "cfg": cfg,
        }
    except Exception:
        return None


# -----------------------------
# Settings / state helpers
# -----------------------------
def _persist_userdata_settings_xml(values: Dict[str, str]):
    """Persist selected values in Kodi's per-addon userdata settings.xml."""
    settings_dir = "special://profile/addon_data/%s" % STALKER_ID
    settings_path = "%s/settings.xml" % settings_dir
    tmp_path = "%s/settings.xml.tmp" % settings_dir
    try:
        if not xbmcvfs.exists(settings_dir):
            xbmcvfs.mkdirs(settings_dir)

        root = None
        if xbmcvfs.exists(settings_path):
            fh = xbmcvfs.File(settings_path)
            try:
                raw = fh.read() or ''
            finally:
                fh.close()
            if raw.strip():
                try:
                    root = ET.fromstring(raw)
                except Exception:
                    root = None
        if root is None or root.tag != 'settings':
            root = ET.Element('settings', {'version': '2'})
        elif 'version' not in root.attrib:
            root.set('version', '2')

        by_id = {node.get('id'): node for node in root.findall('setting') if node.get('id')}
        for setting_id, value in values.items():
            node = by_id.get(setting_id)
            if node is None:
                node = ET.SubElement(root, 'setting', {'id': setting_id})
                by_id[setting_id] = node
            node.text = value or ''

        payload = ET.tostring(root, encoding='utf-8', xml_declaration=True).decode('utf-8')
        fh = xbmcvfs.File(tmp_path, 'w')
        try:
            fh.write(payload)
        finally:
            fh.close()
        if xbmcvfs.exists(settings_path):
            xbmcvfs.delete(settings_path)
        if not xbmcvfs.rename(tmp_path, settings_path):
            raise IOError('settings.xml could not be replaced')
        return True
    except Exception as exc:
        _log("userdata settings.xml could not be written: {}".format(exc), xbmc.LOGERROR)
        try:
            if xbmcvfs.exists(tmp_path):
                xbmcvfs.delete(tmp_path)
        except Exception:
            pass
        return False


def _persist_settings(server_url: Optional[str] = None, mac: Optional[str] = None):
    """Write portal/MAC through Kodi and persist them in userdata settings.xml."""
    try:
        addon = xbmcaddon.Addon(id=STALKER_ID)
        disk_values = {}
        if server_url is not None:
            server_url = (server_url or '').strip()
            setter = getattr(addon, 'setSettingString', None)
            if callable(setter):
                setter('server_address', server_url)
            else:
                addon.setSetting('server_address', server_url)
            disk_values['server_address'] = server_url
        if mac is not None:
            mac = (mac or '').strip().upper()
            setter = getattr(addon, 'setSettingString', None)
            if callable(setter):
                setter('mac_address', mac)
            else:
                addon.setSetting('mac_address', mac)
            disk_values['mac_address'] = mac

        disk_ok = _persist_userdata_settings_xml(disk_values) if disk_values else True
        xbmc.sleep(150)
        fresh = xbmcaddon.Addon(id=STALKER_ID)
        stored_server = fresh.getSetting('server_address')
        stored_mac = fresh.getSetting('mac_address')
        api_ok = ((server_url is None or stored_server == server_url) and
                  (mac is None or stored_mac.upper() == mac.upper()))
        ok = api_ok and disk_ok
        if ok:
            _log("Portal/MAC settings saved permanently: server={} mac={}".format(
                stored_server, (stored_mac[:8] + '**:**:' + stored_mac[-2:]) if len(stored_mac) >= 12 else stored_mac))
        else:
            _log("Portal/MAC persistence failed: api_ok={} disk_ok={} server={!r} mac={!r}".format(
                api_ok, disk_ok, stored_server, stored_mac), xbmc.LOGERROR)
        return ok
    except Exception as exc:
        _log("Portal/MAC settings could not be saved: {}".format(exc), xbmc.LOGERROR)
        return False
