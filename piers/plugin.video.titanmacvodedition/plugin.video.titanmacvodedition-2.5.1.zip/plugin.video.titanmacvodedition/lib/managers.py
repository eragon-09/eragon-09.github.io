"""Small object-oriented façades over the stable functional live-TV helpers.

These classes provide clear extension points without forcing risky rewrites of
working portal, EPG, favourites, and zapper code.
"""
from __future__ import absolute_import, unicode_literals

from .cache import runtime_cache
from .live_epg import compact_now_label, extract_now_next, resolve_channel_ids
from .live_items import (clear_logo_cache, create_live_channel_item,
                         numbered_channel_label, resolve_channel_logo)
from .services import ChannelService, FavoriteService, PortalService


class EPGManager:
    """Resolve identifiers and format current-programme information."""

    @staticmethod
    def channel_ids(channel):
        return resolve_channel_ids(channel)

    @staticmethod
    def split(epg_text):
        return extract_now_next(epg_text)

    @staticmethod
    def compact_label(channel_name, now_line):
        return compact_now_label(channel_name, now_line)


class LogoManager:
    """Resolve and invalidate process-local live-TV logo choices."""

    @staticmethod
    def resolve(channel=None, saved=None, fallback=''):
        return resolve_channel_logo(channel, saved, fallback)

    @staticmethod
    def clear():
        clear_logo_cache()


class ListItemFactory:
    """Create skin-neutral live-TV list items and primary labels."""

    @staticmethod
    def numbered_label(programme_number, label):
        return numbered_channel_label(programme_number, label)

    @staticmethod
    def live_channel(**kwargs):
        return create_live_channel_item(**kwargs)


class CacheManager:
    """Application façade for the shared process-local runtime cache."""

    @staticmethod
    def get(namespace, key, default=None):
        return runtime_cache.get(namespace, key, default)

    @staticmethod
    def set(namespace, key, value, ttl=None):
        return runtime_cache.set(namespace, key, value, ttl)

    @staticmethod
    def invalidate(namespace, key=None):
        return runtime_cache.invalidate(namespace, key)

    @staticmethod
    def clear():
        runtime_cache.clear()
