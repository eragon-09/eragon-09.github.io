# -*- coding: utf-8 -*-
"""Shared, Kodi-independent file helpers.

The helpers deliberately avoid importing Kodi modules or the add-on logger so
that they can be reused from low-level modules without creating import cycles.
Callers remain responsible for user-facing logging where appropriate.
"""
from __future__ import absolute_import, division, unicode_literals

import json
import os
import re
import tempfile


def ensure_directory(path):
    """Create *path* when necessary and return it unchanged."""
    if path and not os.path.exists(path):
        os.makedirs(path, exist_ok=True)
    return path


def read_json(path, default=None):
    """Read UTF-8 JSON, returning *default* for missing or invalid files."""
    if not path or not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except (OSError, ValueError, TypeError):
        return default


def atomic_write_json(path, value, indent=2, sort_keys=False, prefix='.json_'):
    """Atomically write UTF-8 JSON and return ``True`` on success."""
    if not path:
        return False
    directory = os.path.dirname(path)
    ensure_directory(directory)
    fd, temp_path = tempfile.mkstemp(prefix=prefix, suffix='.tmp', dir=directory or None)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(value, handle, ensure_ascii=False, indent=indent,
                      sort_keys=sort_keys)
        os.replace(temp_path, path)
        return True
    except Exception:
        try:
            os.close(fd)
        except Exception:
            pass
        try:
            os.unlink(temp_path)
        except Exception:
            pass
        return False


def read_text(path, default='', encoding='utf-8'):
    """Read a text file and return *default* if it cannot be read."""
    if not path or not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding=encoding) as handle:
            return handle.read()
    except OSError:
        return default


def atomic_write_text(path, value, encoding='utf-8', prefix='.text_'):
    """Atomically write text and return ``True`` on success."""
    if not path:
        return False
    directory = os.path.dirname(path)
    ensure_directory(directory)
    fd, temp_path = tempfile.mkstemp(prefix=prefix, suffix='.tmp', dir=directory or None)
    try:
        with os.fdopen(fd, 'w', encoding=encoding) as handle:
            handle.write(value)
        os.replace(temp_path, path)
        return True
    except Exception:
        try:
            os.close(fd)
        except Exception:
            pass
        try:
            os.unlink(temp_path)
        except Exception:
            pass
        return False


def safe_filename(value, fallback='item'):
    """Return a portable filename fragment without changing display labels."""
    name = str(value or '').strip()
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', '_', name)
    name = re.sub(r'\s+', ' ', name).strip(' ._')
    return name or fallback
