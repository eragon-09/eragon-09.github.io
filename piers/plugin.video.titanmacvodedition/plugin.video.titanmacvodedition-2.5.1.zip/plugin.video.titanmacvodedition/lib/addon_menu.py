"""Split portion of the Kodi add-on controller.

Kept as a class named StalkerAddon so Python private-name mangling remains
compatible with the original monolithic implementation.
"""
from __future__ import absolute_import, division, unicode_literals
from .addon_shared import *


class StalkerAddon:
    def __search_tv(self, params):
        """Real Kodi folder hierarchy so Back returns to the selected search scope."""
        scope = str(params.get('search_scope') or '')
        scopes = (('all', 'ALLE SENDER'), ('countries', 'MEINE LÄNDER'),
                  ('adult', 'EROTIK / ADULT'))
        if scope not in dict(scopes):
            # A directory rather than a modal select: Kodi can preserve its
            # navigation stack when entering a search and leaving its results.
            xbmcplugin.setContent(G.get_handle(), 'files')
            for key, title in scopes:
                item = xbmcgui.ListItem(label=title)
                url = G.get_plugin_url({'action': 'tv_search_scope', 'search_scope': key})
                xbmcplugin.addDirectoryItem(G.get_handle(), url, item, True)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True,
                                      updateListing=False, cacheToDisc=False)
            return
        self.__search_tv_scope(params)

    def __search_tv_scope(self, params):
        """Intermediate folder stays on Kodi's Back stack beneath the results."""
        scope = str(params.get('search_scope') or '')
        if scope not in ('all', 'countries', 'adult'):
            self.__search_tv({})
            return
        if scope == 'adult' and not self.__require_pin():
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False,
                                      updateListing=False, cacheToDisc=False)
            return
        xbmcplugin.setContent(G.get_handle(), 'files')
        item = xbmcgui.ListItem(label='Sender suchen')
        url = G.get_plugin_url({'action': 'tv_search_results', 'search_scope': scope})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True,
                                  updateListing=False, cacheToDisc=False)

    def __search_tv_results(self, params):
        """Search results are a child of the chosen scope, not of TV-SUCHE."""
        scope = str(params.get('search_scope') or '')
        if scope not in ('all', 'countries', 'adult'):
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False,
                                      updateListing=False, cacheToDisc=False)
            return
        # Session-only last query, not a persisted search history.
        window = xbmcgui.Window(10000)
        prop = 'TitanMacVOD.TVSearch.{}'.format(scope)
        previous = window.getProperty(prop) or ''
        query = xbmcgui.Dialog().input('Sender suchen', defaultt=previous,
                                       type=xbmcgui.INPUT_ALPHANUM)
        query = str(query or '').strip()
        if not query:
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False,
                                      updateListing=False, cacheToDisc=False)
            return
        window.setProperty(prop, query)
        from .portal_index import load_all_index, build_all_index, get_or_load_groups
        from .tv_search_filter import search
        index = load_all_index(allow_stale=True)
        channels = index.get('channels') or []
        if not channels:
            try:
                result = build_all_index()
                channels = result.get('channels') or []
            except Exception as exc:
                Logger.error('TV search index unavailable: {}'.format(exc))
        if not channels:
            xbmcgui.Dialog().notification('TV-SUCHE', 'Senderkatalog nicht verfügbar',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False,
                                      updateListing=False, cacheToDisc=False)
            return
        groups = index.get('group_list') or []
        if not groups:
            try:
                groups, _ = get_or_load_groups()
            except Exception:
                groups = []
        group_lookup = {str(g.get('id')): str(g.get('title') or g.get('name') or '')
                        for g in groups if isinstance(g, dict)}
        addon = xbmcaddon.Addon() if xbmcaddon else None
        tokens = get_configured_country_tokens(addon)
        matches = search(channels, query, scope, tokens, group_lookup)
        params.update({'action': 'tv_listing', 'update_listing': False, 'page': 1,
                       'category': {'all': 'ALLE SENDER', 'countries': 'MEINE LÄNDER',
                                    'adult': 'EROTIK / ADULT'}[scope],
                       'search_term': query, 'search_scope': scope, 'local_index': 0})
        self.__create_tv_listing({'data': matches, 'total_items': len(matches),
                                  'max_page_items': max(1, len(matches)), 'page': 1}, params)
        if not matches:
            xbmcgui.Dialog().notification('TV-SUCHE',
                                          'Keine passenden Sender für: ' + query,
                                          xbmcgui.NOTIFICATION_INFO, 3500)

    @staticmethod
    def __list_main_menu():
        """List main menu"""
        media = xbmcaddon.Addon().getAddonInfo('path')
        media = os.path.join(media, 'resources', 'media')

        # Hauptmenü in gewünschter Reihenfolge
        list_item = xbmcgui.ListItem(label='[B][COLOR FFFFC107]TiTan[/COLOR] [COLOR FFFF4500]TV[/COLOR][/B]')
        list_item.setArt({'icon': os.path.join(media, 'tv.png'), 'thumb': os.path.join(media, 'tv.png'), 'poster': os.path.join(media, 'tv.png'), 'fanart': os.path.join(media, 'fanart.jpg')})
        url = G.get_plugin_url({'action': 'tv', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='[B][COLOR FFFFC107]TiTan[/COLOR] [COLOR FFFF4500]VoD[/COLOR][/B]')
        list_item.setArt({'icon': os.path.join(media, 'vod.png'), 'thumb': os.path.join(media, 'vod.png'), 'poster': os.path.join(media, 'vod.png'), 'fanart': os.path.join(media, 'fanart.jpg')})
        url = G.get_plugin_url({'action': 'vod', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Always display Series; do not query the portal while rendering root.
        list_item = xbmcgui.ListItem(label='[B][COLOR FFFFC107]TiTan[/COLOR] [COLOR FFFF4500]Serien[/COLOR][/B]')
        series_art = os.path.join(media, 'serien.png')
        list_item.setArt({'icon': series_art, 'thumb': series_art, 'poster': series_art, 'fanart': os.path.join(media, 'fanart.jpg')})
        url = G.get_plugin_url({'action': 'series', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='[COLOR FF32CD32]Portal wählen[/COLOR]')
        list_item.setArt({'icon': os.path.join(media, 'server.png'), 'thumb': os.path.join(media, 'server.png'), 'poster': os.path.join(media, 'server.png'), 'fanart': os.path.join(media, 'fanart.jpg')})
        url = G.get_plugin_url({'action': 'choose_server'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        # Resolve the MAC expiry directly from the managed portal JSON every
        # time the root directory is built. A Kodi skin change can recreate
        # the plugin container without restarting the background service or
        # preserving module globals, so cached selected_mac_exp values are not
        # authoritative here.
        mac_val = (G.portal_config.mac_cookie or '').replace('mac=', '').strip().upper()
        mac_expiry_label = ''
        if mac_val:
            try:
                from . import portal_manager as pm
                addon_settings = xbmcaddon.Addon(id='plugin.video.titanmacvodedition')
                configured_url = pm.normalize_portal_url(
                    addon_settings.getSetting('server_address') or G.portal_config.portal_url or '')
                configured_mac = (addon_settings.getSetting('mac_address') or mac_val).strip().upper()
                portals = pm.load_portals()
                portal = next((entry for entry in portals
                               if pm.normalize_portal_url(entry.get('portal', '')) == configured_url), None)
                if portal:
                    lookup_mac = configured_mac or str(portal.get('active_mac') or '').strip().upper()
                    mac_entry = next((entry for entry in portal.get('macs', [])
                                      if str(entry.get('mac') or '').strip().upper() == lookup_mac), None)
                    # Settings and portal active_mac can briefly differ during a
                    # Kodi UI reload. Fall back to the JSON active MAC, but never
                    # to an unrelated MAC entry.
                    if mac_entry is None and portal.get('active_mac'):
                        lookup_mac = str(portal.get('active_mac') or '').strip().upper()
                        mac_entry = next((entry for entry in portal.get('macs', [])
                                          if str(entry.get('mac') or '').strip().upper() == lookup_mac), None)
                    if mac_entry:
                        raw_exp = pm._mac_exp(mac_entry)
                        mac_val = str(mac_entry.get('mac') or mac_val).strip().upper()
                        mac_expiry_label = pm.expiry_label(raw_exp)
            except Exception as exc:
                Logger.warn('Root MAC expiry reload failed: {}'.format(exc))

        if mac_val:
            mac_label = '[COLOR FF32CD32]MAC wählen[/COLOR]'
            if mac_expiry_label:
                mac_label += '  {}'.format(mac_expiry_label)
        else:
            mac_label = '[COLOR FFFF6600]MAC wählen  ⚠ keine MAC gesetzt![/COLOR]'
        list_item = xbmcgui.ListItem(label=mac_label)
        try:
            list_item.setLabel2(mac_expiry_label or '')
        except Exception:
            pass
        list_item.setProperty('TitanMacVOD.Mac', mac_val or '')
        list_item.setProperty('TitanMacVOD.Expiry', mac_expiry_label or '')
        list_item.setArt({'icon': os.path.join(media, 'mac.png'), 'thumb': os.path.join(media, 'mac.png'), 'poster': os.path.join(media, 'mac.png'), 'fanart': os.path.join(media, 'fanart.jpg')})
        url = G.get_plugin_url({'action': 'choose_mac'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        list_item = xbmcgui.ListItem(label='[COLOR FF32CD32]Liste in PVR Laden[/COLOR]')
        list_item.setArt({'icon': os.path.join(media, 'pvr.png'), 'thumb': os.path.join(media, 'pvr.png'), 'poster': os.path.join(media, 'pvr.png'), 'fanart': os.path.join(media, 'fanart.jpg')})
        url = G.get_plugin_url({'action': 'apply_pvr'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        list_item = xbmcgui.ListItem(label='[COLOR FFA9A9A9]Cache löschen[/COLOR]')
        list_item.setArt({'icon': os.path.join(media, 'cache.png'), 'thumb': os.path.join(media, 'cache.png'), 'poster': os.path.join(media, 'cache.png'), 'fanart': os.path.join(media, 'fanart.jpg')})
        url = G.get_plugin_url({'action': 'clear_cache'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        list_item = xbmcgui.ListItem(label='[COLOR FFA9A9A9]Einstellungen[/COLOR]')
        list_item.setArt({'icon': os.path.join(media, 'settings.png'), 'thumb': os.path.join(media, 'settings.png'), 'poster': os.path.join(media, 'settings.png'), 'fanart': os.path.join(media, 'fanart.jpg')})
        url = G.get_plugin_url({'action': 'open_settings'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    def __handle_pc_disable(self):
        try:
            if not xbmcaddon:
                return
            _addon = xbmcaddon.Addon()
            try:
                stored_pin = _addon.getSettingString('pin')
            except Exception:
                stored_pin = _addon.getSetting('pin')
            stored_pin = (stored_pin or '').strip()
            entered = xbmcgui.Dialog().numeric(
                0,
                _addon.getLocalizedString(32020) or 'Enter current PIN to disable parental control'
            )
            if (entered or '').strip() == stored_pin:
                try:
                    _addon.setSettingBool('parental_control_enabled', False)
                except Exception:
                    _addon.setSetting('parental_control_enabled', 'false')
                xbmcgui.Dialog().notification(
                    'Info',
                    _addon.getLocalizedString(32035) or 'Parental control disabled',
                    xbmcgui.NOTIFICATION_INFO,
                    2000
                )
            else:
                xbmcgui.Dialog().notification(
                    'PIN',
                    _addon.getLocalizedString(32021) or 'Wrong PIN',
                    xbmcgui.NOTIFICATION_ERROR,
                    3000
                )
        except Exception as e:
            Logger.error('pc_disable error: {}'.format(e))

    def __handle_pin_change(self):
        try:
            if not xbmcaddon:
                return
            _addon = xbmcaddon.Addon()
            new1 = xbmcgui.Dialog().numeric(
                0,
                _addon.getLocalizedString(32032) or 'Enter new PIN'
            )
            new2 = xbmcgui.Dialog().numeric(
                0,
                _addon.getLocalizedString(32033) or 'Confirm new PIN'
            )
            if (new1 or '').strip() != (new2 or '').strip():
                xbmcgui.Dialog().notification(
                    'PIN',
                    _addon.getLocalizedString(32034) or 'PINs do not match',
                    xbmcgui.NOTIFICATION_ERROR,
                    3000
                )
                return
            try:
                _addon.setSettingString('pin', (new1 or '').strip())
            except Exception:
                _addon.setSetting('pin', (new1 or '').strip())
            xbmcgui.Dialog().notification(
                'PIN',
                _addon.getLocalizedString(32023) or 'PIN successfully changed',
                xbmcgui.NOTIFICATION_INFO,
                2000
            )
        except Exception as e:
            Logger.error('pin_change error: {}'.format(e))

    def __handle_pc_enable(self):
        try:
            if not xbmcaddon:
                return
            _addon = xbmcaddon.Addon()
            try:
                _addon.setSettingBool('parental_control_enabled', True)
            except Exception:
                _addon.setSetting('parental_control_enabled', 'true')
            xbmcgui.Dialog().notification(
                'Info',
                _addon.getLocalizedString(32036) or 'Parental control enabled',
                xbmcgui.NOTIFICATION_INFO,
                2000
            )
        except Exception as e:
            Logger.error('pc_enable error: {}'.format(e))

    def __handle_epg_refresh(self):
        try:
            clear_epg_cache()
            _reset_epg_dictionary()
            try:
                get_epg_data()
            except Exception:
                pass
            xbmcgui.Dialog().notification(
                'EPG', 'EPG aktualisiert', xbmcgui.NOTIFICATION_INFO, 2000)
            try:
                xbmc.executebuiltin('Action(Back)')
            except Exception:
                pass
            xbmc.executebuiltin('Container.Refresh')
        except Exception as exc:
            Logger.error('epg_refresh error: {}'.format(exc))

    @staticmethod
    def __handle_xmltv_refresh():
        """Manual XMLTV reload triggered from settings."""
        clear_xmltv_cache()
        try:
            try:
                from .portal_index import get_cached_channels
                portal_channels = get_cached_channels()
            except Exception:
                portal_channels = []
            result = maintenance.run_xmltv_refresh(portal_channels=portal_channels, force=True)
            if not result:
                raise RuntimeError('Keine passenden XMLTV-Sender gefunden. Portal-Index prüfen.')
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'XMLTV EPG geladen: {} Sender'.format(len(result)),
                xbmcgui.NOTIFICATION_INFO, 3500)
        except Exception as exc:
            Logger.error('XMLTV refresh failed: {}'.format(exc))
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'XMLTV Fehler: {}'.format(exc),
                xbmcgui.NOTIFICATION_ERROR, 4000)

    @staticmethod
    def __list_local_tv_cache():
        xbmcplugin.setPluginCategory(G.get_handle(), 'Portal-Cache')
        xbmcplugin.setContent(G.get_handle(), 'files')
        inventory = maintenance.portal_cache_inventory()
        for key, label in (('portal_catalog', 'Portal-Senderindex'), ('portal_groups', 'Portal-Gruppen'),
                           ('xmltv_portal', 'XMLTV Portal-Cache'), ('xmltv_source', 'XMLTV Rohquellen-Cache')):
            info = inventory.get(key) or {}
            size_kb = round(float(info.get('size') or 0) / 1024.0, 1)
            age = info.get('age_seconds')
            age_text = '{} Min.'.format(int(age // 60)) if age is not None else 'nicht vorhanden'
            item = xbmcgui.ListItem(label='[B]{}:[/B] {} KiB | {}'.format(label, size_kb, age_text))
            xbmcplugin.addDirectoryItem(G.get_handle(), '', item, False)
        actions = [
            ('[B]Portal-Cache leeren[/B]', 'local_tv_cache_clear'),
            ('[B]Portal- und XMLTV-Cache leeren[/B]', 'local_tv_cache_clear_all'),
            ('[B]Portal-Index neu aufbauen[/B]', 'local_tv_rebuild_index'),
        ]
        for label, action in actions:
            item = xbmcgui.ListItem(label=label)
            xbmcplugin.addDirectoryItem(G.get_handle(), G.get_plugin_url({'action': action}), item, action == 'local_tv_rebuild_index')
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, cacheToDisc=False)

    @staticmethod
    def __export_diagnostics():
        try:
            path = maintenance.create_diagnostic_report()
            xbmcgui.Dialog().ok('Systemdiagnose', 'Diagnosebericht erstellt:', path)
        except Exception as exc:
            Logger.error('Diagnostic export failed: {}'.format(exc))
            StalkerAddon.__notify('Diagnosebericht konnte nicht erstellt werden.', True)

    @staticmethod
    def __list_local_tv_mappings():
        xbmcplugin.setPluginCategory(G.get_handle(), 'Zuordnungen verwalten')
        xbmcplugin.setContent(G.get_handle(), 'files')
        entries = local_tv.mapping_entries()
        for label, action in (('[B]Zuordnungen sichern[/B]', 'local_tv_backup'),
                              ('[B]Zuordnungen wiederherstellen[/B]', 'local_tv_restore'),
                              ('[B]XMLTV-Lernzuordnungen zurücksetzen[/B]', 'xmltv_mapping_reset')):
            item = xbmcgui.ListItem(label=label)
            xbmcplugin.addDirectoryItem(G.get_handle(), G.get_plugin_url({'action': action}), item, False)
        for entry in entries:
            mapped = entry.get('mapped_name') or 'nicht zugeordnet'
            quality = entry.get('quality') or ''
            state = '[COLOR=lime]{}[/COLOR]'.format(mapped) if entry.get('cmd') else '[COLOR=orange]nicht zugeordnet[/COLOR]'
            label = '{}  →  {}{}'.format(entry.get('channel_name', ''), state, ' | ' + quality if quality else '')
            item = xbmcgui.ListItem(label=label)
            item.setInfo('video', {'title': entry.get('channel_name', ''),
                                   'plot': 'Liste: {}\nPortal-Sender: {}\nPortal-ID: {}'.format(
                                       entry.get('group_name', ''), mapped, entry.get('mapped_id', ''))})
            menu = [
                ('Zuordnung ändern', 'RunPlugin({})'.format(G.get_plugin_url({
                    'action': 'local_tv_map', 'group_id': entry.get('group_id', ''),
                    'channel_id': entry.get('channel_id', '')}))),
                ('Zuordnung löschen', 'RunPlugin({})'.format(G.get_plugin_url({
                    'action': 'local_tv_mapping_delete', 'group_id': entry.get('group_id', ''),
                    'channel_id': entry.get('channel_id', '')}))),
            ]
            item.addContextMenuItems(menu)
            xbmcplugin.addDirectoryItem(G.get_handle(), '', item, False)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, cacheToDisc=False)

    @staticmethod
    def __list_local_tv_diagnostics():
        xbmcplugin.setPluginCategory(G.get_handle(), 'Systemdiagnose')
        xbmcplugin.setContent(G.get_handle(), 'files')
        snap = maintenance.diagnostic_snapshot()
        created = snap.get('portal_cache_created') or 0
        age = int(max(0, time.time() - created)) if created else 0
        status = snap.get('status') or {}
        xmltv = status.get('xmltv') or {}
        rows = [
            ('Portal-Sender', str(snap.get('portal_channels', 0))),
            ('Portal-Gruppen', str(snap.get('portal_groups', 0))),
            ('Index-Methode', str(snap.get('portal_cache_method') or 'unbekannt')),
            ('Index-Alter', '{} Minuten{}'.format(age // 60, ' (veraltet)' if snap.get('portal_cache_stale') else '')),
            ('Lokale Senderlisten', str(snap.get('local_groups', 0))),
            ('Lokale Sender', str(snap.get('local_channels', 0))),
            ('Gespeicherte Zuordnungen', str(snap.get('manual_or_saved_mappings', 0))),
            ('Nicht zugeordnet', str(snap.get('unresolved', 0))),
            ('XMLTV-Status', str(xmltv.get('state') or 'noch kein Lauf')),
            ('XMLTV-Sender', str(xmltv.get('channels', 0))),
            ('Letzte XMLTV-Dauer', '{} s'.format(xmltv.get('duration_seconds', 0))),
        ]
        for title, value in rows:
            item = xbmcgui.ListItem(label='[B]{}:[/B] {}'.format(title, value))
            xbmcplugin.addDirectoryItem(G.get_handle(), '', item, False)
        export = xbmcgui.ListItem(label='[B]Diagnosebericht exportieren[/B]')
        xbmcplugin.addDirectoryItem(G.get_handle(), G.get_plugin_url({'action': 'local_tv_diagnostic_export'}), export, False)
        rebuild = xbmcgui.ListItem(label='[B]Senderkatalog jetzt aktualisieren[/B]')
        xbmcplugin.addDirectoryItem(G.get_handle(), G.get_plugin_url({'action': 'local_tv_rebuild_index'}), rebuild, False)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, cacheToDisc=False)

    @staticmethod
    def __local_tv_backup():
        try:
            path = maintenance.create_mapping_backup()
            StalkerAddon.__notify('Zuordnungen wurden gesichert.' if path else 'Keine Zuordnungen zum Sichern gefunden.', not bool(path))
        except Exception as exc:
            Logger.error('Mapping backup failed: {}'.format(exc))
            StalkerAddon.__notify('Sicherung ist fehlgeschlagen.', True)

    @staticmethod
    def __local_tv_restore():
        if not xbmcgui.Dialog().yesno('Zuordnungen wiederherstellen', 'Die aktuellen Senderlisten werden durch die letzte Sicherung ersetzt. Fortfahren?'):
            return
        try:
            ok = maintenance.restore_mapping_backup()
            StalkerAddon.__notify('Zuordnungen wurden wiederhergestellt.' if ok else 'Keine gültige Sicherung gefunden.', not ok)
        except Exception as exc:
            Logger.error('Mapping restore failed: {}'.format(exc))
            StalkerAddon.__notify('Wiederherstellung ist fehlgeschlagen.', True)
