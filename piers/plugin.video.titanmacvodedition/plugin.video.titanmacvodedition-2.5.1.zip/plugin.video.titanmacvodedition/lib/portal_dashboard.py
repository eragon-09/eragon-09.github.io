# -*- coding: utf-8 -*-
"""Pure portal overview, search and filter helpers.

This module deliberately contains no Kodi UI or network calls.  Keeping the
statistics separate makes the Portal Manager easier to test and reduces the
risk of changes affecting playback, authentication or EPG processing.
"""
from __future__ import absolute_import, division, unicode_literals


def _expiry_days(entry, days_left, mac_exp):
    try:
        return days_left(mac_exp(entry))
    except Exception:
        return None


def aggregate(portals, days_left, mac_exp, warning_days=10):
    result = {
        'portals': len(portals or []), 'macs': 0, 'valid': 0, 'urgent': 0,
        'expired': 0, 'unknown': 0, 'flagged': 0, 'automatic': 0,
        'manual': 0,
    }
    for portal in portals or []:
        if portal.get('auto_mac', True):
            result['automatic'] += 1
        else:
            result['manual'] += 1
        for entry in portal.get('macs', []) or []:
            result['macs'] += 1
            status = str(entry.get('status') or '').strip().lower()
            explicitly_bad = any(entry.get(key) is False for key in
                                 ('working', 'works', 'valid', 'stream_ok'))
            if explicitly_bad or status in ('invalid', 'failed', 'offline', 'dead', 'error'):
                result['flagged'] += 1
            days = _expiry_days(entry, days_left, mac_exp)
            if days is None:
                result['unknown'] += 1
            elif days < 0:
                result['expired'] += 1
            else:
                result['valid'] += 1
                if days <= warning_days:
                    result['urgent'] += 1
    return result


def dashboard_text(portals, days_left, mac_exp, warning_days=10):
    stats = aggregate(portals, days_left, mac_exp, warning_days)
    return (
        'Portale: {portals}\n'
        'MAC-Adressen: {macs}\n\n'
        'Gültig: {valid}\n'
        'Bis {warning} Tage: {urgent}\n'
        'Abgelaufen: {expired}\n'
        'Ablauf unbekannt: {unknown}\n'
        'Als fehlerhaft markiert: {flagged}\n\n'
        'MAC-Modus automatisch: {automatic}\n'
        'MAC-Modus manuell: {manual}'
    ).format(warning=warning_days, **stats)


def portal_matches(portal, query='', mode='all', active_url='', days_left=None,
                   mac_exp=None, warning_days=10, normalize_url=None):
    query = (query or '').strip().lower()
    if query:
        haystack = '{} {}'.format(portal.get('name', ''), portal.get('portal', '')).lower()
        if query not in haystack:
            return False

    mode = mode or 'all'
    if mode == 'all':
        return True
    if mode == 'active':
        left = portal.get('portal', '')
        if normalize_url:
            left, active_url = normalize_url(left), normalize_url(active_url)
        return bool(active_url and left == active_url)

    entries = portal.get('macs', []) or []
    values = [_expiry_days(entry, days_left, mac_exp) for entry in entries]
    if mode == 'urgent':
        return any(value is not None and 0 <= value <= warning_days for value in values)
    if mode == 'expired':
        return bool(entries) and all(value is not None and value < 0 for value in values)
    if mode == 'error':
        for entry in entries:
            status = str(entry.get('status') or '').strip().lower()
            if any(entry.get(key) is False for key in ('working', 'works', 'valid', 'stream_ok')):
                return True
            if status in ('invalid', 'failed', 'offline', 'dead', 'error'):
                return True
        return False
    return True


def filter_portals(portals, query='', mode='all', active_url='', days_left=None,
                   mac_exp=None, warning_days=10, normalize_url=None):
    return [portal for portal in portals or [] if portal_matches(
        portal, query=query, mode=mode, active_url=active_url,
        days_left=days_left, mac_exp=mac_exp, warning_days=warning_days,
        normalize_url=normalize_url)]
