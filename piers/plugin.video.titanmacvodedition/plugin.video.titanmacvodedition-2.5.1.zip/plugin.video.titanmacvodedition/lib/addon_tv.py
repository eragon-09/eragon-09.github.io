"""Split portion of the Kodi add-on controller.

Kept as a class named StalkerAddon so Python private-name mangling remains
compatible with the original monolithic implementation.
"""
from __future__ import absolute_import, division, unicode_literals
from .addon_shared import *


class StalkerAddon:
    @staticmethod
    def __is_adult_category(title):
        try:
            t = (title or '').lower()
        except Exception:
            t = ''
        adult_tokens = [
            'adult', 'xxx', 'xxl', '18+', '18 +',
            'erotik', 'erotic', 'porno', 'porn', 'hardcore'
        ]
        return any(tok in t for tok in adult_tokens)

    @staticmethod
    def __require_pin():
        # Returns True if access is allowed (parental control off or correct PIN)
        try:
            if not xbmcaddon:
                return True
            _addon = xbmcaddon.Addon()
            try:
                pc_enabled = _addon.getSettingBool('parental_control_enabled')
            except Exception:
                pc_enabled = _addon.getSetting('parental_control_enabled') in ('true', 'True', '1')
            if not pc_enabled:
                return True
            try:
                stored_pin = _addon.getSettingString('pin')
            except Exception:
                stored_pin = _addon.getSetting('pin')
            stored_pin = (stored_pin or '').strip()
            if not stored_pin:
                xbmcgui.Dialog().ok(
                    _addon.getLocalizedString(32013) or 'Adult section',
                    _addon.getLocalizedString(32014) or 'Enter pin code'
                )
                return False
            entered = xbmcgui.Dialog().numeric(
                0,
                _addon.getLocalizedString(32014) or 'Enter pin code'
            )
            if (entered or '').strip() == stored_pin:
                return True
            xbmcgui.Dialog().notification(
                'PIN',
                _addon.getLocalizedString(32021) or 'Wrong PIN',
                xbmcgui.NOTIFICATION_ERROR,
                3000
            )
            return False
        except Exception as e:
            Logger.error('PIN check failed: {}'.format(e))
            return False

    @staticmethod
    def __toggle_favorites(video_id, add, _type):
        """Remove/add favorites and refresh"""
        Logger.debug('Toggle Favorites video_id={}, add={}, _type={}'.format(video_id, add, _type))
        if add:
            Api.add_favorites(video_id, _type)
        else:
            Api.remove_favorites(video_id, _type)
        xbmc.executebuiltin('Container.Refresh')

    @staticmethod
    def __play_video(params):
        """Resolve and play a VOD movie or series episode safely."""
        Logger.debug('Play video {}'.format(params))
        try:
            stream_url = Api.get_vod_stream_url(
                params.get('video_id'), params.get('series', 0),
                params.get('cmd', ''), params.get('use_cmd', '0'))
        except Exception as exc:
            Logger.error('VOD stream resolution failed: {}'.format(exc))
            stream_url = None
        if not stream_url:
            Logger.error('Could not resolve VOD stream for {}'.format(params.get('title', '')))
            xbmcgui.Dialog().notification(
                'TitanMacVOD', _LSTR(32208) or 'Stream could not be resolved.',
                xbmcgui.NOTIFICATION_ERROR, 4000)
            xbmcplugin.setResolvedUrl(G.get_handle(), False, xbmcgui.ListItem())
            return

        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setProperty('IsPlayable', 'true')
        video_info = play_item.getVideoInfoTag()
        title = str(params.get('title') or '')
        video_info.setTitle(title)
        video_info.setOriginalTitle(title)
        video_info.setMediaType('movie')
        year = get_int_value(params, 'year')
        if year:
            video_info.setYear(year)
        duration = get_int_value(params, 'duration')
        if duration:
            video_info.setDuration(duration)
        poster_url = str(params.get('poster_url') or '').strip()
        if poster_url:
            play_item.setArt({'poster': poster_url, 'thumb': poster_url, 'icon': poster_url})
        episode_no = get_int_value(params, 'series')
        if episode_no > 0:
            video_info.setEpisode(episode_no)
            video_info.setSeason(get_int_value(params, 'season_no'))
            video_info.setMediaType('episode')
            video_info.setTvShowTitle(title)
        xbmcplugin.setResolvedUrl(G.get_handle(), True, listitem=play_item)

    @staticmethod
    def __play_tv(params):
        """Resolve and play exactly one live-TV stream.

        Live TV no longer creates a Kodi video playlist. Channel navigation is
        owned by the add-on's favorites overlay; Kodi receives only the stream
        explicitly selected by the user.
        """
        Logger.debug('Play TV {}'.format(params))
        stream_url = Api.get_tv_stream_url(params)
        if not stream_url:
            Logger.error('Could not resolve stream for {}'.format(params.get('name', '')))
            xbmcplugin.setResolvedUrl(G.get_handle(), False, xbmcgui.ListItem())
            return

        item = xbmcgui.ListItem(path=stream_url)
        item.setProperty('IsPlayable', 'true')
        try:
            info = item.getVideoInfoTag()
            title = params.get('name', '')
            info.setTitle(title)
            info.setOriginalTitle(title)
            info.setDuration(0)
            if params.get('epg_text'):
                info.setPlot(_highlight_epg_plot(params.get('epg_text'), params.get('epg_id')))
        except Exception:
            pass
        if params.get('logo'):
            item.setArt({'icon': params['logo'], 'thumb': params['logo'], 'clearlogo': params['logo']})
        try:
            home = xbmcgui.Window(10000)
            home.setProperty('TitanMacVOD.LivePlayback', '1')
            home.setProperty('TitanMacVOD.PlayingChannelId', str(params.get('epg_id') or ''))
            home.setProperty('TitanMacVOD.PlayingChannelName', str(params.get('name') or ''))
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(G.get_handle(), True, listitem=item)

    @staticmethod
    def __list_tv_genres():
        """List the TV channel genres"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return

        # EPG cache is handled by lib/api.py (TTL + refresh). We only ensure a cache file exists.
        try:
            if not epg_path or not os.path.exists(epg_path):
                get_epg_data()
        except Exception:
            pass



        Logger.debug('List TV Genres')
        xbmcplugin.setPluginCategory(G.get_handle(), 'TiTan TV')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        # Portal-independent, ordered Live-TV lists.
        list_item = xbmcgui.ListItem(label=LOCAL_TV_LISTS_LABEL)
        local_tv_icon = local_tv_art_path(root=True)
        list_item.setArt({'icon': local_tv_icon, 'thumb': local_tv_icon,
                          'poster': local_tv_icon, 'fanart': fanart_path()})
        list_item.addContextMenuItems([
            ('Neue Senderliste erstellen', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_group_create'}))),
            ('Alle Senderlisten exportieren', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_export_all'}))),
            ('Sender synchronisieren', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_sync'}))),
            ('Portal-Index neu erstellen', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_rebuild_index'}))),
            ('Portal-Cache verwalten', 'Container.Update({})'.format(G.get_plugin_url({'action': 'local_tv_cache'}))),
            ('Zuordnungen verwalten', 'Container.Update({})'.format(G.get_plugin_url({'action': 'local_tv_mappings'}))),
            ('Systemdiagnose', 'Container.Update({})'.format(G.get_plugin_url({'action': 'local_tv_diagnostics'}))),
            ('Zuordnungen sichern', 'RunPlugin({})'.format(G.get_plugin_url({'action': 'local_tv_backup'}))),
            ('Zuordnungen wiederherstellen', 'RunPlugin({})'.format(G.get_plugin_url({'action': 'local_tv_restore'}))),
        ])
        url = G.get_plugin_url({'action': 'local_tv_groups'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Filtered portal groups are kept in a separate folder so the TV root stays clear.
        filter_addon = xbmcaddon.Addon() if xbmcaddon else None
        filtered_groups_label = get_country_filter_label(filter_addon, FILTERED_TV_GROUPS_LABEL)
        list_item = xbmcgui.ListItem(label=filtered_groups_label)
        list_item.setArt({'icon': G.get_custom_thumb_path('tv.png'),
                          'thumb': G.get_custom_thumb_path('tv.png'),
                          'fanart': fanart_path()})
        url = G.get_plugin_url({'action': 'tv_country_favorites'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Unfiltered portal groups are available for browsing only. This view is
        # deliberately not used by the local-TV portal index or synchronization.
        list_item = xbmcgui.ListItem(label=ALL_TV_GROUPS_LABEL)
        list_item.setArt({'icon': G.get_custom_thumb_path('tv.png'),
                          'thumb': G.get_custom_thumb_path('tv.png'),
                          'fanart': fanart_path()})
        url = G.get_plugin_url({'action': 'tv_all_groups'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option.
        list_item = xbmcgui.ListItem(label=TV_SEARCH_LABEL)
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png'), 'fanart': fanart_path()})
        url = G.get_plugin_url({'action': 'tv_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    def __list_tv_country_favorites(self):
        """List only portal TV groups allowed by the configured country-group filter."""
        Logger.debug('List TV Country Favorites (DE/AT/CH)')
        filter_addon = xbmcaddon.Addon() if xbmcaddon else None
        xbmcplugin.setPluginCategory(
            G.get_handle(),
            get_country_filter_label(filter_addon, FILTERED_TV_GROUPS_LABEL),
        )
        xbmcplugin.setContent(G.get_handle(), 'videos')

        # This browsing view loads the portal groups live and only applies the
        # configured country filter. Building the full channel index is reserved
        # for "Meine Sender" (or the explicit rebuild action).
        # Read live portal categories, then supplement with the portal/MAC-scoped
        # cache. Never replace a more complete cache with a partial response.
        cached = local_tv.get_cached_portal_groups() or []
        try:
            categories = Api.get_tv_genres() or []
        except Exception as exc:
            Logger.error('Failed to load live TV groups: {}'.format(exc))
            categories = []
        categories = [g for g in categories if isinstance(g, dict)]
        live_count = len(categories)
        cached = [g for g in cached if isinstance(g, dict)]
        def group_key(group):
            group_id = group.get('id')
            if group_id is not None and str(group_id).strip():
                return 'id:' + str(group_id)
            return 'name:' + str(group.get('title') or group.get('name') or '').strip().casefold()

        merged = {group_key(g): g for g in cached}
        merged.update({group_key(g): g for g in categories})
        categories = list(merged.values())
        if categories and len(categories) >= len(cached):
            local_tv.cache_portal_groups(categories)
        tokens = set(get_configured_country_tokens(filter_addon))
        filtered = filter_categories_for_country_groups(categories, tokens=tokens)
        counts = {token: sum(1 for g in filtered if
                  filter_categories_for_country_groups([g], tokens={token}))
                  for token in ('DE', 'AT', 'CH')}
        Logger.info('DACH TV groups: live={}, cached={}, merged={}, filtered={}, '
                    'per_country={}'.format(
                        live_count, len(cached), len(categories), len(filtered), counts))
        # Log metadata only; no portal addresses, credentials or stream URLs.
        if counts.get('DE', 0) < 10:
            Logger.info('DACH diagnostic: DE={} / {} groups; names: {}'.format(
                counts.get('DE', 0), len(categories),
                [{key: str(g[key])[:90] for key in
                  ('title', 'name', 'alias', 'abbr', 'label', 'display_name', 'genre_name')
                  if g.get(key) is not None}
                 for g in categories[:120]]))
        Logger.debug('DACH selected titles: {}'.format(
            [g.get('title') or g.get('name') for g in filtered]))

        for genre in filtered:
            try:
                title = (genre.get('title') or genre.get('name') or genre.get('alias') or genre.get('abbr') or '').strip()
                disp = (title or '').upper()
                list_item = xbmcgui.ListItem(label=disp)
                fav_url = G.get_plugin_url({'action': 'tv_listing', 'category': title, 'category_id': genre['id'], 'page': 1,
                                            'update_listing': False, 'search_term': '', 'fav': 1})
                search_url = G.get_plugin_url({'action': 'tv_search', 'category': title, 'category_id': genre['id'], 'fav': 0})
                list_item.addContextMenuItems([('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
                url = G.get_plugin_url({'action': 'tv_listing', 'category': title, 'category_id': genre['id'], 'page': 1,
                                        'update_listing': False})
                xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
            except Exception as ie:
                Logger.error('Error building list item for genre: {}'.format(ie))

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    def __list_tv_all_groups(self):
        """List every portal TV group without changing the country filter.

        This is a browsing-only view. Local-list synchronization continues to
        use ``filter_categories_for_country_groups`` exclusively.
        """
        Logger.debug('List all portal TV groups (browse only)')
        xbmcplugin.setPluginCategory(G.get_handle(), ALL_TV_GROUPS_LABEL)
        xbmcplugin.setContent(G.get_handle(), 'videos')

        try:
            genres = Api.get_tv_genres()
            local_tv.cache_portal_groups(genres)
        except Exception as exc:
            Logger.error('Failed to get all TV genres: {}'.format(exc))
            genres = []

        for genre in genres or []:
            try:
                title = (genre.get('title') or genre.get('name') or
                         genre.get('alias') or genre.get('abbr') or '').strip()
                if not title:
                    continue
                list_item = xbmcgui.ListItem(label=title.upper())
                list_item.setArt({'icon': G.get_custom_thumb_path('tv.png'),
                                  'thumb': G.get_custom_thumb_path('tv.png'),
                                  'fanart': fanart_path()})
                search_url = G.get_plugin_url({
                    'action': 'tv_search', 'category': title,
                    'category_id': genre.get('id', ''), 'fav': 0,
                })
                list_item.addContextMenuItems([
                    ('TV-SUCHE', 'RunPlugin({}, False)'.format(search_url)),
                ])
                url = G.get_plugin_url({
                    'action': 'tv_listing', 'category': title,
                    'category_id': genre.get('id', ''), 'page': 1,
                    'update_listing': False,
                })
                xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
            except Exception as exc:
                Logger.error('Error building unfiltered TV group: {}'.format(exc))

        xbmcplugin.endOfDirectory(
            G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_vod_country_favorites():
        """List VOD categories that match country group tokens (DE/AT/CH)"""
        Logger.debug('List VOD Country Favorites (DE/AT/CH)')
        country_tokens = get_configured_country_tokens(xbmcaddon.Addon() if xbmcaddon else None)
        country_suffix = ', '.join(country_tokens)
        country_label = '{} ({})'.format(
            _LSTR(32105) or 'VOD - Favoriten dieser Kategorie', country_suffix)
        xbmcplugin.setPluginCategory(G.get_handle(), country_label)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        # Gruppensuche innerhalb der Ländergruppen-Favoriten
        list_item = xbmcgui.ListItem(label='[COLOR FF32CD32]Gruppensuche[/COLOR]')
        url = G.get_plugin_url({'action': 'vod_fav_group_search'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)


        try:
            categories = Api.get_vod_categories()
        except Exception as e:
            Logger.error('Failed to get VOD categories: {}'.format(e))
            categories = []

        tokens = set(get_configured_country_tokens(xbmcaddon.Addon() if xbmcaddon else None))

        filtered = filter_categories_for_country_groups(categories, tokens=tokens)

        for category in filtered:
            try:
                title = (category.get('title') or category.get('name') or category.get('alias') or category.get('abbr') or '').strip()
                disp = (title or '').upper()
                list_item = xbmcgui.ListItem(label=disp)
                url = G.get_plugin_url({
                    'action': 'vod_category_menu', 'category': title,
                    'category_id': category['id']})
                xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
            except Exception as ie:
                Logger.error('Error building list item for category: {}'.format(ie))

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_series_country_favorites():
        """List SERIES categories that match country group tokens (DE/AT/CH)"""
        Logger.debug('List SERIES Country Favorites (DE/AT/CH)')
        country_tokens = get_configured_country_tokens(xbmcaddon.Addon() if xbmcaddon else None)
        country_label = '{} ({})'.format(_LSTR(32106) or 'Serien - Favoriten dieser Kategorie', ', '.join(country_tokens))
        xbmcplugin.setPluginCategory(G.get_handle(), country_label)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        # Gruppensuche innerhalb der Ländergruppen-Favoriten
        list_item = xbmcgui.ListItem(label='[COLOR FF32CD32]Gruppensuche[/COLOR]')
        url = G.get_plugin_url({'action': 'series_fav_group_search'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)


        try:
            categories = Api.get_series_categories()
        except Exception as e:
            Logger.error('Failed to get Series categories: {}'.format(e))
            categories = []

        tokens = set(get_configured_country_tokens(xbmcaddon.Addon() if xbmcaddon else None))

        filtered = filter_categories_for_country_groups(categories, tokens=tokens)

        for category in filtered:
            try:
                title = (category.get('title') or category.get('name') or category.get('alias') or category.get('abbr') or '').strip()
                disp = (title or '').upper()
                list_item = xbmcgui.ListItem(label=disp)
                url = G.get_plugin_url({'action': 'series_category_menu', 'category': title,
                                        'category_id': category['id']})
                xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
            except Exception as ie:
                Logger.error('Error building list item for category: {}'.format(ie))

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_vod_categories():
        """List vod categories"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        Logger.debug('List VOD Categories')
        xbmcplugin.setPluginCategory(G.get_handle(), 'TiTan VOD')
        xbmcplugin.setContent(G.get_handle(), 'videos')

        # VOD-Favoriten der konfigurierten Ländergruppen (standardmäßig DE, AT, CH)
        country_tokens = get_configured_country_tokens(xbmcaddon.Addon() if xbmcaddon else None)
        country_suffix = ', '.join(country_tokens)
        country_label = '{} ({})'.format(
            _LSTR(32105) or 'VOD - Favoriten dieser Kategorie', country_suffix)
        list_item = xbmcgui.ListItem(label=country_label)
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'vod_country_favorites'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='VOD FAVORITES')
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'vod_favorites', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option
        list_item = xbmcgui.ListItem(label='VOD SEARCH')
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png')})
        url = G.get_plugin_url({'action': 'vod_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        categories = Api.get_vod_categories()
        for category in categories:
            list_item = xbmcgui.ListItem(label=category['title'])
            url = G.get_plugin_url({
                'action': 'vod_category_menu',
                'category': category['title'],
                'category_id': category['id']})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_series_categories():
        """List series categories"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        Logger.debug('List Series Categories')
        xbmcplugin.setPluginCategory(G.get_handle(), 'TiTan Serien')
        xbmcplugin.setContent(G.get_handle(), 'videos')

        # Serien - My Favorites (Ländergruppen DE/AT/CH)
        country_tokens = get_configured_country_tokens(xbmcaddon.Addon() if xbmcaddon else None)
        country_label = '{} ({})'.format(_LSTR(32106) or 'Serien - Favoriten dieser Kategorie', ', '.join(country_tokens))
        list_item = xbmcgui.ListItem(label=country_label)
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'series_country_favorites'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='SERIES FAVORITES')
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'series_favorites', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option
        list_item = xbmcgui.ListItem(label='SERIES SEARCH')
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png')})
        url = G.get_plugin_url({'action': 'series_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        categories = Api.get_series_categories()
        for category in categories:
            list_item = xbmcgui.ListItem(label=category['title'])
            url = G.get_plugin_url({'action': 'series_category_menu', 'category': category['title'],
                                    'category_id': category['id']})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_channels(params):
        """List the TV Channels"""
        Logger.debug('List Channels {}'.format(params))
        search_term = params.get('search_term', '')
        page = params['page']
        plugin_category = 'TV - ' + params['category'] if params.get('fav', '0') != '1' else 'TV - ' + params['category'] + ' - FAVORITES'
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        # 'files' prevents Kodi from treating the channel list as an auto-advancing playlist
        xbmcplugin.setContent(G.get_handle(), 'files')
        if str(params.get('local_index', '0')) == '1':
            from .portal_index import get_cached_group_channels, search_channels
            if search_term:
                data = search_channels(search_term, params.get('category_id'))
            else:
                data = get_cached_group_channels(params.get('category_id'))
            videos = {'data': data, 'total_items': len(data),
                      'max_page_items': max(1, len(data)), 'page': 1}
        else:
            videos = Api.get_tv_channels(params['category_id'], page, search_term, params.get('fav', 0))
        StalkerAddon.__create_tv_listing(videos, params)

    @staticmethod
    def __create_tv_listing(videos, params):
        update_listing = str(params.get('update_listing', 'false')).strip().lower() == 'true'
        epg_dict = _get_epg_dictionary()
        channels = []
        directory_items = []
        ctx_key = _build_zap_key(params)

        try:
            page_number = max(1, int(params.get('page', 1)))
        except (TypeError, ValueError):
            page_number = 1
        try:
            page_size = max(1, int(videos.get('max_page_items') or len(videos.get('data', [])) or 1))
        except (TypeError, ValueError):
            page_size = max(1, len(videos.get('data', [])) or 1)
        programme_offset = (page_number - 1) * page_size

        for idx, video in enumerate(videos['data']):
            programme_number = programme_offset + idx + 1
            label = video['name']
            epgid = video['id']

            # Portal groups and local favourite groups share the same EPG
            # resolver, including identifier fallbacks and runtime XMLTV data.
            epgid, epg_text, plot_text, now_line, next_line = _get_channel_epg_bundle(video, epg_dict)

            channels.append(_channel_payload(video, epg_text))

            if video.get('fav', 0) == 1:
                label = label + ' ★'
            # Keep the EPG in Kodi's primary label because several skins do
            # not render Label2 in video directory views. Label2/properties are
            # still populated as supplementary metadata for skins that use it.
            label_main = _build_now_in_label(label, now_line)
            numbered_label = numbered_channel_label(programme_number, label_main)
            now_label2 = _build_now_label2(now_line)
            logo = resolve_channel_logo(video)
            list_item = _create_skin_neutral_live_item(
                label=numbered_label,
                channel_name=video.get('name', ''),
                programme_number=programme_number,
                now_line=now_line,
                next_line=next_line,
                plot_text=plot_text,
                logo=logo,
                playable=True,
            )
            local_url = G.get_plugin_url({
                'action': 'local_tv_add',
                'name': video.get('name', ''),
                'video_id': video.get('id', ''),
                'cmd': video.get('cmd', ''),
                'logo': logo,
                'use_http_tmp_link': video.get('use_http_tmp_link', 0),
                'use_load_balancing': video.get('use_load_balancing', 0),
            })
            list_item.addContextMenuItems([
                ('Zu lokaler Senderliste hinzufügen', 'RunPlugin({}, False)'.format(local_url)),
                ('Favoriten-Zapper öffnen', 'RunPlugin({}, False)'.format(
                    G.get_plugin_url({'action': 'favorite_zapper'}))),
            ])
            url = G.get_plugin_url({
                'action': 'tv_play',
                'idx': str(idx),
                'cmd': video['cmd'],
                'use_http_tmp_link': video.get('use_http_tmp_link', 0),
                'use_load_balancing': video.get('use_load_balancing', 0),
                'name': video['name'],
                'logo': logo,
                'epg_text': epg_text or '',
                'epg_id': str(epgid),
                'ctx': ctx_key,
            })
            directory_items.append((url, list_item, False))

        # Save zap context for Next/Prev channel switching
        if channels:
            _save_zap_context(ctx_key, {
                'category': params.get('category', ''),
                'channels': channels,
            })

        total_items = get_int_value(videos, 'total_items')
        item_count = len(directory_items)
        if total_items > item_count:
            StalkerAddon.__add_navigation_items(params, videos, directory_items)
            item_count = len(directory_items)
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, item_count)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=update_listing, cacheToDisc=False)
