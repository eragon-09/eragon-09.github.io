"""Split portion of the Kodi add-on controller.

Kept as a class named StalkerAddon so Python private-name mangling remains
compatible with the original monolithic implementation.
"""
from __future__ import absolute_import, division, unicode_literals
from .addon_shared import *


class StalkerAddon:
    @staticmethod
    def __portal_required():
        """Show a friendly empty directory instead of calling an unconfigured API."""
        from . import core_entry as default_module
        try:
            G.init_globals()
            default_module._rehydrate_selection_from_settings()
        except Exception as exc:
            Logger.warn('Portal selection reload failed: {}'.format(exc))
        portal = str(G.portal_config.portal_url or '').strip()
        mac = str(G.portal_config.mac_cookie or '').replace('mac=', '').strip()
        if portal and mac:
            return True
        xbmcgui.Dialog().notification(
            'TitanMacVOD',
            'Kein Portal mit MAC eingerichtet. Bitte Portal und MAC wählen.',
            xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(
            G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)
        return False

    def router(self, param_string):
        """Route calls"""
        params = dict(parse_qsl(param_string))
        if params and 'action' in params:
            if params['action'] == 'tv':
                if self.__portal_required():
                    self.__list_tv_genres()
            elif params['action'] == 'local_tv_groups':
                self.__list_local_tv_groups()
            elif params['action'] == 'local_tv_group':
                self.__list_local_tv_group(params)
            elif params['action'] == 'local_tv_add':
                self.__local_tv_add(params)
            elif params['action'] == 'local_tv_group_add_channels':
                self.__local_tv_group_add_channels(params)
            elif params['action'] == 'local_tv_map':
                # The mapping editor is launched through RunPlugin from the
                # context menu. Always finalize that plugin handle, including
                # cancellation and error paths, so Kodi does not wait for its
                # default timeout with a busy spinner.
                try:
                    self.__local_tv_map(params)
                finally:
                    _finish_runplugin_action()
            elif params['action'] == 'local_tv_unmap':
                if local_tv.clear_mapping(params.get('group_id'), params.get('channel_id')):
                    xbmc.executebuiltin('Container.Refresh')
            elif params['action'] == 'local_tv_remove':
                if local_tv.remove_channel(params.get('group_id'), params.get('channel_id')):
                    xbmc.executebuiltin('Container.Refresh')
            elif params['action'] == 'local_tv_move':
                if local_tv.move_channel(params.get('group_id'), params.get('channel_id'), int(params.get('direction', 0))):
                    xbmc.executebuiltin('Container.Refresh')
            elif params['action'] == 'local_tv_template_tv_spielfilm':
                self.__create_tv_spielfilm_template()
            elif params['action'] == 'local_tv_import':
                self.__local_tv_import(params)
            elif params['action'] == 'local_tv_export_group':
                self.__local_tv_export_group(params)
            elif params['action'] == 'local_tv_export_all':
                self.__local_tv_export_all()
            elif params['action'] == 'local_tv_sync_group':
                self.__local_tv_run_sync(False, params.get('group_id'))
            elif params['action'] == 'local_tv_sync':
                self.__local_tv_run_sync(False)
            elif params['action'] == 'local_tv_rebuild_index':
                self.__local_tv_run_sync(True)
            elif params['action'] == 'local_tv_mappings':
                self.__list_local_tv_mappings()
            elif params['action'] == 'local_tv_cache':
                self.__list_local_tv_cache()
            elif params['action'] == 'local_tv_cache_clear':
                maintenance.clear_portal_cache(include_xmltv=False, all_portals=True)
                StalkerAddon.__notify('Portal-Cache wurde geleert.')
                xbmc.executebuiltin('Container.Refresh')
            elif params['action'] == 'local_tv_cache_clear_all':
                maintenance.clear_portal_cache(include_xmltv=True, all_portals=True)
                StalkerAddon.__notify('Portal- und XMLTV-Cache wurden geleert.')
                xbmc.executebuiltin('Container.Refresh')
            elif params['action'] == 'local_tv_diagnostics':
                self.__list_local_tv_diagnostics()
            elif params['action'] == 'local_tv_diagnostic_export':
                self.__export_diagnostics()
            elif params['action'] == 'xmltv_mapping_reset':
                from .xmltv import reset_xmltv_mapping_cache
                reset_xmltv_mapping_cache()
                StalkerAddon.__notify('XMLTV-Lernzuordnungen wurden zurückgesetzt.')
                xbmc.executebuiltin('Container.Refresh')
            elif params['action'] == 'local_tv_backup':
                self.__local_tv_backup()
            elif params['action'] == 'local_tv_restore':
                self.__local_tv_restore()
            elif params['action'] == 'local_tv_mapping_delete':
                if local_tv.clear_mapping(params.get('group_id'), params.get('channel_id')):
                    StalkerAddon.__notify('Zuordnung wurde gelöscht.')
            elif params['action'] == 'local_tv_group_create':
                self.__local_tv_group_action('create', params)
            elif params['action'] == 'local_tv_group_rename':
                self.__local_tv_group_action('rename', params)
            elif params['action'] == 'local_tv_group_delete':
                self.__local_tv_group_action('delete', params)
            elif params['action'] == 'local_tv_group_move':
                self.__local_tv_group_action('move', params)
            elif params['action'] == 'vod':
                if self.__portal_required():
                    self.__list_vod_categories()
            elif params['action'] == 'series':
                if self.__portal_required():
                    self.__list_series_categories()
            elif params['action'] == 'vod_favorites':
                self.__list_vod_favorites(params)
            elif params['action'] == 'series_favorites':
                self.__list_series_favorites(params)
            elif params['action'] == 'tv_favorites':
                self.__list_tv_favorites(params)
            elif params['action'] == 'tv_country_favorites':
                self.__list_tv_country_favorites()
            elif params['action'] == 'tv_all_groups':
                self.__list_tv_all_groups()
            elif params['action'] == 'tv_listing':
                self.__list_channels(params)
            elif params['action'] == 'vod_category_menu':
                self.__list_vod_category_menu(params)
            elif params['action'] == 'vod_listing':
                self.__list_vod(params)
            elif params['action'] == 'vod_genres':
                self.__list_vod_genres(params)
            elif params['action'] == 'vod_genre_listing':
                self.__list_vod_genre(params)
            elif params['action'] == 'vod_years':
                self.__list_vod_years(params)
            elif params['action'] == 'vod_year_listing':
                self.__list_vod_year(params)
            elif params['action'] == 'vod_new':
                self.__list_vod_new(params)
            elif params['action'] == 'series_category_menu':
                self.__list_series_category_menu(params)
            elif params['action'] == 'series_listing':
                self.__list_series(params)
            elif params['action'] == 'series_genres':
                self.__list_series_genres(params)
            elif params['action'] == 'series_genre_listing':
                self.__list_series_genre(params)
            elif params['action'] == 'series_years':
                self.__list_series_years(params)
            elif params['action'] == 'series_year_listing':
                self.__list_series_year(params)
            elif params['action'] == 'series_new':
                self.__list_series_new(params)
            elif params['action'] == 'season_listing':
                self.__list_season(params)
            elif params['action'] == 'sub_folder':
                self.__list_episodes(params)
            elif params['action'] == 'play':
                self.__play_video(params)
            elif params['action'] == 'tv_play':
                self.__play_tv(params)
            elif params['action'] == 'favorite_zapper':
                show_favorite_zapper()
            elif params['action'] == 'vod_search':
                self.__search_vod(params)
            elif params['action'] == 'series_search':
                self.__search_series(params)
            elif params['action'] == 'tv_search':
                self.__search_tv(params)
            elif params['action'] == 'tv_search_scope':
                self.__search_tv_scope(params)
            elif params['action'] == 'tv_search_results':
                self.__search_tv_results(params)
            elif params['action'] == 'vod_country_favorites':
                self.__list_vod_country_favorites()
            elif params['action'] == 'series_country_favorites':
                self.__list_series_country_favorites()
            
            elif params['action'] == 'vod_fav_group_search':
                self.__vod_favorites_group_search(params)
            elif params['action'] == 'series_fav_group_search':
                self.__series_favorites_group_search(params)
            elif params['action'] == 'pc_disable':
                self.__handle_pc_disable()
            elif params['action'] == 'pc_enable':
                self.__handle_pc_enable()
            elif params['action'] == 'pin_change':
                self.__handle_pin_change()
            elif params['action'] == 'epg_refresh':
                self.__handle_epg_refresh()
            elif params['action'] == 'xmltv_refresh':
                self.__handle_xmltv_refresh()
            elif params['action'] == 'open_settings':
                xbmcaddon.Addon().openSettings()
            elif params['action'] == 'remove_fav':
                self.__toggle_favorites(params['video_id'], False, params['_type'])
            elif params['action'] == 'add_fav':
                self.__toggle_favorites(params['video_id'], True, params['_type'])
            elif params['action'] == 'choose_server':

                from . import core_entry as default_module

                default_module.choose_server()

            elif params['action'] == 'choose_mac':

                from . import core_entry as default_module

                default_module.choose_mac()

            elif params['action'] == 'activate_managed_mac':

                from . import core_entry as default_module

                try:
                    default_module.activate_managed_mac_action(
                        params.get('portal', ''), params.get('mac', ''), refresh_home=True)
                finally:
                    _finish_runplugin_action()

            elif params['action'] == 'apply_pvr':

                from . import core_entry as default_module

                default_module.apply_pvr()

            elif params['action'] == 'clear_cache':

                from . import core_entry as default_module

                default_module.manual_clear_cache()

            else:
                raise ValueError('Invalid param string: {}!'.format(param_string))
        else:
            # Always show the main menu, even on a fresh installation.
            # Portal/MAC configuration is only required when opening content.
            from . import core_entry as default_module
            # Import/manual setup or a Kodi skin reload may have recreated
            # the plugin process and cleared module globals. Rebuild the
            # selection from the authoritative *.portal.json on every root
            # request before rendering labels.
            G.init_globals()
            try:
                default_module._rehydrate_selection_from_settings()
            except Exception as exc:
                Logger.warn('Portal selection rehydrate failed: {}'.format(exc))
            self.__list_main_menu()
