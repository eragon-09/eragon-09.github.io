# -*- coding: utf-8 -*-
"""
XMLTV EPG provider for Titan Stalker VOD Client.

Fetches an XMLTV feed (URL or local file), parses it, and converts the
data into the same dict format that the portal EPG uses:

    { channel_id: [ {name, t_time, t_time_to, descr, start_timestamp,
                     stop_timestamp, ...}, ... ] }

The channel_id used as key is the portal channel ID.  Matching between
XMLTV channel names / tvg-ids and portal channel IDs is done via a
configurable mapping (JSON string in settings) plus a fuzzy name fallback.

All existing EPG functions (short_epg_from_dict, get_epg_dict, …) are
unchanged – this module only provides an alternative/additional data source.
"""

from __future__ import absolute_import, division, unicode_literals

import os
import re
import gzip
import json
import time
import threading
from datetime import datetime


from .loggers import Logger
from .xmltv_config import (
    _addon, _diagnostics_path, _learned_mapping_path, _profile_path,
    _read_json, _resource_alias_path, _resource_source_catalog_path,
    _write_json, _xmltv_cache_path, _xmltv_dict_path,
    _xmltv_source_dict_path, __path, __state_path, get_epg_source,
    get_tvg_mapping, get_xmltv_refresh_hours, get_xmltv_url,
    get_xmltv_url2, get_xmltv_urls,
)
from .xmltv_parser import (
    _fetch_xmltv, _parse_xmltv_bytes, _parse_xmltv_time, _ts_to_hhmm,
)

# ---------------------------------------------------------------------------
# Module-level cache
# ---------------------------------------------------------------------------

_xmltv_mem = {}          # parsed XMLTV dict in portal format
_xmltv_loaded_ts = 0
_xmltv_source_repair_ts = 0
_xmltv_source_repair_lock = threading.Lock()
_xmltv_source_mem = {}
_xmltv_source_mtime = 0.0
_xmltv_source_repair_running = False
_xmltv_lock = threading.Lock()
__lock = threading.Lock()

_ADDON_ID = 'plugin.video.titanmacvodedition'


# ---------------------------------------------------------------------------
# Settings helpers
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Channel matching
# ---------------------------------------------------------------------------

_IGNORED_NAME_TOKENS = ('uhd', 'fhd', 'hd', '4k', 'hevc', 'raw', 'fernsehen', 'fs', 'tv')

# Common portal/XMLTV naming differences. Values are canonical names and are
# deliberately quality-independent. User mappings from the settings still
# take priority over these built-ins.
_BUILTIN_ALIASES = {
    'voxup': 'vox up',
    'rtlup': 'rtl up',
    'rtlplus': 'rtl up',
    'n24doku': 'welt doku',
    'weltderwunder': 'welt der wunder',
    'skycinemaclassics': 'sky cinema classics',
    'universalchannel': 'universal',
    '13thstreet': '13th street',
    'heimatkanal': 'heimatkanal',
    'bergbl': 'bergblick',
}


def _all_aliases():
    aliases = dict(_BUILTIN_ALIASES)
    external = _read_json(_resource_alias_path(), {})
    if isinstance(external, dict):
        for key, value in external.items():
            normal_key = _normalise(key)
            if normal_key and value:
                aliases[normal_key] = str(value)
    return aliases


def _source_catalog():
    """Load the bundled official XMLTV IDs and source-specific aliases."""
    data = _read_json(_resource_source_catalog_path(), {})
    if not isinstance(data, dict):
        return {'channels': [], 'aliases': {}}
    channels = data.get('channels') if isinstance(data.get('channels'), list) else []
    aliases = data.get('aliases') if isinstance(data.get('aliases'), dict) else {}
    return {
        'source': str(data.get('source') or ''),
        'source_timestamp': str(data.get('source_timestamp') or ''),
        'channels': [str(value) for value in channels if value],
        'aliases': {str(key): str(value) for key, value in aliases.items() if key and value},
    }


_FAMILY_SOURCE_IDS = {
    'br': 'BR.de',
    'hr': 'HR.de',
    'mdr': 'MDR.de',
    'ndr': 'NDR.de',
    'rbb': 'RBB.de',
    'swr': 'SWR/SR.de',
    'sr': 'SWR/SR.de',
    'wdr': 'WDR.de',
}


def _family_source_id_for_name(value, xmltv_dict):
    """Return the official source ID for German public regional families.

    Portal lists frequently contain several quality/name variants such as
    ``RBB BERLIN FHD``, ``RBB FERNSEHEN HD`` or ``NDR FERNSEHEN`` while the
    epg_ripper_DE1 source exposes a single family ID (for example ``RBB.de``
    or ``NDR.de``).  This deterministic fallback is intentionally applied
    before learned/fuzzy mappings, but never before an explicit user mapping.
    """
    available = set((xmltv_dict or {}).keys())
    normal = _normalise(value)
    if not normal:
        return ''

    # Longest/specific prefixes first. Quality markers and the words TV/
    # Fernsehen have already been removed by _normalise().
    for family in ('rbb', 'ndr', 'mdr', 'swr', 'wdr', 'br', 'hr', 'sr'):
        if normal == family or normal.startswith(family):
            target = _FAMILY_SOURCE_IDS.get(family, '')
            if target in available:
                return target
    return ''


def _source_id_for_name(value, xmltv_dict):
    """Resolve a portal name to an exact ID documented by the EPG source.

    A catalogue result is accepted only when that exact ID is present in the
    currently downloaded XMLTV feed. This prevents stale catalogue entries
    from producing an empty or incorrect programme guide.
    """
    catalog = _source_catalog()
    available = set((xmltv_dict or {}).keys())
    aliases = catalog.get('aliases') or {}
    normalized_aliases = {_normalise(key): target for key, target in aliases.items()}
    for candidate in _name_candidates(value):
        target = normalized_aliases.get(candidate)
        if target in available:
            return target
    # Also match the documented IDs themselves after normalisation. This is
    # useful when a portal uses e.g. "Sky Sport News HD" while XMLTV uses
    # "Sky.Sport.News.de" and the feed has no display-name.
    wanted = set(_name_candidates(value))
    for source_id in catalog.get('channels') or []:
        if source_id in available and wanted.intersection(_name_candidates(source_id)):
            return source_id
    return ''

# Regional suffixes which often exist as separate portal streams but share a
# single programme schedule in XMLTV.
_REGIONAL_SUFFIXES = {
    'koln', 'koeln', 'bielefeld', 'wuppertal', 'duisburg', 'aachen',
    'dusseldorf', 'duesseldorf', 'munster', 'muenster', 'dortmund', 'essen',
    'siegen', 'bonn', 'rheinland', 'ruhr', 'sachsen', 'thuringen',
    'thueringen', 'sachsenanhalt', 'hamburg', 'hannover', 'niedersachsen',
    'mecklenburgvorpommern', 'schleswigholstein', 'bayern', 'nord', 'sud',
    'sued', 'berlin', 'brandenburg', 'badenwurttemberg',
    'badenwuerttemberg', 'rheinlandpfalz', 'bw', 'rp', 'mv', 'sh', 'sn',
}


def _ascii(value):
    try:
        import unicodedata
        return unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    except Exception:
        return value


def _normalise(s):
    """Normalise channel names while ignoring quality and decoration."""
    value = _ascii((s or '').lower()).replace('&', ' und ')
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    tokens = [token for token in value.split() if token not in _IGNORED_NAME_TOKENS]
    return ''.join(tokens)


def _canonical(value):
    """Return a canonical channel key including regional-family handling."""
    normal = _normalise(value)
    if not normal:
        return ''
    normal = _all_aliases().get(normal, normal)
    normal = _normalise(normal)

    # Public regional streams commonly share the parent station's EPG.
    families = ('wdr', 'ndr', 'mdr', 'swr', 'rbb', 'br', 'hr', 'sr')
    for family in families:
        if normal.startswith(family):
            tail = normal[len(family):]
            if not tail or any(tail == suffix or tail.endswith(suffix) for suffix in _REGIONAL_SUFFIXES):
                return family
    return normal


def _name_candidates(value):
    """Return useful ID, exact-name and canonical candidates."""
    result = []
    for raw in (value or '', re.split(r'[.@:_-]', value or '', 1)[0]):
        for candidate in (_normalise(raw), _canonical(raw)):
            if candidate and candidate not in result:
                result.append(candidate)
    return result


def _similarity(left, right):
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    # Prefixes are useful for names such as "Universal" / "Universal Channel",
    # but short families such as RTL/RTL2 must never be guessed.
    if min(len(left), len(right)) >= 6 and (left.startswith(right) or right.startswith(left)):
        return 0.96
    try:
        from difflib import SequenceMatcher
        return SequenceMatcher(None, left, right).ratio()
    except Exception:
        return 0.0


def _build_xmltv_lookup(xmltv_dict, channel_names):
    lookup = {}
    records = []
    for xid, events in (xmltv_dict or {}).items():
        values = [xid] + list(channel_names.get(xid) or [])
        candidates = []
        for value in values:
            for candidate in _name_candidates(value):
                if candidate not in candidates:
                    candidates.append(candidate)
                    lookup.setdefault(candidate, []).append((xid, events))
        records.append((xid, events, candidates))
    return lookup, records


def _match_channels(xmltv_dict, channel_names, portal_channels, user_mapping):
    """Map XMLTV schedules to portal channels and return diagnostics.

    Matching order: explicit user mapping, learned mapping, exact/canonical
    aliases, then a conservative fuzzy fallback. Ambiguous fuzzy matches are
    deliberately rejected instead of risking a wrong programme guide.
    """
    result = {}
    diagnostics = []
    xml_lookup, xml_records = _build_xmltv_lookup(xmltv_dict, channel_names)
    learned = _read_json(_learned_mapping_path(), {})
    if not isinstance(learned, dict):
        learned = {}

    explicit_by_portal = {}
    for key, portal_id in (user_mapping or {}).items():
        explicit_by_portal.setdefault(str(portal_id), []).append(str(key))

    matched_xml_ids = set()
    new_learned = dict(learned)
    for channel in (portal_channels or []):
        channel_id = str(channel.get('id') or '')
        epg_id = str(channel.get('epg_id') or '')
        portal_id = epg_id or channel_id
        portal_name = channel.get('name') or channel.get('title') or ''
        if not portal_id or not portal_name:
            continue

        chosen = None
        method = ''
        score = 0.0
        explicit_keys = []
        for key in (portal_id, channel_id, epg_id):
            if key and key not in explicit_keys:
                explicit_keys.append(key)
        explicit_values = []
        for key in explicit_keys:
            explicit_values.extend(explicit_by_portal.get(key, []))
        for mapped in explicit_values:
            if mapped in xmltv_dict:
                chosen = (mapped, xmltv_dict[mapped]); method = 'manuell'; score = 1.0
                break
            for candidate in _name_candidates(mapped):
                hits = xml_lookup.get(candidate) or []
                if hits:
                    chosen = hits[0]; method = 'manuell'; score = 1.0
                    break
            if chosen:
                break

        portal_candidates = _name_candidates(portal_name)
        learned_key = _canonical(portal_name) or _normalise(portal_name)

        if not chosen:
            family_id = _family_source_id_for_name(portal_name, xmltv_dict)
            if family_id:
                chosen = (family_id, xmltv_dict[family_id])
                method = 'Senderfamilie'
                score = 1.0

        if not chosen and learned_key:
            learned_id = learned.get(learned_key)
            if learned_id in xmltv_dict:
                chosen = (learned_id, xmltv_dict[learned_id]); method = 'gelernt'; score = 1.0

        if not chosen:
            source_id = _source_id_for_name(portal_name, xmltv_dict)
            if source_id:
                chosen = (source_id, xmltv_dict[source_id])
                method = 'Quellen-ID'
                score = 1.0

        if not chosen:
            exact_hits = []
            seen = set()
            for candidate in portal_candidates:
                for hit in xml_lookup.get(candidate) or []:
                    if hit[0] not in seen:
                        seen.add(hit[0]); exact_hits.append(hit)
            if exact_hits:
                chosen = max(exact_hits, key=lambda hit: len(hit[1] or []))
                method = 'alias/exakt'; score = 1.0

        suggestion = None
        if not chosen:
            # Keep two thresholds: a strict threshold for automatic matching and
            # a lower diagnostic threshold which is never applied automatically.
            # This makes missing aliases visible without risking incorrect EPG.
            scored = []
            for xid, events, xml_candidates in xml_records:
                candidate_score = max((_similarity(pc, xc) for pc in portal_candidates for xc in xml_candidates), default=0.0)
                if candidate_score >= 0.65:
                    scored.append((candidate_score, xid, events))
            scored.sort(reverse=True, key=lambda item: item[0])
            if scored:
                suggestion = {
                    'xmltv_id': scored[0][1],
                    'score': round(float(scored[0][0]), 3),
                    'programmes': len(scored[0][2] or []),
                }
            automatic = [item for item in scored if item[0] >= 0.90]
            if automatic and (len(automatic) == 1 or automatic[0][0] - automatic[1][0] >= 0.04):
                score, xid, events = automatic[0]
                chosen = (xid, events); method = 'fuzzy'

        if chosen:
            events = list(chosen[1] or [])
            for result_id in (channel_id, epg_id, portal_id):
                if result_id:
                    result[result_id] = events
            matched_xml_ids.add(chosen[0])
            if learned_key:
                new_learned[learned_key] = chosen[0]
            diagnostics.append({
                'portal_id': portal_id, 'portal_name': portal_name,
                'xmltv_id': chosen[0], 'method': method,
                'score': round(float(score), 3), 'programmes': len(events),
                'matched': True,
            })
        else:
            diagnostics.append({
                'portal_id': portal_id, 'portal_name': portal_name,
                'xmltv_id': '', 'method': 'kein Treffer', 'score': 0.0,
                'programmes': 0, 'matched': False,
                'suggestion_xmltv_id': (suggestion or {}).get('xmltv_id', ''),
                'suggestion_score': (suggestion or {}).get('score', 0.0),
                'suggestion_programmes': (suggestion or {}).get('programmes', 0),
            })

    for portal_id in result:
        result[portal_id].sort(key=lambda event: event.get('start_timestamp') or 0)

    _write_json(_learned_mapping_path(), new_learned)
    Logger.info('XMLTV matched {} portal IDs using {} XMLTV channels ({} available)'.format(
        len(result), len(matched_xml_ids), len(xmltv_dict or {})))
    return result, diagnostics



def _start_source_repair_background():
    """Start one non-blocking XMLTV repair job.

    Channel lists must never wait for a multi-megabyte XMLTV download/parse.
    The service or this background worker repairs the cache while the current
    list continues to open normally.
    """
    global _xmltv_source_repair_ts, _xmltv_source_repair_running
    now = time.time()
    if _xmltv_source_repair_running or now - float(_xmltv_source_repair_ts or 0) < 120:
        return
    if not _xmltv_source_repair_lock.acquire(False):
        return
    _xmltv_source_repair_running = True
    _xmltv_source_repair_ts = now

    def _worker():
        global _xmltv_source_repair_running, _xmltv_source_mem, _xmltv_source_mtime
        try:
            Logger.warn('XMLTV raw source cache is missing or empty; rebuilding in background')
            load_xmltv(force=True)
            path = _xmltv_source_dict_path()
            data = _read_json(path, {})
            if isinstance(data, dict) and data:
                _xmltv_source_mem = data
                try:
                    _xmltv_source_mtime = os.path.getmtime(path)
                except Exception:
                    _xmltv_source_mtime = time.time()
                Logger.info('XMLTV background repair loaded {} channel IDs'.format(len(data)))
            else:
                Logger.warn('XMLTV background repair produced no channel IDs')
        except Exception as exc:
            Logger.error('XMLTV background repair failed: {}'.format(exc))
        finally:
            _xmltv_source_repair_running = False
            try:
                _xmltv_source_repair_lock.release()
            except Exception:
                pass

    thread = threading.Thread(target=_worker, name='TitanXMLTVRepair')
    thread.daemon = True
    thread.start()


def _load_source_epg_dict(auto_repair=False):
    """Load raw XMLTV schedules once per Python process.

    Previously the multi-megabyte JSON file was parsed for every visible
    channel row.  That made channel lists extremely slow.  The dictionary is
    now cached in memory and only reloaded when the file timestamp changes.
    Missing caches are repaired asynchronously so list rendering stays fast.
    """
    global _xmltv_source_mem, _xmltv_source_mtime
    path = _xmltv_source_dict_path()
    try:
        mtime = os.path.getmtime(path) if path and os.path.exists(path) else 0.0
    except Exception:
        mtime = 0.0

    if _xmltv_source_mem and (not mtime or mtime == _xmltv_source_mtime):
        return _xmltv_source_mem

    if mtime:
        data = _read_json(path, {})
        if isinstance(data, dict) and data:
            _xmltv_source_mem = data
            _xmltv_source_mtime = mtime
            Logger.debug('XMLTV raw source cache loaded once ({} channel IDs)'.format(len(data)))
            return _xmltv_source_mem

    if auto_repair and get_xmltv_urls():
        # Never start long-running worker threads from a plugin directory or
        # RunPlugin invocation. Kodi's CPythonInvoker waits for such threads
        # before completing the request, which keeps the Busy dialog visible
        # for minutes. The persistent xbmc.service refreshes XMLTV separately.
        Logger.debug('XMLTV source cache missing; deferred to background service')
    return {}


def _channel_name_and_data(channel):
    if isinstance(channel, dict):
        return (channel.get('name') or channel.get('title') or ''), channel
    return str(channel or ''), {'name': str(channel or '')}


def _append_(record):
    """Append one runtime matching decision as JSONL, with bounded growth."""
    path = __path()
    if not path:
        return
    try:
        with __lock:
            # Rotate at about 8 MiB. The previous run remains available.
            if os.path.exists(path) and os.path.getsize(path) > 8 * 1024 * 1024:
                previous = path + '.previous'
                try:
                    if os.path.exists(previous):
                        os.remove(previous)
                    os.replace(path, previous)
                except Exception:
                    pass
            with open(path, 'a', encoding='utf-8') as handle:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + '\n')
    except Exception as exc:
        Logger.warn('EPG live trace append failed: {}'.format(exc))


def _new_(channel_name, channel_data, source_epg):
    """Build trace metadata without ever affecting EPG matching."""
    try:
        normalization = _normalisation_trace(channel_name)
    except Exception as exc:
        normalization = {
            'original': str(channel_name or ''),
            'trace_error': '{}: {}'.format(type(exc).__name__, exc),
        }
        Logger.warn('EPG live trace normalization failed: {}'.format(exc))
    try:
        safe_channel = {
            str(k): _diagnostic_safe_value(k, v)
            for k, v in (channel_data or {}).items()
        }
    except Exception as exc:
        safe_channel = {'name': str(channel_name or ''),
                        'trace_error': '{}: {}'.format(type(exc).__name__, exc)}
        Logger.warn('EPG live trace channel serialization failed: {}'.format(exc))
    return {
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'channel': safe_channel,
        'name': channel_name,
        'normalization': normalization,
        '': len(source_epg or {}),
        'attempts': [],
        'result': {
            'matched': False, 'xmltv_id': '',
            'method': 'kein Treffer', 'programmes': 0,
        },
    }


def _trace_attempt(trace, attempt):
    """Add diagnostic data defensively; matching must remain independent."""
    try:
        trace.setdefault('attempts', []).append(attempt)
    except Exception as exc:
        Logger.warn('EPG live trace attempt failed: {}'.format(exc))


def resolve_xmltv_channel(channel):
    """Resolve one channel and write the exact runtime decision to Live-Trace.

    Accepts either the complete portal channel dictionary or a plain name. The
    matching order itself remains unchanged; tracing observes the real runtime
    fallback rather than rebuilding a separate diagnostic model later.
    """
    channel_name, channel_data = _channel_name_and_data(channel)
    source_epg = _load_source_epg_dict(auto_repair=True)
    # The trace is observational only. Any trace failure is contained and must
    # never prevent channel listing or EPG matching.
    trace = _new_(channel_name, channel_data, source_epg)
    if not source_epg or not channel_name:
        trace['reason'] = '' if not source_epg else 'Sendername leer'
        _append_(trace)
        return '', [], ''

    family_id = _family_source_id_for_name(channel_name, source_epg)
    _trace_attempt(trace, {
        'stage': 'Senderfamilie', 'matched': bool(family_id),
        'xmltv_id': family_id or '',
        'programmes': len(source_epg.get(family_id) or []) if family_id else 0,
    })
    if family_id and source_epg.get(family_id):
        events = list(source_epg[family_id])
        trace['result'] = {'matched': True, 'xmltv_id': family_id,
                           'method': 'Senderfamilie/Laufzeit', 'programmes': len(events)}
        _append_(trace)
        return family_id, events, 'Senderfamilie/Laufzeit'

    source_id = _source_id_for_name(channel_name, source_epg)
    _trace_attempt(trace, {
        'stage': 'Quellen-ID-Katalog', 'matched': bool(source_id),
        'xmltv_id': source_id or '',
        'programmes': len(source_epg.get(source_id) or []) if source_id else 0,
    })
    if source_id and source_epg.get(source_id):
        events = list(source_epg[source_id])
        trace['result'] = {'matched': True, 'xmltv_id': source_id,
                           'method': 'Quellen-ID/Laufzeit', 'programmes': len(events)}
        _append_(trace)
        return source_id, events, 'Quellen-ID/Laufzeit'

    lookup, records = _build_xmltv_lookup(source_epg, {})
    exact = []
    seen = set()
    candidates = _name_candidates(channel_name)
    for candidate in candidates:
        for hit in lookup.get(candidate) or []:
            if hit[0] not in seen:
                seen.add(hit[0])
                exact.append(hit)
    _trace_attempt(trace, {
        'stage': 'Alias/Exakt', 'inputs': candidates, 'matched': bool(exact),
        'hits': [{'xmltv_id': hit[0], 'programmes': len(hit[1] or [])} for hit in exact[:10]],
    })
    if exact:
        chosen = max(exact, key=lambda hit: len(hit[1] or []))
        events = list(chosen[1] or [])
        trace['result'] = {'matched': True, 'xmltv_id': chosen[0],
                           'method': 'Alias/Exakt/Laufzeit', 'programmes': len(events)}
        _append_(trace)
        return chosen[0], events, 'Alias/Exakt/Laufzeit'

    scored = []
    diagnostic = []
    for xid, events, xml_candidates in records:
        score = max((_similarity(pc, xc) for pc in candidates for xc in xml_candidates), default=0.0)
        if score >= 0.65:
            diagnostic.append((score, xid, events))
        if score >= 0.90:
            scored.append((score, xid, events))
    diagnostic.sort(reverse=True, key=lambda item: item[0])
    scored.sort(reverse=True, key=lambda item: item[0])
    _trace_attempt(trace, {
        'stage': 'Fuzzy',
        'matched': bool(scored and (len(scored) == 1 or scored[0][0] - scored[1][0] >= 0.04)),
        'top_candidates': [
            {'score': round(float(item[0]), 3), 'xmltv_id': item[1],
             'programmes': len(item[2] or [])} for item in diagnostic[:5]
        ],
    })
    if scored and (len(scored) == 1 or scored[0][0] - scored[1][0] >= 0.04):
        events = list(scored[0][2] or [])
        trace['result'] = {'matched': True, 'xmltv_id': scored[0][1],
                           'method': 'Fuzzy/Laufzeit', 'programmes': len(events),
                           'score': round(float(scored[0][0]), 3)}
        _append_(trace)
        return scored[0][1], events, 'Fuzzy/Laufzeit'

    _append_(trace)
    return '', [], ''


def get_runtime_xmltv_events(channel):
    """Return runtime XMLTV events and record the actual matching path."""
    name, _data = _channel_name_and_data(channel)
    xid, events, method = resolve_xmltv_channel(channel)
    if xid and events:
        Logger.debug('XMLTV runtime mapping: {} -> {} ({}, {} programmes)'.format(
            name, xid, method, len(events)))
    return events


def get_live_epg_trace_status():
    path = __path()
    rows = []
    if path and os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                for line in handle:
                    try:
                        rows.append(json.loads(line))
                    except Exception:
                        continue
        except Exception:
            rows = []
    matched = sum(1 for row in rows if (row.get('result') or {}).get('matched'))
    return {'path': path, 'entries': len(rows), 'matched': matched,
            'unmatched': len(rows) - matched, 'rows': rows}


def clear_live_epg_trace():
    removed = False
    for path in (__path(), __path() + '.previous'):
        try:
            if path and os.path.exists(path):
                os.remove(path)
                removed = True
        except Exception:
            pass
    return removed


def export_live_epg_trace():
    """Export collected runtime decisions to readable TXT and JSON files."""
    status = get_live_epg_trace_status()
    rows = status.get('rows') or []
    now = datetime.now()
    stamp = now.strftime('%Y%m%d_%H%M%S')
    txt_path = _profile_path('_{}.txt'.format(stamp))
    json_path = _profile_path('_{}.json'.format(stamp))
    methods = {}
    unique = {}
    for row in rows:
        result = row.get('result') or {}
        method = result.get('method') or 'kein Treffer'
        methods[method] = methods.get(method, 0) + 1
        key = '{}|{}'.format(row.get('name') or '', (row.get('channel') or {}).get('id') or '')
        unique[key] = row
    payload = {
        'report_type': 'Titan Live EPG Trace',
        'generated': now.strftime('%Y-%m-%d %H:%M:%S'),
        'summary': {'entries': len(rows), 'unique_channels': len(unique),
                    'matched': status.get('matched') or 0,
                    'unmatched': status.get('unmatched') or 0,
                    'mapping_methods': methods},
        'entries': rows,
    }
    lines = [
        'Titan Portal MAC VOD Edition – ',
        'Erstellt: {}'.format(payload['generated']),
        'Laufzeitentscheidungen: {}'.format(len(rows)),
        'Eindeutige Sender: {}'.format(len(unique)),
        'Treffer: {}'.format(status.get('matched') or 0),
        'Ohne Treffer: {}'.format(status.get('unmatched') or 0),
        'Zuordnungswege: {}'.format(', '.join('{}={}'.format(k, methods[k]) for k in sorted(methods)) or 'keine'),
        'Rohdatei: {}'.format(status.get('path') or ''), '',
    ]
    for row in rows:
        result = row.get('result') or {}
        channel_data = row.get('channel') or {}
        lines.extend([
            '=' * 78,
            'Zeit: {}'.format(row.get('timestamp') or ''),
            'Sender: {}'.format(row.get('name') or 'unbekannt'),
            'Portal-ID: {}'.format(channel_data.get('id') or channel_data.get('ch_id') or 'leer'),
            'Portal-EPG-ID: {}'.format(channel_data.get('epg_id') or 'leer'),
            'Portal-XMLTV-ID: {}'.format(channel_data.get('xmltv_id') or channel_data.get('tvg_id') or 'leer'),
            'XMLTV-Quellkanäle: {}'.format(row.get('') or 0),
        ])
        for number, attempt in enumerate(row.get('attempts') or [], 1):
            lines.append('{}. {}: {}'.format(number, attempt.get('stage'),
                         'TREFFER' if attempt.get('matched') else 'kein Treffer'))
            if attempt.get('xmltv_id'):
                lines.append('   XMLTV-ID: {} | Programme: {}'.format(
                    attempt.get('xmltv_id'), attempt.get('programmes') or 0))
            for candidate in attempt.get('top_candidates') or []:
                lines.append('   Kandidat: {} | {} % | {} Programme'.format(
                    candidate.get('xmltv_id'), int(round(float(candidate.get('score') or 0) * 100)),
                    candidate.get('programmes') or 0))
        lines.extend([
            'Ergebnis: {}'.format('TREFFER' if result.get('matched') else 'KEIN TREFFER'),
            'Gewählte XMLTV-ID: {}'.format(result.get('xmltv_id') or 'keine'),
            'Methode: {}'.format(result.get('method') or 'kein Treffer'),
            'Programme: {}'.format(result.get('programmes') or 0), '',
        ])
    try:
        with open(txt_path, 'w', encoding='utf-8') as handle:
            handle.write('\n'.join(lines))
        with open(json_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        return {'txt': txt_path, 'json': json_path, 'raw': status.get('path'),
                'entries': len(rows), 'unique_channels': len(unique)}
    except Exception as exc:
        Logger.error('EPG live trace export failed: {}'.format(exc))
        return {}



def export_xmltv_input_diagnostics():
    """Inspect configured XMLTV inputs without touching any EPG cache.

    This routine is only called from an explicit diagnostics menu action.  It
    deliberately does not call ``load_xmltv`` and does not write, delete or
    replace XMLTV/EPG cache files.
    """
    import io
    import xml.etree.ElementTree as ET
    from urllib.parse import urlsplit, urlunsplit

    def _safe_source(value):
        try:
            parts = urlsplit(value)
            if parts.scheme in ('http', 'https'):
                host = parts.hostname or ''
                if parts.port:
                    host += ':' + str(parts.port)
                return urlunsplit((parts.scheme, host, parts.path, '', ''))
        except Exception:
            pass
        return value

    generated = datetime.now()
    report = {
        'report_type': 'Titan XMLTV input diagnostics',
        'generated': generated.strftime('%Y-%m-%d %H:%M:%S'),
        'cache_modified': False,
        'sources': [],
    }

    for source_no, source in enumerate(get_xmltv_urls(), 1):
        item = {
            'source': source_no,
            'location': _safe_source(source),
            'download_ok': False,
            'raw_bytes': 0,
            'gzip': False,
            'xml_bytes': 0,
            'root_tag': '',
            'exact_channels': 0,
            'exact_programmes': 0,
            'namespace_independent_channels': 0,
            'namespace_independent_programmes': 0,
            'sample_channel_ids': [],
            'error': '',
        }
        try:
            raw = _fetch_xmltv(source)
            if not raw:
                item['error'] = 'Quelle lieferte keine Daten'
                report['sources'].append(item)
                continue
            item['download_ok'] = True
            item['raw_bytes'] = len(raw)
            xml_data = raw
            if raw[:2] == b'\x1f\x8b':
                item['gzip'] = True
                with gzip.GzipFile(fileobj=io.BytesIO(raw)) as gz:
                    xml_data = gz.read()
            item['xml_bytes'] = len(xml_data)
            root = ET.fromstring(xml_data)
            item['root_tag'] = root.tag
            exact_channels = list(root.iter('channel'))
            exact_programmes = list(root.iter('programme'))
            all_elements = list(root.iter())
            ns_channels = [el for el in all_elements if str(el.tag).split('}')[-1] == 'channel']
            ns_programmes = [el for el in all_elements if str(el.tag).split('}')[-1] == 'programme']
            item['exact_channels'] = len(exact_channels)
            item['exact_programmes'] = len(exact_programmes)
            item['namespace_independent_channels'] = len(ns_channels)
            item['namespace_independent_programmes'] = len(ns_programmes)
            item['sample_channel_ids'] = [
                (el.get('id') or '').strip() for el in ns_channels[:12]
                if (el.get('id') or '').strip()
            ]
        except Exception as exc:
            item['error'] = '{}: {}'.format(type(exc).__name__, exc)
        report['sources'].append(item)

    stamp = generated.strftime('%Y%m%d_%H%M%S')
    json_path = _profile_path('XMLTV_Eingangsdiagnose_{}.json'.format(stamp))
    txt_path = _profile_path('XMLTV_Eingangsdiagnose_{}.txt'.format(stamp))
    lines = [
        'Titan Portal MAC VOD Edition – XMLTV-Eingangsdiagnose',
        'Erstellt: {}'.format(report['generated']),
        'EPG-/XMLTV-Cache verändert: NEIN',
        'Konfigurierte Quellen: {}'.format(len(report['sources'])),
        '',
    ]
    for item in report['sources']:
        lines.extend([
            '=' * 78,
            'Quelle {}: {}'.format(item['source'], item['location'] or 'leer'),
            'Download: {}'.format('OK' if item['download_ok'] else 'FEHLER'),
            'Rohdaten: {} Bytes'.format(item['raw_bytes']),
            'GZIP: {}'.format('ja' if item['gzip'] else 'nein'),
            'XML-Daten: {} Bytes'.format(item['xml_bytes']),
            'Wurzelelement: {}'.format(item['root_tag'] or 'nicht lesbar'),
            'Exakte <channel>: {}'.format(item['exact_channels']),
            'Exakte <programme>: {}'.format(item['exact_programmes']),
            'Namespace-unabhängige channel: {}'.format(item['namespace_independent_channels']),
            'Namespace-unabhängige programme: {}'.format(item['namespace_independent_programmes']),
            'Beispiel-IDs: {}'.format(', '.join(item['sample_channel_ids']) or 'keine'),
            'Fehler: {}'.format(item['error'] or 'keiner'),
            '',
        ])
    try:
        with open(json_path, 'w', encoding='utf-8') as handle:
            json.dump(report, handle, ensure_ascii=False, indent=2, sort_keys=True)
        with open(txt_path, 'w', encoding='utf-8') as handle:
            handle.write('\n'.join(lines))
        return {'json': json_path, 'txt': txt_path, 'sources': len(report['sources'])}
    except Exception as exc:
        Logger.error('XMLTV input diagnostics export failed: {}'.format(exc))
        return {}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_xmltv(portal_channels=None, force=False):
    """Fetch, parse and cache all configured XMLTV feeds.

    Sources are processed in settings order. Source 1 has priority; source 2
    only fills portal channel IDs for which source 1 produced no schedule.
    The returned dictionary uses the normal portal EPG format.
    """
    global _xmltv_mem, _xmltv_loaded_ts, _xmltv_source_mem, _xmltv_source_mtime

    with _xmltv_lock:
        urls = get_xmltv_urls()
        if not urls:
            return {}

        dict_path = _xmltv_dict_path()
        refresh_s = get_xmltv_refresh_hours()

        if not force and dict_path and os.path.exists(dict_path):
            try:
                age = time.time() - os.path.getmtime(dict_path)
                if age <= refresh_s:
                    with open(dict_path, 'r', encoding='utf-8') as f:
                        cached_portal = json.load(f)
                    raw_source = _read_json(_xmltv_source_dict_path(), {})
                    if isinstance(raw_source, dict) and raw_source:
                        _xmltv_mem = cached_portal if isinstance(cached_portal, dict) else {}
                        _xmltv_loaded_ts = int(time.time())
                        Logger.debug('XMLTV loaded from disk cache (age {:.0f}s; {} raw source IDs)'.format(
                            age, len(raw_source)))
                        return _xmltv_mem
                    Logger.warn('XMLTV portal cache is fresh but raw source cache is empty; forcing rebuild')
            except Exception:
                pass

        if not portal_channels:
            try:
                from .portal_index import get_cached_channels
                portal_channels = get_cached_channels()
            except Exception as exc:
                Logger.warn('XMLTV could not read portal index: {}'.format(exc))
                portal_channels = []

        user_mapping = get_tvg_mapping()
        combined = {}
        source_combined = {}
        source_stats = []
        all_diagnostics = []

        for source_no, url in enumerate(urls, 1):
            Logger.info('XMLTV source {}: downloading from {}'.format(source_no, url))
            raw = _fetch_xmltv(url)
            if not raw:
                source_stats.append((source_no, 0, 'download failed'))
                continue

            xmltv_dict, channel_names = _parse_xmltv_bytes(raw)
            if not xmltv_dict:
                source_stats.append((source_no, 0, 'parse failed'))
                continue

            # Preserve original source-ID schedules for runtime matching of
            # channels that were not yet present in the portal index.
            for source_id, events in xmltv_dict.items():
                if source_id not in source_combined or not source_combined.get(source_id):
                    source_combined[source_id] = events

            matched, diagnostics = _match_channels(
                xmltv_dict, channel_names, portal_channels or [], user_mapping)
            for item in diagnostics:
                item['source'] = source_no
            all_diagnostics.extend(diagnostics)
            added = 0
            for portal_id, events in matched.items():
                key = str(portal_id)
                # Earlier sources win. A later source only fills a channel that
                # is still absent or has no programme entries.
                if key not in combined or not combined.get(key):
                    combined[key] = events
                    added += 1
            source_stats.append((source_no, added, 'ok'))
            Logger.info('XMLTV source {} added {} portal IDs'.format(source_no, added))

        # The raw source cache is also required by the runtime matcher.
        # Persist it independently of portal-ID matching: a valid XMLTV feed
        # may contain hundreds of schedules even when the initial portal index
        # is empty or no portal channel can be mapped during this load.
        if source_combined:
            _write_json(_xmltv_source_dict_path(), source_combined)
            _xmltv_source_mem = source_combined
            try:
                _xmltv_source_mtime = os.path.getmtime(_xmltv_source_dict_path())
            except Exception:
                _xmltv_source_mtime = time.time()
            Logger.info('XMLTV raw source cache contains {} channel IDs'.format(
                len(source_combined)))
        else:
            Logger.error('XMLTV import produced no raw source channels; existing raw cache is kept unchanged')

        source_catalog = _source_catalog()
        _write_json(_diagnostics_path(), {
            'generated': datetime.now().isoformat(timespec='seconds'),
            'sources': source_stats,
            'source_catalog': {
                'name': source_catalog.get('source') or '',
                'timestamp': source_catalog.get('source_timestamp') or '',
                'channel_count': len(source_catalog.get('channels') or []),
            },
            'raw_source_channels': len(source_combined),
            'portal_channels': len(combined),
            'channels': all_diagnostics,
        })

        if not combined:
            # A non-empty raw cache is still a successful XMLTV import. The
            # runtime matcher can resolve channel names directly against it.
            # Keep any existing portal-ID cache as a fallback for callers that
            # only consume the pre-mapped dictionary.
            if _xmltv_mem:
                return _xmltv_mem
            if dict_path and os.path.exists(dict_path):
                try:
                    with open(dict_path, 'r', encoding='utf-8') as f:
                        _xmltv_mem = json.load(f)
                    return _xmltv_mem
                except Exception:
                    pass
            return {}

        if dict_path:
            try:
                tmp = dict_path + '.tmp'
                with open(tmp, 'w', encoding='utf-8') as f:
                    json.dump(combined, f, ensure_ascii=False)
                os.replace(tmp, dict_path)
            except Exception as exc:
                Logger.warn('XMLTV dict save failed: {}'.format(exc))

        _xmltv_mem = combined
        _xmltv_loaded_ts = int(time.time())
        Logger.info('XMLTV combined cache contains {} portal IDs; stats={}'.format(
            len(combined), source_stats))
        return combined


def get_xmltv_dict():
    """Return cached XMLTV dict or load from disk (respecting refresh interval)."""
    global _xmltv_mem
    with _xmltv_lock:
        if _xmltv_mem:
            return _xmltv_mem
        dict_path = _xmltv_dict_path()
        if dict_path and os.path.exists(dict_path):
            try:
                age = time.time() - os.path.getmtime(dict_path)
                refresh_s = get_xmltv_refresh_hours()
                if age <= refresh_s:
                    # Disk cache is fresh – load it without re-downloading
                    with open(dict_path, 'r', encoding='utf-8') as f:
                        _xmltv_mem = json.load(f)
                    Logger.debug('XMLTV dict loaded from disk cache (age {:.0f}s)'.format(age))
                    return _xmltv_mem
            except Exception:
                pass
        return {}


def get_xmltv_diagnostics():
    """Return the most recent channel-matching diagnostics."""
    data = _read_json(_diagnostics_path(), {})
    return data if isinstance(data, dict) else {}


def get_xmltv_diagnostics_text(limit=18):
    data = get_xmltv_diagnostics()
    channels = data.get('channels') or []
    if not channels:
        return ('Noch keine EPG-Zuordnungsdiagnose vorhanden.\n\n'
                'Bitte zuerst „Externe EPG-Daten neu laden“ ausführen.')
    # Multiple sources may contain duplicate portal rows; keep best match.
    best = {}
    for item in channels:
        key = str(item.get('portal_id') or item.get('portal_name') or '')
        old = best.get(key)
        rank = (1 if item.get('matched') else 0, int(item.get('programmes') or 0), float(item.get('score') or 0))
        if old is None or rank > old[0]:
            best[key] = (rank, item)
    rows = [value[1] for value in best.values()]
    matched = [row for row in rows if row.get('matched')]
    missing = [row for row in rows if not row.get('matched')]
    catalog = data.get('source_catalog') or {}
    source_line = '{} ({} IDs)'.format(
        catalog.get('name') or 'keine Quellen-ID-Datenbank',
        int(catalog.get('channel_count') or 0))
    methods = {}
    for row in matched:
        method_name = row.get('method') or 'unbekannt'
        methods[method_name] = methods.get(method_name, 0) + 1
    method_line = ', '.join('{}: {}'.format(key, methods[key]) for key in sorted(methods)) or 'keine'
    lines = [
        'Stand: {}'.format(data.get('generated') or 'unbekannt'),
        'Quellenkatalog: {}'.format(source_line),
        'Sender geprüft: {}'.format(len(rows)),
        'Mit EPG zugeordnet: {}'.format(len(matched)),
        'Ohne Zuordnung: {}'.format(len(missing)),
        'Zuordnungswege: {}'.format(method_line),
        '', 'Nicht zugeordnete Sender:',
    ]
    if missing:
        for row in sorted(missing, key=lambda x: (x.get('portal_name') or '').lower())[:limit]:
            name = row.get('portal_name') or row.get('portal_id')
            suggestion = row.get('suggestion_xmltv_id') or ''
            suggestion_score = float(row.get('suggestion_score') or 0.0)
            if suggestion and suggestion_score >= 0.65:
                lines.append('• {}  → Vorschlag: {} ({} %)'.format(
                    name, suggestion, int(round(suggestion_score * 100))))
            else:
                lines.append('• {}'.format(name))
        if len(missing) > limit:
            lines.append('… und {} weitere'.format(len(missing) - limit))
    else:
        lines.append('Keine – alle erkannten Sender wurden zugeordnet.')
    return '\n'.join(lines)



def _diagnostic_safe_value(key, value):
    """Return serialisable channel metadata while masking credentials."""
    key_l = str(key or '').lower()
    sensitive = ('token', 'password', 'passwd', 'authorization', 'cookie', 'mac')
    if any(part in key_l for part in sensitive):
        return '<maskiert>' if value not in (None, '', [], {}) else value
    if isinstance(value, dict):
        return {str(k): _diagnostic_safe_value(k, v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_diagnostic_safe_value(key, item) for item in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        text = value
    else:
        text = repr(value)
    if isinstance(text, str) and len(text) > 2000:
        return text[:1997] + '...'
    return text


def _normalisation_trace(value):
    """Expose the relevant name-cleaning stages without changing matching."""
    original = str(value or '')
    lower = original.lower().strip()
    quality_removed = re.sub(r'\b(?:uhd|fhd|full\s*hd|hd|sd|4k|8k|hevc|h265|h264)\b', ' ', lower)
    bracket_removed = re.sub(r'[\[\(\{].*?[\]\)\}]', ' ', quality_removed)
    punctuation_removed = re.sub(r'[^a-z0-9äöüß]+', ' ', bracket_removed)
    whitespace_cleaned = re.sub(r'\s+', ' ', punctuation_removed).strip()
    return {
        'original': original,
        'lowercase': lower,
        'quality_removed': re.sub(r'\s+', ' ', quality_removed).strip(),
        'brackets_removed': re.sub(r'\s+', ' ', bracket_removed).strip(),
        'punctuation_removed': whitespace_cleaned,
        'normalised_function': _normalise(original),
        'canonical_function': _canonical(original),
        'name_candidates': _name_candidates(original),
    }


def _mapping_trace(channel, source_epg):
    """Trace every resolver stage, mirroring the runtime resolver order."""
    name = str(channel.get('name') or channel.get('title') or '')
    attempts = []

    portal_ids = []
    for key in ('epg_id', 'xmltv_id', 'tvg_id', 'channel_id', 'id', 'ch_id'):
        value = str(channel.get(key) or '').strip()
        if value and value not in portal_ids:
            portal_ids.append(value)
    direct = next((value for value in portal_ids if value in source_epg), '')
    attempts.append({
        'stage': 'Portal-ID direkt', 'inputs': portal_ids,
        'matched': bool(direct), 'xmltv_id': direct,
        'programmes': len(source_epg.get(direct) or []) if direct else 0,
    })

    family_id = _family_source_id_for_name(name, source_epg)
    attempts.append({
        'stage': 'Senderfamilie', 'input': name, 'matched': bool(family_id),
        'xmltv_id': family_id or '',
        'programmes': len(source_epg.get(family_id) or []) if family_id else 0,
    })

    source_id = _source_id_for_name(name, source_epg)
    attempts.append({
        'stage': 'Quellen-ID-Katalog', 'input': name, 'matched': bool(source_id),
        'xmltv_id': source_id or '',
        'programmes': len(source_epg.get(source_id) or []) if source_id else 0,
    })

    lookup, records = _build_xmltv_lookup(source_epg, {})
    candidates = _name_candidates(name)
    exact_hits = []
    seen = set()
    for candidate in candidates:
        for hit in lookup.get(candidate) or []:
            if hit[0] not in seen:
                seen.add(hit[0]); exact_hits.append(hit)
    exact = max(exact_hits, key=lambda hit: len(hit[1] or [])) if exact_hits else None
    attempts.append({
        'stage': 'Alias/Exakt', 'inputs': candidates, 'matched': bool(exact),
        'xmltv_id': exact[0] if exact else '',
        'programmes': len(exact[1] or []) if exact else 0,
        'hit_count': len(exact_hits),
    })

    scored = []
    for xid, events, xml_candidates in records:
        score = max((_similarity(pc, xc) for pc in candidates for xc in xml_candidates), default=0.0)
        if score >= 0.55:
            scored.append((score, xid, events))
    scored.sort(reverse=True, key=lambda item: item[0])
    top = scored[:5]
    automatic = [item for item in scored if item[0] >= 0.90]
    fuzzy_ok = bool(automatic and (len(automatic) == 1 or automatic[0][0] - automatic[1][0] >= 0.04))
    attempts.append({
        'stage': 'Fuzzy', 'matched': fuzzy_ok,
        'xmltv_id': automatic[0][1] if fuzzy_ok else '',
        'programmes': len(automatic[0][2] or []) if fuzzy_ok else 0,
        'threshold': 0.90, 'minimum_margin': 0.04,
        'top_candidates': [
            {'xmltv_id': xid, 'score': round(float(score), 3), 'programmes': len(events or [])}
            for score, xid, events in top
        ],
    })
    return attempts


def diagnose_xmltv_channel(channel):
    """Return a complete, read-only developer trace for one portal channel."""
    channel = channel if isinstance(channel, dict) else {'name': str(channel or '')}
    name = str(channel.get('name') or channel.get('title') or '')
    source_epg = _load_source_epg_dict(auto_repair=True)
    xmltv_id, events, method = resolve_xmltv_channel(name)
    attempts = _mapping_trace(channel, source_epg)

    # Direct portal metadata is diagnostic only; the runtime matcher currently
    # resolves by name. Showing this distinction is essential for debugging.
    direct_ids = [str(channel.get(k) or '').strip() for k in
                  ('epg_id', 'xmltv_id', 'tvg_id', 'channel_id', 'id', 'ch_id')]
    direct_ids = [v for i, v in enumerate(direct_ids) if v and v not in direct_ids[:i]]
    direct_xmltv_id = next((v for v in direct_ids if v in source_epg), '')

    suggestion = {}
    fuzzy_attempt = next((a for a in attempts if a.get('stage') == 'Fuzzy'), {})
    if fuzzy_attempt.get('top_candidates'):
        suggestion = fuzzy_attempt['top_candidates'][0]

    first = events[0] if events else {}
    raw_fields = {str(k): _diagnostic_safe_value(k, v)
                  for k, v in sorted(channel.items(), key=lambda item: str(item[0]).lower())}
    return {
        'name': name,
        'portal_id': str(channel.get('id') or channel.get('ch_id') or ''),
        'stream_id': str(channel.get('stream_id') or channel.get('id') or ''),
        'portal_epg_id': str(channel.get('epg_id') or ''),
        'portal_xmltv_id': str(channel.get('xmltv_id') or channel.get('tvg_id') or ''),
        'cmd': str(channel.get('cmd') or ''),
        'group_titles': list(channel.get('group_titles') or []),
        'raw_fields': raw_fields,
        'normalisation': _normalisation_trace(name),
        'mapping_attempts': attempts,
        'direct_xmltv_id': direct_xmltv_id,
        'runtime_uses_direct_portal_id': False,
        'normalized_name': _normalise(name),
        'canonical_name': _canonical(name),
        'xmltv_id': xmltv_id,
        'mapping_method': method or 'kein Treffer',
        'xmltv_channel_present': bool(xmltv_id and xmltv_id in source_epg),
        'programmes': len(events or []),
        'first_title': str(first.get('name') or ''),
        'first_start': str(first.get('t_time') or ''),
        'first_stop': str(first.get('t_time_to') or ''),
        'suggestion_xmltv_id': suggestion.get('xmltv_id', ''),
        'suggestion_score': suggestion.get('score', 0.0),
        'suggestion_programmes': suggestion.get('programmes', 0),
        'source_channel_count': len(source_epg),
        'status': 'Zuordnung erfolgreich' if xmltv_id and events else ('XMLTV-ID ohne Programme' if xmltv_id else 'Keine XMLTV-ID gefunden'),
    }


def format_xmltv_channel_diagnosis(report):
    """Format the complete developer trace for a Kodi text dialog."""
    lines = [
        '===== PORTAL-ROHDATEN (Zugangsdaten maskiert) =====',
    ]
    for key, value in (report.get('raw_fields') or {}).items():
        lines.append('{}: {}'.format(key, json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else value))

    trace = report.get('normalisation') or {}
    lines.extend(['', '===== NAMENSNORMALISIERUNG ====='])
    for key in ('original', 'lowercase', 'quality_removed', 'brackets_removed',
                'punctuation_removed', 'normalised_function', 'canonical_function'):
        lines.append('{}: {}'.format(key, trace.get(key) or 'leer'))
    lines.append('name_candidates: {}'.format(', '.join(trace.get('name_candidates') or []) or 'keine'))

    lines.extend(['', '===== MATCH-ENGINE ====='])
    for number, attempt in enumerate(report.get('mapping_attempts') or [], 1):
        lines.append('{}. {}: {}'.format(number, attempt.get('stage'), 'TREFFER' if attempt.get('matched') else 'kein Treffer'))
        if attempt.get('inputs'):
            lines.append('   Eingaben: {}'.format(', '.join(str(v) for v in attempt.get('inputs') or [])))
        if attempt.get('xmltv_id'):
            lines.append('   XMLTV-ID: {}'.format(attempt.get('xmltv_id')))
            lines.append('   Programme: {}'.format(attempt.get('programmes') or 0))
        for candidate in attempt.get('top_candidates') or []:
            lines.append('   Kandidat: {} | {} % | {} Programme'.format(
                candidate.get('xmltv_id'), int(round(float(candidate.get('score') or 0) * 100)),
                candidate.get('programmes') or 0))

    lines.extend([
        '', '===== LAUFZEIT-ERGEBNIS =====',
        'Sendername: {}'.format(report.get('name') or 'unbekannt'),
        'Portal-EPG-ID: {}'.format(report.get('portal_epg_id') or 'leer'),
        'Portal-XMLTV-ID: {}'.format(report.get('portal_xmltv_id') or 'leer'),
        'Direkte vorhandene XMLTV-ID: {}'.format(report.get('direct_xmltv_id') or 'keine'),
        'Hinweis: Laufzeit-Matcher verwendet Portal-ID direkt: {}'.format(
            'JA' if report.get('runtime_uses_direct_portal_id') else 'NEIN'),
        'Gewählte XMLTV-ID: {}'.format(report.get('xmltv_id') or 'kein Treffer'),
        'Zuordnungsweg: {}'.format(report.get('mapping_method') or 'unbekannt'),
        'XMLTV-Kanal vorhanden: {}'.format('JA' if report.get('xmltv_channel_present') else 'NEIN'),
        'Programme gefunden: {}'.format(int(report.get('programmes') or 0)),
    ])
    if report.get('first_title'):
        lines.extend([
            'Erste Sendung: {}'.format(report.get('first_title')),
            'Zeit: {}–{}'.format(report.get('first_start') or '?', report.get('first_stop') or '?'),
        ])
    lines.extend(['', 'Status: {}'.format(report.get('status') or 'unbekannt')])
    return '\n'.join(lines)


def search_(term, limit=100):
    """Search cached real XMLTV IDs and return programme counts."""
    source_epg = _load_source_epg_dict(auto_repair=True)
    needle = _normalise(term)
    rows = []
    for xid, events in source_epg.items():
        if not needle or needle in _normalise(xid):
            rows.append({'xmltv_id': xid, 'programmes': len(events or [])})
    rows.sort(key=lambda row: row['xmltv_id'].lower())
    return rows[:max(1, int(limit or 100))]


def prepare_epg_diagnostic_data(channels=None, force_portal=False, force_xmltv=False,
                                progress_callback=None, cancel_callback=None):
    """Ensure portal channels and raw XMLTV schedules exist before diagnosis.

    Returns a dictionary containing the prepared channel list plus provenance,
    durations and non-fatal errors.  The function intentionally reuses valid
    caches unless a required cache is missing or a force flag is supplied.
    """
    started = time.time()
    result = {
        'channels': list(channels or []),
        'portal_source': 'provided' if channels else 'cache',
        'xmltv_source': 'cache',
        'portal_seconds': 0.0,
        'xmltv_seconds': 0.0,
        'errors': [],
        'cancelled': False,
    }

    if not result['channels']:
        try:
            from .portal_index import get_cached_channels
            result['channels'] = list(get_cached_channels() or [])
        except Exception as exc:
            result['errors'].append('Portal-Cache konnte nicht gelesen werden: {}'.format(exc))

    if force_portal or not result['channels']:
        portal_started = time.time()
        try:
            from .portal_index import build_index
            built = build_index(
                force=bool(force_portal or not result['channels']),
                progress_callback=progress_callback,
                cancel_callback=cancel_callback,
            ) or {}
            result['portal_seconds'] = round(time.time() - portal_started, 3)
            result['cancelled'] = bool(built.get('cancelled'))
            if result['cancelled']:
                result['errors'].append('Portal-Index-Aufbau wurde abgebrochen.')
            built_channels = list(built.get('channels') or [])
            if built_channels:
                result['channels'] = built_channels
                result['portal_source'] = 'neu aufgebaut' if not built.get('cached') else 'cache'
            elif not result['channels']:
                result['errors'].append('Das Portal lieferte keine Sender für den Diagnose-Index.')
        except Exception as exc:
            result['portal_seconds'] = round(time.time() - portal_started, 3)
            result['errors'].append('Portal-Index-Aufbau fehlgeschlagen: {}'.format(exc))

    if result['cancelled']:
        result['total_seconds'] = round(time.time() - started, 3)
        return result

    source_before = _load_source_epg_dict()
    need_xmltv = bool(force_xmltv or not source_before)
    xmltv_started = time.time()
    try:
        # A missing raw source cache requires a forced parse even when the
        # mapped portal cache is still considered fresh.
        load_xmltv(result['channels'], force=need_xmltv)
        source_after = _load_source_epg_dict()
        result['xmltv_source'] = 'neu geladen' if need_xmltv and source_after else 'cache'
        result[''] = len(source_after)
        if not source_after:
            if not get_xmltv_urls():
                result['errors'].append('Keine XMLTV-Quelle ist in den Add-on-Einstellungen konfiguriert.')
            else:
                result['errors'].append('Die XMLTV-Quelle lieferte keine auswertbaren Quellkanäle.')
    except Exception as exc:
        result[''] = len(_load_source_epg_dict())
        result['errors'].append('XMLTV-Initialisierung fehlgeschlagen: {}'.format(exc))
    result['xmltv_seconds'] = round(time.time() - xmltv_started, 3)
    result['total_seconds'] = round(time.time() - started, 3)
    return result


def create_epg_diagnostic_report(channels=None, preparation=None):
    """Create detailed TXT and JSON developer reports in the add-on profile."""
    if channels is None:
        try:
            from .portal_index import get_cached_channels
            channels = get_cached_channels()
        except Exception:
            channels = []
    preparation = dict(preparation or {})
    preparation.pop('channels', None)
    reports = [diagnose_xmltv_channel(channel) for channel in (channels or [])]
    now = datetime.now()
    generated = now.strftime('%Y-%m-%d %H:%M:%S')
    successful = sum(1 for row in reports if row.get('programmes'))
    methods = {}
    for row in reports:
        method = row.get('mapping_method') or 'kein Treffer'
        methods[method] = methods.get(method, 0) + 1
    payload = {
        'report_type': 'Titan EPG developer diagnosis',
        'generated': generated,
        'privacy': 'Credential-like fields are masked.',
        'summary': {
            'channels': len(reports), '': len(_load_source_epg_dict()),
            'matched': successful, 'unmatched': len(reports) - successful,
            'mapping_methods': methods,
        },
        'preparation': preparation,
        'channels': reports,
    }
    stamp = now.strftime('%Y%m%d_%H%M%S')
    txt_path = _profile_path('EPG_Entwicklerdiagnose_{}.txt'.format(stamp))
    json_path = _profile_path('EPG_Entwicklerdiagnose_{}.json'.format(stamp))
    lines = [
        'Titan Portal MAC VOD Edition – EPG-Entwicklerdiagnose',
        'Erstellt: {}'.format(generated),
        'Sender im Portal-Index: {}'.format(len(reports)),
        'XMLTV-Quellkanäle im Cache: {}'.format(len(_load_source_epg_dict())),
        'Erfolgreich zugeordnet: {}'.format(successful),
        'Ohne EPG: {}'.format(len(reports) - successful),
        'Zuordnungswege: {}'.format(', '.join('{}={}'.format(k, methods[k]) for k in sorted(methods))),
        'Portal-Datenquelle: {}'.format(preparation.get('portal_source') or 'unbekannt'),
        'XMLTV-Datenquelle: {}'.format(preparation.get('xmltv_source') or 'unbekannt'),
        'Portal-Aufbau: {:.3f} Sekunden'.format(float(preparation.get('portal_seconds') or 0)),
        'XMLTV-Aufbau: {:.3f} Sekunden'.format(float(preparation.get('xmltv_seconds') or 0)),
        'Gesamtdauer Vorbereitung: {:.3f} Sekunden'.format(float(preparation.get('total_seconds') or 0)),
        'Vorbereitungsfehler: {}'.format(' | '.join(preparation.get('errors') or []) or 'keine'),
        'JSON-Bericht: {}'.format(json_path), '',
    ]
    for row in sorted(reports, key=lambda item: (item.get('name') or '').lower()):
        lines.append(format_xmltv_channel_diagnosis(row))
        lines.append('\n' + ('-' * 78) + '\n')
    try:
        with open(txt_path, 'w', encoding='utf-8') as handle:
            handle.write('\n'.join(lines))
        with open(json_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        return {'txt': txt_path, 'json': json_path}
    except Exception as exc:
        Logger.error('EPG developer diagnostic report save failed: {}'.format(exc))
        return {}

def reset_xmltv_mapping_cache():
    """Forget learned mappings and diagnostics without touching settings."""
    for path in (_learned_mapping_path(), _diagnostics_path(), _xmltv_dict_path(), _xmltv_source_dict_path()):
        try:
            if path and os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
    clear_xmltv_cache()


def clear_xmltv_cache():
    """Remove XMLTV in-memory and disk cache."""
    global _xmltv_mem, _xmltv_loaded_ts, _xmltv_source_mem, _xmltv_source_mtime
    with _xmltv_lock:
        _xmltv_mem = {}
        _xmltv_source_mem = {}
        _xmltv_source_mtime = 0.0
        _xmltv_loaded_ts = 0
        for p in (_xmltv_cache_path(), _xmltv_dict_path(), _xmltv_source_dict_path()):
            try:
                if p and os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass


def merge_epg_dicts(portal_dict, xmltv_dict):
    """Merge portal and XMLTV EPG dicts.

    Portal data takes priority. XMLTV fills in channels missing from portal.
    """
    merged = dict(portal_dict or {})
    for ch_id, events in (xmltv_dict or {}).items():
        key_str = str(ch_id)
        if key_str not in merged and ch_id not in merged:
            merged[key_str] = events
    return merged
