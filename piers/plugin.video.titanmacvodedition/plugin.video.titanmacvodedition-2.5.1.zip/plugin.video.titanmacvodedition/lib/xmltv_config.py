# -*- coding: utf-8 -*-
"""XMLTV settings, file paths, and JSON persistence helpers."""
from __future__ import absolute_import, division, unicode_literals

import json
import os

import xbmcaddon
import xbmcvfs

from .loggers import Logger
from .file_utils import atomic_write_json, read_json
from .kodi_paths import data_resource_path, profile_path

_ADDON_ID = 'plugin.video.titanmacvodedition'

def _addon():
    return xbmcaddon.Addon(_ADDON_ID)


def get_epg_source():
    """Return 'portal', 'xmltv', or 'merge'."""
    try:
        raw = (_addon().getSetting('epg_source') or '0').strip()
        return {'0': 'portal', '1': 'xmltv', '2': 'merge'}.get(raw, 'portal')
    except Exception:
        return 'portal'


def get_xmltv_url():
    try:
        return (_addon().getSetting('xmltv_url') or '').strip()
    except Exception:
        return ''


def get_xmltv_url2():
    """Return the optional second XMLTV source URL."""
    try:
        return (_addon().getSetting('xmltv_url2') or '').strip()
    except Exception:
        return ''


def get_xmltv_urls():
    """Return configured XMLTV sources in priority order, without duplicates."""
    result = []
    for url in (get_xmltv_url(), get_xmltv_url2()):
        if url and url not in result:
            result.append(url)
    return result


def get_xmltv_refresh_hours():
    """Return refresh interval in seconds (setting is enum 0-3 = 6/12/24/48h)."""
    try:
        raw = (_addon().getSetting('xmltv_refresh') or '1').strip()
        hours = [6, 12, 24, 48]
        idx = int(raw) if raw.isdigit() else 1
        return hours[idx if 0 <= idx < len(hours) else 1] * 3600
    except Exception:
        return 12 * 3600


def get_tvg_mapping():
    """Return dict {tvg-id-or-name: portal_channel_id} from settings JSON."""
    try:
        raw = (_addon().getSetting('xmltv_mapping') or '').strip()
        if not raw:
            return {}
        return json.loads(raw)
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# File paths
# ---------------------------------------------------------------------------

def _xmltv_cache_path():
    return profile_path('xmltv_cache.xml.gz')


def _xmltv_dict_path():
    return profile_path('xmltv_epg.json')


def _xmltv_source_dict_path():
    """Raw XMLTV schedules keyed by the real source channel IDs."""
    return profile_path('xmltv_source_epg.json')


def _profile_path(filename):
    return profile_path(filename)


def _learned_mapping_path():
    return _profile_path('xmltv_learned_mapping.json')


def _diagnostics_path():
    return _profile_path('xmltv_diagnostics.json')


def __path():
    return _profile_path('.jsonl')


def __state_path():
    return _profile_path('_state.json')


def _resource_alias_path():
    return data_resource_path('epg_aliases.json')


def _resource_source_catalog_path():
    """Return the bundled channel-ID catalogue for epg_ripper_DE1."""
    return data_resource_path('epg_source_de1.json')


def _read_json(path, default):
    return read_json(path, default)


def _write_json(path, value):
    if atomic_write_json(path, value, sort_keys=True, prefix='.xmltv_'):
        return True
    Logger.warning('XMLTV JSON save failed for {}'.format(path))
    return False
