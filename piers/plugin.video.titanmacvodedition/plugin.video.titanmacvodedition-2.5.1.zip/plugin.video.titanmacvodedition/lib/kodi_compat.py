"""Kodi API compatibility helpers.

All version-sensitive metadata calls live here so future Kodi changes can be
handled without touching every directory builder.
"""
from __future__ import absolute_import, unicode_literals

import xbmc

from .loggers import Logger


def kodi_major_version():
    try:
        value = xbmc.getInfoLabel('System.BuildVersion') or ''
        return int(str(value).split('.', 1)[0])
    except (TypeError, ValueError):
        return 0


def set_video_metadata(item, plot='', playcount=0):
    """Set metadata through VideoInfoTag with a safe legacy fallback."""
    try:
        info = item.getVideoInfoTag()
        info.setPlot(str(plot or ''))
        info.setPlaycount(int(playcount or 0))
        return True
    except Exception as exc:
        Logger.debug('VideoInfoTag metadata fallback used: {}'.format(exc))
        try:
            item.setInfo('video', {
                'plot': str(plot or ''),
                'playcount': int(playcount or 0),
            })
            return True
        except Exception as fallback_exc:
            Logger.debug('Could not set video metadata: {}'.format(fallback_exc))
            return False
