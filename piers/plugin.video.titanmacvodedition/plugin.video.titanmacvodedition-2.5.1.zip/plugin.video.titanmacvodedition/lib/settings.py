"""Central, typed access to Kodi add-on settings.

The manager keeps compatibility with Kodi releases that expose either the
specialised getSetting* methods or only the classic string based API.
"""
from __future__ import absolute_import, unicode_literals

import xbmcaddon

ADDON_ID = 'plugin.video.titanmacvodedition'


class SettingsManager:
    """Read add-on settings through one defensive compatibility layer."""

    def __init__(self, addon_id=ADDON_ID):
        self.addon_id = addon_id

    def _addon(self):
        return xbmcaddon.Addon(self.addon_id)

    def get_string(self, setting_id, default=''):
        """Return a setting as text, using *default* on Kodi/API errors."""
        try:
            addon = self._addon()
            getter = getattr(addon, 'getSettingString', None)
            value = getter(setting_id) if callable(getter) else addon.getSetting(setting_id)
            return str(value) if value is not None else str(default)
        except Exception:
            return str(default)

    def get_bool(self, setting_id, default=False):
        """Return a setting as bool across old and current Kodi APIs."""
        try:
            addon = self._addon()
            getter = getattr(addon, 'getSettingBool', None)
            if callable(getter):
                return bool(getter(setting_id))
            value = addon.getSetting(setting_id)
            return str(value).strip().lower() in ('true', '1', 'yes', 'on')
        except Exception:
            return bool(default)

    def get_int(self, setting_id, default=0, minimum=None, maximum=None):
        """Return a bounded integer setting."""
        try:
            value = int(self.get_string(setting_id, default))
        except (TypeError, ValueError):
            value = int(default)
        if minimum is not None:
            value = max(int(minimum), value)
        if maximum is not None:
            value = min(int(maximum), value)
        return value

    def set_string(self, setting_id, value):
        """Persist text while retaining compatibility with older Kodi APIs."""
        addon = self._addon()
        setter = getattr(addon, 'setSettingString', None)
        if callable(setter):
            return setter(setting_id, str(value))
        return addon.setSetting(setting_id, str(value))


settings = SettingsManager()
