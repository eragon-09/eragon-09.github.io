# -*- coding: utf-8 -*-
"""Central Kodi/add-on path resolution with non-Kodi fallbacks."""
from __future__ import absolute_import, division, unicode_literals

import os

try:
    import xbmcaddon
    import xbmcvfs
except ImportError:  # permits syntax/unit checks outside Kodi
    xbmcaddon = None
    xbmcvfs = None

from .settings import ADDON_ID
from .file_utils import ensure_directory


def translate(path):
    try:
        return xbmcvfs.translatePath(path) if xbmcvfs else path
    except Exception:
        return path


def addon_path(*parts):
    try:
        base = translate(xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'))
    except Exception:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts) if parts else base


def profile_path(*parts, **kwargs):
    create = kwargs.pop('create', True)
    try:
        base = translate(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile'))
    except Exception:
        base = addon_path('profile')
    if create:
        ensure_directory(base)
    return os.path.join(base, *parts) if parts else base


def resource_path(*parts):
    return addon_path('resources', *parts)


def data_resource_path(*parts):
    return resource_path('data', *parts)


def temp_path(*parts, **kwargs):
    create = kwargs.pop('create', True)
    base = translate('special://temp/{}/'.format(ADDON_ID))
    if create:
        ensure_directory(base)
    return os.path.join(base, *parts) if parts else base
