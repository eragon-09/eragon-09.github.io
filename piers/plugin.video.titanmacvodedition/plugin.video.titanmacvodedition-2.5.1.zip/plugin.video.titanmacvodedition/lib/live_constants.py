"""Named constants shared by live-TV presentation modules."""
from __future__ import absolute_import, unicode_literals

EPG_TITLE_MAX_LENGTH = 45
CHANNEL_LABEL_MAX_VISIBLE_LENGTH = 66
SECONDARY_LABEL_MAX_LENGTH = 90
CHANNEL_NUMBER_WIDTH = 3
LOGO_CACHE_NAMESPACE = 'channel_logos'
