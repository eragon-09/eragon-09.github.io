"""Skin-neutral ListItem and artwork helpers for live TV.

This module deliberately keeps all important information in ListItem.Label.
Additional metadata is only a fallback for skins that expose it.
"""
from __future__ import absolute_import, unicode_literals

import xbmcgui

from .cache import runtime_cache
from .kodi_compat import set_video_metadata
from .live_constants import CHANNEL_NUMBER_WIDTH, LOGO_CACHE_NAMESPACE
from .live_epg import next_label2, now_label2


def resolve_channel_logo(channel=None, saved=None, fallback=''):
    """Resolve and cache the preferred channel logo without probing the URL.

    The live portal logo wins, followed by a saved/local logo and finally the
    supplied generic fallback. Caching only stores the resolved string, so it
    remains safe for local paths as well as remote image URLs.
    """
    channel = channel or {}
    saved = saved or {}
    key = (
        str(channel.get('logo') or ''),
        str(saved.get('logo') or ''),
        str(fallback or ''),
    )
    return runtime_cache.get_or_create(
        LOGO_CACHE_NAMESPACE, key, lambda: key[0] or key[1] or key[2])


def clear_logo_cache():
    runtime_cache.invalidate(LOGO_CACHE_NAMESPACE)


def numbered_channel_label(programme_number, label):
    """Return the stable primary label used by every live-TV directory."""
    try:
        number = int(programme_number)
        number_text = ('{:0' + str(CHANNEL_NUMBER_WIDTH) + 'd}').format(number)
    except (TypeError, ValueError):
        number_text = str(programme_number or '')
    if number_text:
        return '[COLOR FFADADAD]{}[/COLOR]  {}'.format(number_text, str(label or ''))
    return str(label or '')


def create_live_channel_item(label, channel_name, programme_number,
                             now_line='', next_line='', plot_text='',
                             logo='', fanart='', playable=True):
    """Create one skin-neutral live-TV ListItem.

    No VideoInfoTag title is set because some skins prefer it over the primary
    label, which can hide the programme number or the compact EPG text.
    """
    secondary = now_label2(now_line) or str(channel_name or '')
    item = xbmcgui.ListItem(label=str(label or ''), label2=secondary)

    item.setProperty('IsPlayable', 'true' if playable else 'false')
    item.setProperty('channel_number', str(programme_number or ''))
    item.setProperty('channel_name', str(channel_name or ''))
    item.setProperty('epg_now', now_label2(now_line))
    item.setProperty('epg_next', next_label2(next_line))

    set_video_metadata(item, plot=plot_text, playcount=0)

    art = {}
    if logo:
        art['icon'] = logo
        art['thumb'] = logo
    if fanart:
        art['fanart'] = fanart
    if art:
        item.setArt(art)
    return item
