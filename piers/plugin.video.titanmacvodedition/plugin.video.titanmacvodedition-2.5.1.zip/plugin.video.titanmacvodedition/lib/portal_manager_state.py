# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

"""Portal Manager preferences and automatic MAC maintenance."""
import datetime
import json

import xbmc
import xbmcaddon
import xbmcgui

from .constants import PORTAL_WARNING_DAYS
from .portal_manager_data import (ADDON_ID, STATE_PATH, _load_state, _save_state, _log,
                                  load_portals, normalize_portal_url)
from .portal_manager_import import update_portal
from .portal_manager_status import _mac_exp, days_left

def get_portal_view_preferences():
    """Return persisted Portal Manager search/filter preferences."""
    state = _load_state()
    mode = str(state.get('portal_filter_mode') or 'all')
    if mode not in ('all', 'active', 'urgent', 'expired', 'error'):
        mode = 'all'
    return {
        'query': str(state.get('portal_search_query') or ''),
        'filter': mode,
    }

def set_portal_view_preferences(query=None, filter_mode=None):
    """Persist Portal Manager search/filter preferences without touching portals."""
    state = _load_state()
    if query is not None:
        state['portal_search_query'] = str(query).strip()
    if filter_mode is not None:
        mode = str(filter_mode)
        state['portal_filter_mode'] = mode if mode in (
            'all', 'active', 'urgent', 'expired', 'error') else 'all'
    _save_state(state)
    return get_portal_view_preferences()

def get_auto_switch_days():
    """Return the global remaining-days threshold for automatic MAC changes."""
    state = _load_state()
    try:
        value = int(state.get('auto_switch_days', 10))
    except (TypeError, ValueError):
        value = 10
    return max(0, min(365, value))

def set_auto_switch_days(days):
    """Persist the global remaining-days threshold used by daily maintenance."""
    value = max(0, min(365, int(days)))
    state = _load_state()
    state['auto_switch_days'] = value
    _save_state(state)
    return value

def get_last_auto_switch(portal_url=''):
    """Return the most recent automatic MAC change, optionally for one portal."""
    event = _load_state().get('last_auto_switch') or {}
    if portal_url and normalize_portal_url(event.get('portal', '')) != normalize_portal_url(portal_url):
        return {}
    return event if isinstance(event, dict) else {}

def _record_auto_switch(portal, old_mac, new_mac, threshold, old_days, new_days):
    state = _load_state()
    state['last_auto_switch'] = {
        'timestamp': datetime.datetime.now().replace(microsecond=0).isoformat(),
        'portal': normalize_portal_url(portal.get('portal', '')),
        'portal_name': portal.get('name') or '',
        'old_mac': (old_mac or '').upper(),
        'new_mac': (new_mac or '').upper(),
        'threshold_days': int(threshold),
        'old_days': old_days,
        'new_days': new_days,
        'reason': 'Restlaufzeit unter oder gleich {} Tagen'.format(threshold),
        'date': datetime.date.today().isoformat(),
    }
    _save_state(state)

def _mac_explicitly_usable(entry):
    """Reject candidates explicitly marked invalid; legacy entries remain eligible."""
    if not isinstance(entry, dict):
        return False
    for key in ('working', 'works', 'valid', 'stream_ok'):
        if key in entry and entry.get(key) is False:
            return False
    status = str(entry.get('status') or '').strip().lower()
    if status in ('invalid', 'failed', 'offline', 'dead', 'expired', 'error'):
        return False
    d = days_left(_mac_exp(entry))
    return d is None or d >= 0

def _best_automatic_replacement(portal, current_mac, current_days):
    """Choose a different usable MAC with a strictly longer known lifetime."""
    candidates = []
    for entry in portal.get('macs', []):
        mac = (entry.get('mac') or '').upper()
        if not mac or mac == (current_mac or '').upper() or not _mac_explicitly_usable(entry):
            continue
        d = days_left(_mac_exp(entry))
        # Unknown expiry must not replace a MAC with a known expiry automatically.
        if d is None or current_days is None or d <= current_days:
            continue
        candidates.append((d, mac, entry))
    return max(candidates, key=lambda item: (item[0], item[1]))[2] if candidates else None

def warn_active_mac_once_daily():
    """Warn about expiry and automatically replace an expired MAC in auto mode."""
    addon = xbmcaddon.Addon(id=ADDON_ID)
    current_portal = normalize_portal_url(addon.getSetting('server_address'))
    current_mac = addon.getSetting('mac_address').upper()
    if not current_portal or not current_mac:
        return
    for portal in load_portals():
        if portal.get('portal') != current_portal:
            continue
        entry = next((m for m in portal.get('macs', []) if m.get('mac','').upper() == current_mac), None)
        if not entry:
            return
        d = days_left(_mac_exp(entry))

        # In automatic mode, replace the active MAC once it reaches the
        # configured remaining-days threshold. The replacement must actually
        # be better than the current MAC, otherwise the current selection stays.
        switch_days = get_auto_switch_days()
        if d is not None and d <= switch_days and portal.get('auto_mac', True):
            last_switch = get_last_auto_switch(current_portal)
            already_switched_today = (
                last_switch.get('date') == datetime.date.today().isoformat()
                and (last_switch.get('new_mac') or '').upper() == current_mac)
            if already_switched_today:
                return
            replacement = _best_automatic_replacement(portal, current_mac, d)
            replacement_days = days_left(_mac_exp(replacement or {}))
            if replacement:
                new_mac = replacement.get('mac', '').upper()
                portal['active_mac'] = new_mac
                update_portal(portal)
                addon.setSetting('server_address', portal.get('portal', ''))
                addon.setSetting('mac_address', new_mac)
                _record_auto_switch(
                    portal, current_mac, new_mac, switch_days, d, replacement_days)
                xbmcgui.Dialog().notification(
                    'MAC automatisch gewechselt',
                    '{} → {} (Schwelle: {} Tage)'.format(current_mac, new_mac, switch_days),
                    xbmcgui.NOTIFICATION_WARNING, 8000)
                _log('MAC automatically replaced at {} days: {} -> {}'.format(
                    switch_days, current_mac, new_mac))
                return

        if d is None or d > PORTAL_WARNING_DAYS:
            return
        state = _load_state(); key = '{}|{}'.format(current_portal, current_mac)
        today = datetime.date.today().isoformat()
        if state.get('warnings', {}).get(key) == today:
            return
        state.setdefault('warnings', {})[key] = today; _save_state(state)
        if d < 0:
            msg = 'Die aktuell gewählte MAC ist abgelaufen.'
        elif d == 0:
            msg = 'Die aktuell gewählte MAC läuft heute ab.'
        else:
            msg = 'Die aktuell gewählte MAC läuft in {} Tagen ab.'.format(d)
        xbmcgui.Dialog().notification('MAC-Ablaufwarnung', msg, xbmcgui.NOTIFICATION_WARNING, 7000)
        return

def run_daily_maintenance():
    """Run lightweight once-daily portal maintenance.

    This performs schema migration while loading the portal files and checks the
    active MAC warning/automatic replacement. It intentionally does not probe
    portals or build the channel index in the background.
    """
    state = _load_state()
    today = datetime.date.today().isoformat()
    if state.get('last_maintenance') == today:
        return False
    load_portals(import_legacy=True)
    warn_active_mac_once_daily()
    state = _load_state()
    state['last_maintenance'] = today
    _save_state(state)
    _log('Tägliche Portalwartung abgeschlossen')
    return True

