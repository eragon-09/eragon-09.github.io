# -*- coding: utf-8 -*-
"""Portal JSON schema migration and validation helpers."""
from __future__ import absolute_import, division, unicode_literals

from urllib.parse import urlparse

from .constants import PORTAL_SCHEMA_VERSION


def migrate_portal_record(data, normalize_url):
    """Return ``(record, changed)`` upgraded to the current portal schema.

    Older exports used ``source_file`` and occasionally plain MAC strings.
    Migration is deliberately lossless: unknown fields are kept.
    """
    record = dict(data or {})
    before = repr(record)
    record['portal'] = normalize_url(record.get('portal', ''))
    record.setdefault('name', urlparse(record.get('portal', '')).hostname or record.get('portal', ''))

    source_files = record.get('source_files')
    if not isinstance(source_files, list):
        source_files = []
    legacy_source = record.pop('source_file', None)
    if legacy_source and legacy_source not in source_files:
        source_files.append(legacy_source)
    record['source_files'] = [str(item) for item in source_files if item]

    clean_macs = []
    seen = set()
    for item in record.get('macs') or []:
        if isinstance(item, dict):
            clean = dict(item)
            mac = str(clean.get('mac', '')).strip().upper()
            exp = clean.get('exp') or clean.get('expiry') or clean.get('expires') or clean.get('expiration') or clean.get('date') or ''
        else:
            clean = {}
            mac = str(item).strip().upper()
            exp = ''
        if not mac or mac in seen:
            continue
        seen.add(mac)
        clean['mac'] = mac
        clean['exp'] = str(exp).strip() if exp else ''
        clean_macs.append(clean)
    record['macs'] = clean_macs
    record['active_mac'] = str(record.get('active_mac') or '').strip().upper()
    record['auto_mac'] = bool(record.get('auto_mac', True))
    record['schema'] = PORTAL_SCHEMA_VERSION
    return record, before != repr(record)


def portal_counts(portals):
    """Return compact statistics used by the manager overview."""
    total = valid = expired = unknown = 0
    for portal in portals or []:
        for entry in portal.get('macs', []):
            total += 1
            state = entry.get('_expiry_state')
            if state == 'expired':
                expired += 1
            elif state == 'valid':
                valid += 1
            else:
                unknown += 1
    return {'portals': len(portals or []), 'macs': total, 'valid': valid,
            'expired': expired, 'unknown': unknown}
