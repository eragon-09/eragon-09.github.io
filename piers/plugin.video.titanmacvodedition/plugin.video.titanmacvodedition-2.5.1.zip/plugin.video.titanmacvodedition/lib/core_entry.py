# -*- coding: utf-8 -*-
"""
Titan Core Mod — lokale Portal/MAC-Integration.

Integrierte Funktionen aus plugin.program.local.portal.mac.switcher:
- lokale JSON-Portalquelle automatisch erkennen
- MAC-Ablaufdatum anzeigen und abgelaufene MACs filtern
- Zufalls-MAC nur aus Einträgen mit > 30 Tagen Restlaufzeit
- letzte lokale Portal/MAC-Auswahl persistent speichern
- optionale PVR-Stalker-Aktualisierung
"""
from __future__ import absolute_import, division, unicode_literals

import json
import os
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .loggers import Logger

from .core_support import (
    STALKER_ID, TITLE, DATA_ID, PORTAL_DIR_CANDIDATES, LOCAL_TOKEN_DIR,
    LOCAL_TOKEN_PATH, PVR_DIR_CANDIDATES, _URL_RE, _MAC_RE, _log, _val_error,
    _exists, _ensure_dir, _read_text, _write_text, _cachebust, _is_valid_url,
    _hostname_from_url, _hostname_from_filename, _days_left, _exp_display,
    _mac_desc, _resolve_portal_dir, _valid_macs, _load_local_cfg,
    _load_all_local_cfgs, _save_local_token, _load_local_token,
    _persist_settings,
)

# State
selected_portal = None
selected_portal_url = None
selected_server_index = None
selected_server_id = None
selected_mac = None
selected_mac_label = None
selected_mac_exp = None
selected_source = None  # 'remote' or 'local'
selected_local_file = None
selected_local_cfg = None



def _clear_mac_state():
    global selected_mac, selected_mac_label, selected_mac_exp
    selected_mac = None
    selected_mac_label = None
    selected_mac_exp = None
    _persist_settings(mac="")


def _addon_data_path():
    try:
        return xbmcvfs.translatePath("special://profile/addon_data/%s/" % STALKER_ID)
    except Exception:
        return ""


def clear_portal_cache_files():
    base = _addon_data_path()
    if not base:
        return

    # Delete token and portal EPG cache files
    for fn in ("token.json", "epg.json"):
        p = base + fn
        try:
            if xbmcvfs.exists(p):
                xbmcvfs.delete(p)
        except Exception:
            pass

    # Delete all zap context files (zap_*.json)
    try:
        import glob
        for zap_file in glob.glob(os.path.join(base, "zap_*.json")):
            try:
                os.remove(zap_file)
            except Exception:
                pass
    except Exception:
        pass

    # Clear in-memory EPG cache (portal)
    try:
        from .api import clear_epg_cache  # correct relative import
        clear_epg_cache()
    except Exception:
        pass

    # Clear XMLTV cache (disk + memory) – XMLTV is portal-specific via channel mapping
    try:
        from .xmltv import clear_xmltv_cache
        clear_xmltv_cache()
    except Exception:
        pass


def _reset_runtime_state():
    try:
        from .globals import G
        G.init_globals()
    except Exception:
        pass
    try:
        from .auth import Auth
        Auth().clear_cache()
    except Exception:
        pass


def _go_home(portal_name=None, mac=None):
    try:
        if portal_name:
            msg = portal_name
            if mac:
                msg = "%s\nMAC: %s" % (portal_name, mac)
            xbmcgui.Dialog().notification(TITLE, msg, xbmcgui.NOTIFICATION_INFO, 3500)
    except Exception:
        pass
    # Brief pause so Kodi flushes the written settings to disk before the
    # new plugin process starts and reads them via xbmcaddon.Addon(id=...).
    xbmc.sleep(300)
    _reset_runtime_state()
    try:
        xbmc.executebuiltin("Container.Update(plugin://%s/,replace)" % STALKER_ID)
    except Exception:
        pass


def manual_clear_cache():
    try:
        confirmed = xbmcgui.Dialog().yesno(TITLE, "Willst du wirklich den Cache löschen?")
    except Exception:
        confirmed = True
    if not confirmed:
        return

    # clear_portal_cache_files already handles: token, epg, zap files, XMLTV disk+memory, in-memory EPG
    clear_portal_cache_files()
    _reset_runtime_state()

    try:
        xbmcgui.Dialog().notification(TITLE, "Cache vollständig gelöscht (EPG, Token, XMLTV, Zapping)", xbmcgui.NOTIFICATION_INFO, 3500)
    except Exception:
        pass

    try:
        xbmc.executebuiltin("Container.Update(plugin://%s/,replace)" % STALKER_ID)
    except Exception:
        try:
            xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass


def _rehydrate_selection_from_settings():
    """Rebuild the selected portal/MAC from persistent storage.

    Kodi reloads Python modules when the skin changes.  Module globals are then
    empty, so the managed portal JSON is the authoritative source for the MAC
    expiry.  The local token remains only a legacy fallback.
    """
    global selected_portal, selected_portal_url, selected_server_index, selected_server_id
    global selected_source, selected_local_file, selected_local_cfg
    global selected_mac, selected_mac_exp, selected_mac_label

    try:
        addon = xbmcaddon.Addon(id=STALKER_ID)
        stored_url = addon.getSetting("server_address") or ""
        stored_mac = (addon.getSetting("mac_address") or "").strip().upper()
    except Exception:
        stored_url = ""
        stored_mac = ""

    # Canonical managed-portal restore: always re-read *.portal.json and resolve
    # the configured/active MAC there.  This keeps the expiry visible after a
    # skin reload and avoids relying on stale in-memory state or token metadata.
    if stored_url:
        try:
            from . import portal_manager as pm
            wanted_url = pm.normalize_portal_url(stored_url)
            portal = next(
                (item for item in pm.load_portals()
                 if pm.normalize_portal_url(item.get('portal', '')) == wanted_url),
                None)
            if portal:
                active_mac = stored_mac or (portal.get('active_mac') or '').strip().upper()
                mac_entry = next(
                    (item for item in portal.get('macs', [])
                     if (item.get('mac') or '').strip().upper() == active_mac),
                    None)
                if mac_entry is None and portal.get('active_mac'):
                    active_mac = (portal.get('active_mac') or '').strip().upper()
                    mac_entry = next(
                        (item for item in portal.get('macs', [])
                         if (item.get('mac') or '').strip().upper() == active_mac),
                        None)

                selected_source = 'managed'
                selected_local_cfg = portal
                selected_local_file = os.path.basename(portal.get('_path', '')) or None
                selected_portal_url = portal.get('portal') or stored_url
                selected_portal = portal.get('name') or _hostname_from_url(selected_portal_url)
                selected_server_index = None
                selected_server_id = None
                selected_mac = mac_entry.get('mac') if mac_entry else (active_mac or None)
                selected_mac_exp = pm._mac_exp(mac_entry or {}) or None
                selected_mac_label = pm.expiry_label(selected_mac_exp) if selected_mac else None

                # Refresh the compatibility token with the date from JSON.  It
                # is not used as the primary source, but remains correct for
                # older call paths.
                if selected_mac:
                    _save_local_token(
                        selected_local_file, selected_portal_url,
                        selected_mac, selected_mac_exp)
                return True
        except Exception as exc:
            _log('Managed portal restore failed: {}'.format(exc), xbmc.LOGWARNING)

    # Legacy converter JSON/token fallback.
    portal_dir = _resolve_portal_dir()
    token = _load_local_token(portal_dir)
    if token and token.get("selected_portal_url"):
        selected_source = "local"
        selected_local_file = token.get("selected_file")
        selected_local_cfg = token.get("cfg")
        selected_portal_url = token.get("selected_portal_url")
        selected_portal = token.get("cfg", {}).get("_hostname") or _hostname_from_url(selected_portal_url)
        selected_mac = token.get("selected_mac")
        selected_mac_exp = token.get("selected_mac_exp")
        selected_mac_label = _exp_display(selected_mac_exp) if selected_mac else None
        return True

    if not stored_url:
        return False

    selected_source = "manual"
    selected_portal_url = stored_url
    selected_portal = _hostname_from_url(stored_url) or "Manuelles Portal"
    selected_server_index = None
    selected_server_id = None
    selected_local_file = None
    selected_local_cfg = None
    selected_mac = stored_mac or None
    selected_mac_exp = None
    selected_mac_label = None
    return True


# -----------------------------
# Public actions
# -----------------------------
def _activate_managed_portal(portal, mac_entry=None, manual=False, refresh_home=True):
    """Persist a managed portal/MAC and optionally refresh the add-on home.

    During first-run setup ``refresh_home`` is disabled. Starting a nested
    ``Container.Update`` before the current plugin call has completed can make
    the new process read the old, still-empty settings from disk.
    """
    global selected_portal, selected_portal_url, selected_source, selected_local_cfg
    global selected_local_file, selected_mac, selected_mac_exp, selected_mac_label
    from . import portal_manager as pm

    selected_portal = portal.get('name') or _hostname_from_url(portal.get('portal'))
    selected_portal_url = portal.get('portal')
    selected_source = 'managed'
    selected_local_cfg = portal
    selected_local_file = os.path.basename(portal.get('_path', '')) or None

    if mac_entry is None:
        active = (portal.get('active_mac') or '').upper()
        if active:
            mac_entry = next((m for m in portal.get('macs', []) if m.get('mac', '').upper() == active), None)
        if mac_entry is None:
            mac_entry = pm.best_mac(portal)
    selected_mac = mac_entry.get('mac') if mac_entry else None
    selected_mac_exp = mac_entry.get('exp') if mac_entry else None
    selected_mac_label = pm.expiry_label(selected_mac_exp) if selected_mac else None

    auto_was_on = bool(portal.get('auto_mac', True))
    if selected_mac:
        portal['active_mac'] = selected_mac
        portal['auto_mac'] = not manual
        pm.update_portal(portal)
    clear_portal_cache_files()
    if not selected_portal_url or not selected_mac:
        xbmcgui.Dialog().ok(TITLE, 'Portal oder MAC ist ungültig und konnte nicht aktiviert werden.')
        return False
    if not _persist_settings(server_url=selected_portal_url, mac=selected_mac):
        xbmcgui.Dialog().ok(TITLE, 'Portal und MAC konnten nicht in den Kodi-Einstellungen gespeichert werden.')
        return False
    _save_local_token(selected_local_file, selected_portal_url, selected_mac, selected_mac_exp)
    _reset_runtime_state()
    if manual and auto_was_on:
        xbmcgui.Dialog().ok(
            'Manuelle MAC-Auswahl',
            'Die automatische MAC-Auswahl wurde deaktiviert.\n\n'
            'Die ausgewählte MAC bleibt aktiv, bis Sie die Automatik wieder einschalten.')
    if refresh_home:
        _go_home(portal_name=selected_portal, mac=selected_mac)
    return True


def activate_managed_mac_action(portal_url, mac, refresh_home=True):
    """Resolve portal and MAC from storage, confirm them and activate them.

    This is the canonical action behind both the portal button and first-run
    setup.  Callers pass only stable identifiers; the portal record and MAC
    entry are always reloaded from the portal database before activation.
    """
    from . import portal_manager as pm

    wanted_url = pm.normalize_portal_url(portal_url or '')
    wanted_mac = str(mac or '').strip().upper()
    if not wanted_url or not wanted_mac:
        xbmcgui.Dialog().ok(TITLE, 'Portal oder MAC-Adresse ist ungültig.')
        return False

    portals = pm.load_portals()
    portal = next((entry for entry in portals
                   if pm.normalize_portal_url(entry.get('portal', '')) == wanted_url), None)
    if portal is None:
        xbmcgui.Dialog().ok(TITLE, 'Das ausgewählte Portal wurde nicht mehr gefunden.')
        return False

    choice = next((entry for entry in portal.get('macs', [])
                   if str(entry.get('mac', '')).strip().upper() == wanted_mac), None)
    if choice is None:
        xbmcgui.Dialog().ok(TITLE, 'Die ausgewählte MAC-Adresse wurde nicht mehr gefunden.')
        return False

    if not xbmcgui.Dialog().yesno(
            TITLE,
            'Diese MAC aktivieren?\n\n{}\n{}'.format(
                choice.get('mac'), pm.expiry_label(pm._mac_exp(choice)))):
        return False

    return bool(_activate_managed_portal(
        portal, choice, manual=True, refresh_home=refresh_home))


def _confirm_and_activate_managed_mac(portal, choice, refresh_home=True):
    """Compatibility wrapper for the canonical activation action."""
    return activate_managed_mac_action(
        portal.get('portal', '') if portal else '',
        choice.get('mac', '') if choice else '',
        refresh_home=refresh_home)


def _choose_managed_mac(portal):
    from . import portal_manager as pm
    macs = pm.sorted_macs(portal)
    if not macs:
        xbmcgui.Dialog().ok(TITLE, 'Für dieses Portal sind noch keine MAC-Adressen gespeichert.')
        return
    try:
        configured_mac = xbmcaddon.Addon(id=STALKER_ID).getSetting('mac_address').upper()
    except Exception:
        configured_mac = ''
    active = configured_mac or (portal.get('active_mac') or '').upper()
    labels = []
    for m in macs:
        mac = m.get('mac', '').upper()
        if mac == active:
            mac_label = '[COLOR lime]* {}[/COLOR]'.format(mac)
        else:
            mac_label = '[COLOR white]{}[/COLOR]'.format(mac)
        labels.append('{}  {}'.format(mac_label, pm.expiry_label(pm._mac_exp(m))))
    title = 'Aktive MAC: {}'.format(active) if active else 'MAC-Adresse auswählen'
    idx = xbmcgui.Dialog().select(title, labels)
    if idx < 0:
        return
    choice = macs[idx]
    _confirm_and_activate_managed_mac(portal, choice, refresh_home=True)


def _portal_actions(portal):
    from . import portal_manager as pm
    while True:
        auto_label = 'Automatik deaktivieren' if portal.get('auto_mac', True) else 'Automatisch beste MAC verwenden'
        options = [
            '[COLOR lime]Portal aktivieren[/COLOR]',
            'MAC-Adresse manuell auswählen',
            auto_label,
            'Portalstatus prüfen',
            'Portal-Details',
            'Portal-Analyse',
            '',
            '[COLOR red]Portal entfernen[/COLOR]',
        ]
        idx = xbmcgui.Dialog().select(portal.get('name') or 'Portal', options)
        if idx < 0:
            return
        if idx == 0:
            entry = pm.best_mac(portal) if portal.get('auto_mac', True) else None
            _activate_managed_portal(portal, entry, manual=not portal.get('auto_mac', True))
            return
        if idx == 1:
            _choose_managed_mac(portal)
            return
        if idx == 2:
            if portal.get('auto_mac', True):
                portal['auto_mac'] = False
                xbmcgui.Dialog().notification(TITLE, 'Manuell gewählte MAC wird beibehalten.', xbmcgui.NOTIFICATION_INFO, 3500)
            else:
                portal['auto_mac'] = True
                best = pm.best_mac(portal)
                if best:
                    portal['active_mac'] = best.get('mac', '')
                xbmcgui.Dialog().notification(TITLE, 'Beste gültige MAC wird automatisch verwendet.', xbmcgui.NOTIFICATION_INFO, 3500)
            pm.update_portal(portal)
        elif idx == 3:
            online, status = pm.portal_health(portal)
            status_color = 'lime' if online else ('red' if online is False else 'yellow')
            xbmcgui.Dialog().ok(TITLE, '[COLOR {}]{}[/COLOR]\n\n{}'.format(status_color, portal.get('name') or portal.get('portal'), status))
        elif idx == 4:
            active_mac = (portal.get('active_mac') or '').upper()
            active_entry = next((m for m in portal.get('macs', []) if m.get('mac','').upper() == active_mac), None)
            valid = sum(1 for m in portal.get('macs', []) if pm.days_left(pm._mac_exp(m)) is None or pm.days_left(pm._mac_exp(m)) >= 0)
            urgent = sum(1 for m in portal.get('macs', []) if pm.days_left(pm._mac_exp(m)) is not None and 0 <= pm.days_left(pm._mac_exp(m)) <= 10)
            expired = sum(1 for m in portal.get('macs', []) if pm.days_left(pm._mac_exp(m)) is not None and pm.days_left(pm._mac_exp(m)) < 0)
            sources = ', '.join(portal.get('source_files') or []) or 'manuell/unbekannt'
            xbmcgui.Dialog().ok(TITLE, 'Portal: {}\nURL: {}\nMACs: {}\nAktive MAC: {}\nAblauf: {}\nGültig/unbekannt: {}\n≤10 Tage: {}\nAbgelaufen: {}\nModus: {}\nLetzter Import: {}\nQuelle: {}'.format(
                portal.get('name'), portal.get('portal'), len(portal.get('macs', [])), active_mac or 'keine',
                pm.expiry_label(pm._mac_exp(active_entry or {})), valid, urgent, expired,
                'Automatisch' if portal.get('auto_mac', True) else 'Manuell',
                portal.get('last_import') or 'unbekannt', sources))
        elif idx == 5:
            if xbmcgui.Dialog().yesno(TITLE, 'Portal wirklich entfernen?\n\n{}\n{} MAC-Adressen\n\nDieser Vorgang kann nur über eine Sicherung rückgängig gemacht werden.'.format(portal.get('name'), len(portal.get('macs', [])))):
                pm.delete_portal(portal)
                xbmcgui.Dialog().notification(TITLE, 'Portal entfernt', xbmcgui.NOTIFICATION_INFO, 3000)
                return


def _add_portal_menu():
    """Import portals from one or more TXT files or enter one manually."""
    from . import portal_manager as pm
    options = ['Portal-TXT importieren', 'Portal manuell hinzufügen']
    idx = xbmcgui.Dialog().select('Portal importieren', options)
    if idx < 0:
        return
    if idx == 0:
        portals, hits = pm.import_txt_selection()
    else:
        portal = pm.add_manual_portal()
        portals, hits = (1, len(portal.get('macs', []))) if portal else (0, 0)
    if portals:
        xbmcgui.Dialog().notification(
            TITLE, '{} Portal(e) hinzugefügt · {} MACs'.format(portals, hits),
            xbmcgui.NOTIFICATION_INFO, 5000)


def _managed_portal_context(pm):
    """Return portals plus the configured portal/MAC from legacy settings."""
    portals = pm.load_portals()
    try:
        addon = xbmcaddon.Addon(id=STALKER_ID)
        configured_url = pm.normalize_portal_url(addon.getSetting('server_address'))
        configured_mac = addon.getSetting('mac_address').upper()
    except Exception:
        configured_url = ''
        configured_mac = ''
    # Compare normalized URLs on both sides. Older imports may store /c,
    # portal.php or a trailing slash differently than the legacy setting.
    active = next((p for p in portals
                   if pm.normalize_portal_url(p.get('portal', '')) == configured_url), None)
    return portals, configured_url, configured_mac, active


def _portal_manager_heading(active, configured_mac=''):
    """Compact heading that keeps the active state visible in every dialog."""
    if not active:
        return 'Portal Manager – kein Portal aktiv'
    name = active.get('name') or _hostname_from_url(active.get('portal', ''))
    return 'Portal Manager – {}'.format(name)


def _stage_managed_portal(portal):
    """Activate a portal with its preferred MAC without leaving the manager.

    The regular portal list uses this lightweight hand-off before opening the
    MAC picker.  It keeps the common action to one click while avoiding the
    old portal-action submenu.
    """
    from . import portal_manager as pm
    entry = None
    active_mac = (portal.get('active_mac') or '').upper()
    if active_mac:
        entry = next((m for m in portal.get('macs', [])
                      if m.get('mac', '').upper() == active_mac), None)
    if entry is None:
        entry = pm.best_mac(portal)
    if entry is None:
        xbmcgui.Dialog().ok(TITLE, 'Für dieses Portal ist keine MAC gespeichert.')
        return False

    mac = entry.get('mac', '').upper()
    portal['active_mac'] = mac
    pm.update_portal(portal)
    clear_portal_cache_files()
    if not _persist_settings(server_url=portal.get('portal', ''), mac=mac):
        xbmcgui.Dialog().ok(TITLE, 'Portal und MAC konnten nicht in den Kodi-Einstellungen gespeichert werden.')
        return False
    _save_local_token(os.path.basename(portal.get('_path', '')) or None,
                      portal.get('portal', ''), mac, pm._mac_exp(entry))
    _reset_runtime_state()
    return True


def _portal_status_overview():
    """Show overview and status actions for the currently active portal."""
    from . import portal_manager as pm
    from . import portal_dashboard as dashboard
    while True:
        portals, configured_url, configured_mac, active = _managed_portal_context(pm)
        idx = xbmcgui.Dialog().select('Portalinformationen', [
            'Portalübersicht',
            'Portalstatus prüfen',
            'Portal-Details',
            'Portal-Analyse',
            '[COLOR red]Portal entfernen[/COLOR]',
        ])
        if idx < 0:
            return
        if idx == 0:
            xbmcgui.Dialog().ok(
                'Portalübersicht',
                dashboard.dashboard_text(
                    portals, pm.days_left, pm._mac_exp, pm.get_auto_switch_days()))
            continue
        if not active:
            xbmcgui.Dialog().ok(TITLE, 'Bitte zuerst ein Portal aktivieren.')
            continue
        if idx == 1:
            online, status = pm.portal_health(active)
            status_color = 'lime' if online else ('red' if online is False else 'yellow')
            xbmcgui.Dialog().ok(
                TITLE, '[COLOR {}]{}[/COLOR]\n\n{}'.format(
                    status_color, active.get('name') or active.get('portal'), status))
        elif idx == 2:
            active_mac = (active.get('active_mac') or configured_mac or '').upper()
            active_entry = next((m for m in active.get('macs', [])
                                 if m.get('mac', '').upper() == active_mac), None)
            valid = sum(1 for m in active.get('macs', [])
                        if pm.days_left(pm._mac_exp(m)) is None
                        or pm.days_left(pm._mac_exp(m)) >= 0)
            urgent = sum(1 for m in active.get('macs', [])
                         if pm.days_left(pm._mac_exp(m)) is not None
                         and 0 <= pm.days_left(pm._mac_exp(m)) <= pm.get_auto_switch_days())
            expired = sum(1 for m in active.get('macs', [])
                          if pm.days_left(pm._mac_exp(m)) is not None
                          and pm.days_left(pm._mac_exp(m)) < 0)
            sources = ', '.join(active.get('source_files') or []) or 'manuell/unbekannt'
            last_switch = pm.get_last_auto_switch(active.get('portal', ''))
            if last_switch:
                timestamp = (last_switch.get('timestamp') or 'unbekannt').replace('T', ' ')
                switch_info = '{}\n{} → {}\nGrund: {}'.format(
                    timestamp,
                    '{} ({} Tage)'.format(
                        last_switch.get('old_mac') or 'unbekannt',
                        last_switch.get('old_days') if last_switch.get('old_days') is not None else '?'),
                    '{} ({} Tage)'.format(
                        last_switch.get('new_mac') or 'unbekannt',
                        last_switch.get('new_days') if last_switch.get('new_days') is not None else '?'),
                    last_switch.get('reason') or 'automatische Auswahl')
            else:
                switch_info = 'noch kein automatischer Wechsel'
            current_days = pm.days_left(pm._mac_exp(active_entry or {}))
            if not active.get('auto_mac', True):
                next_switch = 'deaktiviert'
            elif current_days is None:
                next_switch = 'Ablaufdatum unbekannt'
            elif current_days <= pm.get_auto_switch_days():
                next_switch = 'bei der nächsten täglichen Prüfung'
            else:
                next_switch = 'in {} Tagen (Schwelle {} Tage)'.format(
                    current_days - pm.get_auto_switch_days(), pm.get_auto_switch_days())
            xbmcgui.Dialog().ok(TITLE, (
                'Portal: {}\nURL: {}\nMACs: {}\nAktive MAC: {}\nAblauf: {}\n'
                'Gültig/unbekannt: {}\nBis zur Wechselschwelle: {}\nAbgelaufen: {}\n'
                'MAC-Modus: {}\nAutomatische beste MAC: {}\nMAC-Wechsel bei Restlaufzeit: {} Tage\n'
                'Nächster automatischer Wechsel: {}\n\nLetzter automatischer Wechsel:\n{}\n\n'
                'Letzter Import: {}\nQuelle: {}').format(
                    active.get('name'), active.get('portal'), len(active.get('macs', [])),
                    active_mac or 'keine', pm.expiry_label(pm._mac_exp(active_entry or {})),
                    valid, urgent, expired,
                    'Automatisch' if active.get('auto_mac', True) else 'Manuell',
                    'Ein' if active.get('auto_mac', True) else 'Aus',
                    pm.get_auto_switch_days(), next_switch, switch_info,
                    active.get('last_import') or 'unbekannt', sources))
        elif idx == 3:
            xbmcgui.Dialog().ok('Portal-Analyse', pm.portal_analysis_text(active))
        elif idx == 4:
            _interactive_epg_diagnostics()
        elif idx == 5:
            if xbmcgui.Dialog().yesno(
                    TITLE, 'Portal wirklich entfernen?\n\n{}\n{} MAC-Adressen\n\n'
                    'Dieser Vorgang kann nur über eine Sicherung rückgängig gemacht werden.'.format(
                        active.get('name'), len(active.get('macs', [])))):
                pm.delete_portal(active)
                _persist_settings(server_url='', mac='')
                _reset_runtime_state()
                xbmcgui.Dialog().notification(
                    TITLE, 'Portal entfernt', xbmcgui.NOTIFICATION_INFO, 3000)
                return



def _interactive_epg_diagnostics():
    """Inspect and export decisions collected by the real runtime matcher."""
    from .xmltv import (clear_live_epg_trace, export_live_epg_trace,
                        get_live_epg_trace_status)
    while True:
        status = get_live_epg_trace_status()
        options = [
            'Live-Trace-Status ({} Einträge)'.format(status.get('entries') or 0),
            'Live-Trace exportieren (TXT + JSON)',
            'Live-Trace löschen',
            'XMLTV-Eingangsdiagnose erstellen',
        ]
        idx = xbmcgui.Dialog().select('', options)
        if idx < 0:
            return
        if idx == 0:
            xbmcgui.Dialog().textviewer(
                ' – Status',
                'Der Trace wird automatisch geschrieben, wenn Live-TV einen Sender '
                'anzeigt und der normale Portal-EPG keinen Eintrag liefert.\n\n'
                'Einträge: {}\nTreffer: {}\nOhne Treffer: {}\n\nRohdatei:\n{}\n\n'
                'Für einen aussagekräftigen Bericht zuerst die problematischen '
                'Senderlisten öffnen, danach den Trace exportieren.'.format(
                    status.get('entries') or 0, status.get('matched') or 0,
                    status.get('unmatched') or 0, status.get('path') or 'nicht verfügbar'),
                usemono=True)
        elif idx == 1:
            paths = export_live_epg_trace()
            if paths:
                xbmcgui.Dialog().textviewer(
                    ' exportiert',
                    'Laufzeitentscheidungen: {}\nEindeutige Sender: {}\n\nTXT:\n{}\n\nJSON:\n{}\n\nRohdatei:\n{}'.format(
                        paths.get('entries') or 0, paths.get('unique_channels') or 0,
                        paths.get('txt') or 'Fehler', paths.get('json') or 'Fehler',
                        paths.get('raw') or 'nicht verfügbar'), usemono=True)
            else:
                xbmcgui.Dialog().ok('', 'Der Trace konnte nicht exportiert werden.')
        elif idx == 2:
            if xbmcgui.Dialog().yesno('', 'Gesammelten Live-Trace wirklich löschen?'):
                clear_live_epg_trace()
                xbmcgui.Dialog().notification(TITLE, ' gelöscht', xbmcgui.NOTIFICATION_INFO, 3000)
        elif idx == 3:
            try:
                from .xmltv import export_xmltv_input_diagnostics
                paths = export_xmltv_input_diagnostics()
            except Exception as exc:
                paths = {}
                Logger.error('XMLTV input diagnostics failed: {}'.format(exc))
            if paths:
                xbmcgui.Dialog().textviewer(
                    'XMLTV-Eingangsdiagnose erstellt',
                    'Die Diagnose wurde manuell ausgeführt. EPG- und XMLTV-Caches wurden nicht verändert.\n\n'
                    'TXT:\n{}\n\nJSON:\n{}'.format(
                        paths.get('txt') or 'Fehler', paths.get('json') or 'Fehler'),
                    usemono=True)
            else:
                xbmcgui.Dialog().ok('XMLTV-Eingangsdiagnose', 'Die Diagnose konnte nicht erstellt werden.')

def _select_portal_for_actions():
    """Select a portal and open its less frequently used actions."""
    from . import portal_manager as pm
    portals, configured_url, _configured_mac, _active = _managed_portal_context(pm)
    if not portals:
        xbmcgui.Dialog().ok(TITLE, 'Es sind noch keine Portale gespeichert.')
        return
    labels = [pm.portal_card_label(
        portal,
        active=(pm.normalize_portal_url(portal.get('portal', '')) == configured_url)
    ) for portal in portals]
    idx = xbmcgui.Dialog().select('Portal für Aktion auswählen', labels)
    if idx >= 0:
        _portal_actions(portals[idx])



def _first_run_select_portal_and_mac(portals):
    """Select only what is necessary and activate the first portal setup."""
    from . import portal_manager as pm

    portals = list(portals or [])
    if not portals:
        xbmcgui.Dialog().ok(TITLE, 'Es wurde kein verwendbares Portal gefunden.')
        return False

    if len(portals) == 1:
        portal = portals[0]
    else:
        labels = [pm.portal_card_label(portal, active=False) for portal in portals]
        index = xbmcgui.Dialog().select('Welches Portal möchten Sie verwenden?', labels)
        if index < 0:
            return False
        portal = portals[index]

    macs = pm.sorted_macs(portal)
    if not macs:
        xbmcgui.Dialog().ok(
            TITLE,
            'Für das ausgewählte Portal wurde keine gültige MAC-Adresse gefunden.\n\n'
            'Bitte wählen Sie eine andere TXT-Datei oder fügen Sie das Portal manuell hinzu.')
        return False

    if len(macs) == 1:
        mac_entry = macs[0]
    else:
        labels = [
            '{}  {}'.format(entry.get('mac', ''), pm.expiry_label(pm._mac_exp(entry)))
            for entry in macs
        ]
        index = xbmcgui.Dialog().select('Welche MAC-Adresse möchten Sie verwenden?', labels)
        if index < 0:
            return False
        mac_entry = macs[index]

    # Mirror the portal button sequence exactly.  The regular portal manager
    # first stages the portal with its preferred MAC.  This writes the initial
    # settings pair, clears portal caches, saves the local selection token and
    # rebuilds the runtime state.  Only afterwards is the explicitly selected
    # MAC confirmed and activated a second time.
    if not _stage_managed_portal(portal):
        return False

    confirmed = _confirm_and_activate_managed_mac(
        portal, mac_entry, refresh_home=False)
    if confirmed:
        xbmcgui.Dialog().notification(
            TITLE, 'Portal wurde aktiviert.', xbmcgui.NOTIFICATION_INFO, 2500)
    return confirmed


def _first_run_manual_portal():
    """Create one manual portal and require a valid MAC for first setup."""
    from . import portal_manager as pm

    portal = pm.add_manual_portal()
    if not portal:
        return False

    macs = pm.sorted_macs(portal)
    if not macs:
        while True:
            mac = xbmcgui.Dialog().input(
                'MAC-Adresse eingeben', type=xbmcgui.INPUT_ALPHANUM).strip().upper()
            if not mac:
                xbmcgui.Dialog().ok(
                    TITLE,
                    'Für die Ersteinrichtung wird eine MAC-Adresse benötigt.')
                return False
            if _MAC_RE.fullmatch(mac):
                portal['macs'] = [{'mac': mac, 'exp': ''}]
                portal['active_mac'] = mac
                pm.update_portal(portal)
                macs = portal['macs']
                break
            xbmcgui.Dialog().ok(TITLE, 'Die eingegebene MAC-Adresse ist ungültig.')

    return _first_run_select_portal_and_mac([portal])


def _first_run_portal_wizard():
    """Guide a new user through setup and activate the first portal."""
    from . import portal_manager as pm

    heading = 'Willkommen bei Titan MAC VOD Edition'
    message = (
        'Es wurde noch kein Portal eingerichtet.\n\n'
        'Wählen Sie eine einfache Einrichtungsmethode.'
    )

    while True:
        try:
            choice = xbmcgui.Dialog().yesnocustom(
                heading, message,
                customlabel='Portal manuell hinzufügen',
                nolabel='Später',
                yeslabel='Portal aus TXT-Datei importieren (empfohlen)')
        except (AttributeError, TypeError):
            choice = xbmcgui.Dialog().select(
                heading,
                [
                    'Portal aus TXT-Datei importieren (empfohlen)',
                    'Portal manuell hinzufügen',
                    'Später',
                ])
            choice = {0: 1, 1: 2, 2: 0}.get(choice, 0)

        if choice == 1:
            before_paths = {
                portal.get('_path') for portal in pm.load_portals() if portal.get('_path')
            }
            imported, hits = pm.import_txt_selection()
            if not imported:
                continue

            portals = pm.load_portals()
            new_portals = [
                portal for portal in portals
                if portal.get('_path') and portal.get('_path') not in before_paths
            ]
            candidates = new_portals or portals
            if _first_run_select_portal_and_mac(candidates):
                return True
            continue

        if choice == 2:
            if _first_run_manual_portal():
                return True
            continue

        return False


def _set_first_run_wizard_done(addon, value):
    """Persist the first-run marker without assuming typed-setting support."""
    try:
        addon.setSettingBool('first_run_portal_wizard_done', bool(value))
    except Exception:
        addon.setSetting('first_run_portal_wizard_done', 'true' if value else 'false')


def ensure_portal_setup_on_addon_open():
    """Ensure that first-run setup produced real, readable Kodi settings.

    The root plugin invocation stays alive after a successful wizard run.  The
    router reloads globals and builds the normal main menu in the same directory
    handle, avoiding a second ``Container.Update``/``RunPlugin`` navigation that
    briefly exposed Kodi's generic file view.
    """
    from . import portal_manager as pm

    addon = xbmcaddon.Addon(id=STALKER_ID)
    try:
        first_open_done = addon.getSettingBool('first_run_portal_wizard_done')
    except Exception:
        first_open_done = addon.getSetting('first_run_portal_wizard_done').lower() == 'true'

    portals, configured_url, configured_mac, active = _managed_portal_context(pm)
    settings_ready = bool(configured_url and configured_mac and active)

    if first_open_done and settings_ready:
        return True

    # Repair old/partial wizard runs: when portals already exist but Kodi has no
    # active server/MAC pair, select from those records instead of pretending
    # setup is complete or forcing another TXT import.
    if portals and not settings_ready:
        configured = _first_run_select_portal_and_mac(portals)
    elif portals and settings_ready:
        configured = True
    else:
        configured = _first_run_portal_wizard()

    if not configured:
        return False

    # Verify through a fresh Addon object before marking setup complete.  Once
    # verified, continue in this same plugin invocation; addon_router reloads G
    # immediately afterwards and then lists the normal root menu.
    verify = xbmcaddon.Addon(id=STALKER_ID)
    stored_server = pm.normalize_portal_url(verify.getSetting('server_address'))
    stored_mac = verify.getSetting('mac_address').strip().upper()
    if not stored_server or not stored_mac:
        _set_first_run_wizard_done(addon, False)
        xbmcgui.Dialog().ok(
            TITLE,
            'Portal und MAC wurden ausgewählt, konnten aber noch nicht aus den '
            'Kodi-Einstellungen gelesen werden. Bitte erneut versuchen.')
        return False

    _set_first_run_wizard_done(verify, True)
    return True


def _further_portal_actions():
    """Show the compact portal-management actions with their current state."""
    from . import portal_manager as pm
    while True:
        portals, configured_url, configured_mac, active = _managed_portal_context(pm)
        auto_on = bool(active and active.get('auto_mac', True))
        switch_days = pm.get_auto_switch_days()
        try:
            addon = xbmcaddon.Addon(id=STALKER_ID)
            debug_on = addon.getSettingBool('debug_logging')
        except Exception:
            addon = None
            debug_on = False
        labels = [
            '[B][COLOR deepskyblue]Portal aus TXT-Datei importieren (empfohlen)[/COLOR][/B]',
            'Portal manuell hinzufügen',
            'Automatische beste MAC - [COLOR {}]{}[/COLOR]'.format(
                'lime' if auto_on else 'red', 'Ein' if auto_on else 'Aus'),
            ('MAC-Wechsel bei Restlaufzeit - [COLOR gold]{} Tage[/COLOR]'.format(switch_days)
             if auto_on else
             'MAC-Wechsel bei Restlaufzeit - [COLOR grey]deaktiviert[/COLOR]'),
            'Erweitertes Diagnoseprotokoll - [COLOR {}]{}[/COLOR]'.format(
                'lime' if debug_on else 'red', 'Ein' if debug_on else 'Aus'),
            'Portal-Sicherung erstellen',
            'Portal-Sicherung wiederherstellen',
            'Entwicklerbericht erstellen (Portal + )',
            'Portal-Sortierung - {}'.format({
                'active_name': 'Aktiv zuerst',
                'name': 'Alphabetisch',
                'mac_count': 'MAC-Anzahl',
                'validity': 'Beste Restlaufzeit',
            }.get(pm.get_portal_sort_mode(), 'Aktiv zuerst')),
            'Portal-Suche und Filter',
            'EPG-Zuordnungen neu erstellen',
            'Portal-Index neu erstellen',
        ]
        # Reine Textliste: keine eigenen Aktions-PNGs. Dadurch bleibt die
        # Darstellung in unterschiedlichen Kodi-Skins kompakt und konsistent.
        idx = xbmcgui.Dialog().select('Weitere Portalaktionen', labels)
        if idx < 0:
            return
        if idx == 0:
            imported, hits = pm.import_txt_selection()
            if imported:
                xbmcgui.Dialog().notification(
                    TITLE, '{} Portal(e) verarbeitet, {} neue MACs'.format(imported, hits),
                    xbmcgui.NOTIFICATION_INFO, 5000)
                # Nach einem erfolgreichen Import dieses Untermenü schließen.
                # choose_server() baut anschließend den Portal Manager neu auf,
                # sodass neu importierte Portale sofort sichtbar sind.
                return True
        elif idx == 1:
            portal = pm.add_manual_portal()
            if portal:
                xbmcgui.Dialog().notification(
                    TITLE, 'Portal hinzugefügt', xbmcgui.NOTIFICATION_INFO, 3000)
        elif idx == 2:
            if not active:
                xbmcgui.Dialog().ok(TITLE, 'Bitte zuerst ein Portal aktivieren.')
                continue
            active['auto_mac'] = not auto_on
            if active['auto_mac']:
                switch_days = pm.get_auto_switch_days()
                xbmcgui.Dialog().ok(
                    TITLE,
                    'Automatische MAC-Auswahl aktiviert.\n\n'
                    'Die aktuell ausgewählte MAC bleibt aktiv.\n\n'
                    'Erst wenn ihre Restlaufzeit {} Tage oder weniger beträgt, '
                    'wird automatisch auf eine bessere verfügbare MAC gewechselt.'.format(switch_days))
            pm.update_portal(active)
            if not active['auto_mac']:
                xbmcgui.Dialog().notification(
                    TITLE, 'Automatische beste MAC deaktiviert',
                    xbmcgui.NOTIFICATION_INFO, 3000)
        elif idx == 3:
            if not auto_on:
                xbmcgui.Dialog().ok(
                    TITLE, 'Aktiviere zuerst „Automatische beste MAC“.')
                continue
            values = [30, 20, 15, 10, 7, 5, 3, 1, 0]
            names = ['{} Tage'.format(value) if value != 1 else '1 Tag' for value in values]
            selected = xbmcgui.Dialog().select(
                'MAC-Wechsel bei Restlaufzeit', names,
                preselect=values.index(switch_days) if switch_days in values else -1)
            if selected >= 0:
                pm.set_auto_switch_days(values[selected])
                xbmcgui.Dialog().notification(
                    TITLE, 'MAC-Wechsel bei {} Tagen Restlaufzeit'.format(values[selected]),
                    xbmcgui.NOTIFICATION_INFO, 3000)
        elif idx == 4:
            if addon:
                addon.setSettingBool('debug_logging', not debug_on)
                xbmcgui.Dialog().notification(
                    TITLE, 'Erweitertes Diagnoseprotokoll {}'.format(
                        'aktiviert' if not debug_on else 'deaktiviert'),
                    xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                xbmcgui.Dialog().ok(TITLE, 'Erweitertes Diagnoseprotokoll konnte nicht geändert werden.')
        elif idx == 5:
            pm.export_backup()
        elif idx == 6:
            pm.restore_backup()
        elif idx == 7:
            portal_path = pm.create_diagnostic_report(portals, configured_url, configured_mac)
            try:
                from .xmltv import export_live_epg_trace
                epg_paths = export_live_epg_trace()
            except Exception as exc:
                epg_paths = {}
                Logger.error('Live EPG trace export failed: {}'.format(exc))
            if epg_paths:
                xbmcgui.Dialog().textviewer(
                    'Entwicklerbericht 2.8.4',
                    'PORTAL-ÜBERSICHT:\n{}\n\n'
                    'LIVE-EPG-TRACE – DIESE DATEIEN FÜR EPG-FEHLER HOCHLADEN:\n'
                    'TXT: {}\n\nJSON: {}\n\n'
                    'Laufzeitentscheidungen: {}\nEindeutige Sender: {}\n\n'
                    'Hinweis: Der Live-Trace entsteht beim echten Anzeigen der Senderliste. '
                    'Vor dem Export bitte die betroffenen RBB-/NDR-Sender öffnen.'.format(
                        portal_path, epg_paths.get('txt') or 'Fehler',
                        epg_paths.get('json') or 'Fehler', epg_paths.get('entries') or 0,
                        epg_paths.get('unique_channels') or 0), usemono=True)
            else:
                xbmcgui.Dialog().ok(
                    'Entwicklerbericht',
                    'Portalbericht gespeichert:\n{}\n\nDer  konnte nicht exportiert werden.'.format(portal_path))
        elif idx == 8:
            modes = ['active_name', 'name', 'mac_count', 'validity']
            names = ['Aktiv zuerst', 'Alphabetisch', 'MAC-Anzahl', 'Beste Restlaufzeit']
            current_mode = pm.get_portal_sort_mode()
            selected = xbmcgui.Dialog().select(
                'Portal-Sortierung', names,
                preselect=modes.index(current_mode) if current_mode in modes else 0)
            if selected >= 0:
                pm.set_portal_sort_mode(modes[selected])
                xbmcgui.Dialog().notification(
                    TITLE, 'Portal-Sortierung: {}'.format(names[selected]),
                    xbmcgui.NOTIFICATION_INFO, 3000)
        elif idx == 9:
            prefs = pm.get_portal_view_preferences()
            filter_modes = ['all', 'active', 'urgent', 'expired', 'error']
            filter_names = ['Alle', 'Nur aktives Portal', 'Bald ablaufend',
                            'Nur vollständig abgelaufen', 'Fehlerhaft markiert']
            action = xbmcgui.Dialog().select('Portal-Suche und Filter', [
                'Suchbegriff ändern - {}'.format(prefs['query'] or 'kein Suchbegriff'),
                'Filter ändern - {}'.format(filter_names[filter_modes.index(prefs['filter'])]),
                'Suche und Filter zurücksetzen',
            ])
            if action == 0:
                query = xbmcgui.Dialog().input(
                    'Portal suchen', defaultt=prefs['query'], type=xbmcgui.INPUT_ALPHANUM)
                pm.set_portal_view_preferences(query=query)
            elif action == 1:
                selected = xbmcgui.Dialog().select(
                    'Portal-Filter', filter_names,
                    preselect=filter_modes.index(prefs['filter']))
                if selected >= 0:
                    pm.set_portal_view_preferences(filter_mode=filter_modes[selected])
            elif action == 2:
                pm.set_portal_view_preferences(query='', filter_mode='all')
                xbmcgui.Dialog().notification(
                    TITLE, 'Portal-Suche und Filter zurückgesetzt',
                    xbmcgui.NOTIFICATION_INFO, 3000)
        elif idx == 10:
            if xbmcgui.Dialog().yesno(
                    TITLE, 'Gelernte EPG-Zuordnungen löschen und XMLTV-Daten neu zuordnen?'):
                from .xmltv import reset_xmltv_mapping_cache, load_xmltv
                reset_xmltv_mapping_cache()
                load_xmltv(force=True)
                xbmcgui.Dialog().ok('EPG', 'EPG-Zuordnungen wurden neu erstellt.')
        elif idx == 11:
            if xbmcgui.Dialog().yesno(
                    TITLE, 'Portal-Index für „Meine Sender“ jetzt vollständig neu erstellen?'):
                xbmc.executebuiltin(
                    'RunPlugin(plugin://{}/?action=local_tv_rebuild_index)'.format(STALKER_ID))
                return


def _use_managed_portal(portal, configured_url):
    """Activate a selected portal when needed and open its MAC selection."""
    from . import portal_manager as pm
    portal_url = pm.normalize_portal_url(portal.get('portal', ''))
    if portal_url != configured_url and not _stage_managed_portal(portal):
        return
    _choose_managed_mac(portal)

def _backup_menu():
    from . import portal_manager as pm
    while True:
        idx = xbmcgui.Dialog().select('Sicherung', [
            'Sicherung erstellen',
            'Sicherung wiederherstellen',
        ])
        if idx < 0:
            return
        if idx == 0:
            pm.export_backup()
        elif idx == 1:
            pm.restore_backup()


def _portal_settings_menu():
    """Portal-related switches and maintenance actions in one place."""
    from . import portal_manager as pm
    while True:
        portals, configured_url, configured_mac, active = _managed_portal_context(pm)
        auto_on = bool(active and active.get('auto_mac', True))
        try:
            addon = xbmcaddon.Addon(id=STALKER_ID)
            debug_on = addon.getSettingBool('debug_logging')
        except Exception:
            addon = None
            debug_on = False
        labels = [
            'MAC-Automatik: {}'.format('[COLOR lime]Ein[/COLOR]' if auto_on else '[COLOR white]Aus[/COLOR]'),
            'Ablaufwarnung: [COLOR yellow]unter {} Tagen[/COLOR]'.format(pm.PORTAL_WARNING_DAYS),
            'Diagnoseprotokoll: {}'.format('[COLOR lime]Ein[/COLOR]' if debug_on else '[COLOR white]Aus[/COLOR]'),
            'Portal-Index neu erstellen',
            'Kodi-Addon-Einstellungen öffnen',
        ]
        idx = xbmcgui.Dialog().select('Einstellungen', labels)
        if idx < 0:
            return
        if idx == 0:
            if not active:
                xbmcgui.Dialog().ok(TITLE, 'Bitte zuerst ein Portal aktivieren.')
                continue
            active['auto_mac'] = not auto_on
            if active['auto_mac']:
                best = pm.best_mac(active)
                if best:
                    active['active_mac'] = best.get('mac', '')
                    _activate_managed_portal(active, best, manual=False)
            pm.update_portal(active)
            xbmcgui.Dialog().notification(
                TITLE,
                'MAC-Automatik {}'.format('aktiviert' if active['auto_mac'] else 'deaktiviert'),
                xbmcgui.NOTIFICATION_INFO, 3000)
        elif idx == 1:
            xbmcgui.Dialog().ok(
                TITLE,
                'Die Ablaufwarnung erscheint einmal täglich, sobald die aktive MAC weniger als {} Tage gültig ist.'.format(
                    pm.PORTAL_WARNING_DAYS))
        elif idx == 2:
            if addon:
                addon.setSettingBool('debug_logging', not debug_on)
        elif idx == 3:
            if xbmcgui.Dialog().yesno(
                    TITLE,
                    'Portal-Index für „Meine Sender“ jetzt vollständig neu erstellen?'):
                xbmc.executebuiltin(
                    'RunPlugin(plugin://{}/?action=local_tv_rebuild_index)'.format(STALKER_ID))
                return
        elif idx == 4:
            if addon:
                addon.openSettings()


def choose_server():
    """Open the compact 2.2 portal manager with direct portal selection."""
    from . import portal_manager as pm
    while True:
        portals, configured_url, configured_mac, active = _managed_portal_context(pm)
        if not portals:
            if not _first_run_portal_wizard():
                return
            portals, configured_url, configured_mac, active = _managed_portal_context(pm)
            if not portals:
                return
            continue
        from . import portal_dashboard as dashboard
        prefs = pm.get_portal_view_preferences()
        portals = dashboard.filter_portals(
            portals, query=prefs['query'], mode=prefs['filter'], active_url=configured_url,
            days_left=pm.days_left, mac_exp=pm._mac_exp,
            warning_days=pm.get_auto_switch_days(), normalize_url=pm.normalize_portal_url)
        portals = pm.sort_portals(portals, configured_url)
        heading = _portal_manager_heading(active, configured_mac)
        if prefs['query'] or prefs['filter'] != 'all':
            heading += ' – Filter aktiv'
        options = [
            'Portalinformationen',
            'Weitere Portalaktionen',
        ]
        options.extend(pm.portal_card_label(
            portal,
            active=(pm.normalize_portal_url(portal.get('portal', '')) == configured_url)
        ) for portal in portals)
        idx = xbmcgui.Dialog().select(heading, options)
        if idx < 0:
            return
        if idx == 0:
            _portal_status_overview()
        elif idx == 1:
            _further_portal_actions()
        else:
            portal_index = idx - 2
            if 0 <= portal_index < len(portals):
                _use_managed_portal(portals[portal_index], configured_url)
                return

def choose_mac():
    """Choose a MAC manually for the currently configured managed portal."""
    from . import portal_manager as pm
    try:
        addon = xbmcaddon.Addon(id=STALKER_ID)
        current_url = pm.normalize_portal_url(addon.getSetting('server_address'))
    except Exception:
        current_url = ''
    portals = pm.load_portals()
    portal = next((p for p in portals if p.get('portal') == current_url), None)
    if portal:
        _choose_managed_mac(portal)
        return
    # Legacy converter JSON fallback.
    if selected_portal_url is None and not _rehydrate_selection_from_settings():
        xbmcgui.Dialog().ok(TITLE, 'Bitte zuerst ein Portal wählen!')
        return
    xbmcgui.Dialog().ok(TITLE, 'Das aktuelle Portal ist noch nicht in der Portalverwaltung.\nBitte über „Portal wählen → Neues Portal hinzufügen“ importieren.')

def apply_pvr():
    portal_url = selected_portal_url
    mac = selected_mac
    if not portal_url or not mac:
        try:
            addon = xbmcaddon.Addon(id=STALKER_ID)
            portal_url = portal_url or addon.getSetting("server_address")
            mac = mac or addon.getSetting("mac_address")
        except Exception:
            pass

    if not portal_url or not mac:
        xbmcgui.Dialog().ok(TITLE, "Bitte zuerst Portal und MAC wählen.")
        return

    xml_content = (
        '<settings version="2">'
        '<setting id="kodi_addon_instance_enabled">true</setting>'
        '<setting id="mac">%s</setting>'
        '<setting id="server">%s</setting>'
        '<setting id="time_zone">Europe/Berlin</setting>'
        '</settings>'
    ) % (mac, portal_url)

    written_any = False
    for d in PVR_DIR_CANDIDATES:
        if _exists(d):
            _dirs, files = xbmcvfs.listdir(d)
            for f in files:
                if f.startswith("instance-settings-") and f.endswith(".xml"):
                    _write_text("%s/%s" % (d, f), xml_content)
                    written_any = True
                    _log("PVR geschrieben: %s/%s" % (d, f))

    if not written_any:
        fallback = "%s/instance-settings-1.xml" % PVR_DIR_CANDIDATES[0]
        _write_text(fallback, xml_content)
        written_any = True
        _log("PVR Fallback geschrieben: %s" % fallback)

    if written_any:
        try:
            xbmc.executebuiltin("UpdateLibrary(video)")
            xbmc.executebuiltin("Addon.Enable(pvr.stalker)")
        except Exception:
            pass
        xbmcgui.Dialog().notification(TITLE, "PVR aktualisiert", xbmcgui.NOTIFICATION_INFO, 3000)



def activate():
    if not selected_portal_url:
        xbmcgui.Dialog().ok(TITLE, "Bitte zuerst Portal wählen!")
        return
    if not selected_mac:
        xbmcgui.Dialog().ok(TITLE, "Bitte passenden Zugang (MAC) wählen!")
        return
    try:
        stalker = xbmcaddon.Addon(id=STALKER_ID)
        stalker.setSetting("server_address", selected_portal_url)
        stalker.setSetting("mac_address", selected_mac)
        xbmcgui.Dialog().ok("Aktivieren", "Connect:\n%s\nMAC %s gesetzt" % (selected_portal, selected_mac))
    except Exception:
        xbmcgui.Dialog().ok("Aktivieren", "Connect:\n%s\nMAC %s gesetzt" % (selected_portal, selected_mac))
