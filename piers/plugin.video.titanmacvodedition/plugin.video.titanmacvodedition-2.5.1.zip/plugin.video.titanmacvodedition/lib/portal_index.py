"""Central filtered Live-TV portal index.

The index is scoped by portal/MAC and the configured country filter.  It is the
single data source for automatic synchronization and cached manual suggestions.
The unfiltered ``TV-GRUPPEN – ALLE`` browser never writes to this index.
"""
from __future__ import absolute_import, division, unicode_literals

import hashlib
import os
import re
import time
import unicodedata

from .api import Api
from .constants import LOCAL_TV_CATALOG_TTL_SECONDS
from .country_filter import filter_categories_for_country_groups, get_configured_country_tokens
from .globals import G
from .loggers import Logger
from .file_utils import atomic_write_json, read_json
from .paths import local_tv_catalog_path, local_tv_groups_path

try:
    import xbmcaddon
except ImportError:
    xbmcaddon = None

_SCHEMA_VERSION = 5
_MAX_INDEX_ENTRIES = 8
_TEMPORARY_SYNC_GROUP_PATTERNS = (
    r"\bWM\s*20\d{2}\b", r"\bEURO\s*20\d{2}\b", r"\bEM\s*20\d{2}\b",
    r"\bHALLOWEEN\b", r"\bCHRISTMAS\b", r"\bWEIHNACHT", r"\bSILVESTER\b",
    r"\bOSTERN\b", r"\b24\s*/\s*7\b",
)


def _read_json(path, default):
    value = read_json(path, default)
    return default if value is None and default is not None else value


def _atomic_write(path, value):
    if not atomic_write_json(path, value, prefix='.portal_index_'):
        raise OSError('Could not write portal index {}'.format(path))


def portal_key():
    source = '{}|{}'.format(G.portal_config.portal_url or G.portal_config.server_address or '',
                            G.portal_config.mac_cookie or '')
    return hashlib.sha1(source.encode('utf-8')).hexdigest()[:20]


def normalize_name(value):
    value = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode('ascii')
    value = re.sub(r'\b(?:HD|FHD|UHD|4K|HEVC|RAW|TV|FERNSEHEN|FS)\b', ' ', value, flags=re.I)
    return re.sub(r'[^A-Z0-9]+', '', value.upper())


def mapping_payload(channel, group_id=None, group_title=''):
    payload = {
        'id': channel.get('id', ''), 'name': channel.get('name', ''),
        'cmd': channel.get('cmd', ''), 'logo': channel.get('logo', ''),
        'use_http_tmp_link': channel.get('use_http_tmp_link', 0),
        'use_load_balancing': channel.get('use_load_balancing', 0),
        'epg_id': channel.get('epg_id', channel.get('id', '')),
        'xmltv_id': channel.get('xmltv_id', ''),
        'tvg_id': channel.get('tvg_id', ''),
        'ch_id': channel.get('ch_id', ''),
        'channel_id': channel.get('channel_id', ''),
        'number': channel.get('number', channel.get('num', '')),
        'genre_id': channel.get('genre_id', channel.get('tv_genre_id', '')),
        'normalized_name': channel.get('normalized_name') or normalize_name(channel.get('name', '')),
    }
    group_ids = list(channel.get('group_ids') or [])
    group_titles = list(channel.get('group_titles') or [])
    if group_id is not None and str(group_id) not in [str(value) for value in group_ids]:
        group_ids.append(group_id)
    if group_title and group_title not in group_titles:
        group_titles.append(group_title)
    if group_ids:
        payload['group_ids'] = group_ids
    if group_titles:
        payload['group_titles'] = group_titles
    return payload


def active_country_tokens():
    addon = xbmcaddon.Addon() if xbmcaddon else None
    return get_configured_country_tokens(addon)


def context_key(tokens=None):
    token_list = list(tokens or active_country_tokens())
    raw = '{}|{}'.format(portal_key(), '|'.join(token_list))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def _read_store():
    value = _read_json(local_tv_catalog_path(), {})
    if not isinstance(value, dict):
        return {'schema': _SCHEMA_VERSION, 'entries': {}}
    if isinstance(value.get('entries'), dict):
        value['schema'] = _SCHEMA_VERSION
        return value
    # Migrate the former single-index format in place on the next write.
    if isinstance(value.get('channels'), list) and value.get('portal'):
        tokens = list(value.get('tokens') or [])
        raw = '{}|{}'.format(value.get('portal'), '|'.join(tokens))
        key = hashlib.sha256(raw.encode('utf-8')).hexdigest()
        return {'schema': _SCHEMA_VERSION, 'entries': {key: value}}
    return {'schema': _SCHEMA_VERSION, 'entries': {}}


def _entry(tokens=None):
    store = _read_store()
    return store, store.get('entries', {}).get(context_key(tokens), {})


def _matches_context(entry, tokens=None):
    expected = list(tokens or active_country_tokens())
    return (isinstance(entry, dict) and entry.get('portal') == portal_key() and
            list(entry.get('tokens') or []) == expected and
            isinstance(entry.get('channels'), list))


def _valid(entry, tokens=None):
    return (_matches_context(entry, tokens) and
            time.time() - float(entry.get('created', 0)) < LOCAL_TV_CATALOG_TTL_SECONDS)


def _write_entry(entry, tokens=None):
    store = _read_store()
    entries = store.setdefault('entries', {})
    entries[context_key(tokens)] = entry
    if len(entries) > _MAX_INDEX_ENTRIES:
        ordered = sorted(entries.items(), key=lambda pair: float((pair[1] or {}).get('created', 0)), reverse=True)
        store['entries'] = dict(ordered[:_MAX_INDEX_ENTRIES])
    _atomic_write(local_tv_catalog_path(), store)


def load_index(allow_stale=True):
    """Load the active local index without portal requests.

    Stale data remains usable so opening TV never blocks on a network refresh.
    The background service replaces it when the portal is reachable.
    """
    _, cached = _entry()
    if not _matches_context(cached):
        return {'channels': [], 'group_list': [], 'groups': 0, 'cached': False,
                'stale': False, 'cancelled': False}
    stale = not _valid(cached)
    if stale and not allow_stale:
        return {'channels': [], 'group_list': [], 'groups': 0, 'cached': False,
                'stale': True, 'cancelled': False}
    return {'channels': list(cached.get('channels') or []),
            'group_list': list(cached.get('group_list') or []),
            'groups': int(cached.get('groups') or 0), 'cached': True,
            'stale': stale, 'created': float(cached.get('created') or 0),
            'statistics': dict(cached.get('statistics') or {}), 'cancelled': False}


def index_needs_refresh():
    data = load_index(allow_stale=True)
    return bool(data.get('cached') and data.get('stale'))


def get_index_groups():
    data = load_index(allow_stale=True)
    groups = data.get('group_list') or []
    return groups if groups else load_cached_groups()


def search_channels(term, group_id=None):
    needle = normalize_name(term)
    channels = get_cached_channels()
    if group_id is not None:
        wanted = str(group_id)
        channels = [c for c in channels if wanted in [str(v) for v in (c.get('group_ids') or [])]]
    if not needle:
        return channels
    return [c for c in channels if needle in (c.get('normalized_name') or normalize_name(c.get('name', '')))]



_ALL_GROUPS_TOKEN = '__ALL_PORTAL_GROUPS__'

def all_groups_tokens():
    return [_ALL_GROUPS_TOKEN]

def load_all_index(allow_stale=True):
    """Load the persistent portal-wide channel index without network access."""
    tokens = all_groups_tokens()
    _, cached = _entry(tokens)
    if not _matches_context(cached, tokens):
        return {'channels': [], 'group_list': [], 'groups': 0, 'cached': False,
                'stale': False, 'cancelled': False}
    stale = not _valid(cached, tokens)
    if stale and not allow_stale:
        return {'channels': [], 'group_list': [], 'groups': 0, 'cached': False,
                'stale': True, 'cancelled': False}
    return {'channels': list(cached.get('channels') or []),
            'group_list': list(cached.get('group_list') or []),
            'groups': int(cached.get('groups') or 0), 'cached': True,
            'stale': stale, 'created': float(cached.get('created') or 0),
            'statistics': dict(cached.get('statistics') or {}), 'cancelled': False}

def get_cached_all_channels():
    return load_all_index(allow_stale=True).get('channels') or []

def build_all_index(force=False, progress_callback=None, cancel_callback=None):
    """Build the persistent portal-wide catalogue used by manual search.

    The preferred path is one ``get_all_channels`` request, matching the
    architecture used by modern IPTV clients.  If a portal does not implement
    that endpoint, the previous group-by-group pagination remains available as
    a compatibility fallback.  XMLTV is never consulted here.
    """
    tokens = all_groups_tokens()
    _, cached = _entry(tokens)
    if not force and _valid(cached, tokens):
        return {'channels': list(cached.get('channels') or []),
                'groups': int(cached.get('groups') or 0), 'cancelled': False,
                'cached': True, 'method': cached.get('method', 'cache')}

    genres, groups_cached = get_or_load_groups()
    group_titles = {}
    group_list = []
    for group in genres or []:
        group_id = group.get('id')
        title = (group.get('title') or group.get('name') or '').strip()
        if group_id is not None:
            group_titles[str(group_id)] = title
            group_list.append({'id': group_id, 'title': title})

    # Fast path: one complete catalogue request.
    all_channels = []
    try:
        all_channels = Api.get_all_tv_channels() or []
    except Exception as exc:
        Logger.warn('Complete portal catalogue request failed: {}'.format(exc))
    if all_channels:
        channels, by_key = [], {}
        total = len(all_channels)
        for position, channel in enumerate(all_channels, 1):
            if cancel_callback and cancel_callback():
                return {'channels': channels, 'groups': 0, 'cancelled': True,
                        'cached': False, 'method': 'get_all_channels'}
            group_id = (channel.get('tv_genre_id') if channel.get('tv_genre_id') is not None
                        else channel.get('genre_id'))
            title = group_titles.get(str(group_id), '') if group_id is not None else ''
            payload = mapping_payload(channel, group_id, title)
            key = '{}|{}'.format(payload.get('id', ''), payload.get('name', ''))
            existing = by_key.get(key)
            if existing is None:
                by_key[key] = payload
                channels.append(payload)
            else:
                ids = existing.setdefault('group_ids', [])
                titles = existing.setdefault('group_titles', [])
                if group_id is not None and str(group_id) not in [str(v) for v in ids]:
                    ids.append(group_id)
                if title and title not in titles:
                    titles.append(title)
            if progress_callback and (position == 1 or position == total or position % 250 == 0):
                progress_callback(position, total, title or 'Gesamter Senderkatalog', len(channels))
        used_groups = len(set(str(c.get('genre_id')) for c in channels if c.get('genre_id') not in (None, '')))
        entry = {'portal': portal_key(), 'tokens': tokens, 'created': time.time(),
                 'groups': used_groups, 'group_list': group_list, 'channels': channels,
                 'method': 'get_all_channels',
                 'statistics': {'logos': sum(1 for item in channels if item.get('logo')),
                                'epg_ids': sum(1 for item in channels if item.get('epg_id'))}}
        try:
            _write_entry(entry, tokens)
        except Exception as exc:
            Logger.warn('Could not save complete portal catalogue: {}'.format(exc))
        Logger.info('Portal catalogue loaded with get_all_channels: {} channels'.format(len(channels)))
        return {'channels': channels, 'groups': used_groups, 'cancelled': False,
                'cached': False, 'groups_cached': groups_cached, 'method': 'get_all_channels'}

    # Compatibility fallback for portals without get_all_channels.
    filtered = [group for group in genres if is_sync_group_allowed(group) and
                str(group.get('title') or group.get('name') or '').strip().casefold() != 'all']
    group_list = [{'id': g.get('id'), 'title': (g.get('title') or g.get('name') or '').strip()}
                  for g in filtered if g.get('id') is not None]
    channels, by_key = [], {}
    cancelled = False
    completed_groups = 0
    total_groups = len(filtered)
    for position, genre in enumerate(filtered, 1):
        if cancel_callback and cancel_callback():
            cancelled = True
            break
        category_id = genre.get('id')
        title = (genre.get('title') or genre.get('name') or '').strip()
        if progress_callback:
            progress_callback(position, total_groups, title, len(channels))
        page, group_count = 1, 0
        while category_id is not None:
            if cancel_callback and cancel_callback():
                cancelled = True
                break
            try:
                listing = Api.get_tv_channels(category_id, page, '', 0)
            except Exception as exc:
                Logger.warn('Portal-wide index failed for group {} page {}: {}'.format(title, page, exc))
                break
            page_data = listing.get('data') or []
            for channel in page_data:
                payload = mapping_payload(channel, category_id, title)
                key = '{}|{}'.format(payload.get('id', ''), payload.get('name', ''))
                existing = by_key.get(key)
                if existing is None:
                    by_key[key] = payload
                    channels.append(payload)
                    group_count += 1
                else:
                    ids = existing.setdefault('group_ids', [])
                    titles = existing.setdefault('group_titles', [])
                    if str(category_id) not in [str(value) for value in ids]:
                        ids.append(category_id)
                    if title and title not in titles:
                        titles.append(title)
            max_items = max(1, int(listing.get('max_page_items') or 1))
            total = int(listing.get('total_items') or len(page_data))
            if not page_data or page * max_items >= total:
                break
            page += 1
        if cancelled:
            break
        if group_count:
            completed_groups += 1
        if progress_callback:
            progress_callback(position, total_groups, title, len(channels))
    if not cancelled:
        try:
            _write_entry({'portal': portal_key(), 'tokens': tokens, 'created': time.time(),
                          'groups': completed_groups, 'group_list': group_list, 'channels': channels,
                          'method': 'group_pagination',
                          'statistics': {'logos': sum(1 for item in channels if item.get('logo')),
                                         'epg_ids': sum(1 for item in channels if item.get('epg_id'))}}, tokens)
        except Exception as exc:
            Logger.warn('Could not save portal-wide index: {}'.format(exc))
    return {'channels': channels, 'groups': completed_groups, 'cancelled': cancelled,
            'cached': False, 'groups_cached': groups_cached, 'method': 'group_pagination'}


def statistics():
    data = load_index(allow_stale=True)
    stats = dict(data.get('statistics') or {})
    stats.update({'created': data.get('created', 0), 'stale': data.get('stale', False),
                  'channels': len(data.get('channels') or []),
                  'groups': int(data.get('groups') or 0)})
    return stats


def get_cached_channels():
    return load_index(allow_stale=True).get('channels') or []


def get_cached_group_channels(group_id):
    """Return channels for a group from the active local portal index only."""
    wanted = str(group_id)
    result = []
    for channel in get_cached_channels():
        if wanted in [str(value) for value in (channel.get('group_ids') or [])]:
            result.append(channel)
    return result


def merge_channels(channels):
    tokens = active_country_tokens()
    _, cached = _entry(tokens)
    current = list(cached.get('channels') or []) if _valid(cached, tokens) else []
    merged, seen = [], set()
    for channel in current + [mapping_payload(item) for item in (channels or [])]:
        key = '{}|{}'.format(channel.get('id', ''), channel.get('name', ''))
        if key in seen:
            continue
        seen.add(key); merged.append(channel)
    try:
        _write_entry({'portal': portal_key(), 'tokens': list(tokens), 'created': time.time(),
                      'groups': int(cached.get('groups') or 0),
                      'group_list': list(cached.get('group_list') or []),
                      'channels': merged,
                      'statistics': {'logos': sum(1 for item in merged if item.get('logo')),
                                     'epg_ids': sum(1 for item in merged if item.get('epg_id'))}}, tokens)
    except Exception as exc:
        Logger.warn('Could not update portal index: {}'.format(exc))
    return merged


def cache_groups(groups):
    clean = []
    for group in groups or []:
        if not isinstance(group, dict):
            continue
        group_id = group.get('id')
        title = (group.get('title') or group.get('name') or group.get('alias') or group.get('abbr') or '').strip()
        if group_id is not None and title:
            clean.append({'id': group_id, 'title': title})
    try:
        _atomic_write(local_tv_groups_path(), {'portal': portal_key(), 'created': time.time(), 'groups': clean})
    except Exception as exc:
        Logger.warn('Could not cache portal TV groups: {}'.format(exc))
    return clean


def load_cached_groups():
    value = _read_json(local_tv_groups_path(), {})
    if not isinstance(value, dict) or value.get('portal') != portal_key():
        return []
    return value.get('groups') if isinstance(value.get('groups'), list) else []


def get_or_load_groups():
    groups = load_cached_groups()
    if groups:
        return groups, True
    try:
        groups = Api.get_tv_genres() or []
    except Exception as exc:
        Logger.error('Could not load TV genres for portal index: {}'.format(exc))
        return [], False
    return cache_groups(groups), False


def is_sync_group_allowed(group):
    title = (group.get('title') or group.get('name') or group.get('alias') or '').strip()
    if not title:
        return False
    normalized = unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').decode('ascii').upper()
    return not any(re.search(pattern, normalized) for pattern in _TEMPORARY_SYNC_GROUP_PATTERNS)


def build_index(force=False, progress_callback=None, cancel_callback=None):
    """Build the central index from filtered, non-temporary portal groups."""
    tokens = active_country_tokens()
    _, cached = _entry(tokens)
    if not force and _valid(cached, tokens):
        return {'channels': list(cached.get('channels') or []),
                'groups': int(cached.get('groups') or 0), 'cancelled': False, 'cached': True}

    genres, groups_cached = get_or_load_groups()
    if not genres:
        return {'channels': [], 'groups': 0, 'cancelled': False, 'cached': False, 'groups_cached': False}
    filtered = [group for group in filter_categories_for_country_groups(genres, tokens=set(tokens))
                if is_sync_group_allowed(group)]
    group_list = [{'id': g.get('id'), 'title': (g.get('title') or g.get('name') or '').strip()}
                  for g in filtered if g.get('id') is not None]
    channels, seen = [], set()
    cancelled = False
    completed_groups = 0
    total_groups = len(filtered)
    for position, genre in enumerate(filtered, 1):
        if cancel_callback and cancel_callback():
            cancelled = True; break
        category_id = genre.get('id')
        title = (genre.get('title') or genre.get('name') or '').strip()
        if progress_callback:
            progress_callback(position, total_groups, title, len(channels))
        page, group_count = 1, 0
        while category_id is not None:
            if cancel_callback and cancel_callback():
                cancelled = True; break
            try:
                listing = Api.get_tv_channels(category_id, page, '', 0)
            except Exception as exc:
                Logger.warn('Portal index failed for group {} page {}: {}'.format(title, page, exc)); break
            page_data = listing.get('data') or []
            for channel in page_data:
                payload = mapping_payload(channel, category_id, title)
                key = '{}|{}'.format(payload.get('id', ''), payload.get('name', ''))
                if key not in seen:
                    seen.add(key); channels.append(payload); group_count += 1
                else:
                    existing = next((item for item in channels
                                     if '{}|{}'.format(item.get('id', ''), item.get('name', '')) == key), None)
                    if existing is not None:
                        ids = existing.setdefault('group_ids', [])
                        titles = existing.setdefault('group_titles', [])
                        if str(category_id) not in [str(value) for value in ids]:
                            ids.append(category_id)
                        if title and title not in titles:
                            titles.append(title)
            max_items = max(1, int(listing.get('max_page_items') or 1))
            total = int(listing.get('total_items') or len(page_data))
            if not page_data or page * max_items >= total:
                break
            page += 1
        if cancelled:
            break
        if group_count:
            completed_groups += 1
        if progress_callback:
            progress_callback(position, total_groups, title, len(channels))
    if not cancelled:
        try:
            logo_count = sum(1 for item in channels if item.get('logo'))
            epg_count = sum(1 for item in channels if item.get('epg_id'))
            _write_entry({'portal': portal_key(), 'tokens': list(tokens), 'created': time.time(),
                          'groups': completed_groups, 'group_list': group_list, 'channels': channels,
                          'statistics': {'logos': logo_count, 'epg_ids': epg_count}}, tokens)
        except Exception as exc:
            Logger.warn('Could not save filtered portal index: {}'.format(exc))
    return {'channels': channels, 'groups': completed_groups, 'cancelled': cancelled,
            'cached': False, 'groups_cached': groups_cached}


def find_channel(predicate):
    """Return the first cached channel accepted by ``predicate``."""
    return next((channel for channel in get_cached_channels() if predicate(channel)), None)


def find_group(predicate):
    """Return the first cached portal group accepted by ``predicate``."""
    return next((group for group in load_cached_groups() if predicate(group)), None)


def invalidate_index(all_entries=False):
    """Delete the active portal/filter index, or all retained indexes."""
    try:
        path = local_tv_catalog_path()
        if not path or not os.path.exists(path):
            return True
        if all_entries:
            os.remove(path); return True
        store = _read_store()
        store.setdefault('entries', {}).pop(context_key(), None)
        _atomic_write(path, store)
        return True
    except Exception as exc:
        Logger.error('Could not clear portal index: {}'.format(exc))
        return False
