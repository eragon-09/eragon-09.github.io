# -*- coding: utf-8 -*-
"""XMLTV source loading and XML parsing helpers."""
from __future__ import absolute_import, division, unicode_literals

import gzip
import os
from datetime import datetime

import requests

from .loggers import Logger

def _fetch_xmltv(url):
    """Download XMLTV from URL (supports http/https and local file://).
    Returns raw bytes or None."""
    if not url:
        return None
    try:
        if url.startswith('file://') or os.path.exists(url):
            path = url.replace('file://', '')
            with open(path, 'rb') as f:
                return f.read()

        from .utils import get_request_timeout
        resp = requests.get(url, timeout=get_request_timeout(60),
                            headers={'User-Agent': 'TitanStalkerVOD/1.0'})
        if resp.status_code == 200:
            return resp.content
        Logger.warn('XMLTV fetch failed, HTTP {}'.format(resp.status_code))
        return None
    except Exception as exc:
        Logger.error('XMLTV fetch error: {}'.format(exc))
        return None


# ---------------------------------------------------------------------------
# XMLTV parser  (stdlib xml.etree – no extra deps)
# ---------------------------------------------------------------------------

def _parse_xmltv_time(s):
    """Parse XMLTV timestamp like '20240407203000 +0200' → Unix timestamp."""
    if not s:
        return None
    try:
        s = s.strip()
        # Split off timezone
        parts = s.split()
        dt_str = parts[0]
        tz_str = parts[1] if len(parts) > 1 else '+0000'

        dt = datetime.strptime(dt_str, '%Y%m%d%H%M%S')
        # Convert timezone offset to seconds
        sign = 1 if tz_str[0] != '-' else -1
        tz_str = tz_str.lstrip('+-')
        tz_h = int(tz_str[:2]) if len(tz_str) >= 2 else 0
        tz_m = int(tz_str[2:4]) if len(tz_str) >= 4 else 0
        tz_offset = sign * (tz_h * 3600 + tz_m * 60)

        # epoch = local dt interpreted as UTC, then subtract tz offset
        import calendar
        epoch = calendar.timegm(dt.timetuple()) - tz_offset
        return int(epoch)
    except Exception:
        return None


def _ts_to_hhmm(ts):
    """Convert Unix timestamp to 'HH:MM' local time string."""
    if ts is None:
        return ''
    try:
        return datetime.fromtimestamp(ts).strftime('%H:%M')
    except Exception:
        return ''


def _parse_xmltv_bytes(data):
    """Parse XMLTV bytes. Return ``(programmes, channel_names)``.

    ``programmes`` maps XMLTV channel IDs to events. ``channel_names`` maps
    those IDs to all declared ``display-name`` values, which is essential for
    feeds whose IDs do not equal portal channel names.
    """
    try:
        import xml.etree.ElementTree as ET

        # Decompress if gzip
        if data[:2] == b'\x1f\x8b':
            import io
            with gzip.GzipFile(fileobj=io.BytesIO(data)) as gz:
                data = gz.read()

        root = ET.fromstring(data)
    except Exception as exc:
        Logger.error('XMLTV parse error: {}'.format(exc))
        return {}, {}

    result = {}
    channel_names = {}

    for channel in root.iter('channel'):
        channel_id = (channel.get('id') or '').strip()
        if not channel_id:
            continue
        names = []
        for display in channel.findall('display-name'):
            value = (display.text or '').strip()
            if value and value not in names:
                names.append(value)
        channel_names[channel_id] = names

    for prog in root.iter('programme'):
        ch_id = prog.get('channel', '')
        start_ts = _parse_xmltv_time(prog.get('start'))
        stop_ts  = _parse_xmltv_time(prog.get('stop'))

        title_el = prog.find('title')
        title = (title_el.text or '').strip() if title_el is not None else ''

        desc_el = prog.find('desc')
        desc = (desc_el.text or '').strip() if desc_el is not None else ''

        cat_el = prog.find('category')
        genre = (cat_el.text or '').strip() if cat_el is not None else ''

        icon_el = prog.find('icon')
        icon = icon_el.get('src', '') if icon_el is not None else ''

        event = {
            'name':            title,
            't_time':          _ts_to_hhmm(start_ts),
            't_time_to':       _ts_to_hhmm(stop_ts),
            'start_timestamp': start_ts,
            'stop_timestamp':  stop_ts,
            'descr':           desc,
            'genre':           genre,
            'icon':            icon,
        }

        result.setdefault(ch_id, []).append(event)

    # Sort each channel's events by start time
    for ch_id in result:
        result[ch_id].sort(key=lambda e: e.get('start_timestamp') or 0)

    Logger.debug('XMLTV parsed: {} channels, {} events total'.format(
        len(result), sum(len(v) for v in result.values())))
    return result, channel_names
