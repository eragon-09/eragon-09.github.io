# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

"""Portal validity, labels, sorting, diagnostics and health checks."""
import datetime
import re
from urllib.parse import urlparse

import xbmc
import xbmcaddon

try:
    import requests
except Exception:
    requests = None

from .constants import (PORTAL_WARNING_DAYS, PORTAL_GOOD_DAYS,
                        PORTAL_COLOR_ACTIVE, PORTAL_COLOR_NORMAL,
                        PORTAL_COLOR_WARNING, PORTAL_COLOR_EXPIRED)
from .portal_manager_data import (ADDON_ID, DATA_DIR, _ensure_dir, _load_state, _save_state,
                                  _write, normalize_portal_url)

def _normalise_exp(value):
    """Return an expiry date as YYYY-MM-DD from common JSON/TXT variants."""
    if value is None:
        return ''
    text = str(value).strip()
    if not text:
        return ''
    # Accept ISO datetimes as well as the stored YYYY-MM-DD format.
    match = re.search(r'(\d{4})-(\d{2})-(\d{2})', text)
    if match:
        return '{}-{}-{}'.format(*match.groups())
    # Compatibility with German and slash-separated exports.
    match = re.search(r'(\d{1,2})[./](\d{1,2})[./](\d{4})', text)
    if match:
        day, month, year = match.groups()
        return '{:04d}-{:02d}-{:02d}'.format(int(year), int(month), int(day))
    return ''

def _mac_exp(entry):
    """Read expiry from current and legacy MAC object field names."""
    if not isinstance(entry, dict):
        return ''
    return _normalise_exp(
        entry.get('exp') or entry.get('expiry') or entry.get('expires')
        or entry.get('expiration') or entry.get('date')
    )

def _expiry_date(exp):
    """Parse a normalized expiry value without locale-dependent strptime().

    Kodi reloads Python add-on modules while changing skins. On affected Kodi
    installations ``datetime.strptime`` can temporarily fail during that GUI
    reload even though the ISO date itself is valid. Constructing ``date``
    directly from the numeric ISO components is locale independent and keeps
    the expiry status stable across skin changes.
    """
    exp = _normalise_exp(exp)
    if not exp:
        return None
    try:
        year, month, day = (int(part) for part in exp.split('-', 2))
        return datetime.date(year, month, day)
    except (TypeError, ValueError, OverflowError):
        return None


def days_left(exp):
    expiry = _expiry_date(exp)
    if expiry is None:
        return None
    try:
        return (expiry - datetime.date.today()).days
    except Exception:
        return None


def expiry_label(exp):
    exp = _normalise_exp(exp)
    expiry = _expiry_date(exp)
    if expiry is None:
        return '[COLOR grey]Datum unbekannt[/COLOR]'
    d = days_left(exp)
    if d is None:
        return '[COLOR grey]Datum unbekannt[/COLOR]'
    date_label = '{:02d}.{:02d}.{:04d}'.format(expiry.day, expiry.month, expiry.year)
    if d < 0:
        return '[COLOR grey]abgelaufen am {}[/COLOR]'.format(date_label)
    if d <= PORTAL_WARNING_DAYS:
        return '[COLOR red]{} ({} Tage)[/COLOR]'.format(date_label, d)
    if d <= PORTAL_GOOD_DAYS:
        return '[COLOR {}]{} ({} Tage)[/COLOR]'.format(PORTAL_COLOR_WARNING, date_label, d)
    return '[COLOR {}]{} ({} Tage)[/COLOR]'.format(PORTAL_COLOR_ACTIVE, date_label, d)

def sorted_macs(portal):
    active = portal.get('active_mac', '').upper()
    def key(m):
        d = days_left(_mac_exp(m))
        expired = d is not None and d < 0
        unknown = d is None
        return (0 if m.get('mac','').upper() == active else 1, 1 if expired else 0, 1 if unknown else 0, -(d or 0), m.get('mac',''))
    return sorted(portal.get('macs', []), key=key)

def best_mac(portal):
    candidates = []
    for m in portal.get('macs', []):
        d = days_left(_mac_exp(m))
        if d is None or d >= 0:
            candidates.append((d if d is not None else -1, m))
    return max(candidates, key=lambda x: x[0])[1] if candidates else None

def portal_best_days(portal):
    """Return the longest known non-expired validity in days, or None."""
    values = []
    for entry in portal.get('macs', []):
        d = days_left(_mac_exp(entry))
        if d is not None and d >= 0:
            values.append(d)
    return max(values) if values else None

def portal_label(portal, active=False):
    """Return a compact portal selector label with MAC count and validity."""
    count = len({m.get('mac','').upper() for m in portal.get('macs', []) if m.get('mac')})
    name = portal.get('name') or urlparse(portal.get('portal', '')).hostname or portal.get('portal', '')
    best_days = portal_best_days(portal)
    validity = '{} Tage'.format(best_days) if best_days is not None else 'Datum unbekannt'
    color = PORTAL_COLOR_ACTIVE if active else PORTAL_COLOR_NORMAL
    star = '★ ' if active else ''
    return '[COLOR {}]{}{}[/COLOR]  [COLOR grey]({} MACs · {})[/COLOR]'.format(
        color, star, name, count, validity)

def portal_card_label(portal, active=False):
    """Return a compact one-line label with MAC count and best validity."""
    count = len({m.get('mac', '').upper() for m in portal.get('macs', []) if m.get('mac')})
    name = portal.get('name') or urlparse(portal.get('portal', '')).hostname or portal.get('portal', '')
    color = PORTAL_COLOR_ACTIVE if active else PORTAL_COLOR_NORMAL
    marker = '* ' if active else '  '
    best_days = portal_best_days(portal)
    if best_days is None:
        validity = '[COLOR grey]? Tage[/COLOR]'
    elif best_days <= PORTAL_WARNING_DAYS:
        validity = '[COLOR red]{} Tage[/COLOR]'.format(best_days)
    elif best_days <= PORTAL_GOOD_DAYS:
        validity = '[COLOR {}]{} Tage[/COLOR]'.format(PORTAL_COLOR_WARNING, best_days)
    else:
        validity = '[COLOR {}]{} Tage[/COLOR]'.format(PORTAL_COLOR_ACTIVE, best_days)
    return '[COLOR {}]{}{}[/COLOR]  [COLOR grey]({} · [/COLOR]{}[COLOR grey])[/COLOR]'.format(
        color, marker, name, count, validity)

def get_portal_sort_mode():
    """Return the persisted portal-list sort mode."""
    mode = str(_load_state().get('portal_sort_mode') or 'active_name')
    return mode if mode in ('active_name', 'name', 'mac_count', 'validity') else 'active_name'

def set_portal_sort_mode(mode):
    """Persist a supported portal-list sort mode."""
    if mode not in ('active_name', 'name', 'mac_count', 'validity'):
        mode = 'active_name'
    state = _load_state()
    state['portal_sort_mode'] = mode
    _save_state(state)
    return mode

def sort_portals(portals, configured_url=''):
    """Sort a copy of the portal list without changing stored portal data."""
    configured = normalize_portal_url(configured_url)
    mode = get_portal_sort_mode()

    def name_of(portal):
        return (portal.get('name') or urlparse(portal.get('portal', '')).hostname
                or portal.get('portal', '')).casefold()

    def mac_count(portal):
        return len({m.get('mac', '').upper() for m in portal.get('macs', []) if m.get('mac')})

    def validity(portal):
        value = portal_best_days(portal)
        return value if value is not None else -1

    if mode == 'name':
        key = lambda portal: (name_of(portal), portal.get('portal', ''))
    elif mode == 'mac_count':
        key = lambda portal: (-mac_count(portal), name_of(portal))
    elif mode == 'validity':
        key = lambda portal: (-validity(portal), name_of(portal))
    else:
        key = lambda portal: (0 if normalize_portal_url(portal.get('portal', '')) == configured else 1,
                              name_of(portal))
    return sorted(list(portals or []), key=key)

def portal_statistics(portal, warning_days=None):
    from .portal_manager_state import get_auto_switch_days
    """Return read-only MAC statistics for a portal.

    This helper only evaluates locally stored expiry/status metadata. It does
    not contact the portal and therefore cannot affect playback or EPG data.
    """
    if warning_days is None:
        warning_days = get_auto_switch_days()
    unique = {}
    for entry in portal.get('macs', []) or []:
        mac = (entry.get('mac') or '').upper()
        if mac:
            unique[mac] = entry
    known_days = []
    valid = expired = urgent = unknown = disabled = 0
    for entry in unique.values():
        d = days_left(_mac_exp(entry))
        status = str(entry.get('status') or '').strip().lower()
        explicitly_disabled = status in ('invalid', 'failed', 'offline', 'dead', 'error')
        if explicitly_disabled:
            disabled += 1
        if d is None:
            unknown += 1
        elif d < 0:
            expired += 1
        else:
            valid += 1
            known_days.append(d)
            if d <= int(warning_days):
                urgent += 1
    average = int(round(sum(known_days) / float(len(known_days)))) if known_days else None
    return {
        'total': len(unique),
        'valid': valid,
        'expired': expired,
        'urgent': urgent,
        'unknown': unknown,
        'disabled': disabled,
        'best_days': max(known_days) if known_days else None,
        'shortest_days': min(known_days) if known_days else None,
        'average_days': average,
    }

def portal_analysis_text(portal):
    """Build a compact, skin-friendly local analysis text."""
    stats = portal_statistics(portal)

    def days(value):
        return '{} Tage'.format(value) if value is not None else 'unbekannt'

    return (
        'Portal: {name}\nURL: {url}\n\n'
        'MAC-Analyse\n'
        'Gesamt: {total}\n'
        'Gültig: {valid}\n'
        'Bis zur Wechselschwelle: {urgent}\n'
        'Abgelaufen: {expired}\n'
        'Datum unbekannt: {unknown}\n'
        'Als fehlerhaft markiert: {disabled}\n\n'
        'Längste Restlaufzeit: {best}\n'
        'Kürzeste Restlaufzeit: {shortest}\n'
        'Durchschnittliche Restlaufzeit: {average}\n\n'
        'Letzter Import: {last_import}'
    ).format(
        name=portal.get('name') or portal.get('portal') or 'unbekannt',
        url=portal.get('portal') or 'unbekannt',
        last_import=portal.get('last_import') or 'unbekannt',
        best=days(stats['best_days']), shortest=days(stats['shortest_days']),
        average=days(stats['average_days']), **stats)

def create_diagnostic_report(portals, configured_url='', configured_mac=''):
    """Write a privacy-conscious portal report without full MAC addresses."""
    _ensure_dir()
    now = datetime.datetime.now().replace(microsecond=0)
    lines = [
        'Titan Portal-Diagnosebericht',
        'Erstellt: {}'.format(now.isoformat().replace('T', ' ')),
        'Addon-Version: {}'.format(xbmcaddon.Addon(id=ADDON_ID).getAddonInfo('version')),
        'Kodi-Version: {}'.format(xbmc.getInfoLabel('System.BuildVersion') or 'unbekannt'),
        'Python-Version: {}'.format('{}.{}.{}'.format(*__import__('sys').version_info[:3])),
        'Plattform: {}'.format(xbmc.getInfoLabel('System.OSVersionInfo') or 'unbekannt'),
        'Portale: {}'.format(len(portals or [])),
        '',
    ]
    configured = normalize_portal_url(configured_url)
    for portal in portals or []:
        stats = portal_statistics(portal)
        active = normalize_portal_url(portal.get('portal', '')) == configured
        lines.extend([
            '[{}] {}'.format('AKTIV' if active else 'PORTAL', portal.get('name') or portal.get('portal')),
            'URL: {}'.format(portal.get('portal') or 'unbekannt'),
            'MAC-Modus: {}'.format('Automatisch' if portal.get('auto_mac', True) else 'Manuell'),
            'MACs: {total}; gültig: {valid}; bald ablaufend: {urgent}; abgelaufen: {expired}; unbekannt: {unknown}; markiert: {disabled}'.format(**stats),
            'Beste Restlaufzeit: {}'.format(
                '{} Tage'.format(stats['best_days']) if stats['best_days'] is not None else 'unbekannt'),
            'Aktive MAC: {}'.format('gesetzt' if active and configured_mac else 'nicht gesetzt'),
            'Letzter Import: {}'.format(portal.get('last_import') or 'unbekannt'),
            '',
        ])
    filename = 'portal_diagnose_{}.txt'.format(now.strftime('%Y%m%d_%H%M%S'))
    path = '{}/{}'.format(DATA_DIR, filename)
    _write(path, '\n'.join(lines))
    return path

def portal_health(portal, timeout=4):
    """Perform a lightweight reachability check without authenticating a MAC."""
    url = normalize_portal_url(portal.get('portal', ''))
    if not url:
        return False, 'Ungültige Portal-URL'
    # Probe the host root; scanner endpoints such as /c may reject HEAD requests.
    parsed = urlparse(url)
    probe = '{}://{}'.format(parsed.scheme or 'http', parsed.netloc)
    if requests is None:
        return None, 'Statusprüfung nicht verfügbar'
    try:
        response = requests.get(probe, timeout=timeout, allow_redirects=True, stream=True,
                                headers={'User-Agent': 'Kodi Titan Portal Manager'})
        code = int(response.status_code)
        response.close()
        if code < 500:
            return True, 'Online (HTTP {})'.format(code)
        return False, 'Serverfehler (HTTP {})'.format(code)
    except Exception as exc:
        return False, 'Offline oder nicht erreichbar ({})'.format(exc)

def portal_overview(portals, configured_url='', configured_mac=''):
    """Build a readable status summary for the portal manager."""
    configured_normalized = normalize_portal_url(configured_url or '')
    active = next((p for p in portals
                   if normalize_portal_url(p.get('portal', '')) == configured_normalized), None)
    if not active:
        return ('Aktives Portal: keines\nAktive MAC: keine\n\n'
                '{} Portale gespeichert\n{} MAC-Adressen gespeichert').format(
                    len(portals), sum(len(p.get('macs', [])) for p in portals))
    entry = next((m for m in active.get('macs', [])
                  if m.get('mac', '').upper() == (configured_mac or '').upper()), None)
    expiry = expiry_label(_mac_exp(entry or {}))
    valid = sum(1 for m in active.get('macs', [])
                if days_left(_mac_exp(m)) is None or days_left(_mac_exp(m)) >= 0)
    return ('Aktives Portal: {}\nAktive MAC: {}\nLäuft bis: {}\nModus: {}\n\n'
            '{} Portale gespeichert\n{} MACs im aktiven Portal\n{} gültig/unbekannt').format(
                active.get('name') or active.get('portal'), configured_mac or 'keine', expiry,
                'Automatisch' if active.get('auto_mac', True) else 'Manuell',
                len(portals), len(active.get('macs', [])), valid)

