"""Groups helpers for local Live-TV lists."""

from . import core as _core

groups = _core.groups
get_group = _core.get_group
create_group = _core.create_group
create_group_from_names = _core.create_group_from_names
create_default_tv_spielfilm_group = _core.create_default_tv_spielfilm_group
rename_group = _core.rename_group
delete_group = _core.delete_group
move_group = _core.move_group
clean_channel_display_name = _core.clean_channel_display_name
add_channels = _core.add_channels
add_channel = _core.add_channel
get_portal_group_channels = _core.get_portal_group_channels
remove_channel = _core.remove_channel
move_channel = _core.move_channel

__all__ = [
    'groups',
    'get_group',
    'create_group',
    'create_group_from_names',
    'create_default_tv_spielfilm_group',
    'rename_group',
    'delete_group',
    'move_group',
    'clean_channel_display_name',
    'add_channels',
    'add_channel',
    'get_portal_group_channels',
    'remove_channel',
    'move_channel',
]
