"""Modular local Live-TV list services.

The public compatibility interface remains ``lib.local_tv_lists``.
"""
