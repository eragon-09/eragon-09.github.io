"""Matching helpers for local Live-TV lists."""

from . import core as _core

hydrate_portal_channel = _core.hydrate_portal_channel
resolve_playable_portal_channel = _core.resolve_playable_portal_channel
set_mapping = _core.set_mapping
clear_mapping = _core.clear_mapping
portal_key = _core.portal_key
normalize_channel_name = _core.normalize_channel_name
channel_quality_score = _core.channel_quality_score
similarity = _core.similarity
candidates = _core.candidates
build_catalog_identity_index = _core.build_catalog_identity_index
resolve_channel = _core.resolve_channel
mapping_entries = _core.mapping_entries
quality_label = _core.quality_label

__all__ = [
    'hydrate_portal_channel',
    'resolve_playable_portal_channel',
    'set_mapping',
    'clear_mapping',
    'portal_key',
    'normalize_channel_name',
    'channel_quality_score',
    'similarity',
    'candidates',
    'build_catalog_identity_index',
    'resolve_channel',
    'mapping_entries',
    'quality_label',
]
