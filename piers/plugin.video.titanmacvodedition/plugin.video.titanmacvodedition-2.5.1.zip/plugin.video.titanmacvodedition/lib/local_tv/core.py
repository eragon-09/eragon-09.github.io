"""Portal-independent, ordered Live-TV lists.

Only Live TV uses this module. VOD and series favorites remain untouched.
"""

from __future__ import absolute_import, division, unicode_literals
import hashlib
import json
import os
import re
import time
import unicodedata
import zipfile
import shutil
from datetime import datetime
from difflib import SequenceMatcher

from ..api import Api
from .. import portal_index
from .. import channel_search_cache
from .. import channel_index
from ..constants import (
    CHANNEL_ALIASES, CHANNEL_NOISE_WORDS, CHANNEL_QUALITY_BONUSES,
    CHANNEL_QUALITY_PENALTIES, CHANNEL_QUALITY_RULES,
    CHANNEL_QUALITY_SEARCH_WORDS, LOCAL_TV_CATALOG_TTL_SECONDS,
    LOCAL_TV_SCHEMA_VERSION, LOCAL_TV_DEFAULT_TEMPLATE,
    LOCAL_TV_DEFAULT_TEMPLATE_NAME,
)
from ..globals import G
from ..country_filter import filter_categories_for_country_groups, get_configured_country_tokens
from ..loggers import Logger
from ..file_utils import atomic_write_json, read_json, safe_filename
from ..paths import (
    art_slug, bundled_list_template_path, local_tv_art_path, local_tv_catalog_path, local_tv_groups_path,
    local_tv_lists_path, user_art_dir,
)

try:
    import xbmcaddon
except ImportError:
    xbmcaddon = None


# Small in-memory LRU-style cache for repeated manual searches.
_SEARCH_RESULT_CACHE = {}
_SEARCH_RESULT_CACHE_ORDER = []
_SEARCH_RESULT_CACHE_LIMIT = 24


def _empty_data():
    return {'schema': LOCAL_TV_SCHEMA_VERSION, 'groups': [], 'sync_notices': {}}


def _read_json(path, default):
    value = read_json(path, default)
    return default if value is None and default is not None else value


def _atomic_write(path, value):
    if not atomic_write_json(path, value, prefix='.local_tv_'):
        raise OSError('Could not write {}'.format(path))


def load_data():
    data = _read_json(local_tv_lists_path(), _empty_data())
    if not isinstance(data, dict) or not isinstance(data.get('groups'), list):
        return _empty_data()
    data['schema'] = LOCAL_TV_SCHEMA_VERSION
    if not isinstance(data.get('sync_notices'), dict):
        data['sync_notices'] = {}
    changed = False
    for group in data.get('groups', []):
        for channel in group.get('channels', []):
            old_name = str(channel.get('name', '') or '')
            clean_name = clean_channel_display_name(old_name) or old_name
            if clean_name != old_name:
                aliases = list(channel.get('aliases') or [])
                if old_name and old_name not in aliases:
                    aliases.append(old_name)
                if clean_name and clean_name not in aliases:
                    aliases.append(clean_name)
                channel['aliases'] = aliases
                channel['name'] = clean_name
                changed = True
            # Keep an explicit portal-independent identity beside the visible
            # station name. Older list files are upgraded transparently.
            identity = normalize_channel_name(channel.get('name', ''))
            if identity and channel.get('normalized_name') != identity:
                channel['normalized_name'] = identity
                changed = True
    if changed:
        save_data(data)
    return data


def save_data(data):
    try:
        _atomic_write(local_tv_lists_path(), data)
        return True
    except Exception as exc:
        Logger.error('Could not save local TV lists: {}'.format(exc))
        return False


def groups():
    return load_data()['groups']


def get_group(group_id):
    return next((group for group in groups() if group.get('id') == group_id), None)


def _new_id(prefix, text):
    raw = '{}|{}|{}'.format(prefix, text, time.time_ns())
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:16]


def create_group(name):
    name = str(name or '').strip()
    if not name:
        return None
    data = load_data()
    group = {'id': _new_id('group', name), 'name': name, 'channels': []}
    data['groups'].append(group)
    return group if save_data(data) else None


def _channel_record_from_name(name):
    display_name = clean_channel_display_name(name)
    if not display_name:
        return None
    return {
        'id': _new_id('channel', display_name),
        'name': display_name,
        'normalized_name': normalize_channel_name(display_name),
        'logo': '',
        'aliases': [display_name],
        'mappings': {},
    }


def create_group_from_names(name, channel_names):
    """Create an ordered local group from portal-independent channel names."""
    name = str(name or '').strip()
    if not name:
        return {'status': 'invalid', 'group': None, 'count': 0}
    data = load_data()
    if any(str(group.get('name', '')).strip().lower() == name.lower() for group in data['groups']):
        return {'status': 'exists', 'group': None, 'count': 0}
    channels = []
    seen = set()
    for value in channel_names or []:
        record = _channel_record_from_name(value)
        if not record:
            continue
        normalized = normalize_channel_name(record['name'])
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        channels.append(record)
    group = {'id': _new_id('group', name), 'name': name, 'channels': channels}
    data['groups'].append(group)
    return {
        'status': 'created' if save_data(data) else 'error',
        'group': group,
        'count': len(channels),
    }


def create_default_tv_spielfilm_group():
    """Create the bundled TV Spielfilm list while preserving file order."""
    path = bundled_list_template_path(LOCAL_TV_DEFAULT_TEMPLATE)
    try:
        with open(path, 'r', encoding='utf-8-sig') as handle:
            names = [
                line.strip() for line in handle
                if line.strip() and not line.lstrip().startswith('#')
            ]
    except Exception as exc:
        Logger.error('Could not read local TV template {}: {}'.format(path, exc))
        return {'status': 'error', 'group': None, 'count': 0}
    return create_group_from_names(LOCAL_TV_DEFAULT_TEMPLATE_NAME, names)


def rename_group(group_id, name):
    name = str(name or '').strip()
    if not name:
        return False
    data = load_data()
    for group in data['groups']:
        if group.get('id') == group_id:
            group['name'] = name
            return save_data(data)
    return False


def delete_group(group_id):
    data = load_data()
    before = len(data['groups'])
    data['groups'] = [group for group in data['groups'] if group.get('id') != group_id]
    return before != len(data['groups']) and save_data(data)


def move_group(group_id, direction):
    data = load_data()
    index = next((i for i, group in enumerate(data['groups']) if group.get('id') == group_id), -1)
    target = index + int(direction)
    if index < 0 or target < 0 or target >= len(data['groups']):
        return False
    data['groups'][index], data['groups'][target] = data['groups'][target], data['groups'][index]
    return save_data(data)


def clean_channel_display_name(name):
    """Return a Kodi-safe local display name while preserving the portal name elsewhere.

    Portal lists often prefix channel names with flags, emoji, private-use glyphs or
    decorative separators. These characters can appear as empty squares in Kodi.
    Only leading decoration is removed; normal punctuation inside the station name
    remains untouched.
    """
    text = unicodedata.normalize('NFKC', str(name or '')).strip()
    if not text:
        return ''
    # Remove control/format/private-use characters throughout the visible label.
    text = ''.join(char for char in text if unicodedata.category(char)[0] != 'C')
    # Strip leading symbols, punctuation and separators until the first letter/number.
    text = re.sub(r'^[^\w]+', '', text, flags=re.UNICODE)
    return re.sub(r'\s+', ' ', text).strip()


def _channel_record(channel):
    portal_name = str(channel.get('name', '') or '').strip()
    display_name = clean_channel_display_name(portal_name) or portal_name
    aliases = [portal_name] if portal_name else []
    if display_name and display_name not in aliases:
        aliases.append(display_name)
    return {
        'id': _new_id('channel', display_name),
        'name': display_name,
        'normalized_name': normalize_channel_name(display_name),
        'logo': channel.get('logo', ''),
        'aliases': aliases,
        'mappings': {portal_key(): _mapping_payload(channel)},
    }


def add_channels(group_id, channels):
    data = load_data()
    for group in data['groups']:
        if group.get('id') != group_id:
            continue
        existing = {normalize_channel_name(item.get('name', '')) for item in group['channels']}
        added = 0
        skipped = 0
        for channel in channels or []:
            normalized = normalize_channel_name(channel.get('name', ''))
            if not normalized or normalized in existing:
                skipped += 1
                continue
            group['channels'].append(_channel_record(channel))
            existing.add(normalized)
            added += 1
        if not added:
            return {'status': 'exists', 'added': 0, 'skipped': skipped}
        saved = save_data(data)
        if saved:
            cache_portal_channels(channels)
        return {
            'status': 'added' if saved else 'error',
            'added': added,
            'skipped': skipped,
        }
    return {'status': 'missing_group', 'added': 0, 'skipped': 0}


def add_channel(group_id, channel):
    return add_channels(group_id, [channel]).get('status')


def get_portal_group_channels(category_id):
    channels = []
    page = 1
    while True:
        listing = Api.get_tv_channels(category_id, page, '', 0)
        page_data = listing.get('data') or []
        channels.extend(_mapping_payload(channel) for channel in page_data)
        max_items = max(1, int(listing.get('max_page_items') or 1))
        total = int(listing.get('total_items') or len(page_data))
        if not page_data or page * max_items >= total:
            break
        page += 1
    return channels


def remove_channel(group_id, channel_id):
    data = load_data()
    for group in data['groups']:
        if group.get('id') == group_id:
            before = len(group['channels'])
            group['channels'] = [item for item in group['channels'] if item.get('id') != channel_id]
            return before != len(group['channels']) and save_data(data)
    return False


def move_channel(group_id, channel_id, direction):
    data = load_data()
    for group in data['groups']:
        if group.get('id') != group_id:
            continue
        index = next((i for i, item in enumerate(group['channels']) if item.get('id') == channel_id), -1)
        target = index + int(direction)
        if index < 0 or target < 0 or target >= len(group['channels']):
            return False
        group['channels'][index], group['channels'][target] = group['channels'][target], group['channels'][index]
        return save_data(data)
    return False


def _mapping_identity_keys(channel):
    """Return stable identifiers used to hydrate skeletal search results."""
    keys = set()
    for field in ('id', 'ch_id', 'channel_id', 'epg_id'):
        value = str((channel or {}).get(field) or '').strip()
        if value:
            keys.add((field, value))
    identity = normalize_channel_name((channel or {}).get('name', ''))
    if identity:
        keys.add(('identity', identity))
    return keys


def hydrate_portal_channel(portal_channel, catalog=None):
    """Replace incomplete portal search records with a playable catalogue item.

    Some Stalker portals return only ``id`` and ``name`` for server-side search
    results. Persisting such a record creates a manual mapping without ``cmd``;
    the list then still shows "nicht verfügbar". Prefer a matching entry from
    the filtered portal catalogue whenever the selected result is skeletal.
    """
    payload = _mapping_payload(portal_channel or {})
    if payload.get('cmd'):
        return payload

    wanted = _mapping_identity_keys(payload)
    source = catalog if catalog is not None else get_cached_portal_catalog()
    best = None
    for candidate in source or []:
        candidate_payload = _mapping_payload(candidate)
        if not candidate_payload.get('cmd'):
            continue
        candidate_keys = _mapping_identity_keys(candidate_payload)
        if wanted.intersection(candidate_keys):
            if best is None or _quality_sort_key(candidate_payload) < _quality_sort_key(best):
                best = candidate_payload
    return best or payload


def resolve_playable_portal_channel(portal_channel, catalog=None):
    """Resolve a selected search result to a complete, playable portal record.

    Several portals return skeletal records from server-side searches.  The
    visible name is correct, but ``cmd`` is missing.  Manual mapping must not
    treat that as "not found".  We first hydrate from the local index, then ask
    the portal again using the selected station name and finally search the
    station's advertised group(s).  Only an identity-equal result is accepted.
    """
    selected = _mapping_payload(portal_channel or {})
    playable = hydrate_portal_channel(selected, catalog=catalog)
    if playable.get('cmd'):
        return playable

    wanted_identity = normalize_channel_name(selected.get('name', ''))
    if not wanted_identity:
        return selected

    terms = []
    for value in (selected.get('name', ''), _quality_neutral_search_term(selected.get('name', ''))):
        value = str(value or '').strip()
        if value and value.casefold() not in [item.casefold() for item in terms]:
            terms.append(value)

    # Search only likely groups first. This is fast and commonly returns the
    # complete record even when the portal-wide result omitted ``cmd``.
    group_ids = []
    for value in list(selected.get('group_ids') or []) + [selected.get('genre_id')]:
        value = str(value or '').strip()
        if value and value not in group_ids:
            group_ids.append(value)

    def consider(items):
        best = None
        for item in items or []:
            payload = _mapping_payload(item)
            if not payload.get('cmd'):
                continue
            if normalize_channel_name(payload.get('name', '')) != wanted_identity:
                continue
            if best is None or _quality_sort_key(payload) < _quality_sort_key(best):
                best = payload
        return best

    for group_id in group_ids:
        for term in terms:
            try:
                listing = Api.get_tv_channels(group_id, 1, term, 0)
                best = consider(listing.get('data') or [])
                if best:
                    cache_portal_channels([best])
                    return best
            except Exception as exc:
                Logger.warn('Playable channel lookup failed for {} in group {}: {}'.format(term, group_id, exc))

    # Portal-wide fallback. Some servers support genre="*" and return the full
    # object here even though an earlier cached search result was skeletal.
    for term in terms:
        try:
            best = consider(_search_portal_channels(term))
            if best:
                cache_portal_channels([best])
                return best
        except Exception as exc:
            Logger.warn('Portal-wide playable channel lookup failed for {}: {}'.format(term, exc))

    # Last, inspect cached groups that contain the same identity. This remains
    # network-free and also repairs older incomplete mappings after an index
    # refresh.
    best = consider(get_cached_portal_catalog())
    return best or selected


def set_mapping(group_id, channel_id, portal_channel):
    playable = resolve_playable_portal_channel(portal_channel)
    if not playable.get('cmd'):
        Logger.warn('Manual mapping rejected because selected channel has no playable cmd: {}'.format(
            playable.get('name', '')
        ))
        return False

    data = load_data()
    for group in data['groups']:
        if group.get('id') != group_id:
            continue
        for item in group['channels']:
            if item.get('id') == channel_id:
                selected = _mapping_payload(playable)
                selected['manual'] = True
                item.setdefault('mappings', {})[portal_key()] = selected
                # Do not teach the automatic matcher an unverified alias.
                # A manually selected alternative must remain portal-specific.
                return save_data(data)
    return False


def clear_mapping(group_id, channel_id):
    data = load_data()
    for group in data['groups']:
        if group.get('id') != group_id:
            continue
        for item in group['channels']:
            if item.get('id') == channel_id:
                item.setdefault('mappings', {}).pop(portal_key(), None)
                return save_data(data)
    return False


def portal_key():
    return portal_index.portal_key()


def _mapping_payload(channel):
    return portal_index.mapping_payload(channel)

def _strip_portal_prefixes(value):
    """Remove only known leading provider/country decorations, never station variants."""
    text = unicodedata.normalize('NFKC', str(value or '')).strip()
    # Country markers are meaningful as metadata, but not as station identity.
    for _ in range(5):
        before = text
        text = re.sub(r'^\s*(?:DE|AT|CH|GER|AUT|SUI)\s*[:|]\s*', '', text, flags=re.I)
        text = re.sub(r'^\s*(?:[|\[({]\s*)?(?:VIP|WOW|AMZ)(?:\s*[|\])}]\s*)?\s*[:|\-]?\s+', '', text, flags=re.I)
        # Also support a prefix directly followed by a pipe, e.g. |WOW|SKY.
        text = re.sub(r'^\s*\|(?:VIP|WOW|AMZ)\|\s*', '', text, flags=re.I)
        if text == before:
            break
    return text.strip()


def manual_search_term(value):
    """Broad search term without provider and terminal picture-quality labels."""
    text = _strip_portal_prefixes(value)
    text = re.sub(r'(?:\s|[-_])+\b(?:FHD|FULL\s*HD|UHD|HD|SD|4K|8K|HEVC|1080P|720P|2160P)\b\s*$', '', text, flags=re.I)
    return text.strip()


def _normalize_match_text(value):
    """Return a case-insensitive, punctuation-neutral text for station matching.

    This is the single normalization entry point used before aliases and fuzzy
    matching.  It deliberately transliterates German characters in a stable
    way instead of relying on the portal's capitalization or punctuation.
    """
    text = _strip_portal_prefixes(value).casefold()
    replacements = {
        'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss',
        '&': ' und ', '+': ' plus ',
    }
    for source, target in replacements.items():
        text = text.replace(source, target)
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
    text = re.sub(r'[()\[\]{}]', ' ', text)
    text = re.sub(r'[.\-_/|:]+', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _channel_alias_database_path():
    """Return the bundled, data-driven alias catalogue path."""
    return os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'resources', 'data', 'channel_aliases.json',
    )


def _load_channel_aliases():
    """Merge built-in safety aliases with the maintainable JSON catalogue.

    The Python constants remain a compatibility fallback. New station spellings
    can be maintained in ``resources/data/channel_aliases.json`` without
    touching the matcher implementation. Malformed optional entries are ignored
    so a single typo cannot prevent the add-on from starting.
    """
    aliases = dict(CHANNEL_ALIASES)
    alias_path = _channel_alias_database_path()
    if not os.path.isfile(alias_path):
        Logger.debug('Optionale Sender-Aliasdatenbank nicht gefunden: {}'.format(alias_path))
        return aliases
    try:
        with open(alias_path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict):
            raise TypeError('Aliasdatenbank muss ein JSON-Objekt enthalten')
        for station in payload.get('stations', []):
            canonical = str(station.get('id') or '').strip()
            if not canonical:
                continue
            candidates = [canonical, station.get('name')] + list(station.get('aliases') or [])
            for candidate in candidates:
                candidate = str(candidate or '').strip()
                if candidate:
                    aliases[candidate] = canonical
    except (OSError, ValueError, TypeError) as exc:
        Logger.warning('Sender-Aliasdatenbank konnte nicht geladen werden: %s' % exc)
    return aliases


def _alias_lookup_tables():
    """Build O(1) alias lookup tables once per Kodi plugin invocation.

    Version 1.3.3 applied every alias as a regular expression to every channel
    name. With several hundred aliases and a large portal catalogue this became
    noticeably expensive whenever Kodi rebuilt ``Meine Sender`` after playback.
    The matcher now reduces a name to a compact, quality-neutral key and performs
    a dictionary lookup instead.
    """
    phrase_lookup = {}
    compact_lookup = {}
    for source, target in _load_channel_aliases().items():
        normalized_source = _normalize_match_text(source)
        normalized_target = _normalize_match_text(target).replace(' ', '')
        if not normalized_source or not normalized_target:
            continue
        phrase_lookup[normalized_source] = normalized_target
        source_tokens = re.findall(r'[a-z0-9]+', normalized_source)
        source_tokens = [token for token in source_tokens if token not in CHANNEL_NOISE_WORDS]
        compact_source = ''.join(source_tokens)
        if compact_source:
            compact_lookup[compact_source] = normalized_target
    return phrase_lookup, compact_lookup


_NORMALIZED_CHANNEL_ALIAS_LOOKUP, _COMPACT_CHANNEL_ALIAS_LOOKUP = _alias_lookup_tables()


def _identity_without_aliases(name):
    """Return the cosmetic/quality-neutral station spelling before aliases.

    This lets the UI distinguish a direct spelling match (100 %) from a known
    alias such as ``PRO7`` versus ``ProSieben`` (98 %), without weakening the
    canonical station identity used for grouping and automatic resolution.
    """
    text = _normalize_match_text(name)
    tokens = re.findall(r'[a-z0-9]+', text)
    tokens = [token for token in tokens if token not in CHANNEL_NOISE_WORDS]
    return ''.join(tokens)


def normalize_channel_name(name):
    """Return the canonical station identity using constant-time alias lookup."""
    text = _normalize_match_text(name)
    if not text:
        return ''

    # Fast path for a complete known spelling.
    direct = _NORMALIZED_CHANNEL_ALIAS_LOOKUP.get(text)
    if direct:
        return direct

    tokens = re.findall(r'[a-z0-9]+', text)
    tokens = [token for token in tokens if token not in CHANNEL_NOISE_WORDS]
    compact = ''.join(tokens)
    if not compact:
        return ''

    # Most portal labels differ only by country/quality decorations. Those
    # tokens are removed above, so aliases can be resolved by one dictionary
    # access rather than hundreds of regex substitutions.
    alias_identity = _COMPACT_CHANNEL_ALIAS_LOOKUP.get(compact)
    if alias_identity:
        return alias_identity

    # Compatibility rules for regional names whose decorations may occur in
    # the middle of a portal label.
    compact_aliases = {
        'ndrmecklenburgvorpommern': 'ndrmv', 'ndrfsmecklenburgvorpommern': 'ndrmv',
        'ndrfernsehenmecklenburgvorpommern': 'ndrmv', 'ndrfernsehenmv': 'ndrmv',
        'ndrmecklenburgvorpommernhd': 'ndrmv', 'ndrfsmv': 'ndrmv',
        'ndrhamburg': 'ndrhh', 'ndrfernsehenhamburg': 'ndrhh', 'ndrhh': 'ndrhh',
        'ndrniedersachsen': 'ndrni', 'ndrfernsehenniedersachsen': 'ndrni', 'ndrni': 'ndrni',
        'ndrschleswigholstein': 'ndrsh', 'ndrfernsehenschleswigholstein': 'ndrsh', 'ndrsh': 'ndrsh',
        'bayerischesfernsehen': 'br', 'brfernsehen': 'br', 'brfernsehensued': 'brsued', 'brfernsehnord': 'brnord', 'brfernsehensud': 'brsued',
        'hessischerrundfunk': 'hr', 'hrfernsehen': 'hr', 'hessenfernsehen': 'hr',
        'rbbfernsehen': 'rbb', 'rbbfernsehenberlin': 'rbb', 'rbbfernsehenbrandenburg': 'rbb',
        'swrfernsehen': 'swr', 'swrfernsehenbw': 'swrbw', 'swrfernsehenrp': 'swrrp',
        'srfernsehen': 'sr', 'radiobremen': 'radiobremen', 'radiobrementv': 'radiobremen',
        'kabeleins': 'kabeleins', 'sat1gold': 'sat1gold', 'pro7maxx': 'pro7maxx',
        'rtlup': 'rtlup', 'superrtl': 'superrtl', 'rtlzwei': 'rtl2', 'rtl2': 'rtl2',
        'rtlzw': 'rtl2', 'prosieben': 'pro7', 'prosiebenmaxx': 'pro7maxx',
        'prosiebenfun': 'pro7fun', 'kabel1': 'kabeleins', 'kabeleinsdoku': 'kabeleinsdoku',
        'sat1emotions': 'sat1emotions', 'sat1comedy': 'sat1comedy', 'zdfinfo': 'zdfinfo',
        'zdfneo': 'zdfneo', 'tagesschau24': 'tagesschau24', 'orfeins': 'orf1',
        'orfzwei': 'orf2', 'orfiii': 'orf3', 'srfeins': 'srf1', 'srfzwei': 'srf2',
        'servustv': 'servustv', 'ntv': 'ntv', 'ntvde': 'ntv', 'n24': 'welt',
        'welttv': 'welt', 'rictvtv': 'rictv',
    }
    return compact_aliases.get(compact, compact)


def channel_quality_score(name):
    """Rank a portal label by advertised quality.

    This is deliberately applied only after the station identity has matched.
    It evaluates the portal label, not the actual decoded stream properties.
    """
    text = _normalize_match_text(name)
    quality = 0
    for score, patterns in CHANNEL_QUALITY_RULES:
        if any(re.search(pattern, text, re.IGNORECASE) for pattern in patterns):
            quality = max(quality, score)
    for bonus, pattern in CHANNEL_QUALITY_BONUSES:
        if re.search(pattern, text, re.IGNORECASE):
            quality += bonus
    for penalty, pattern in CHANNEL_QUALITY_PENALTIES:
        if re.search(pattern, text, re.IGNORECASE):
            quality += penalty
    return quality


def _quality_neutral_search_term(name):
    """Create a portal search term without quality/codec decorations."""
    text = clean_channel_display_name(name)
    if not text:
        return ''
    tokens = re.findall(r'[A-Za-z0-9+]+', unicodedata.normalize('NFKC', text))
    kept = [token for token in tokens if token.lower() not in CHANNEL_QUALITY_SEARCH_WORDS]
    return ' '.join(kept).strip()


def _quality_sort_key(channel):
    return (-channel_quality_score(channel.get('name', '')), channel.get('name', '').lower())


def similarity(saved_name, portal_name):
    """Return a station-aware similarity score.

    A general text matcher alone produces misleading suggestions such as
    KIKA -> HEIMATKANAL or DISNEY -> DISCOVERY.  Known aliases are
    canonicalized first.  Fuzzy comparison is then allowed only when the
    beginning of both station identities agrees.
    """
    left = normalize_channel_name(saved_name)
    right = normalize_channel_name(portal_name)
    if not left or not right:
        return 0.0
    if left == right:
        # Cosmetic differences (country prefix, quality, punctuation) are a
        # direct match.  A canonical alias is intentionally shown just below
        # 100 % so users can see that e.g. PRO7 and ProSieben were equated by a
        # known rule rather than by fuzzy guessing.
        raw_left = _identity_without_aliases(saved_name)
        raw_right = _identity_without_aliases(portal_name)
        return 1.0 if raw_left == raw_right else 0.98

    # Remaining suffixes are part of the station identity. Quality, country and
    # decoration tokens have already been removed, so ``pro7fun`` and
    # ``pro7maxx`` must not inherit a high score merely because they start with
    # ``pro7``. Genuine spelling variations are handled by aliases or by the
    # guarded SequenceMatcher comparison below.

    if left.startswith(right) or right.startswith(left):
        return 0.0

    # Require a meaningful common prefix before any fuzzy score is accepted.
    # Four characters distinguish DISNEY from DISCOVERY and NICK from NITRO.
    prefix_length = min(4, len(left), len(right))
    if prefix_length < 2 or left[:prefix_length] != right[:prefix_length]:
        return 0.0

    ratio = SequenceMatcher(None, left, right).ratio()
    return ratio if ratio >= 0.72 else 0.0


def _active_country_tokens():
    return portal_index.active_country_tokens()


def get_cached_portal_catalog():
    return portal_index.get_cached_channels()


def get_cached_portal_group_channels(group_id):
    return portal_index.get_cached_group_channels(group_id)


def cache_portal_channels(channels):
    return portal_index.merge_channels(channels)


def cache_portal_groups(groups):
    return portal_index.cache_groups(groups)


def get_cached_portal_groups():
    return portal_index.load_cached_groups()


def get_or_load_portal_groups():
    return portal_index.get_or_load_groups()


def build_filtered_portal_index(force=False, progress_callback=None, cancel_callback=None):
    return portal_index.build_index(force=force, progress_callback=progress_callback,
                                    cancel_callback=cancel_callback)

def build_all_portal_index(force=False, progress_callback=None, cancel_callback=None):
    return portal_index.build_all_index(force=force, progress_callback=progress_callback,
                                        cancel_callback=cancel_callback)

def get_cached_all_portal_catalog():
    return portal_index.get_cached_all_channels()


def filter_catalog_for_active_country_groups(channels):
    """Filter the complete portal catalogue to configured DE/AT/CH groups.

    Both manual search modes now share one complete catalogue.  This helper
    performs a purely local filter using the current portal's genre metadata,
    so no second channel index or network search is involved.
    """
    try:
        genres, _ = get_or_load_portal_groups()
    except Exception as exc:
        Logger.warn('Could not load portal groups for country filter: {}'.format(exc))
        genres = get_cached_portal_groups() or []
    allowed = filter_categories_for_country_groups(
        genres or [], tokens=set(_active_country_tokens())
    )
    allowed_ids = {str(item.get('id')) for item in allowed if item.get('id') is not None}
    allowed_titles = {
        str(item.get('title') or item.get('name') or '').strip().casefold()
        for item in allowed
        if str(item.get('title') or item.get('name') or '').strip()
    }
    if not allowed_ids and not allowed_titles:
        return []

    filtered = []
    for channel in channels or []:
        group_ids = {str(value) for value in (channel.get('group_ids') or [])}
        for value in (channel.get('genre_id'), channel.get('tv_genre_id')):
            if value not in (None, ''):
                group_ids.add(str(value))
        group_titles = {
            str(value or '').strip().casefold()
            for value in (channel.get('group_titles') or [])
            if str(value or '').strip()
        }
        category_name = str(channel.get('category_name') or '').strip().casefold()
        if category_name:
            group_titles.add(category_name)
        if group_ids.intersection(allowed_ids) or group_titles.intersection(allowed_titles):
            filtered.append(channel)
    return filtered


def get_portal_catalog(force=False):
    return portal_index.build_index(force=force).get('channels') or []

def _search_portal_channels(search_term):
    """Search the active portal without downloading its full TV catalog."""
    term = str(search_term or '').strip()
    if not term:
        return []
    found = []
    seen = set()
    # Most Stalker portals support a portal-wide search with genre="*".
    # A small category fallback covers portals that ignore that convention.
    category_ids = ['*']
    try:
        genres = Api.get_tv_genres() or []
    except Exception as exc:
        Logger.warn('Could not load TV genres for local sync: {}'.format(exc))
        genres = []
    category_ids.extend([genre.get('id') for genre in genres if genre.get('id') is not None])
    for category_id in category_ids:
        try:
            listing = Api.get_tv_channels(category_id, 1, term, 0)
        except Exception as exc:
            Logger.warn('Local TV search failed for {} in {}: {}'.format(term, category_id, exc))
            continue
        for channel in listing.get('data') or []:
            payload = _mapping_payload(channel)
            key = '{}|{}'.format(payload.get('id', ''), payload.get('name', ''))
            if key not in seen:
                seen.add(key)
                found.append(payload)
        # Stop early when the portal-wide search already returned useful data.
        if category_id == '*' and found:
            break
    return found



def search_portal_channels(query, channels=None, all_groups=False, limit=100):
    """Search portal channels quickly for manual mapping.

    ``all_groups=False`` searches only the already filtered DE/AT/CH index.
    ``all_groups=True`` uses the portal's server-side search and therefore does
    not need to download every country/group before showing results.
    """
    term = str(query or '').strip()
    if not term:
        return []

    if all_groups:
        source = channels or get_cached_all_portal_catalog()
    else:
        source = channels or get_cached_portal_catalog()
    if not source and not all_groups:
        source = build_filtered_portal_index().get('channels') or []

    # Large catalogues are narrowed through a persistent SQLite index first.
    # Final alias, similarity and quality ranking below remains authoritative.
    original_source = source
    scope = '{}:{}'.format(portal_key(), 'all' if all_groups else 'filtered')
    shared_index = channel_index.get_index(
        source, scope, normalize_channel_name, channel_quality_score
    )
    # Search the complete cached catalogue. An index based on literal names can
    # drop e.g. "DE: VIP SUPER RTL HD" for a query of "SUPER RTL".
    # Keep the shared index for other callers, but do not narrow this search.
    term = manual_search_term(term) or term

    term_fold = manual_search_term(term).casefold()
    term_identity = normalize_channel_name(term)
    cache_key = (id(original_source), len(original_source or []), term_fold, bool(all_groups), int(limit or 100))
    cached = _SEARCH_RESULT_CACHE.get(cache_key)
    if cached is not None:
        return list(cached)
    ranked = []
    # Map normalized station identities to their currently best candidate.
    # This must be a dict because the ranking code uses .get()/.values().
    seen = {}
    for channel in source or []:
        name = str(channel.get('name') or '').strip()
        if not name:
            continue
        clean = clean_channel_display_name(name)
        clean_fold = manual_search_term(clean).casefold()
        identity = normalize_channel_name(name)
        score = similarity(term, name)

        # Keep substring searches intuitive, while aliases/normalization cover
        # inputs such as PRO7, RTL2, Nat Geo and cosmetic HD/UHD suffixes.
        if clean_fold == term_fold:
            rank = 0
        elif clean_fold.startswith(term_fold):
            rank = 1
        elif term_fold in clean_fold:
            rank = 2
        elif term_identity and identity == term_identity:
            rank = 3
        elif score >= 0.72:
            rank = 4
        else:
            continue

        quality = channel_quality_score(name)
        payload = _mapping_payload(channel)

        # Keep every real portal stream variant.  HD/FHD/UHD/HEVC entries often
        # normalize to the same station identity, but they are separate streams
        # and must be selectable individually.  Only collapse records that refer
        # to the same portal channel/command (for example duplicate group rows).
        channel_id = str(payload.get('id') or payload.get('channel_id') or payload.get('ch_id') or '').strip()
        command = str(payload.get('cmd') or '').strip()
        if channel_id:
            duplicate_key = 'id:' + channel_id
        elif command:
            duplicate_key = 'cmd:' + command
        else:
            duplicate_key = 'name:' + clean_fold

        # A playable duplicate must always beat a skeletal server-search record.
        # Quality is used for ordering, not for removing another stream variant.
        playable_rank = 0 if command else 1
        candidate = (rank, playable_rank, -score, -quality, clean_fold, payload)
        current = seen.get(duplicate_key)
        if current is None or candidate[:5] < current[:5]:
            seen[duplicate_key] = candidate

    ranked = sorted(seen.values(), key=lambda item: item[:5])
    result = [item[5] for item in ranked[:max(1, int(limit or 100))]]
    _SEARCH_RESULT_CACHE[cache_key] = list(result)
    _SEARCH_RESULT_CACHE_ORDER.append(cache_key)
    while len(_SEARCH_RESULT_CACHE_ORDER) > _SEARCH_RESULT_CACHE_LIMIT:
        expired = _SEARCH_RESULT_CACHE_ORDER.pop(0)
        _SEARCH_RESULT_CACHE.pop(expired, None)
    return result


def _requested_quality_tier(name):
    """Return the explicitly requested quality tier, or zero when unspecified."""
    text = _normalize_match_text(name)
    rules = (
        (500, r'(?<![a-z0-9])(?:4k\+?|4\+|uhd|2160p?)(?![a-z0-9])'),
        (450, r'(?<![a-z0-9])raw(?![a-z0-9])'),
        (400, r'(?<![a-z0-9])(?:fhd|full[ ._-]*hd|1080p?|hd\+)(?![a-z0-9])'),
        (350, r'(?<![a-z0-9])(?:hevc|h[ ._-]*265|x265)(?![a-z0-9])'),
        (300, r'(?<![a-z0-9])(?:hd|720p?)(?![a-z0-9])'),
        (100, r'(?<![a-z0-9])(?:sd|576p?|480p?)(?![a-z0-9])'),
    )
    for tier, pattern in rules:
        if re.search(pattern, text, re.IGNORECASE):
            return tier
    return 0


def _automatic_variant_sort_key(saved, pair):
    """Prefer the saved quality when available, otherwise the best variant."""
    station_score, channel = pair
    # Prefer FHD, HD, UHD, SD for the same recognized station identity.
    def preference(name):
        tier = _requested_quality_tier(name)
        if tier == 400: return 0
        if tier in (300, 350): return 1
        if tier in (450, 500): return 2
        if tier == 100: return 3
        return 4
    return (preference(channel.get('name', '')), -station_score,
            channel.get('name', '').lower())


def _station_variant_guard(name):
    """Distinguish regional feeds and independently branded station offshoots.

    This is checked even for aliases created by older sync versions, which may
    have accidentally recorded the wrong portal station as a valid alias.
    """
    text = _normalize_match_text(name)
    tokens = set(re.findall(r'[a-z0-9]+', text))
    compact = ''.join(token for token in tokens if token not in CHANNEL_NOISE_WORDS)
    if re.search(r'\b(?:br|bayerisches)\b', text) or compact.startswith('brfernsehen'):
        if re.search(r'\b(?:sued|sud|south)\b', text) or 'brfernsehensued' in compact:
            return 'br:sued'
        if re.search(r'\b(?:nord|north)\b', text) or 'brfernsehnord' in compact:
            return 'br:nord'
        return 'br:generic'
    if re.search(r'\bswr\b', text) or compact.startswith('swr'):
        if re.search(r'\b(?:bw|baden|wuerttemberg)\b', text) or 'swrbw' in compact:
            return 'swr:bw'
        if re.search(r'\b(?:rp|rheinland|pfalz)\b', text) or 'swrrp' in compact:
            return 'swr:rp'
        return 'swr:generic'
    if re.search(r'\bndr\b', text) or compact.startswith('ndr'):
        for tag, pattern in [('mv', r'\b(?:mv|mecklenburg|vorpommern)\b'),
                             ('hh', r'\b(?:hh|hamburg)\b'),
                             ('ni', r'\b(?:ni|niedersachsen)\b'),
                             ('sh', r'\b(?:sh|schleswig|holstein)\b')]:
            if re.search(pattern, text) or compact.startswith('ndr' + tag):
                return 'ndr:' + tag
        return 'ndr:generic'
    # Distinguish numbered Sky feeds, including Sport/Bundesliga variants.
    sky = re.search(r'\bsky\s+(sport\s+bundesliga|sport|cinema)\s+(\d+)\b', text)
    if sky:
        return 'sky:{}:{}'.format(re.sub(r'\s+', '', sky.group(1)), sky.group(2))
    if re.search(r'\banixe\s*plus\b|\banixe\s*\+', str(name or '').casefold()) or 'anixeplus' in compact:
        return 'anixe:plus'
    if re.search(r'\banixe\b', text):
        return 'anixe:main'
    return ''


def _safe_station_identity(name):
    """Canonical identity without unsafe regional aliases from old releases."""
    guard = _station_variant_guard(name)
    if guard:
        return guard
    return normalize_channel_name(name)


def _best_automatic_match(saved, candidates_list):
    """Only auto-assign the same proven station, never a fuzzy neighbour."""
    primary = _safe_station_identity(saved.get('name', ''))
    if not primary:
        return None
    # Old auto-sync releases added portal labels to aliases. They are not proof
    # of identity and must not authorize a different regional or branded feed.
    permitted = {primary}
    for alias in saved.get('aliases') or []:
        if _safe_station_identity(alias) == primary:
            permitted.add(primary)
    exact = []
    for channel in candidates_list or []:
        if _safe_station_identity(channel.get('name', '')) in permitted:
            exact.append((similarity(saved.get('name', ''), channel.get('name', '')), channel))
    if not exact:
        return None
    exact.sort(key=lambda pair: _automatic_variant_sort_key(saved, pair))
    return exact[0][1]


def _saved_channel_identities(saved):
    primary = _safe_station_identity(saved.get('name', ''))
    return {primary} if primary else set()


def _mapping_matches_saved_channel(saved, mapping):
    """Reject stale portal mappings that point to a different station family.

    Earlier versions considered every mapping containing ``cmd`` valid forever.
    That prevented the improved alias matcher from repairing wrong assignments.
    """
    if not isinstance(mapping, dict) or not mapping.get('cmd'):
        return False
    mapping_identity = _safe_station_identity(mapping.get('name', ''))
    if not mapping_identity:
        return False
    return mapping_identity in _saved_channel_identities(saved)


def sync_context_key():
    """Stable key for one portal, filter and matcher revision."""
    tokens = [str(token).strip().upper() for token in get_configured_country_tokens() if str(token).strip()]
    # Revision token intentionally triggers one fresh synchronization after
    # installing this alias/mapping-repair patch.
    raw = 'strict-station-identity-v7|{}|{}'.format(portal_key(), '|'.join(tokens))
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()


def automatic_sync_is_due():
    """Refresh mappings on portal/MAC switch and periodically on active portal.

    The list itself remains portal-independent; only its mappings are refreshed.
    """
    data = load_data()
    current = portal_key()
    if data.get('last_local_tv_portal_key') != current:
        return True
    completed = (data.get('sync_runs') or {}).get(sync_context_key())
    try:
        return not completed or time.time() - float(completed) >= 3600
    except (TypeError, ValueError):
        return True


def automatic_sync_was_completed():
    """Return whether automatic synchronization already ran for this portal/filter."""
    return bool((load_data().get('sync_runs') or {}).get(sync_context_key()))


def mark_automatic_sync_completed(completed=True):
    """Remember automatic synchronization independently from the result dialog."""
    data = load_data()
    runs = data.setdefault('sync_runs', {})
    key = sync_context_key()
    if completed:
        runs[key] = int(time.time())
        data['last_local_tv_portal_key'] = portal_key()
    else:
        runs.pop(key, None)
    return save_data(data)


def sync_summary_was_shown():
    """Return whether the automatic synchronization summary was already shown."""
    return bool((load_data().get('sync_notices') or {}).get(sync_context_key()))


def mark_sync_summary_shown(shown=True):
    """Remember the summary state for the active portal/filter combination."""
    data = load_data()
    notices = data.setdefault('sync_notices', {})
    key = sync_context_key()
    if shown:
        notices[key] = int(time.time())
    else:
        notices.pop(key, None)
    return save_data(data)


def mapping_is_valid(saved):
    """Whether this favorite has a plausible mapping for the active portal."""
    mapping = ((saved.get('mappings') or {}).get(portal_key()) or {})
    return bool(mapping.get('cmd') and (mapping.get('manual') or _mapping_matches_saved_channel(saved, mapping)))


def current_sync_summary():
    """Count all local channels and mappings available for the active portal."""
    current_portal = portal_key()
    total = 0
    available = 0
    for group in groups():
        for channel in group.get('channels') or []:
            total += 1
            mapping = ((channel.get('mappings') or {}).get(current_portal) or {})
            if mapping.get('cmd') and (mapping.get('manual') or _mapping_matches_saved_channel(channel, mapping)):
                available += 1
    return {'total': total, 'available': available, 'unresolved': max(0, total - available)}

def pending_sync_count(group_id=None):
    """Return unresolved channels for one group or all local groups."""
    if not G.portal_config.portal_url:
        return 0
    current_portal = portal_key()
    selected_groups = [get_group(group_id)] if group_id else groups()
    return sum(
        1 for group in selected_groups if group
        for saved in group.get('channels') or []
        if not _mapping_matches_saved_channel(
            saved, ((saved.get('mappings') or {}).get(current_portal) or {})
        )
    )


def sync_all_groups_for_current_portal(catalog, progress_callback=None, cancel_callback=None, group_id=None):
    """Fully rebuild every local channel mapping for the active portal.

    Every saved favourite is checked again, including entries that already have
    a playable mapping. This is required after a portal switch because channel
    IDs and commands are portal-specific. Stale mappings are removed when no
    reliable current-portal match exists.
    """
    result = {'mapped': 0, 'updated': 0, 'unchanged': 0, 'unresolved': 0,
              'searched': 0, 'total': 0, 'cancelled': False, 'unresolved_names': []}
    if not G.portal_config.portal_url:
        return result
    data = load_data()
    current_portal = portal_key()
    saved_channels = [
        saved for group in data.get('groups') or []
        if group_id is None or str(group.get('id')) == str(group_id)
        for saved in group.get('channels') or []
    ]
    result['total'] = len(saved_channels)
    changed = False
    shared_index = channel_index.get_index(
        catalog, '{}:sync'.format(current_portal), normalize_channel_name,
        channel_quality_score,
    )

    for position, saved in enumerate(saved_channels, 1):
        if cancel_callback and cancel_callback():
            result['cancelled'] = True
            break
        name = saved.get('name', '')
        if progress_callback:
            progress_callback(position - 1, result['total'], name)

        mappings = saved.setdefault('mappings', {})
        old_mapping = dict(mappings.get(current_portal) or {})
        old_id = str(old_mapping.get('id') or old_mapping.get('channel_id') or old_mapping.get('ch_id') or '').strip()
        old_name = str(old_mapping.get('name') or '').strip()
        # Full catalogue required: older indexes collapse regional variants.
        match = _best_automatic_match(saved, catalog)
        result['searched'] += 1

        if old_mapping.get('manual'):
            # Keep confirmed manual assignments only while the selected portal
            # channel is still present in the freshly loaded catalogue.
            manual_id = str(old_mapping.get('id') or old_mapping.get('channel_id') or old_mapping.get('ch_id') or '').strip()
            manual_match = next((ch for ch in (catalog or []) if manual_id and str(ch.get('id') or ch.get('channel_id') or ch.get('ch_id') or '').strip() == manual_id), None)
            if manual_match and manual_match.get('cmd'):
                match = manual_match
            else:
                match = None
        if match:
            new_mapping = _mapping_payload(match)
            if old_mapping.get('manual'):
                new_mapping['manual'] = True
            new_id = str(new_mapping.get('id') or new_mapping.get('channel_id') or new_mapping.get('ch_id') or '').strip()
            new_name = str(new_mapping.get('name') or '').strip()
            mappings[current_portal] = new_mapping
            aliases = saved.setdefault('aliases', [])
            # Never promote a guessed portal spelling into a trusted alias.
            result['mapped'] += 1
            if old_mapping != new_mapping:
                result['updated'] += 1
                changed = True
                Logger.info(
                    'Meine Sender remap favorite={!r} old_name={!r} old_id={!r} '
                    'new_name={!r} new_id={!r}'.format(
                        name, old_name, old_id, new_name, new_id,
                    )
                )
            else:
                result['unchanged'] += 1
                Logger.debug(
                    'Meine Sender mapping unchanged favorite={!r} name={!r} id={!r}'.format(
                        name, new_name, new_id,
                    )
                )
        else:
            if current_portal in mappings:
                mappings.pop(current_portal, None)
                changed = True
                Logger.warning(
                    'Meine Sender mapping removed favorite={!r} old_name={!r} old_id={!r}: '
                    'no reliable match in current portal'.format(name, old_name, old_id)
                )
            else:
                Logger.warning(
                    'Meine Sender unresolved favorite={!r}: no reliable match in current portal'.format(name)
                )
            result['unresolved'] += 1
            result['unresolved_names'].append(name)

        if progress_callback:
            progress_callback(position, result['total'], name)

    if changed:
        save_data(data)
    Logger.info('Meine Sender unresolved names: {}'.format(result['unresolved_names']))
    Logger.info(
        'Meine Sender full sync portal={} checked={} mapped={} updated={} unchanged={} '
        'unresolved={} cancelled={}'.format(
            current_portal, result['searched'], result['mapped'], result['updated'],
            result['unchanged'], result['unresolved'], result['cancelled'],
        )
    )
    return result


def sync_group_for_current_portal(group_id, progress_callback=None, cancel_callback=None):
    """Compatibility wrapper using the central filtered portal index."""
    index_result = build_filtered_portal_index(cancel_callback=cancel_callback)
    if index_result.get('cancelled'):
        return {'mapped': 0, 'unresolved': 0, 'searched': 0, 'total': 0, 'cancelled': True}
    # All groups are deliberately synchronized together so a portal change is
    # handled once, not again for every local list opened by the user.
    return sync_all_groups_for_current_portal(
        index_result.get('channels') or [], progress_callback, cancel_callback
    )

def candidates(channel, catalog=None, limit=12):
    """Return unique, station-aware manual mapping suggestions.

    Duplicate portal entries and quality variants of the same normalized station
    are collapsed. The best advertised quality is retained, while regional NDR
    variants remain distinct identities (MV, HH, NI and SH).
    """
    catalog = catalog if catalog is not None else get_portal_catalog()
    names = [channel.get('name', '')] + list(channel.get('aliases') or [])
    names = [name for name in names if name]
    saved_identities = {normalize_channel_name(name) for name in names}
    saved_identities.discard('')
    best_by_station = {}
    for portal_channel in catalog or []:
        portal_name = portal_channel.get('name', '')
        station_identity = normalize_channel_name(portal_name)
        if not station_identity:
            continue
        score = max((similarity(name, portal_name) for name in names), default=0.0)
        if station_identity in saved_identities:
            score = 1.0
        if score < 0.72:
            continue
        quality = channel_quality_score(portal_name)
        clean_label = clean_channel_display_name(portal_name)
        # The identity removes cosmetic prefixes, quality labels and known aliases.
        # This also removes duplicate records returned from several portal groups.
        duplicate_key = station_identity
        current = best_by_station.get(duplicate_key)
        candidate = (score, quality, clean_label.casefold(), portal_channel)
        if current is None or candidate[:2] > current[:2]:
            best_by_station[duplicate_key] = candidate
    scored = list(best_by_station.values())
    scored.sort(key=lambda value: (-value[0], -value[1], value[2]))
    return [item for _, _, _, item in scored[:limit]]


def _catalog_identity_index(catalog):
    """Return the shared best-channel map for the active portal catalogue."""
    return channel_index.get_index(
        catalog or [], '{}:resolve'.format(portal_key()),
        normalize_channel_name, channel_quality_score,
    ).best_by_identity


def build_catalog_identity_index(catalog):
    """Public helper used by the directory renderer to avoid repeated scans."""
    return _catalog_identity_index(catalog)


def resolve_channel(channel, catalog=None, identity_index=None):
    """Only expose verified current-portal streams; never guess during display.

    Portal IDs and commands are scoped to portal_key() (URL and MAC).  A stale
    mapping or a generic index alias must not turn a regional feed into another.
    """
    mapping = (channel.get('mappings') or {}).get(portal_key())
    catalog = catalog if catalog is not None else get_cached_all_portal_catalog()
    if not mapping:
        return None, 'unavailable'
    if not mapping.get('manual') and not _mapping_matches_saved_channel(channel, mapping):
        return None, 'unavailable'
    if not catalog:
        # No current catalogue: do not treat an old command as verified.
        return None, 'unavailable'
    selected_id = str(mapping.get('id') or mapping.get('channel_id') or mapping.get('ch_id') or '').strip()
    selected_cmd = str(mapping.get('cmd') or '').strip()
    for candidate in catalog:
        candidate_id = str(candidate.get('id') or candidate.get('channel_id') or candidate.get('ch_id') or '').strip()
        candidate_cmd = str(candidate.get('cmd') or '').strip()
        if selected_id and candidate_id != selected_id:
            continue
        if not selected_id and (not selected_cmd or candidate_cmd != selected_cmd):
            continue
        if not mapping.get('manual') and _safe_station_identity(candidate.get('name', '')) != _safe_station_identity(channel.get('name', '')):
            continue
        hydrated = hydrate_portal_channel(candidate, catalog=catalog)
        if hydrated.get('cmd'):
            return hydrated, 'manual' if mapping.get('manual') else 'mapped'
    return None, 'unavailable'


# ---------------------------------------------------------------------------
# Portable TXT/ZIP packages for "Meine Sender"
# ---------------------------------------------------------------------------

def _safe_filename(value):
    return safe_filename(value, fallback='tv-list')


def _group_txt(group):
    return '\n'.join(str(item.get('name', '')).strip() for item in group.get('channels') or [] if str(item.get('name', '')).strip()) + '\n'


def export_group_package(group_id, destination_directory):
    group = get_group(group_id)
    if not group or not destination_directory:
        return {'status': 'error', 'path': ''}
    os.makedirs(destination_directory, exist_ok=True)
    base = _safe_filename(group.get('name', 'Senderliste'))
    output = os.path.join(destination_directory, base + '.zip')
    info = {
        'format': 'TitanMacVOD-Meine-Sender', 'format_version': 1,
        'name': group.get('name', ''), 'created': datetime.now().isoformat(timespec='seconds'),
        'lists': [{'name': group.get('name', ''), 'file': base + '.txt', 'channels': len(group.get('channels') or [])}],
    }
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('info.json', json.dumps(info, ensure_ascii=False, indent=2))
        archive.writestr(base + '.txt', _group_txt(group))
        art = local_tv_art_path(group.get('name', ''))
        if art and os.path.isfile(art):
            archive.write(art, base + '.png')
    return {'status': 'exported', 'path': output, 'count': 1}


def export_all_packages(destination_directory):
    local_groups = groups()
    if not local_groups or not destination_directory:
        return {'status': 'empty' if not local_groups else 'error', 'path': ''}
    os.makedirs(destination_directory, exist_ok=True)
    output = os.path.join(destination_directory, 'Meine_Sender_{}.zip'.format(datetime.now().strftime('%Y-%m-%d')))
    files = []
    used = set()
    for group in local_groups:
        base = _safe_filename(group.get('name', 'Senderliste'))
        original = base
        suffix = 2
        while base in used:
            base = '{}_{}'.format(original, suffix); suffix += 1
        used.add(base)
        files.append((group, base + '.txt'))
    info = {
        'format': 'TitanMacVOD-Meine-Sender', 'format_version': 1,
        'name': 'Meine Sender', 'created': datetime.now().isoformat(timespec='seconds'),
        'lists': [{'name': group.get('name', ''), 'file': filename, 'channels': len(group.get('channels') or [])}
                  for group, filename in files],
    }
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('info.json', json.dumps(info, ensure_ascii=False, indent=2))
        for group, filename in files:
            archive.writestr(filename, _group_txt(group))
            art = local_tv_art_path(group.get('name', ''))
            if art and os.path.isfile(art):
                archive.write(art, 'art/{}.png'.format(os.path.splitext(filename)[0]))
        art = local_tv_art_path(root=True)
        if art and os.path.isfile(art):
            archive.write(art, 'cover.png')
    return {'status': 'exported', 'path': output, 'count': len(files)}


def inspect_import_file(path):
    """Return portable list definitions without changing user data."""
    result = {'status': 'error', 'lists': [], 'metadata': {}, 'path': path}
    if not path or not os.path.isfile(path):
        return result
    try:
        if path.lower().endswith('.txt'):
            with open(path, 'r', encoding='utf-8-sig') as handle:
                names = [line.strip() for line in handle if line.strip() and not line.lstrip().startswith('#')]
            title = os.path.splitext(os.path.basename(path))[0].replace('_', ' ').strip().title()
            result.update(status='ok', lists=[{'name': title, 'channels': names}])
            return result
        if not zipfile.is_zipfile(path):
            return result
        with zipfile.ZipFile(path, 'r') as archive:
            names = archive.namelist()
            metadata = {}
            if 'info.json' in names:
                try:
                    metadata = json.loads(archive.read('info.json').decode('utf-8-sig'))
                except Exception:
                    metadata = {}
            declared = {entry.get('file'): entry.get('name') for entry in metadata.get('lists', []) if isinstance(entry, dict)}
            lists = []
            for filename in names:
                if filename.endswith('/') or not filename.lower().endswith('.txt'):
                    continue
                raw = archive.read(filename).decode('utf-8-sig')
                channels = [line.strip() for line in raw.splitlines() if line.strip() and not line.lstrip().startswith('#')]
                title = declared.get(filename) or os.path.splitext(os.path.basename(filename))[0].replace('_', ' ').strip().title()
                lists.append({'name': title, 'channels': channels, 'source_file': filename})
            result.update(status='ok' if lists else 'empty', lists=lists, metadata=metadata)
            return result
    except Exception as exc:
        Logger.error('Could not inspect sender list import {}: {}'.format(path, exc))
        return result


def install_import_art(package_path, imported_lists):
    """Install optional list artwork from an imported ZIP.

    ``imported_lists`` may contain visible list names or dictionaries with
    ``name`` (the final local list name) and ``source_file`` (the TXT member in
    the ZIP). Images are always copied into the writable profile ``art``
    directory using the final list name.
    """
    if not package_path or not zipfile.is_zipfile(package_path):
        return 0
    installed = 0
    try:
        destination_dir = user_art_dir()
        if not destination_dir:
            return 0
        if not os.path.isdir(destination_dir):
            os.makedirs(destination_dir, exist_ok=True)

        with zipfile.ZipFile(package_path, 'r') as archive:
            archive_names = [name for name in archive.namelist() if not name.endswith('/')]
            members = {name.replace('\\', '/').lower(): name for name in archive_names}
            txt_members = [name for name in archive_names if name.lower().endswith('.txt')]

            entries = []
            for value in imported_lists or []:
                if isinstance(value, dict):
                    name = str(value.get('name') or '').strip()
                    source_file = str(value.get('source_file') or '').replace('\\', '/').strip()
                else:
                    name = str(value or '').strip()
                    source_file = ''
                if name:
                    entries.append({'name': name, 'source_file': source_file})

            for entry in entries:
                list_name = entry['name']
                txt_member = entry['source_file'] if entry['source_file'] in archive_names else ''
                if not txt_member:
                    wanted = _safe_filename(list_name)
                    txt_member = next((item for item in txt_members
                                       if _safe_filename(os.path.splitext(os.path.basename(item))[0]) == wanted), '')
                if not txt_member and len(entries) == 1 and len(txt_members) == 1:
                    txt_member = txt_members[0]

                slug = art_slug(list_name)
                candidates = []
                if txt_member:
                    normalized_txt = txt_member.replace('\\', '/')
                    directory = normalized_txt.rsplit('/', 1)[0] if '/' in normalized_txt else ''
                    stem = os.path.splitext(normalized_txt)[0]
                    candidates.extend([
                        stem + '.png',
                        (directory + '/cover.png') if directory else 'cover.png',
                    ])
                candidates.extend([
                    'art/{}.png'.format(_safe_filename(list_name)),
                    'art/{}.png'.format(slug),
                ])
                if len(entries) == 1:
                    candidates.append('cover.png')

                image_member = next((members.get(candidate.lower()) for candidate in candidates
                                     if members.get(candidate.lower())), None)
                if not image_member:
                    continue

                data = archive.read(image_member)
                if not data or len(data) > 2 * 1024 * 1024 or not data.startswith(b'\x89PNG\r\n\x1a\n'):
                    continue

                destination = os.path.join(destination_dir, '{}.png'.format(slug))
                temporary = destination + '.tmp'
                with open(temporary, 'wb') as handle:
                    handle.write(data)
                    handle.flush()
                    try:
                        os.fsync(handle.fileno())
                    except OSError:
                        pass
                os.replace(temporary, destination)
                if os.path.isfile(destination) and os.path.getsize(destination) == len(data):
                    installed += 1
                    Logger.info('Imported sender-list artwork {} -> {}'.format(image_member, destination))
                else:
                    Logger.error('Sender-list artwork was not written correctly: {}'.format(destination))
    except Exception as exc:
        Logger.error('Could not import sender-list artwork {}: {}'.format(package_path, exc))
    return installed

def import_list_definition(name, channel_names, mode='new'):
    """Import one list. mode: new, replace, merge, rename."""
    name = str(name or '').strip() or 'Importierte Senderliste'
    data = load_data()
    existing = next((group for group in data.get('groups') or [] if str(group.get('name', '')).casefold() == name.casefold()), None)
    records = []
    seen = set()
    for value in channel_names or []:
        record = _channel_record_from_name(value)
        normalized = normalize_channel_name((record or {}).get('name', ''))
        if record and normalized and normalized not in seen:
            seen.add(normalized); records.append(record)
    if existing and mode == 'replace':
        existing['channels'] = records
        return {'status': 'imported' if save_data(data) else 'error', 'name': name, 'count': len(records)}
    if existing and mode == 'merge':
        current = {normalize_channel_name(item.get('name', '')) for item in existing.get('channels') or []}
        added = 0
        for record in records:
            key = normalize_channel_name(record.get('name', ''))
            if key not in current:
                existing.setdefault('channels', []).append(record); current.add(key); added += 1
        return {'status': 'imported' if save_data(data) else 'error', 'name': name, 'count': added}
    if existing and mode == 'rename':
        base = name; number = 2
        while any(str(group.get('name', '')).casefold() == name.casefold() for group in data.get('groups') or []):
            name = '{} ({})'.format(base, number); number += 1
    elif existing:
        return {'status': 'exists', 'name': name, 'count': 0}
    group = {'id': _new_id('group', name), 'name': name, 'channels': records}
    data.setdefault('groups', []).append(group)
    return {'status': 'imported' if save_data(data) else 'error', 'name': name, 'count': len(records)}


def clear_portal_catalog_cache(all_entries=False):
    """Invalidate the central index and reset one-shot synchronization state."""
    cleared = portal_index.invalidate_index(all_entries=all_entries)
    if cleared and not all_entries:
        mark_automatic_sync_completed(False)
        mark_sync_summary_shown(False)
    return cleared


def mapping_entries():
    """Return all saved local channels with their active-portal mapping."""
    data = load_data()
    key = portal_key()
    result = []
    for group in data.get('groups') or []:
        for channel in group.get('channels') or []:
            mapping = ((channel.get('mappings') or {}).get(key) or {})
            result.append({
                'group_id': group.get('id', ''), 'group_name': group.get('name', ''),
                'channel_id': channel.get('id', ''), 'channel_name': channel.get('name', ''),
                'mapped_name': mapping.get('name', ''), 'mapped_id': mapping.get('id', ''),
                'cmd': mapping.get('cmd', ''), 'quality': quality_label(mapping.get('name', '')),
            })
    return result


def quality_label(name):
    text = str(name or '').upper()
    for label in ('8K', '4K', 'UHD', 'FHD', 'HD', 'SD'):
        if re.search(r'(^|[^A-Z0-9]){}([^A-Z0-9]|$)'.format(label), text):
            return label
    return ''
