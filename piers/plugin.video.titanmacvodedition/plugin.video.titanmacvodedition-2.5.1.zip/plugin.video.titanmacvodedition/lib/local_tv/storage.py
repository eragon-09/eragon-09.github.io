"""Storage helpers for local Live-TV lists."""

from . import core as _core

load_data = _core.load_data
save_data = _core.save_data

__all__ = [
    'load_data',
    'save_data',
]
