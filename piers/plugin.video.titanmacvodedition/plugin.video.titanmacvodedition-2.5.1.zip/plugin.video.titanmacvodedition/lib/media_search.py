# -*- coding: utf-8 -*-
"""Shared media-search infrastructure.

This module owns the short-lived category cache and the shared worker pool used
by VOD and series searches. Keeping this infrastructure outside the Kodi
controller reduces duplication and keeps ``addon_media`` focused on routing and
rendering.
"""
from __future__ import absolute_import, division, unicode_literals

from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import time

from .country_filter import filter_categories_for_country_groups
from .loggers import Logger

_CATEGORY_CACHE_TTL = 900
_SEARCH_WORKERS = 12


class MediaSearchEngine:
    """Cache portal categories and merge concurrent category-search results."""

    def __init__(self, cache_ttl=_CATEGORY_CACHE_TTL, max_workers=_SEARCH_WORKERS):
        self._cache_ttl = max(0, int(cache_ttl))
        self._cache = {}
        self._cache_lock = threading.RLock()
        self._executor = ThreadPoolExecutor(max_workers=max(1, int(max_workers)))

    @staticmethod
    def _copy_items(items):
        """Return a shallow list copy without mutating loader-owned data."""
        return list(items or [])

    def _get_cached(self, cache_key):
        now = time.monotonic()
        with self._cache_lock:
            cached = self._cache.get(cache_key)
            if cached and now - cached[0] < self._cache_ttl:
                return self._copy_items(cached[1])
        return None

    def _store_cached(self, cache_key, items):
        copied = self._copy_items(items)
        with self._cache_lock:
            self._cache[cache_key] = (time.monotonic(), copied)
        return self._copy_items(copied)

    def get_categories(self, media_type, loader):
        """Return portal categories from a short in-process cache."""
        cache_key = ('categories', str(media_type))
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached
        return self._store_cached(cache_key, loader() or [])

    def get_country_group_categories(self, media_type, loader, tokens):
        """Return country-filtered categories using the shared category cache."""
        normalized_tokens = {
            str(token).upper() for token in (tokens or set()) if str(token).strip()
        }
        cache_key = (
            'country-categories',
            str(media_type),
            tuple(sorted(normalized_tokens)),
        )
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        categories = self.get_categories(media_type, loader)
        filtered = filter_categories_for_country_groups(
            categories,
            tokens=normalized_tokens,
        )
        return self._store_cached(cache_key, filtered)

    def search_categories(self, categories, fetcher, id_keys):
        """Search categories concurrently and merge unique results in source order."""
        categories = self._copy_items(categories)
        if not categories:
            return []

        def search_one(index, category):
            try:
                response = fetcher(category) or {'data': []}
            except Exception as exc:
                Logger.error(
                    'Media search failed for category {}: {}'.format(
                        category.get('id'), exc
                    )
                )
                response = {'data': []}
            return index, category, response

        ordered_results = [None] * len(categories)
        started = time.monotonic()
        futures = [
            self._executor.submit(search_one, index, category)
            for index, category in enumerate(categories)
        ]
        for future in as_completed(futures):
            index, category, response = future.result()
            ordered_results[index] = (category, response)

        Logger.debug(
            'Parallel media search: {} categories in {:.2f}s'.format(
                len(categories), time.monotonic() - started
            )
        )
        return self._merge_results(ordered_results, id_keys)

    @staticmethod
    def _merge_results(ordered_results, id_keys):
        combined = []
        seen_ids = set()

        for result in ordered_results:
            if result is None:
                continue
            category, response = result
            category_title = (
                category.get('title') or category.get('name') or ''
            ).strip()

            for source_item in response.get('data', []):
                item = dict(source_item)
                item_id = next(
                    (
                        item.get(key)
                        for key in id_keys
                        if item.get(key) is not None
                    ),
                    None,
                )
                if item_id is not None:
                    dedupe_key = str(item_id)
                    if dedupe_key in seen_ids:
                        continue
                    seen_ids.add(dedupe_key)

                if category_title:
                    item['name'] = '[{}] {}'.format(
                        category_title,
                        item.get('name', ''),
                    )
                combined.append(item)

        return combined

    def clear_cache(self):
        """Clear cached category data; useful after portal changes."""
        with self._cache_lock:
            self._cache.clear()


def build_result_page(items, page=1):
    """Build the result envelope expected by Kodi media-list renderers."""
    data = list(items or [])
    return {
        'data': data,
        'total_items': len(data),
        'max_page_items': max(1, len(data)),
        'page': int(page),
    }


media_search = MediaSearchEngine()
