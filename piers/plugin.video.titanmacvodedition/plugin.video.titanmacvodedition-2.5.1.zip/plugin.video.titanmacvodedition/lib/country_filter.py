# -*- coding: utf-8 -*-
"""
country_filter.py
Ländergruppen-Helfer für TiTan-Stalker-Addon.

Beschränkt auf DE / AT / CH.
"""

from __future__ import absolute_import, division, unicode_literals
import re

# Nur diese Tokens gelten als Ländergruppen
COUNTRY_TOKENS = {'DE', 'AT', 'CH'}


def get_country_tokens():
    """
    Gibt die Menge der Ländergruppen-Tokens zurück.
    Aktuell: {'DE', 'AT', 'CH'}
    """
    return set(COUNTRY_TOKENS)


def get_configured_country_tokens(addon=None):
    """Return the active country-group tokens in a stable display order.

    DE, AT and CH are the built-in filter groups. Additional comma-separated
    tokens are read from the existing ``extra_country_tokens`` setting.
    """
    tokens = set(COUNTRY_TOKENS)
    if addon is not None:
        try:
            try:
                extra = addon.getSettingString('extra_country_tokens')
            except Exception:
                extra = addon.getSetting('extra_country_tokens')
            tokens.update(
                token.strip().upper()
                for token in (extra or '').split(',')
                if token.strip()
            )
        except Exception:
            pass

    preferred_order = ('DE', 'AT', 'CH')
    ordered = [token for token in preferred_order if token in tokens]
    ordered.extend(sorted(tokens.difference(preferred_order)))
    return ordered


def get_country_filter_label(addon=None, prefix='TV-GRUPPEN'):
    """Build the menu label for the currently configured country filter."""
    tokens = get_configured_country_tokens(addon)
    suffix = ' | '.join(tokens) if tokens else 'ALLE'
    return '{} – {}'.format(prefix, suffix)


def _clean_category_name(value):
    """Normalize names from Ministra/Stalker, including escaped/HTML markup."""
    import html
    import unicodedata
    name = html.unescape(str(value or ''))
    name = unicodedata.normalize('NFKC', name)
    # Portal country prefixes may use Unicode small-capital glyphs.
    # NFKC does not fold these (e.g. ᴅᴇ), so translate them explicitly.
    small_caps = str.maketrans({'ᴅ': 'D', 'ᴇ': 'E', 'ᴀ': 'A', 'ᴛ': 'T',
                                'ᴄ': 'C', 'ʜ': 'H', 'ʀ': 'R', 'ɢ': 'G',
                                'ᴜ': 'U', 'ɴ': 'N', 'ʟ': 'L', 'ɪ': 'I',
                                'ᴏ': 'O', 'ꜱ': 'S', 'ᴘ': 'P', 'ᴍ': 'M',
                                'ᴠ': 'V', 'ᴡ': 'W', 'ʏ': 'Y', 'ʙ': 'B',
                                'ꜰ': 'F', 'ᴋ': 'K', 'ᴊ': 'J', 'ᴢ': 'Z'})
    name = name.translate(small_caps)
    name = re.sub(r'\[/?(?:COLOR|B|I|LIGHT|UPPERCASE)(?:\s+[^\]]*)?\]', '', name, flags=re.I)
    name = name.replace('🇩🇪', ' DE ').replace('🇦🇹', ' AT ').replace('🇨🇭', ' CH ')
    name = re.sub(r'[\u200b-\u200f\u202a-\u202e\ufeff]', '', name)
    return name.upper().strip()


_COUNTRY_ALIASES = {
    'DE': {'DE', 'GER', 'DEU', 'GERMANY', 'DEUTSCHLAND', 'DEUTSCH'},
    'AT': {'AT', 'AUT', 'AUSTRIA', 'ÖSTERREICH', 'OESTERREICH'},
    'CH': {'CH', 'CHE', 'SWITZERLAND', 'SCHWEIZ', 'SUISSE'},
}


def matches_country_tokens(name, tokens=None):
    if not name:
        return False
    normalized = _clean_category_name(name)
    words = set(word for word in re.split(r'[^\w]+', normalized) if word)
    active = {str(t).upper().strip() for t in (tokens if tokens is not None else COUNTRY_TOKENS)}
    return any(words.intersection(_COUNTRY_ALIASES.get(token, {token})) for token in active)


def _category_names(cat):
    """Inspect every name field; some portals put numeric codes in 'title'."""
    for key in ('title', 'name', 'alias', 'abbr', 'label', 'display_name', 'genre_name'):
        value = cat.get(key)
        if isinstance(value, str) and value.strip():
            yield value


def filter_categories_for_country_groups(categories, tokens=None):
    if tokens is None:
        tokens = COUNTRY_TOKENS
    return [cat for cat in (categories or [])
            if isinstance(cat, dict) and any(
                matches_country_tokens(name, tokens) for name in _category_names(cat))]
