"""Logger class"""
from __future__ import absolute_import, division, unicode_literals
import xbmc

from .settings import ADDON_ID, settings


class Logger:
    """Logger – debug() only writes when debug_logging is enabled in settings."""

    @staticmethod
    def _debug_enabled():
        try:
            return settings.get_bool('debug_logging', False)
        except Exception:
            return False

    @staticmethod
    def log(message, level=xbmc.LOGDEBUG):
        xbmc.log('{}: {}'.format(ADDON_ID, message), level)

    @staticmethod
    def info(message):
        Logger.log(message, xbmc.LOGINFO)

    @staticmethod
    def error(message):
        Logger.log(message, xbmc.LOGERROR)

    @staticmethod
    def warning(message):
        """Write a warning using the standard logging method name."""
        Logger.log(message, xbmc.LOGWARNING)

    @staticmethod
    def warn(message):
        """Backward-compatible alias for older call sites."""
        Logger.warning(message)

    @staticmethod
    def exception(message):
        """Log an error message for use inside exception handlers.

        Kodi's logger does not append Python tracebacks automatically, so call
        sites may include exception details in ``message`` when required.
        """
        Logger.log(message, xbmc.LOGERROR)

    @staticmethod
    def debug(message):
        if Logger._debug_enabled():
            Logger.log(message, xbmc.LOGDEBUG)
