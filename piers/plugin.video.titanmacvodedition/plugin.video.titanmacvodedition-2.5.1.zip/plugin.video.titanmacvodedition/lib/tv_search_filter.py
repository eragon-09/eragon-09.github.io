"""Strict, scope-aware matching for the general Live-TV search."""
import re
import unicodedata
from .country_filter import matches_country_tokens

_ADULT = re.compile(r'(?<![A-Z0-9])(?:ADULT|XXX|XXL|18\s*\+|EROTIK|EROTIC|PORN(?:O)?|HARDCORE)(?![A-Z0-9])', re.I)
_PREFIX = re.compile(r'^\s*(?:(?:DE|AT|CH|GER|AUT|CHE)\s*[:|]\s*|[|\[({]\s*(?:VIP|WOW|AMZ)\s*[|\])}]\s*|(?:VIP|WOW|AMZ)\s*[:| -]\s*)', re.I)
_QUALITY = re.compile(r'(?:\s|[-_])+(?:FHD|FULL\s*HD|HD|UHD|4K|8K|SD|HEVC)\s*$', re.I)
_COUNTRY_END = re.compile(r'\s+(?:AUSTRIA|OESTERREICH|ÖSTERREICH|GERMANY|DEUTSCHLAND|SCHWEIZ|SWITZERLAND)$', re.I)

def clean_name(value):
    value = unicodedata.normalize('NFKC', str(value or ''))
    value = re.sub(r'\[/?(?:COLOR|B|I)(?:\s+[^]]*)?\]', '', value, flags=re.I)
    for _ in range(8):
        updated = _PREFIX.sub('', value)
        if updated == value:
            break
        value = updated
    value = _QUALITY.sub('', value).strip()
    return re.sub(r'\s+', ' ', value).strip(' :-|')

def identity(value):
    value = clean_name(value).upper().replace('+', ' PLUS ')
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    return re.sub(r'[^A-Z0-9]+', '', value)

def matches_query(query, name):
    """Case-insensitive text search across normalized portal channel names.

    Unlike favorites synchronization, general TV search deliberately matches
    partial names: SKY finds SKY SPORT and SKY CINEMA, RTL finds SUPER RTL.
    """
    requested = identity(query)
    return bool(requested and requested in identity(name))

def is_adult(channel, group_names=()):
    names = list(channel.get('group_titles') or [])
    names.extend([channel.get('group_title', ''), channel.get('category', '')])
    names.extend(group_names or ())
    return any(_ADULT.search(str(name or '')) for name in names)

def in_countries(channel, tokens, group_names=()):
    names = list(channel.get('group_titles') or [])
    names.extend([channel.get('group_title', ''), channel.get('category', '')])
    names.extend(group_names or ())
    return any(matches_country_tokens(name, tokens) for name in names)

def search(channels, query, scope, tokens, group_lookup=None):
    group_lookup = group_lookup or {}
    results = []
    for channel in channels or []:
        if not isinstance(channel, dict):
            continue
        group_names = [group_lookup.get(str(group_id), '') for group_id in (channel.get('group_ids') or [channel.get('genre_id')])]
        adult = is_adult(channel, group_names)
        if scope == 'adult':
            if not adult:
                continue
        elif adult:
            continue
        if scope == 'countries' and not in_countries(channel, tokens, group_names):
            continue
        if matches_query(query, channel.get('name', '')):
            results.append(channel)
    quality_order = {'FHD': 0, 'HD': 1, 'UHD': 2, '4K': 2, '8K': 2, 'SD': 3}
    def order(channel):
        match = _QUALITY.search(str(channel.get('name', '')))
        quality = match.group(0).strip().upper() if match else 'SD'
        return (quality_order.get(quality, 3), str(channel.get('name', '')).casefold())
    return sorted(results, key=order)
