"""Small thread-safe in-memory cache shared by add-on modules.

The cache is intentionally process-local. Persistent portal/XMLTV caches keep
using their existing on-disk implementations; this helper only replaces the
scattered short-lived dictionaries used while Kodi's Python process is alive.
"""
from __future__ import absolute_import, unicode_literals

import threading
import time


_MISSING = object()


class CacheManager:
    """Thread-safe namespaced cache with optional TTL values."""

    def __init__(self):
        self._values = {}
        self._lock = threading.RLock()

    @staticmethod
    def _full_key(namespace, key):
        return str(namespace or 'default'), key

    def get(self, namespace, key, default=None):
        full_key = self._full_key(namespace, key)
        with self._lock:
            entry = self._values.get(full_key, _MISSING)
            if entry is _MISSING:
                return default
            expires_at, value = entry
            if expires_at and expires_at <= time.time():
                self._values.pop(full_key, None)
                return default
            return value

    def set(self, namespace, key, value, ttl=None):
        expires_at = (time.time() + float(ttl)) if ttl else 0
        with self._lock:
            self._values[self._full_key(namespace, key)] = (expires_at, value)
        return value

    def get_or_create(self, namespace, key, factory, ttl=None):
        """Return cached value or atomically create and store it."""
        full_key = self._full_key(namespace, key)
        with self._lock:
            entry = self._values.get(full_key, _MISSING)
            if entry is not _MISSING:
                expires_at, value = entry
                if not expires_at or expires_at > time.time():
                    return value
                self._values.pop(full_key, None)
            value = factory()
            expires_at = (time.time() + float(ttl)) if ttl else 0
            self._values[full_key] = (expires_at, value)
            return value

    def invalidate(self, namespace, key=None):
        with self._lock:
            if key is not None:
                return self._values.pop(self._full_key(namespace, key), None) is not None
            prefix = str(namespace or 'default')
            keys = [item for item in self._values if item[0] == prefix]
            for item in keys:
                self._values.pop(item, None)
            return bool(keys)

    def clear(self):
        with self._lock:
            self._values.clear()


runtime_cache = CacheManager()
