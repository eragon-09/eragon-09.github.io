"""Skin-aware left-side TV favorites zapper overlay.

The add-on owns the overlay so playback stays visible and the behaviour is
consistent across skins.  Layout selection is skin-aware, with a neutral
fallback for unknown skins.
"""
from __future__ import absolute_import, division, unicode_literals

import hashlib
import os
import time

import xbmc
import xbmcgui

from .api import Api, get_epg_dict, short_epg_from_dict
from .live_epg import compact_now_label, compact_now_suffix
from .globals import G
from .loggers import Logger

_ACTION_CANCEL = {9, 10, 92, 216, 247, 257, 275, 61467, 61448}
_ACTION_SELECT = {7, 100}
_ACTION_NAVIGATION = {1, 2, 3, 4, 5, 6, 104, 105}
_ACTION_DIGITS = {58 + digit: str(digit) for digit in range(10)}


def _stream_identity(url):
    """Return a stable stream identity without Kodi header suffixes."""
    value = str(url or '').strip()
    return value.split('|', 1)[0]


def _addon_path():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getAddonInfo('path')
    except Exception:
        return os.path.dirname(os.path.dirname(__file__))



def _skin_id():
    """Return the active Kodi skin id without making it a hard dependency."""
    try:
        return str(xbmc.getSkinDir() or '').strip().lower()
    except Exception:
        return ''


def _dialog_xml():
    """Always use the add-on owned neutral layout.

    WindowXMLDialog loads the XML from this add-on, not from the active skin.
    Using one Kodi-standard layout prevents third-party skins from making the
    zapper entry disappear or selecting an incompatible skin-specific file.
    """
    return 'FavoriteZapperDialog.xml'


def _as_rows(payload):
    if isinstance(payload, dict):
        data = payload.get('data') or []
    elif isinstance(payload, list):
        data = payload
    else:
        data = []
    return [row for row in data if isinstance(row, dict)]


def _load_favorites(max_pages=10):
    """Load favorite channels, following normal portal pagination conservatively."""
    rows = []
    seen = set()
    for page in range(1, max_pages + 1):
        payload = Api.get_tv_favorites(page)
        current = _as_rows(payload)
        if not current:
            break
        added = 0
        for row in current:
            key = str(row.get('id') or row.get('cmd') or row.get('name') or '')
            if not key or key in seen:
                continue
            seen.add(key)
            rows.append(row)
            added += 1
        total = 0
        try:
            total = int(payload.get('total_items') or 0) if isinstance(payload, dict) else 0
        except Exception:
            total = 0
        if (total and len(rows) >= total) or not added:
            break
    return rows


def _ctx_key(rows):
    raw = '|'.join(str(row.get('id') or row.get('cmd') or row.get('name') or '') for row in rows)
    return 'favzapper_' + hashlib.md5(raw.encode('utf-8')).hexdigest()


def _plugin_url(row, index, ctx_key):
    return G.get_plugin_url({
        'action': 'tv_play',
        'idx': str(index),
        'cmd': row.get('cmd', ''),
        'use_http_tmp_link': row.get('use_http_tmp_link', 0),
        'use_load_balancing': row.get('use_load_balancing', 0),
        'name': row.get('name', ''),
        'logo': row.get('logo', ''),
        'epg_text': '',
        'epg_id': str(row.get('id', '')),
        'ctx': ctx_key,
    })


class LiveZapperController(object):
    """Own exactly one direct live-TV playback request at a time.

    The controller resolves exactly one channel from the add-on's original
    favorites list and hands only that stream URL to Kodi. It never creates
    or modifies a Kodi video playlist and never opens a plugin:// playback
    route from the overlay.
    """

    PROP_LIVE = 'TitanMacVOD.LivePlayback'
    PROP_REQUESTED = 'TitanMacVOD.RequestedStream'
    PROP_CHANNEL_ID = 'TitanMacVOD.PlayingChannelId'
    PROP_CHANNEL_NAME = 'TitanMacVOD.PlayingChannelName'

    def __init__(self):
        self.player = xbmc.Player()
        self.monitor = xbmc.Monitor()
        self.active_index = -1
        self._busy = False

    @property
    def busy(self):
        return self._busy

    def _set_live_properties(self, stream_url, row, channel_name):
        try:
            home = xbmcgui.Window(10000)
            home.setProperty(self.PROP_LIVE, '1')
            home.setProperty(self.PROP_REQUESTED, _stream_identity(stream_url))
            home.setProperty(self.PROP_CHANNEL_ID, str(row.get('id') or ''))
            home.setProperty(self.PROP_CHANNEL_NAME, channel_name or '')
        except Exception:
            pass

    def _clear_requested(self):
        try:
            xbmcgui.Window(10000).clearProperty(self.PROP_REQUESTED)
        except Exception:
            pass

    def play(self, row, channel_name, detail_text='', logo='', timeout_ms=8000):
        if self._busy:
            return False, 'Umschalten läuft bereits'
        self._busy = True
        try:
            stream_url = Api.get_tv_stream_url({
                'cmd': row.get('cmd', ''),
                'use_http_tmp_link': row.get('use_http_tmp_link', 0),
                'use_load_balancing': row.get('use_load_balancing', 0),
                'name': row.get('name', ''),
            })
            if not stream_url:
                return False, 'Sender momentan nicht erreichbar'

            play_item = xbmcgui.ListItem(path=stream_url)
            play_item.setProperty('IsPlayable', 'true')
            if logo:
                play_item.setArt({'icon': logo, 'thumb': logo})
            try:
                info = play_item.getVideoInfoTag()
                info.setTitle(channel_name)
                info.setOriginalTitle(channel_name)
                if detail_text:
                    info.setPlot(detail_text)
            except Exception:
                pass

            self._set_live_properties(stream_url, row, channel_name)
            self.player.play(stream_url, play_item)

            requested = _stream_identity(stream_url)
            previous = ''
            steps = max(1, int(timeout_ms / 100))
            for _ in range(steps):
                if self.monitor.abortRequested():
                    return False, 'Kodi wird beendet'
                xbmc.sleep(100)
                try:
                    playing = self.player.isPlayingVideo()
                    current = _stream_identity(self.player.getPlayingFile() if playing else '')
                except Exception:
                    playing = False
                    current = ''
                if not playing or not current:
                    continue
                if current == requested:
                    return True, ''
                # Portal redirects may change the final URL. Any newly
                # playing video after this single direct request is accepted.
                if current != previous:
                    return True, ''
                previous = current

            return False, 'Sender momentan nicht erreichbar'
        except Exception as exc:
            Logger.error('Live zapper controller failed for {}: {}'.format(channel_name, exc))
            return False, 'Sender momentan nicht erreichbar'
        finally:
            self._clear_requested()
            self._busy = False


class FavoriteZapperDialog(xbmcgui.WindowXMLDialog):
    def __new__(cls, *args, **kwargs):
        return super(FavoriteZapperDialog, cls).__new__(cls, *args)

    def __init__(self, *args, **kwargs):
        super(FavoriteZapperDialog, self).__init__(*args)
        self.rows = kwargs.get('rows') or []
        self.ctx_key = kwargs.get('ctx_key') or ''
        self.selected_url = ''
        self._epg_dict = {}
        self._playing_index = -1
        self.controller = LiveZapperController()
        self._number_buffer = ''
        self._number_buffer_time = 0.0

    def onInit(self):
        control = self.getControl(300)
        control.reset()
        try:
            self._epg_dict = get_epg_dict() or {}
        except Exception:
            self._epg_dict = {}
        try:
            playing_channel_id = xbmcgui.Window(10000).getProperty(LiveZapperController.PROP_CHANNEL_ID)
        except Exception:
            playing_channel_id = ''
        selected = 0
        for index, row in enumerate(self.rows):
            name = str(row.get('name') or 'Unbenannter Sender')
            channel_number = str(index + 1)
            # The add-on-owned XML renders the programme place in a dedicated
            # column. Keep the channel name clean so no skin formatting or
            # combined labels can hide or duplicate the number.
            # Put the programme place into Kodi's primary label. This is the
            # only text field every Kodi list renderer is guaranteed to draw.
            # Keep the clean channel name separately for playback and details.
            now_line, next_line, detail_text = self._epg_lines(row)
            display_label = '{:03d}  {}'.format(index + 1, compact_now_label(name, now_line))
            item = xbmcgui.ListItem(label=display_label)
            item.setProperty('channel_name', name)
            item.setProperty('channel_number', channel_number)
            item.setProperty('display_number', channel_number)
            item.setProperty('programme_label', '{}   {}'.format(channel_number, name))
            item.setProperty('channel_id', str(row.get('id') or ''))
            item.setProperty('quality', _quality(name))
            logo = str(row.get('logo') or '')
            if logo:
                item.setArt({'icon': logo, 'thumb': logo})
                item.setProperty('logo', logo)
            item.setProperty('now_line', now_line)
            item.setProperty('next_line', next_line)
            item.setProperty('detail_text', detail_text or now_line)
            item.setProperty('list_epg', compact_now_suffix(now_line) if now_line else '')
            # Keep the raw portal row in self.rows.  Playback is resolved
            # directly inside this dialog; no plugin:// route is opened while
            # the overlay is active.  This prevents Kodi from rebuilding the
            # underlying media container after a failed stream.
            item.setProperty('row_index', str(index))
            if playing_channel_id and str(row.get('id') or '') == playing_channel_id:
                item.setProperty('currently_playing', '▶')
                item.setProperty('playing_badge', 'LÄUFT')
                selected = index
                self._playing_index = index
            control.addItem(item)
        if self.rows:
            control.selectItem(selected)
            self.setFocusId(300)
            self._update_info()

    def _epg_lines(self, row):
        """Return compact list text, following broadcast and detailed panel text."""
        try:
            channel_id = str(row.get('id', ''))
            raw = short_epg_from_dict(channel_id, self._epg_dict)
            if not raw or 'Keine Informationen' in str(raw):
                return '', '', 'Keine EPG-Information verfügbar'
            lines = [line.strip() for line in str(raw).split('\n') if line.strip()]
            now_line = lines[0] if lines else ''
            next_line = lines[1] if len(lines) > 1 else ''

            events = self._epg_dict.get(channel_id) or []
            now_ts = int(time.time())
            current = None
            following = None
            normalized = []
            for event in events if isinstance(events, list) else []:
                if not isinstance(event, dict):
                    continue
                try:
                    start_ts = int(event.get('start_timestamp') or event.get('start') or 0)
                except Exception:
                    start_ts = 0
                try:
                    end_ts = int(event.get('stop_timestamp') or event.get('end_timestamp') or event.get('end') or 0)
                except Exception:
                    end_ts = 0
                normalized.append((start_ts, end_ts, event))
            normalized.sort(key=lambda entry: entry[0] or 10 ** 18)
            current_index = -1
            for index, (start_ts, end_ts, event) in enumerate(normalized):
                if start_ts and end_ts and start_ts <= now_ts < end_ts:
                    current = event
                    current_index = index
                    break
            if current is None and normalized:
                current = normalized[0][2]
                current_index = 0
            if current_index >= 0 and current_index + 1 < len(normalized):
                following = normalized[current_index + 1][2]

            def value(event, *keys):
                if not event:
                    return ''
                for key in keys:
                    text = event.get(key)
                    if text:
                        return str(text).strip()
                return ''

            title = value(current, 'name', 'title')
            start_time = value(current, 't_time', 'start_time')
            end_time = value(current, 't_time_to', 'end_time')
            description = value(current, 'descr', 'description', 'plot', 'text', 'info')
            detail_parts = []
            if title:
                detail_parts.append(title)
            if start_time or end_time:
                detail_parts.append('{} – {}'.format(start_time, end_time).strip(' –'))
            if description:
                detail_parts.extend(['', description])
            detail_text = '\n'.join(detail_parts) if detail_parts else now_line

            if following:
                next_title = value(following, 'name', 'title')
                next_start = value(following, 't_time', 'start_time')
                next_end = value(following, 't_time_to', 'end_time')
                next_parts = [part for part in (next_title, '{} – {}'.format(next_start, next_end).strip(' –')) if part]
                next_line = '\n'.join(next_parts) or next_line
            return now_line, next_line, detail_text
        except Exception:
            return '', '', 'Keine EPG-Information verfügbar'

    def _set_label(self, control_id, value):
        try:
            self.getControl(control_id).setLabel(value or '')
        except Exception:
            pass

    def _update_info(self):
        try:
            item = self.getControl(300).getSelectedItem()
            if not item:
                return
            self._set_label(401, item.getProperty('channel_name'))
            number = item.getProperty('display_number') or item.getProperty('channel_number')
            playing = item.getProperty('playing_badge')
            meta = 'Programmplatz {}  •  {}'.format(number, playing or 'AUSWAHL')
            self._set_label(402, meta)
            self._set_label(406, item.getProperty('quality'))
            self._set_label(403, item.getProperty('detail_text') or 'Keine EPG-Information verfügbar')
            self._set_label(404, item.getProperty('next_line'))
            try:
                self.getControl(400).setImage(item.getProperty('logo'))
            except Exception:
                pass
        except Exception:
            pass

    def _set_status(self, text):
        self._set_label(405, text)

    def _mark_playing(self, index):
        try:
            control = self.getControl(300)
            for position in range(control.size()):
                row_item = control.getListItem(position)
                row_item.setProperty('currently_playing', '▶' if position == index else '')
                row_item.setProperty('playing_badge', 'LÄUFT' if position == index else '')
            self._playing_index = index
        except Exception:
            self._playing_index = index

    def _switch_channel(self, index, item):
        """Switch through the single direct-playback controller."""
        if self.controller.busy:
            return
        if index < 0 or index >= len(self.rows):
            self._set_status('Sender momentan nicht erreichbar')
            return

        row = self.rows[index]
        channel_name = item.getProperty('channel_name') or str(row.get('name') or 'Sender')
        self._set_status('Verbinde mit {} …'.format(channel_name))
        success, error_text = self.controller.play(
            row=row,
            channel_name=channel_name,
            detail_text=item.getProperty('detail_text'),
            logo=str(row.get('logo') or ''),
        )
        if success:
            self._mark_playing(index)
            self.controller.active_index = index
            self._set_status('{} wird wiedergegeben'.format(channel_name))
            Logger.info('Favorite zapper switched directly to {}'.format(channel_name))
            xbmc.sleep(250)
            self.close()
            return

        self._set_status('{} – bitte anderen Sender wählen'.format(error_text))
        Logger.warning('Favorite zapper direct stream unavailable: {}'.format(channel_name))
        try:
            self.getControl(300).selectItem(index)
            self.setFocusId(300)
        except Exception:
            pass

    def onFocus(self, control_id):
        # Some skins dispatch focus changes differently. Keeping this callback
        # in addition to onAction makes the preview panel follow the list in
        # Estuary, Aeon-derived and Arctic-derived skins alike.
        if control_id == 300:
            self._update_info()

    def _select_channel_number(self, digit):
        now = time.time()
        if now - self._number_buffer_time > 1.8:
            self._number_buffer = ''
        self._number_buffer_time = now
        self._number_buffer = (self._number_buffer + digit)[-4:]
        try:
            requested = int(self._number_buffer)
        except Exception:
            self._number_buffer = ''
            return
        if requested < 1 or requested > len(self.rows):
            self._set_status('Programmplatz {} ist nicht vorhanden'.format(self._number_buffer))
            return
        try:
            self.getControl(300).selectItem(requested - 1)
            self.setFocusId(300)
            self._update_info()
            item = self.getControl(300).getSelectedItem()
            name = item.getProperty('channel_name') if item else ''
            self._set_status('{}  {} – mit OK bestätigen'.format(requested, name).strip())
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id != 300:
            return
        control = self.getControl(300)
        item = control.getSelectedItem()
        if not item:
            return
        index = control.getSelectedPosition()
        self._switch_channel(index, item)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = -1
        if action_id in _ACTION_CANCEL:
            self.selected_url = ''
            self.close()
            return
        digit = _ACTION_DIGITS.get(action_id)
        if digit is not None:
            self._select_channel_number(digit)
            return
        # Kodi normally sends clicks for OK on a focused list. A few remote
        # mappings only dispatch ACTION_SELECT, so handle that path explicitly.
        if action_id in _ACTION_SELECT:
            try:
                control = self.getControl(300)
                item = control.getSelectedItem()
                if item:
                    self._switch_channel(control.getSelectedPosition(), item)
            except Exception:
                pass
            return
        # Kodi moves the list focus after dispatching the action. A tiny delay
        # lets the information pane follow the newly focused channel reliably.
        if action_id in _ACTION_NAVIGATION:
            xbmc.sleep(25)
            self._number_buffer = ''
            self._update_info()


def _quality(name):
    upper = str(name or '').upper()
    if any(token in upper for token in ('8K', '4320P')):
        return '8K'
    if any(token in upper for token in ('4K', 'UHD', '2160P')):
        return 'UHD'
    if any(token in upper for token in ('FHD', '1080P')):
        return 'FHD'
    if any(token in upper for token in (' HD', '720P')):
        return 'HD'
    return 'SD'


def show_favorite_zapper():
    try:
        rows = _load_favorites()
    except Exception as exc:
        Logger.error('Favorite zapper could not load favorites: {}'.format(exc))
        xbmcgui.Dialog().notification('TitanMacVOD', 'Favoriten konnten nicht geladen werden.', xbmcgui.NOTIFICATION_ERROR, 3500)
        return

    if not rows:
        xbmcgui.Dialog().notification('TitanMacVOD', 'Keine TV-Favoriten vorhanden.', xbmcgui.NOTIFICATION_INFO, 3000)
        return

    addon_path = _addon_path()
    ctx_key = _ctx_key(rows)
    try:
        dialog = FavoriteZapperDialog(
            _dialog_xml(), addon_path, 'Default', '1080i',
            rows=rows, ctx_key=ctx_key,
        )
        home = xbmcgui.Window(10000)
        home.setProperty('TitanMacVOD.ZapperActive', '1')
        try:
            dialog.doModal()
        finally:
            home.clearProperty('TitanMacVOD.ZapperActive')
            del dialog
    except Exception as exc:
        # A third-party skin must never make the zapper unusable.  The native
        # selection dialog remains a last-resort fallback and also resolves
        # the final stream directly, without opening another plug-in route.
        Logger.error('Favorite zapper XML failed for skin {}: {}'.format(_skin_id(), exc))
        labels = [
            '{}   {}'.format(index + 1, str(row.get('name') or 'Unbenannter Sender'))
            for index, row in enumerate(rows)
        ]
        choice = xbmcgui.Dialog().select('TV-Favoriten', labels, useDetails=False)
        if choice >= 0:
            row = rows[choice]
            try:
                stream_url = Api.get_tv_stream_url(row)
                if stream_url:
                    home = xbmcgui.Window(10000)
                    home.setProperty('TitanMacVOD.LivePlayback', '1')
                    home.setProperty('TitanMacVOD.RequestedStream', _stream_identity(stream_url))
                    home.setProperty('TitanMacVOD.PlayingChannelId', str(row.get('id') or ''))
                    home.setProperty('TitanMacVOD.PlayingChannelName', str(row.get('name') or ''))
                    item = xbmcgui.ListItem(path=stream_url)
                    item.setProperty('IsPlayable', 'true')
                    xbmc.Player().play(stream_url, item)
            except Exception as play_exc:
                Logger.error('Favorite zapper fallback playback failed: {}'.format(play_exc))
                xbmcgui.Dialog().notification(
                    'TitanMacVOD', 'Sender momentan nicht erreichbar.',
                    xbmcgui.NOTIFICATION_ERROR, 3000)
