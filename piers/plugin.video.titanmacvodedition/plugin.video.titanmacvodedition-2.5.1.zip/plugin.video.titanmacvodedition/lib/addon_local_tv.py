"""Split portion of the Kodi add-on controller.

Kept as a class named StalkerAddon so Python private-name mangling remains
compatible with the original monolithic implementation.
"""
from __future__ import absolute_import, division, unicode_literals
from .addon_shared import *


class StalkerAddon:
    @staticmethod
    def __notify(message, error=False):
        xbmcgui.Dialog().notification(
            ADDON_NAME, message,
            xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO,
            3000)

    @staticmethod
    def __choose_local_group(allow_create=True):
        groups = local_tv.groups()
        labels = [group.get('name', '') for group in groups]
        if allow_create:
            labels.append(DIALOG_NEW_GROUP)
        selected = xbmcgui.Dialog().select('Lokale Senderliste auswählen', labels)
        if selected < 0:
            return None
        if allow_create and selected == len(groups):
            name = xbmcgui.Dialog().input('Name der neuen Senderliste').strip()
            return local_tv.create_group(name) if name else None
        return groups[selected]

    @staticmethod
    def __local_tv_add(params):
        group = StalkerAddon.__choose_local_group(True)
        if not group:
            return
        channel = {
            'id': params.get('video_id', ''), 'name': params.get('name', ''),
            'cmd': params.get('cmd', ''), 'logo': params.get('logo', ''),
            'use_http_tmp_link': params.get('use_http_tmp_link', 0),
            'use_load_balancing': params.get('use_load_balancing', 0),
        }
        result = local_tv.add_channel(group.get('id'), channel)
        messages = {
            'added': 'Sender wurde zu „{}“ hinzugefügt.'.format(group.get('name', '')),
            'exists': 'Sender ist bereits in dieser Liste.',
            'error': 'Sender konnte nicht gespeichert werden.',
            'missing_group': 'Senderliste wurde nicht gefunden.',
        }
        StalkerAddon.__notify(messages.get(result, 'Unbekannter Fehler.'), result not in ('added', 'exists'))

    @staticmethod
    def __list_local_tv_groups():
        xbmcplugin.setPluginCategory(G.get_handle(), LOCAL_TV_LISTS_PLAIN_LABEL)
        xbmcplugin.setContent(G.get_handle(), 'files')
        groups = local_tv.groups()
        for index, group in enumerate(groups):
            item = xbmcgui.ListItem(label=group.get('name', ''))
            group_icon = local_tv_art_path(group.get('name', ''))
            item.setArt({'icon': group_icon, 'thumb': group_icon,
                         'poster': group_icon, 'fanart': fanart_path()})
            group_id = group.get('id', '')
            menu = [
                ('Senderliste automatisch synchronisieren', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_sync_group', 'group_id': group_id}))),
                ('Sender hinzufügen', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_group_add_channels', 'group_id': group_id}))),
                ('Senderliste importieren', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_import', 'group_id': group_id}))),
                ('Senderliste exportieren', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_export_group', 'group_id': group_id}))),
                ('Umbenennen', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_group_rename', 'group_id': group_id}))),
                ('Löschen', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_group_delete', 'group_id': group_id}))),
            ]
            if index > 0:
                menu.append(('Sender nach oben verschieben', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_group_move', 'group_id': group_id, 'direction': -1}))))
            if index < len(groups) - 1:
                menu.append(('Sender nach unten verschieben', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_group_move', 'group_id': group_id, 'direction': 1}))))
            item.addContextMenuItems(menu)
            url = G.get_plugin_url({'action': 'local_tv_group', 'group_id': group_id})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, item, True)
        # Offer the bundled starter template only while no TV-Spielfilm list exists.
        # Once created, the normal list remains the only visible entry.
        if not any(str(group.get('name', '')).strip().lower() == 'tv spielfilm' for group in groups):
            template_item = xbmcgui.ListItem(label='TV Spielfilm erstellen')
            template_icon = local_tv_art_path('TV Spielfilm')
            template_item.setArt({'icon': template_icon, 'thumb': template_icon,
                                  'poster': template_icon, 'fanart': fanart_path()})
            xbmcplugin.addDirectoryItem(
                G.get_handle(),
                G.get_plugin_url({'action': 'local_tv_template_tv_spielfilm'}),
                template_item,
                False,
            )
        create_item = xbmcgui.ListItem(label='Neue Senderliste erstellen')
        create_icon = local_tv_art_path()
        create_item.setArt({'icon': create_icon, 'thumb': create_icon, 'fanart': fanart_path()})
        xbmcplugin.addDirectoryItem(G.get_handle(), G.get_plugin_url({'action': 'local_tv_group_create'}), create_item, False)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, cacheToDisc=False)

    @staticmethod
    def __create_tv_spielfilm_template():
        result = local_tv.create_default_tv_spielfilm_group()
        status = result.get('status')
        if status == 'created':
            StalkerAddon.__notify(
                'TV Spielfilm wurde mit {} Sendern erstellt.'.format(result.get('count', 0))
            )
            xbmc.executebuiltin('Container.Refresh')
        elif status == 'exists':
            StalkerAddon.__notify('Die Senderliste „TV Spielfilm“ ist bereits vorhanden.')
        else:
            StalkerAddon.__notify('Die TV-Spielfilm-Vorlage konnte nicht erstellt werden.', True)

    @staticmethod
    def __show_local_tv_sync_summary(force=False):
        """Show a concise synchronization result once per portal/filter context."""
        if not force and local_tv.sync_summary_was_shown():
            return
        summary = local_tv.current_sync_summary()
        total = int(summary.get('total') or 0)
        available = int(summary.get('available') or 0)
        unresolved = int(summary.get('unresolved') or 0)
        if total <= 0:
            return
        lines = [
            '[COLOR=green]{} von {} Sendern[/COLOR] wurden erfolgreich synchronisiert.'.format(available, total)
        ]
        if unresolved:
            missing = [ch.get('name', '') for g in local_tv.groups() for ch in g.get('channels') or []
                       if not local_tv.mapping_is_valid(ch)]
            if missing:
                lines.extend(['', 'Nicht verfügbar: ' + ', '.join(missing)])
        if unresolved == 1:
            lines.extend([
                '',
                '[COLOR=orange]1 Sender[/COLOR] benötigt eine manuelle Zuordnung.',
                '',
                'Öffnen Sie die Senderliste und wählen Sie über das',
                'Kontextmenü [B]„Portal-Sender auswählen“[/B].',
            ])
        elif unresolved > 1:
            lines.extend([
                '',
                '[COLOR=orange]{} Sender[/COLOR] benötigen eine manuelle Zuordnung.'.format(unresolved),
                '',
                'Öffnen Sie die Senderliste und wählen Sie über das',
                'Kontextmenü [B]„Portal-Sender auswählen“[/B].',
            ])
        xbmcgui.Dialog().ok('Synchronisierung abgeschlossen', '\n'.join(lines))
        local_tv.mark_sync_summary_shown(True)

    @staticmethod
    def __list_local_tv_group(params):
        group = local_tv.get_group(params.get('group_id'))
        if not group:
            StalkerAddon.__notify('Senderliste wurde nicht gefunden.', True)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        xbmcplugin.setPluginCategory(G.get_handle(), group.get('name', ''))
        xbmcplugin.setContent(G.get_handle(), 'files')
        # A new portal is indexed once across every country-filtered TV group.
        # All local lists are then synchronized against that shared index.
        progress_dialog = None
        try:
            sync_total = local_tv.current_sync_summary().get('total', 0)
            # Run one complete remap for every new portal/filter/matcher context.
            # Existing IDs cannot be trusted because portal channel IDs are local
            # to each provider, even when the old mapping is still playable.
            auto_sync_needed = sync_total and local_tv.automatic_sync_is_due()
            if auto_sync_needed:
                progress_dialog = xbmcgui.DialogProgress()
                progress_dialog.create(
                    'Meine Sender werden synchronisiert',
                    'Vollständiger Portal-Index wird vorbereitet...',
                )

                def update_index_progress(completed, total, group_name, channel_count):
                    # The index occupies the first half of the progress bar.
                    phase_percent = int(round((float(completed) / float(total)) * 50)) if total else 50
                    progress_dialog.update(
                        max(0, min(50, phase_percent)),
                        'Portal-Index: Gruppe {} von {}\n{}\n{} Sender eingelesen'.format(
                            completed, total, group_name or 'Portalgruppe', channel_count,
                        ),
                    )

                # Meine Sender must use the complete portal catalogue. Country-
                # filtered groups can omit valid favourites such as KiKA, Disney,
                # Nickelodeon or documentary channels even though manual search
                # finds them portal-wide.
                index_result = local_tv.build_all_portal_index(
                    force=True,
                    progress_callback=update_index_progress,
                    cancel_callback=progress_dialog.iscanceled,
                )
                if index_result.get('cancelled'):
                    sync_result = {
                        'mapped': 0, 'unresolved': 0, 'searched': 0,
                        'total': sync_total, 'cancelled': True,
                    }
                else:
                    catalog = index_result.get('channels') or []
                    if not catalog:
                        # A failed portal request must not erase working mappings.
                        raise RuntimeError('Portal-Senderindex ist leer; bestehende Favoriten bleiben erhalten')

                    def update_sync_progress(completed, total, channel_name):
                        # Mapping occupies the second half of the progress bar.
                        phase = int(round((float(completed) / float(total)) * 50)) if total else 50
                        percent = 50 + phase
                        progress_dialog.update(
                            max(50, min(100, percent)),
                            '{} von {} Sendern\n{}\n{} %'.format(
                                completed, total, channel_name or 'Sender wird zugeordnet', percent,
                            ),
                        )

                    sync_result = local_tv.sync_all_groups_for_current_portal(
                        catalog,
                        progress_callback=update_sync_progress,
                        cancel_callback=progress_dialog.iscanceled,
                    )

                if not sync_result.get('cancelled'):
                    progress_dialog.update(
                        100,
                        '{} von {} Sendern\nSynchronisierung abgeschlossen\n100 %'.format(
                            sync_result.get('searched', 0), sync_result.get('total', 0),
                        ),
                    )
                if sync_result.get('mapped'):
                    group = local_tv.get_group(group.get('id', '')) or group
                if sync_result.get('cancelled'):
                    StalkerAddon.__notify(
                        'Synchronisierung abgebrochen: {} Sender zugeordnet.'.format(sync_result.get('mapped', 0))
                    )
                else:
                    if sync_result.get('searched') == sync_result.get('total'):
                        local_tv.mark_automatic_sync_completed(True)
                        StalkerAddon.__show_local_tv_sync_summary(force=False)
        except Exception as exc:
            Logger.error('Automatic local TV sync failed: {}'.format(exc))
        finally:
            if progress_dialog is not None:
                progress_dialog.close()
        catalog = local_tv.get_cached_all_portal_catalog()
        identity_index = None
        # Local lists use the exact same merged EPG dictionary as normal TV
        # groups. Previously these entries were created with an empty EPG
        # string, so XMLTV/portal EPG could never appear under MEINE SENDER.
        epg_dict = _get_epg_dictionary()
        channels = []
        directory_items = []
        ctx_key = hashlib.md5(('local|' + group.get('id', '')).encode('utf-8')).hexdigest()
        entries = group.get('channels') or []
        if not entries:
            StalkerAddon.__notify('Die Senderliste ist leer. Sender über das Kontextmenü der Liste hinzufügen.')
        for index, saved in enumerate(entries):
            resolved, _ = local_tv.resolve_channel(saved, catalog, identity_index)
            channel = resolved or {}
            available = bool(resolved)
            programmplatz = index + 1
            base_name = saved.get('name','')
            label = ('[COLOR FFADADAD]{:03d}[/COLOR]  {}'.format(programmplatz, base_name) if available else '[COLOR FFADADAD]{:03d}[/COLOR]  [COLOR orange]{} - nicht verfügbar[/COLOR]'.format(programmplatz, base_name))
            logo = resolve_channel_logo(channel, saved, _get_favoriten_icon())
            group_id = group.get('id', '')
            channel_id = saved.get('id', '')
            add_url = G.get_plugin_url({'action': 'local_tv_group_add_channels', 'group_id': group_id})
            menu = [
                ('Portal-Sender auswählen', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_map', 'group_id': group_id, 'channel_id': channel_id}))),
                ('Automatische Zuordnung wiederherstellen', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_unmap', 'group_id': group_id, 'channel_id': channel_id}))),
                ('Aus Favoriten entfernen', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_remove', 'group_id': group_id, 'channel_id': channel_id}))),
            ]
            if index > 0:
                menu.append(('Sender nach oben verschieben', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_move', 'group_id': group_id, 'channel_id': channel_id, 'direction': -1}))))
            if index < len(entries) - 1:
                menu.append(('Sender nach unten verschieben', 'RunPlugin({}, False)'.format(G.get_plugin_url({'action': 'local_tv_move', 'group_id': group_id, 'channel_id': channel_id, 'direction': 1}))))
            if available:
                # Use exactly the same EPG resolver as the normal portal
                # sender groups. It tries the live portal id first and falls
                # back to epg_id/ch_id/channel_id when needed.
                epg_channel = _favorite_epg_channel(saved, channel, catalog)
                epgid, epg_text, plot_text, now_line, next_line = _get_channel_epg_bundle(epg_channel, epg_dict)

                # Keep the current EPG in the primary label for native Kodi
                # directory views, while retaining Label2/properties as an
                # additional source for skins that support them.
                clean_label = saved.get('name', '')
                # Render local favourites through the same ListItem path as
                # the working portal channel lists: build the EPG part first,
                # add the programme number afterwards, and do not set a title
                # InfoTag that a skin could prefer over the primary label.
                label_main = _build_compact_now_in_label(clean_label, now_line)
                final_label = numbered_channel_label(programmplatz, label_main)
                item = _create_skin_neutral_live_item(
                    label=final_label,
                    channel_name=clean_label,
                    programme_number=programmplatz,
                    now_line=now_line,
                    next_line=next_line,
                    plot_text=plot_text,
                    logo=logo,
                    fanart=fanart_path(),
                    playable=True,
                )

                payload = _channel_payload(channel, epg_text)
                payload['name'] = clean_label
                payload['epg_id'] = epgid
                channels.append(payload)
                url = G.get_plugin_url({
                    'action': 'tv_play', 'idx': str(len(channels) - 1), 'cmd': channel.get('cmd', ''),
                    'use_http_tmp_link': channel.get('use_http_tmp_link', 0),
                    'use_load_balancing': channel.get('use_load_balancing', 0),
                    'name': clean_label, 'logo': logo, 'epg_text': epg_text or '',
                    'epg_id': str(epgid), 'ctx': ctx_key,
                })
            else:
                item = _create_skin_neutral_live_item(
                    label=label, channel_name=base_name,
                    programme_number=programmplatz, logo=logo,
                    fanart=fanart_path(), playable=False,
                )
                url = G.get_plugin_url({'action': 'local_tv_map', 'group_id': group_id, 'channel_id': channel_id})
            item.addContextMenuItems(menu)
            directory_items.append((url, item, False))
        if channels:
            _save_zap_context(ctx_key, {'category': group.get('name', ''), 'channels': channels})
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, len(directory_items))
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, cacheToDisc=False)

    @staticmethod
    def __local_tv_group_add_channels(params):
        group = local_tv.get_group(params.get('group_id'))
        if not group:
            StalkerAddon.__notify('Senderliste wurde nicht gefunden.', True)
            return
        try:
            genres = Api.get_tv_genres() or []
        except Exception as exc:
            Logger.error('Could not load portal TV groups: {}'.format(exc))
            StalkerAddon.__notify('Portal-Sendergruppen konnten nicht geladen werden.', True)
            return
        labels = [(genre.get('title') or genre.get('name') or '').strip() for genre in genres]
        valid = [(genre, label) for genre, label in zip(genres, labels) if label]
        selected_group = xbmcgui.Dialog().select('Portal-Sendergruppe auswählen', [label for _, label in valid])
        if selected_group < 0:
            return
        genre, genre_label = valid[selected_group]
        channels = local_tv.get_cached_portal_group_channels(genre.get('id'))
        if not channels:
            loading_dialog = xbmcgui.DialogProgress()
            loading_dialog.create(
                'Senderliste wird geladen',
                'Portalgruppe „{}“ wird erstmals eingelesen...'.format(genre_label))
            loading_dialog.update(10, 'Verbindung zum Portal wird hergestellt...')
            try:
                channels = local_tv.get_portal_group_channels(genre.get('id'))
                loading_dialog.update(100, '{} Sender wurden geladen.'.format(len(channels)))
            except Exception as exc:
                Logger.error('Could not load channels for portal group {}: {}'.format(genre_label, exc))
                StalkerAddon.__notify('Sender konnten nicht geladen werden.', True)
                return
            finally:
                loading_dialog.close()
        channels = sorted(channels, key=lambda item: item.get('name', '').lower())
        if not channels:
            StalkerAddon.__notify('In dieser Portalgruppe wurden keine Sender gefunden.', True)
            return
        selected = xbmcgui.Dialog().multiselect(
            'Sender aus „{}“ hinzufügen'.format(genre_label),
            [local_tv.clean_channel_display_name(item.get('name', '')) or item.get('name', '') for item in channels])
        if not selected:
            return
        result = local_tv.add_channels(group.get('id'), [channels[index] for index in selected])
        status = result.get('status')
        if status == 'added':
            message = '{} Sender hinzugefügt.'.format(result.get('added', 0))
            if result.get('skipped'):
                message += ' {} bereits vorhanden.'.format(result.get('skipped'))
            StalkerAddon.__notify(message)
            xbmc.executebuiltin('Container.Refresh')
        elif status == 'exists':
            StalkerAddon.__notify('Die ausgewählten Sender sind bereits in dieser Liste.')
        else:
            StalkerAddon.__notify('Sender konnten nicht gespeichert werden.', True)

    @staticmethod
    def __local_tv_map(params):
        group = local_tv.get_group(params.get('group_id'))
        saved = next((item for item in (group or {}).get('channels', []) if item.get('id') == params.get('channel_id')), None)
        if not saved:
            StalkerAddon.__notify('Sender wurde nicht gefunden.', True)
            return

        # Direct, editable search with no history dialog. The cleaned favorite
        # name is a suggestion only; the user can change it before searching.
        query = xbmcgui.Dialog().input(
            'Sender suchen',
            defaultt=local_tv.manual_search_term(saved.get('name', '')),
            type=xbmcgui.INPUT_ALPHANUM,
        )
        query = str(query or '').strip()
        if not query:
            return

        chosen = None
        catalog = local_tv.get_cached_portal_catalog()
        progress = xbmcgui.DialogProgress()
        progress.create('Sender werden gesucht', 'Suche im aktuellen Portal...')
        try:
            all_catalog = local_tv.get_cached_all_portal_catalog()
            if not all_catalog:
                progress.update(5, 'Portal-Senderkatalog wird aufgebaut...')
                index_result = local_tv.build_all_portal_index(
                    progress_callback=lambda pos, total, name, count=0: progress.update(
                        min(95, int((float(pos) / max(1, total)) * 95)),
                        'Lade {}... ({} Sender)'.format(name, count)),
                    cancel_callback=progress.iscanceled,
                )
                if index_result.get('cancelled') or progress.iscanceled():
                    return
                all_catalog = index_result.get('channels') or []
            progress.update(96, 'Treffer werden gesucht...')
            results = local_tv.search_portal_channels(
                query, channels=all_catalog, all_groups=True, limit=150)
            # Prefer DACH matches without hiding other portal channels.
            dach_channels = local_tv.filter_catalog_for_active_country_groups(results)
            dach_ids = {id(item) for item in dach_channels}
            # Some filtering implementations return copied dictionaries;
            # compare stable channel and group identifiers as a fallback.
            dach_keys = {(str(item.get('id')), str(item.get('genre_id') or item.get('category_id') or ''))
                         for item in dach_channels}
            def dach_first(item):
                key = (str(item.get('id')), str(item.get('genre_id') or item.get('category_id') or ''))
                return 0 if id(item) in dach_ids or key in dach_keys else 1
            results.sort(key=dach_first)
            progress.update(100, '{} Treffer gefunden.'.format(len(results)))
        except Exception as exc:
            Logger.error('Manual channel search failed: {}'.format(exc))
            StalkerAddon.__notify('Sendersuche ist fehlgeschlagen.', True)
            return
        finally:
            progress.close()
        if not results:
            StalkerAddon.__notify('Kein Sender für „{}“ gefunden.'.format(query))
            return
        result_index = select_channel_result(
            '{} Treffer für „{}“'.format(len(results), query), results,
            local_tv.clean_channel_display_name, local_tv.quality_label)
        if result_index < 0:
            return
        chosen = results[result_index]

        if chosen:
            # All manual paths use the same resolver. Search results and group
            # entries can therefore be selected identically, even when the
            # portal initially returned only a name/id without ``cmd``.
            resolved = local_tv.resolve_playable_portal_channel(chosen, catalog=catalog)
            if not xbmcgui.Dialog().yesno('Portal-Sender auswählen',
                    'Favorit: {}\nPortal-Sender: {}\n\nDiese Zuordnung für das aktuelle Portal und die aktuelle MAC speichern?'.format(
                        saved.get('name', ''), resolved.get('name', chosen.get('name', '')))):
                return
            if local_tv.set_mapping(params.get('group_id'), params.get('channel_id'), resolved):
                StalkerAddon.__notify(
                    'Sender wurde „{}“ zugeordnet. Die Liste wird beim nächsten Öffnen aktualisiert.'.format(
                        resolved.get('name', chosen.get('name', ''))
                    )
                )
                # This action is opened with RunPlugin from a context menu.
                # Container.Refresh here starts the directory action again on
                # some Kodi skins and causes an endless loading spinner.  The
                # saved mapping is already persistent, so simply return.
                return
            else:
                StalkerAddon.__notify(
                    'Der Sender wurde gefunden, aber das Portal lieferte keine abspielbare Stream-Adresse.',
                    True,
                )

    @staticmethod
    def __browse_export_directory():
        selected = xbmcgui.Dialog().browseSingle(3, 'Exportordner auswählen', 'files')
        if not selected:
            return ''
        try:
            return xbmcvfs.translatePath(selected)
        except Exception:
            return selected

    @staticmethod
    def __local_tv_export_group(params):
        directory = StalkerAddon.__browse_export_directory()
        if not directory:
            return
        result = local_tv.export_group_package(params.get('group_id', ''), directory)
        if result.get('status') == 'exported':
            StalkerAddon.__notify('Senderliste wurde als ZIP exportiert.')
        else:
            StalkerAddon.__notify('Senderliste konnte nicht exportiert werden.', True)

    @staticmethod
    def __local_tv_export_all():
        directory = StalkerAddon.__browse_export_directory()
        if not directory:
            return
        result = local_tv.export_all_packages(directory)
        if result.get('status') == 'exported':
            StalkerAddon.__notify('{} Senderlisten wurden exportiert.'.format(result.get('count', 0)))
        elif result.get('status') == 'empty':
            StalkerAddon.__notify('Es sind keine Senderlisten vorhanden.')
        else:
            StalkerAddon.__notify('Senderlisten konnten nicht exportiert werden.', True)

    @staticmethod
    def __local_tv_import(params):
        target_group = local_tv.get_group(params.get('group_id', ''))
        if not target_group:
            StalkerAddon.__notify('Senderliste wurde nicht gefunden.', True)
            return

        selected = xbmcgui.Dialog().browseSingle(
            1, 'Senderliste auswählen', 'files', '.zip|.txt', False, False, ''
        )
        if not selected:
            return
        try:
            selected = xbmcvfs.translatePath(selected)
        except Exception:
            pass

        package = local_tv.inspect_import_file(selected)
        definitions = package.get('lists') or []
        if package.get('status') != 'ok' or not definitions:
            StalkerAddon.__notify('Keine gültigen Senderlisten gefunden.', True)
            return

        definition = definitions[0]
        if len(definitions) > 1:
            labels = ['{} ({} Sender)'.format(item.get('name', ''), len(item.get('channels') or []))
                      for item in definitions]
            selected_index = xbmcgui.Dialog().select('Senderliste aus Paket auswählen', labels)
            if selected_index < 0:
                return
            definition = definitions[selected_index]

        target_name = target_group.get('name', '')
        choice = xbmcgui.Dialog().select(
            'Importieren nach „{}“'.format(target_name),
            [
                '„{}“ ersetzen'.format(target_name),
                'Mit „{}“ zusammenführen'.format(target_name),
                'Als neue Senderliste erstellen',
                'Abbrechen',
            ],
        )
        if choice < 0 or choice == 3:
            return

        if choice == 0:
            import_name, mode = target_name, 'replace'
        elif choice == 1:
            import_name, mode = target_name, 'merge'
        else:
            import_name = definition.get('name', '') or 'Importierte Senderliste'
            existing = next((group for group in local_tv.groups()
                             if str(group.get('name', '')).casefold() == str(import_name).casefold()), None)
            if existing:
                rename_choice = xbmcgui.Dialog().select(
                    '„{}“ ist bereits vorhanden'.format(import_name),
                    ['Als neue Liste mit angepasstem Namen importieren', 'Abbrechen'],
                )
                if rename_choice != 0:
                    return
                mode = 'rename'
            else:
                mode = 'new'

        result = local_tv.import_list_definition(
            import_name, definition.get('channels') or [], mode
        )
        if result.get('status') != 'imported':
            StalkerAddon.__notify('Senderliste konnte nicht importiert werden.', True)
            return

        art_count = local_tv.install_import_art(selected, [{
            'name': result.get('name') or import_name,
            'source_file': definition.get('source_file') or '',
        }])
        message = '{} Sender wurden importiert.'.format(int(result.get('count') or 0))
        if art_count:
            message += ' Listenbild wurde übernommen.'
        StalkerAddon.__notify(message)
        xbmc.executebuiltin('Container.Refresh')

    @staticmethod
    def __local_tv_run_sync(force_index=False, group_id=None):
        if not G.portal_config.portal_url:
            StalkerAddon.__notify('Bitte zuerst ein Portal auswählen.', True)
            return
        if group_id and not local_tv.get_group(group_id):
            StalkerAddon.__notify('Senderliste wurde nicht gefunden.', True)
            return
        progress = xbmcgui.DialogProgress()
        progress.create('Meine Sender werden synchronisiert', 'Vollständiger Portal-Index wird vorbereitet...')
        try:
            if force_index:
                local_tv.clear_portal_catalog_cache()
            def index_progress(completed, total, group_name, channel_count):
                percent = int(round((float(completed) / float(total)) * 50)) if total else 50
                progress.update(max(0, min(50, percent)), 'Portal-Index: Gruppe {} von {}\n{}\n{} Sender eingelesen'.format(
                    completed, total, group_name or 'Portalgruppe', channel_count))
            index_result = local_tv.build_all_portal_index(
                force=force_index, progress_callback=index_progress, cancel_callback=progress.iscanceled)
            if index_result.get('cancelled'):
                StalkerAddon.__notify('Synchronisierung wurde abgebrochen.')
                return
            # Manual synchronization deliberately rebuilds every mapping for the active portal.
            def sync_progress(completed, total, channel_name):
                phase = int(round((float(completed) / float(total)) * 50)) if total else 50
                percent = 50 + phase
                progress.update(max(50, min(100, percent)), '{} von {} Sendern\n{}\n{} %'.format(
                    completed, total, channel_name or 'Sender wird zugeordnet', percent))
            result = local_tv.sync_all_groups_for_current_portal(
                index_result.get('channels') or [], progress_callback=sync_progress,
                cancel_callback=progress.iscanceled, group_id=group_id)
            if result.get('cancelled'):
                StalkerAddon.__notify('Synchronisierung wurde abgebrochen.')
            else:
                progress.update(100, 'Synchronisierung abgeschlossen\n{} von {} Sendern zugeordnet\n100 %'.format(
                    result.get('mapped', 0), result.get('total', 0)))
                progress.close()
                progress = None
                xbmcgui.Dialog().ok('Synchronisierung abgeschlossen',
                    '{} von {} Sendern zugeordnet.\n{} nicht verfügbar.{}'.format(
                        result.get('mapped', 0), result.get('total', 0), result.get('unresolved', 0),
                        ('\n\nNicht gefunden:\n' + '\n'.join(result.get('unresolved_names') or []))
                        if result.get('unresolved_names') else ''))
                xbmc.executebuiltin('Container.Refresh')
        except Exception as exc:
            Logger.error('Manual local TV sync failed: {}'.format(exc))
            StalkerAddon.__notify('Synchronisierung ist fehlgeschlagen.', True)
        finally:
            if progress is not None:
                progress.close()

    @staticmethod
    def __local_tv_group_action(action, params):
        group_id = params.get('group_id', '')
        group = local_tv.get_group(group_id)
        changed = False
        if action == 'create':
            name = xbmcgui.Dialog().input('Name der neuen Senderliste').strip()
            changed = bool(name and local_tv.create_group(name))
        elif action == 'rename' and group:
            name = xbmcgui.Dialog().input('Senderliste umbenennen', defaultt=group.get('name', '')).strip()
            changed = bool(name and local_tv.rename_group(group_id, name))
        elif action == 'delete' and group:
            confirmed = xbmcgui.Dialog().yesno(ADDON_NAME, 'Senderliste „{}“ wirklich löschen?'.format(group.get('name', '')))
            changed = confirmed and local_tv.delete_group(group_id)
        elif action == 'move':
            changed = local_tv.move_group(group_id, int(params.get('direction', 0)))
        if changed:
            xbmc.executebuiltin('Container.Refresh')
