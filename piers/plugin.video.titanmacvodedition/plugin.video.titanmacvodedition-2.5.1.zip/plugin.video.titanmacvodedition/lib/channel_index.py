"""Shared in-memory channel catalogue index.

The persistent portal catalogue remains owned by :mod:`portal_index`.  This
module adds a process-local, reusable lookup layer so directory rendering,
manual search and "Meine Sender" synchronization do not repeatedly scan the
same large list.
"""
from __future__ import absolute_import, unicode_literals

import hashlib
import re
import threading
import unicodedata

_TOKEN_RE = re.compile(r"[a-z0-9äöüß]+", re.I)
_LOCK = threading.RLock()
_CACHE = {}
_CACHE_ORDER = []
_CACHE_LIMIT = 4


def _fold(value):
    value = unicodedata.normalize('NFKD', str(value or ''))
    value = ''.join(ch for ch in value if not unicodedata.combining(ch))
    value = value.casefold().replace('ß', 'ss')
    return ' '.join(_TOKEN_RE.findall(value))


def _item_key(item):
    for field in ('id', 'channel_id', 'ch_id'):
        value = str((item or {}).get(field) or '').strip()
        if value:
            return 'id:' + value
    command = str((item or {}).get('cmd') or '').strip()
    if command:
        return 'cmd:' + command
    return 'name:' + _fold((item or {}).get('name'))


def _signature(channels, scope):
    digest = hashlib.sha1()
    digest.update(str(scope or '').encode('utf-8'))
    digest.update(str(len(channels or [])).encode('ascii'))
    # Sampling plus stable first/last records keeps construction cheap while
    # still invalidating on portal switches and normal catalogue refreshes.
    sample = list(channels[:12]) + list(channels[-12:]) if channels else []
    for item in sample:
        digest.update(_item_key(item).encode('utf-8', 'ignore'))
        digest.update(str(item.get('name') or '').encode('utf-8', 'ignore'))
        digest.update(b'\0')
    return digest.hexdigest()


class ChannelIndex(object):
    def __init__(self, channels, identity_func, quality_func):
        self.channels = list(channels or [])
        self.by_identity = {}
        self.best_by_identity = {}
        self.by_token = {}
        self.search_text = {}
        self._quality_func = quality_func

        for item in self.channels:
            identity = identity_func(item.get('name', ''))
            if identity:
                self.by_identity.setdefault(identity, []).append(item)
                current = self.best_by_identity.get(identity)
                if current is None or self._sort_key(item) < self._sort_key(current):
                    self.best_by_identity[identity] = item

            text = _fold(' '.join([
                str(item.get('name') or ''),
                str(item.get('category_name') or ''),
                str(item.get('group_title') or ''),
                ' '.join(str(v or '') for v in (item.get('group_titles') or [])),
                ' '.join(str(v or '') for v in (item.get('aliases') or [])),
            ]))
            key = _item_key(item)
            self.search_text[key] = text
            for token in set(text.split()):
                self.by_token.setdefault(token, []).append(item)

    def _sort_key(self, item):
        return (-self._quality_func(item.get('name', '')), str(item.get('name') or '').casefold())

    def exact(self, identities):
        result = []
        seen = set()
        for identity in identities or []:
            for item in self.by_identity.get(identity, []):
                key = _item_key(item)
                if key not in seen:
                    seen.add(key)
                    result.append(item)
        return result

    def best(self, identity):
        return self.best_by_identity.get(identity)

    def search(self, query, limit=1200):
        tokens = [token for token in _fold(query).split() if token]
        if not tokens:
            return []
        pools = [self.by_token.get(token, []) for token in tokens]
        if any(not pool for pool in pools):
            # Token may be embedded in a combined station name (e.g. RTL2).
            source = self.channels
        else:
            source = min(pools, key=len)
        result = []
        seen = set()
        for item in source:
            key = _item_key(item)
            text = self.search_text.get(key, '')
            if all(token in text for token in tokens) and key not in seen:
                seen.add(key)
                result.append(item)
                if len(result) >= max(1, int(limit or 1200)):
                    break
        return result


def get_index(channels, scope, identity_func, quality_func):
    channels = list(channels or [])
    key = (str(scope or ''), _signature(channels, scope))
    with _LOCK:
        index = _CACHE.get(key)
        if index is not None:
            return index
        index = ChannelIndex(channels, identity_func, quality_func)
        _CACHE[key] = index
        _CACHE_ORDER.append(key)
        while len(_CACHE_ORDER) > _CACHE_LIMIT:
            expired = _CACHE_ORDER.pop(0)
            _CACHE.pop(expired, None)
        return index


def clear():
    with _LOCK:
        _CACHE.clear()
        del _CACHE_ORDER[:]
