# -*- coding: utf-8 -*-
"""Maintenance, cache management, diagnostics and performance telemetry for v1.7.1."""
from __future__ import absolute_import, division, unicode_literals

import json
import os
import shutil
import tempfile
import platform
import sys
import time
from datetime import datetime

from .globals import G
from .loggers import Logger
from .paths import profile_file, local_tv_lists_path, local_tv_catalog_path, local_tv_groups_path

STATUS_FILE = 'maintenance_status.json'
XMLTV_LOCK_FILE = 'xmltv_refresh.lock'
MAPPING_BACKUP_FILE = 'local_tv_mappings_backup.json'
DIAGNOSTIC_REPORT_FILE = 'system_diagnostic_1.7.1.json'
PERFORMANCE_HISTORY_LIMIT = 30


def _read(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        return default if default is not None else {}


def _write(path, value):
    directory = os.path.dirname(path)
    if directory and not os.path.exists(directory):
        os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.titan_maintenance_', suffix='.tmp', dir=directory or None)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(value, handle, ensure_ascii=False, separators=(',', ':'))
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise


def status_path():
    return profile_file(STATUS_FILE)


def read_status():
    value = _read(status_path(), {})
    return value if isinstance(value, dict) else {}


def update_status(section, **values):
    data = read_status()
    current = data.get(section) if isinstance(data.get(section), dict) else {}
    current.update(values)
    data[section] = current
    try:
        _write(status_path(), data)
    except Exception as exc:
        Logger.warn('Could not write maintenance status: {}'.format(exc))
    return current


def file_info(path):
    exists = bool(path and os.path.exists(path))
    return {
        'exists': exists,
        'size': os.path.getsize(path) if exists else 0,
        'modified': os.path.getmtime(path) if exists else 0,
        'age_seconds': max(0, time.time() - os.path.getmtime(path)) if exists else None,
    }


def acquire_job_lock(name='xmltv', stale_seconds=7200):
    path = profile_file(XMLTV_LOCK_FILE if name == 'xmltv' else '{}.lock'.format(name))
    if os.path.exists(path):
        try:
            age = time.time() - os.path.getmtime(path)
            if age < stale_seconds:
                return None
            os.unlink(path)
            Logger.warn('Removed stale {} lock after {:.0f}s'.format(name, age))
        except Exception:
            return None
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            handle.write('{}\n{}'.format(os.getpid(), time.time()))
        return path
    except Exception:
        return None


def release_job_lock(path):
    if not path:
        return
    try:
        os.unlink(path)
    except Exception:
        pass


def run_xmltv_refresh(portal_channels=None, force=False):
    """Run XMLTV refresh once, guarded by a cross-invocation lock and status file."""
    lock = acquire_job_lock('xmltv')
    if not lock:
        update_status('xmltv', state='already_running', checked=time.time())
        Logger.info('XMLTV refresh skipped: another refresh is active')
        return None
    started = time.time()
    update_status('xmltv', state='running', started=started, force=bool(force), error='')
    try:
        from .xmltv import load_xmltv
        result = load_xmltv(portal_channels=portal_channels or [], force=force)
        count = len(result or {})
        update_status('xmltv', state='ok', finished=time.time(), duration_seconds=round(time.time()-started, 2), channels=count)
        Logger.info('XMLTV coordinated refresh finished in {:.1f}s with {} channels'.format(time.time()-started, count))
        record_performance('xmltv_refresh', started, channels=count, force=bool(force))
        return result
    except Exception as exc:
        update_status('xmltv', state='error', finished=time.time(), duration_seconds=round(time.time()-started, 2), error=str(exc))
        raise
    finally:
        release_job_lock(lock)


def create_mapping_backup():
    src = local_tv_lists_path()
    if not src or not os.path.exists(src):
        return ''
    data = _read(src, {})
    payload = {
        'format': 'titan-local-tv-backup-v1',
        'created': time.time(),
        'created_text': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'portal': getattr(G.portal_config, 'portal_url', '') or '',
        'data': data,
    }
    path = profile_file(MAPPING_BACKUP_FILE)
    _write(path, payload)
    update_status('mapping_backup', state='ok', created=payload['created'], path=path)
    return path


def restore_mapping_backup():
    path = profile_file(MAPPING_BACKUP_FILE)
    payload = _read(path, {})
    data = payload.get('data') if isinstance(payload, dict) else None
    if not isinstance(data, dict) or not isinstance(data.get('groups'), list):
        return False
    target = local_tv_lists_path()
    if os.path.exists(target):
        shutil.copy2(target, target + '.before_restore')
    _write(target, data)
    update_status('mapping_backup', state='restored', restored=time.time(), path=path)
    return True


def diagnostic_snapshot():
    from . import local_tv_lists as local_tv
    from . import portal_index
    data = local_tv.load_data()
    groups = data.get('groups') or []
    channels = [item for group in groups for item in (group.get('channels') or [])]
    portal = portal_index.load_all_index(allow_stale=True)
    mappings = 0
    unresolved = 0
    key = local_tv.portal_key()
    for channel in channels:
        mapping = ((channel.get('mappings') or {}).get(key) or {})
        if mapping.get('cmd'):
            mappings += 1
        else:
            unresolved += 1
    return {
        'portal_channels': len(portal.get('channels') or []),
        'portal_groups': int(portal.get('groups') or 0),
        'portal_cache_created': float(portal.get('created') or 0),
        'portal_cache_stale': bool(portal.get('stale', False)),
        'portal_cache_method': portal.get('method', ''),
        'local_groups': len(groups),
        'local_channels': len(channels),
        'manual_or_saved_mappings': mappings,
        'unresolved': unresolved,
        'files': {
            'catalog': file_info(local_tv_catalog_path()),
            'groups': file_info(local_tv_groups_path()),
            'lists': file_info(local_tv_lists_path()),
        },
        'status': read_status(),
    }


def record_performance(operation, started, **values):
    """Persist a small rolling performance history for user diagnostics."""
    elapsed = round(max(0.0, time.time() - float(started)), 3)
    data = read_status()
    history = data.get('performance') if isinstance(data.get('performance'), list) else []
    row = {'operation': str(operation), 'finished': time.time(), 'duration_seconds': elapsed}
    row.update(values)
    history.append(row)
    data['performance'] = history[-PERFORMANCE_HISTORY_LIMIT:]
    try:
        _write(status_path(), data)
    except Exception as exc:
        Logger.warn('Could not store performance metric: {}'.format(exc))
    return row


def portal_cache_inventory():
    """Return cache sizes and age without triggering portal requests."""
    from .xmltv import _xmltv_dict_path, _xmltv_source_dict_path, _diagnostics_path
    paths = {
        'portal_catalog': local_tv_catalog_path(),
        'portal_groups': local_tv_groups_path(),
        'local_lists': local_tv_lists_path(),
        'xmltv_portal': _xmltv_dict_path(),
        'xmltv_source': _xmltv_source_dict_path(),
        'xmltv_diagnostics': _diagnostics_path(),
    }
    result = {name: file_info(path) for name, path in paths.items()}
    result['total_size'] = sum(item.get('size', 0) for item in result.values() if isinstance(item, dict))
    return result


def clear_portal_cache(include_xmltv=False, all_portals=True):
    """Clear persistent portal indexes; optionally include XMLTV caches."""
    from . import portal_index
    started = time.time()
    ok = portal_index.invalidate_index(all_entries=bool(all_portals))
    groups = local_tv_groups_path()
    try:
        if groups and os.path.exists(groups):
            os.remove(groups)
    except Exception:
        ok = False
    if include_xmltv:
        try:
            from .xmltv import clear_xmltv_cache
            clear_xmltv_cache()
        except Exception:
            ok = False
    record_performance('clear_portal_cache', started, success=bool(ok), include_xmltv=bool(include_xmltv))
    return ok


def create_diagnostic_report():
    """Write a privacy-conscious JSON report into the add-on profile."""
    started = time.time()
    snap = diagnostic_snapshot()
    portal_url = getattr(G.portal_config, 'portal_url', '') or ''
    if portal_url:
        portal_url = portal_url.split('?', 1)[0].rstrip('/')
    payload = {
        'format': 'titan-system-diagnostic-v1',
        'created': datetime.now().isoformat(timespec='seconds'),
        'addon_version': '1.7.1',
        'python': sys.version.split()[0],
        'platform': platform.platform(),
        'portal_host': portal_url,
        'snapshot': snap,
        'cache': portal_cache_inventory(),
    }
    path = profile_file(DIAGNOSTIC_REPORT_FILE)
    _write(path, payload)
    record_performance('create_diagnostic_report', started, bytes=os.path.getsize(path) if os.path.exists(path) else 0)
    return path
