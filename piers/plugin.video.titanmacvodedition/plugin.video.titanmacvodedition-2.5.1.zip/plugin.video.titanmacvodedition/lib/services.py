"""Stable service façades for cross-module add-on operations.

The services keep high-level controller modules independent from concrete
storage, portal-index and live-TV helper implementations. Imports for the
heavier portal and favourites modules are intentionally delayed until a method
is called, reducing import-time coupling without changing the public API.
"""
from __future__ import absolute_import, unicode_literals

from .live_epg import (
    compact_now_label,
    extract_now_next,
    next_label2,
    now_label2,
    resolve_channel_ids,
    strip_kodi_markup,
)
from .live_items import (
    create_live_channel_item,
    numbered_channel_label,
    resolve_channel_logo,
)


class ChannelService:
    """Skin-neutral channel labels, EPG formatting and ListItem creation.

    These methods deliberately forward ``*args`` and ``**kwargs`` unchanged.
    The service layer is therefore a compatibility boundary rather than a
    second, narrower API that can accidentally reject optional parameters
    supported by the underlying helper functions.
    """

    @staticmethod
    def compact_now_label(*args, **kwargs):
        return compact_now_label(*args, **kwargs)

    @staticmethod
    def extract_now_next(*args, **kwargs):
        return extract_now_next(*args, **kwargs)

    @staticmethod
    def next_label2(*args, **kwargs):
        return next_label2(*args, **kwargs)

    @staticmethod
    def now_label2(*args, **kwargs):
        return now_label2(*args, **kwargs)

    @staticmethod
    def resolve_channel_ids(*args, **kwargs):
        return resolve_channel_ids(*args, **kwargs)

    @staticmethod
    def strip_kodi_markup(*args, **kwargs):
        return strip_kodi_markup(*args, **kwargs)

    @staticmethod
    def create_live_channel_item(*args, **kwargs):
        return create_live_channel_item(*args, **kwargs)

    @staticmethod
    def numbered_channel_label(*args, **kwargs):
        return numbered_channel_label(*args, **kwargs)

    @staticmethod
    def resolve_channel_logo(*args, **kwargs):
        return resolve_channel_logo(*args, **kwargs)


class FavoriteService:
    """Lazy façade over local TV lists and favourite mappings."""

    @staticmethod
    def _module():
        from . import local_tv_lists
        return local_tv_lists

    def __getattr__(self, name):
        return getattr(self._module(), name)


class PortalService:
    """Lazy façade over the portal catalogue/index implementation."""

    @staticmethod
    def _module():
        from . import portal_index
        return portal_index

    def __getattr__(self, name):
        return getattr(self._module(), name)


channel_service = ChannelService()
favorite_service = FavoriteService()
portal_service = PortalService()
