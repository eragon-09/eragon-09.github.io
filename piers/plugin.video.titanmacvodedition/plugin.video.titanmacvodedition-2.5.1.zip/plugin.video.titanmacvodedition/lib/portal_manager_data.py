# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

"""Portal persistence, parsing and schema migration helpers."""
import datetime
import json
import os
import re
from urllib.parse import urlparse

import xbmc
import xbmcvfs

from .constants import PORTAL_SCHEMA_VERSION
from .portal_schema import migrate_portal_record
from .loggers import Logger

ADDON_ID = 'plugin.video.titanmacvodedition'
DATA_DIR = 'special://profile/addon_data/{}/portals'.format(ADDON_ID)
STATE_PATH = 'special://profile/addon_data/{}/portal_manager_state.json'.format(ADDON_ID)
LEGACY_DIRS = [
    'special://profile/addon_data/script.portal.mac.converter/2_JSON_Export',
    'special://userdata/addon_data/script.portal.mac.converter/2_JSON_Export',
]
URL_RE = re.compile(r'(https?://[^\s\]\)\}\>"\']+)', re.I)
MAC_RE = re.compile(r'([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})')
DATE_ISO_RE = re.compile(r'(?<!\d)(\d{4})[./-](\d{1,2})[./-](\d{1,2})(?!\d)')
DATE_NUM_RE = re.compile(r'(?<!\d)(\d{1,2})[./-](\d{1,2})[./-](\d{4})(?!\d)')
EXPIRY_LABEL_RE = re.compile(r'exp(?:ire|iry|iration)?|ablauf(?:datum)?|gueltig(?:keit)?|gültig(?:keit)?|valid(?:ity)?|datum|bis', re.I)
DATE_EN_RE = re.compile(r'(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(\d{1,2}),\s+(\d{4})', re.I)
MONTHS = {'jan':1,'feb':2,'mar':3,'apr':4,'may':5,'jun':6,'jul':7,'aug':8,'sep':9,'oct':10,'nov':11,'dec':12}

def _log(msg, level=xbmc.LOGINFO):
    """Route portal-manager messages through the shared logger."""
    if level == xbmc.LOGERROR:
        Logger.error(msg)
    elif level == xbmc.LOGWARNING:
        Logger.warn(msg)
    elif level == xbmc.LOGDEBUG:
        Logger.debug(msg)
    else:
        Logger.debug(msg)

def _ensure_dir(path=DATA_DIR):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

def _read(path):
    f = xbmcvfs.File(path, 'r')
    data = f.read()
    f.close()
    if isinstance(data, bytes):
        data = data.decode('utf-8', 'ignore')
    return data

def _write(path, text):
    parent = os.path.dirname(xbmcvfs.translatePath(path))
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    f = xbmcvfs.File(path, 'w')
    f.write(text)
    f.close()

def normalize_portal_url(url):
    """Normalize a scanner URL without losing the portal endpoint hint.

    ``/c`` is significant for many MAG portals: the legacy code uses it to
    select ``/server/load.php`` instead of ``/stalker_portal/server/load.php``.
    Direct ``portal.php``/``load.php`` URLs are preserved as well.
    """
    url = (url or '').strip().rstrip('.,;')
    if not url:
        return ''
    if not re.match(r'^https?://', url, re.I):
        url = 'http://' + url
    p = urlparse(url)
    if not p.hostname:
        return ''
    netloc = p.hostname
    if p.port:
        netloc += ':{}'.format(p.port)
    base = '{}://{}'.format(p.scheme or 'http', netloc)
    path = re.sub(r'/+', '/', p.path or '').rstrip('/')
    low = path.lower()
    if low.endswith('/c'):
        return base + '/c'
    if low.endswith('/portal.php') or low.endswith('/server/load.php') or low.endswith('/load.php'):
        return base + path
    return base

def _portal_id(url):
    p = urlparse(url)
    raw = '{}{}'.format(p.hostname or 'portal', '_{}'.format(p.port) if p.port else '')
    return re.sub(r'[^a-zA-Z0-9._-]+', '_', raw).strip('_').lower()

def _parse_date(line):
    # Scanner exports commonly use ISO dates (YYYY-MM-DD).  Parse those first
    # so they are not mistaken for a day-first date.
    m = DATE_ISO_RE.search(line or '')
    if m:
        try:
            return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
        except ValueError:
            pass
    m = DATE_NUM_RE.search(line or '')
    if m:
        try:
            return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat()
        except ValueError:
            pass
    m = DATE_EN_RE.search(line or '')
    if m:
        try:
            return datetime.date(int(m.group(3)), MONTHS[m.group(1).lower()[:3]], int(m.group(2))).isoformat()
        except (ValueError, KeyError):
            pass
    return ''

def _extract_exp(lines, index):
    # A date on the MAC line itself is unambiguous and must be accepted even
    # when the export does not include an English 'expiry' label.
    current = lines[index] if 0 <= index < len(lines) else ''
    exp = _parse_date(current)
    if exp:
        return exp

    # For surrounding lines require an expiry-like label.  This supports both
    # English and German scanner exports while avoiding unrelated dates from
    # neighbouring records.
    nearby = lines[index + 1:index + 7] + lines[max(0, index - 3):index]
    for line in nearby:
        if EXPIRY_LABEL_RE.search(line or ''):
            exp = _parse_date(line)
            if exp:
                return exp
    return ''

def _candidate_portal_from_line(line):
    """Return a normalized portal URL from common scanner labels or a bare URL."""
    low = (line or '').lower()
    preferred = ('portal url', 'portal:', 'panel', 'host', 'server', 'real url', 'url:')
    match = URL_RE.search(line or '')
    if match and (any(k in low for k in preferred) or low.strip().startswith(('http://', 'https://'))):
        return normalize_portal_url(match.group(1))
    return ''

def parse_txt_multi(content, source_file=''):
    """Parse one scanner export and return one record per detected portal.

    Portal/MAC associations are block based: a newly detected portal starts a new
    block and subsequent MACs belong to it until another portal appears.
    """
    lines = (content or '').replace('\x00', '').splitlines()
    blocks = {}
    current = ''
    fallback_urls = [normalize_portal_url(u) for u in URL_RE.findall(content or '')]
    fallback_urls = [u for u in fallback_urls if u]

    for i, line in enumerate(lines):
        portal = _candidate_portal_from_line(line)
        if portal:
            current = portal
            blocks.setdefault(current, [])
        macs = MAC_RE.findall(line)
        if not macs:
            continue
        if not current and fallback_urls:
            current = fallback_urls[0]
            blocks.setdefault(current, [])
        if not current:
            continue
        exp = _extract_exp(lines, i)
        for mac in macs:
            blocks[current].append({'mac': mac.upper(), 'exp': exp})

    # Some exports mention the portal only once outside the hit blocks.
    if not blocks and fallback_urls:
        current = fallback_urls[0]
        entries = []
        for i, line in enumerate(lines):
            for mac in MAC_RE.findall(line):
                entries.append({'mac': mac.upper(), 'exp': _extract_exp(lines, i)})
        if entries:
            blocks[current] = entries

    result = []
    now = datetime.datetime.now().replace(microsecond=0).isoformat()
    for portal_url, entries in blocks.items():
        by_mac = {}
        for item in entries:
            mac = item.get('mac', '').upper()
            if not mac:
                continue
            old = by_mac.get(mac, {'mac': mac, 'exp': ''})
            if item.get('exp'):
                old['exp'] = item['exp']
            by_mac[mac] = old
        if not by_mac:
            continue
        result.append({
            'schema': PORTAL_SCHEMA_VERSION,
            'portal': portal_url,
            'name': urlparse(portal_url).hostname or portal_url,
            'source_files': [os.path.basename(source_file or '')] if source_file else [],
            'last_import': now,
            'active_mac': '',
            'auto_mac': True,
            'macs': list(by_mac.values()),
        })
    if not result:
        if not fallback_urls:
            raise ValueError('Keine Portal-URL erkannt')
        raise ValueError('Keine MAC-Adresse erkannt')
    return result

def parse_txt(content, source_file=''):
    """Compatibility wrapper for callers expecting exactly one portal."""
    return parse_txt_multi(content, source_file)[0]

def _merge(existing, incoming):
    """Merge a TXT import without destroying previously known MAC metadata.

    Scanner exports do not always contain an expiry date on every run.  A
    missing/invalid incoming value therefore means "no new information", not
    "delete the old date".  Existing auxiliary fields are preserved as well.
    """
    by_mac = {}
    for entry in existing.get('macs', []):
        if not isinstance(entry, dict):
            continue
        mac = str(entry.get('mac', '')).upper()
        if mac:
            saved = dict(entry)
            saved['mac'] = mac
            by_mac[mac] = saved

    for item in incoming.get('macs', []):
        if not isinstance(item, dict):
            continue
        mac = str(item.get('mac', '')).upper()
        if not mac:
            continue

        previous = by_mac.get(mac, {})
        merged = dict(previous)
        merged.update({k: v for k, v in item.items()
                       if k not in ('mac', 'exp', '_expiry_state')})
        merged['mac'] = mac

        new_exp = str(item.get('exp') or '').strip()
        old_exp = str(previous.get('exp') or '').strip()
        if new_exp:
            merged['exp'] = new_exp
            # The state is derived again when loading. Never retain a stale
            # state when the date itself changed.
            merged.pop('_expiry_state', None)
            if new_exp != old_exp:
                _log('[MAC Import] Ablaufdatum aktualisiert: {} -> {}'.format(mac, new_exp))
        elif old_exp:
            merged['exp'] = old_exp
            merged.pop('_expiry_state', None)
            _log('[MAC Import] Kein neues Datum; vorhandenes Datum beibehalten: {} ({})'.format(mac, old_exp))
        else:
            merged['exp'] = ''
            merged.pop('_expiry_state', None)

        by_mac[mac] = merged

    result = dict(existing)
    result.update({k: v for k, v in incoming.items()
                   if k not in ('macs', 'active_mac', 'auto_mac')})
    result['macs'] = list(by_mac.values())

    files = []
    sources = ((existing.get('source_files') or
                ([existing.get('source_file')] if existing.get('source_file') else [])) +
               (incoming.get('source_files') or []))
    for src in sources:
        if src and src not in files:
            files.append(src)
    result['source_files'] = files
    result.pop('source_file', None)
    result['active_mac'] = existing.get('active_mac', '')
    result['auto_mac'] = existing.get('auto_mac', True)
    return result



def _clean_portal_for_storage(portal):
    clean = {k: v for k, v in dict(portal or {}).items() if not k.startswith('_')}
    macs = []
    for entry in clean.get('macs', []) or []:
        if isinstance(entry, dict):
            macs.append({k: v for k, v in entry.items() if not k.startswith('_')})
        else:
            macs.append(entry)
    clean['macs'] = macs
    return clean

def _write_json_atomic(path, data):
    """Validate and atomically replace a portal JSON file when possible."""
    text = json.dumps(data, indent=2, ensure_ascii=False)
    # Validate the exact payload before touching the existing file.
    json.loads(text)

    local_path = xbmcvfs.translatePath(path) or path
    parent = os.path.dirname(local_path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    temp_path = local_path + '.tmp'
    try:
        with open(temp_path, 'w', encoding='utf-8', newline='\n') as handle:
            handle.write(text)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        # Re-read the temporary file before replacement to catch truncated or
        # otherwise invalid writes.
        with open(temp_path, 'r', encoding='utf-8') as handle:
            json.load(handle)
        os.replace(temp_path, local_path)
    except Exception:
        try:
            if os.path.exists(temp_path):
                os.remove(temp_path)
        except Exception:
            pass
        # Keep compatibility with non-local VFS paths.
        _write(path, text)


def save_portal(data):
    _ensure_dir()
    data, _changed = migrate_portal_record(data, normalize_portal_url)
    path = '{}/{}.json'.format(DATA_DIR, _portal_id(data.get('portal', '')))
    old_data = None
    if xbmcvfs.exists(path):
        try:
            old_data = json.loads(_read(path))
            data = _merge(old_data, data)
        except Exception as exc:
            _log('Bestehende Portaldatei konnte nicht zusammengeführt werden: {}'.format(exc), xbmc.LOGWARNING)

    if old_data == data:
        _log('[MAC Import] Portaldatei unverändert: {}'.format(os.path.basename(path)))
        return path, data

    _write_json_atomic(path, _clean_portal_for_storage(data))
    _log('[MAC Import] Portaldatei sicher gespeichert: {}'.format(os.path.basename(path)))
    return path, data

def load_portals(import_legacy=True):
    from .portal_manager_status import _mac_exp, days_left
    _ensure_dir()
    if import_legacy:
        _import_legacy_once()
    _dirs, files = xbmcvfs.listdir(DATA_DIR)
    out = []
    for fn in sorted(files):
        if not fn.lower().endswith('.json'):
            continue
        path = DATA_DIR + '/' + fn
        try:
            _log('[MAC Import] Portaldatei geladen: {}'.format(xbmcvfs.translatePath(path) or path))
            raw = json.loads(_read(path))
            data, migrated = migrate_portal_record(raw, normalize_portal_url)
            data['_path'] = path
            for item in data.get('macs', []):
                item['exp'] = _mac_exp(item)
                d = days_left(item['exp'])
                item['_expiry_state'] = 'unknown' if d is None else ('expired' if d < 0 else 'valid')
            out.append(data)
            if migrated:
                persisted = dict(data)
                persisted.pop('_path', None)
                for item in persisted.get('macs', []):
                    item.pop('_expiry_state', None)
                _write(path, json.dumps(persisted, indent=2, ensure_ascii=False))
                _log('Portaldatei automatisch auf Schema {} migriert: {}'.format(PORTAL_SCHEMA_VERSION, fn))
        except Exception as exc:
            _log('Portal JSON übersprungen {}: {}'.format(fn, exc), xbmc.LOGWARNING)

    # Version 2.3.3 initializes the automatic MAC mode exactly once. This
    # migration also fixes installations where the former default ``Aus`` was
    # already persisted. Later manual user changes are preserved because the
    # marker prevents this block from running again.
    state = _load_state()
    if not state.get('auto_mac_defaults_v1_initialized'):
        changed = 0
        for data in out:
            if not data.get('auto_mac', False):
                data['auto_mac'] = True
                persisted = dict(data)
                path = persisted.pop('_path', '')
                for item in persisted.get('macs', []):
                    item.pop('_expiry_state', None)
                if path:
                    _write(path, json.dumps(persisted, indent=2, ensure_ascii=False))
                    changed += 1
        state['auto_switch_days'] = 10
        state['auto_mac_defaults_v1_initialized'] = True
        _save_state(state)
        _log('Automatische beste MAC einmalig für {} Portal(e) aktiviert; Schwelle: 10 Tage'.format(changed))

    return out

def _import_legacy_once():
    state = _load_state()
    if state.get('legacy_import_done'):
        return
    imported = 0
    for directory in LEGACY_DIRS:
        if not xbmcvfs.exists(directory):
            continue
        _dirs, files = xbmcvfs.listdir(directory)
        for fn in files:
            if not fn.lower().endswith('.json'):
                continue
            try:
                old = json.loads(_read(directory + '/' + fn))
                data = {
                    'schema': PORTAL_SCHEMA_VERSION, 'portal': normalize_portal_url(old.get('portal', '')),
                    'name': urlparse(normalize_portal_url(old.get('portal', ''))).hostname or fn[:-5],
                    'source_file': fn, 'last_import': datetime.datetime.now().replace(microsecond=0).isoformat(),
                    'active_mac': '', 'auto_mac': True,
                    'macs': [{'mac': str(m.get('mac','')).upper(), 'exp': m.get('exp') or ''} if isinstance(m, dict) else {'mac': str(m).upper(), 'exp': ''} for m in old.get('macs', [])],
                }
                if data['portal'] and data['macs']:
                    save_portal(data); imported += 1
            except Exception:
                continue
    state['legacy_import_done'] = True
    _save_state(state)
    if imported:
        _log('{} vorhandene Converter-Portale übernommen'.format(imported))

def _load_state():
    try:
        return json.loads(_read(STATE_PATH)) if xbmcvfs.exists(STATE_PATH) else {}
    except Exception:
        return {}

def _save_state(state):
    _write(STATE_PATH, json.dumps(state, indent=2, ensure_ascii=False))

