from __future__ import absolute_import, unicode_literals

import os
import re
import json

import xbmcgui
import xbmcvfs

from .file_utils import atomic_write_json, read_json
from .kodi_paths import addon_path, profile_path, data_resource_path
try:
    import xbmcaddon
except Exception:
    xbmcaddon = None


_ACTION_CANCEL = {9, 10, 13, 92, 216, 247, 257}
_ACTION_CONTEXT = {101, 117}
_COUNTRY_TOKEN_RE = re.compile(r'(?<![A-Z0-9])([A-Z]{2})(?![A-Z0-9])', re.I)
_EMOJI_RE = re.compile('[\U0001F1E6-\U0001F1FF]+')
_HISTORY_LIMIT = 20


def _addon_path():
    return addon_path()


def _profile_path(filename):
    return profile_path(filename)


def _read_json(filename, default):
    return read_json(_profile_path(filename), default)


def _write_json(filename, value):
    return atomic_write_json(_profile_path(filename), value, prefix='.search_')


def _load_aliases():
    path = data_resource_path('flag_aliases.json')
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return {str(k).casefold(): str(v).lower() for k, v in data.items()}
    except Exception:
        return {}


_ALIASES = _load_aliases()


def _normalise_text(value):
    text = _EMOJI_RE.sub(' ', str(value or ''))
    text = re.sub(r'[\[\]{}()|:;,_/\\·•★✶*+\-]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


def resolve_country(item):
    """Return (ISO code, display code) using group names before channel names."""
    parts = list(item.get('group_titles') or [])
    parts.extend([item.get('group_title', ''), item.get('category', ''), item.get('name', '')])
    for part in parts:
        clean = _normalise_text(part)
        for token in clean.split():
            code = _ALIASES.get(token.casefold())
            if code and code != 'default':
                return code, code.upper()
        match = _COUNTRY_TOKEN_RE.search(clean)
        if match:
            token = match.group(1).casefold()
            code = _ALIASES.get(token, token)
            flag = os.path.join(_addon_path(), 'resources', 'media', 'flags', code + '.png')
            if os.path.exists(flag):
                return code, code.upper()
    return 'default', '--'


def clean_group_details(item, country_code):
    """Return a short category label suitable for a single Kodi-style row."""
    groups = list(item.get('group_titles') or [])[:2]
    if not groups:
        groups = [item.get('group_title', ''), item.get('category', '')]
    text = ' / '.join(str(value or '') for value in groups if value)
    text = _EMOJI_RE.sub(' ', text)
    text = re.sub(r'24\s*/\s*7', ' ', text, flags=re.I)
    text = re.sub(r'(?<![A-Z0-9])(8K|4K|UHD|FHD|HD|SD|HEVC)(?![A-Z0-9])', ' ', text, flags=re.I)
    text = re.sub(r'[^\wÄÖÜäöüß/&+ -]+', ' ', text, flags=re.UNICODE)

    ignored = {
        'DE', 'AT', 'CH', 'GERMANY', 'DEUTSCHLAND', 'AUSTRIA', 'ÖSTERREICH',
        'SWISS', 'SCHWEIZ', 'SUISSE', 'SVIZZERA', 'TV', 'GRUPPE', 'GROUP',
    }
    if country_code and country_code != '--':
        ignored.add(country_code.upper())

    tokens = []
    for token in re.split(r'\s+', text.strip()):
        clean = token.strip(' -_/&+')
        if not clean:
            continue
        if clean.upper() in ignored:
            continue
        alias = _ALIASES.get(clean.casefold())
        if alias and country_code and alias.upper() == country_code.upper():
            continue
        tokens.append(clean)

    result = ' '.join(tokens)
    result = re.sub(r'\s+', ' ', result).strip(' -_/&+')
    return result[:28]


def _favorite_key(item):
    channel_id = str(item.get('id') or item.get('channel_id') or item.get('ch_id') or '').strip()
    command = str(item.get('cmd') or '').strip()
    name = str(item.get('name') or '').strip().casefold()
    if channel_id:
        return 'id:' + channel_id
    if command:
        return 'cmd:' + command
    return 'name:' + name


def _load_favorites():
    value = _read_json('channel_search_favorites.json', [])
    return set(str(item) for item in value if item) if isinstance(value, list) else set()


def _save_favorites(values):
    _write_json('channel_search_favorites.json', sorted(values))


def remember_search_query(query):
    query = str(query or '').strip()
    if not query:
        return
    history = _read_json('channel_search_history.json', [])
    history = [str(item).strip() for item in history if str(item).strip()] if isinstance(history, list) else []
    history = [item for item in history if item.casefold() != query.casefold()]
    history.insert(0, query)
    _write_json('channel_search_history.json', history[:_HISTORY_LIMIT])


def prompt_search_query(default_text=''):
    """Show recent searches when available and return a query string."""
    history = _read_json('channel_search_history.json', [])
    history = [str(item).strip() for item in history if str(item).strip()] if isinstance(history, list) else []
    if history:
        labels = ['[B]Neue Suche eingeben[/B]'] + history[:_HISTORY_LIMIT]
        selected = xbmcgui.Dialog().select('Sender suchen – Verlauf', labels)
        if selected < 0:
            return ''
        if selected > 0:
            query = history[selected - 1]
            remember_search_query(query)
            return query
    query = xbmcgui.Dialog().input('Sender suchen', defaultt=default_text, type=xbmcgui.INPUT_ALPHANUM)
    query = str(query or '').strip()
    remember_search_query(query)
    return query


class ChannelSearchDialog(xbmcgui.WindowXMLDialog):
    def __new__(cls, *args, **kwargs):
        return super(ChannelSearchDialog, cls).__new__(cls, *args)

    def __init__(self, *args, **kwargs):
        self.heading = kwargs.get('heading', 'Sender auswählen')
        self.rows = kwargs.get('rows') or []
        self.selected_index = -1
        self.quality_filter = 'ALL'
        self.country_filter = ''
        self.favorites_only = False
        self.favorites = _load_favorites()
        self.visible_rows = []

    def onInit(self):
        try:
            self._refresh()
        except Exception:
            self.close()

    def _matches_quality(self, quality):
        quality = str(quality or 'SD').upper()
        if self.quality_filter == 'ALL':
            return True
        if self.quality_filter == 'HD+':
            return quality not in ('SD', '')
        return quality in ('UHD', '4K', '8K')

    def _refresh(self, preferred_key=''):
        control = self.getControl(300)
        try:
            control.reset()
        except Exception:
            pass
        rows = []
        for row in self.rows:
            is_favorite = row.get('favorite_key') in self.favorites
            if self.favorites_only and not is_favorite:
                continue
            if self.country_filter and row.get('country') != self.country_filter:
                continue
            if not self._matches_quality(row.get('quality')):
                continue
            copied = dict(row)
            copied['is_favorite'] = is_favorite
            rows.append(copied)
        rows.sort(key=lambda row: (0 if row.get('is_favorite') else 1, row.get('source_index', 0)))
        self.visible_rows = rows

        items = []
        selected_position = 0
        for pos, row in enumerate(rows):
            item = xbmcgui.ListItem(label=row.get('channel_name', ''))
            for key in ('channel_name', 'quality', 'country', 'category', 'portal_id', 'flag', 'artwork'):
                item.setProperty(key, str(row.get(key, '') or ''))
            item.setProperty('favorite', '★' if row.get('is_favorite') else '')
            item.setProperty('quality_sd', 'true' if str(row.get('quality')).upper() == 'SD' else '')
            item.setProperty('quality_hd', 'true' if str(row.get('quality')).upper() in ('HD', 'HEVC') else '')
            item.setProperty('quality_fhd', 'true' if str(row.get('quality')).upper() == 'FHD' else '')
            item.setProperty('quality_uhd', 'true' if str(row.get('quality')).upper() in ('UHD', '4K', '8K') else '')
            items.append(item)
            if preferred_key and row.get('favorite_key') == preferred_key:
                selected_position = pos
        control.addItems(items)
        if items:
            control.selectItem(min(selected_position, len(items) - 1))
            try:
                self.setFocus(control)
            except Exception:
                pass

        filter_parts = []
        if self.quality_filter != 'ALL':
            filter_parts.append(self.quality_filter)
        if self.country_filter:
            filter_parts.append(self.country_filter)
        if self.favorites_only:
            filter_parts.append('Favoriten')
        suffix = ' • Filter: ' + ', '.join(filter_parts) if filter_parts else ''
        self.getControl(100).setLabel('{} ({}/{}){}'.format(
            self.heading, len(rows), len(self.rows), suffix
        ))

    def _current_row(self):
        try:
            pos = self.getControl(300).getSelectedPosition()
            return self.visible_rows[pos] if 0 <= pos < len(self.visible_rows) else None
        except Exception:
            return None

    def _show_options(self):
        row = self._current_row()
        favorite_label = 'Suchfavorit entfernen' if row and row.get('favorite_key') in self.favorites else 'Als Suchfavorit markieren'
        labels = [
            'Qualitätsfilter: {}'.format(self.quality_filter),
            'Länderfilter: {}'.format(self.country_filter or 'Alle'),
            'Nur Suchfavoriten: {}'.format('Ein' if self.favorites_only else 'Aus'),
            favorite_label,
            'Alle Filter zurücksetzen',
        ]
        selected = xbmcgui.Dialog().select('Treffer filtern', labels)
        if selected < 0:
            return
        preferred = row.get('favorite_key') if row else ''
        if selected == 0:
            choices = ['Alle', 'HD und besser', 'Nur UHD/4K/8K']
            value = xbmcgui.Dialog().select('Qualität', choices)
            if value >= 0:
                self.quality_filter = ('ALL', 'HD+', 'UHD')[value]
        elif selected == 1:
            countries = sorted(set(item.get('country') for item in self.rows if item.get('country') and item.get('country') != '--'))
            value = xbmcgui.Dialog().select('Land', ['Alle'] + countries)
            if value >= 0:
                self.country_filter = '' if value == 0 else countries[value - 1]
        elif selected == 2:
            self.favorites_only = not self.favorites_only
        elif selected == 3 and row:
            key = row.get('favorite_key')
            if key in self.favorites:
                self.favorites.remove(key)
            else:
                self.favorites.add(key)
            _save_favorites(self.favorites)
        elif selected == 4:
            self.quality_filter = 'ALL'
            self.country_filter = ''
            self.favorites_only = False
        self._refresh(preferred)

    def onClick(self, control_id):
        if control_id == 300:
            row = self._current_row()
            self.selected_index = row.get('source_index', -1) if row else -1
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = -1
        if action_id in _ACTION_CONTEXT:
            self._show_options()
            return
        if action_id in _ACTION_CANCEL:
            self.selected_index = -1
            self.close()



def _preferred_artwork(item, flag):
    """Prefer a channel logo and fall back to the resolved country flag."""
    for key in ('logo', 'logo_url', 'icon', 'icon_url', 'thumb'):
        value = str(item.get(key) or '').strip()
        if value and value.lower() not in ('null', 'none', '0'):
            return value
    return flag

def select_channel_result(heading, results, clean_name_func, quality_func):
    addon_path = _addon_path()
    favorites = _load_favorites()
    rows = []
    for source_index, item in enumerate(results):
        name = clean_name_func(item.get('name', '')) or item.get('name', '')
        quality = quality_func(item.get('name', '')) or 'SD'
        iso_code, display_code = resolve_country(item)
        flag = os.path.join(addon_path, 'resources', 'media', 'flags', iso_code + '.png')
        if not os.path.exists(flag):
            flag = os.path.join(addon_path, 'resources', 'media', 'flags', 'default.png')
        category = clean_group_details(item, display_code)
        portal_id = str(item.get('id')) if item.get('id') not in (None, '') else ''
        favorite_key = _favorite_key(item)
        artwork = _preferred_artwork(item, flag)
        rows.append({
            'source_index': source_index,
            'channel_name': name,
            'quality': quality,
            'country': display_code,
            'category': category,
            'portal_id': portal_id,
            'flag': flag,
            'artwork': artwork,
            'favorite_key': favorite_key,
            'is_favorite': favorite_key in favorites,
        })

    try:
        dialog = ChannelSearchDialog(
            'ChannelSearchDialog.xml', addon_path, 'Default', '1080i',
            heading=heading, rows=rows,
        )
        dialog.doModal()
        selected = dialog.selected_index
        del dialog
        return selected
    except Exception:
        ordered = sorted(rows, key=lambda row: (0 if row.get('is_favorite') else 1, row.get('source_index', 0)))
        labels = ['{}{}    {}    {}    {}    {}'.format(
            '★ ' if row.get('is_favorite') else '', row.get('channel_name', ''), row.get('quality', ''),
            row.get('country', ''), row.get('category', ''),
            'ID ' + row.get('portal_id', '') if row.get('portal_id') else ''
        ).strip() for row in ordered]
        selected = xbmcgui.Dialog().select(heading, labels)
        return ordered[selected].get('source_index', -1) if 0 <= selected < len(ordered) else -1
