"""Persistent SQLite search index for large portal channel catalogues.

The index is deliberately optional: every public function fails open and lets
callers continue with the normal in-memory search when SQLite is unavailable.
"""
from __future__ import absolute_import, unicode_literals

import hashlib
import json
import os
import re
import sqlite3
import unicodedata

try:
    import xbmcaddon
    import xbmcvfs
except Exception:
    xbmcaddon = None
    xbmcvfs = None

_SCHEMA_VERSION = 1
_TOKEN_RE = re.compile(r"[a-z0-9äöüß]+", re.I)


def _profile_dir():
    try:
        path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    except Exception:
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'profile')
    os.makedirs(path, exist_ok=True)
    return path


def _db_path():
    return os.path.join(_profile_dir(), 'channel_search_index.db')


def _fold(value):
    value = unicodedata.normalize('NFKD', str(value or ''))
    value = ''.join(ch for ch in value if not unicodedata.combining(ch))
    value = value.casefold().replace('ß', 'ss')
    return ' '.join(_TOKEN_RE.findall(value))


def _payload_key(item):
    channel_id = str(item.get('id') or item.get('channel_id') or item.get('ch_id') or '').strip()
    command = str(item.get('cmd') or '').strip()
    if channel_id:
        return 'id:' + channel_id
    if command:
        return 'cmd:' + command
    return 'name:' + _fold(item.get('name'))


def _catalog_signature(channels, scope):
    digest = hashlib.sha1()
    digest.update(str(scope or '').encode('utf-8'))
    digest.update(str(len(channels or [])).encode('ascii'))
    for item in channels or []:
        digest.update(_payload_key(item).encode('utf-8', 'ignore'))
        digest.update(str(item.get('name') or '').encode('utf-8', 'ignore'))
        digest.update(b'\0')
    return digest.hexdigest()


def _search_text(item):
    values = [item.get('name', ''), item.get('category_name', ''), item.get('group_title', '')]
    values.extend(item.get('group_titles') or [])
    values.extend(item.get('aliases') or [])
    return _fold(' '.join(str(v or '') for v in values))


def _connect():
    connection = sqlite3.connect(_db_path(), timeout=10)
    connection.execute('PRAGMA journal_mode=WAL')
    connection.execute('PRAGMA synchronous=NORMAL')
    connection.execute('CREATE TABLE IF NOT EXISTS meta (scope TEXT PRIMARY KEY, signature TEXT, schema_version INTEGER)')
    connection.execute('''CREATE TABLE IF NOT EXISTS channels (
        scope TEXT NOT NULL,
        item_key TEXT NOT NULL,
        name_fold TEXT NOT NULL,
        search_text TEXT NOT NULL,
        payload TEXT NOT NULL,
        PRIMARY KEY (scope, item_key)
    )''')
    connection.execute('CREATE INDEX IF NOT EXISTS idx_channels_scope_name ON channels(scope, name_fold)')
    connection.execute('CREATE INDEX IF NOT EXISTS idx_channels_scope_search ON channels(scope, search_text)')
    return connection


def ensure_index(channels, scope='all'):
    """Build or refresh one scope and return True when the index is usable."""
    channels = list(channels or [])
    if not channels:
        return False
    signature = _catalog_signature(channels, scope)
    try:
        con = _connect()
        row = con.execute('SELECT signature, schema_version FROM meta WHERE scope=?', (scope,)).fetchone()
        if row and row[0] == signature and int(row[1] or 0) == _SCHEMA_VERSION:
            con.close()
            return True
        rows = []
        for item in channels:
            name_fold = _fold(item.get('name'))
            if not name_fold:
                continue
            rows.append((scope, _payload_key(item), name_fold, _search_text(item),
                         json.dumps(item, ensure_ascii=False, separators=(',', ':'))))
        with con:
            con.execute('DELETE FROM channels WHERE scope=?', (scope,))
            con.executemany('INSERT OR REPLACE INTO channels(scope,item_key,name_fold,search_text,payload) VALUES(?,?,?,?,?)', rows)
            con.execute('INSERT OR REPLACE INTO meta(scope,signature,schema_version) VALUES(?,?,?)',
                        (scope, signature, _SCHEMA_VERSION))
        con.close()
        return True
    except Exception:
        return False


def search_candidates(query, channels, scope='all', limit=1200):
    """Return a persistent-index candidate subset, or ``None`` on failure.

    Every query token must occur in the searchable channel text. The caller
    performs final alias/fuzzy ranking, preserving existing behaviour.
    """
    tokens = [token for token in _fold(query).split() if token]
    if not tokens or not ensure_index(channels, scope=scope):
        return None
    try:
        con = _connect()
        clauses = ['scope=?']
        params = [scope]
        for token in tokens:
            clauses.append('search_text LIKE ?')
            params.append('%{}%'.format(token))
        sql = ('SELECT payload FROM channels WHERE ' + ' AND '.join(clauses) +
               ' ORDER BY CASE WHEN name_fold=? THEN 0 WHEN name_fold LIKE ? THEN 1 ELSE 2 END, name_fold LIMIT ?')
        folded = _fold(query)
        params.extend([folded, folded + '%', max(1, int(limit or 1200))])
        rows = con.execute(sql, params).fetchall()
        con.close()
        return [json.loads(row[0]) for row in rows]
    except Exception:
        return None


def clear():
    try:
        path = _db_path()
        if os.path.exists(path):
            os.remove(path)
        for suffix in ('-wal', '-shm'):
            if os.path.exists(path + suffix):
                os.remove(path + suffix)
        return True
    except Exception:
        return False
