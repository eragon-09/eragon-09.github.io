# -*- coding: utf-8 -*-
"""Backward-compatible facade for the modular Portal Manager implementation."""
from __future__ import absolute_import, division, unicode_literals

from . import portal_manager_data as _data
from . import portal_manager_status as _status
from . import portal_manager_import as _importer
from . import portal_manager_state as _state

for _module in (_data, _status, _importer, _state):
    for _name in dir(_module):
        if not _name.startswith('__'):
            globals()[_name] = getattr(_module, _name)

del _module, _name
