"""
Compatible with Kodi 19.x "Matrix" and above
"""
from __future__ import absolute_import, division, unicode_literals
import re
import math
from urllib.parse import parse_qsl
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
try:
    import xbmcaddon
except Exception:
    xbmcaddon = None
from .globals import G
from .utils import ask_for_input, get_int_value, ask_for_category_selection
from .country_filter import (
    get_country_tokens, filter_categories_for_country_groups,
    get_country_filter_label, get_configured_country_tokens,
)
from .api import Api
from .loggers import Logger
from .cache import runtime_cache
from .api import get_epg_data, epg_caches, epg_path, get_epg_dict, short_epg_from_dict, clear_epg_cache
from .xmltv import load_xmltv, clear_xmltv_cache, get_epg_source, get_runtime_xmltv_events
from .constants import (
    ADDON_NAME, DIALOG_NEW_GROUP, ALL_TV_GROUPS_LABEL, FILTERED_TV_GROUPS_LABEL, ICON_FAVORITES,
    LOCAL_TV_LISTS_LABEL, LOCAL_TV_LISTS_PLAIN_LABEL, TV_SEARCH_LABEL,
)
from .paths import fanart_path, media_path, local_tv_art_path
from . import local_tv_lists as local_tv
from . import maintenance
from .channel_search_dialog import select_channel_result, prompt_search_query
from .favorite_zapper import show_favorite_zapper
from .services import channel_service

# Compatibility aliases keep the controller code and its behaviour unchanged
# while routing cross-module live-TV operations through one stable service.
compact_now_label = channel_service.compact_now_label
extract_now_next = channel_service.extract_now_next
next_label2 = channel_service.next_label2
now_label2 = channel_service.now_label2
resolve_channel_ids = channel_service.resolve_channel_ids
strip_kodi_markup = channel_service.strip_kodi_markup
create_live_channel_item = channel_service.create_live_channel_item
numbered_channel_label = channel_service.numbered_channel_label
resolve_channel_logo = channel_service.resolve_channel_logo
import hashlib
import json
import time
import os


_EPG_CACHE_NAMESPACE = 'epg_runtime'
_EPG_DICTIONARY_KEY = 'merged_dictionary'


def _get_epg_dictionary(force=False):
    """Load the merged EPG dictionary once per plug-in process."""
    if force:
        runtime_cache.invalidate(_EPG_CACHE_NAMESPACE, _EPG_DICTIONARY_KEY)

    def _load():
        try:
            return get_epg_dict() or {}
        except Exception as exc:
            Logger.error('EPG dictionary could not be loaded: {}'.format(exc))
            return {}

    return runtime_cache.get_or_create(
        _EPG_CACHE_NAMESPACE, _EPG_DICTIONARY_KEY, _load)


def _reset_epg_dictionary():
    runtime_cache.invalidate(_EPG_CACHE_NAMESPACE, _EPG_DICTIONARY_KEY)


def _strip_kodi_markup(s):
    return strip_kodi_markup(s)


# ---------------------------------------------------------------------------
# Zapping context helpers
# ---------------------------------------------------------------------------

def _zap_context_path(ctx_key):
    base = getattr(G.addon_config, 'token_path', '') or ''
    if not base:
        return ''
    return os.path.join(base, 'zap_{}.json'.format(ctx_key))


def _save_zap_context(ctx_key, payload):
    try:
        path = _zap_context_path(ctx_key)
        if not path:
            return False
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(payload or {}, fh, ensure_ascii=False)
        return True
    except Exception as exc:
        Logger.error('save zap context failed: {}'.format(exc))
        return False


def _load_zap_context(ctx_key):
    try:
        path = _zap_context_path(ctx_key)
        if not path or not os.path.exists(path):
            return None
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else None
    except Exception as exc:
        Logger.error('load zap context failed: {}'.format(exc))
        return None


def _build_zap_key(params):
    raw = '|'.join([
        str(params.get('category_id', '')),
        str(params.get('category', '')),
        str(params.get('page', '1')),
        str(params.get('search_term', '')),
        str(params.get('fav', '0')),
    ])
    return hashlib.md5(raw.encode('utf-8')).hexdigest()


def _channel_payload(video, epg_text=''):
    return {
        'name': video.get('name', ''),
        'cmd': video.get('cmd', ''),
        'logo': video.get('logo', ''),
        'id': video.get('id', ''),
        'epg_id': video.get('id', ''),
        'use_http_tmp_link': video.get('use_http_tmp_link', 0),
        'use_load_balancing': video.get('use_load_balancing', 0),
        'epg_text': epg_text or '',
    }


def _remaining_minutes_from_range(start_s, end_s):
    try:
        from datetime import datetime, timedelta
        now = datetime.now()
        sh, sm = [int(x) for x in str(start_s).split(':', 1)]
        eh, em = [int(x) for x in str(end_s).split(':', 1)]
        start_dt = now.replace(hour=sh, minute=sm, second=0, microsecond=0)
        end_dt = now.replace(hour=eh, minute=em, second=0, microsecond=0)
        if end_dt <= start_dt:
            end_dt += timedelta(days=1)
        if now < start_dt:
            remaining = int((end_dt - start_dt).total_seconds() // 60)
        else:
            remaining = int((end_dt - now).total_seconds() // 60)
        return max(0, remaining)
    except Exception:
        return None


def _build_zap_label_with_now(channel_name, now_line, max_len=150):
    """Build the playlist title for the following channel.

    Keep the channel name first so the zapping list remains easy to scan:
    ``DAS ERSTE HD • Sendungstitel • 19:45 - 19:50``.
    """
    try:
        base = str(channel_name or '').strip()
        clean = _strip_kodi_markup(now_line)
        if not clean:
            return base

        import re as _re
        m = _re.match(r'^(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*:\s*(.+)$', clean)
        if not m:
            core = '{} [COLOR=gray]•[/COLOR] {}'.format(base, clean) if base else clean
            if len(_strip_kodi_markup(core)) > max_len - 1:
                core = _strip_kodi_markup(core)[:max_len - 1] + '…'
            return core

        start_s, end_s, title = m.groups()
        body = '{} [COLOR=gray]•[/COLOR] {} [COLOR=gray]•[/COLOR] [COLOR=white]{} - {}[/COLOR]'.format(
            base, title.strip(), start_s, end_s) if base else '{} [COLOR=gray]•[/COLOR] [COLOR=white]{} - {}[/COLOR]'.format(
                title.strip(), start_s, end_s)
        if len(_strip_kodi_markup(body)) > max_len - 1:
            body = _strip_kodi_markup(body)[:max_len - 1] + '…'
        return body
    except Exception:
        return str(channel_name or '')


def _epg_event_details(epgid, line=None):
    """Return dict for current and following EPG events from the cached portal EPG."""
    try:
        epg_dict = _get_epg_dictionary()
        items = epg_dict.get(str(epgid)) or epg_dict.get(int(epgid))
    except Exception:
        items = None
    if not items:
        return {'current': None, 'next': []}

    now_ts = int(time.time())

    def _to_int(v):
        try:
            return int(v)
        except Exception:
            return None

    def _parse_hhmm(s):
        s = str(s or '').strip()
        if ':' not in s:
            return None
        try:
            hh, mm = s.split(':', 1)
            return int(hh), int(mm)
        except Exception:
            return None

    def _event_bounds(ev):
        st = (_to_int(ev.get('start_timestamp')) or _to_int(ev.get('start')) or
              _to_int(ev.get('time')) or _to_int(ev.get('begin_timestamp')))
        en = (_to_int(ev.get('stop_timestamp')) or _to_int(ev.get('end_timestamp')) or
              _to_int(ev.get('end')) or _to_int(ev.get('time_to')) or
              _to_int(ev.get('end_time')) or _to_int(ev.get('finish_timestamp')))
        if st is None and ev.get('t_time'):
            parsed = _parse_hhmm(ev.get('t_time'))
            if parsed:
                hh, mm = parsed
                now = time.localtime(now_ts)
                st = int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, hh, mm, 0, 0, 0, -1)))
        if en is None and ev.get('t_time_to'):
            parsed = _parse_hhmm(ev.get('t_time_to'))
            if parsed:
                hh, mm = parsed
                now = time.localtime(now_ts)
                en = int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, hh, mm, 0, 0, 0, -1)))
                if st and en <= st:
                    en += 86400
        return st, en

    def _desc(ev):
        for key in ('descr', 'description', 'plot', 'text', 'info'):
            val = ev.get(key)
            if val:
                return str(val).strip()
        return ''

    norm = []
    for ev in items:
        if not isinstance(ev, dict):
            continue
        st, en = _event_bounds(ev)
        norm.append((st, en, ev))
    norm.sort(key=lambda x: (x[0] if x[0] is not None else 10 ** 18))

    current = None
    for st, en, ev in norm:
        if st is None:
            continue
        if en is not None and st <= now_ts < en:
            current = (st, en, ev)
            break

    if current is None and line:
        wanted = _strip_kodi_markup(line)
        for st, en, ev in norm:
            built = '{} - {}: {}'.format(ev.get('t_time') or '', ev.get('t_time_to') or '', ev.get('name') or '')
            if _strip_kodi_markup(built) == wanted:
                current = (st, en, ev)
                break

    if current is None and norm:
        current = norm[0]

    next_items = []
    seen = False
    for st, en, ev in norm:
        if current and (st, en, ev) == current:
            seen = True
            continue
        if not seen:
            continue
        next_items.append((st, en, ev))
        if len(next_items) >= 2:
            break

    def _pack(tup):
        if not tup:
            return None
        st, en, ev = tup
        return {
            'start': str(ev.get('t_time') or ''),
            'end': str(ev.get('t_time_to') or ''),
            'title': str(ev.get('name') or '').strip(),
            'desc': _desc(ev),
            'st_ts': st,
            'en_ts': en,
        }

    return {
        'current': _pack(current),
        'next': [_pack(x) for x in next_items if _pack(x)],
    }


def _highlight_epg_plot(epg_text, epgid=None):
    """Build the information panel for the highlighted TV channel.

    The panel shows the current title, airtime, remaining time and the full EPG
    synopsis.  The directly following broadcast on the same channel is shown
    below it.  Skins such as Estuary and Aeon Nox Silvo render this plot in the
    left information area while the channel list remains visible.
    """
    try:
        if not epg_text or 'Keine Informationen' in str(epg_text):
            return str(epg_text or '')
        lines = [l.strip() for l in str(epg_text).split('\n') if l.strip()]
        if not lines:
            return str(epg_text)

        details = _epg_event_details(epgid, lines[0]) if epgid else {'current': None, 'next': []}
        current = details.get('current') if isinstance(details, dict) else None
        upcoming = details.get('next') if isinstance(details, dict) else []

        if not current:
            return '[B][COLOR=yellow]JETZT[/COLOR][/B]\n{}'.format('\n'.join(lines))

        start = current.get('start', '')
        end = current.get('end', '')
        time_str = '{} - {}'.format(start, end).strip(' -') if (start or end) else ''
        rem = _remaining_minutes_from_range(start, end) if start and end else None
        if rem is not None and rem >= 0:
            time_line = '{} | noch {} min'.format(time_str, rem) if time_str else 'noch {} min'.format(rem)
        else:
            time_line = time_str

        title = current.get('title', '').strip()
        parts = ['[B][COLOR=yellow]JETZT[/COLOR][/B]']
        if title:
            parts.append('[B]{}[/B]'.format(title))
        if time_line:
            parts.append(time_line)

        description = current.get('desc', '').strip()
        if description:
            parts.append('')
            parts.append(description)

        # Only the directly following broadcast on the same channel is shown.
        if upcoming:
            ev = upcoming[0]
            ev_start = ev.get('start', '')
            ev_end = ev.get('end', '')
            ev_title = ev.get('title', '').strip()
            rng = '{} - {}'.format(ev_start, ev_end).strip(' -') if (ev_start or ev_end) else ''

            parts.append('')
            parts.append('[B][COLOR=cyan]DANACH[/COLOR][/B]')
            if ev_title:
                parts.append('[B]{}[/B]'.format(ev_title))
            if rng:
                parts.append(rng)

        return '\n'.join(parts)
    except Exception:
        return str(epg_text or '')


def _extract_now_next(epg_text):
    return extract_now_next(epg_text)


def _build_now_in_label(channel_name, now_line, max_len=90):
    """Put NOW into the main label (usually rendered larger by skin)."""
    try:
        if not now_line:
            return channel_name
        # Keep it readable; many skins truncate label anyway.
        now_clean = _strip_kodi_markup(now_line)
        combined = f"{channel_name}  [COLOR=yellow]• Jetzt:[/COLOR] {now_clean}"
        if len(combined) > max_len:
            return combined[:max_len - 1] + "…"
        return combined
    except Exception:
        return channel_name



def _build_compact_now_in_label(channel_name, now_line, max_visible=66):
    return compact_now_label(channel_name, now_line, max_visible=max_visible)


def _build_now_label2(now_line, max_len=90):
    return now_label2(now_line, max_len=max_len)


def _build_next_label2(next_line, max_len=90):
    return next_label2(next_line, max_len=max_len)


def _create_skin_neutral_live_item(label, channel_name, programme_number,
                                   now_line='', next_line='', plot_text='',
                                   logo='', fanart='', playable=True):
    """Compatibility wrapper for the centralized live item factory."""
    return create_live_channel_item(
        label=label, channel_name=channel_name,
        programme_number=programme_number, now_line=now_line,
        next_line=next_line, plot_text=plot_text, logo=logo,
        fanart=fanart, playable=playable,
    )


def _get_channel_epg_bundle(channel, epg_dict):
    """Return one shared EPG bundle for portal and local favourite lists.

    Saved favourite mappings can contain an ``epg_id`` that is absent or stale
    for the active portal, while the portal channel ``id`` still has valid EPG.
    Try every stable channel identifier and use the first one that provides
    programme data. This keeps "Meine Sender" on the same EPG path as the
    normal country/portal channel groups.
    """
    # Resolve all portal/favourite/XMLTV identifiers in one shared helper.
    candidates = resolve_channel_ids(channel)

    if not candidates:
        return '', '', '', '', ''

    fallback = None
    runtime_events = None
    for epgid in candidates:
        cache_key = str(epgid)
        if cache_key not in epg_caches:
            raw = short_epg_from_dict(epgid, epg_dict)
            if not raw or 'Keine Informationen' in str(raw):
                if runtime_events is None:
                    runtime_events = get_runtime_xmltv_events(channel)
                if runtime_events:
                    raw = short_epg_from_dict(epgid, {str(epgid): runtime_events})
            now_line, next_line = _extract_now_next(raw)
            plot = _highlight_epg_plot(raw, epgid)
            epg_caches[cache_key] = (raw, plot, now_line, next_line)

        cached = epg_caches[cache_key]
        if isinstance(cached, tuple):
            epg_text, plot_text, now_line, next_line = cached
        else:
            epg_text = cached
            now_line, next_line = _extract_now_next(epg_text)
            plot_text = _highlight_epg_plot(epg_text, epgid)

        bundle = (epgid, epg_text, plot_text, now_line, next_line)
        if fallback is None:
            fallback = bundle
        if epg_text and 'Keine Informationen' not in str(epg_text):
            return bundle

    return fallback or ('', '', '', '', '')

def _favorite_epg_channel(saved, resolved, catalog):
    """Build an EPG-rich channel record for a saved favourite.

    Playback keeps using the resolved best-quality portal record.  EPG lookup,
    however, also receives identifiers from the persisted mapping and every
    catalogue variant with the same canonical station identity.  This covers
    portals where HD/FHD duplicates use separate stream IDs but only one of
    those IDs is present in the portal EPG cache.
    """
    merged = {}
    mapping = ((saved or {}).get('mappings') or {}).get(local_tv.portal_key()) or {}
    for source in (mapping, saved or {}, resolved or {}):
        for key, value in source.items():
            if value not in (None, '', [], {}):
                merged[key] = value

    identifiers = []
    def add_identifiers(source):
        for field in ('id', 'epg_id', 'ch_id', 'channel_id', 'xmltv_id', 'tvg_id'):
            value = str((source or {}).get(field) or '').strip()
            if value and value not in identifiers:
                identifiers.append(value)

    add_identifiers(resolved)
    add_identifiers(mapping)

    wanted = set()
    for name in [merged.get('name', '')] + list((saved or {}).get('aliases') or []):
        identity = local_tv.normalize_channel_name(name)
        if identity:
            wanted.add(identity)
    for candidate in catalog or []:
        if local_tv.normalize_channel_name(candidate.get('name', '')) in wanted:
            add_identifiers(candidate)

    merged['epg_candidates'] = identifiers
    return merged


def _get_favoriten_icon():
    return media_path(ICON_FAVORITES)

def _LSTR(id):
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getLocalizedString(id)
    except Exception:
        return ''


def _finish_runplugin_action():
    """Finish a context-menu RunPlugin action without refreshing the container.

    Kodi can keep its busy spinner active until the plugin handle is explicitly
    completed. Closing both busy dialogs is harmless on skins that do not use
    them and avoids the roughly two-minute timeout seen after manual mappings.
    """
    try:
        handle = G.get_handle()
        if isinstance(handle, int) and handle >= 0:
            xbmcplugin.endOfDirectory(
                handle,
                succeeded=False,
                updateListing=False,
                cacheToDisc=False,
            )
    except Exception as exc:
        Logger.debug('RunPlugin action finalization failed: {}'.format(exc))
    for dialog_name in ('busydialognocancel', 'busydialog'):
        try:
            xbmc.executebuiltin('Dialog.Close({})'.format(dialog_name))
        except Exception:
            pass

# Export private helper names as well for the split addon modules.
__all__ = [name for name in globals() if not name.startswith('__')]
