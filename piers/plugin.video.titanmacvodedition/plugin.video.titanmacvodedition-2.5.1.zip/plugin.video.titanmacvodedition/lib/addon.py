"""Kodi add-on controller assembled from focused mixin modules."""
from __future__ import absolute_import, division, unicode_literals

from .globals import G
from . import addon_tv as _addon_tv
from . import addon_local_tv as _addon_local_tv
from . import addon_media as _addon_media
from . import addon_menu as _addon_menu
from . import addon_router as _addon_router


class StalkerAddon(
        _addon_router.StalkerAddon,
        _addon_menu.StalkerAddon,
        _addon_media.StalkerAddon,
        _addon_local_tv.StalkerAddon,
        _addon_tv.StalkerAddon):
    """Combined controller; behavior is unchanged from the monolithic class."""


# Some legacy methods call ``StalkerAddon.__method`` explicitly. Point each
# split module at the combined controller so those calls keep resolving to the
# same private names as before.
_addon_tv.StalkerAddon = StalkerAddon
_addon_local_tv.StalkerAddon = StalkerAddon
_addon_media.StalkerAddon = StalkerAddon
_addon_menu.StalkerAddon = StalkerAddon
_addon_router.StalkerAddon = StalkerAddon


def _install_menu_fanart():
    """Attach the bundled background to every Kodi directory entry.

    Entries without their own fanart receive the bundled background.
    Existing artwork is preserved.
    """
    import xbmcplugin
    from .paths import fanart_path

    fanart = fanart_path()
    original_single = xbmcplugin.addDirectoryItem
    original_batch = xbmcplugin.addDirectoryItems

    def decorate(item, folder):
        try:
            if not item.getArt('fanart'):
                item.setArt({'fanart': fanart})
        except Exception:
            # Never break Kodi navigation because of artwork.
            pass

    def add_single(handle, url, listitem, isFolder=False, *args, **kwargs):
        decorate(listitem, isFolder)
        return original_single(handle, url, listitem, isFolder, *args, **kwargs)

    def add_batch(handle, items, totalItems=0, *args, **kwargs):
        for entry in items:
            if len(entry) >= 3:
                decorate(entry[1], entry[2])
        return original_batch(handle, items, totalItems, *args, **kwargs)

    xbmcplugin.addDirectoryItem = add_single
    xbmcplugin.addDirectoryItems = add_batch


def run(argv):
    """Initialize globals and dispatch the Kodi plugin request."""
    G.init_globals()
    _install_menu_fanart()
    stalker_addon = StalkerAddon()
    stalker_addon.router(argv[2][1:])
