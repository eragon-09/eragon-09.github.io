"""Central constants used by the add-on."""

ADDON_ID = 'plugin.video.titanmacvodedition'
ADDON_NAME = 'TitanMacVOD'
LOCAL_TV_LISTS_FILENAME = 'local_tv_lists.json'
LOCAL_TV_CATALOG_FILENAME = 'local_tv_catalog.json'
LOCAL_TV_GROUPS_FILENAME = 'local_tv_groups.json'
LOCAL_TV_SCHEMA_VERSION = 1

# Portal Manager configuration. Keep schema and warning thresholds centralized so
# future migrations and UI changes do not require edits across multiple modules.
PORTAL_SCHEMA_VERSION = 3
PORTAL_WARNING_DAYS = 10
PORTAL_GOOD_DAYS = 30
PORTAL_COLOR_ACTIVE = 'lime'
PORTAL_COLOR_NORMAL = 'white'
PORTAL_COLOR_WARNING = 'yellow'
PORTAL_COLOR_EXPIRED = 'grey'
LOCAL_TV_CATALOG_TTL_SECONDS = 86400
LOCAL_TV_LISTS_LABEL = '[B][COLOR gold]MEINE SENDER[/COLOR][/B]'
LOCAL_TV_LISTS_PLAIN_LABEL = 'MEINE SENDER'
FILTERED_TV_GROUPS_LABEL = 'TV-GRUPPEN'
ALL_TV_GROUPS_LABEL = 'TV-GRUPPEN – ALLE'
LOCAL_TV_DEFAULT_GROUP_NAME = 'Meine Sender'
DIALOG_OK = 'OK'
DIALOG_CANCEL = 'Abbrechen'
TV_SEARCH_LABEL = 'TV-SUCHE'
DIALOG_NEW_GROUP = 'Neue Gruppe erstellen'
ICON_FAVORITES = 'favoriten.png'
ICON_LOCAL_TV = 'tv.png'
ICON_FOLDER = 'tv.png'
ICON_ADD = 'tv.png'
ICON_TV = 'tv.png'
FANART = 'fanart.png'
LOCAL_TV_ART_SUBDIR = 'art'
LOCAL_TV_DEFAULT_ART = 'default.png'
LOCAL_TV_ROOT_ART = 'meine_sender.png'
LOCAL_TV_TEMPLATE_SUBDIR = 'lists'
LOCAL_TV_DEFAULT_TEMPLATE = 'tv_spielfilm.txt'
LOCAL_TV_DEFAULT_TEMPLATE_NAME = 'TV Spielfilm'

# Words that do not identify a channel and should not dominate matching.
CHANNEL_NOISE_WORDS = frozenset({
    'de', 'deutschland', 'germany', 'at', 'ch', 'hd', 'fhd', 'uhd', '4k',
    'sd', 'hevc', 'h265', 'backup', 'vip', 'live', 'channel', 'tv', 'plus', 'ultra',
    'fernsehen', 'fernseh', 'fs', 'programm', 'stream', 'premium',
})


# Quality labels used only after a station name has been matched reliably.
# Higher values win. Codec/source labels are intentionally below explicit
# resolution labels because HEVC and RAW do not guarantee a specific resolution.
CHANNEL_QUALITY_RULES = (
    (500, (r'(?<![a-z0-9])(?:4k\+?|4\+|uhd|2160p?)(?![a-z0-9])',)),
    (450, (r'(?<![a-z0-9])raw(?![a-z0-9])',)),
    (400, (r'(?<![a-z0-9])(?:fhd|full[ ._-]*hd|1080p?|hd\+)(?![a-z0-9])',)),
    (350, (r'(?<![a-z0-9])(?:hevc|h[ ._-]*265|x265)(?![a-z0-9])',)),
    (300, (r'(?<![a-z0-9])(?:hd|720p?)(?![a-z0-9])',)),
    (100, (r'(?<![a-z0-9])(?:sd|576p?|480p?)(?![a-z0-9])',)),
)

CHANNEL_QUALITY_BONUSES = (
    (20, r'(?<![a-z0-9])(?:50|60)[ ._-]*(?:fps|hz)(?![a-z0-9])'),
    (10, r'(?<![a-z0-9])(?:h[ ._-]*264|x264)(?![a-z0-9])'),
)

CHANNEL_QUALITY_PENALTIES = (
    (-250, r'(?<![a-z0-9])(?:backup|reserve|ersatz)(?![a-z0-9])'),
    (-200, r'(?<![a-z0-9])(?:low|mobile|mobil)(?![a-z0-9])'),
    (-40, r'(?<![a-z0-9])(?:test)(?![a-z0-9])'),
)

CHANNEL_QUALITY_SEARCH_WORDS = frozenset({
    '4k', '4k+', '4+', 'uhd', '2160', '2160p', 'raw', 'fhd', 'fullhd',
    '1080', '1080p', 'hd+', 'hevc', 'h265', 'x265', 'hd', '720', '720p',
    'sd', '576', '576p', '480', '480p', 'h264', 'x264', '50fps', '60fps',
    '50hz', '60hz', 'backup', 'reserve', 'ersatz', 'low', 'mobile', 'mobil',
})

CHANNEL_ALIASES = {

    # TV-Spielfilm-Favoriten und verbreitete IPTV/XMLTV-Schreibweisen.
    'das erste hd': 'ard',
    'ard das erste': 'ard',
    'ard alpha': 'ardalpha',
    'br fernsehen sued': 'br',
    'br fernsehen süd': 'br',
    'swr': 'swr',
    'sr': 'sr',
    'hr fernsehen': 'hr',
    'hr-fernsehen': 'hr',
    'rtlzwei': 'rtl2',
    'rtl zwei hd': 'rtl2',
    'pro sieben': 'pro7',
    'pro sieben maxx': 'pro7maxx',
    'pro sieben fun': 'pro7fun',
    'sat1 gold': 'sat1gold',
    'sat1 emotions': 'sat1emotions',
    'kabel eins classics': 'kabeleinsclassics',
    'kabel 1 classics': 'kabeleinsclassics',
    'comedy central hd': 'comedycentral',
    'axn black': 'axnblack',
    'axn white': 'axnwhite',
    'toggo plus': 'toggoplus',
    'nick jr.': 'nickjr',
    'nick jr': 'nickjr',
    'nickjr': 'nickjr',
    'nicktoons': 'nicktoons',
    'ric': 'rictv',
    'ric tv': 'rictv',
    'fix foxi': 'fixfoxi',
    'fix and foxi': 'fixfoxi',
    'fix&foxi': 'fixfoxi',
    'fix&foxi tv': 'fixfoxi',
    'discovery': 'discovery',
    'discovery channel': 'discovery',
    'spiegel geschichte': 'spiegelgeschichte',
    'n24 doku': 'n24doku',
    'nat geo': 'nationalgeographic',
    'nat geo hd': 'nationalgeographic',
    'national geographic': 'nationalgeographic',
    'nat geo wild': 'nationalgeographicwild',
    'national geographic wild': 'nationalgeographicwild',
    'welt der wunder': 'weltderwunder',
    'welt der wunder tv': 'weltderwunder',
    'anixe': 'anixe',
    'anixe hd': 'anixe',
    'bibel tv': 'bibeltv',
    'k tv': 'ktv',
    'k-tv': 'ktv',
    'tele5': 'tele5',
    'tele 5': 'tele5',
    'prosieben': 'pro7',
    'pro sieben': 'pro7',
    'sat 1': 'sat1',
    'sat.1': 'sat1',
    'das erste': 'ard',
    'erste': 'ard',
    'sport 1': 'sport1',
    'rtl zwei': 'rtl2',
    'rtl ii': 'rtl2',
    'rtl nitro': 'nitro',
    'vox up': 'voxup',
    'ndr fernsehen mecklenburg vorpommern': 'ndrmv',
    'ndr fernsehen mv': 'ndrmv',
    'ndr mecklenburg-vorpommern': 'ndrmv',
    'ndr fernsehen hamburg': 'ndrhh',
    'ndr fs hamburg': 'ndrhh',
    'ndr hamburg': 'ndrhh',
    'ndr fernsehen niedersachsen': 'ndrni',
    'ndr fs niedersachsen': 'ndrni',
    'ndr niedersachsen': 'ndrni',
    'ndr fernsehen schleswig holstein': 'ndrsh',
    'ndr fs schleswig holstein': 'ndrsh',
    'ndr schleswig holstein': 'ndrsh',
    'ndr mecklenburg vorpommern': 'ndrmv',
    'ndr fs mv': 'ndrmv',
    'ndr mv': 'ndrmv',
    'bayerisches fernsehen': 'br',
    'br fernsehen': 'br',
    'hessischer rundfunk': 'hr',
    'hr fernsehen': 'hr',
    'rbb fernsehen': 'rbb',
    'swr fernsehen': 'swr',
    'radio bremen': 'radiobremen',
    'zdf neo': 'zdfneo',
    'mdr sachsen anhalt': 'mdr',
    'mdr sachsen': 'mdr',
    'mdr thueringen': 'mdr',
    'mdr thuringen': 'mdr',
    'rbb berlin': 'rbb',
    'rbb brandenburg': 'rbb',
    'swr baden wuerttemberg': 'swr',
    'swr baden wurttemberg': 'swr',
    'swr rheinland pfalz': 'swr',
    'ndr fs mecklenburg vorpommern': 'ndrmv',
    'ndr mecklenburg vorpommern hd': 'ndrmv',
    'ndr mv hd': 'ndrmv',
    'ndr fs mv hd': 'ndrmv',
    'ndr fs hh': 'ndrhh',
    'ndr hh': 'ndrhh',
    'ndr fs ni': 'ndrni',
    'ndr ni': 'ndrni',
    'ndr fs sh': 'ndrsh',
    'ndr sh': 'ndrsh',
    'mdr fernsehen': 'mdr',
    'mdr tv': 'mdr',
    'br fernsehen sued': 'br',
    'br fernsehen nord': 'br',
    'hr fernsehen': 'hr',
    'hessen fernsehen': 'hr',
    'rbb fernsehen berlin': 'rbb',
    'rbb fernsehen brandenburg': 'rbb',
    'swr fernsehen bw': 'swr',
    'swr fernsehen rp': 'swr',
    'sr fernsehen': 'sr',
    'radio bremen tv': 'radiobremen',
    'rb tv': 'radiobremen',
    'kabel 1': 'kabeleins',
    'kabel eins': 'kabeleins',
    'sat 1 gold': 'sat1gold',
    'sat.1 gold': 'sat1gold',
    'pro sieben maxx': 'pro7maxx',
    'prosieben maxx': 'pro7maxx',
    'pro sieben fun': 'pro7fun',
    'prosieben fun': 'pro7fun',
    'rtl up': 'rtlup',
    'rtl plus': 'rtlup',
    'super rtl': 'superrtl',
    'ki ka': 'kika',
    'ki.ka': 'kika',
    'kinder kanal': 'kika',
    'kinderkanal': 'kika',
    'nickelodeon': 'nick',
    'nick junior': 'nickjr',
    'nick jr': 'nickjr',
    'disney channel': 'disney',
    # Common German/Austrian/Swiss station spellings.  Family suffixes such as
    # MAXX, FUN, GOLD, DOKU or regional names intentionally remain part of the
    # identity unless explicitly listed as a spelling alias below.
    'pro 7': 'pro7',
    'pro7': 'pro7',
    'rtl2': 'rtl2',
    'rtl zwo': 'rtl2',
    'rtlzwie': 'rtl2',
    'rtlplus': 'rtlup',
    'rtl up': 'rtlup',
    'kabel1': 'kabeleins',
    'kabel eins doku': 'kabeleinsdoku',
    'kabel 1 doku': 'kabeleinsdoku',
    'sat1': 'sat1',
    'sat 1 emotions': 'sat1emotions',
    'sat.1 emotions': 'sat1emotions',
    'sat 1 comedy': 'sat1comedy',
    'sat.1 comedy': 'sat1comedy',
    'sixx': 'sixx',
    'voxup': 'voxup',
    'nitro': 'nitro',
    'rtl crime': 'rtlcrime',
    'rtl living': 'rtlliving',
    'rtl passion': 'rtlpassion',
    'zdf info': 'zdfinfo',
    'zdf kultur': 'zdfkultur',
    'zdf neo': 'zdfneo',
    'one ard': 'one',
    'ard one': 'one',
    'tagesschau 24': 'tagesschau24',
    'tagesschau24': 'tagesschau24',
    'phoenix': 'phoenix',
    '3 sat': '3sat',
    'arte deutsch': 'arte',
    'arte de': 'arte',
    'orf eins': 'orf1',
    'orf one': 'orf1',
    'orf 1': 'orf1',
    'orf zwei': 'orf2',
    'orf 2': 'orf2',
    'orf iii': 'orf3',
    'orf 3': 'orf3',
    'srf eins': 'srf1',
    'srf 1': 'srf1',
    'srf zwei': 'srf2',
    'srf 2': 'srf2',
    'srf info': 'srfinfo',
    'servus tv': 'servustv',
    'servustv': 'servustv',
    'welt tv': 'welt',
    'n24': 'welt',
    'ntv': 'ntv',
    'n tv': 'ntv',
    'euronews deutsch': 'euronews',
    'eurosport 1': 'eurosport1',
    'eurosport eins': 'eurosport1',
    'eurosport 2': 'eurosport2',
    'eurosport zwei': 'eurosport2',
    'sky sport news': 'skysportnews',
    'sport1 plus': 'sport1plus',
    'sport 1 plus': 'sport1plus',
    'deluxe music': 'deluxemusic',
    'mtv germany': 'mtv',
    'comedy central': 'comedycentral',
}


