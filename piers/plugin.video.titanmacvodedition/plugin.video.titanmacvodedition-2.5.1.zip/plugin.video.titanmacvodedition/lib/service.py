# -*- coding: utf-8 -*-
"""Background service – EPG refresh + PlayerMonitor with zap window handling."""

from __future__ import absolute_import, division, unicode_literals

from urllib.parse import urlsplit, parse_qsl, urlencode
import xbmc
from xbmc import Monitor, Player, getInfoLabel
from .loggers import Logger
from .utils import get_int_value, get_next_info_and_send_signal
from .api import get_epg_data, epg_caches, get_next_epg_refresh_seconds
from .globals import G
from .xmltv import get_epg_source, get_xmltv_url
from .maintenance import run_xmltv_refresh, update_status

ADDON_ID = 'plugin.video.titanmacvodedition'
HOME_WINDOW_ID = 10000
PROP_LIVE = 'TitanMacVOD.LivePlayback'


def _close_playlist_window():
    """Compatibility no-op.

    Older builds emitted global Action(Back) commands when playback changed.
    Aeon Nox Silvo could forward those commands into its navigation stack,
    instantly closing the zapper or returning to Home.  Window lifetime is now
    controlled exclusively by FavoriteZapperDialog.
    """
    return


class BackgroundService(Monitor):
    """EPG background refresh service."""

    def _wait_for_portal(self, timeout_s=60, poll_s=2):
        """Wait until both portal_url AND mac_address are configured.
        Returns True when ready, False if timed out or abort requested."""
        elapsed = 0
        while elapsed < timeout_s:
            G.reload_portal_settings(quiet=True)
            mac = (G.portal_config.mac_cookie or '').replace('mac=', '').strip()
            if G.portal_config.portal_url and mac:
                return True
            Logger.debug('Service: waiting for first portal/MAC configuration')
            if self.waitForAbort(poll_s):
                return False
            elapsed += poll_s
        Logger.warn('Service: portal/MAC still not set after {}s, skipping initial EPG load'.format(timeout_s))
        return False


    def _refresh_portal_index_if_needed(self):
        """Do not build the channel index in the background.

        The full portal index belongs exclusively to "Meine Sender" and the
        explicit manual rebuild command. Normal TV browsing and EPG refreshes
        must never trigger an index synchronization.
        """
        Logger.debug('Portal index background refresh skipped (Meine Sender only)')

    def onSettingsChanged(self):
        """Immediately pick up portal/MAC changes made by the plugin process."""
        try:
            G.reload_portal_settings(quiet=True)
        except Exception as exc:
            Logger.debug('Service settings reload failed: {}'.format(exc))

    def run(self):
        Logger.debug('Service started')

        # Wait for portal to be configured, then do initial EPG load
        if self._wait_for_portal(timeout_s=60, poll_s=2):
            try:
                try:
                    from .portal_manager import run_daily_maintenance
                    run_daily_maintenance()
                except Exception as warning_exc:
                    Logger.warn('MAC expiry warning failed: {}'.format(warning_exc))
                get_epg_data()
                Logger.debug('EPG startup refresh finished')
                self._refresh_portal_index_if_needed()
            except Exception as exc:
                Logger.error('EPG startup refresh failed: {}'.format(exc))

            # Load XMLTV if configured
            if get_epg_source() in ('xmltv', 'merge') and get_xmltv_url():
                try:
                    try:
                        from .portal_index import get_cached_channels
                        portal_channels = get_cached_channels()
                    except Exception:
                        portal_channels = []
                    run_xmltv_refresh(portal_channels=portal_channels, force=False)
                    Logger.debug('XMLTV EPG startup load finished')
                except Exception as exc:
                    Logger.warn('XMLTV startup load failed: {}'.format(exc))

        while not self.abortRequested():
            # Periodic EPG refresh
            try:
                wait_s = get_next_epg_refresh_seconds(
                    default_seconds=600, min_seconds=120, max_seconds=900)
            except Exception:
                wait_s = 600

            if self.waitForAbort(int(wait_s)):
                break

            # Lightweight daily portal maintenance (schema migration + MAC warning).
            try:
                from .portal_manager import run_daily_maintenance
                run_daily_maintenance()
            except Exception as maintenance_exc:
                Logger.warn('Daily portal maintenance failed: {}'.format(maintenance_exc))

            # Re-read settings so portal/MAC changes take effect without restart
            G.reload_portal_settings(quiet=True)
            mac = (G.portal_config.mac_cookie or '').replace('mac=', '').strip()
            if not G.portal_config.portal_url or not mac:
                Logger.debug('Service: portal or MAC not set, skipping EPG refresh')
                continue
            try:
                get_epg_data()
                Logger.debug('EPG background refresh done')
                self._refresh_portal_index_if_needed()
            except Exception as exc:
                Logger.error('EPG background refresh failed: {}'.format(exc))

            # XMLTV refresh is coordinated by a profile lock. This prevents
            # overlapping service runs and records duration/result for diagnostics.
            if get_epg_source() in ('xmltv', 'merge') and get_xmltv_url():
                try:
                    from .portal_index import get_cached_channels
                    run_xmltv_refresh(portal_channels=get_cached_channels(), force=False)
                except Exception as exc:
                    Logger.warn('XMLTV periodic refresh failed: {}'.format(exc))

        Logger.debug('Service stopped')


class PlayerMonitor(Player):
    """Read-only playback monitor.

    The service never retries, restarts, stops, advances, or opens live TV.
    It only keeps the existing UpNext integration for normal episodic plugin
    playback. Direct favorite-zapper streams are fully owned by the dialog's
    LiveZapperController.
    """

    def __init__(self):
        Player.__init__(self)
        self.__path = ''
        self.__listen = False

    def onPlayBackStarted(self):
        self.__path = getInfoLabel('Player.FilenameAndPath')
        self.__listen = self.__path.startswith('plugin://{}/'.format(ADDON_ID))

    def onAVStarted(self):
        if not self.__listen:
            return
        params = dict(parse_qsl(urlsplit(self.__path).query))
        episode_no = get_int_value(params, 'series')
        total_episodes = get_int_value(params, 'total_episodes')
        if episode_no != 0 and episode_no < total_episodes:
            params['series'] = episode_no + 1
            next_url = '{}?{}'.format(
                'plugin://{}/'.format(ADDON_ID), urlencode(params))
            try:
                get_next_info_and_send_signal(params, next_url)
            except Exception as exc:
                Logger.warn('UpNext signal failed: {}'.format(exc))

    def onPlayBackError(self):
        self.__listen = False

    def onPlayBackEnded(self):
        self.__listen = False

    def onPlayBackStopped(self):
        self.__listen = False


def run():
    """Service entry point."""
    G.init_globals(quiet=True)
    monitor = BackgroundService()
    player = PlayerMonitor()  # noqa: F841 – kept alive intentionally
    monitor.run()
