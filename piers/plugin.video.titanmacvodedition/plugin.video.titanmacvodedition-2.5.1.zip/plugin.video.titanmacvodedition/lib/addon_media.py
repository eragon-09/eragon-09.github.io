"""Split portion of the Kodi add-on controller.

Kept as a class named StalkerAddon so Python private-name mangling remains
compatible with the original monolithic implementation.
"""
from __future__ import absolute_import, division, unicode_literals
from .addon_shared import *
from .media_search import build_result_page, media_search


class StalkerAddon:
    @staticmethod
    def __list_vod_category_menu(params):
        """Show the actions available inside one VOD portal category."""
        category = str(params.get('category') or '').strip()
        category_id = params.get('category_id')
        if not category or category_id in (None, ''):
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return

        if StalkerAddon.__is_adult_category(category):
            if not StalkerAddon.__require_pin():
                xbmcplugin.endOfDirectory(
                    G.get_handle(), succeeded=True,
                    updateListing=False, cacheToDisc=False)
                return

        xbmcplugin.setPluginCategory(G.get_handle(), category)
        xbmcplugin.setContent(G.get_handle(), 'videos')

        base = {
            'category': category,
            'category_id': category_id,
            'page': 1,
            'update_listing': False,
            'search_term': '',
            'fav': 0,
        }
        entries = [
            (_LSTR(32212) or 'Alle Filme', dict(base, action='vod_listing')),
            (_LSTR(32217) or 'Neu hinzugefügt', dict(base, action='vod_new')),
            (_LSTR(32214) or 'Genres dieser Kategorie', dict(base, action='vod_genres')),
            (_LSTR(32215) or 'Nach Erscheinungsjahr', dict(base, action='vod_years')),
        ]

        directory_items = []
        for label, target in entries:
            item = xbmcgui.ListItem(label=label, label2=label)
            directory_items.append((G.get_plugin_url(target), item, True))
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, len(directory_items))
        xbmcplugin.endOfDirectory(
            G.get_handle(), succeeded=True,
            updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_vod(params):
        """List videos for a category"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        category_title = params.get('category') if isinstance(params, dict) else None
        if StalkerAddon.__is_adult_category(category_title):
            if not StalkerAddon.__require_pin():
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)
                return
        Logger.debug('List VOD {}'.format(params))
        search_term = params.get('search_term', '')
        plugin_category = ('VOD - ' + params['category'] if params.get('fav', '0') != '1'
                           else 'VOD - ' + params['category'] + ' - ' + (_LSTR(32209) or 'Favoriten dieser Kategorie'))
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        try:
            videos = Api.get_videos(params['category_id'], params['page'], search_term, params.get('fav', 0))
            StalkerAddon.__create_video_listing(videos, params)
        except Exception as exc:
            Logger.error('__list_vod failed: {}'.format(exc))
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)

    @staticmethod
    def __vod_added_sort_key(video):
        """Return a comparable timestamp for common cross-portal added-date fields."""
        if not isinstance(video, dict):
            return 0
        value = None
        for key in ('added', 'date_added', 'created', 'created_at', 'added_at'):
            if video.get(key) not in (None, ''):
                value = video.get(key)
                break
        if value in (None, ''):
            return 0
        try:
            numeric = float(value)
            if numeric > 100000000:
                return numeric
        except (TypeError, ValueError):
            pass
        text = str(value).strip()
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d',
                    '%d.%m.%Y %H:%M:%S', '%d.%m.%Y'):
            try:
                return time.mktime(time.strptime(text[:19], fmt))
            except (TypeError, ValueError, OverflowError):
                continue
        digits = ''.join(re.findall(r'\d+', text))
        try:
            return float(digits) if digits else 0
        except ValueError:
            return 0

    @staticmethod
    def __list_vod_new(params):
        """List the newest movies in the selected category."""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        category = str(params.get('category') or '').strip()
        if StalkerAddon.__is_adult_category(category):
            if not StalkerAddon.__require_pin():
                xbmcplugin.endOfDirectory(
                    G.get_handle(), succeeded=True,
                    updateListing=False, cacheToDisc=False)
                return
        xbmcplugin.setPluginCategory(
            G.get_handle(), '{} - {}'.format(category, _LSTR(32217) or 'Neu hinzugefügt'))
        xbmcplugin.setContent(G.get_handle(), 'videos')
        try:
            videos = Api.get_videos(
                params.get('category_id'), params.get('page', 1), '', params.get('fav', 0))
            rows = videos.get('data', []) if isinstance(videos, dict) else []
            if isinstance(rows, list):
                videos['data'] = sorted(
                    rows, key=StalkerAddon.__vod_added_sort_key, reverse=True)
            listing_params = dict(params or {})
            listing_params.update({'search_term': '', 'fav': 0})
            StalkerAddon.__create_video_listing(videos, listing_params)
        except Exception as exc:
            Logger.error('__list_vod_new failed: {}'.format(exc))
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)

    @staticmethod
    def __list_series_category_menu(params):
        """Show the actions available inside one series portal category."""
        category = str(params.get('category') or '').strip()
        category_id = params.get('category_id')
        if not category or category_id in (None, ''):
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        if StalkerAddon.__is_adult_category(category) and not StalkerAddon.__require_pin():
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)
            return
        xbmcplugin.setPluginCategory(G.get_handle(), category)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        base = {'category': category, 'category_id': category_id, 'page': 1,
                'update_listing': False, 'search_term': '', 'fav': 0}
        entries = [
            (_LSTR(32218) or 'Alle Serien', dict(base, action='series_listing')),
            (_LSTR(32217) or 'Neu hinzugefügt', dict(base, action='series_new')),
            (_LSTR(32214) or 'Genres dieser Kategorie', dict(base, action='series_genres')),
            (_LSTR(32215) or 'Nach Erscheinungsjahr', dict(base, action='series_years')),
        ]
        items=[]
        for label,target in entries:
            item=xbmcgui.ListItem(label=label,label2=label)
            items.append((G.get_plugin_url(target),item,True))
        xbmcplugin.addDirectoryItems(G.get_handle(),items,len(items))
        xbmcplugin.endOfDirectory(G.get_handle(),succeeded=True,updateListing=False,cacheToDisc=False)

    @staticmethod
    def __series_added_sort_key(video):
        return StalkerAddon.__vod_added_sort_key(video)

    @staticmethod
    def __extract_series_genres(video):
        return StalkerAddon.__extract_vod_genres(video)

    @staticmethod
    def __extract_series_year(video):
        return StalkerAddon.__extract_vod_year(video)

    @staticmethod
    def __load_series_filter_source(params):
        return Api.get_series(params.get('category_id'), params.get('page', 1),
                              params.get('search_term', ''), params.get('fav', 0))

    @staticmethod
    def __list_series_new(params):
        xbmcplugin.setPluginCategory(G.get_handle(), '{} - {}'.format(params.get('category',''), _LSTR(32217) or 'Neu hinzugefügt'))
        xbmcplugin.setContent(G.get_handle(), 'videos')
        try:
            data=StalkerAddon.__load_series_filter_source(params)
            rows=data.get('data',[]) if isinstance(data,dict) else []
            data['data']=sorted(rows,key=StalkerAddon.__series_added_sort_key,reverse=True)
            StalkerAddon.__create_series_listing(data,dict(params))
        except Exception as exc:
            Logger.error('__list_series_new failed: {}'.format(exc))
            xbmcplugin.endOfDirectory(G.get_handle(),succeeded=False)

    @staticmethod
    def __list_series_genres(params):
        xbmcplugin.setPluginCategory(G.get_handle(), '{} - {}'.format(params.get('category',''), _LSTR(32214) or 'Genres dieser Kategorie'))
        xbmcplugin.setContent(G.get_handle(),'videos')
        try: data=StalkerAddon.__load_series_filter_source(params)
        except Exception as exc:
            Logger.error('Could not load series genres: {}'.format(exc)); data={'data':[]}
        counts={}
        for row in data.get('data',[]):
            for genre in StalkerAddon.__extract_series_genres(row): counts[genre]=counts.get(genre,0)+1
        items=[]
        for genre in sorted(counts,key=lambda x:x.casefold()):
            label='{} ({})'.format(genre,counts[genre]); item=xbmcgui.ListItem(label=label,label2=label)
            target=dict(params); target.update({'action':'series_genre_listing','genre':genre,'page':1})
            items.append((G.get_plugin_url(target),item,True))
        if not items:
            label=_LSTR(32211) or 'Keine Genreinformationen für diese Kategorie verfügbar.'
            items.append(('',xbmcgui.ListItem(label=label,label2=label),False))
        xbmcplugin.addDirectoryItems(G.get_handle(),items,len(items)); xbmcplugin.endOfDirectory(G.get_handle(),True,False,False)

    @staticmethod
    def __list_series_genre(params):
        selected=str(params.get('genre') or '').strip().casefold()
        try: data=StalkerAddon.__load_series_filter_source(params)
        except Exception as exc:
            Logger.error('Could not load series genre listing: {}'.format(exc)); data={'data':[]}
        rows=[r for r in data.get('data',[]) if selected in {g.casefold() for g in StalkerAddon.__extract_series_genres(r)}]
        result={'data':rows,'total_items':len(rows),'max_page_items':25,'page':1}
        target=dict(params); target.update({'category':'{} - {}'.format(params.get('category',''),params.get('genre','')),'page':1,'update_listing':False})
        StalkerAddon.__create_series_listing(result,target)

    @staticmethod
    def __list_series_years(params):
        xbmcplugin.setPluginCategory(G.get_handle(), '{} - {}'.format(params.get('category',''), _LSTR(32215) or 'Nach Erscheinungsjahr'))
        xbmcplugin.setContent(G.get_handle(),'videos')
        try: data=StalkerAddon.__load_series_filter_source(params)
        except Exception as exc:
            Logger.error('Could not load series years: {}'.format(exc)); data={'data':[]}
        counts={}
        for row in data.get('data',[]):
            year=StalkerAddon.__extract_series_year(row)
            if year: counts[year]=counts.get(year,0)+1
        items=[]
        for year in sorted(counts,reverse=True):
            label='{} ({})'.format(year,counts[year]); item=xbmcgui.ListItem(label=label,label2=label)
            target=dict(params); target.update({'action':'series_year_listing','year':year,'page':1})
            items.append((G.get_plugin_url(target),item,True))
        if not items:
            label=_LSTR(32216) or 'Keine Angaben zum Erscheinungsjahr verfügbar.'
            items.append(('',xbmcgui.ListItem(label=label,label2=label),False))
        xbmcplugin.addDirectoryItems(G.get_handle(),items,len(items)); xbmcplugin.endOfDirectory(G.get_handle(),True,False,False)

    @staticmethod
    def __list_series_year(params):
        selected=get_int_value(params,'year')
        try: data=StalkerAddon.__load_series_filter_source(params)
        except Exception as exc:
            Logger.error('Could not load series year listing: {}'.format(exc)); data={'data':[]}
        rows=[r for r in data.get('data',[]) if StalkerAddon.__extract_series_year(r)==selected]
        result={'data':rows,'total_items':len(rows),'max_page_items':25,'page':1}
        target=dict(params); target.update({'category':'{} - {}'.format(params.get('category',''),selected),'page':1,'update_listing':False})
        StalkerAddon.__create_series_listing(result,target)

    @staticmethod
    def __list_vod_favorites(params):
        """List Favorites Channels"""
        Logger.debug('List VOD Favorites {}'.format(params))
        xbmcplugin.setPluginCategory(G.get_handle(), 'VOD FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        videos = Api.get_vod_favorites(params['page'])
        StalkerAddon.__create_video_listing(videos, params)

    @staticmethod
    def __list_series_favorites(params):
        """List Favorites Channels"""
        xbmcplugin.setPluginCategory(G.get_handle(), 'SERIES FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        series = Api.get_series_favorites(params['page'])
        StalkerAddon.__create_series_listing(series, params)

    @staticmethod
    def __list_tv_favorites(params):
        """List Favorites Channels"""
        Logger.debug('List TV favorites {}'.format(params))
        xbmcplugin.setPluginCategory(G.get_handle(), 'TV FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'files')
        videos = Api.get_tv_favorites(params['page'])
        StalkerAddon.__create_tv_listing(videos, params)

    @staticmethod
    def __list_series(params):
        """List series"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        category_title = params.get('category') if isinstance(params, dict) else None
        if StalkerAddon.__is_adult_category(category_title):
            if not StalkerAddon.__require_pin():
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)
                return
        Logger.debug('List Series {}'.format(params))
        search_term = params.get('search_term', '')
        plugin_category = 'SERIES - ' + params['category'] if params.get('fav', '0') != '1' else 'SERIES - ' + params['category'] + ' - FAVORITES'
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        try:
            series = Api.get_series(params['category_id'], params['page'], search_term, params.get('fav', 0))
            StalkerAddon.__create_series_listing(series, params)
        except Exception as exc:
            Logger.error('__list_series failed: {}'.format(exc))
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)

    @staticmethod
    def __list_season(params):
        """List season"""
        xbmcplugin.setPluginCategory(G.get_handle(), params['name'])
        xbmcplugin.setContent(G.get_handle(), 'videos')
        seasons = Api.get_seasons(params['video_id'])
        directory_items = []
        for season in seasons['data']:
            label = season['name']
            list_item = xbmcgui.ListItem(label=label, label2=label)
            match = re.match("^Season [0-9]+$", season['name'])
            name = params['name'] + ' ' + season['name']
            if match:
                temp = season['name'].split(' ')
                name = params['name'] + ' S' + temp[-1]
            url = G.get_plugin_url({'action': 'sub_folder', 'video_id': season['id'], 'start': season['series'][0],
                                    'end': season['series'][-1], 'name': name, 'poster_url': params['poster_url']})
            video_info = list_item.getVideoInfoTag()
            video_info.setMediaType('season')
            video_info.setTitle(season['name'])
            video_info.setOriginalTitle(season['name'])
            video_info.setSortTitle(season['name'])
            video_info.setPlot(season.get('description', ''))
            video_info.setPlotOutline(season.get('description', ''))
            actors = [xbmc.Actor(actor) for actor in season['actors'].split(',') if actor]  # pylint: disable=maybe-no-member
            video_info.setCast(actors)
            list_item.setArt({'poster': params['poster_url']})
            directory_items.append((url, list_item, True))
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, len(seasons['data']))
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __create_video_listing(videos, params):
        """Create a robust paginated VOD listing."""
        update_listing = str(params.get('update_listing', 'False'))
        video_rows = videos.get('data', []) if isinstance(videos, dict) else []
        if not isinstance(video_rows, list):
            video_rows = []

        directory_items = []
        for index, video in enumerate(video_rows):
            if not isinstance(video, dict):
                Logger.warning('Skipping invalid VOD item at index {}'.format(index))
                continue
            try:
                video_id = video.get('id') or video.get('video_id') or video.get('vod_id')
                name = str(video.get('name') or video.get('title') or (_LSTR(32200) or 'Unknown movie')).strip()
                if not video_id:
                    Logger.warning('Skipping VOD item without id: {}'.format(name))
                    continue

                label = name if get_int_value(video, 'hd') != 0 or 'hd' not in video else name + ' (SD)'
                is_favorite = get_int_value(video, 'fav') == 1
                if is_favorite:
                    label += ' ★'
                list_item = xbmcgui.ListItem(label=label, label2=label)

                if is_favorite:
                    context_url = G.get_plugin_url({'action': 'remove_fav', 'video_id': video_id, '_type': 'vod'})
                    context_label = _LSTR(32202) or 'Remove from favorites'
                else:
                    context_url = G.get_plugin_url({'action': 'add_fav', 'video_id': video_id, '_type': 'vod'})
                    context_label = _LSTR(32201) or 'Add to favorites'
                list_item.addContextMenuItems([(context_label, 'RunPlugin({}, False)'.format(context_url))])

                poster_url = StalkerAddon.__build_portal_art_url(video.get('screenshot_uri'))
                video_info = list_item.getVideoInfoTag()
                series_data = video.get('series') or []
                if not isinstance(series_data, (list, tuple)):
                    series_data = []

                is_folder = bool(series_data)
                if is_folder:
                    url = G.get_plugin_url({
                        'action': 'sub_folder', 'video_id': video_id,
                        'start': series_data[0], 'end': series_data[-1],
                        'name': name, 'poster_url': poster_url or ''
                    })
                    video_info.setMediaType('season')
                else:
                    duration = get_int_value(video, 'time')
                    url = G.get_plugin_url({
                        'action': 'play', 'video_id': video_id, 'series': 0,
                        'title': name, 'cmd': video.get('cmd', ''),
                        'poster_url': poster_url or '',
                        'year': get_int_value(video, 'year'),
                        'duration': duration * 60 if duration else 0
                    })
                    if duration:
                        video_info.setDuration(duration * 60)
                    video_info.setMediaType('movie')
                    list_item.setProperty('IsPlayable', 'true')

                video_info.setTitle(name)
                video_info.setOriginalTitle(name)
                video_info.setSortTitle(name)

                country = str(video.get('country') or '').strip()
                if country:
                    video_info.setCountries([country])
                genres = StalkerAddon.__extract_vod_genres(video)
                if genres:
                    try:
                        video_info.setGenres(genres)
                    except Exception:
                        pass
                director = str(video.get('director') or '').strip()
                if director:
                    video_info.setDirectors([director])
                description = str(video.get('description') or '').strip()
                video_info.setPlot(description)
                video_info.setPlotOutline(description)
                actors_raw = video.get('actors') or ''
                if isinstance(actors_raw, (list, tuple)):
                    actor_names = [str(actor).strip() for actor in actors_raw if str(actor).strip()]
                else:
                    actor_names = [actor.strip() for actor in str(actors_raw).split(',') if actor.strip()]
                if actor_names:
                    video_info.setCast([xbmc.Actor(actor) for actor in actor_names])  # pylint: disable=maybe-no-member
                last_played = str(video.get('last_played') or '').strip()
                if last_played:
                    video_info.setLastPlayed(last_played)
                date_added = str(video.get('added') or '').strip()
                if date_added:
                    video_info.setDateAdded(date_added)
                year = get_int_value(video, 'year')
                if year:
                    video_info.setYear(year)
                if poster_url:
                    list_item.setArt({'poster': poster_url, 'thumb': poster_url, 'icon': poster_url})

                directory_items.append((url, list_item, is_folder))
            except Exception as exc:
                Logger.warning('Skipping broken VOD item at index {}: {}'.format(index, exc))

        item_count = len(directory_items)
        if not directory_items:
            label = _LSTR(32203) or 'No movies found'
            empty_item = xbmcgui.ListItem(label=label, label2=label)
            empty_item.setProperty('IsPlayable', 'false')
            directory_items.append(('', empty_item, False))
            item_count = 1
        else:
            total_items = get_int_value(videos, 'total_items')
            if total_items > len(video_rows):
                StalkerAddon.__add_navigation_items(params, videos, directory_items)
                item_count = len(directory_items)

        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, item_count)
        xbmcplugin.endOfDirectory(
            G.get_handle(), succeeded=True,
            updateListing=update_listing.lower() == 'true', cacheToDisc=False)

    @staticmethod
    def __build_portal_art_url(value):
        """Return a normalized absolute artwork URL or None."""
        if not isinstance(value, str):
            return None
        value = value.strip()
        if not value:
            return None
        if value.lower().startswith(('http://', 'https://')):
            return value
        base = str(getattr(G.portal_config, 'portal_base_url', '') or '').rstrip('/')
        if not base:
            return None
        return base + '/' + value.lstrip('/')

    @staticmethod
    def __create_series_listing(series, params):
        """Create a defensive series listing with 25-item pagination."""
        update_listing=str(params.get('update_listing','False')).lower()=='true'
        rows=series.get('data',[]) if isinstance(series,dict) else []
        if not isinstance(rows,list): rows=[]
        items=[]
        for index,video in enumerate(rows):
            if not isinstance(video,dict): continue
            try:
                video_id=video.get('id') or video.get('video_id') or video.get('series_id')
                name=str(video.get('name') or video.get('title') or (_LSTR(32220) or 'Unbekannte Serie')).strip()
                if not video_id: continue
                label=name if get_int_value(video,'hd') != 0 or 'hd' not in video else name+' (SD)'
                favorite=get_int_value(video,'fav')==1
                if favorite: label+=' ★'
                item=xbmcgui.ListItem(label=label,label2=label)
                action='remove_fav' if favorite else 'add_fav'
                text=(_LSTR(32202) or 'Aus Favoriten entfernen') if favorite else (_LSTR(32201) or 'Zu Favoriten hinzufügen')
                ctx=G.get_plugin_url({'action':action,'video_id':video_id,'_type':'series'})
                item.addContextMenuItems([(text,'RunPlugin({}, False)'.format(ctx))])
                poster=StalkerAddon.__build_portal_art_url(video.get('screenshot_uri'))
                url=G.get_plugin_url({'action':'season_listing','video_id':video_id,'name':name,'poster_url':poster or ''})
                info=item.getVideoInfoTag(); info.setMediaType('tvshow'); info.setTitle(name); info.setOriginalTitle(name); info.setSortTitle(name)
                country=str(video.get('country') or '').strip()
                if country: info.setCountries([country])
                genres=StalkerAddon.__extract_series_genres(video)
                if genres:
                    try: info.setGenres(genres)
                    except Exception: pass
                director=str(video.get('director') or '').strip()
                if director: info.setDirectors([director])
                description=str(video.get('description') or '')
                info.setPlot(description); info.setPlotOutline(description)
                actors=video.get('actors') or ''
                names=[str(a).strip() for a in actors] if isinstance(actors,(list,tuple)) else [a.strip() for a in str(actors).split(',')]
                names=[a for a in names if a]
                if names: info.setCast([xbmc.Actor(a) for a in names])
                last=str(video.get('last_played') or '').strip()
                if last: info.setLastPlayed(last)
                added=str(video.get('added') or video.get('date_added') or '').strip()
                if added: info.setDateAdded(added)
                year=StalkerAddon.__extract_series_year(video)
                if year: info.setYear(year)
                if poster: item.setArt({'poster':poster,'thumb':poster,'icon':poster})
                items.append((url,item,True))
            except Exception as exc:
                Logger.warning('Skipping broken series item at index {}: {}'.format(index,exc))
        if not items:
            label=_LSTR(32221) or 'Keine Serien gefunden'
            items.append(('',xbmcgui.ListItem(label=label,label2=label),False))
        elif get_int_value(series,'total_items')>len(rows):
            StalkerAddon.__add_navigation_items(params,series,items)
        xbmcplugin.addDirectoryItems(G.get_handle(),items,len(items))
        xbmcplugin.endOfDirectory(G.get_handle(),succeeded=True,updateListing=update_listing,cacheToDisc=False)

    @staticmethod
    def __add_navigation_items(params, videos, directory_items):
        """Add navigation list items without mutating the caller's parameters."""
        page = max(1, get_int_value(params, 'page'))
        total_items = get_int_value(videos, 'total_items')
        max_page_items = max(1, get_int_value(videos, 'max_page_items'))
        total_pages = max(1, int(math.ceil(float(total_items) / float(max_page_items))))
        page_step = 1

        previous_label = (_LSTR(32206) or 'Last Page') if page == 1 else (_LSTR(32204) or 'Previous Page')
        previous_item = xbmcgui.ListItem('<< ' + previous_label)
        previous_item.setArt({'thumb': G.get_custom_thumb_path('pagePrevious.png')})
        previous_item.setProperty('specialsort', 'top')
        previous_page = total_pages - page_step + 1 if page == 1 else max(1, page - page_step)
        previous_params = dict(params)
        previous_params.update({'page': previous_page, 'update_listing': True})
        directory_items.insert(0, (G.get_plugin_url(previous_params), previous_item, True))

        is_last_block = page >= total_pages - page_step + 1
        next_label = (_LSTR(32207) or 'First Page') if is_last_block else (_LSTR(32205) or 'Next Page')
        next_item = xbmcgui.ListItem(next_label + ' >>')
        next_item.setArt({'thumb': G.get_custom_thumb_path('pageNext.png')})
        next_item.setProperty('specialsort', 'bottom')
        next_page = 1 if is_last_block else page + page_step
        next_params = dict(params)
        next_params.update({'page': next_page, 'update_listing': True})
        directory_items.append((G.get_plugin_url(next_params), next_item, True))

    @staticmethod
    def __list_episodes(params):
        """List episodes for a series"""
        name = params['name']
        xbmcplugin.setPluginCategory(G.get_handle(), name)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        temp = name.split(' ')
        match = re.match("^S[0-9]+$", temp[-1])
        season = None
        if match:
            season = int(match.string[1:])
            name = ' '.join(temp[:-1])
        start = get_int_value(params, 'start')
        end = get_int_value(params, 'end')
        for episode_no in range(start, end + 1):
            list_item = xbmcgui.ListItem(label='Episode ' + str(episode_no))
            video_info = list_item.getVideoInfoTag()
            video_info.setTitle(name)
            video_info.setOriginalTitle(name)
            if match:
                video_info.setEpisode(episode_no)
                video_info.setSeason(season)
                video_info.setSortSeason(season)
                video_info.setMediaType('episode')
                video_info.setTvShowTitle(name)
            else:
                video_info.setMediaType('movie')
            list_item.setProperties({'IsPlayable': 'true'})
            list_item.setArt({'poster': params['poster_url']})
            url = G.get_plugin_url({'action': 'play', 'video_id': params['video_id'], 'series': episode_no, 'season_no': season,
                                    'title': name, 'total_episodes': end, 'poster_url': params['poster_url']})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __extract_vod_genres(video):
        """Extract normalized genre names from common cross-portal metadata fields."""
        if not isinstance(video, dict):
            return []
        values = []
        for key in ('genre', 'genres', 'genre_name', 'genres_str', 'category_name'):
            value = video.get(key)
            if value not in (None, '', [], {}):
                values.append(value)

        parts = []
        for value in values:
            if isinstance(value, dict):
                value = value.get('name') or value.get('title') or value.get('value') or ''
            if isinstance(value, (list, tuple, set)):
                raw_items = value
            else:
                raw_items = re.split(r'\s*[,;|/]\s*', str(value))
            for item in raw_items:
                if isinstance(item, dict):
                    item = item.get('name') or item.get('title') or item.get('value') or ''
                text = str(item or '').strip()
                if not text or text.isdigit():
                    continue
                parts.append(text)

        result = []
        seen = set()
        for text in parts:
            key = text.casefold()
            if key not in seen:
                seen.add(key)
                result.append(text)
        return result

    @staticmethod
    def __load_vod_genre_source(params):
        """Load the normal portal listing used for experimental local genre filtering."""
        return Api.get_videos(params.get('category_id'), 1, '', params.get('fav', 0))

    @staticmethod
    def __list_vod_genres(params):
        """Show genres discovered in the current VOD category without a special portal API."""
        Logger.debug('List experimental VOD genres {}'.format(params))
        category = str(params.get('category') or '').strip()
        xbmcplugin.setPluginCategory(
            G.get_handle(), '{} - {}'.format(category, _LSTR(32210) or 'Genre-Filter dieser Kategorie'))
        xbmcplugin.setContent(G.get_handle(), 'videos')
        try:
            videos = StalkerAddon.__load_vod_genre_source(params)
        except Exception as exc:
            Logger.error('Could not load VOD genres: {}'.format(exc))
            videos = {'data': []}

        genre_map = {}
        for video in videos.get('data', []) if isinstance(videos, dict) else []:
            for genre in StalkerAddon.__extract_vod_genres(video):
                genre_map.setdefault(genre.casefold(), genre)

        directory_items = []
        for key in sorted(genre_map, key=lambda value: genre_map[value].casefold()):
            genre = genre_map[key]
            item = xbmcgui.ListItem(label=genre, label2=genre)
            url = G.get_plugin_url({
                'action': 'vod_genre_listing', 'category': category,
                'category_id': params.get('category_id'), 'genre': genre,
                'fav': params.get('fav', 0), 'page': 1,
                'update_listing': False, 'search_term': ''})
            directory_items.append((url, item, True))

        if not directory_items:
            label = _LSTR(32211) or 'Keine Genreinformationen für diese Kategorie verfügbar.'
            item = xbmcgui.ListItem(label=label, label2=label)
            item.setProperty('IsPlayable', 'false')
            directory_items.append(('', item, False))

        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, len(directory_items))
        xbmcplugin.endOfDirectory(
            G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_vod_genre(params):
        """Filter the locally loaded category data by a discovered genre."""
        selected = str(params.get('genre') or '').strip()
        Logger.debug('List VOD genre {} for {}'.format(selected, params.get('category')))
        try:
            videos = StalkerAddon.__load_vod_genre_source(params)
        except Exception as exc:
            Logger.error('Could not load VOD genre listing: {}'.format(exc))
            videos = {'data': []}

        rows = videos.get('data', []) if isinstance(videos, dict) else []
        selected_key = selected.casefold()
        filtered = [
            video for video in rows if isinstance(video, dict) and
            selected_key in {genre.casefold() for genre in StalkerAddon.__extract_vod_genres(video)}
        ]
        results = {
            'data': filtered, 'total_items': len(filtered),
            'max_page_items': max(1, len(filtered)), 'page': 1}
        listing_params = dict(params or {})
        listing_params.update({
            'category': '{} - {}'.format(params.get('category', ''), selected),
            'page': 1, 'update_listing': False, 'search_term': '', 'fav': 0})
        StalkerAddon.__create_video_listing(results, listing_params)

    @staticmethod
    def __extract_vod_year(video):
        """Return a plausible release year from common cross-portal fields."""
        if not isinstance(video, dict):
            return 0
        for key in ('year', 'release_year', 'production_year', 'movie_year'):
            value = video.get(key)
            if value in (None, ''):
                continue
            match = re.search(r'\b(19\d{2}|20\d{2}|21\d{2})\b', str(value))
            if match:
                return int(match.group(1))
        return 0

    @staticmethod
    def __list_vod_years(params):
        """Show release years discovered in the current VOD category."""
        category = str(params.get('category') or '').strip()
        xbmcplugin.setPluginCategory(
            G.get_handle(), '{} - {}'.format(category, _LSTR(32215) or 'Nach Erscheinungsjahr'))
        xbmcplugin.setContent(G.get_handle(), 'videos')
        try:
            videos = StalkerAddon.__load_vod_genre_source(params)
        except Exception as exc:
            Logger.error('Could not load VOD years: {}'.format(exc))
            videos = {'data': []}

        year_counts = {}
        for video in videos.get('data', []) if isinstance(videos, dict) else []:
            year = StalkerAddon.__extract_vod_year(video)
            if year:
                year_counts[year] = year_counts.get(year, 0) + 1

        directory_items = []
        for year in sorted(year_counts, reverse=True):
            label = '{} ({})'.format(year, year_counts[year])
            item = xbmcgui.ListItem(label=label, label2=label)
            target = dict(params or {})
            target.update({'action': 'vod_year_listing', 'year': year, 'page': 1})
            directory_items.append((G.get_plugin_url(target), item, True))

        if not directory_items:
            label = _LSTR(32216) or 'Keine Angaben zum Erscheinungsjahr verfügbar.'
            item = xbmcgui.ListItem(label=label, label2=label)
            item.setProperty('IsPlayable', 'false')
            directory_items.append(('', item, False))

        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, len(directory_items))
        xbmcplugin.endOfDirectory(
            G.get_handle(), succeeded=True,
            updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_vod_year(params):
        """List movies of one locally discovered release year."""
        selected_year = get_int_value(params, 'year')
        try:
            videos = StalkerAddon.__load_vod_genre_source(params)
        except Exception as exc:
            Logger.error('Could not load VOD year listing: {}'.format(exc))
            videos = {'data': []}

        rows = videos.get('data', []) if isinstance(videos, dict) else []
        filtered = [
            video for video in rows
            if isinstance(video, dict) and
            StalkerAddon.__extract_vod_year(video) == selected_year
        ]
        results = {
            'data': filtered,
            'total_items': len(filtered),
            'max_page_items': max(1, len(filtered)),
            'page': 1,
        }
        listing_params = dict(params or {})
        listing_params.update({
            'category': '{} - {}'.format(params.get('category', ''), selected_year),
            'page': 1,
            'update_listing': False,
            'search_term': '',
            'fav': 0,
        })
        StalkerAddon.__create_video_listing(results, listing_params)

    def __search_vod(self, params):
        """Search for videos"""
        Logger.debug('Search VOD {}'.format(params))

        # If the category is missing, show the category selection popup
        if not params.get('category'):
            categories = Api.get_vod_categories()
            selected_category = ask_for_category_selection(categories, 'VOD Category')
            if not selected_category:
                # User cancelled category selection - end directory properly
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)
                return
            params.update({
                'category': selected_category['title'],
                'category_id': selected_category['id']
            })

        search_term = ask_for_input(params['category'])
        search_term = str(search_term or '').strip()
        if not search_term:
            # Closing or cancelling the keyboard must finish the plugin call
            # immediately. Otherwise Kodi keeps waiting for a directory result
            # and displays the busy spinner for several seconds.
            xbmcplugin.endOfDirectory(
                G.get_handle(), succeeded=True,
                updateListing=False, cacheToDisc=False)
            return

        params.update({'action': 'vod_listing', 'update_listing': False,
                       'search_term': search_term, 'page': 1})
        is_context = str(params.get('isContextMenuSearch', 'true')).lower() == 'true'
        if is_context:
            url = G.get_plugin_url(params)
            func_str = f'Container.Update({url})'
            xbmc.executebuiltin(func_str)
            xbmcplugin.endOfDirectory(
                G.get_handle(), succeeded=True,
                updateListing=False, cacheToDisc=False)
        else:
            self.__list_vod(params)

    @staticmethod
    def __search_series(params):
        """Search series through the same category search engine as group search.

        The top-level SERIES SEARCH searches all regular series categories in
        parallel. A context-menu search that already contains a category keeps
        searching only that category.
        """
        params = dict(params or {})

        search_title = str(params.get('category') or 'SERIES SEARCH')
        search_term = str(ask_for_input(search_title) or '').strip()
        if not search_term:
            xbmcplugin.endOfDirectory(
                G.get_handle(), succeeded=True,
                updateListing=False, cacheToDisc=False)
            return

        try:
            if params.get('category_id') not in (None, ''):
                categories = [{
                    'id': params.get('category_id'),
                    'title': params.get('category') or 'SERIES'
                }]
                if StalkerAddon.__is_adult_category(params.get('category')):
                    if not StalkerAddon.__require_pin():
                        xbmcplugin.endOfDirectory(
                            G.get_handle(), succeeded=True,
                            updateListing=False, cacheToDisc=False)
                        return
            else:
                # The main SERIES SEARCH is a true global search. This avoids
                # relying on one selected portal category, which some portals
                # do not search correctly or return empty for.
                categories = [
                    category for category in media_search.get_categories(
                        'series', Api.get_series_categories)
                    if not StalkerAddon.__is_adult_category(
                        category.get('title') or category.get('name'))
                ]
        except Exception as exc:
            Logger.error('Failed to load SERIES search categories: {}'.format(exc))
            categories = []

        combined = media_search.search_categories(
            categories,
            lambda category: Api.get_series(category.get('id'), 1, search_term, 0),
            ('id', 'video_id', 'series_id'))

        results = build_result_page(combined)

        params.update({
            'action': 'series_listing',
            'category': params.get('category') or 'SERIES SEARCH',
            'category_id': params.get('category_id', 0),
            'page': 1,
            'update_listing': False,
            'search_term': search_term,
            'fav': 0
        })
        xbmcplugin.setPluginCategory(
            G.get_handle(), 'TiTan Serien - {} - {}'.format(
                params['category'], search_term))
        xbmcplugin.setContent(G.get_handle(), 'videos')
        StalkerAddon.__create_series_listing(results, params)

    def __vod_favorites_group_search(self, params):
        """Search across VOD categories filtered by country-group favorites (DE/AT/CH)."""
        Logger.debug('VOD Favorites Group Search {}'.format(params))
        tokens = set(get_configured_country_tokens(xbmcaddon.Addon() if xbmcaddon else None))

        search_term = str(ask_for_input(_LSTR(32100) or 'Meine Favoriten') or '').strip()
        if not search_term:
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
            return

        try:
            fav_categories = media_search.get_country_group_categories(
                'vod', Api.get_vod_categories, tokens)
        except Exception as exc:
            Logger.error('Failed to get VOD categories: {}'.format(exc))
            fav_categories = []

        combined = media_search.search_categories(
            fav_categories,
            lambda category: Api.get_videos(category['id'], 1, search_term, 0),
            ('id', 'video_id', 'vod_id'))

        results = build_result_page(combined)

        params = dict(params or {})
        params.update({'category': _LSTR(32100) or 'Meine Favoriten', 'category_id': 0, 'page': 1, 'update_listing': False, 'search_term': search_term, 'fav': 0})
        xbmcplugin.setPluginCategory(G.get_handle(), f"TiTan VOD - {_LSTR(32100) or 'Meine Favoriten'} - {search_term}")
        xbmcplugin.setContent(G.get_handle(), 'videos')
        StalkerAddon.__create_video_listing(results, params)

    def __series_favorites_group_search(self, params):
        """Search across SERIES categories filtered by country-group favorites (DE/AT/CH)."""
        Logger.debug('SERIES Favorites Group Search {}'.format(params))
        tokens = set(get_configured_country_tokens(xbmcaddon.Addon() if xbmcaddon else None))

        search_term = str(ask_for_input(_LSTR(32100) or 'Meine Favoriten') or '').strip()
        if not search_term:
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
            return

        try:
            fav_categories = media_search.get_country_group_categories(
                'series', Api.get_series_categories, tokens)
        except Exception as exc:
            Logger.error('Failed to get SERIES categories: {}'.format(exc))
            fav_categories = []

        combined = media_search.search_categories(
            fav_categories,
            lambda category: Api.get_series(category['id'], 1, search_term, 0),
            ('id', 'video_id', 'series_id'))

        results = build_result_page(combined)

        params = dict(params or {})
        params.update({'category': _LSTR(32100) or 'Meine Favoriten', 'category_id': 0, 'page': 1, 'update_listing': False, 'search_term': search_term, 'fav': 0})
        xbmcplugin.setPluginCategory(G.get_handle(), f"TiTan Serien - {_LSTR(32100) or 'Meine Favoriten'} - {search_term}")
        xbmcplugin.setContent(G.get_handle(), 'videos')
        StalkerAddon.__create_series_listing(results, params)

