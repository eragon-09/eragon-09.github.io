"""Central path management for writable profile data and media assets."""

from __future__ import absolute_import, division, unicode_literals
import os
import re
import unicodedata
import xbmcvfs
from .globals import G
from .constants import (
    LOCAL_TV_LISTS_FILENAME, LOCAL_TV_CATALOG_FILENAME, LOCAL_TV_GROUPS_FILENAME, FANART,
    LOCAL_TV_ART_SUBDIR, LOCAL_TV_DEFAULT_ART, LOCAL_TV_ROOT_ART,
    LOCAL_TV_TEMPLATE_SUBDIR,
)


def profile_dir():
    path = getattr(G.addon_config, 'token_path', '') or ''
    if path and not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def profile_file(filename):
    return os.path.join(profile_dir(), filename)


def local_tv_lists_path():
    return profile_file(LOCAL_TV_LISTS_FILENAME)


def local_tv_catalog_path():
    return profile_file(LOCAL_TV_CATALOG_FILENAME)


def local_tv_groups_path():
    return profile_file(LOCAL_TV_GROUPS_FILENAME)


def media_path(filename):
    return G.get_custom_thumb_path(filename)


def fanart_path():
    return media_path(FANART)


def bundled_art_dir():
    """Return the read-only artwork directory shipped with the add-on."""
    return os.path.join(G.addon_config.addon_data_path, 'resources', LOCAL_TV_ART_SUBDIR)


def user_art_dir():
    """Return the writable artwork override directory in the Kodi profile."""
    path = profile_file(LOCAL_TV_ART_SUBDIR)
    if path and not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def art_slug(value):
    """Convert a visible list name to a stable, filesystem-safe PNG basename."""
    text = str(value or '').strip().lower()
    replacements = {'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss'}
    for source, target in replacements.items():
        text = text.replace(source, target)
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
    text = re.sub(r'[^a-z0-9]+', '_', text).strip('_')
    return text or 'default'



def bundled_list_template_path(filename):
    """Return a read-only sender-list template shipped with the add-on."""
    return os.path.join(
        G.addon_config.addon_data_path, 'resources', LOCAL_TV_TEMPLATE_SUBDIR, filename
    )

def local_tv_art_path(list_name=None, root=False):
    """Resolve list artwork with user override, bundled art and default fallback."""
    filename = LOCAL_TV_ROOT_ART if root else '{}.png'.format(art_slug(list_name))
    for directory in (user_art_dir(), bundled_art_dir()):
        candidate = os.path.join(directory, filename)
        if xbmcvfs.exists(candidate):
            return candidate
    for directory in (user_art_dir(), bundled_art_dir()):
        fallback = os.path.join(directory, LOCAL_TV_DEFAULT_ART)
        if xbmcvfs.exists(fallback):
            return fallback
    return media_path('tv.png')
