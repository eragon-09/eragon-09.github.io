- First-run wizard now continues directly into the main menu in the same plugin invocation; removed the temporary Container.Update restart that exposed Kodi's file-folder view.
# History

## 2.5.0
- VOD-Bereich stabilisiert: fehlende Portaldaten, Artwork, Seitennavigation und Streamfehler werden robuster behandelt.
- Vollständig modernisierte Codebasis
- Modulare Architektur
- Vereinheitlichte Netzwerkverwaltung
- Optimierter Service-Layer
- Verbesserte Performance und Stabilität
- Kodi 20/21 kompatibel
- Experimenteller, portalübergreifender Genre-Filter für VOD-Kategorien (nutzt vorhandene Film-Metadaten, keine spezielle Portal-API).
- Ländergruppen-Eintrag in „VOD - Favoriten dieser Kategorie“ umbenannt.
- VOD-Kategorien öffnen jetzt ein Untermenü mit Filmen, Kategorien-Favoriten, Suche, Genres und Erscheinungsjahr.
- Rückwärtsnavigation der VOD- und Serien-Ländergruppen korrigiert; reguläre Menüebenen ersetzen den Kodi-Verlauf nicht mehr.
- Der VOD-Bereich wurde mit einem stabilen Kategorie-Untermenü einschließlich „Neu hinzugefügt“ abgeschlossen.
