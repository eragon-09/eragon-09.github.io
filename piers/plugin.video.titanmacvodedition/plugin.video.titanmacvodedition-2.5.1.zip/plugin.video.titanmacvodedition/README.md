# Titan MAC VOD Edition

Version 2.5.0

## Funktionen
- Portalverwaltung (MAC/Stalker)
- Live TV
- Video on Demand
- Serien
- XMLTV / EPG
- Favoriten
- Senderlogos
- Lokale TV-Gruppen
- Kodi 20/21 kompatibel

## Neuerungen in 2.5.0
- Modernisierte Codebasis
- Modulare Architektur
- Vereinheitlichte Netzwerkverwaltung
- Optimierter Service-Layer
- Verbesserte Stabilität und Performance
