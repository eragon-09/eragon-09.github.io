"""
YouTube-Datenbeschaffung ueber yt-dlp - FlimmerBox DE - TiTanX Lab.

Ersetzt die frueher genutzte YouTube Data API v3 komplett.
Kein API-Key mehr noetig: Suche, Playlists, Kanal-Uploads, Kanal-Playlists
und Kanal-Metadaten werden direkt von der YouTube-Website extrahiert.

Die eigentliche Wiedergabe laeuft weiterhin unveraendert ueber
plugin.video.youtube (siehe player.py) - daran aendert sich nichts.

Datei-Cache in userdata/addon_data, damit wiederholte Aufrufe schnell
bleiben und YouTube nicht unnoetig oft angefragt wird.
"""

import json
import os
import time
import hashlib
import sys
import traceback
import datetime as _dt
from urllib.parse import quote
from urllib.request import urlopen, Request

# Bekannter Python-Bug: datetime.strptime() laedt beim allerersten Aufruf
# intern lazy das Submodul '_strptime' nach. Unter bestimmten Bedingungen
# (Thread-Race, restriktive Android-Umgebung) kann dieser Lazy-Import
# fehlschlagen und zu "TypeError: 'NoneType' object is not callable" in
# yt-dlp fuehren. Einmaliges "Aufwaermen" beim Modul-Import behebt das.
try:
    _dt.datetime.strptime('2000-01-01', '%Y-%m-%d')
except Exception:
    pass

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()

LIB_DIR = xbmcvfs.translatePath(
    os.path.join(ADDON.getAddonInfo('path'), 'resources', 'lib')
)
if LIB_DIR not in sys.path:
    sys.path.insert(0, LIB_DIR)

# Zwei yt-dlp-Varianten sind eingebettet, da Kodi je nach Plattform ein
# unterschiedliches, mitgebrachtes Python nutzt (z.B. Windows-Builds oft
# noch Python 3.8, manche Android-/Fire-TV-Builds bereits 3.11+):
#   ytdlp_variants/py310/  -> aktuelle offizielle yt-dlp-Version (Python 3.10+)
#   ytdlp_variants/py38/   -> aeltere, manuell gepatchte Version (Python 3.8/3.9)
# Es wird zur Laufzeit anhand der tatsaechlichen Python-Version entschieden,
# welche zuerst versucht wird - pro Kodi-Plugin-Aufruf ist das ein frischer
# Prozess, daher gibt es keine Kollision zwischen den beiden gleichnamigen
# Paketen.
#
# FALLBACK: Ist die primaer gewaehlte Variante auf dem Geraet unvollstaendig
# oder beschaedigt (z.B. durch Windows-Pfadlaengenlimits beim Entpacken auf
# BlueStacks, Antivirus-Quarantaene einzelner Dateien oder einen fehlgeschlagenen
# Installationsvorgang), schlaegt der Import bzw. das spaetere Instanziieren
# von YoutubeDL() mit ModuleNotFoundError/ImportError fehl. In dem Fall wird
# automatisch einmalig auf die jeweils andere Variante umgeschaltet, statt das
# Addon komplett funktionsunfaehig zu lassen.
_VARIANT_ORDER = (
    ['py310', 'py38'] if sys.version_info >= (3, 10) else ['py38', 'py310']
)
_VARIANT = _VARIANT_ORDER[0]
_FALLBACK_TRIED = False


def _variant_dir(variant):
    return os.path.join(LIB_DIR, 'ytdlp_variants', variant)


def _unload_yt_dlp_modules():
    """Entfernt alle bereits importierten yt_dlp-Module aus sys.modules,
    damit ein erneuter Import garantiert die Dateien der neu gewaehlten
    Variante laedt (statt gecachter Module der alten, kaputten Variante)."""
    for mod_name in [m for m in sys.modules if m == 'yt_dlp' or m.startswith('yt_dlp.')]:
        del sys.modules[mod_name]


def _import_yt_dlp(variant):
    """Versucht, yt-dlp aus der angegebenen Variante zu laden.
    Gibt (YoutubeDL_Klasse, Versionsstring) zurueck oder wirft eine Exception."""
    other_dir = _variant_dir('py38' if variant == 'py310' else 'py310')
    target_dir = _variant_dir(variant)
    if other_dir in sys.path:
        sys.path.remove(other_dir)
    if target_dir not in sys.path:
        sys.path.insert(0, target_dir)

    from yt_dlp import YoutubeDL as _YDL
    from yt_dlp.version import __version__ as _ver
    return _YDL, _ver


try:
    YoutubeDL, _YTDLP_VERSION = _import_yt_dlp(_VARIANT)
except Exception as e:
    xbmc.log(f'FlimmerBoxYT: yt-dlp ({_VARIANT}) konnte nicht geladen werden: {e}', xbmc.LOGERROR)
    _fallback_variant = _VARIANT_ORDER[1]
    xbmc.log(f'FlimmerBoxYT: Versuche Fallback-Variante {_fallback_variant} ...', xbmc.LOGWARNING)
    try:
        _unload_yt_dlp_modules()
        YoutubeDL, _YTDLP_VERSION = _import_yt_dlp(_fallback_variant)
    except Exception as e2:
        YoutubeDL = None
        _YTDLP_VERSION = '?'
        _FALLBACK_TRIED = True
        xbmc.log(f'FlimmerBoxYT: Fallback-Variante {_fallback_variant} ebenfalls fehlgeschlagen: {e2}. '
                  f'yt-dlp steht nicht zur Verfuegung - Addon-Installation ist vermutlich '
                  f'unvollstaendig (bitte neu installieren).', xbmc.LOGERROR)
    else:
        _VARIANT = _fallback_variant
        _FALLBACK_TRIED = True
        xbmc.log(f'FlimmerBoxYT: yt-dlp {_YTDLP_VERSION} ueber Fallback-Variante '
                  f'{_VARIANT} geladen.', xbmc.LOGWARNING)
else:
    xbmc.log(f'FlimmerBoxYT: yt-dlp {_YTDLP_VERSION} geladen (Variante {_VARIANT}, '
              f'Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro})',
              xbmc.LOGINFO)

CACHE_DIR = xbmcvfs.translatePath(
    'special://profile/addon_data/{}/cache'.format(ADDON.getAddonInfo('id'))
)

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')

# Cache-Zeiten (Sekunden)
TTL_SEARCH          = 15 * 60
TTL_PLAYLIST_VIDEOS = 15 * 60
TTL_UPLOADS         = 30 * 60
TTL_CHANNEL_META    = 7 * 24 * 60 * 60
TTL_RESOLVE         = 30 * 24 * 60 * 60
TTL_DEAD_CHANNEL    = 24 * 60 * 60  # tote/geloeschte Kanaele nicht bei jedem Aufruf neu pruefen


# ---------------------------------------------------------------------------
# Cache-Hilfsfunktionen
# ---------------------------------------------------------------------------

def _ensure_cache_dir():
    try:
        if not xbmcvfs.exists(CACHE_DIR):
            xbmcvfs.mkdirs(CACHE_DIR)
    except Exception:
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
        except Exception:
            pass


def _cache_key(name, params):
    safe = json.dumps({'name': name, 'params': params}, sort_keys=True, default=str)
    return hashlib.md5(safe.encode('utf-8')).hexdigest() + '.json'


def _cache_path(name, params):
    _ensure_cache_dir()
    return os.path.join(CACHE_DIR, _cache_key(name, params))


def _read_cache(name, params, ttl):
    if not ttl:
        return None
    path = _cache_path(name, params)
    try:
        if not os.path.exists(path):
            return None
        with open(path, 'r', encoding='utf-8') as f:
            payload = json.load(f)
        if time.time() - payload.get('time', 0) > ttl:
            return None
        return payload.get('data')
    except Exception:
        return None


def _write_cache(name, params, data):
    if data is None:
        return
    path = _cache_path(name, params)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'time': time.time(), 'data': data}, f)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# yt-dlp Kern
# ---------------------------------------------------------------------------

class _YdlLogger:
    """Leitet yt-dlp Warnungen/Fehler sichtbar ins Kodi-Log um."""
    def debug(self, msg):
        if msg.startswith('[debug] '):
            return
        xbmc.log(f'FlimmerBoxYT yt-dlp trace: {msg}', xbmc.LOGDEBUG)

    def info(self, msg):
        xbmc.log(f'FlimmerBoxYT yt-dlp info: {msg}', xbmc.LOGDEBUG)

    def warning(self, msg):
        xbmc.log(f'FlimmerBoxYT yt-dlp warning: {msg}', xbmc.LOGWARNING)

    def error(self, msg):
        xbmc.log(f'FlimmerBoxYT yt-dlp ERROR: {msg}', xbmc.LOGERROR)


def _preferred_lang():
    """Liest die Einstellung 'Sprache fuer Titel & Beschreibungen' aus.

    Rueckgabe: ('de', 'DE') oder ('en', 'US') je nach Einstellung
    metadata_lang (0 = Deutsch, 1 = Englisch). Faellt bei fehlender/
    ungueltiger Einstellung auf Deutsch zurueck.
    """
    try:
        val = ADDON.getSetting('metadata_lang')
    except Exception:
        val = '0'
    if val == '1':
        return 'en', 'US'
    return 'de', 'DE'


def _ydl_opts(extra=None):
    hl, gl = _preferred_lang()
    accept_language = (
        'de-DE,de;q=0.9,en;q=0.8' if hl == 'de'
        else 'en-US,en;q=0.9,de;q=0.8'
    )
    opts = {
        'quiet': True,
        'no_warnings': False,
        'verbose': False,
        'ignoreerrors': True,
        'skip_download': True,
        'socket_timeout': 15,
        'nocheckcertificate': True,
        'noplaylist': False,
        'logger': _YdlLogger(),
        'http_headers': {
            'User-Agent': UA,
            'Referer': 'https://www.youtube.com/',
            'Accept-Language': accept_language,
        },
        # 'lang' steuert den 'hl'-Parameter im internen Innertube-Request
        # der YouTube-Extractor-Player-Clients (android/web) - das ist der
        # eigentliche Hebel fuer die Sprache von Titeln/Beschreibungen,
        # da diese Clients den Accept-Language-Header selbst ignorieren.
        'extractor_args': {
            'youtube': {
                'player_client': ['android', 'web'],
                'lang': [hl],
            },
        },
    }
    if extra:
        opts.update(extra)
    return opts


def _raw_diag(url):
    """Holt die Roh-Antwort unabhaengig von yt-dlp, um Bot-/Consent-Zwischenseiten
    zweifelsfrei zu erkennen (nur zu Diagnosezwecken, kein Cache)."""
    try:
        _hl, _ = _preferred_lang()
        _accept_language = (
            'de-DE,de;q=0.9,en;q=0.8' if _hl == 'de'
            else 'en-US,en;q=0.9,de;q=0.8'
        )
        req = Request(url, headers={
            'User-Agent': UA,
            'Accept-Language': _accept_language,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        })
        with urlopen(req, timeout=10) as r:
            status = getattr(r, 'status', getattr(r, 'code', '?'))
            final_url = r.geturl()
            body = r.read(6000).decode('utf-8', errors='ignore')
    except Exception as e:
        xbmc.log(f'FlimmerBoxYT raw-diag Ausnahme fuer {url}: {e}', xbmc.LOGWARNING)
        return

    markers = []
    for kw in ('consent.youtube.com', 'Before you continue', 'unusual traffic',
               'recaptcha', 'g-recaptcha', 'Our systems have detected',
               'sorry/index', 'Um YouTube in deiner Sprache', 'confirm you',
               'ytInitialData', 'accounts.google.com'):
        if kw.lower() in body.lower():
            markers.append(kw)

    xbmc.log(
        f'FlimmerBoxYT raw-diag: HTTP {status} finalURL={final_url!r} '
        f'bodyLen={len(body)} Marker={markers}',
        xbmc.LOGWARNING
    )


def _extract(url, extra=None, cache_name=None, ttl=0):
    """extract_info mit optionalem Datei-Cache."""
    global YoutubeDL, _YTDLP_VERSION, _VARIANT, _FALLBACK_TRIED

    cache_params = {'url': url, 'extra': extra}
    if cache_name and ttl:
        cached = _read_cache(cache_name, cache_params, ttl)
        if cached is not None:
            return cached

    if YoutubeDL is None:
        return None

    try:
        with YoutubeDL(_ydl_opts(extra)) as ydl:
            info = ydl.extract_info(url, download=False)
    except (ModuleNotFoundError, ImportError) as e:
        # Die aktuell geladene yt-dlp-Variante ist auf diesem Geraet
        # unvollstaendig/beschaedigt (fehlende Extractor-Datei o.ae.,
        # z.B. durch Windows-Pfadlaengenlimits auf BlueStacks oder
        # Antivirus-Quarantaene). Einmal pro Prozess automatisch auf die
        # jeweils andere Variante umschalten und den Aufruf wiederholen,
        # statt das Addon komplett funktionsunfaehig zu lassen.
        if _FALLBACK_TRIED:
            xbmc.log(f'FlimmerBoxYT yt-dlp: Fallback bereits versucht, gebe auf '
                      f'fuer {url}: {e}', xbmc.LOGERROR)
            xbmc.log(f'FlimmerBoxYT yt-dlp Traceback:\n{traceback.format_exc()}', xbmc.LOGERROR)
            return None

        _FALLBACK_TRIED = True
        _fallback_variant = 'py38' if _VARIANT == 'py310' else 'py310'
        xbmc.log(f'FlimmerBoxYT yt-dlp: Variante {_VARIANT} ist unvollstaendig/beschaedigt '
                  f'({e}). Schalte auf Variante {_fallback_variant} um und wiederhole.',
                  xbmc.LOGWARNING)
        try:
            _unload_yt_dlp_modules()
            YoutubeDL, _YTDLP_VERSION = _import_yt_dlp(_fallback_variant)
            _VARIANT = _fallback_variant
        except Exception as e2:
            xbmc.log(f'FlimmerBoxYT yt-dlp: Fallback-Variante {_fallback_variant} '
                      f'ebenfalls nicht ladbar: {e2}. Addon-Installation ist vermutlich '
                      f'unvollstaendig - bitte neu installieren.', xbmc.LOGERROR)
            YoutubeDL = None
            return None

        try:
            with YoutubeDL(_ydl_opts(extra)) as ydl:
                info = ydl.extract_info(url, download=False)
        except Exception as e3:
            xbmc.log(f'FlimmerBoxYT yt-dlp Ausnahme (nach Fallback) bei {url}: {e3}', xbmc.LOGERROR)
            xbmc.log(f'FlimmerBoxYT yt-dlp Traceback:\n{traceback.format_exc()}', xbmc.LOGERROR)
            return None
    except Exception as e:
        xbmc.log(f'FlimmerBoxYT yt-dlp Ausnahme bei {url}: {e}', xbmc.LOGERROR)
        xbmc.log(f'FlimmerBoxYT yt-dlp Traceback:\n{traceback.format_exc()}', xbmc.LOGERROR)
        return None

    if info is None:
        xbmc.log(f'FlimmerBoxYT yt-dlp lieferte keine Daten (info=None) fuer {url}', xbmc.LOGWARNING)
        _raw_diag(url)
        return None

    n_entries = len(info.get('entries') or []) if isinstance(info, dict) else 0
    if 'entries' in (info or {}) and n_entries == 0:
        xbmc.log(
            f'FlimmerBoxYT yt-dlp: 0 Eintraege fuer {url} | '
            f'_type={info.get("_type")!r} title={info.get("title")!r} '
            f'webpage_url={info.get("webpage_url")!r} '
            f'availability={info.get("availability")!r}',
            xbmc.LOGWARNING
        )

    if cache_name and ttl:
        _write_cache(cache_name, cache_params, info)
    return info


# ---------------------------------------------------------------------------
# Hilfsfunktionen zum Normalisieren
# ---------------------------------------------------------------------------

def _best_thumb(entry):
    thumbs = entry.get('thumbnails') or []
    if thumbs:
        return thumbs[-1].get('url', '')
    vid = entry.get('id', '')
    return f'https://i.ytimg.com/vi/{vid}/sddefault.jpg' if vid else ''


def _parse_entry(entry):
    if not entry:
        return None
    vid = entry.get('id', '')
    if not vid:
        url = entry.get('url', '') or entry.get('webpage_url', '')
        if 'watch?v=' in url:
            vid = url.split('watch?v=', 1)[1].split('&', 1)[0]
    if not vid:
        return None

    year = 0
    if entry.get('release_year'):
        year = int(entry.get('release_year'))

    upload_date = entry.get('upload_date', '') or ''
    published = ''
    if upload_date and len(upload_date) == 8:
        published = f'{upload_date[0:4]}-{upload_date[4:6]}-{upload_date[6:8]}T00:00:00Z'
        if not year:
            year = int(upload_date[0:4])

    desc = (entry.get('description') or '')[:300]

    return {
        'youtube_id':  vid,
        'title':       entry.get('title', '') or 'Ohne Titel',
        'description': desc,
        'channel':     entry.get('channel') or entry.get('uploader') or '',
        'thumb':       _best_thumb(entry),
        'year':        year,
        'published':   published,
    }


def _entries_of(info):
    if not info:
        return []
    return [e for e in (info.get('entries') or []) if e]


# ---------------------------------------------------------------------------
# Oeffentliche API (gleiche Signaturen wie zuvor mit YouTube Data API)
# ---------------------------------------------------------------------------

def has_api_key():
    """Kein Key mehr noetig - yt-dlp braucht keinen. Bleibt fuer Kompatibilitaet."""
    return YoutubeDL is not None


def search(query, max_results=25, page_token=None):
    """
    Sucht Videos auf YouTube per yt-dlp.
    page_token wird hier als einfacher Offset (String einer Zahl) genutzt.
    Gibt (videos, next_page_token) zurueck.
    """
    try:
        offset = int(page_token) if page_token else 0
    except Exception:
        offset = 0

    total = offset + max_results
    search_url = f'ytsearch{total}:{query}'

    info = _extract(
        search_url,
        extra={'extract_flat': 'in_playlist'},
        cache_name='search',
        ttl=TTL_SEARCH,
    )
    entries = _entries_of(info)
    page = entries[offset:offset + max_results]

    videos = [v for v in (_parse_entry(e) for e in page) if v]
    next_token = str(offset + max_results) if len(entries) >= total else None
    return videos, next_token


def get_uploads_playlist_id(channel_id):
    """
    Frueher: echte YouTube-Uploads-Playlist-ID (UU...).
    Jetzt: einfacher Marker, den get_playlist_videos() erkennt und
    in die /videos-URL des Kanals uebersetzt. Kein Netzwerkaufruf noetig.
    """
    if not channel_id:
        return ''
    return 'UPLOADS:' + channel_id


def _playlist_source_url(playlist_id):
    """Wandelt playlist_id oder UPLOADS:/POPULAR:-Marker in eine abrufbare URL um.

    Fuer Uploads wird bewusst NICHT die /videos-Tab-Seite verwendet:
    Deren JSON-Layout ("rich grid") hat sich bei YouTube mehrfach geaendert
    und wird von der (aus Python-3.8-Kompatibilitaetsgruenden alten)
    yt-dlp-Version nicht mehr erkannt -> 0 Eintraege trotz erfolgreicher
    Seitenabfrage. Die klassische "Uploads"-Playlist (Praefix UU statt UC)
    nutzt dagegen die stabile, kaum veraenderte Playlist-Ansicht.
    """
    if playlist_id.startswith('UPLOADS:'):
        channel_id = playlist_id.split(':', 1)[1]
        if channel_id.startswith('UC') and len(channel_id) >= 24:
            uploads_id = 'UU' + channel_id[2:]
            return f'https://www.youtube.com/playlist?list={uploads_id}'
        return f'https://www.youtube.com/channel/{channel_id}/videos'
    if playlist_id.startswith('POPULAR:'):
        channel_id = playlist_id.split(':', 1)[1]
        return f'https://www.youtube.com/channel/{channel_id}/videos?view=0&sort=p&flow=grid'
    return f'https://www.youtube.com/playlist?list={playlist_id}'


def get_playlist_videos(playlist_id, page_token=None, max_results=50):
    """
    Laedt Videos einer Playlist oder eines Kanal-Uploads-/Beliebt-Feeds per yt-dlp.
    Gibt (videos, next_page_token) zurueck.
    """
    if not playlist_id or YoutubeDL is None:
        return None, None

    # Kanaele, die zuletzt eindeutig fehlgeschlagen sind (geloescht/nicht
    # gefunden), fuer eine Weile ueberspringen statt bei jedem Aufruf erneut
    # mehrere Sekunden mit Wiederholungsversuchen zu verlieren.
    if _read_cache('dead_channel', {'id': playlist_id}, TTL_DEAD_CHANNEL):
        return [], None

    try:
        offset = int(page_token) if page_token else 0
    except Exception:
        offset = 0

    url = _playlist_source_url(playlist_id)
    info = _extract(
        url,
        extra={
            'extract_flat': 'in_playlist',
            'playliststart': offset + 1,
            'playlistend': offset + max_results,
        },
        cache_name='playlist_videos',
        ttl=TTL_PLAYLIST_VIDEOS,
    )

    if info is None:
        # Bei 'Beliebteste Videos' zuerst den Fallback auf die Uploads-Playlist
        # versuchen, bevor der Kanal als tot markiert wird.
        if playlist_id.startswith('POPULAR:') and offset == 0:
            channel_id = playlist_id.split(':', 1)[1]
            return get_playlist_videos('UPLOADS:' + channel_id, page_token=page_token, max_results=max_results)
        # Echter Fehlschlag (z.B. HTTP 404, "channel does not exist") ->
        # fuer TTL_DEAD_CHANNEL merken, damit "Neueste Uploads" nicht bei
        # jedem Aufruf erneut Zeit mit denselben toten Kanaelen verliert.
        _write_cache('dead_channel', {'id': playlist_id}, True)
        return [], None

    entries = _entries_of(info)

    # Fallback: 'Beliebteste Videos' (sort=p Tab) nutzt das brueckige
    # rich-grid-Layout. Wenn das 0 Treffer liefert (aber kein harter Fehler),
    # auf die stabile Uploads-Playlist ausweichen statt eine leere Liste zu zeigen.
    if not entries and playlist_id.startswith('POPULAR:') and offset == 0:
        channel_id = playlist_id.split(':', 1)[1]
        return get_playlist_videos('UPLOADS:' + channel_id, page_token=page_token, max_results=max_results)

    videos = [v for v in (_parse_entry(e) for e in entries) if v]
    next_token = str(offset + max_results) if len(videos) >= max_results else None
    return videos, next_token


def get_popular_videos(channel_id, page_token=None, max_results=50):
    """Beliebteste Videos eines Kanals (YouTube-Sortierung 'sort=p')."""
    if not channel_id:
        return [], None
    return get_playlist_videos('POPULAR:' + channel_id, page_token=page_token, max_results=max_results)


def resolve_handle_to_id(handle_or_query):
    """Loest ein @handle (oder einen Kanalnamen) zu einer UC...-Kanal-ID auf."""
    if not handle_or_query:
        return ''
    if handle_or_query.startswith('UC') and len(handle_or_query) >= 20:
        return handle_or_query

    # Kein echtes @handle (z.B. Anzeigename mit Leerzeichen) -> ueber die
    # Kanalsuche aufloesen statt eine ungueltige URL zu bauen.
    if ' ' in handle_or_query or not handle_or_query.replace('@', '').strip():
        results = search_channels(handle_or_query, max_results=1)
        return results[0]['id'] if results else ''

    handle = handle_or_query if handle_or_query.startswith('@') else '@' + handle_or_query.lstrip('@')
    url = f'https://www.youtube.com/{handle}'

    info = _extract(
        url,
        extra={'extract_flat': 'in_playlist', 'playlistend': 1},
        cache_name='resolve_handle',
        ttl=TTL_RESOLVE,
    )
    if not info:
        return ''
    return info.get('channel_id') or info.get('uploader_id') or info.get('id') or ''


def get_channel_metadata(channel_id):
    """Titel, Beschreibung, Icon und Abonnentenzahl eines Kanals."""
    if not channel_id:
        return {}

    url = f'https://www.youtube.com/channel/{channel_id}'
    info = _extract(
        url,
        extra={'extract_flat': 'in_playlist', 'playlistend': 1},
        cache_name='channel_meta',
        ttl=TTL_CHANNEL_META,
    )
    if not info:
        return {}

    thumbs = info.get('thumbnails') or []
    icon_url = thumbs[-1].get('url', '') if thumbs else ''
    subs = info.get('channel_follower_count')

    return {
        'title':            info.get('channel') or info.get('uploader') or info.get('title') or '',
        'description':      info.get('description') or '',
        'icon_url':         icon_url,
        'banner_url':       '',
        'subscriberCount':  f'{subs:,}'.replace(',', '.') if isinstance(subs, int) else '',
        'videoCount':       '',
    }


def get_channel_playlists(channel_id, page_token=None, max_results=25):
    """Playlists eines Kanals."""
    if not channel_id:
        return [], None
    try:
        offset = int(page_token) if page_token else 0
    except Exception:
        offset = 0

    url = f'https://www.youtube.com/channel/{channel_id}/playlists'
    info = _extract(
        url,
        extra={
            'extract_flat': 'in_playlist',
            'playliststart': offset + 1,
            'playlistend': offset + max_results,
        },
        cache_name='channel_playlists',
        ttl=TTL_UPLOADS,
    )
    entries = _entries_of(info)

    playlists = []
    for e in entries:
        pid = e.get('id', '')
        if not pid:
            continue
        playlists.append({
            'id':          pid,
            'name':        e.get('title', '') or 'Playlist',
            'description': e.get('description', '') or '',
            'thumb':       _best_thumb(e),
        })
    next_token = str(offset + max_results) if len(playlists) >= max_results else None
    return playlists, next_token


def search_channels(query, max_results=10):
    """
    Sucht YouTube-Kanaele per Schlagwort (yt-dlp, ueber die Such-URL
    mit YouTube-Filter 'nur Kanaele').
    """
    if not query or YoutubeDL is None:
        return []

    # sp=EgIQAg%3D%3D ist YouTubes Suchfilter "Typ: Kanal"
    search_url = (
        'https://www.youtube.com/results?search_query='
        + quote(query) + '&sp=EgIQAg%253D%253D'
    )
    info = _extract(
        search_url,
        extra={'extract_flat': 'in_playlist', 'playlistend': max_results},
        cache_name='channel_search',
        ttl=TTL_SEARCH,
    )
    entries = _entries_of(info)[:max_results]

    results = []
    for e in entries:
        cid = e.get('channel_id') or e.get('id', '')
        if not cid or not str(cid).startswith('UC'):
            continue
        results.append({
            'id':          cid,
            'name':        e.get('title', '') or e.get('channel', '') or cid,
            'handle':      '',
            'description': e.get('description', '') or '',
            'icon_url':    _best_thumb(e),
            'banner_url':  '',
        })
    return results
