#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import xbmc
from datetime import datetime


class XManagerLogger:
   
    
    def __init__(self, addon):
        self.addon = addon
        self.addon_id = addon.getAddonInfo('id')
        self.debug_enabled = addon.getSetting('debug_logging') == 'true'
    
    def _log(self, message, level=xbmc.LOGDEBUG):
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        formatted_message = f'[{self.addon_id}] [{timestamp}] {message}'
        xbmc.log(formatted_message, level)
    
    def debug(self, message):
        if self.debug_enabled:
            self._log(f'DEBUG: {message}', xbmc.LOGDEBUG)
    
    def info(self, message):
        self._log(f'INFO: {message}', xbmc.LOGINFO)
    
    def warning(self, message):
        self._log(f'WARNING: {message}', xbmc.LOGWARNING)
    
    def error(self, message):
        self._log(f'ERROR: {message}', xbmc.LOGERROR)
