# -*- coding: utf-8 -*-
import json
from datetime import date
from urllib.parse import urlencode, urlsplit
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'vod_oha'
SITE_NAME = 'VoD - Oha'
SITE_ICON = 'vod_oha.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON
SITE_GLOBAL_SEARCH = cConfig().getSetting('global_search_' + SITE_IDENTIFIER) != 'false'
BASE = 'https://www.mhub.mx/tmdb/'
OHA = 'https://oha.to/'
PAGE_SIZE = 15

def url(path, **kw):
    return BASE + path + '?' + urlencode(dict(region='US', language='de', **kw))

def fetch(address, cache=3600):
    try:
        r = cRequestHandler(address, caching=bool(cache), ignoreErrors=True)
        r.cacheTime = cache
        r.addHeaderEntry('Referer', OHA)
        r.addHeaderEntry('Origin', OHA.rstrip('/'))
        r.removeNewLines(False)
        return json.loads(r.request())
    except Exception as e:
        logger.info('Oha API: %s' % e)
        return {}

def params(**kw):
    p = ParameterHandler()
    for k,v in kw.items(): p.setParam(k,str(v))
    return p

def folder(g, name, fn, **kw):
    g.addFolder(cGuiElement(name,SITE_IDENTIFIER,fn),params(icon=SITE_ICON,**kw))

def catalog(kind, **kw):
    return url('catalog/%s/%s.json' % (kind,'movie' if kind=='video' else 'series'),**kw)

def load():
    g=cGui()
    for name,kind,sort in [('Angesagte Filme','video','trendingDay'),('Beliebte Filme','video','popularity'),('Aktuelle Filme','video','releaseDate'),('Angesagte Serien','series','trendingDay'),('Beliebte Serien','series','popularity')]:
        extra={'year':str(date.today().year)} if name=='Aktuelle Filme' else {}
        folder(g,name,'showEntries',sUrl=catalog(kind,sort=sort,**extra),kind=kind)
    for name,kind,filterid in [('Filme Genre','video','genre'),('Erscheinungsjahr','video','year'),('Serien Genre','series','genre')]:
        folder(g,name,'showFilters',kind=kind,filterid=filterid)
    folder(g,'Filme Suche','showSearchMovies'); folder(g,'Serien Suche','showSearchSeries')
    g.setEndOfDirectory()

def showFilters():
    p=ParameterHandler(); g=cGui(); kind=p.getValue('kind'); fid=p.getValue('filterid')
    for c in fetch(url('mhub-addon.json'),86400).get('catalogs',[]):
        if c.get('type')!=kind: continue
        for f in c.get('features',{}).get('filter',[]):
            if f.get('id')==fid:
                for v in f.get('values',[]): folder(g,v['name'],'showEntries',kind=kind,sUrl=catalog(kind,sort='popularity',**{fid:v['id']}))
    g.setEndOfDirectory()

def element(item, name, fn, media):
    e=cGuiElement(name,SITE_IDENTIFIER,fn); e.setMediaType(media)
    im=item.get('images') or {}; back=im.get('backdrops') or []
    if im.get('poster') or im.get('thumbnail'): e.setThumbnail(im.get('poster') or im.get('thumbnail'))
    if back: e.setFanart(back[0])
    if item.get('description'): e.setDescription(item['description'])
    if item.get('releaseDate'): e.setYear(item['releaseDate'][:4])
    return e

def showEntries(entryUrl=False,sGui=False,sSearchText=False):
    p=ParameterHandler(); g=sGui or cGui(); address=entryUrl or p.getValue('sUrl'); kind='series' if '/catalog/series/' in address else 'video'
    offset=int(p.getValue('offset') or 0) if not entryUrl else 0
    d=fetch(address); items=d.get('items',[]); rows=items[offset:offset+PAGE_SIZE]
    for i in rows:
        ident=str(i.get('ids',{}).get('tmdb') or i.get('id','')); name=i.get('name','')
        if not ident or not name: continue
        series=kind=='series'; e=element(i,name,'showSeasons' if series else 'showHosters','tvshow' if series else 'movie')
        g.addFolder(e,params(sId=ident,sName=name,kind=kind),series,len(rows))
    if not sGui:
        if offset+PAGE_SIZE<len(items): g.addNextPage(SITE_IDENTIFIER,'showEntries',params(sUrl=address,offset=offset+PAGE_SIZE))
        elif d.get('nextCursor'):
            from urllib.parse import parse_qsl,urlunsplit
            u=urlsplit(address); q=dict(parse_qsl(u.query)); q['cursor']=str(d['nextCursor']); nxt=urlunsplit((u.scheme,u.netloc,u.path,urlencode(q),''))
            if nxt!=address: g.addNextPage(SITE_IDENTIFIER,'showEntries',params(sUrl=nxt,offset=0))
        if not rows: g.showInfo()
        g.setView('tvshows' if kind=='series' else 'movies'); g.setEndOfDirectory()

def details(ident,kind): return fetch(url('item/%s/%s.json'%(kind,ident)))
def showSeasons():
    p=ParameterHandler(); g=cGui(); ident=p.getValue('sId'); d=details(ident,'series')
    for s in sorted(d.get('catalogs',[]),key=lambda x:int(x.get('season',0))):
        if 'season' not in s: continue
        e=element(s,s.get('name','Staffel '+str(s['season'])),'showEpisodes','season'); e.setSeason(str(s['season']))
        g.addFolder(e,params(sId=ident,sSeasonNr=s['season'],sName=p.getValue('sName')),True)
    g.setView('seasons'); g.setEndOfDirectory()

def showEpisodes():
    p=ParameterHandler(); g=cGui(); ident=p.getValue('sId'); season=p.getValue('sSeasonNr'); d=details(ident,'series')
    for s in d.get('catalogs',[]):
        if str(s.get('season'))!=str(season): continue
        items = s.get('items') or []
        if not items:
            catalog_id = s.get('id') or 'season_%s_%s' % (ident, season)
            items = fetch(url('catalog/video/%s.json' % catalog_id)).get('items') or []
        if not items:
            g.showInfo()
        for i in sorted(items,key=lambda x:int(x.get('episode',0))):
            n=str(i.get('episode',0)); e=element(i,n+' - '+i.get('name',''),'showHosters','episode'); e.setSeason(str(season)); e.setEpisode(n)
            g.addFolder(e,params(sId=ident,episodeId=i.get('id','tmdb:%s:%s:%s'%(ident,season,n)),sName=i.get('name','')),False)
    g.setView('episodes'); g.setEndOfDirectory()

def showHosters(sGui=False):
    p=ParameterHandler(); ident=p.getValue('sId'); ep=p.getValue('episodeId'); query={'region':'US','language':'de'}
    if ep: source=ep
    else:
        d=details(ident,'video'); imdb=d.get('ids',{}).get('imdb'); source='imdb:'+imdb if imdb else 'tmdb:'+ident
        if imdb: query['ids']='tmdb:'+ident
    d=fetch(OHA+'vod/source/video/'+source+'.json?'+urlencode(query),0); out=[]; seen=set()
    for i in d.get('sources',[]):
        if 'de' not in (i.get('languages') or []): continue
        link=i.get('url',''); host=urlsplit(link).hostname
        if not host or link in seen: continue
        seen.add(link); quality=str(i.get('quality') or '').rstrip('p'); name=host.removeprefix('www.') if hasattr(host,'removeprefix') else host
        out.append(dict(link=link,name=name,displayedName=name+' (DE)'+(' '+quality+'p' if quality else ''),quality=quality or '0',languageCode='(DE)'))
    if out: out.append('getHosterUrl')
    return out

def getHosterUrl(sUrl=False): return [{'streamUrl':sUrl,'resolved':False}]
def showSearchMovies():
    q=cGui().showKeyBoard(sHeading='Filme suchen')
    if q: showEntries(catalog('video',search=q))
def showSearchSeries():
    q=cGui().showKeyBoard(sHeading='Serien suchen')
    if q: showEntries(catalog('series',search=q))
def _searchMovies(oGui,sSearchText): showEntries(catalog('video',search=sSearchText),oGui)
def _searchSeries(oGui,sSearchText): showEntries(catalog('series',search=sSearchText),oGui)
def _search(oGui,sSearchText):
    _searchMovies(oGui,sSearchText); _searchSeries(oGui,sSearchText)

SCRAPER_SETTINGS = f'''
            <group id="plugin_vod_oha" label="30792">
                <setting id="plugin_vod_oha" type="boolean" label="30050" help="">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_vod_oha" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_vod_oha">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_vod_oha_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''

