# -*- coding: utf-8 -*-
# Python 3
# Primekiste.com - xStream Site Plugin
# API: /data/browse/ (Filmliste) + /data/watch/ (Streams)

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
import json
import re
from urllib.parse import urlsplit, parse_qs, quote_plus

SITE_IDENTIFIER = 'primekiste'
SITE_NAME = 'Primekiste'
SITE_ICON = 'primekiste.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

# Global search deaktivieren falls gewünscht
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'primekiste.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN   = 'https://' + DOMAIN
URL_BROWSE = URL_MAIN + '/data/browse/'
URL_WATCH  = URL_MAIN + '/data/watch/'
URL_LIST   = URL_BROWSE + '?lang=%s&type=%s&order_by=%s&page=%s'
URL_GENRE  = URL_BROWSE + '?lang=%s&type=%s&order_by=%s&genre=%s&page=%s'
URL_YEAR   = URL_BROWSE + '?lang=%s&type=%s&order_by=%s&year=%s&page=%s'
URL_CAST   = URL_BROWSE + '?lang=%s&type=%s&order_by=%s&cast=%s&page=%s'
URL_SEARCH_API = URL_BROWSE + '?lang=%s&keyword=%s&page=%s'

# Seitengroesse fuer Listenansicht
PAGE_SIZE = 15

SCRAPER_SETTINGS = f'''
            <group id="plugin_primekiste" label="30730">
                <setting id="plugin_primekiste" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_primekiste" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_primekiste">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_primekiste_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_primekiste">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_primekiste">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_primekiste.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>primekiste.com</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_primekiste">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_primekiste">false</dependency>
                    </dependencies>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_primekiste_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''


def _fetchJson(url, cacheTime=None):
    """JSON von der Primekiste-API holen."""
    oRequest = cRequestHandler(url, ignoreErrors=True)
    if cacheTime is not None:
        oRequest.cacheTime = cacheTime
    elif cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6
    oRequest.addHeaderEntry('Accept', 'application/json, text/plain, */*')
    oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequest.addHeaderEntry('Referer', URL_MAIN + '/')
    data = oRequest.request()
    if not data:
        return None
    try:
        return json.loads(data)
    except Exception:
        return None


def _fetchDesc(sId):
    """Beschreibung fuer einen Film/Serie aus Watch-API holen (langer Cache)."""
    try:
        obj = _fetchJson(URL_WATCH + '?_id=' + sId, cacheTime=60 * 60 * 24 * 7)
        if not obj:
            return ''
        aM = obj if isinstance(obj, dict) else {}
        if isinstance(aM.get('movie'), dict):
            aM = aM['movie']
        elif isinstance(aM.get('movies'), list) and aM['movies']:
            aM = aM['movies'][0]
        return str(aM.get('storyline') or aM.get('overview') or
                   aM.get('description') or aM.get('plot') or '')
    except Exception:
        return ''


def load():
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    sLang = '2'
    params.setParam('sLanguage', sLang)

    params.setParam('sUrl', URL_LIST % (sLang, 'movies', 'new', '1'))
    cGui().addFolder(cGuiElement('Neu hinzugefügt', SITE_IDENTIFIER, 'showEntries'), params)
    from datetime import date
    year = str(date.today().year)
    params.setParam('sUrl', URL_YEAR % (sLang, 'movies', 'new', year, '1'))
    cGui().addFolder(cGuiElement('Aktuelle Filme', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_LIST % (sLang, 'movies', 'votes', '1'))
    cGui().addFolder(cGuiElement('Beliebte Filme', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_LIST % (sLang, 'movies', 'name', '1'))
    cGui().addFolder(cGuiElement('Filme', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_LIST % (sLang, 'series', 'new', '1'))
    cGui().addFolder(cGuiElement('Serien - Neu', SITE_IDENTIFIER, 'showEntries'), params)

    # Genre Filme
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30551), SITE_IDENTIFIER, 'showGenreMMenu'), params)

    # Jahre
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30508), SITE_IDENTIFIER, 'showYearsMenu'), params)

    # Suche
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)
    cGui().setEndOfDirectory()




def _showGenreMenu(params=None):
    params = params or ParameterHandler()
    sLang  = '2'
    sType  = params.getValue('sType')
    sOrder = params.getValue('sOrder') or 'new'
    genres = ['Action', 'Abenteuer', 'Animation', 'Komödie', 'Krimi',
              'Dokumentarfilm', 'Drama', 'Familie', 'Fantasy', 'Historie',
              'Horror', 'Musik', 'Mystery', 'Liebesfilm', 'Science Fiction',
              'Thriller', 'Kriegsfilm', 'Western']
    for sGenre in genres:
        params.setParam('sUrl', URL_GENRE % (sLang, sType, sOrder, quote_plus(sGenre), '1'))
        cGui().addFolder(cGuiElement(sGenre, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showGenreMMenu():
    params = ParameterHandler()
    params.setParam('sType', 'movies')
    params.setParam('sOrder', 'new')
    _showGenreMenu(params)



def showYearsMenu():
    params = ParameterHandler()
    sLang = '2'
    import datetime
    current_year = datetime.datetime.now().year
    for year in range(current_year, 1929, -1):
        params.setParam('sUrl', URL_YEAR % (sLang, 'movies', 'new', str(year), '1'))
        cGui().addFolder(cGuiElement(str(year), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def _is_series(movie):
    tv = str(movie.get('tv', '')).lower()
    if tv in ('0', 'false'):
        return False
    if tv in ('1', 'true'):
        return True
    return (str(movie.get('type', '')).lower() in ('series', 'tvseries', 'tvshow', 'tv', 'show') or
            bool(movie.get('poster_path_season')) or
            str(movie.get('last_updated_epi') or '0') not in ('0', '') or
            bool(re.search(r'\b(?:staffel|season)\s+\d+\b', str(movie.get('title', '')), re.I)))


def _catalog_is_series(movie):
    return _is_series(movie)


def showEntries(entryUrl=False, sGui=False, sSearchText=False, supplied=None, next_action='showEntries'):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')

    # Aktuelle Seite aus URL lesen
    iPage = 1
    try:
        iPage = int(params.getValue('page')) or 1
    except Exception:
        pass

    # URL mit aktueller Seite aufbauen
    if 'page=' in entryUrl:
        sPageUrl = re.sub(r'page=\d+', 'page=%d' % iPage, entryUrl)
    else:
        sPageUrl = entryUrl + ('&' if '?' in entryUrl else '?') + 'page=%d' % iPage

    obj = supplied if supplied is not None else _fetchJson(sPageUrl)
    if not isinstance(obj, dict):
        logger.info('[primekiste] showEntries: API gab None zurück für %s' % sPageUrl)
        if not sGui:
            try: oGui.showInfo()
            except Exception: pass
            try: oGui.setEndOfDirectory()
            except Exception: pass
        return

    # API gibt verschiedene Keys zurück - alle prüfen
    movies = (obj.get('movies') or obj.get('series') or obj.get('items') or
              obj.get('results') or obj.get('data') or [])
    if not isinstance(movies, list):
        movies = []

    logger.info('[primekiste] showEntries: %d Einträge für %s' % (len(movies), sPageUrl[-60:]))

    if not movies and supplied is None:
        if not sGui:
            try: oGui.showInfo()
            except Exception: pass
            try: oGui.setEndOfDirectory()
            except Exception: pass
        return

    query = parse_qs(urlsplit(sPageUrl).query)
    kind = query.get('type', [''])[0]
    genre = query.get('genre', [''])[0].casefold()
    year = query.get('year', [''])[0]
    catalog = kind == 'movies' and query.get('order_by', [''])[0] == 'name'
    popular = kind == 'movies' and query.get('order_by', [''])[0] == 'votes'
    def matches(m):
        if not isinstance(m, dict):
            return False
        tv = _catalog_is_series(m) if (catalog or popular) else _is_series(m)
        if (kind == 'movies' and tv) or (kind == 'series' and not tv):
            return False
        if popular and re.search(r'\btrailer\b', str(m.get('title', '')), re.I):
            return False
        if not m.get('_id') or not m.get('title'):
            return False
        if sSearchText and not cParser.search(sSearchText, str(m.get('title', ''))):
            return False
        genres = m.get('genres') or []
        if isinstance(genres, str):
            genres = [genres]
        if genre and not any(str(g).casefold() == genre for g in genres):
            return False
        return not year or str(m.get('year', '')) == year
    movies = [m for m in movies if matches(m)]

    # Paginierung
    try:
        total_pages = int((obj.get('pager') or {}).get('totalPages') or obj.get('total_pages') or obj.get('totalPages') or 1)
    except Exception:
        total_pages = 1
    # Series pages are mixed with movies. Keep a cursor into the API page
    # so a full Kodi page never discards the remaining series.
    next_page = iPage + 1
    next_offset = 0
    if not sGui and not sSearchText:
        try:
            offset = max(0, int(params.getValue('seriesOffset') or 0))
        except (ValueError, TypeError):
            offset = 0
        collected = []
        seen = set()
        current = iPage
        scanned = 0
        batch = movies
        while True:
            scanned += 1
            for index in range(offset, len(batch)):
                item = batch[index]
                ident = str(item.get('_id') or '')
                if not ident or not item.get('title') or ident in seen:
                    continue
                seen.add(ident)
                collected.append(item)
                if len(collected) >= PAGE_SIZE:
                    break
            else:
                index = len(batch) - 1
            next_page = current
            next_offset = index + 1
            if next_offset >= len(batch):
                next_page = current + 1
                next_offset = 0
            if len(collected) >= PAGE_SIZE or current >= total_pages or scanned >= 12:
                break
            current += 1
            offset = 0
            url = re.sub(r'page=\d+', 'page=%d' % current, sPageUrl)
            data = _fetchJson(url)
            if not isinstance(data, dict):
                next_page, next_offset = current, 0
                break
            raw = (data.get('movies') or data.get('series') or data.get('items') or
                   data.get('results') or data.get('data') or [])
            if not isinstance(raw, list) or not raw:
                next_page, next_offset = current, 0
                break
            batch = [m for m in raw if matches(m)]
        movies = collected
        logger.info('[primekiste] list: %d entries from %d API pages' % (len(movies), scanned))
    else:
        movies = movies[:PAGE_SIZE]
    total = len(movies)

    isTvshow = kind == 'series'
    for movie in movies:
        sId      = str(movie.get('_id', ''))
        sName    = str(movie.get('title', ''))
        sYear    = str(movie.get('year', ''))
        # Poster: verschiedene moegliche Keys
        sThumbnail = (movie.get('poster_path') or movie.get('poster') or
                      movie.get('poster_path_season') or movie.get('backdrop_path') or '')
        sThumbnail = str(sThumbnail)
        # Fanart: backdrop bevorzugt
        sFanartUrl = (movie.get('backdrop_path') or movie.get('poster_path') or
                      movie.get('poster') or '')
        sFanartUrl = str(sFanartUrl)
        # Beschreibung: verschiedene moegliche Keys
        sDesc    = (movie.get('storyline') or movie.get('overview') or
                    movie.get('description') or movie.get('plot') or '')
        sDesc    = str(sDesc)
        sQuality = str(movie.get('quality') or '')
        sImdb    = str(movie.get('imdb_id', ''))
        isTvshow = _catalog_is_series(movie) if (catalog or popular) else _is_series(movie)

        if not sId or not sName:
            continue
        if sSearchText and not cParser.search(sSearchText, sName):
            continue

        # Thumbnail-URL vervollstaendigen
        if sThumbnail and not sThumbnail.startswith('http'):
            sThumbnail = 'https://image.tmdb.org/t/p/w780' + sThumbnail
        if sFanartUrl and not sFanartUrl.startswith('http'):
            sFanartUrl = 'https://image.tmdb.org/t/p/w780' + sFanartUrl

        # Titelformat: Name - (Jahr) [Qualität]
        sDisplayTitle = sName.strip()
        if sYear and len(sYear) == 4:
            sDisplayTitle += ' - (%s)' % sYear
        if sQuality and sQuality.strip():
            sDisplayTitle += ' [%s]' % sQuality.strip()
        oGuiElement = cGuiElement(sDisplayTitle, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if sFanartUrl:
            oGuiElement.setFanart(sFanartUrl)
        if sYear and len(sYear) == 4:
            oGuiElement.setYear(sYear)
        if not sDesc:
            try:
                sDesc = _fetchDesc(sId)
            except Exception:
                sDesc = ''
        if sDesc:
            try:
                oGuiElement.setDescription(sDesc)
            except Exception:
                pass

        params.setParam('sId',        sId)
        params.setParam('sName',      sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sImdb',      sImdb)
        params.setParam('sDesc',      sDesc[:200] if sDesc else '')  # für showSeasons/showEpisodes
        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText:
        try:
            if next_page <= total_pages:
                params.setParam('page', next_page)
                params.setParam('seriesOffset', next_offset)
                params.setParam('sUrl', entryUrl)
                oGui.addNextPage(SITE_IDENTIFIER, next_action, params)
        except Exception:
            pass
        # setView URL-basiert
        if 'type=series' in sPageUrl:
            oGui.setView('tvshows')
        elif 'type=movies' in sPageUrl:
            oGui.setView('movies')
        else:
            oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons():
    """Staffeln einer Serie anzeigen."""
    params     = ParameterHandler()
    sId        = params.getValue('sId')
    sThumbnail = params.getValue('sThumbnail')
    sDesc      = params.getValue('sDesc') if params.getValue('sDesc') else ''

    obj = _fetchJson(URL_WATCH + '?_id=' + sId)
    if not obj:
        logger.info('[primekiste] showSeasons: Watch-API blocked/None für sId=%s' % sId)
        # Cloudflare blockt → direkt showHosters versuchen
        try:
            hosters = showHosters()
        except Exception:
            hosters = None
        if not hosters:
            try: cGui().showInfo()
            except Exception: pass
            try: cGui().setEndOfDirectory()
            except Exception: pass
        return

    streams = obj.get('streams', [])
    # Alle vorhandenen Staffeln ermitteln
    seasons = sorted(set(
        str(s.get('s', '1')) for s in streams if s.get('s') is not None
    ), key=lambda x: int(x) if x.isdigit() else 0)

    if not seasons and str(obj.get("s", "")).isdigit():
        seasons = [str(obj["s"])]

    if not seasons:
        # Keine Staffelinfo → direkt Hoster zeigen
        try:
            showHosters()
        except Exception:
            pass
        return

    total = len(seasons)
    for sSeason in seasons:
        oGuiElement = cGuiElement('Staffel ' + sSeason, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season')
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if sDesc:
            oGuiElement.setDescription(sDesc)
        params.setParam('season', sSeason)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    """Episoden einer Staffel anzeigen."""
    params     = ParameterHandler()
    sId        = params.getValue('sId')
    sSeason    = params.getValue('season')
    sThumbnail = params.getValue('sThumbnail')
    sDesc      = params.getValue('sDesc') if params.getValue('sDesc') else ''

    obj = _fetchJson(URL_WATCH + '?_id=' + sId)
    if not obj:
        logger.info('[primekiste] showEpisodes: Watch-API blocked/None für sId=%s' % sId)
        try: cGui().showInfo()
        except Exception: pass
        try: cGui().setEndOfDirectory()
        except Exception: pass
        return

    streams = obj.get('streams', [])
    # Alle Episoden der gewählten Staffel
    episodes = sorted(set(
        str(s.get('e', '1')) for s in streams
        if str(s.get('s', '1')) == sSeason and s.get('e') is not None
    ), key=lambda x: int(x) if x.isdigit() else 0)

    if not episodes and str(obj.get('s', '')) == sSeason:
        match = re.search(r'-s(\d+)e(\d+)(?:/|$)', str(obj.get('filmpalast_url', '')), re.I)
        if match and int(match.group(1)) == int(sSeason):
            episodes = [str(i) for i in range(1, min(int(match.group(2)), 500) + 1)]

    if not episodes:
        cGui().showInfo()
        return

    total = len(episodes)
    for sEpisode in episodes:
        oGuiElement = cGuiElement('Episode ' + sEpisode, SITE_IDENTIFIER, 'showEpisodeHosters')
        oGuiElement.setMediaType('episode')
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if sDesc:
            oGuiElement.setDescription(sDesc)
        params.setParam('episode', sEpisode)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def _buildHosters(streams):
    """Stream-Liste in xStream-Hoster-Format umwandeln."""
    hosters = []

    for stream in streams:
        sUrl = stream.get('stream', '')
        if not sUrl:
            continue
        if any(x in sUrl for x in ('filmpalast', 'primekiste', DOMAIN)):
            continue
        if sUrl.startswith('//'):
            sUrl = 'https:' + sUrl
        sRelease = stream.get('release', '')
        sQuality = _quality(sRelease)
        sName = cParser.urlparse(sUrl).split('.')[0].strip() if sUrl else ''
        if cConfig().isBlockedHoster(sName)[0]:
            continue
        hoster = {
            'link': sUrl,
            'name': sName,
            'displayedName': '%s [I][%s][/I]' % (sName, sQuality) if sQuality else sName,
            'quality': sQuality
        }
        hosters.append(hoster)
    return hosters


def _quality(release):
    r = str(release).upper()
    if '4K' in r or '2160' in r:
        return '4K'
    if '1080' in r:
        return '1080p'
    if '720' in r:
        return '720p'
    if '.TS.' in r or '.CAM.' in r or 'TELESYNC' in r:
        return 'CAM'
    if 'SD' in r or '480' in r:
        return 'SD'
    return ''


def showHosters():
    """Stream-Links für einen Film anzeigen."""
    hosters = []
    params  = ParameterHandler()
    sId     = params.getValue('sId')

    obj = _fetchJson(URL_WATCH + '?_id=' + sId)
    if not obj:
        logger.info('[primekiste] showHosters: Watch-API blocked/None für sId=%s' % sId)
    if obj:
        streams = obj.get('streams') or []
        hosters = _buildHosters(streams)
        if not hosters:
            hosters = _movieFilmpalastHosters(obj)

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def _movieFilmpalastHosters(obj):
    url = urlsplit(str(obj.get('filmpalast_url') or ''))
    if url.scheme != 'https' or url.netloc != 'filmpalast.to':
        return []
    if not re.fullmatch(r'/stream/[^/]+/?', url.path) or re.search(r'-s\d+e\d+/?$', url.path, re.I):
        return []
    target = 'https://filmpalast.to' + url.path
    try:
        html = cRequestHandler(target, caching=False, bypass_dns=True).request()
        found, results = cParser.parse(html, 'hostName">([^<]+).*?(http[^"]+)')
        quality_found, quality = cParser.parseSingleResult(html, 'class="rb">.*?(\\d\\d\\d+)p\\.')
        hosters = []
        if found:
            for name, link in results:
                name = name.split(' HD')[0].strip()
                if cConfig().isBlockedHoster(name)[0]:
                    continue
                if any(x in name for x in ('Filemoon', 'Swiftload', 'Vidhide')):
                    link += '$$https://filmpalast.to/'
                q = quality if quality_found else ''
                hosters.append({'link': link, 'name': name, 'displayedName': name + (' [%sp]' % q if q else ''), 'quality': q})
        return hosters
    except Exception as exc:
        logger.info('[primekiste] Film-Fallback: %s' % type(exc).__name__)
        return []


def _episodeFilmpalastHosters(obj, season, episode):
    url = urlsplit(str(obj.get('filmpalast_url', '')))
    if url.scheme != 'https' or url.hostname != 'filmpalast.to':
        return []
    match = re.fullmatch(r'(/stream/[^/]+)-s(\d+)e(\d+)/?', url.path, re.I)
    if not match or not str(season).isdigit() or not str(episode).isdigit():
        return []
    if int(match.group(2)) != int(season) or int(episode) < 1:
        return []
    target = 'https://filmpalast.to%s-s%02de%02d' % (match.group(1), int(season), int(episode))
    try:
        html = cRequestHandler(target, caching=False, bypass_dns=True).request()
        found, results = cParser.parse(html, 'hostName">([^<]+).*?(http[^"]+)')
        quality_found, quality = cParser.parseSingleResult(html, 'class="rb">.*?(\\d\\d\\d+)p\\.')
        hosters = []
        if found:
            for name, link in results:
                name = name.split(' HD')[0].strip()
                if cConfig().isBlockedHoster(name)[0]:
                    continue
                if any(x in name for x in ('Filemoon', 'Swiftload', 'Vidhide')):
                    link += '$$https://filmpalast.to/'
                q = quality if quality_found else ''
                hosters.append({'link': link, 'name': name, 'displayedName': name + (' [%sp]' % q if q else ''), 'quality': q})
        return hosters
    except Exception as exc:
        logger.info('[primekiste] Serien-Fallback: %s' % type(exc).__name__)
        return []


def showEpisodeHosters():
    """Stream-Links für eine Episode anzeigen."""
    hosters  = []
    params   = ParameterHandler()
    sId      = params.getValue('sId')
    sSeason  = params.getValue('season')
    sEpisode = params.getValue('episode')

    obj = _fetchJson(URL_WATCH + '?_id=' + sId)
    if not obj:
        logger.info('[primekiste] showHosters: Watch-API blocked/None für sId=%s' % sId)
    if obj:
        streams = [s for s in obj.get('streams', [])
                   if str(s.get('s', '')) == sSeason and str(s.get('e', '')) == sEpisode]
        hosters = _buildHosters(streams)
        if not hosters:
            hosters = _episodeFilmpalastHosters(obj, sSeason, sEpisode)

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText:
        return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()



def _search(oGui, sSearchText):
    params = ParameterHandler()
    sLang = '2'
    sUrl = URL_SEARCH_API % (sLang, cParser.quotePlus(sSearchText), '1')
    showEntries(sUrl, oGui, sSearchText)
