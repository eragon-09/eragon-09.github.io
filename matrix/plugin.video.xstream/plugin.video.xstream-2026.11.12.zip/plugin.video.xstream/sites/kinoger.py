# -*- coding: utf-8 -*-
# Python 3
# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showGenre:     48 Stunden
# showEntries:    6 Stunden
# showSeasons:    6 Stunden
# showEpisodes:   4 Stunden

import re
import html
from urllib.parse import urljoin, urlsplit
from itertools import zip_longest as ziplist
import xbmcgui

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui


SITE_IDENTIFIER = 'kinoger'
SITE_NAME = 'KinoGer'
BUILD_ID = 'kinoger-titel-fix-2026-11-15'
SITE_ICON = 'kinoger.png'
logger.info('KinoGer build loaded: %s' % BUILD_ID)

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
_domain_config = cConfig()
_domain_setting = 'plugin_' + SITE_IDENTIFIER + '.domain'
DOMAIN = _domain_config.getSetting(_domain_setting)
if DOMAIN not in ('kinoger.com', 'kinoger.to'):
    DOMAIN = 'kinoger.com'
    _domain_config.setSetting(_domain_setting, DOMAIN)
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')  # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)  # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN
URL_TV = URL_MAIN + '/main/tv-shows/'
URL_SERIES = URL_MAIN + '/main/serie/'


MEINECLOUD_MOVIE = 'https://meinecloud.click/movie/%s'


def _normalize_urls(text):
    """Extract external http(s) URLs from HTML/JSON/JS responses."""
    if not text:
        return []
    text = html.unescape(text).replace('\\/', '/').replace('\\u0026', '&')
    urls = re.findall(r"https?://[^\s\"'<>]+", text, re.I)
    cleaned = []
    seen = set()
    blocked_parts = (
        'meinecloud.click/static/', 'meinecloud.click/assets/',
        'google.com/', 'gstatic.com/', 'cloudflare.com/',
        'schema.org/', 'w3.org/', 'jquery', '.css', '.js',
        '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico'
    )
    for url in urls:
        url = url.rstrip(');,]}>\\')
        low = url.lower()
        if any(part in low for part in blocked_parts):
            continue
        if 'meinecloud.click/movie/' in low:
            continue
        if url not in seen:
            seen.add(url)
            cleaned.append(url)
    return cleaned


def _resolve_meinecloud_movie(imdb_id, referer=''):
    """Fetch Meinecloud movie page and return embedded hoster URLs."""
    if not imdb_id:
        return []
    try:
        req = cRequestHandler(MEINECLOUD_MOVIE % imdb_id, caching=False, ignoreErrors=True)
        if referer:
            req.addHeaderEntry('Referer', referer)
        content = req.request()
        urls = _normalize_urls(content)
        logger.info('-> [KinoGer]: Meinecloud %s returned %d hoster links' % (imdb_id, len(urls)))
        return urls
    except Exception as exc:
        logger.error('-> [KinoGer]: Meinecloud request failed for %s: %s' % (imdb_id, exc))
        return []


def _build_hoster(url, quality='720'):
    """Create an xStream-compatible hoster dictionary."""
    if not url or url.startswith('/vod/'):
        return None
    try:
        name = cParser.urlparse(url)
        if not name or name.lower() in ('youtube.com', 'youtu.be'):
            return None
        if cConfig().isBlockedHoster(name)[0]:
            return None
        return {
            'link': url + 'DIREKT',
            'name': name,
            'displayedName': '%s [I][%sp][/I]' % (name, quality),
            'quality': quality
        }
    except Exception as exc:
        logger.error('-> [KinoGer]: Cannot build hoster for %s: %s' % (url, exc))
        return None


def load():  # KinoGer Hauptmenue
    logger.info('Load %s' % SITE_NAME)
    xbmcgui.Window(10000).clearProperty('xstream.kinoger.lastSearchText')
    oGui = cGui()
    for title, url in (
        ('Neu hinzugefügt', URL_MAIN + '/'),
        ('TV-Shows', URL_TV),
    ):
        params = ParameterHandler()
        params.setParam('sUrl', url)
        oGui.addFolder(cGuiElement(title, SITE_IDENTIFIER, 'showEntries'), params)
    oGui.addFolder(cGuiElement('Genres', SITE_IDENTIFIER, 'showGenre'))
    oGui.addFolder(cGuiElement('Erscheinungsjahr', SITE_IDENTIFIER, 'showArchive'))
    params = ParameterHandler()
    params.setParam('sUrl', URL_SERIES)
    oGui.addFolder(cGuiElement('Serien', SITE_IDENTIFIER, 'showEntries'), params)
    oGui.addFolder(cGuiElement('Suche', SITE_IDENTIFIER, 'showSearch'))
    oGui.setEndOfDirectory()


def showArchive():
    # Das DLE-Archiv gruppiert nach Hinzufuegedatum, nicht Erscheinungsjahr.
    # Jahres-URLs ohne Monatsuntermenue verwenden.
    from datetime import datetime
    oGui = cGui()
    for year in range(datetime.now().year, 2013, -1):
        params = ParameterHandler()
        params.setParam('sUrl', URL_MAIN + '/%d/' % year)
        oGui.addFolder(cGuiElement(str(year), SITE_IDENTIFIER, 'showEntries'), params)
    oGui.setEndOfDirectory()


def showGenre():
    params = ParameterHandler()
    # Genre-Liste direkt aus dem HTML der Sidebar (hardcoded)
    genres = [
        ('Alle Filme', URL_MAIN + '/'),
        ('Anime', URL_MAIN + '/main/anime/'),
        ('Action', URL_MAIN + '/main/action/'),
        ('Animation', URL_MAIN + '/main/animation/'),
        ('Abenteuer', URL_MAIN + '/main/abenteuer/'),
        ('Biography', URL_MAIN + '/main/biography/'),
        ('Bollywood', URL_MAIN + '/main/bollywood/'),
        ('Drama', URL_MAIN + '/main/drama/'),
        ('Dokumentation', URL_MAIN + '/main/dokumentation/'),
        ('Englisch', URL_MAIN + '/main/englisch/'),
        ('Familie', URL_MAIN + '/main/familie/'),
        ('Fantasy', URL_MAIN + '/main/fantasy/'),
        ('Geschichte', URL_MAIN + '/main/geschichte/'),
        ('Horror', URL_MAIN + '/main/horror/'),
        ('History', URL_MAIN + '/main/history/'),
        ('Krimi', URL_MAIN + '/main/krimi/'),
        ('Krieg', URL_MAIN + '/main/krieg/'),
        ('Komödie', URL_MAIN + '/main/komdie/'),
        ('Kurzfilm', URL_MAIN + '/main/kurzfilm/'),
        ('Music', URL_MAIN + '/main/music/'),
        ('Mystery', URL_MAIN + '/main/mystery/'),
        ('Musical', URL_MAIN + '/main/musical/'),
        ('Romance', URL_MAIN + '/main/romance/'),
        ('Tv Shows', URL_MAIN + '/main/tv-shows/'),
        ('Serie', URL_MAIN + '/main/serie/'),
        ('Sport', URL_MAIN + '/main/sport/'),
        ('Sci-Fi', URL_MAIN + '/main/sci-fi/'),
        ('Thriller', URL_MAIN + '/main/thriller/'),
        ('Trickfilm', URL_MAIN + '/main/trickfilm/'),
        ('Western', URL_MAIN + '/main/western/'),
        ('Zeichentrick', URL_MAIN + '/main/zeichentrick/'),
    ]
    for sName, sUrl in genres:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


_ENTRY_PATTERN = r'<div class="title">\s*<div class="begin"><img[^>]*class="img"[^>]*/>\s*<a href="([^"]+)">([^<]+)</a>.*?<div class="content_text">.*?<img src="([^"]+)"[^>]*alt="[^"]*"[^>]*>(.+?)<br><br'

def _search_blocked(page):
    return not page or page == 'CLOUDFLARE-SCHUTZ AKTIV' or 'cf-chl-' in page or 'Just a moment...' in page


def _listing_request(url, search=None, ignore=False):
    req = cRequestHandler(url, ignoreErrors=ignore)
    req.cacheTime = 60 * 60 * 6
    values = {'story': search, 'do': 'search', 'subaction': 'search', 'x': '0', 'y': '0', 'titleonly': '3', 'submit': 'submit'} if search else {'dlenewssortby': 'date', 'dledirection': 'desc', 'set_new_sort': 'dle_sort_main', 'set_direction_sort': 'dle_direction_main'}
    for key, value in values.items():
        req.addParameters(key, value)
    return req


def _clean_listing_title(title):
    title = html.unescape(title).strip()
    return re.sub(r'\s*(?:-\s*)?\(\s*\)\s*$', '', title).strip()


def _is_listing_notice(title):
    normalized = _clean_listing_title(title).casefold()
    return ('kinoger' in normalized and
            bool(re.search(r'dns[\s-]*sperren', normalized)))


def _parse_entries(page):
    found, entries = cParser.parse(page, _ENTRY_PATTERN)
    if not found:
        found, entries = cParser.parse(page, r'class="title".*?href="([^"]+)">([^<]+).*?src="([^"]+)(.*?)</a> </span>')
    return [entry for entry in entries if not _is_listing_notice(entry[1])] if found else []


def _title_matches(query, title):
    def normalize(value):
        return ' '.join(re.sub(r'[^\w]+', ' ', html.unescape(value).casefold()).split())
    query, title = normalize(query), normalize(title)
    return bool(query and (query in title or all(word in title.split() for word in query.split())))


def _catalogue_search(query):
    visited = set()
    for listing in (URL_MAIN + '/', URL_SERIES, URL_TV):
        page_url = listing
        matches = []
        for _ in range(2):
            if not page_url or page_url in visited:
                break
            visited.add(page_url)
            request = _listing_request(page_url, ignore=True)
            page = request.request()
            if _search_blocked(page):
                break
            entries = _parse_entries(page)
            if entries:
                matches.extend((entry, listing) for entry in entries if _title_matches(query, entry[1]))
            if matches:
                return matches
            found, next_url = cParser.parseSingleResult(page, r'href="([^"]+)">vorw')
            page_url = urljoin(page_url, next_url) if found else None
    return []


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    oRequest = _listing_request(entryUrl, sSearchText, ignore=(bool(sGui) or bool(sSearchText)))
    sHtmlContent = oRequest.request()
    if sSearchText and _search_blocked(sHtmlContent):
        logger.info('KinoGer: search blocked; checking catalogue listings')
        results = _catalogue_search(sSearchText)
    else:
        results = [(entry, entryUrl) for entry in _parse_entries(sHtmlContent)]
    if sSearchText:
        results = [(entry, source) for entry, source in results if _title_matches(sSearchText, entry[1])]
    if not results:
        if not sGui:
            oGui.showInfo()
        return

    results = results[:15]
    total = len(results)
    isTvshow = True if 'serienstream' in entryUrl else False  # Default basierend auf URL
    for (sUrl, sName, sThumbnail, sDummy), source in results:
        sName = _clean_listing_title(sName)
        # Serien werden via "Staffel" im Titel oder /serienstream-deutsch/-URL erkannt
        isTvshow = True if 'staffel' in sName.lower() or ('/main/serie/' in source or '/main/tv-shows/' in source or ';">S0' in sDummy) else False
        # Jahr aus Name extrahieren: "Der Super Mario Galaxy Film (2026)"
        sYear = ''
        isYear, aYear = cParser.parse(sName, r'(.*?)\s+\((\d{4})\)')
        if isYear and aYear:
            sName, sYear = aYear[0]
            sName = sName.strip().rstrip('-').strip()
        # Extra-Tags wie "*English*" oder "*Subbed*" rausziehen
        sName = re.sub(r'\s*\*[^*]+\*\s*', ' ', sName).strip()
        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail
        # Beschreibung aus dem Dummy-Block (alles vor dem Genre/Quality-Block)
        sDesc = sDummy
        # Erstes <div ...></div> (text-align right) raus
        sDesc = re.sub(r'<div[^>]*></div>', '', sDesc).strip()
        # Quality aus <b>(HD)</b>
        sQual = ''
        isQual, aQual = cParser.parseSingleResult(sDummy, r'<b>\(([^)]+)\)</b>')
        if isQual:
            sQual = aQual

        params = ParameterHandler()
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        if sYear:
            oGuiElement.setYear(sYear)
        if sDesc:
            oGuiElement.setDescription(sDesc[:500])  # Beschreibung trimmen
        if sQual:
            oGuiElement.setQuality(sQual)
        params.setParam('entryUrl', sUrl)
        params.setParam('searchTitle', sName)
        params.setParam('thumbnail', sThumbnail)
        oGui.addFolder(oGuiElement, params, isTvshow, total)
    if not sGui:
        # Pagination: <a href="URL">vorwaerts + ...</a> am Ende des Navigation-Blocks
        # Findet auf Movie-Listings + Genre. Search hat keine Pagination
        if not sSearchText:
            isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, r'href="([^"]+)">vorw')
            if isMatchNextPage:
                params.setParam('sUrl', urljoin(entryUrl, sNextUrl))
                oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sName = params.getValue('searchTitle')
    sThumb = params.getValue('thumbnail') if params.exist('thumbnail') else ''
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    # Staffel-Nummern aus den Episoden-IDs ziehen: <li id="serie-{STAFFEL}_{EPISODE}">
    pattern = r'<li id="serie-(\d+)_\d+">'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)

    # meinecloud-Fallback: alte DLE-Pattern leer (z.B. neue Serien wie Stranger Things
    # haben Daten nur via meinecloud serials.php Endpoint). Bei 0 Treffern
    # IMDB-ID extrahieren und meinecloud-Resolver fragen.
    if not aResult:
        _, aImdb = cParser.parse(sHtmlContent, r'(tt\d{7,9})')
        sImdbId = aImdb[0] if aImdb else ''
        if sImdbId:
            episodes = []
            if episodes:
                aResult = [str(ep['season']) for ep in episodes]

    if not aResult:
        return _legacy_seasons()

    # Unique Staffeln
    seasons = sorted(set(aResult), key=int)
    for sStaffel in seasons:
        oGuiElement = cGuiElement(cConfig().getLocalizedString(30512) + ' %s' % sStaffel, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season')
        oGuiElement.setSeason(sStaffel)
        if sThumb:
            oGuiElement.setThumbnail(sThumb)
        params.setParam('entryUrl', sUrl)
        params.setParam('staffel', sStaffel)
        params.setParam('searchTitle', sName)
        cGui().addFolder(oGuiElement, params, True)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sName = params.getValue('searchTitle')
    sStaffel = params.getValue('staffel')
    sThumb = params.getValue('thumbnail') if params.exist('thumbnail') else ''
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4  # 4 Stunden
    sHtmlContent = oRequest.request()
    # Pattern: <li id="serie-{STAFFEL}_{EPISODE}"><a href="#">Episoden N</a><ul...>HOSTER_BLOCK</ul></li>
    pattern = r'<li id="serie-' + re.escape(sStaffel) + r'_(\d+)"><a href="#">[^<]+</a>\s*<ul[^>]*>(.*?)</ul>\s*</li>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)

    # meinecloud-Fallback: alte DLE-Pattern leer. IMDB-ID extrahieren, meinecloud
    # fragen, Episoden der Staffel rausfiltern. Synthetischer hosterBlock
    # mit data-link='...' damit showHosters() unveraendert weiterarbeitet.
    aMeinecloudEpisodes = []
    if not aResult:
        _, aImdb = cParser.parse(sHtmlContent, r'(tt\d{7,9})')
        sImdbId = aImdb[0] if aImdb else ''
        if sImdbId:
            try:
                iStaffel = int(sStaffel)
            except (TypeError, ValueError):
                iStaffel = 0
            allEps = []
            aMeinecloudEpisodes = [ep for ep in allEps if ep['season'] == iStaffel]
            aMeinecloudEpisodes.sort(key=lambda ep: ep['episode'])
            # Tupel-Format kompatibel: (episode_str, synthetischer_hoster_block)
            aResult = [
                (str(ep['episode']), 'data-link="%s"' % ep['url'])
                for ep in aMeinecloudEpisodes
            ]

    if not aResult:
        cGui().showInfo()
        return

    total = len(aResult)
    for i, (sEpisode, sHosterBlock) in enumerate(aResult):
        # meinecloud-Mode: Episode-Titel aus den Dict-Daten verwenden, sonst Standard
        if aMeinecloudEpisodes:
            ep = aMeinecloudEpisodes[i]
            sEpTitle = '%s - S%sE%s — %s' % (sName, sStaffel.zfill(2), sEpisode.zfill(2), ep['title'])
        else:
            sEpTitle = '%s - S%sE%s' % (sName, sStaffel.zfill(2), sEpisode.zfill(2))
        oGuiElement = cGuiElement(sEpTitle, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setMediaType('episode')
        oGuiElement.setSeason(sStaffel)
        oGuiElement.setEpisode(sEpisode)
        if sThumb:
            oGuiElement.setThumbnail(sThumb)
        params.setParam('hosterBlock', sHosterBlock)
        params.setParam('searchTitle', sName)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def _legacy_seasons():
    params = ParameterHandler()
    # Parameter laden
    entryUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('thumbnail')
    sTVShowTitle = params.getValue('searchTitle')
    oRequest = cRequestHandler(entryUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    total = 0
    L11 = []
    isMatchsst, sstsContainer = cParser.parseSingleResult(sHtmlContent, 'sst.show.*?</script>')
    if isMatchsst:
        sstsContainer = sstsContainer.replace('[', '<').replace(']', '>')
        isMatchsst, L11 = cParser.parse(sstsContainer, "<'([^>]+)")
        if isMatchsst:
            total = max(total, len(L11))
    L22 = []
    isMatchollhd, ollhdsContainer = cParser.parseSingleResult(sHtmlContent, 'ollhd.show.*?</script>')
    if isMatchollhd:
        ollhdsContainer = ollhdsContainer.replace('[', '<').replace(']', '>')
        isMatchollhd, L22 = cParser.parse(ollhdsContainer, "<'([^>]+)")
        if isMatchollhd:
            total = max(total, len(L22))
    L33 = []
    isMatchpw, pwsContainer = cParser.parseSingleResult(sHtmlContent, 'pw.show.*?</script>')
    if isMatchpw:
        pwsContainer = pwsContainer.replace('[', '<').replace(']', '>')
        isMatchpw, L33 = cParser.parse(pwsContainer, "<'([^>]+)")
        if isMatchpw:
            total = max(total, len(L33))

    L44 = []
    isMatchgo, gosContainer = cParser.parseSingleResult(sHtmlContent, 'go.show.*?</script>')
    if isMatchgo:
        gosContainer = gosContainer.replace('[', '<').replace(']', '>')
        isMatchgo, L44 = cParser.parse(gosContainer, "<'([^>]+)")
        if isMatchgo:
            total = max(total, len(L44))

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '</b>([^"]+)<br><br>')
    for i in range(0, total):
        params = ParameterHandler()
        params.setParam('searchTitle', sTVShowTitle)
        params.setParam('thumbnail', sThumbnail)
        try:
            params.setParam('L11', L11[i])
        except Exception:
            pass
        try:
            params.setParam('L22', L22[i])
        except Exception:
            pass
        try:
            params.setParam('L33', L33[i])
        except Exception:
            pass
        try:
            params.setParam('L44', L44[i])
        except Exception:
            pass
        i = i + 1
        oGuiElement = cGuiElement('Staffel ' + str(i), SITE_IDENTIFIER, 'showLegacyEpisodes')
        oGuiElement.setMediaType('season')
        oGuiElement.setTVShowTitle(sTVShowTitle)
        oGuiElement.setSeason(i)
        oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        params.setParam('sDesc', sDesc)
        params.setParam('sSeasonNr', i)
        cGui().addFolder(oGuiElement, params, True, total)
        cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showLegacyEpisodes():
    params = ParameterHandler()
    sSeasonNr = params.getValue('sSeasonNr')
    sThumbnail = params.getValue('thumbnail')
    sTVShowTitle = params.getValue('searchTitle')
    sDesc = params.getValue('sDesc')
    L11 = []
    if params.exist('L11'):
        L11 = params.getValue('L11')
        isMatch1, L11 = cParser.parse(L11, "(http[^']+)")
    L22 = []
    if params.exist('L22'):
        L22 = params.getValue('L22')
        isMatch, L22 = cParser.parse(L22, "(http[^']+)")
    L33 = []
    if params.exist('L33'):
        L33 = params.getValue('L33')
        isMatch3, L33 = cParser.parse(L33, "(http[^']+)")
    L44 = []
    if params.exist('L44'):
        L44 = params.getValue('L44')
        isMatch4, L44 = cParser.parse(L44, "(http[^']+)")
    liste = ziplist(L11, L22, L33, L44)
    i = 0
    for sUrl in liste:
        i = i + 1
        oGuiElement = cGuiElement('Episode ' + str(i), SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setTVShowTitle(sTVShowTitle)
        oGuiElement.setSeason(sSeasonNr)
        oGuiElement.setEpisode(i)
        oGuiElement.setMediaType('episode')
        if sDesc:
            oGuiElement.setDescription(sDesc)
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        params.setParam('sLinks', sUrl)
        params.setParam('searchTitle', sTVShowTitle)
        cGui().addFolder(oGuiElement, params, False)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()



def showHosters():
    hosters = []
    params = ParameterHandler()

    # Serien-Episoden liefern den alten Hosterblock direkt.
    sHosterBlock = params.getValue('hosterBlock') if params.exist('hosterBlock') else ''
    sPageUrl = params.getValue('entryUrl') if params.exist('entryUrl') else ''
    sHtmlContent = ''

    if params.exist('sLinks'):
        _, direct_urls = cParser.parse(params.getValue('sLinks'), r"(http[^']+)")
    elif sHosterBlock:
        _, direct_urls = cParser.parse(sHosterBlock, r'data-link="([^"]+)"')
    else:
        if not sPageUrl:
            return []
        sHtmlContent = cRequestHandler(sPageUrl, caching=False, ignoreErrors=True).request()
        _, direct_urls = cParser.parse(sHtmlContent, r'data-link="([^"]+)"')

        # Aktuelle KinoGer-Filmseiten: IMDb-ID auslesen und Meinecloud direkt abrufen.
        if not direct_urls:
            imdb_match = re.search(r'(tt\d{7,10})', sHtmlContent or '')
            if imdb_match:
                direct_urls = _resolve_meinecloud_movie(imdb_match.group(1), referer=sPageUrl)

        # Legacy-Fallback für ältere show(...)-Blöcke.
        if not direct_urls:
            _, direct_urls = cParser.parse(sHtmlContent, r"show[^>]\d,[^>][^>]'([^']+)'")

    # Falls ein Meinecloud-Link selbst eingebettet ist, dessen Antwort expandieren.
    expanded = []
    for url in direct_urls or []:
        url = html.unescape(url).replace('\\/', '/')
        if 'meinecloud.click/movie/' in url:
            imdb_match = re.search(r'(tt\d{7,10})', url)
            expanded.extend(_resolve_meinecloud_movie(imdb_match.group(1), referer=sPageUrl) if imdb_match else [])
        else:
            expanded.append(url)

    seen = set()
    for url in expanded:
        if url in seen:
            continue
        seen.add(url)
        hoster = _build_hoster(url)
        if hoster:
            hosters.append(hoster)

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    if not sUrl:
        return []
    if sUrl.endswith('DIREKT'):
        sUrl = sUrl[:-6]
        try:
            request = cRequestHandler(sUrl, caching=False, ignoreErrors=True)
            request.request()
            sUrl = request.getRealUrl() or sUrl
        except Exception:
            pass
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    win = xbmcgui.Window(10000)
    sSearchText = win.getProperty('xstream.kinoger.lastSearchText')
    if not sSearchText:
        sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
        if not sSearchText:
            return
        win.setProperty('xstream.kinoger.lastSearchText', sSearchText)
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_MAIN + '/', oGui, sSearchText)
