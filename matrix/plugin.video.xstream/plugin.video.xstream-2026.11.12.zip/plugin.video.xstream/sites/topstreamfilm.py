# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showValue:     48 Stunden
# showEntries:    6 Stunden
# showEpisodes:   4 Stunden

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
import html as _html
import re
from urllib.parse import urljoin, urlsplit
from resources.lib.wrappers.devideosrc import get_sources, source_quality, probe_qualities
from resources.lib.wrappers.meinecloud import buildHosterFromUrl
import json
from urllib.parse import quote_plus, urlencode


def _normalise_stream_link(link):
    link = _html.unescape((link or "").strip()).replace("\\/", "/")
    if link.startswith("//"):
        link = "https:" + link
    return link if link.startswith("http") else ""


SITE_IDENTIFIER = 'topstreamfilm'
SITE_NAME = 'Topstreamfilm'
SITE_ICON = 'topstreamfilm.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.debug('globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'topstreamfilm.best') # Domain Auswahl über die xStream Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN
# URL_MAIN wird aus der konfigurierten Domain gebildet

URL_NEW = URL_MAIN + '/filme-online-sehen'
URL_ALL = URL_MAIN + '/filme-online-sehen'
URL_MOVIES = URL_MAIN + '/filme-online-sehen'
URL_POPULAR = URL_MAIN + '/im-gespraech'
URL_KINO = URL_MAIN + '/kinofilme'
URL_SERIES = URL_MAIN + '/serien'
URL_SOON = URL_MAIN + '/demnachst/'
URL_SEARCH = URL_MAIN + '/suche?q=%s'


SCRAPER_SETTINGS = f'''
            <group id="topstreamfilm" label="30732">
                <setting id="plugin_topstreamfilm" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_topstreamfilm" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <!-- Domain Überprüfung mit automatischer und manueller Anpassung -->
                <setting id="plugin_topstreamfilm_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_topstreamfilm.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>topstreamfilm.best</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                    </dependencies>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_topstreamfilm_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''

def _add_menu_folder(label, function, params=None, url='', content_type=''):
    p = ParameterHandler()
    if url:
        p.setParam('sUrl', url)
    if content_type:
        p.setParam('contentType', content_type)
    cGui().addFolder(cGuiElement(label, SITE_IDENTIFIER, function), p)


def load():
    logger.debug('Load %s' % SITE_NAME)
    params = ParameterHandler()
    _add_menu_folder('Neueste Filme', 'showEntries', params, URL_NEW, 'movie')
    _add_menu_folder('Kinofilme', 'showEntries', params, URL_KINO, 'movie')
    _add_menu_folder('Filme', 'showMovieMenu', params)
    _add_menu_folder('Serien', 'showSeriesMenu', params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), ParameterHandler())
    cGui().setEndOfDirectory()


def showMovieMenu():
    params = ParameterHandler()
    _add_menu_folder('Neueste Filme', 'showEntries', params, URL_NEW, 'movie')
    _add_menu_folder('Alle Filme', 'showEntries', params, URL_MOVIES, 'movie')
    _add_menu_folder('Kinofilme', 'showEntries', params, URL_KINO, 'movie')
    _add_menu_folder('Kategorien', 'showGenre', params, content_type='movie')
    _add_menu_folder('Jahre', 'showYears', params, content_type='movie')
    _add_menu_folder('Länder', 'showCountry', params, content_type='movie')
    _add_menu_folder('A-Z', 'showAZ', params, content_type='movie')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showMovieSearch'), ParameterHandler())
    cGui().setEndOfDirectory()


def showSeriesMenu():
    params = ParameterHandler()
    _add_menu_folder('Neue Serien', 'showEntries', params, URL_SERIES, 'tvshow')
    _add_menu_folder('Alle Serien', 'showEntries', params, URL_SERIES, 'tvshow')
    _add_menu_folder('Genres', 'showSeriesGenre', params, content_type='tvshow')
    _add_menu_folder('Jahre', 'showSeriesYears', params, content_type='tvshow')
    _add_menu_folder('Länder', 'showSeriesCountry', params, content_type='tvshow')
    _add_menu_folder('Beliebte Serien', 'showSeriesPopular', params, content_type='tvshow')
    _add_menu_folder('A-Z', 'showSeriesAZ', params, content_type='tvshow')
    cGui().addFolder(cGuiElement('Serien suchen', SITE_IDENTIFIER, 'showSeriesSearch'), ParameterHandler())
    cGui().setEndOfDirectory()



def _fetch(url):
    return cRequestHandler(url, caching=False).request() or ''


def _links(path, kind):
    for href, name in re.findall(r'<a\b[^>]*href="(/'+path+r'/[^"<>]+)"[^>]*>([^<]+)</a>', _fetch(URL_MAIN), re.I):
        _add_menu_folder(_html.unescape(name), 'showEntries', url=urljoin(URL_MAIN, href), content_type=kind)
    cGui().setEndOfDirectory()


def showGenre(): _links('genre', 'movie')
def showSeriesGenre(): _links('genre', 'tvshow')
def showYears(): _links('jahr', 'movie')
def showSeriesYears(): _links('jahr', 'tvshow')
def showCountry(): _links('land', 'movie')
def showSeriesCountry(): _links('land', 'tvshow')
def showAZ(): _links('catalog', 'movie')
def showSeriesAZ(): _links('catalog', 'tvshow')
def showSeriesPopular(): showEntries(URL_POPULAR, forcedType='tvshow')


def _cards(text):
    for tag, body in re.findall(r'(<a\b[^>]*class="cv"[^>]*>)(.*?)</a>', text, re.S):
        def attr(key):
            m = re.search(r'\b'+key+r'="([^"]*)"', tag)
            return _html.unescape(m.group(1)) if m else ''
        def field(cls):
            m = re.search(r'class="'+cls+r'"[^>]*>([^<]*)', body)
            return _html.unescape(m.group(1)).strip() if m else ''
        img = re.search(r'<img\b[^>]*src="([^"]+)"', body)
        yield dict(url=attr('href'), title=field('cv-t') or attr('title'), thumb=_html.unescape(img.group(1)) if img else '', meta=field('cv-m'), series='tag-serie' in body)


def _poster_hd(url):
    # Only change known TMDB-style image sizes, not arbitrary image URLs.
    return re.sub(r'(/t/p/)w(?:92|154|185|300|342|500)(/)', r'\g<1>w780\2', url or '')


class _FilmElement(cGuiElement):
    """Keep the display label separate from the metadata search title."""
    def __init__(self, name, year, function):
        super().__init__(name, SITE_IDENTIFIER, function)
        self._film_name = name
        self._film_year = year
        self._metadata_lookup = False

    def getTitle(self):
        if self._metadata_lookup:
            return self._film_name
        return self._film_name + (' - (%s)' % self._film_year if self._film_year else '')

    def getMeta(self, *args, **kwargs):
        self._metadata_lookup = True
        try:
            return super().getMeta(*args, **kwargs)
        finally:
            self._metadata_lookup = False

    def getThumbnail(self):
        return _poster_hd(super().getThumbnail())

    def setThumbnail(self, url):
        return super().setThumbnail(_poster_hd(url))


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText=False, forcedType=False, sortMode=False):
    gui = sGui or cGui()
    params = ParameterHandler()
    url = entryUrl or params.getValue('sUrl') or URL_MAIN
    kind = forcedType or params.getValue('contentType')
    text = _fetch(url)
    rows = [r for r in _cards(text) if r['url'] and (not kind or kind == ('tvshow' if r['series'] else 'movie'))]
    for r in rows:
        year = r['meta'] if re.fullmatch(r'\d{4}', r['meta']) else ''
        poster = _poster_hd(r['thumb'])
        el = _FilmElement(r['title'], year, 'showSeasons' if r['series'] else 'showHosters')
        el.setMediaType('tvshow' if r['series'] else 'movie')
        if poster:
            el.setThumbnail(poster)
        # Leave default fanart available for the existing TMDB metadata lookup.
        if year:
            el.setYear(year)
        p = ParameterHandler(); p.setParam('entryUrl', urljoin(url,r['url'])); p.setParam('sThumbnail',poster)
        p.setParam('sName', r['title'])
        gui.addFolder(el,p,r['series'],len(rows))
    if not sGui:
        nxt = re.search(r'<a\b[^>]*href="([^"]+)"[^>]*>\s*weitere Titel',text,re.I)
        if nxt:
            p=ParameterHandler(); p.setParam('sUrl',urljoin(url,_html.unescape(nxt.group(1)))); p.setParam('contentType',kind or '')
            gui.addNextPage(SITE_IDENTIFIER,'showEntries',p)
        view = 'tvshows' if kind == 'tvshow' or (rows and all(r['series'] for r in rows)) else 'movies'
        gui.setView(view)
        gui.setEndOfDirectory()


def _series(text):
    # Next.js serializes the initial state inside a JSON string in a script.
    for m in re.finditer(r'self\.__next_f\.push\((.*?)\)</script>',text,re.S):
        try:
            chunk=json.loads(m.group(1))[1]
            marker='"iniziale":'
            pos=chunk.find(marker)
            if pos>=0:
                data=json.JSONDecoder().raw_decode(chunk[pos+len(marker):])[0]
                if isinstance(data,dict) and data.get('imdb'): return data
        except (ValueError,IndexError,TypeError): pass
    return {}


def showSeasons():
    p=ParameterHandler(); url=p.getValue('entryUrl'); data=_series(_fetch(url)); gui=cGui()
    for s in data.get('stagioni',[]):
        num=s['season_number']; el=cGuiElement(s.get('name') or 'Staffel %s'%num,SITE_IDENTIFIER,'showEpisodes'); el.setMediaType('season'); el.setSeason(num)
        q=ParameterHandler(); q.setParam('entryUrl',url); q.setParam('season',str(num)); q.setParam('sThumbnail',p.getValue('sThumbnail')); gui.addFolder(el,q,True)
    gui.setView('seasons')
    gui.setEndOfDirectory()


def showEpisodes():
    p=ParameterHandler(); url=p.getValue('entryUrl'); season=int(p.getValue('season')); data=_series(_fetch(url)); gui=cGui()
    if data.get('stagione') != season:
        # Season URL convention is provisional; never display another season by mistake.
        data=_series(_fetch(url+(' & ' if '?' in url else '?').strip()+'season='+str(season)))
    for ep in data.get('episodi',[]):
        if ep.get('season_number')!=season or not ep.get('stream_available'): continue
        num=ep['episode_number']; el=cGuiElement('E%d - %s'%(num,ep.get('name') or 'Folge'),SITE_IDENTIFIER,'showEpisodeHosters'); el.setMediaType('episode'); el.setSeason(season); el.setEpisode(num); el.setThumbnail(ep.get('foto') or p.getValue('sThumbnail')); el.setDescription(ep.get('overview') or '')
        q=ParameterHandler(); q.setParam('entryUrl',url); q.setParam('imdb',data['imdb']); q.setParam('season',str(season)); q.setParam('episode',str(num)); gui.addFolder(el,q,False)
    gui.setView('episodes')
    gui.setEndOfDirectory()


def _hosters(player, referer):
    result=[]
    try:
        sources = get_sources(player,referer)
        candidates = [s for s in sources if buildHosterFromUrl(s['url'], sQuality='', includeQualitySuffix=False)]
        qualities = probe_qualities(candidates, player)
        for source, quality in zip(candidates, qualities):
            item = buildHosterFromUrl(source['url'], sQuality=quality, includeQualitySuffix=False)
            if item:
                item['displayedName'] = '%s [%sp]' % (item['name'], quality) if quality else item['name']
                result.append(item)
    except Exception as exc:
        logger.info('Topstreamfilm: DeVideoSRC error: %s'%type(exc).__name__)
    result.sort(key=lambda item: (item['name'].lower() == 'dropload', int(item['quality'] or 0)), reverse=True)
    return result+['getHosterUrl'] if result else []


def showHosters():
    url=ParameterHandler().getValue('entryUrl'); text=_fetch(url)
    m=re.search(r'<iframe\b[^>]*src="(https://devideosrc\.co/movie/tt\d+[^"<>]*)"',text)
    return _hosters(_html.unescape(m.group(1)),url) if m else []


def showEpisodeHosters():
    p=ParameterHandler(); imdb=p.getValue('imdb')
    if not re.fullmatch(r'tt\d+',imdb or ''):
        return []
    return _hosters('https://devideosrc.co/serial/%s/%d/%d?autoplay=1'%(imdb,int(p.getValue('season')),int(p.getValue('episode'))),p.getValue('entryUrl'))


def getHosterUrl(sUrl=False): return [{'streamUrl':sUrl,'resolved':False}]

def _search(oGui,sSearchText): showEntries(URL_SEARCH%quote_plus(sSearchText),oGui,sSearchText)
def _keyboard(kind=False):
    text=cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if text: showEntries(URL_SEARCH%quote_plus(text),forcedType=kind)
def showSearch(): _keyboard()
def showMovieSearch(): _keyboard('movie')
def showSeriesSearch(): _keyboard('tvshow')
