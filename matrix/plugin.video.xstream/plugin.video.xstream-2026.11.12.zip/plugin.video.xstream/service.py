# -*- coding: utf-8 -*-
# Python 3

import os
import time

from resources.lib.config import cConfig
from resources.lib import tools
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.handler.pluginHandler import cPluginHandler
from resources.lib import updateManager
from resources.lib.utils import translatePath
from resources.lib.tools import cCache
from resources.lib.tools import infoDialog
from xbmc import log, LOGINFO, LOGERROR

# Pfad der update.sha (ResolveURL)
RESOLVE_ADDON_DATA_PATH = translatePath(os.path.join('special://home/userdata/addon_data/script.module.resolveurl'))
RESOLVE_SHA = os.path.join(translatePath(RESOLVE_ADDON_DATA_PATH), "update_sha")


def delHtmlCache():
    # Html Cache beim KodiStart nach (X) Tage löschen
    deltaDay = int(cConfig().getSetting('cacheDeltaDay', 2))
    deltaTime = 60*60*24*deltaDay # Tage
    currentTime = int(time.time())
    # alle x Tage
    if currentTime >= int(cConfig().getSetting('lastdelhtml', 0)) + deltaTime:
        cRequestHandler('').clearCache() # Cache löschen
        cConfig().setSetting('lastdelhtml', str(currentTime))


def checkResolverUpdate():
    config = cConfig()
    forced = config.getSetting('enforceUpdate') == 'true'
    if not forced and config.getSetting('githubUpdateResolver') != 'true':
        return
    full = config.getSetting('update.notification') == 'full'
    log('xStream: ResolveURL startup update check', LOGINFO)
    try:
        if full:
            infoDialog(config.getLocalizedString(30112), sound=False, icon='INFO', time=6000)
        status = updateManager.resolverUpdate(True)
        if status is True:
            infoDialog('Resolver ' + config.getSetting('resolver.branch') + config.getLocalizedString(30116), sound=False, icon='INFO', time=6000)
        elif status is False:
            infoDialog(config.getLocalizedString(30117), sound=True, icon='ERROR')
        elif full:
            infoDialog(config.getLocalizedString(30118), sound=False, icon='INFO', time=6000)
    except Exception as exc:
        log('xStream: ResolveURL startup check failed: %s' % exc, LOGERROR)
        infoDialog(config.getLocalizedString(30117), sound=True, icon='ERROR')
    finally:
        if forced:
            config.setSetting('enforceUpdate', 'false')


def main():
    cCache().set(cConfig().getAddonInfo('id') + '_main', 'running')

    # Wenn neue settings vorhanden oder geändert in addon_data dann starte Pluginhandler und aktualisiere die PluginDB
    try:
        if cConfig().getSetting('newSetting') == 'true':
            cPluginHandler().getAvailablePlugins()
    except Exception:
        pass

    # getAvailablePlugins must be finished before the main menu can be started!
    cCache().set(cConfig().getAddonInfo('id') + '_main', 'finished')

    # Changelog Popup in den "settings.xml" ein bzw. aus schaltbar
    if cConfig().getSetting('popup.update.notification') == 'true':
        tools.changelog()

    # Html Cache beim KodiStart nach (X) Tage löschen
    delHtmlCache()

    # Kodi service runs independently of the plugin menu.
    checkResolverUpdate()

if __name__ == "__main__":
    main()
