# -*- coding: utf-8 -*-
# Python 3
#
# 24.01.23 - Heptamer: Korrektur getpriorities (nun werden alle Hoster gelesen und sortiert)
# 22.12.24 - Heptamer: m3u8 und mpd Files über inputstream adaptive abspielen lassen

import re
import xbmc
import xbmcgui 
import xbmcplugin
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from resources.lib.player import cPlayer, XstreamPlayer
from resources.lib import playback
from resources.lib.tools import logger


def _playback_title(title, year):
    """Remove only a trailing parenthesized metadata year, not title digits."""
    title = str(title or '')
    if not re.fullmatch(r'[0-9]{4}', str(year)):
        return title
    pattern = r'\s*(?:[-–—]\s*)?\(' + re.escape(str(year)) + r'\)\s*$'
    cleaned = title
    while True:
        candidate = re.sub(pattern, '', cleaned).strip()
        if not candidate or candidate == cleaned:
            return cleaned
        cleaned = candidate


class cHosterGui:
    SITE_NAME = 'cHosterGui'

    def __init__(self):
        self.maxHoster = int(cConfig().getSetting('maxHoster', 100))
        self.dialog = False
        self._silentResolveErrors = False
        self._resume_offset = None
        self._resume_cancelled = False
        self._auto_attempt = 0
        self._auto_playback = False

    # TODO: unify parts of play, download etc.
    def _getInfoAndResolve(self, siteResult):
        oGui = cGui()
        params = ParameterHandler()
        # get data
        mediaUrl = params.getValue('sMediaUrl')
        fileName = params.getValue('MovieTitle')
        try:
            try:
                import resolveurl as resolver
            except:
                import urlresolver as resolver
            # resolve
            if siteResult:
                mediaUrl = siteResult.get('streamUrl', False)
                mediaId = siteResult.get('streamID', False)
                if mediaUrl:
                    logger.info('-> [hoster]: resolve: ' + mediaUrl)
                    link = mediaUrl if siteResult['resolved'] else resolver.resolve(mediaUrl)
                elif mediaId:
                    logger.info('-> [hoster]: resolve: hoster: %s - mediaID: %s' % (siteResult['host'], mediaId))
                    link = resolver.HostedMediaFile(host=siteResult['host'].lower(), media_id=mediaId).resolve()
                else:
                    if not self._silentResolveErrors:
                        oGui.showError('xStream', cConfig().getLocalizedString(30134), 5)
                    return False
            elif mediaUrl:
                logger.info('-> [hoster]: resolve: ' + mediaUrl)
                link = resolver.resolve(mediaUrl)
            else:
                if not self._silentResolveErrors:
                    oGui.showError('xStream', cConfig().getLocalizedString(30134), 5)
                return False
        except resolver.resolver.ResolverError as e:
            logger.error('-> [hoster]: ResolverError: %s' % e)
            if not self._silentResolveErrors:
                oGui.showError('xStream', cConfig().getLocalizedString(30135), 7)
            return False
        except Exception as e:
            # Kool only: ResolveURL can propagate urllib HTTPError directly.
            if params.getValue('site') != 'vod_kool' or getattr(e, 'code', None) != 404:
                raise
            logger.error('-> [hoster]: Kool HTTP 404: %s' % e)
            if not self._silentResolveErrors:
                if self.dialog:
                    self.dialog.close()
                oGui.showError('Kool', 'Video nicht verfügbar. Bitte wähle einen anderen Hoster.', 7)
            return False
        # resolver response
        if link is not False:
            data = {'title': fileName, 'season': params.getValue('season'), 'episode': params.getValue('episode'), 'showTitle': params.getValue('TVShowTitle'), 'thumb': params.getValue('thumb'), 'link': link}
            return data
        return False

    def play(self, siteResult=False):
        logger.info('-> [hoster]: attempt to play file')
        data = self._getInfoAndResolve(siteResult)
        if not data:
            return False
        if self.dialog:
            try:
                self.dialog.close()
            except:
                pass

        vers = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])

        # Only Topstreamfilm Dropload: learn the actual HLS variants from the
        # already resolved stream. Never resolve a second time or alter the URL.
        try:
            params = ParameterHandler()
            embed = siteResult.get('streamUrl', '') if siteResult else ''
            from urllib.parse import urlsplit
            host = (urlsplit(embed).hostname or '').lower()
            if params.getValue('site') == 'topstreamfilm' and 'dropload' in host:
                from resources.lib.wrappers.devideosrc import remember_resolved_quality
                quality = remember_resolved_quality(embed, data['link'])
                if quality:
                    logger.info('Topstreamfilm: Dropload HLS maximum %sp' % quality)
        except Exception as exc:
            logger.debug('Topstreamfilm: HLS quality check failed: %s' % type(exc).__name__)
        logger.info('-> [hoster]: play file link: ' + str(data['link']))
        list_item = xbmcgui.ListItem(path=data['link'])
        #m3u8 und mpd via inputstream, exklusive Filemoon, da IA mit dem Hoster nicht unter Android läuft
        if not 'filemoon' in siteResult['streamUrl']:
            if '.m3u8' in data['link'] or '.mpd' in data['link']:
                list_item.setProperty("inputstream", "inputstream.adaptive")
                if '.mpd' in data['link']:
                    if vers < 21: list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                    list_item.setMimeType('application/dash+xml')
                else:
                    if vers < 21: list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                    list_item.setMimeType("application/vnd.apple.mpegurl")
                if '|' in data['link']:
                    data['link'], header = data['link'].split('|')
                    list_item.setProperty('inputstream.adaptive.stream_headers', header)
                    if vers > 19: list_item.setProperty('inputstream.adaptive.manifest_headers', header)

        if 'youtube' in data['link']:
            import time
            time.sleep(1)
        # Keep the original title in the playback context/history. Only the
        # player-facing metadata must omit the separately supplied year.
        import json
        params = ParameterHandler().getAllParameters()
        try:
            meta = json.loads(params.get('playbackMeta') or '{}').get('info', {})
            year = int(meta.get('year') or params.get('year') or params.get('sYear') or 0)
        except (ValueError, TypeError, AttributeError):
            year = 0
        info = {'Title': _playback_title(data['title'], year)}
        if 1000 <= year <= 9999:
            info['Year'] = year
        if data['thumb']:
            list_item.setArt(data['thumb'])
        if data['showTitle']:
            info['Episode'] = data['episode']
            info['Season'] = data['season']
            info['TVShowTitle'] = data['showTitle']

        #Neuer Video-Tag, mit Kodi 19 nicht kompatibel, daher folgende Abfrage
        kodi_version = xbmc.getInfoLabel('System.BuildVersion')
        if kodi_version[:2] < '20':
            list_item.setInfo(type="Video", infoLabels=info)
        else:
            vtag = list_item.getVideoInfoTag()
            vtag.setMediaType('video')
            if 'Title' in info:
                try:
                    vtag.setTitle(str(info['Title']))
                except: pass
            if 'Year' in info:
                try:
                    vtag.setYear(info['Year'])
                except: pass
            if 'Season' in info:
                try:
                    vtag.setSeason(int(info['Season']))
                except: pass
            if 'Episode' in info:
                try:
                    vtag.setEpisode(int(info['Episode']))
                except: pass
            if 'TVShowTitle' in info:
                try:
                    vtag.setTvShowTitle(info['TVShowTitle'])
                except: pass

        context = ParameterHandler().getAllParameters()
        if context.get('playbackFunction'):
            context['function']=context.pop('playbackFunction')
            context.pop('url',None); context.pop('isHoster',None)
        progress_key = getattr(self, "_original_progress_key", None) or playback.key(context)
        if self._resume_offset is None:
            self._resume_offset = playback.resume(progress_key) if playback.resume_enabled(context) else 0
            if self._resume_offset is None:
                self._resume_cancelled = True
                return False
        player = XstreamPlayer()
        list_item.setProperty('IsPlayable', 'true')
        if context.get('nextAuto') == 'true' or (self._auto_playback and self._auto_attempt > 1):
            logger.info('-> [hoster]: Next Episode direct playback')
            xbmc.Player().play(data['link'], list_item)
        elif cGui().pluginHandle > 0:
            xbmcplugin.setResolvedUrl(cGui().pluginHandle, True, list_item)
        else:
            xbmc.Player().play(data['link'], list_item)
        return cPlayer().startPlayer(player=player, progress_key=progress_key, offset=self._resume_offset, context=context, auto_retry=self._auto_playback)

    def addToPlaylist(self, siteResult=False):
        oGui = cGui()
        logger.info('-> [hoster]: attempt addToPlaylist')
        data = self._getInfoAndResolve(siteResult)
        if not data: return False
        logger.info('-> [hoster]: addToPlaylist file link: ' + str(data['link']))
        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(self.SITE_NAME)
        oGuiElement.setMediaUrl(data['link'])
        oGuiElement.setTitle(data['title'])
        if data['thumb']:
            oGuiElement.setThumbnail(data['thumb'])
        if data['showTitle']:
            oGuiElement.setEpisode(data['episode'])
            oGuiElement.setSeason(data['season'])
            oGuiElement.setTVShowTitle(data['showTitle'])
        if self.dialog:
            self.dialog.close()
        oPlayer = cPlayer()
        oPlayer.addItemToPlaylist(oGuiElement)
        oGui.showInfo(cConfig().getLocalizedString(30136), cConfig().getLocalizedString(30137), 5)
        return True

    def download(self, siteResult=False):
        from resources.lib.download import cDownload
        logger.info('-> [hoster]: attempt download')
        data = self._getInfoAndResolve(siteResult)
        if not data: return False
        logger.info('-> [hoster]: download file link: ' + data['link'])
        if self.dialog:
            self.dialog.close()
        oDownload = cDownload()
        oDownload.download(data['link'], data['title'])
        return True

    def sendToPyLoad(self, siteResult=False):
        from resources.lib.handler.pyLoadHandler import cPyLoadHandler
        logger.info('-> [hoster]: attempt download with pyLoad')
        data = self._getInfoAndResolve(siteResult)
        if not data: return False
        cPyLoadHandler().sendToPyLoad(data['title'], data['link'])
        return True

    def sendToJDownloader(self, sMediaUrl=False):
        from resources.lib.handler.jdownloaderHandler import cJDownloaderHandler
        params = ParameterHandler()
        if not sMediaUrl:
            sMediaUrl = params.getValue('sMediaUrl')
        if self.dialog:
            self.dialog.close()
        logger.info('-> [hoster]: call send to JDownloader: ' + sMediaUrl)
        cJDownloaderHandler().sendToJDownloader(sMediaUrl)

    def sendToJDownloader2(self, sMediaUrl=False):
        from resources.lib.handler.jdownloader2Handler import cJDownloader2Handler
        params = ParameterHandler()
        if not sMediaUrl:
            sMediaUrl = params.getValue('sMediaUrl')
        if self.dialog:
            self.dialog.close()
        logger.info('-> [hoster]: call send to JDownloader2: ' + sMediaUrl)
        cJDownloader2Handler().sendToJDownloader2(sMediaUrl)

    def sendToMyJDownloader(self, sMediaUrl=False, sMovieTitle='xStream'):
        from resources.lib.handler.myjdownloaderHandler import cMyJDownloaderHandler
        params = ParameterHandler()
        if not sMediaUrl:
            sMediaUrl = params.getValue('sMediaUrl')
        sMovieTitle = params.getValue('MovieTitle')
        if not sMovieTitle:
            sMovieTitle = params.getValue('Title')
        if not sMovieTitle:  # only temporary
            sMovieTitle = params.getValue('sMovieTitle')
        if not sMovieTitle:
            sMovieTitle = params.getValue('title')
        if self.dialog:
            self.dialog.close()
        logger.info('-> [hoster]: call send to My.JDownloader: ' + sMediaUrl)
        cMyJDownloaderHandler().sendToMyJDownloader(sMediaUrl, sMovieTitle)

    def __getPriorities(self, hosterList, filter=True):
        # Sort hosters based on their resolvers priority.
        ranking = []
        # handles multihosters but is about 10 times slower
        for hoster in hosterList:

            # we try to load resolveurl within the loop, making sure that the resolver loads new with every cycle
            try:
                import resolveurl as resolver
            except:
                import urlresolver as resolver
                 
            # accept hoster which is marked as resolveable by sitePlugin
            if hoster.get('resolveable', False):
                ranking.append([0, hoster])
                continue
             
            try:
                # serienstream VOE hoster = {'link': [sUrl, sName], aus array "[0]" True bzw. False
                link = hoster['link'][0] if isinstance(hoster['link'], list) else hoster['link']
                hmf = resolver.HostedMediaFile(url=link)
                #hmf = resolver.HostedMediaFile(url=hoster['link'])
            except:
                continue

            if not hmf.valid_url():
                hmf = resolver.HostedMediaFile(host=hoster['name'].lower(), media_id='dummy')

            if len(hmf.get_resolvers()):
                priority = False
                for resolver in hmf.get_resolvers():
                    # prefer individual priority
                    if not resolver.isUniversal():
                        priority = resolver._get_priority()
                        break
                    if not priority:
                        priority = resolver._get_priority()
                if priority:
                    ranking.append([priority, hoster])
            elif not filter:
                ranking.append([999, hoster])

            # Reset resolver so we have a fresh instance when loop starts again
            del(resolver) 

        return self._sort_quality([hoster for _, hoster in sorted(ranking, key=lambda item: item[0])])

    @staticmethod
    def _quality(hoster):
        for value in (hoster.get('quality'), hoster.get('displayedName'), hoster.get('name')):
            text = str(value or '')
            match = re.search(r'(?<!\d)(2160|1440|1080|720|576|540|480|360|240)\s*p?(?!\d)', text, re.I)
            if match:
                return int(match.group(1))
            for pattern, resolution in ((r'\b(?:4K|UHD)\b', 2160), (r'\b(?:FHD|FULL\s*HD)\b', 1080), (r'\bHD\b', 720)):
                if re.search(pattern, text, re.I):
                    return resolution
        return 0

    @staticmethod
    def _language(hoster):
        code = str(hoster.get('languageCode') or '').strip().lower().strip('()[] ')
        return {'de': 0, 'ger': 0, 'german': 0, 'deutsch': 0, '': 1, 'en': 2, 'eng': 2, 'english': 2}.get(code, 3)

    def _sort_quality(self, hosters):
        target = {'0':240, '1':360, '2':480, '3':720, '4':1080}.get(cConfig().getSetting('preferedQuality'))
        def key(hoster):
            q = self._quality(hoster)
            if target is None:
                quality = (0, -q)
            elif not q:
                quality = (3, 0)
            elif q <= target:
                quality = (0, target-q)
            else:
                quality = (2, q-target)
            return (self._language(hoster), quality)
        return sorted(hosters, key=key)

    def _quality_label(self, hoster):
        name = str(hoster.get('displayedName') or hoster.get('name') or 'Hoster')
        q = self._quality(hoster)
        if q and self._quality({'displayedName': name}) == q:
            return name
        return '%s [%s]' % (name, '%sp' % q if q else playback.tr(31004))

    def stream(self, playMode, siteName, function, url):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('xStream', cConfig().getLocalizedString(30138))
        # load site as plugin and run the function
        self.dialog.update(5, cConfig().getLocalizedString(30139))
        plugin = __import__(siteName, globals(), locals())
        function = getattr(plugin, function)
        self.dialog.update(10, cConfig().getLocalizedString(30140))
        if url:
            siteResult = function(url)
        else:
            siteResult = function()
        self.dialog.update(40)
        if not siteResult:
            self.dialog.close()
            cGui().showInfo('xStream', cConfig().getLocalizedString(30141))
            return
        # if result is not a list, make in one
        if not type(siteResult) is list:
            temp = [siteResult]
            siteResult = temp
        # field "name" marks hosters
        if 'name' in siteResult[0]:
            functionName = siteResult[-1]
            del siteResult[-1]
            if not siteResult:
                self.dialog.close()
                cGui().showInfo('xStream', cConfig().getLocalizedString(30142))
                return

            self.dialog.update(60, cConfig().getLocalizedString(30143))
            # Sitplugins VOD mit in automatische Abspielliste aufnehmen (Da Links bei der Überprüfung der Verfügbarkeit gekickt werden)
            if (playMode != 'jd') and (playMode != 'jd2') and (playMode != 'pyload') and (cConfig().getSetting('presortHoster') == 'true') and (playMode != 'myjd'):
            #if (not siteName.startswith('vod_')) and (playMode != 'jd') and (playMode != 'jd2') and (playMode != 'pyload') and (cConfig().getSetting('presortHoster') == 'true') and (playMode != 'myjd'):
                siteResult = self.__getPriorities(siteResult)
            elif playMode == 'play':
                siteResult = self._sort_quality(siteResult)
            if not siteResult:
                self.dialog.close()
                cGui().showInfo('xStream', cConfig().getLocalizedString(30144))
                return False
            self.dialog.update(90)
            # self.dialog.close()
            if len(siteResult) > self.maxHoster:
                siteResult = siteResult[:self.maxHoster - 1]
            if playback.mode(ParameterHandler().getAllParameters()) == 'List' and not ParameterHandler().exist('manual'):
                self.showHosterFolder(siteResult, siteName, functionName)
                return
            if len(siteResult) > 1:
                # choose hoster
                siteResult = self._chooseHoster(siteResult)
                if not siteResult:
                    return
            else:
                siteResult = siteResult[0]
            # get stream links
            logger.info(siteResult['link'])
            function = getattr(plugin, functionName)
            siteResult = function(siteResult['link'])
            # if result is not a list, make in one
            if not type(siteResult) is list:
                temp = [siteResult]
                siteResult = temp
        # choose part
        if len(siteResult) > 1:
            siteResult = self._choosePart(siteResult)
            if not siteResult:
                logger.info('-> [hoster]: no part selected')
                return
        else:
            siteResult = siteResult[0]

        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('xStream', cConfig().getLocalizedString(30145))
        self.dialog.update(95, cConfig().getLocalizedString(30146))
        if playMode == 'play':
            self.play(siteResult)
        elif playMode == 'download':
            self.download(siteResult)
        elif playMode == 'enqueue':
            self.addToPlaylist(siteResult)
        elif playMode == 'jd':
            self.sendToJDownloader(siteResult['streamUrl'])
        elif playMode == 'jd2':
            self.sendToJDownloader2(siteResult['streamUrl'])
        elif playMode == 'myjd':
            self.sendToMyJDownloader(siteResult['streamUrl'])
        elif playMode == 'pyload':
            self.sendToPyLoad(siteResult)

    def streamAuto(self, playMode, siteName, function):
        import sys
        from urllib.parse import urlencode
        original = ParameterHandler().getAllParameters()
        original['site'] = siteName
        self._cross_active = (playMode == 'play' and playback.enabled('playback_fallback')
                              and playback.kind(original) in ('movie', 'series')
                              and playback.enabled('playback_cross_' + playback.kind(original)))
        self._original_progress_key = playback.key(original)
        if self._streamAutoLocal(playMode, siteName, function):
            return True
        if not self._cross_active or self._resume_cancelled or xbmc.Monitor().abortRequested():
            return False
        old = sys.argv[2]
        try:
            for context in playback.fallback_targets(original):
                if self._resume_cancelled or xbmc.Monitor().abortRequested():
                    return False
                logger.info('-> [hoster]: cross-provider fallback: ' + context['site'])
                sys.argv[2] = '?' + urlencode(context)
                self._auto_attempt = max(1, self._auto_attempt)
                try:
                    if self._streamAutoLocal(playMode, context['site'], 'showHosters'):
                        return True
                except Exception as exc:
                    logger.warning('-> [hoster]: cross-provider failed: %s' % exc)
        finally:
            sys.argv[2] = old
        if not self._resume_cancelled and not xbmc.Monitor().abortRequested():
            xbmcgui.Dialog().ok('xStream', playback.tr(30999))
        return False

    def _streamAutoLocal(self, playMode, siteName, function):
        # Existing xStream AutoPlay path. It deliberately remains separate from
        # manual hoster selection; only sorting and user feedback are refined.
        logger.info('-> [hoster]: auto stream initiated')
        self._auto_playback = playMode == 'play' and playback.enabled('playback_fallback')
        if ParameterHandler().getValue('nextAuto') == 'true':
            logger.info('-> [hoster]: Next Episode action received')
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('xStream', cConfig().getLocalizedString(30138))
        self.dialog.update(5, cConfig().getLocalizedString(30139))
        plugin = __import__(siteName, globals(), locals())
        function = getattr(plugin, function)
        self.dialog.update(10, cConfig().getLocalizedString(30140))
        try:
            siteResult = function()
        except Exception as e:
            # A site request may fail before a hoster list exists (for example
            # an iframe/container timeout). Keep AutoPlay from leaking the
            # Python exception into Kodi's GUI. Resolver-specific code such as
            # dropload.py is intentionally untouched.
            logger.error('-> [hoster]: hoster discovery failed: %s' % e)
            try:
                self.dialog.close()
            except Exception:
                pass
            if not getattr(self, "_cross_active", False):
                xbmcgui.Dialog().ok('xStream', 'Stream konnte nicht gestartet werden.\nKeine Hoster konnten geladen werden.')
            return False
        if not siteResult:
            self.dialog.close()
            if not getattr(self, "_cross_active", False):
                cGui().showInfo('xStream', cConfig().getLocalizedString(30141))
            return False
        if not type(siteResult) is list:
            siteResult = [siteResult]

        if 'name' in siteResult[0]:
            self.dialog.update(90, cConfig().getLocalizedString(30143))
            functionName = siteResult[-1]
            del siteResult[-1]
            if siteName.startswith('dummy'):
                hosters = self._sort_quality(siteResult)
            else:
                hosters = self.__getPriorities(siteResult)
            if not hosters:
                self.dialog.close()
                if not getattr(self, "_cross_active", False):
                    cGui().showInfo('xStream', cConfig().getLocalizedString(30144))
                return False
            if self._auto_playback:
                blocked = {v.strip().lower() for v in cConfig().getSetting('blockedHoster','').split(',') if v.strip()}
                hosters = [v for v in hosters if str(v.get('name','')).lower() not in blocked]
                # Preserve language and quality ordering; health breaks ties only.
                def health_key(v):
                    name = str(v.get('name','')).lower()
                    failures, good = playback.hoster_health(siteName,name)
                    return (failures >= 2, -good)
                import itertools
                hosters = [v for _, group in itertools.groupby(hosters, key=lambda v: (self._language(v), self._quality(v))) for v in sorted(group,key=health_key)]
            hosters = hosters[:self.maxHoster]
            total = len(hosters)
            icon = 'special://home/addons/plugin.video.xstream/resources/icon.png'
            self._silentResolveErrors = True
            try:
                for count, hoster in enumerate(hosters):
                    if self._resume_cancelled or xbmc.Monitor().abortRequested():
                        return False
                    percent = (count + 1) * 100 // max(1, total)
                    display = self._quality_label(hoster)
                    try:
                        logger.info('-> [hoster]: try hoster %s' % display)
                        self.dialog = xbmcgui.DialogProgress()
                        self.dialog.create('xStream', playback.tr(30997))
                        self.dialog.update(percent, 'Hoster: %s' % display)
                        xbmcgui.Dialog().notification('xStream', playback.tr(30998) % display, icon, 1800, False)
                        result = getattr(plugin, functionName)(hoster['link'])
                        self._auto_attempt += 1
                        if self.__autoEnqueue(result, playMode):
                            if self._auto_playback: playback.hoster_health(siteName,str(hoster.get('name','')).lower(),True)
                            return True
                        if self._auto_playback and not self._resume_cancelled: playback.hoster_health(siteName,str(hoster.get('name','')).lower(),False)
                        if self._resume_cancelled: return False
                        if not playback.enabled('playback_fallback'): break
                    except Exception as e:
                        logger.error('-> [hoster]: playback with hoster %s failed: %s' % (display, e))
                        if not playback.enabled('playback_fallback'): break
                        # No error popup here: AutoPlay continues with the next hoster.
                        continue
            finally:
                self._silentResolveErrors = False
            try:
                self.dialog.close()
            except Exception:
                pass
            if not getattr(self, "_cross_active", False):
                xbmcgui.Dialog().ok('xStream', playback.tr(30999))
            return False

        elif 'resolved' in siteResult[0]:
            self._silentResolveErrors = True
            try:
                for stream in siteResult:
                    if self._resume_cancelled or xbmc.Monitor().abortRequested(): return False
                    self._auto_attempt += 1
                    try:
                        if self.__autoEnqueue([stream], playMode):
                            self.dialog.close()
                            return True
                        if not playback.enabled('playback_fallback'): break
                    except Exception:
                        pass
            finally:
                self._silentResolveErrors = False
            try:
                self.dialog.close()
            except Exception:
                pass
            if not getattr(self, "_cross_active", False):
                xbmcgui.Dialog().ok('xStream', 'Stream konnte nicht gestartet werden.\nKein verfügbarer Stream war erfolgreich.')
            return False


    def _chooseHoster(self, siteResult):
        dialog = xbmcgui.Dialog()
        titles = []
        for result in siteResult:
            titles.append(self._quality_label(result))
        index = dialog.select(cConfig().getLocalizedString(30149), titles)
        if index > -1:
            siteResult = siteResult[index]
            return siteResult
        else:
            logger.info('-> [hoster]: no hoster selected')
            return False

    def _choosePart(self, siteResult):
        self.dialog = xbmcgui.Dialog()
        titles = []
        for result in siteResult:
            titles.append(str(result['title']))
        index = self.dialog.select(cConfig().getLocalizedString(30150), titles)
        if index > -1:
            siteResult = siteResult[index]
            return siteResult
        else:
            return False

    def showHosterFolder(self, siteResult, siteName, functionName):
        oGui = cGui()
        total = len(siteResult)
        params = ParameterHandler()
        params.setParam('playbackFunction',params.getValue('function'))
        for hoster in siteResult:
            name = self._quality_label(hoster)
            oGuiElement = cGuiElement(name, siteName, functionName)
            oGuiElement.setThumbnail(str(params.getValue('thumb')))
            params.setParam('url', hoster['link'])
            params.setParam('isHoster', 'true')
            oGui.addFolder(oGuiElement, params, False, iTotal=total, isHoster=True)
        oGui.setEndOfDirectory()

    def __autoEnqueue(self, partList, playMode):
        # choose part
        if not partList:
            return False
        for i in range(len(partList) - 1, -1, -1):
            try:
                if playMode == 'play' and i == 0:
                    if not self.play(partList[i]):
                        return False
                elif playMode == 'download':
                    self.download(partList[i])
                elif playMode == 'enqueue' or (playMode == 'play' and i > 0):
                    self.addToPlaylist(partList[i])
            except:
                return False
        logger.info('-> [hoster]: autoEnqueue successful')
        return True


class Hoster:
    def __init__(self, name, link):
        self.name = name
        self.link = link