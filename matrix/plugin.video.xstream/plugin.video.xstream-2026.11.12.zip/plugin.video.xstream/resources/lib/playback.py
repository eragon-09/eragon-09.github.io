# -*- coding: utf-8 -*-
"""Persistent playback progress and MediaHub episode navigation."""
import os
import json
import time
import sqlite3
import importlib
import re
from html import unescape
from urllib.parse import urljoin, urlsplit
from urllib.parse import urlencode
import xbmc
import xbmcgui
import xbmcvfs
from resources.lib.config import cConfig

MEDIAHUB = ('vod_kool', 'vod_huhu', 'vod_oha', 'vod_vavoo')

def enabled(name):
    return cConfig().getSetting(name, 'true').lower() == 'true'

def tr(n): return cConfig().getLocalizedString(n)

def kind(p):
    if p.get('episodeId') or p.get('mediaType') in ('episode','tvshow','season') or (p.get('season') and p.get('episode')) or re.search(r'/staffel-\d+/episode-\d+', str(p.get('sUrl',''))): return 'series'
    if p.get('mediaType') == 'movie' or p.get('media') == 'movie' or p.get('site') in MEDIAHUB: return 'movie'
    return None

def migrate_hoster_settings():
    """Preserve explicit selections and migrate legacy inherited values once."""
    import xml.etree.ElementTree as ET
    cfg = cConfig()
    profile = xbmcvfs.translatePath(cfg.getAddonInfo('profile'))
    marker = os.path.join(profile, 'hoster-selection-migrated-v1')
    if os.path.exists(marker):
        return
    try:
        saved = {}
        path = os.path.join(profile, 'settings.xml')
        if os.path.exists(path):
            saved = {e.get('id'): e.text or e.get('value', '') for e in ET.parse(path).getroot().iter('setting')}
        valid = ('Dialog', 'List', 'Auto')
        old = saved.get('hosterSelect', cfg.getSetting('hosterSelect'))
        old = old if old in valid else 'Dialog'
        for k in ('movie', 'series'):
            name = 'hosterSelect_' + k
            value = saved.get(name)
            cfg.setSetting(name, value if value in valid else old)
        os.makedirs(profile, exist_ok=True)
        with open(marker, 'w') as f:
            f.write('1')
    except Exception as e:
        xbmc.log('xStream hoster settings migration: ' + str(e), xbmc.LOGWARNING)

def mode(p):
    migrate_hoster_settings()
    k = kind(p)
    old = cConfig().getSetting('hosterSelect')
    value = cConfig().getSetting('hosterSelect_'+k) if k else old
    return value if value in ('Dialog','List','Auto') else (old if old in ('Dialog','List','Auto') else 'Dialog')

def resume_enabled(p):
    k=kind(p)
    return enabled('playback_resume_'+k) if k else enabled('playback_resume')

def key(p):
    site = p.get('site', '')
    ep = p.get('episodeId', '')
    if site in MEDIAHUB and p.get('sId'):
        return 'tmdb:episode:' + ep.removeprefix('tmdb:') if ep and hasattr(ep, 'removeprefix') else ('tmdb:episode:' + ep.replace('tmdb:', '', 1) if ep else 'tmdb:movie:' + p['sId'])
    if site == 'serienstream':
        match = re.search(r'/staffel-(\d+)/episode-(\d+)/?$', urlsplit(p.get('sUrl','')).path)
        if match:
            ident = p.get('tmdbID') or urlsplit(p['sUrl']).path.split('/staffel-')[0]
            return 'episode:serienstream:%s:%s:%s' % (ident, *match.groups())
    if kind(p) is None: return None
    ident = p.get('tmdbID') or p.get('sId') or p.get('entryUrl') or p.get('sUrl') or p.get('TVShowTitle') or p.get('MovieTitle')
    if not ident:
        return None
    if kind(p) == 'series':
        ident=p.get('playbackParent') or p.get('TVShowTitle') or ident
        if not p.get('season') or not p.get('episode'):
            return None
        return 'episode:%s:%s:%s:%s' % (site, ident, p['season'], p['episode'])
    if p.get('tmdbID'): return 'tmdb:movie:'+str(p['tmdbID'])
    return 'movie:%s:%s' % (site, ident)

def status_identity(p):
    """Only explicit identifiers; never match unrelated titles by name."""
    k = kind(p)
    if k == 'movie':
        ident = p.get('tmdbID') or (p.get('sId') if p.get('site') in MEDIAHUB else '')
        if str(ident).isdigit(): return 'tmdb:movie:' + str(ident)
    if k == 'series':
        ep = re.fullmatch(r'tmdb:(\d+):(\d+):(\d+)', str(p.get('episodeId','')))
        if ep: return 'tmdb:episode:' + ':'.join(ep.groups())
        ident = p.get('playbackShowTmdb') or (p.get('sId') if p.get('site') in MEDIAHUB else '')
        try:
            if str(ident).isdigit() and int(p.get('season',0)) >= 0 and int(p.get('episode',0)) > 0:
                return 'tmdb:episode:%s:%d:%d' % (ident,int(p['season']),int(p['episode']))
        except (ValueError, TypeError, KeyError): pass
    return None


def status_context(p):
    k = key(p)
    canonical = status_identity(p)
    if not canonical: return status(k)
    try:
        with db() as c:
            row = c.execute('SELECT h.id FROM history h LEFT JOIN status_alias a ON a.id=h.id WHERE h.id=? OR h.id=? OR a.canonical=? ORDER BY h.updated DESC LIMIT 1', (k,canonical,canonical)).fetchone()
        return status(row[0] if row else k)
    except Exception: return status(k)


def db():
    path = xbmcvfs.translatePath(cConfig().getAddonInfo('profile'))
    os.makedirs(path, exist_ok=True)
    conn = sqlite3.connect(os.path.join(path, 'playback-progress.sqlite'), timeout=5)
    conn.execute('CREATE TABLE IF NOT EXISTS hidden_continue (id TEXT PRIMARY KEY)')
    conn.execute('CREATE TABLE IF NOT EXISTS next_items (id TEXT PRIMARY KEY, context TEXT)')
    conn.execute('CREATE TABLE IF NOT EXISTS progress (id TEXT PRIMARY KEY, position REAL, duration REAL)')
    conn.execute('CREATE TABLE IF NOT EXISTS history (id TEXT PRIMARY KEY, context TEXT, updated REAL, watched INTEGER)')
    conn.execute('CREATE TABLE IF NOT EXISTS seasons (parent TEXT, season INTEGER, context TEXT, PRIMARY KEY(parent,season))')
    conn.execute('CREATE TABLE IF NOT EXISTS episodes (parent TEXT, season INTEGER, episode INTEGER, context TEXT, PRIMARY KEY(parent,season,episode))')
    conn.execute('CREATE TABLE IF NOT EXISTS status_alias (id TEXT PRIMARY KEY, canonical TEXT)')
    conn.execute('CREATE INDEX IF NOT EXISTS status_alias_canonical ON status_alias(canonical)')
    conn.execute('CREATE TABLE IF NOT EXISTS playback_migrations (name TEXT PRIMARY KEY)')
    if not conn.execute("SELECT 1 FROM playback_migrations WHERE name='status_alias_v1'").fetchone():
        with conn:
            for ident, raw in conn.execute('SELECT id,context FROM history').fetchall():
                try:
                    canonical = status_identity(json.loads(raw))
                    if canonical: conn.execute('INSERT OR REPLACE INTO status_alias VALUES (?,?)',(ident,canonical))
                except Exception: pass
            conn.execute("INSERT OR IGNORE INTO playback_migrations VALUES ('status_alias_v1')")
    return conn

def read(k):
    if not k: return 0
    try:
        with db() as c:
            row = c.execute('SELECT position FROM progress WHERE id=?', (k,)).fetchone()
            return row[0] if row else 0
    except Exception: return 0

def save(k, pos, duration, ended=False, context=None):
    if not k: return
    try:
        with db() as c:
            if context and (ended or pos >= 1):
                canonical = status_identity(context)
                if canonical: c.execute('INSERT OR REPLACE INTO status_alias VALUES (?,?)',(k,canonical))
                c.execute('DELETE FROM hidden_continue WHERE id=?',(k,))
                c.execute('INSERT OR REPLACE INTO history VALUES (?,?,?,?)',(k,json.dumps(context),time.time(),int(ended or (duration > 0 and pos >= duration*.95))))
            if ended or (duration > 0 and pos >= duration * .95):
                c.execute('DELETE FROM progress WHERE id=?', (k,))
            elif pos >= 1:
                c.execute('INSERT OR REPLACE INTO progress VALUES (?,?,?)', (k,pos,duration))
    except Exception as e:
        xbmc.log('xStream progress: '+str(e), xbmc.LOGWARNING)

def resume(k):
    pos = read(k)
    if pos < 10: return 0
    h, rem = divmod(int(pos),3600); m,s = divmod(rem,60)
    choice = xbmcgui.Dialog().select(tr(30991), [tr(30992) % ('%02d:%02d:%02d' % (h,m,s)), tr(30993)])
    return pos if choice == 0 else (0 if choice == 1 else None)

def serienstream_next(p):
    from serienstream import cRequestHandler
    current = p.get('sUrl', '')
    match = re.fullmatch(r'(.+)/staffel-(\d+)/episode-(\d+)/?', urlsplit(current).path)
    if not match: return None
    base, season, episode = match.group(1), int(match.group(2)), int(match.group(3))
    if season < 1: return None
    def read_rows(sn):
        page = urljoin(current, base + '/staffel-%s' % sn)
        html = cRequestHandler(page, caching=False).request() or ''
        rows = re.findall(r'(<tr[^>]*class="episode-row[^"]*"[^>]*>)(.*?)</tr>', re.sub(r'\s+', ' ', html), re.DOTALL)
        result = {}
        for tag, row in rows:
            if 'watch-link' not in row: continue
            nr = re.search(r'episode-number-cell">\s*(\d+)\s*<', row)
            link = re.search(r"""onclick="window\.location='([^']+)'""", tag)
            if not nr or not link: continue
            title = re.search(r'episode-title-(?:ger|eng)"[^>]*title="([^"]+)"', row)
            target = urljoin(page, unescape(link.group(1)))
            if urlsplit(target).netloc != urlsplit(current).netloc: continue
            result[int(nr.group(1))] = (target, unescape(title.group(1)) if title else '')
        return page, result
    page, rows = read_rows(season)
    if episode not in rows: return None
    en = episode + 1
    if en not in rows:
        if any(n > episode for n in rows) or not enabled('playback_next_season'): return None
        season += 1
        page, rows = read_rows(season)
        en = 1
    if en not in rows: return None
    target, title = rows[en]
    nxt = dict(p)
    nxt.pop('playbackMeta', None)
    nxt.update(site='serienstream', function='showHosters', playMode='play',
               sUrl=target, entryUrl=page, season=season, episode=en,
               title='Episode %s - %s' % (en,title), MovieTitle=title or 'Episode %s' % en,
               mediaType='episode', nextAuto='true')
    return nxt

def next_episode(p):
    if p.get('site') == 'serienstream':
        try: return serienstream_next(p)
        except Exception as e:
            xbmc.log('xStream SerienStream next episode: '+str(e), xbmc.LOGWARNING)
            return None
    if p.get('site') not in MEDIAHUB or not p.get('episodeId'): return cached_next(p)
    try:
        season, episode = map(int,p['episodeId'].split(':')[-2:])
        if season < 1: return None
        mod = importlib.import_module(p['site'])
        ident = p['sId']; detail = mod.details(ident,'series')
        catalogs = sorted((x for x in detail.get('catalogs',[]) if int(x.get('season',0)) >= season),key=lambda x:int(x['season']))
        for cat in catalogs:
            sn = int(cat['season'])
            if sn != season and (not enabled('playback_next_season') or sn != season+1): return None
            items = cat.get('items') or mod.fetch(mod.url('catalog/video/%s.json' % (cat.get('id') or 'season_%s_%s' % (ident,sn)))).get('items',[])
            if not items: return None
            for item in sorted(items,key=lambda x:int(x.get('episode',0))):
                en = int(item.get('episode',0))
                if en != (episode+1 if sn == season else 1): continue
                return dict(site=p['site'],function='showHosters',playMode='play',sId=ident,episodeId=item.get('id') or 'tmdb:%s:%s:%s'%(ident,sn,en),sName=item.get('name',''),MovieTitle=item.get('name',''),TVShowTitle=detail.get('name',''),season=sn,episode=en,mediaType='episode',nextAuto='true',playbackMeta=json.dumps(dict(info={'plot':item.get('description','')},thumb=(detail.get('images') or {}).get('poster',''),fanart=((detail.get('images') or {}).get('backdrops') or [''])[0])))
    except Exception as e:
        xbmc.log('xStream next episode: '+str(e),xbmc.LOGWARNING)
    return None

def offer_next(p):
    if not enabled('playback_next'): return
    nxt = next_episode(p)
    if not nxt: return
    try:
        with db() as c: c.execute('INSERT OR REPLACE INTO next_items VALUES (?,?)', (key(p), json.dumps(nxt)))
    except Exception: pass
    delay = max(5,min(30,int(cConfig().getSetting('playback_delay','15'))))
    dialog = xbmcgui.DialogProgress()
    dialog.create(tr(30990), tr(30994) % (nxt['season'],nxt['episode'])+'\n'+nxt['MovieTitle'])
    monitor = xbmc.Monitor()
    try:
        for remaining in range(delay,0,-1):
            dialog.update(int((delay-remaining)*100/delay), tr(30994) % (nxt['season'],nxt['episode'])+'\n'+nxt['MovieTitle']+'\n'+tr(30995) % remaining)
            if dialog.iscanceled() or monitor.waitForAbort(1): return
        if dialog.iscanceled(): return
    finally: dialog.close()
    # RunPlugin starts a separate action invocation, not a nested PlayMedia resolution.
    xbmc.log('xStream Next Episode: dispatch S%sE%s via RunPlugin' % (nxt['season'], nxt['episode']), xbmc.LOGINFO)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.xstream/?'+urlencode(nxt)+')', False)

# Record the actual playable episode routes emitted by the scraper, not guessed URLs.
def remember_episode(p):
    parent=p.get('playbackParent')
    if not parent or kind(p)!='series': return
    try:
        sn,en=int(p['season']),int(p['episode'])
        if sn<1 or en<1: return
        with db() as c:
            c.execute('INSERT OR REPLACE INTO episodes VALUES (?,?,?,?)',(parent,sn,en,json.dumps(p)))
    except Exception: pass

def cached_next(p):
    try:
        parent=p['playbackParent']; sn,en=int(p['season']),int(p['episode'])
        with db() as c:
            row=c.execute('SELECT context FROM episodes WHERE parent=? AND season=? AND episode=?',(parent,sn,en+1)).fetchone()
            if not row and enabled('playback_next_season'):
                later=c.execute('SELECT 1 FROM episodes WHERE parent=? AND season=? AND episode>?',(parent,sn,en)).fetchone()
                if not later:
                    row=c.execute('SELECT context FROM episodes WHERE parent=? AND season=? AND episode=1',(parent,sn+1)).fetchone()
                    if not row:
                        route=c.execute('SELECT context FROM seasons WHERE parent=? AND season=?',(parent,sn+1)).fetchone()
                        if route: row=load_season(json.loads(route[0]),parent,sn+1)
        if row:
            nxt=json.loads(row[0]); nxt['nextAuto']='true'; return nxt
    except Exception: pass
    return None

def status(k):
    if not k: return (0,0,False)
    try:
        with db() as c:
            r=c.execute('SELECT position,duration FROM progress WHERE id=?',(k,)).fetchone()
            h=c.execute('SELECT watched FROM history WHERE id=?',(k,)).fetchone()
        return (r[0],r[1],False) if r else (0,0,bool(h and h[0]))
    except Exception: return (0,0,False)

def series_identity(p):
    ident = p.get('sId') if p.get('site') in MEDIAHUB else p.get('tmdbID')
    if str(ident).isdigit(): return 'tmdb:' + str(ident)
    parent = p.get('playbackParent') or p.get('TVShowTitle')
    if not parent:
        parent = re.sub(r'/staffel-\d+/episode-\d+/?$', '', p.get('sUrl', ''))
    return str(p.get('site')) + ':' + str(parent or key(p))


def continue_watching(section='', page=1):
    import sys
    import xbmcplugin
    from resources.lib.gui.gui import cGui
    from resources.lib.gui.guiElement import cGuiElement
    from resources.lib.handler.ParameterHandler import ParameterHandler
    g=cGui()
    if section not in ('movie','series'):
        art = os.path.join(cConfig().getAddonInfo('path'), 'resources', 'art')
        for k, label, icon in [('movie',31005,'movies.png'),('series',31006,'series.png')]:
            e=cGuiElement(tr(label),'xStream','continueWatching')
            e.setIcon(os.path.join(art, icon)); e.setThumbnail(os.path.join(art, icon))
            e.setFanart(os.path.join(art, icon))
            params=ParameterHandler(); params.setParam('section',k); g.addFolder(e,params)
        xbmcplugin.endOfDirectory(g.pluginHandle, succeeded=True, cacheToDisc=False); return
    with db() as c:
        rows=c.execute('SELECT h.id,h.context,h.watched,COALESCE(p.position,0),COALESCE(p.duration,0),n.context FROM history h LEFT JOIN progress p ON h.id=p.id LEFT JOIN next_items n ON h.id=n.id WHERE h.id NOT IN (SELECT id FROM hidden_continue) ORDER BY h.updated DESC').fetchall()
        cached={(parent,sn,en):ctx for parent,sn,en,ctx in c.execute('SELECT parent,season,episode,context FROM episodes')}
    xbmc.log('xStream continue: section=%s history=%d' % (section,len(rows)), xbmc.LOGINFO)
    entries=[]; seen=set(); watched={r[0] for r in rows if r[2]}
    for ident, raw, done, pos, duration, next_raw in rows:
        try:
            p=json.loads(raw)
            # Older history records may lack a mediaType; the saved key is authoritative.
            saved_kind = 'series' if ident.startswith(('episode:', 'tmdb:episode:')) else ('movie' if ident.startswith(('movie:', 'tmdb:movie:')) else kind(p))
            if saved_kind != section: continue
            group=series_identity(p) if section=='series' else ident
            if group in seen: continue
            if done:
                if section=='movie': continue
                if not next_raw:
                    sn,en=int(p.get('season',0)),int(p.get('episode',0))
                    next_raw=cached.get((p.get('playbackParent'),sn,en+1))
                    if not next_raw and not any(a==p.get('playbackParent') and b==sn and d>en for a,b,d in cached):
                        next_raw=cached.get((p.get('playbackParent'),sn+1,1))
                if not next_raw: continue
                p=json.loads(next_raw)
                if key(p) in watched: continue
                pos=duration=0
            elif pos<1: continue
            if not p.get('site') or not p.get('function'): continue
            p.pop('nextAuto',None); p.pop('manual',None)
            seen.add(group)
            entries.append((p,pos,duration,done,ident))
        except Exception as exc:
            xbmc.log('xStream continue history: '+str(exc), xbmc.LOGWARNING)
    page=max(1,int(page)); start=(page-1)*15
    for p,pos,duration,done,ident in entries[start:start+15]:
        try:
            title=p.get('MovieTitle') or p.get('title') or p.get('sName') or ''
            try: meta=json.loads(p.get('playbackMeta','{}'))
            except Exception: meta={}
            if not isinstance(meta,dict): meta={}
            values=meta.get('info',{}); values=values if isinstance(values,dict) else {}
            show=p.get('TVShowTitle') or values.get('TVShowTitle') or ''
            if section=='series':
                title=(show+' '+tr(30994)%(p.get('season','?'),p.get('episode','?'))+' - '+title).strip()
            e=cGuiElement(title,p['site'],p['function']); e.setMediaType('episode' if section=='series' else 'movie')
            if values.get('genres') and not values.get('genre'): values['genre']=values['genres']
            e.setItemValues(dict(values)); e.setThumbnail(meta.get('thumb') or p.get('thumb',''))
            if meta.get('fanart'): e.setFanart(meta['fanart'])
            if section=='series':
                e.setTVShowTitle(show)
                if str(p.get('season','')).isdigit(): e.setSeason(p['season'])
                if str(p.get('episode','')).isdigit(): e.setEpisode(p['episode'])
            if duration>0:
                progress=tr(31007) % (int(pos/60),int(max(0,duration-pos)/60),int(min(100,pos/duration*100)))
                e.setDescription((e.getDescription()+'\n\n'+progress).strip())
            elif done: e.setDescription((e.getDescription()+'\n\n'+tr(31008)).strip())
            item=g.createListItem(e)
            item.addContextMenuItems([(tr(31009), 'RunPlugin(plugin://plugin.video.xstream/?'+urlencode({'function':'removeContinue','historyId':ident})+')')])
            try:
                tag=item.getVideoInfoTag(); tag.setMediaType('episode' if section=='series' else 'movie')
                if duration>0: tag.setDuration(int(duration)); tag.setResumePoint(pos,duration)
            except Exception: pass
            url='plugin://plugin.video.xstream/?'+urlencode(dict(p,playMode='play'))
            folder=mode(p)=='List'
            if not folder: item.setProperty('IsPlayable','true')
            xbmcplugin.addDirectoryItem(g.pluginHandle,url,item,folder)
        except Exception as exc:
            xbmc.log('xStream continue item: '+str(exc), xbmc.LOGWARNING)
            title = p.get('MovieTitle') or p.get('title') or p.get('sName') or p.get('TVShowTitle') or ident
            item = xbmcgui.ListItem(str(title))
            item.setArt({'thumb': p.get('thumb',''), 'poster': p.get('thumb','')})
            try:
                tag=item.getVideoInfoTag()
                tag.setMediaType('episode' if section=='series' else 'movie')
                if duration>0: tag.setResumePoint(pos,duration)
            except Exception: pass
            folder=mode(p)=='List'
            if not folder: item.setProperty('IsPlayable','true')
            xbmcplugin.addDirectoryItem(g.pluginHandle,'plugin://plugin.video.xstream/?'+urlencode(dict(p,playMode='play')),item,folder)
    if len(entries)>start+15:
        params=ParameterHandler(); params.setParam('section',section); params.setParam('page',page+1)
        g.addNextPage('xStream','continueWatching',params)
    g.setView('episodes' if section=='series' else 'movies')
    xbmcplugin.endOfDirectory(g.pluginHandle, succeeded=True, cacheToDisc=False)

def remember_season(p):
    try:
        parent=p['playbackParent']; sn=int(p['season'])
        if sn<1: return
        with db() as c: c.execute('INSERT OR REPLACE INTO seasons VALUES (?,?,?)',(parent,sn,json.dumps(p)))
    except Exception: pass

def load_season(p,parent,sn):
    import sys
    from resources.lib.gui.gui import cGui
    old=sys.argv[:]; capture=cGui.playbackCapture
    try:
        cGui.playbackCapture=True
        sys.argv=[old[0],old[1],'?'+urlencode(p)]
        getattr(importlib.import_module(p['site']),p['function'])()
    except Exception as e:
        xbmc.log('xStream next season: '+str(e),xbmc.LOGWARNING)
    finally:
        sys.argv=old; cGui.playbackCapture=capture
    with db() as c: return c.execute('SELECT context FROM episodes WHERE parent=? AND season=? AND episode=1',(parent,sn)).fetchone()


def hoster_health(site, name, success=None):
    """Local, expiring hoster statistics; never store stream URLs."""
    try:
        with db() as conn:
            conn.execute('CREATE TABLE IF NOT EXISTS hoster_health (site TEXT, name TEXT, failures INTEGER, updated REAL, good REAL, PRIMARY KEY(site,name))')
            row = conn.execute('SELECT failures,updated,good FROM hoster_health WHERE site=? AND name=?',(site,name)).fetchone() or (0,0,0)
            failures, updated, good = row
            now = time.time()
            if now-updated > 900: failures=0
            if success is not None:
                failures = 0 if success else failures+1
                good = now if success else good
                conn.execute('INSERT OR REPLACE INTO hoster_health VALUES (?,?,?,?,?)',(site,name,failures,now,good))
            return failures, good if now-good < 86400 else 0
    except Exception:
        return 0,0


def fallback_targets(p):
    """Only transfer verified TMDb identities to German MediaHub sources."""
    site = p.get('site', '')
    media = kind(p)
    if media not in ('movie', 'series') or not enabled('playback_cross_' + media):
        return
    ident = str(p.get('sId') if site in MEDIAHUB else p.get('tmdbID') or '')
    if not ident.isdigit() or int(ident) < 1:
        return
    episode_id = ''
    if media == 'series':
        if site in MEDIAHUB:
            match = re.fullmatch(r'tmdb:(\d+):(\d+):(\d+)', str(p.get('episodeId', '')))
            if not match or match.group(1) != ident:
                return
            season, episode = match.group(2), match.group(3)
        else:
            season, episode = str(p.get('season', '')), str(p.get('episode', ''))
        if not season.isdigit() or not episode.isdigit() or int(episode) < 1:
            return
        episode_id = 'tmdb:%s:%s:%s' % (ident, int(season), int(episode))
    for target in MEDIAHUB:
        if target == site or cConfig().getSetting('plugin_' + target, 'false').lower() != 'true':
            continue
        context = dict(p)
        for field in ('sUrl', 'entryUrl', 'url', 'isHoster', 'playbackFunction', 'sMediaUrl', 'playbackParent'):
            context.pop(field, None)
        context.update(site=target, function='showHosters', sId=ident, playMode='play', mediaType='episode' if episode_id else 'movie')
        if episode_id:
            context.update(episodeId=episode_id, season=season, episode=episode)
        yield context


def remove_continue(ident):
    if not ident: return
    with db() as c:
        row=c.execute('SELECT context FROM history WHERE id=?',(ident,)).fetchone()
        ids=[ident]
        if row:
            p=json.loads(row[0])
            if kind(p)=='series':
                group=series_identity(p)
                ids=[i for i,raw in c.execute('SELECT id,context FROM history') if kind(json.loads(raw))=='series' and series_identity(json.loads(raw))==group]
        # Hide the entry without deleting watched history or resume data.
        c.execute('CREATE TABLE IF NOT EXISTS hidden_continue (id TEXT PRIMARY KEY)')
        c.executemany('INSERT OR IGNORE INTO hidden_continue VALUES (?)',[(i,) for i in ids])
    xbmc.executebuiltin('Container.Refresh')
