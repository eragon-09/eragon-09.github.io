# -*- coding: utf-8 -*-
# Python 3

import xbmc
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from xbmc import LOGINFO as LOGNOTICE, LOGERROR, log

class XstreamPlayer(xbmc.Player):
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self, *args, **kwargs)
        self.streamFinished = False
        self.ended = False
        self.started = False
        self.streamSuccess = True
        self.playedTime = 0
        self.totalTime = 999999
        log(cConfig().getLocalizedString(30166) + ' -> [player]: player instance created', LOGNOTICE)

    def onPlayBackStarted(self):
        log(cConfig().getLocalizedString(30166) + ' -> [player]: starting Playback', LOGNOTICE)
        self.started = True
        try: self.totalTime = self.getTotalTime()
        except Exception: pass

    def onPlayBackStopped(self):
        log(cConfig().getLocalizedString(30166) + ' -> [player]: Playback stopped', LOGNOTICE)
        if self.playedTime == 0 and self.totalTime == 999999:
            self.streamSuccess = False
            log(cConfig().getLocalizedString(30166) + ' -> [player]: Kodi failed to open stream', LOGERROR)
        if self.started:
            try:
                import time
                import xbmcgui
                xbmcgui.Window(10000).setProperty('xstream.search.return', str(time.time()))
            except Exception:
                pass
        self.streamFinished = True

    def onPlayBackError(self):
        self.streamSuccess = False
        self.streamFinished = True

    def onPlayBackEnded(self):
        log(cConfig().getLocalizedString(30166) + ' -> [player]: Playback completed', LOGNOTICE)
        self.ended = True
        self.onPlayBackStopped()


class cPlayer:
    def clearPlayList(self):
        oPlaylist = self.__getPlayList()
        oPlaylist.clear()

    def __getPlayList(self):
        return xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

    def addItemToPlaylist(self, oGuiElement):
        oListItem = cGui().createListItem(oGuiElement)
        self.__addItemToPlaylist(oGuiElement, oListItem)

    def __addItemToPlaylist(self, oGuiElement, oListItem):
        oPlaylist = self.__getPlayList()
        oPlaylist.add(oGuiElement.getMediaUrl(), oListItem)

    def startPlayer(self, poll_interval=1, player=None, progress_key=None, offset=0, context=None, auto_retry=False):
        from resources.lib import playback
        xbmcPlayer = player or XstreamPlayer()
        monitor = xbmc.Monitor()
        import time
        start = time.monotonic()
        last_save = start
        seek_pending = offset > 0
        while not monitor.abortRequested() and not xbmcPlayer.streamFinished:
            if xbmcPlayer.isPlayingVideo():
                try:
                    xbmcPlayer.started = True
                    xbmcPlayer.totalTime = xbmcPlayer.getTotalTime()
                    if seek_pending:
                        xbmcPlayer.seekTime(offset)
                        seek_pending = False
                    xbmcPlayer.playedTime = xbmcPlayer.getTime()
                    if time.monotonic() - last_save >= 10:
                        playback.save(progress_key, xbmcPlayer.playedTime, xbmcPlayer.totalTime, context=context)
                        last_save = time.monotonic()
                except Exception: pass
            elif not xbmcPlayer.started and time.monotonic()-start > 45:
                return False
            monitor.waitForAbort(min(poll_interval, 1))
        if xbmcPlayer.started:
            log('xStream continue save: key=%s position=%.2f duration=%.2f' % (progress_key, xbmcPlayer.playedTime, xbmcPlayer.totalTime), LOGNOTICE)
            playback.save(progress_key, xbmcPlayer.playedTime, xbmcPlayer.totalTime, xbmcPlayer.ended, context=context)
            # Refresh only the exact saved search, never initiate a provider search.
            try:
                import json, xbmcgui
                from urllib.parse import urlsplit, parse_qsl
                window = xbmcgui.Window(10000)
                folder = xbmc.getInfoLabel('Container.FolderPath')
                saved = json.loads(window.getProperty('xstream.search.snapshot') or 'null')
                if saved and folder.startswith('plugin://plugin.video.xstream/') and json.loads(saved[0]) == dict(parse_qsl(urlsplit(folder).query)):
                    window.setProperty('xstream.search.return', str(time.time()))
                    xbmc.executebuiltin('Container.Refresh')
            except Exception as exc:
                log('xStream status refresh: '+str(exc), LOGNOTICE)

        if xbmcPlayer.ended and context and not monitor.abortRequested():
            playback.offer_next(context)
        # A user stop after playback started is not a failed hoster.
        if monitor.abortRequested(): return True
        if auto_retry and xbmcPlayer.started and not xbmcPlayer.streamSuccess:
            # Do not restart a film after substantial playback.
            if xbmcPlayer.playedTime > max(30, offset + 30): return True
        return xbmcPlayer.streamSuccess and xbmcPlayer.started
