# -*- coding: utf-8 -*-
"""DeVideoSRC embed adapter; fresh tokens, no persistent credentials."""
import re
import requests
from urllib.parse import urlsplit


def _series_token(text):
    from html import unescape
    text = unescape(text).replace(r'\"', '"').replace(r"\'", "'")
    patterns = (
        r"""(?:\btoken\b|["']token["'])\s*[:=]\s*["']([^"']+)""",
        r"""\bdata-token\s*=\s*["']([^"']+)""",
        r"""\b(?:playerToken|apiToken|resolveToken)\s*[:=]\s*["']([^"']+)""",
    )
    for pattern in patterns:
        for match in re.finditer(pattern, text, re.I):
            value = match.group(1).strip()
            if re.fullmatch(r'[A-Za-z0-9_-]+\.[A-Fa-f0-9]{32,}', value):
                return value
    return ''


def _series_sources(player, referer, match):
    try:
        with requests.Session() as session:
            session.headers.update({'User-Agent': 'Mozilla/5.0', 'Referer': referer})
            response = session.get(player, timeout=15)
            response.raise_for_status()
            token = _series_token(response.text)
            if not token:
                return []
            payload = {'type': 'tv', 'id': match[2], 'season': match[3], 'episode': match[4], 'mode': 'custom', 'token': token}
            response = session.post('https://devideosrc.co/api/resolve', json=payload, headers={'Origin': 'https://devideosrc.co', 'Referer': player}, timeout=15)
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict) or not data.get('ok'):
                return []
            sources = data.get('sources', [])
            if not isinstance(sources, list):
                return []
            result = [s for s in sources if isinstance(s, dict) and isinstance(s.get('url'), str) and urlsplit(s['url']).scheme in ('http', 'https')]
            return result
    except Exception:
        return []


def get_sources(player, referer):
    u=urlsplit(player)
    if u.scheme!='https' or u.hostname!='devideosrc.co': return []
    match=re.fullmatch(r'/movie/(tt\d+)|/serial/(tt\d+)/(\d+)/(\d+)',u.path)
    if not match: return []
    if match[2]:
        return _series_sources(player, referer, match)
    with requests.Session() as session:
        session.headers.update({'User-Agent':'Mozilla/5.0','Referer':referer})
        response=session.get(player,timeout=15); response.raise_for_status()
        text=response.text
        token=re.search(r'\btoken\s*:\s*["\']([^"\']+)',text)
        if not token: return []
        if match[2]:
            endpoint = 'https://devideosrc.co/api/resolve'
            payload = {'type': 'tv', 'id': match[2], 'season': match[3],
                       'episode': match[4], 'mode': 'custom', 'token': token[1]}
        else:
            endpoint = 'https://devideosrc.co/api/embed-links'
            payload = {'type': 'movie', 'id': match[1], 'token': token[1]}
        response=session.post(endpoint,json=payload,headers={'Origin':'https://devideosrc.co','Referer':player},timeout=15); response.raise_for_status()
        data=response.json()
        if not data.get('ok'): return []
        return [s for s in data.get('sources',[]) if isinstance(s,dict) and isinstance(s.get('url'),str) and urlsplit(s['url']).scheme in ('http','https')]


def source_quality(source):
    """Return an explicitly reported vertical resolution, never a default."""
    for key in ('height', 'resolution', 'quality', 'videoQuality', 'video_quality', 'label', 'name'):
        value = source.get(key)
        if isinstance(value, dict):
            value = value.get('height') or value.get('resolution')
        if not isinstance(value, (str, int)):
            continue
        value = str(value).strip()
        match = re.search(r'(?<!\d)(2160|1440|1080|720|576|540|480|360|240)\s*p\b', value, re.I)
        if not match:
            match = re.fullmatch(r'(?:\d{3,4}\s*[x×]\s*)?(2160|1440|1080|720|576|540|480|360|240)', value)
        if match:
            return match.group(1)
        if re.search(r'\b(?:4K|UHD)\b', value, re.I):
            return '2160'
        if re.search(r'\b(?:FHD|FULL\s*HD)\b', value, re.I):
            return '1080'
    return ''


# No worker threads: Kodi can tear down the plugin immediately after selection.
import html
import hashlib
import json
import os
import time
from urllib.parse import urljoin, parse_qsl


def _cache_path(url):
    import xbmcvfs
    folder = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.xstream/')
    return os.path.join(folder, 'topstream-quality-' + hashlib.sha256(url.encode()).hexdigest() + '.json')


def cached_quality(url):
    try:
        with open(_cache_path(url), encoding='utf-8') as f:
            data = json.load(f)
        if time.time() - data['time'] < 86400:
            return source_quality({'height': data['height']})
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return ''


def _remember(url, quality):
    if not quality:
        return
    try:
        path = _cache_path(url)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        # Unique temporary file avoids collisions between Kodi plugin invocations.
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=os.path.dirname(path), delete=False) as f:
            temp = f.name
            json.dump({'time': time.time(), 'height': quality}, f)
        try:
            os.replace(temp, path)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
    except OSError:
        pass


def _manifest_quality(text):
    if not text.lstrip('\ufeff \r\n').startswith('#EXTM3U'):
        return ''
    heights = []
    for line in text.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            match = re.search(r'(?:[:,])RESOLUTION=\d+x(\d+)(?:,|$)', line, re.I)
            if match:
                heights.append(int(match[1]))
    return str(max(heights)) if heights else ''


def _read_small(url, headers):
    if urlsplit(url).scheme not in ('http', 'https'):
        return ''
    deadline = time.monotonic() + 1.2
    with requests.get(url, headers=headers, timeout=(0.7, 0.7), stream=True) as response:
        response.raise_for_status()
        if 'video/' in response.headers.get('Content-Type', '').lower():
            return ''
        chunks = bytearray()
        for chunk in response.iter_content(4096):
            chunks.extend(chunk)
            if len(chunks) >= 131072 or time.monotonic() >= deadline:
                break
        return chunks.decode('utf-8', 'replace')


def manifest_quality(link, referer):
    url, _, raw_headers = link.partition('|')
    if not urlsplit(url).path.lower().endswith('.m3u8'):
        return ''
    headers = {'User-Agent': 'Mozilla/5.0', 'Referer': referer}
    headers.update(dict(parse_qsl(raw_headers, keep_blank_values=True)))
    try:
        return _manifest_quality(_read_small(url, headers))
    except (requests.RequestException, ValueError, UnicodeError):
        return ''


def remember_resolved_quality(embed, link):
    quality = manifest_quality(link, embed)
    if quality:
        _remember(embed, quality)
    return quality


def probe_qualities(sources, referer):
    # Explicit API metadata or a previously verified HLS master. No speculative
    # resolver calls before selection, no background jobs, no guessed heights.
    return [source_quality(s) or cached_quality(s['url']) for s in sources]
