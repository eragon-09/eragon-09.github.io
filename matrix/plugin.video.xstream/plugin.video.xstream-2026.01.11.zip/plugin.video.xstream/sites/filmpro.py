# -*- coding: utf-8 -*-
# Python 3
# FilmPalast.one - xStream Site Plugin
# HTML-Struktur identisch zu topstreamfilm.live

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.wrappers.meinecloud import (
    resolveMeinecloudSerial, expandHosterList, buildHosterFromUrl,
    isPlatformUrl, platformImdbId, packSourceUrls, unpackSourceUrls
)
import html as _html
import re
import base64
import json
import datetime
from urllib.request import Request, urlopen
from urllib.parse import urlsplit


def _normalise_stream_link(link):
    link = _html.unescape((link or "").strip()).replace("\\/", "/")
    if link.startswith("//"):
        link = "https:" + link
    return link if link.startswith("http") else ""


def _decode_data_link(value):
    """MeineCloud data-link: Klartext- oder Base64-URL normalisieren."""
    value = _html.unescape((value or "").strip())
    direct = _normalise_stream_link(value)
    if direct:
        return direct
    try:
        raw = value.replace(" ", "+")
        raw += "=" * (-len(raw) % 4)
        decoded = base64.b64decode(raw).decode("utf-8", "ignore").strip()
        return _normalise_stream_link(decoded)
    except Exception:
        return ""


def _episode_data_link(html, episode):
    """Bevorzugt data-episode-Zuordnung; Reihenfolge nur als Fallback."""
    try:
        ep = str(int(episode))
    except Exception:
        ep = str(episode or "1")
    patterns = [
        r'data-episode=["\']?' + re.escape(ep) + r'["\']?[^>]*data-link=["\']([^"\']+)',
        r'data-link=["\']([^"\']+)["\'][^>]*data-episode=["\']?' + re.escape(ep) + r'["\']?',
    ]
    for pattern in patterns:
        m = re.search(pattern, html or "", flags=re.I | re.S)
        if m:
            link = _decode_data_link(m.group(1))
            if link:
                return link
    links = re.findall(r'data-link=["\']([^"\']+)["\']', html or "", flags=re.I)
    links = [_decode_data_link(x) for x in links]
    links = [x for x in links if x and "youtube" not in x.lower()]
    if not links:
        return ""
    try:
        idx = max(0, int(episode) - 1)
    except Exception:
        idx = 0
    return links[idx] if idx < len(links) else links[0]

SITE_IDENTIFIER = 'filmpro'
SITE_NAME = 'FilmPro'
SITE_ICON = 'filmpro.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'filmpalast.one')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN   = 'https://' + DOMAIN
URL_NEW    = URL_MAIN + '/'
URL_MOVIES = URL_MAIN + '/filme/'
URL_KINO   = URL_MAIN + '/kinofilme/'
URL_SERIES = URL_MAIN + '/serien/'
URL_SOON   = URL_MAIN + '/demnachst/'
URL_SEARCH = URL_MAIN + '/?story=%s&do=search&subaction=search'

SCRAPER_SETTINGS = f'''
            <group id="filmpro" label="30729">
                <setting id="plugin_filmpro" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_filmpro" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_filmpro">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_filmpro_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_filmpro">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_filmpro">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_filmpro.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>filmpalast.one</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_filmpro">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_filmpro">false</dependency>
                    </dependencies>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_filmpro_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''


def load():
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()

    # --- Hauptmenü ---
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement('Im Kino', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_NEW)
    cGui().addFolder(cGuiElement('Neu', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_SOON)
    cGui().addFolder(cGuiElement('Demnächst im Kino', SITE_IDENTIFIER, 'showEntries'), params)
    cGui().addFolder(cGuiElement('Filme', SITE_IDENTIFIER, 'showMovieMenu'), params)
    cGui().addFolder(cGuiElement('Serien', SITE_IDENTIFIER, 'showSeriesMenu'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)
    cGui().setEndOfDirectory()


def showMovieMenu():
    """Untermenü: Filme"""
    params = ParameterHandler()

    params.setParam('sUrl', URL_MOVIES)
    cGui().addFolder(cGuiElement('Alle Filme', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement('Im Kino', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_SOON)
    cGui().addFolder(cGuiElement('Demnächst', SITE_IDENTIFIER, 'showEntries'), params)
    cGui().addFolder(cGuiElement('Nach Genre', SITE_IDENTIFIER, 'showGenre'), params)
    cGui().addFolder(cGuiElement('Nach Jahr', SITE_IDENTIFIER, 'showYears'), params)
    cGui().addFolder(cGuiElement('Nach Land', SITE_IDENTIFIER, 'showCountry'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)
    cGui().setEndOfDirectory()


def showSeriesMenu():
    """Untermenü: Serien"""
    params = ParameterHandler()

    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement('Alle Serien', SITE_IDENTIFIER, 'showEntries'), params)
    cGui().addFolder(cGuiElement('Nach Genre', SITE_IDENTIFIER, 'showSeriesGenre'), params)
    cGui().addFolder(cGuiElement('Nach Jahr', SITE_IDENTIFIER, 'showYears'), params)
    cGui().addFolder(cGuiElement('Nach Land', SITE_IDENTIFIER, 'showCountry'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)
    cGui().setEndOfDirectory()


def showSeriesGenre():
    """Genre-Untermenü für Serien"""
    params = ParameterHandler()
    genres = [
        ('Drama',        URL_MAIN + '/drama/'),
        ('Fantasy',      URL_MAIN + '/fantasy/'),
        ('Horror',       URL_MAIN + '/horror/'),
        ('Komödie',      URL_MAIN + '/komodie/'),
        ('Krimi',        URL_MAIN + '/krimi/'),
        ('Mystery',      URL_MAIN + '/mystery/'),
        ('Reality-TV',   URL_MAIN + '/reality-tv/'),
        ('Romantik',     URL_MAIN + '/romantik/'),
        ('Sci-Fi',       URL_MAIN + '/sci-fi/'),
        ('Thriller',     URL_MAIN + '/thriller/'),
    ]
    for sName, sUrl in genres:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showGenre():
    params = ParameterHandler()
    # Genre-Liste aus dem HTML der Seite (KATEGORIEN)
    genres = [
        ('Drama', URL_MAIN + '/drama/'),
        ('Serien', URL_MAIN + '/serien/'),
        ('Familie', URL_MAIN + '/familie/'),
        ('Fantasy', URL_MAIN + '/fantasy/'),
        ('Historie', URL_MAIN + '/historie/'),
        ('Horror', URL_MAIN + '/horror/'),
        ('Musik', URL_MAIN + '/musik/'),
        ('Mystery', URL_MAIN + '/mystery/'),
        ('Romantik', URL_MAIN + '/romantik/'),
        ('Reality-TV', URL_MAIN + '/reality-tv/'),
        ('Sci-Fi', URL_MAIN + '/sci-fi/'),
        ('Sport', URL_MAIN + '/sport/'),
        ('Thriller', URL_MAIN + '/thriller/'),
        ('Krieg', URL_MAIN + '/krieg/'),
        ('Western', URL_MAIN + '/western/'),
        ('Action', URL_MAIN + '/action/'),
        ('Abenteuer', URL_MAIN + '/abenteuer/'),
        ('Animation', URL_MAIN + '/animation/'),
        ('Biographie', URL_MAIN + '/biographie/'),
        ('Komödie', URL_MAIN + '/komodie/'),
        ('Krimi', URL_MAIN + '/krimi/'),
        ('Dokumentation', URL_MAIN + '/dokumentation/'),
        ('Demnächst', URL_MAIN + '/demnachst/'),
        ('Liebesfilm', URL_MAIN + '/liebesfilm/'),
        ('Kinofilme', URL_MAIN + '/kinofilme/'),
    ]
    for sName, sUrl in genres:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showCountry():
    params = ParameterHandler()
    # Länder aus dem HTML der Seite
    countries = [
        ('USA', URL_MAIN + '/xfsearch/USA'),
        ('Deutschland', URL_MAIN + '/xfsearch/deutschland'),
        ('Kanada', URL_MAIN + '/xfsearch/country/Canada/'),
        ('Italien', URL_MAIN + '/xfsearch/country/italien/'),
        ('Frankreich', URL_MAIN + '/xfsearch/country/frankreich/'),
        ('Spanien', URL_MAIN + '/xfsearch/country/spanien/'),
        ('China', URL_MAIN + '/xfsearch/country/China/'),
        ('Japan', URL_MAIN + '/xfsearch/country/Japan/'),
        ('Taiwan', URL_MAIN + '/xfsearch/country/Taiwan/'),
        ('Thailand', URL_MAIN + '/xfsearch/country/Thailand/'),
        ('Belgium', URL_MAIN + '/xfsearch/country/Belgium/'),
        ('Israel', URL_MAIN + '/xfsearch/country/Israel/'),
    ]
    for sName, sUrl in countries:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showYears():
    params = ParameterHandler()
    import datetime
    current_year = datetime.datetime.now().year
    for year in range(current_year, 1989, -1):
        sUrl = URL_MAIN + '/xfsearch/%d' % year
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(str(year), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = False
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()

    # Erfasst href, data-src (Thumbnail), Titel und den TPMvCn-Block mit allen Infos
    pattern = 'TPostMv">.*?href="([^"]+).*?data-src="([^"]+).*?<h3[^>]*>([^<]+).*?TPMvCn(.*?)</li>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    # Die Webseite liefert bei kurzen Suchbegriffen nicht immer alle Treffer.
    # Eine zweite, jahresbezogene Suche ergaenzt aktuelle exakte Titel, ohne
    # andere Anbieter oder den zentralen Suchfilter zu veraendern.
    if sSearchText:
        _search_value = _html.unescape(str(sSearchText)).strip()
        _year_given = re.search(r'\b(?:19|20)\d{2}\b', _search_value)
        _plain_title = re.sub(r'\s*\(?\b(?:19|20)\d{2}\b\)?\s*$', '', _search_value).strip()
        if _plain_title and not _year_given:
            try:
                _year_query = '%s (%s)' % (_plain_title, datetime.datetime.now().year)
                _extra_url = URL_SEARCH % cParser.quotePlus(_year_query)
                _extra_request = cRequestHandler(_extra_url, ignoreErrors=True)
                _extra_request.cacheTime = 60 * 30
                _extra_html = _extra_request.request()
                _extra_ok, _extra_results = cParser.parse(_extra_html, pattern)
                if _extra_ok:
                    _seen = {item[0] for item in (aResult or [])}
                    for _item in _extra_results:
                        if _item[0] not in _seen:
                            aResult.append(_item)
                            _seen.add(_item[0])
            except Exception as _exc:
                logger.info('FilmPro Jahres-Nachsuche fehlgeschlagen: %s' % _exc)
    if not isMatch and not aResult:
        if not sGui: oGui.showInfo()
        return

    # Jahresfilter wenn URL ein xfsearch-Jahr enthält
    import re as _re
    _year_match = _re.search(r'/xfsearch/(\d{4})', entryUrl if entryUrl else '')
    if _year_match:
        _yf = _year_match.group(1)
        aResult = [r for r in aResult if _yf in r[3]][:16]
    else:
        # Bei der Suche nicht vorzeitig auf 16 Treffer begrenzen:
        # Der gesuchte Film kann auf der Ergebnisseite weiter unten stehen.
        if not sSearchText:
            aResult = aResult[:16]
    total = len(aResult)

    for sUrl, sThumbnail, sName, sDummy in aResult:
        sName = _html.unescape(sName).strip()
        if sSearchText:
            import re as _re
            _query = _re.sub(r'\s*\(\d{4}\)\s*$', '', str(sSearchText)).strip()
            if _query and not cParser.search(_re.escape(_query), sName):
                continue

        isYear,     sYear     = cParser.parseSingleResult(sDummy, 'Date[^>]*>([0-9]+)</span>')
        isDuration, sDuration = cParser.parseSingleResult(sDummy, 'Time[^>]*>([0-9]+)')
        isRating,   sRating   = cParser.parseSingleResult(sDummy, 'Vote[^>]*>([0-9.]+)')
        isQuality,  sQuality  = cParser.parseSingleResult(sDummy, 'Qlty">([^<]+)</span>')
        isDesc,     sDesc     = cParser.parseSingleResult(sDummy, 'Description[^>]*>\\s*<p>([^<]+)')

        # TV-Show Erkennung per Laufzeit: Serien-Episoden haben fast immer < 75 Minuten,
        # echte Filme typischerweise >= 75 Minuten. Serien-URLs direkt als tvshow markieren.
        try:
            iDuration = int(sDuration) if isDuration else 999
        except Exception:
            iDuration = 999
        bIsSeriesUrl = any(x in entryUrl for x in ['/serien/', '/drama/', '/mystery/',
                                                    '/reality-tv/', '/sci-fi/'])
        isTvshow = bIsSeriesUrl or (iDuration < 75)

        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail

        # Seitentitel bereinigen: " - Der Film", " - Die Serie" usw. entfernen
        import re as _re
        sCleanName = _re.sub(r'\s*-\s*(Der|Die|Das|The)\s+Film.*$', '', sName, flags=_re.IGNORECASE).strip()
        sCleanName = _re.sub(r'\s*-\s*(Der|Die|Das|The)\s+Serie.*$', '', sCleanName, flags=_re.IGNORECASE).strip()
        # Titel zusammenbauen: Name - (Jahr) [Qualität]
        sTitle = sCleanName
        if isYear:
            sTitle += ' - (%s)' % sYear
        if isQuality:
            sTitle += ' [%s]' % sQuality.strip()
        oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setFanart(sThumbnail)  # Thumbnail als Fanart, kein Extra-Request nötig
        if isYear:
            oGuiElement.setYear(sYear)
        if isDuration:
            oGuiElement.addItemValue('duration', sDuration)
        if isRating:
            oGuiElement.addItemValue('rating', sRating)
        if isDesc:
            oGuiElement.setDescription(sDesc.strip())

        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sDesc', sDesc if isDesc else '')
        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText and not sSearchPageText:
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, 'href="([^"]+)">Next')
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="wp-pagenavi">(.*?)Next')
        if isMatchSiteSearch:
            isMatch, aResult = cParser.parse(sHtmlContainer,
                '<span>([0-9]+)</span>.*?nav_ext">.*?">([0-9]+)</a>.*?href="([^"]+)')
            for sPageActive, sPageLast, sNextPage in (aResult or []):
                sPageName = (cConfig().getLocalizedString(30284) + str(sPageActive) +
                             cConfig().getLocalizedString(30285) + str(sPageLast) +
                             cConfig().getLocalizedString(30286))
                params.setParam('sNextPage', sNextPage)
                params.setParam('sPageLast', sPageLast)
                oGui.searchNextPage(sPageName, SITE_IDENTIFIER, 'showSearchPage', params)
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def _filmpro_series_data(entryUrl):
    """Serienfolgen ueber den vorhandenen, funktionierenden Meinecloud-Wrapper."""
    sHtml = cRequestHandler(entryUrl).request() or ''
    imdb = platformImdbId(sHtml)
    if not imdb:
        logger.info('FilmPro: keine IMDb-ID fuer Serie %s' % entryUrl)
        return []
    return resolveMeinecloudSerial(imdb, referer=entryUrl, siteHtml=sHtml)


def showSeasons():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    episodes = _filmpro_series_data(entryUrl)
    seasons = sorted(set(ep['season'] for ep in episodes))
    if not seasons:
        cGui().showInfo()
        return
    for season in seasons:
        item = cGuiElement('Staffel %d' % season, SITE_IDENTIFIER, 'showEpisodes')
        item.setMediaType('season')
        item.setSeason(season)
        thumb = params.getValue('sThumbnail')
        if thumb:
            item.setThumbnail(thumb)
        desc = params.getValue('sDesc')
        if desc:
            item.setDescription(desc)
        item_params = ParameterHandler()
        item_params.setParam('entryUrl', entryUrl)
        item_params.setParam('sThumbnail', thumb)
        item_params.setParam('sDesc', desc)
        item_params.setParam('season', str(season))
        cGui().addFolder(item, item_params, True, len(seasons))
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    season = str(params.getValue('season'))
    episodes = [ep for ep in _filmpro_series_data(entryUrl) if str(ep['season']) == season]
    if not episodes:
        cGui().showInfo()
        return
    for ep in episodes:
        item = cGuiElement('E%d - %s' % (ep['episode'], ep.get('title', 'Episode')),
                           SITE_IDENTIFIER, 'showEpisodeHosters')
        item.setMediaType('episode')
        item.setSeason(ep['season'])
        item.setEpisode(ep['episode'])
        thumb = params.getValue('sThumbnail')
        if thumb:
            item.setThumbnail(thumb)
        desc = params.getValue('sDesc')
        if desc:
            item.setDescription(desc)
        ep_params = ParameterHandler()
        ep_params.setParam('entryUrl', entryUrl)
        ep_params.setParam('meinecloud_url', packSourceUrls(ep.get('urls', [])))
        cGui().addFolder(item, ep_params, False, len(episodes))
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showEpisodeHosters():
    params = ParameterHandler()
    urls = unpackSourceUrls(params.getValue('meinecloud_url'))
    hosters = []
    for url in urls:
        item = buildHosterFromUrl(url)
        if item:
            hosters.append(item)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def showHosters():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    sHtml = cRequestHandler(entryUrl, caching=False).request() or ''
    raw = []
    for tag in re.findall(r'<iframe\b[^>]*>', sHtml, flags=re.I | re.S):
        m = re.search(r'\bsrc\s*=\s*["\']([^"\']+)', tag, flags=re.I)
        if m:
            link = _normalise_stream_link(m.group(1))
            if link:
                raw.append(link)
    # Auch direkt im HTML eingebettete Plattform-Links beruecksichtigen.
    for link in re.findall(r'https?://[^"\'\s<>]+(?:meinecloud|devideosrc)[^"\'\s<>]*', sHtml, re.I):
        if isPlatformUrl(link):
            raw.append(link)
    expanded = expandHosterList(raw, referer=entryUrl)
    hosters = []
    seen = set()
    for url in expanded:
        item = buildHosterFromUrl(url)
        if item and item['link'] not in seen:
            seen.add(item['link'])
            hosters.append(item)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    # Den dekodierten Embed-Link unverändert an ResolveURL weiterreichen.
    # Die bereits angepasste dropload.py übernimmt dr0pstream/dropload.
    return [{'streamUrl': sUrl, 'resolved': False}]

def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)


def showSearchPage():
    params          = ParameterHandler()
    sNextPage       = params.getValue('sNextPage')
    sPageLast       = params.getValue('sPageLast')
    sHeading        = cConfig().getLocalizedString(30282) + str(sPageLast)
    sSearchPageText = cGui().showKeyBoard(sHeading=sHeading)
    if not sSearchPageText: return
    sNextSearchPage = sNextPage.split('page/')[0].strip() + 'page/' + sSearchPageText + '/'
    showEntries(sNextSearchPage)
    cGui().setEndOfDirectory()
