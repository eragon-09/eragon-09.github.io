# -*- coding: utf-8 -*-
"""Ausgelagerte Provider-Implementierung."""

# ----------------------------------------------------------
# Pluto TV VoD (On-Demand Filme & Serien nach Genre/Kategorie)
# Endpunkte/Ablauf identisch zum offiziellen, aktiv gepflegten
# oe-alliance/PlutoTV-Addon (https://github.com/oe-alliance/PlutoTV):
#   1) boot.pluto.tv liefert ein Sitzungs-JWT (kein Login noetig, Pluto TV
#      VoD ist komplett kostenlos/werbefinanziert)
#   2) api.pluto.tv/v3/vod/categories liefert die Genre-Liste inkl. Filme
#   3) api.pluto.tv/v3/vod/series/{id}/seasons liefert Staffeln+Episoden
#   4) Die im Item enthaltene "stitched"-URL wird mit dem Sitzungstoken zu
#      einer abspielbaren HLS-URL am Stitcher-Host zusammengesetzt
# ----------------------------------------------------------
PLUTO_BOOT_URL       = "https://boot.pluto.tv/v4/start"
PLUTO_STITCHER_BASE  = "https://cfd-v4-service-channel-stitcher-use1-1.prd.pluto.tv"
PLUTO_VOD_URL         = "https://api.pluto.tv/v3/vod/categories"
PLUTO_SEASON_URL      = "https://api.pluto.tv/v3/vod/series/%s/seasons"
PLUTO_IMAGE_URL       = "https://images.pluto.tv"
PLUTO_BOOT_FILE       = PROFILE + "pluto_boot.json"
PLUTO_VOD_CAT_FILE    = PROFILE + "pluto_vod_cats_DE.gz"

PLUTO_BOOT_HEADERS = {
    "accept": "*/*",
    "origin": "https://pluto.tv",
    "referer": "https://pluto.tv/",
    "user-agent": UA,
}



def _pluto_token_expiry(token):
    """Liest das 'exp'-Feld (Unix-Timestamp) aus dem JWT-Payload aus."""
    try:
        import base64
        payload = token.split(".")[1]
        padding = 4 - len(payload) % 4
        if padding != 4:
            payload += "=" * padding
        data = json.loads(base64.urlsafe_b64decode(payload))
        return data.get("exp", 0)
    except Exception:
        return 0


def pluto_boot(force=False):
    """
    Holt/cached ein Pluto-TV-Sitzungstoken (JWT) via boot.pluto.tv - der
    gleiche Ablauf, den die Pluto-TV-Webseite selbst beim Laden ausfuehrt.
    Kein Account noetig. Wird als Bearer-Token fuer die VOD-API-Requests und
    als "jwt="-Parameter fuer die eigentliche Stream-URL gebraucht.
    """
    if not force:
        cached = read_json(PLUTO_BOOT_FILE, {})
        token = cached.get("sessionToken", "")
        if token and time.time() < cached.get("exp", 0) - 60:
            return cached

    params = {
        "appName": "web",
        "appVersion": "8.0.0",
        "deviceVersion": "122.0.0",
        "deviceModel": "web",
        "deviceMake": "chrome",
        "deviceType": "web",
        "clientID": PLUTO_DEVICE_ID,
        "clientModelNumber": "1.0.0",
        "serverSideAds": "false",
        "drmCapabilities": "widevine:L3",
        "blockingMode": "",
    }
    # Der erste Versuch entspricht dem bisher funktionierenden Ablauf. Falls
    # Pluto zwar HTTP 200 liefert, aber ausnahmsweise kein sessionToken, wird
    # genau einmal mit einer frischen, normalen Web-Client-ID erneut gebootet.
    # Das verändert weder IP noch Land und umgeht keine Provider-Prüfung.
    attempts = [params]
    retry_params = dict(params)
    try:
        import uuid as _uuid
        retry_params["clientID"] = str(_uuid.uuid4())
    except Exception:
        pass
    retry_params["appVersion"] = "9.1.0"
    attempts.append(retry_params)

    for attempt_no, boot_params in enumerate(attempts, start=1):
        try:
            r = requests.get(PLUTO_BOOT_URL, headers=PLUTO_BOOT_HEADERS, params=boot_params, timeout=15)
            log(f"[Pluto VoD] GET {PLUTO_BOOT_URL} -> HTTP {r.status_code} (Versuch {attempt_no}/2)")
            if r.status_code != 200:
                log(f"[Pluto VoD] Boot-Fehlerantwort (gekürzt): {r.text[:500]}", xbmc.LOGWARNING)
                continue
            resp = r.json()
        except Exception as e:
            log(f"[Pluto VoD] Boot-Request fehlgeschlagen (Versuch {attempt_no}/2): {e}", xbmc.LOGERROR)
            continue

        token = resp.get("sessionToken", "")
        if not token:
            log(f"[Pluto VoD] Boot-Antwort ohne sessionToken (Versuch {attempt_no}/2)", xbmc.LOGWARNING)
            continue

        resp["exp"] = _pluto_token_expiry(token)
        write_json(PLUTO_BOOT_FILE, resp)
        return resp

    return {}


def _pluto_api_headers():
    token = pluto_boot().get("sessionToken", "")
    return {
        "accept": "application/json, text/javascript, */*; q=0.01",
        "authorization": f"Bearer {token}",
        "origin": "https://pluto.tv",
        "referer": "https://pluto.tv/",
        "user-agent": UA,
    }


def pluto_build_vod_stream_url(vod_url):
    """
    Baut aus der rohen 'stitched'-URL eines VOD-Items die abspielbare,
    tokenisierte HLS-URL am Stitcher-Host zusammen (identisch zu
    buildVodStreamURL() im oe-alliance-Addon).
    """
    token = pluto_boot().get("sessionToken", "")
    if not token or not vod_url:
        return None
    path = vod_url.split("?")[0]
    path = re.sub(r"^https?://[^/]+", "", path)
    if path.startswith("/stitch/"):
        path = "/v2" + path
    return f"{PLUTO_STITCHER_BASE}{path}?jwt={quote_plus(token)}&masterJWTPassthrough=true"


def pluto_vod_load_categories(force=False):
    """
    Laedt die komplette VoD-Genreliste (inkl. aller Filme/Serien je Genre)
    in einem Request und cached sie 12h (per Einstellung anpassbar).
    Gibt die Rohstruktur {"totalCategories": N, "categories": [...]} zurueck.
    """
    cache_h = max(1, get_pluto_vod_cache_seconds() // 3600)
    cached = _rktv_preserve(PLUTO_VOD_CAT_FILE, cache_h)
    if cached and not force:
        return cached

    headers = _pluto_api_headers()
    params = {"includeItems": "true", "deviceType": "web"}
    try:
        r = requests.get(PLUTO_VOD_URL, headers=headers, params=params, timeout=25)
        log(f"[Pluto VoD] GET {PLUTO_VOD_URL} -> HTTP {r.status_code}")
        if r.status_code != 200:
            log(f"[Pluto VoD] Fehlerantwort (gekürzt): {r.text[:500]}", xbmc.LOGWARNING)
            return {}
        data = r.json()
    except Exception as e:
        log(f"[Pluto VoD] Kategorien-Abruf fehlgeschlagen: {e}", xbmc.LOGERROR)
        return {}

    if data.get("categories"):
        _rktv_preserve(PLUTO_VOD_CAT_FILE, cache_h, data)
    return data


def _pluto_item_poster(item):
    covers = item.get("covers") or []
    poster = covers[0].get("url", "") if covers else ""
    image = ""
    if len(covers) > 2:
        image = covers[2].get("url", "")
    if len(covers) > 1 and not image:
        image = covers[1].get("url", "")
    return poster, (image or poster)


def view_pluto_vod_genres():
    """Genre-/Kategorieliste von Pluto TV VoD (Filme + Serien gemischt je Genre)."""
    p = ProgressDialog(enabled=True)
    p.open("Lade Pluto VoD-Genres …")
    try:
        p.update(30, "Lade Genres …")
        data = pluto_vod_load_categories()
        cats = data.get("categories") or []
        if not cats:
            notify("Keine Pluto VoD-Genres gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(80, "Baue Menü …")
        pluto_icon = get_source_icon("pluto")
        for cat in cats:
            cid = cat.get("_id", "")
            name = cat.get("name", "")
            count = cat.get("totalItemsCount", 0) or len(cat.get("items", []))
            if not cid or not name:
                continue
            label = f"{name}  ({count})" if count else name
            url = build_url({"action": "pluto_vod_list", "cat_id": quote_plus(cid)})
            li = xbmcgui.ListItem(colorize(label, COLOR_GROUP))
            li.setArt({"icon": pluto_icon, "thumb": pluto_icon, "fanart": pluto_icon})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

        xbmcplugin.setContent(HANDLE, "genres")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_pluto_vod_list(cat_id):
    """Filme/Serien innerhalb eines Genres."""
    p = ProgressDialog(enabled=True)
    p.open("Lade Inhalte …")
    try:
        p.update(30, "Lade Kategoriedaten …")
        data = pluto_vod_load_categories()
        cat = next((c for c in (data.get("categories") or []) if c.get("_id") == cat_id), None)
        if not cat:
            notify("Genre nicht gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(70, "Baue Menü …")
        for item in cat.get("items", []):
            identifier = item.get("_id", "")
            name = item.get("name", "")
            if not identifier or not name:
                continue
            media_type = item.get("type", "")  # "movie" oder "series"
            plot = item.get("summary") or item.get("description") or ""
            poster, fanart = _pluto_item_poster(item)
            rating = item.get("rating", "")
            genre = item.get("genre", "")

            li = xbmcgui.ListItem(name)
            info = {"title": name, "plot": plot}
            if genre:
                info["genre"] = genre
            if rating:
                info["mpaa"] = f"FSK-{rating}" if rating.isdigit() else rating
            try:
                li.getVideoInfoTag().setTitle(name)
                if plot:
                    li.getVideoInfoTag().setPlot(plot)
                if genre:
                    li.getVideoInfoTag().setGenres([genre])
            except Exception:
                li.setInfo("video", info)
            set_art(li, poster or fanart)

            if media_type == "movie":
                urls = (item.get("stitched") or {}).get("urls") or []
                if not urls:
                    continue
                li.setProperty("IsPlayable", "true")
                play_url = build_url({
                    "action": "pluto_vod_play",
                    "url": quote_plus(urls[0].get("url", "")),
                    "name": quote_plus(name),
                    "plot": quote_plus(plot),
                })
                dl_url = build_url({
                    "action": "pluto_vod_download", "url": quote_plus(urls[0].get("url", "")),
                    "name": quote_plus(name), "plot": quote_plus(plot),
                    "poster": quote_plus(poster or ""), "fanart": quote_plus(fanart or ""),
                    "genre": quote_plus(str(genre or "")), "mpaa": quote_plus((f"FSK-{rating}" if str(rating).isdigit() else str(rating or ""))),
                    "year": str(item.get("year") or item.get("releaseYear") or ""), "media_type": "movie",
                })
                li.addContextMenuItems([("Download", "RunPlugin(%s)" % dl_url)])
                xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)
            elif media_type == "series":
                seasons_url = build_url({
                    "action": "pluto_vod_seasons",
                    "series_id": quote_plus(identifier),
                    "name": quote_plus(name),
                    "plot": quote_plus(plot),
                    "poster": quote_plus(poster),
                })
                xbmcplugin.addDirectoryItem(HANDLE, seasons_url, li, isFolder=True)

        xbmcplugin.setContent(HANDLE, "movies")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_pluto_vod_seasons(series_id, name, plot="", poster=""):
    """Staffeln + Episoden einer Pluto-VoD-Serie."""
    p = ProgressDialog(enabled=True)
    p.open("Lade Staffeln …")
    try:
        p.update(30, f"Lade '{name}' …")
        headers = _pluto_api_headers()
        params = {"includeItems": "true", "deviceType": "web"}
        try:
            r = requests.get(PLUTO_SEASON_URL % series_id, headers=headers, params=params, timeout=25)
            log(f"[Pluto VoD] GET {PLUTO_SEASON_URL % series_id} -> HTTP {r.status_code}")
            if r.status_code != 200:
                log(f"[Pluto VoD] Fehlerantwort (gekürzt): {r.text[:500]}", xbmc.LOGWARNING)
                notify("Staffeln konnten nicht geladen werden", True, 5000)
                xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
                return
            data = r.json()
        except Exception as e:
            log(f"[Pluto VoD] Staffel-Abruf fehlgeschlagen: {e}", xbmc.LOGERROR)
            notify("Staffeln konnten nicht geladen werden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(80, "Baue Menü …")
        seasons = data.get("seasons", [])
        for season in seasons:
            snum = season.get("number", "")
            episodes = season.get("episodes", [])
            for ep in episodes:
                identifier = ep.get("_id", "")
                ep_name = ep.get("name", "")
                if not identifier or not ep_name:
                    continue
                urls = (ep.get("stitched") or {}).get("urls") or []
                if not urls:
                    continue
                enum = ep.get("number", "")
                label = f"S{snum}E{enum} - {ep_name}" if snum and enum else ep_name
                ep_plot = ep.get("description") or ep.get("summary") or ""
                ep_poster, _fan = _pluto_item_poster(ep)
                ep_genre = ep.get("genre") or ""
                ep_rating = ep.get("rating") or ""
                ep_year = ep.get("year") or ep.get("releaseYear") or ""

                li = xbmcgui.ListItem(label)
                try:
                    tag = li.getVideoInfoTag()
                    tag.setTitle(label)
                    if ep_plot:
                        tag.setPlot(ep_plot)
                    if snum:
                        tag.setSeason(int(snum))
                    if enum:
                        tag.setEpisode(int(enum))
                except Exception:
                    pass
                set_art(li, ep_poster or poster)
                li.setProperty("IsPlayable", "true")

                play_url = build_url({
                    "action": "pluto_vod_play",
                    "url": quote_plus(urls[0].get("url", "")),
                    "name": quote_plus(label),
                    "plot": quote_plus(ep_plot),
                })
                dl_url = build_url({
                    "action": "pluto_vod_download", "url": quote_plus(urls[0].get("url", "")),
                    "name": quote_plus(label), "plot": quote_plus(ep_plot),
                    "poster": quote_plus(ep_poster or poster or ""), "fanart": quote_plus(_fan or ""),
                    "season": str(snum or ""), "episode": str(enum or ""), "media_type": "episode",
                    "show_title": quote_plus(name), "genre": quote_plus(str(ep_genre or "")),
                    "mpaa": quote_plus((f"FSK-{ep_rating}" if str(ep_rating).isdigit() else str(ep_rating or ""))), "year": str(ep_year or ""),
                })
                li.addContextMenuItems([("Download", "RunPlugin(%s)" % dl_url)])
                xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)

        xbmcplugin.setContent(HANDLE, "episodes")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_pluto_vod_play(url, name, plot=""):
    """Loest die finale Stream-URL auf und startet die Wiedergabe (HLS, kein DRM)."""
    raw_url = unquote_plus(url)
    name = unquote_plus(name)
    plot = unquote_plus(plot) if plot else ""

    stream_url = pluto_build_vod_stream_url(raw_url)
    if not stream_url:
        notify("Pluto-Stream konnte nicht aufgelöst werden (siehe Kodi-Log)", True, 6000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    WIN.setProperty(RETURN_FROM_PLAY_FLAG, "1")
    playback_url = stream_url + f"|User-Agent={quote_plus(UA)}&Referer={quote_plus('https://pluto.tv/')}"

    li = xbmcgui.ListItem(name, path=playback_url)
    li.setProperty("IsPlayable", "true")
    set_video_info(li, name, plot)
    li.setMimeType("application/vnd.apple.mpegurl")
    if kodi_has_addon("inputstream.ffmpegdirect"):
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
        li.setProperty("inputstream.ffmpegdirect.mime_type", "application/vnd.apple.mpegurl")
        li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
        li.setProperty("inputstream.ffmpegdirect.user_agent", UA)
        li.setProperty("inputstream.ffmpegdirect.stream_headers", "Referer=https://pluto.tv/")
    else:
        log("[Pluto VoD] FFmpeg Direct fehlt - native HLS-Wiedergabe")

    xbmcplugin.setResolvedUrl(HANDLE, True, li)




def view_pluto_download_play(folder, name):
    """Spielt ein lokal gespeichertes Pluto-HLS-Paket. AES-Schluessel bleiben remote und werden nur bei der Wiedergabe angefordert."""
    folder = unquote_plus(folder); name = unquote_plus(name)
    playlist = folder.rstrip("/\\") + "/playlist.m3u8"
    if not xbmcvfs.exists(playlist):
        notify("Lokale Pluto-Playlist fehlt", True, 5000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        local_path = xbmcvfs.translatePath(playlist)
    except Exception:
        local_path = playlist
    meta_path = folder.rstrip("/\\") + "/download.json"
    meta = read_json(meta_path, {}) if xbmcvfs.exists(meta_path) else {}
    title = meta.get("title") or name
    plot = meta.get("plot") or "Lokal gespeicherter Pluto-TV-Download"
    poster = meta.get("poster") or ""
    fanart = meta.get("fanart") or poster
    li = xbmcgui.ListItem(title, path=local_path)
    li.setProperty("IsPlayable", "true")
    li.setMimeType("application/vnd.apple.mpegurl")
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        if plot: tag.setPlot(plot)
        if meta.get("show_title"): tag.setTvShowTitle(str(meta.get("show_title")))
        if meta.get("season") not in (None, ""): tag.setSeason(int(meta.get("season")))
        if meta.get("episode") not in (None, ""): tag.setEpisode(int(meta.get("episode")))
        if meta.get("year"): tag.setYear(int(meta.get("year")))
        if meta.get("genre"): tag.setGenres(meta.get("genre") if isinstance(meta.get("genre"),list) else [str(meta.get("genre"))])
        if meta.get("mpaa"): tag.setMpaa(str(meta.get("mpaa")))
    except Exception:
        set_video_info(li, title, plot)
    art = {}
    if poster: art.update({"thumb":poster, "icon":poster, "poster":poster})
    if fanart: art.update({"fanart":fanart, "landscape":fanart})
    if art: li.setArt(art)
    if fanart: li.setProperty("fanart_image", fanart)
    if kodi_has_addon("inputstream.ffmpegdirect"):
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
        li.setProperty("inputstream.ffmpegdirect.mime_type", "application/vnd.apple.mpegurl")
        li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
        li.setProperty("inputstream.ffmpegdirect.user_agent", UA)
        li.setProperty("inputstream.ffmpegdirect.stream_headers", "Referer=https://pluto.tv/")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def view_pluto_download_info(folder, name):
    folder = unquote_plus(folder); name = unquote_plus(name)
    meta = read_json(folder.rstrip("/\\") + "/download.json", {}) if xbmcvfs.exists(folder.rstrip("/\\") + "/download.json") else {}
    text = "Anbieter: Pluto TV\nSpeicherort: %s\n\n" % folder
    text += "Die Mediensegmente liegen lokal. Bei AES-128-geschuetzten Titeln werden benoetigte Schluessel bei der Wiedergabe online vom Pluto-Server angefordert; sie werden nicht im Download gespeichert."
    if meta.get("encryption"): text += "\n\nVerschluesselung: %s" % meta.get("encryption")
    xbmcgui.Dialog().textviewer(name or "Pluto Download", text)


def view_pluto_download_delete(folder, name):
    folder = unquote_plus(folder); name = unquote_plus(name)
    if not xbmcgui.Dialog().yesno("Download loeschen", "%s wirklich loeschen?" % name): return
    try:
        # Kodi-VFS hat kein rekursives rmdir; Dateien/Unterordner kontrolliert entfernen.
        def _rm_tree(path):
            dirs, files = xbmcvfs.listdir(path)
            for fn in files: xbmcvfs.delete(path.rstrip("/\\") + "/" + fn)
            for dn in dirs:
                sub = path.rstrip("/\\") + "/" + dn + "/"; _rm_tree(sub); xbmcvfs.rmdir(sub)
        _rm_tree(folder); xbmcvfs.rmdir(folder)
        xbmcgui.Dialog().notification("Downloads", "%s geloescht" % name, xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        log("[Pluto Download] Loeschen fehlgeschlagen: %s" % exc, xbmc.LOGERROR)
        notify("Download konnte nicht geloescht werden", True, 5000)


def view_pluto_vod_download(url, name, plot="", poster="", fanart="", season="", episode="", media_type="", show_title="", genre="", mpaa="", year=""):

    """Speichert Pluto-HLS-VOD. Verschluesselte HLS-Segmente bleiben unveraendert verschluesselt; Schluessel werden nicht gespeichert."""
    from urllib.parse import urljoin
    raw_url = unquote_plus(url); name = unquote_plus(name)
    plot = unquote_plus(plot) if plot else ""
    poster = unquote_plus(poster) if poster else ""
    fanart = unquote_plus(fanart) if fanart else ""
    show_title = unquote_plus(show_title) if show_title else ""
    genre = unquote_plus(genre) if genre else ""; mpaa = unquote_plus(mpaa) if mpaa else ""
    try: year = int(year) if year else ""
    except Exception: year = ""
    base = _rktv_download_path()
    if not base: return
    root = _vod_download_root(base) + "Pluto VoD/"; xbmcvfs.mkdirs(root)
    safe = _rktv_safe_filename(name)
    if media_type == "episode" and show_title:
        package_root = root + "Serien/" + _rktv_safe_filename(show_title) + "/Staffel %02d/" % int(season or 0)
        safe = ("S%02dE%02d - %s" % (int(season or 0), int(episode or 0), _rktv_safe_filename(name)))
    elif media_type == "movie":
        package_root = root + "Filme/"
    else:
        package_root = root
    xbmcvfs.mkdirs(package_root)
    xbmcgui.Dialog().notification("Pluto Download", "Download %s gestartet" % name, xbmcgui.NOTIFICATION_INFO, 4000)
    started_at=time.time(); downloaded=0; total_est=0; selected_bw=0
    _download_status_write("Pluto", name, 0, 0, "running", False, started_at)
    try:
        stream = pluto_build_vod_stream_url(raw_url)
        if not stream: raise Exception("Stream konnte nicht aufgeloest werden")
        headers={"User-Agent":UA,"Referer":"https://pluto.tv/"}

        # Pluto-CDN kann einzelne HLS-Segmente voruebergehend mit 5xx/Timeout beantworten.
        # Solche transienten Fehler erneut versuchen, statt den kompletten VoD-Download sofort abzubrechen.
        def _get_segment_with_retry(seg_url, max_attempts=5):
            delays=(1, 2, 4, 8, 12)
            for attempt in range(1, max_attempts + 1):
                if xbmc.Monitor().abortRequested():
                    raise Exception("Download abgebrochen")
                try:
                    resp=requests.get(seg_url,headers=headers,timeout=30)
                    resp.raise_for_status()
                    return resp
                except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as exc:
                    retryable=True
                    status=None
                except requests.exceptions.HTTPError as exc:
                    status=getattr(exc.response, "status_code", None)
                    retryable=status in (408, 429, 500, 502, 503, 504)
                if not retryable or attempt >= max_attempts:
                    raise
                wait_s=delays[min(attempt-1, len(delays)-1)]
                log("[Pluto Download] Segmentabruf fehlgeschlagen (HTTP=%s), Retry %d/%d in %ds" % (status if status else "Netzwerk/Timeout", attempt+1, max_attempts, wait_s), xbmc.LOGWARNING)
                # In kurzen Schritten warten, damit Kodi weiterhin sauber beendet werden kann.
                for _ in range(wait_s * 10):
                    if xbmc.Monitor().abortRequested():
                        raise Exception("Download abgebrochen")
                    xbmc.sleep(100)
            raise Exception("Segmentabruf fehlgeschlagen")

        rr=requests.get(stream,headers=headers,timeout=30); rr.raise_for_status(); text=rr.text
        # Masterplaylist: hoechste BANDWIDTH waehlen.
        if "#EXT-X-STREAM-INF" in text:
            lines=[x.strip() for x in text.splitlines() if x.strip()]
            variants=[]
            for i,line in enumerate(lines):
                if line.startswith("#EXT-X-STREAM-INF") and i+1<len(lines):
                    m=re.search(r"BANDWIDTH=(\d+)",line)
                    variants.append((int(m.group(1)) if m else 0,urljoin(stream,lines[i+1])))
            if variants:
                selected_bw, stream=max(variants,key=lambda x:x[0])
                rr=requests.get(stream,headers=headers,timeout=30); rr.raise_for_status(); text=rr.text

        lines=[x.strip() for x in text.splitlines() if x.strip()]
        key_lines=[x for x in lines if x.startswith("#EXT-X-KEY") and "METHOD=NONE" not in x]
        encrypted=bool(key_lines)
        # Pluto liefert bei HLS meist keine Gesamtdateigroesse. Aus Variant-Bitrate und EXTINF-Dauer
        # laesst sich aber eine brauchbare Gesamtgroesse fuer Prozent/ETA schaetzen.
        try:
            duration=sum(float(m.group(1)) for m in [re.search(r"#EXTINF:([0-9.]+)", x) for x in lines] if m)
            if selected_bw and duration: total_est=int(selected_bw*duration/8.0)
        except Exception: total_est=0
        _download_status_write("Pluto", name, downloaded, total_est, "running", bool(total_est), started_at)
        # Bei verschluesseltem HLS als Paket speichern. Die Mediendaten werden nicht entschluesselt.
        if encrypted:
            folder=package_root+safe+"/"; xbmcvfs.mkdirs(folder)
            segdir=folder+"segments/"; xbmcvfs.mkdirs(segdir)
            out_lines=[]; seg_index=0
            total=sum(1 for x in lines if x and not x.startswith('#'))
            for line in lines:
                if line.startswith("#EXT-X-MAP"):
                    m=re.search(r'URI="([^"]+)"',line)
                    if m:
                        u=urljoin(stream,m.group(1)); r=_get_segment_with_retry(u)
                        fn="init.mp4"; f=xbmcvfs.File(segdir+fn,"wb"); f.write(r.content); f.close(); downloaded += len(r.content)
                        _download_status_write("Pluto", name, downloaded, total_est, "running", bool(total_est), started_at)
                        line=line.replace(m.group(1),"segments/"+fn)
                    out_lines.append(line); continue
                if line.startswith("#EXT-X-KEY"):
                    # Remote Key-URI bleibt absichtlich erhalten; kein DRM-/Key-Material wird gespeichert.
                    m=re.search(r'URI="([^"]+)"',line)
                    if m: line=line.replace(m.group(1),urljoin(stream,m.group(1)))
                    out_lines.append(line); continue
                if line.startswith("#"):
                    out_lines.append(line); continue
                seg_index += 1
                u=urljoin(stream,line); r=_get_segment_with_retry(u)
                ext=".m4s" if ".m4s" in u.split('?')[0].lower() else ".ts"
                fn="seg_%06d%s" % (seg_index,ext)
                f=xbmcvfs.File(segdir+fn,"wb"); f.write(r.content); f.close(); downloaded += len(r.content)
                _download_status_write("Pluto", name, downloaded, total_est, "running", bool(total_est), started_at)
                out_lines.append("segments/"+fn)
            f=xbmcvfs.File(folder+"playlist.m3u8","w"); f.write("\n".join(out_lines)+"\n"); f.close()
            f=xbmcvfs.File(folder+"source.m3u8","w"); f.write(text); f.close()
            write_json(folder+"download.json", {"provider":"Pluto TV", "title":name, "plot":plot, "poster":poster, "fanart":fanart, "season":season, "episode":episode, "media_type":media_type, "show_title":show_title, "genre":genre, "mpaa":mpaa, "year":year, "raw_url":raw_url, "stream_url":stream, "encrypted":True, "encryption":"AES-128", "key_storage":False, "completed_at":time.time()})
            _download_status_write("Pluto", name, downloaded, downloaded, "done", False, started_at)
            log("[Pluto Download] Verschluesseltes HLS-Paket gespeichert: %s (%d Segmente)" % (folder,seg_index))
            xbmcgui.Dialog().notification("Pluto Download", "Download %s erledigt (verschluesselt)" % name, xbmcgui.NOTIFICATION_INFO, 7000)
            return

        segs=[]; init=None
        for line in lines:
            if line.startswith("#EXT-X-MAP"):
                m=re.search(r'URI="([^"]+)"',line)
                if m: init=urljoin(stream,m.group(1))
            elif not line.startswith("#"):
                segs.append(urljoin(stream,line))
        if not segs: raise Exception("Keine HLS-Segmente gefunden")
        ext=".mp4" if init or any(".m4s" in x for x in segs) else ".ts"
        folder=package_root+safe+"/"; xbmcvfs.mkdirs(folder)
        out=folder+"video"+ext
        f=xbmcvfs.File(out,"wb")
        try:
            urls=([init] if init else [])+segs
            for u in urls:
                if xbmc.Monitor().abortRequested(): raise Exception("Download abgebrochen")
                r=_get_segment_with_retry(u); f.write(r.content); downloaded += len(r.content)
                _download_status_write("Pluto", name, downloaded, total_est, "running", bool(total_est), started_at)
        finally: f.close()
        write_json(folder+"download.json", {"provider":"Pluto TV", "title":name, "plot":plot, "poster":poster, "fanart":fanart, "season":season, "episode":episode, "media_type":media_type, "show_title":show_title, "genre":genre, "mpaa":mpaa, "year":year, "media_file":"video"+ext, "encrypted":False, "completed_at":time.time()})
        _download_status_write("Pluto", name, downloaded, downloaded, "done", False, started_at)
        log("[Pluto Download] Fertig: %s" % out)
        xbmcgui.Dialog().notification("Pluto Download", "Download %s erledigt" % name, xbmcgui.NOTIFICATION_INFO, 7000)
    except Exception as exc:
        _download_status_write("Pluto", name, downloaded, total_est, "error", bool(total_est), started_at, str(exc))
        log("[Pluto Download] Fehler: %s" % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Pluto Download", "Download %s fehlgeschlagen" % name, xbmcgui.NOTIFICATION_ERROR, 7000)


# ----------------------------------------------------------
# Pluto TV Live - provider-native API
# Nutzt dieselbe lokale Pluto-Sitzung wie VoD. Die Region wird von Pluto anhand
# der echten Verbindung bestimmt; es werden weder X-Forwarded-For noch Proxy,
# VPN oder andere Standort-Vortaeuschungen verwendet.
# ----------------------------------------------------------
PLUTO_LIVE_CHANNELS_URL = "https://service-channels.clusters.pluto.tv/v2/guide/channels"
PLUTO_LIVE_CATEGORIES_URL = "https://service-channels.clusters.pluto.tv/v2/guide/categories"
PLUTO_LIVE_TIMELINES_URL = "https://service-channels.clusters.pluto.tv/v2/guide/timelines"
PLUTO_LIVE_CACHE_FILE = PROFILE + "pluto_live_native.json"


def _pluto_live_headers():
    token = pluto_boot().get("sessionToken", "")
    return {
        "accept": "*/*",
        "authorization": f"Bearer {token}",
        "origin": "https://pluto.tv",
        "referer": "https://pluto.tv/",
        "user-agent": UA,
    }


def _pluto_iso_ts(value):
    if not value:
        return 0
    try:
        # Python 3.8+ / Kodi 19+: Pluto liefert UTC-ISO-Zeitstempel.
        from datetime import datetime
        text = str(value).strip().replace("Z", "+00:00")
        return int(datetime.fromisoformat(text).timestamp())
    except Exception:
        return 0


def _pluto_timeline_title(item):
    if not isinstance(item, dict):
        return ""
    episode = item.get("episode") or {}
    series = item.get("series") or {}
    return (item.get("title") or item.get("name") or
            (episode.get("name") if isinstance(episode, dict) else "") or
            (episode.get("title") if isinstance(episode, dict) else "") or
            (series.get("name") if isinstance(series, dict) else "") or "")


def _pluto_timeline_now_next(rows):
    now_ts = int(time.time())
    parsed = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        start = _pluto_iso_ts(row.get("start") or row.get("startTime") or row.get("startDate"))
        stop = _pluto_iso_ts(row.get("stop") or row.get("end") or row.get("endTime") or row.get("stopTime"))
        if not start:
            continue
        if not stop:
            stop = start + 3600
        parsed.append({"start": start, "stop": stop, "title": _pluto_timeline_title(row)})
    parsed.sort(key=lambda x: x["start"])
    current = next((x for x in parsed if x["start"] <= now_ts < x["stop"]), None)
    nxt = next((x for x in parsed if x["start"] > now_ts), None)
    return current, nxt


def pluto_live_cache_ready():
    if not xbmcvfs.exists(PLUTO_LIVE_CACHE_FILE):
        return False
    cached = read_json(PLUTO_LIVE_CACHE_FILE, {})
    return bool(cached.get("channels") and cached.get("ts") and
                (time.time() - cached["ts"]) <= get_pluto_cache_seconds())


def _pluto_live_stream_url(channel_id):
    boot = pluto_boot()
    token = boot.get("sessionToken", "")
    if not token or not channel_id:
        return ""
    servers = boot.get("servers") or {}
    stitcher = (servers.get("stitcher") or PLUTO_STITCHER_BASE).rstrip("/")
    params = boot.get("stitcherParams") or ""
    url = f"{stitcher}/v2/stitch/hls/channel/{channel_id}/master.m3u8?jwt={quote_plus(token)}&masterJWTPassthrough=true"
    if params:
        url += "&" + str(params).lstrip("?&")
    return url


def load_pluto_live_channels(force=False):
    """Lädt Pluto Live direkt über Plutos eigene, lokal geolokalisierte API."""
    if not force and pluto_live_cache_ready():
        cached = read_json(PLUTO_LIVE_CACHE_FILE, {})
        channels = cached.get("channels", [])
        # Stream-JWTs sind kurzlebiger als der Senderlisten-Cache. Deshalb bei
        # jedem Cache-Hit nur die URL aus der aktuellen Pluto-Sitzung erneuern.
        for item in channels:
            item["url"] = _pluto_live_stream_url(item.get("channel_id", ""))
        log(f"[Pluto Live] NATIVE CACHE HIT: {len(channels)} Sender")
        return channels

    headers = _pluto_live_headers()
    if not headers.get("authorization", "").replace("Bearer ", "").strip():
        notify("Pluto Live: keine gültige Pluto-Sitzung", True, 5000)
        return []
    params = {"channelIds": "", "offset": "0", "limit": "1000", "sort": "number:asc"}
    try:
        r = requests.get(PLUTO_LIVE_CHANNELS_URL, headers=headers, params=params, timeout=20)
        log(f"[Pluto Live] GET channels -> HTTP {r.status_code}")
        r.raise_for_status()
        channel_list = (r.json() or {}).get("data", [])
    except Exception as e:
        log(f"[Pluto Live] Senderabruf fehlgeschlagen: {e}", xbmc.LOGERROR)
        stale = read_json(PLUTO_LIVE_CACHE_FILE, {})
        return stale.get("channels", [])

    if not channel_list:
        log("[Pluto Live] Provider liefert für die aktuelle Verbindung keine Live-Sender", xbmc.LOGWARNING)
        return []

    categories = {}
    try:
        r = requests.get(PLUTO_LIVE_CATEGORIES_URL, headers=headers, params=params, timeout=15)
        log(f"[Pluto Live] GET categories -> HTTP {r.status_code}")
        if r.status_code == 200:
            for cat in (r.json() or {}).get("data", []):
                cname = cat.get("name") or "Sonstige"
                for cid in cat.get("channelIDs", []) or []:
                    categories[cid] = cname
    except Exception as e:
        log(f"[Pluto Live] Kategorien nicht verfügbar: {e}", xbmc.LOGWARNING)

    timelines = {}
    if epg_enabled("pluto"):
        ids = [str(ch.get("id") or "") for ch in channel_list if ch.get("id")]
        for pos in range(0, len(ids), 100):
            group = ids[pos:pos + 100]
            from datetime import datetime, timezone
            start_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
            tparams = {"start": start_iso, "channelIds": ",".join(group), "duration": "240"}
            try:
                r = requests.get(PLUTO_LIVE_TIMELINES_URL, headers=headers, params=tparams, timeout=20)
                log(f"[Pluto Live] GET timelines {pos + 1}-{pos + len(group)} -> HTTP {r.status_code}")
                if r.status_code != 200:
                    continue
                for entry in (r.json() or {}).get("data", []):
                    cid = str(entry.get("channelId") or "")
                    if cid:
                        timelines[cid] = entry.get("timelines", []) or []
            except Exception as e:
                log(f"[Pluto Live] EPG-Abruf fehlgeschlagen: {e}", xbmc.LOGWARNING)

    channels = []
    for ch in channel_list:
        cid = str(ch.get("id") or "").strip()
        if not cid:
            continue
        logo = ""
        for image in ch.get("images", []) or []:
            if image.get("type") == "colorLogoPNG" and image.get("url"):
                logo = image.get("url")
                break
        epg_now, epg_next = _pluto_timeline_now_next(timelines.get(cid, []))
        channels.append({
            "name": ch.get("name") or cid,
            "url": _pluto_live_stream_url(cid),
            "logo": logo,
            "group": categories.get(cid) or "Sonstige",
            "tvgid": cid,
            "tvgname": ch.get("name") or "",
            "channel_id": cid,
            "chno": ch.get("number") or 9999,
            "epg_now": epg_now,
            "epg_next": epg_next,
        })

    channels = [c for c in channels if c.get("url")]
    channels.sort(key=lambda c: (c.get("chno", 9999), (c.get("name") or "").lower()))
    write_json_compact(PLUTO_LIVE_CACHE_FILE, {"ts": time.time(), "channels": channels})
    log(f"[Pluto Live] NATIVE LOADED: {len(channels)} Sender, EPG={sum(1 for c in channels if c.get('epg_now'))}")
    return channels
