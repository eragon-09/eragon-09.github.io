"""
Stalker API Calls
"""
from __future__ import absolute_import, division, unicode_literals

import json
from urllib.parse import urljoin
import math
import requests
from .globals import G
from .auth import Auth
from .loggers import Logger
from .utils import get_int_value

import os
import time

# Kodi-only modules (fallbacks keep unit tests / non-Kodi runs from crashing)
try:
    import xbmcvfs  # type: ignore
except Exception:  # pragma: no cover
    xbmcvfs = None

try:
    import xbmcgui  # type: ignore
except Exception:  # pragma: no cover
    xbmcgui = None

try:
    import xbmcaddon  # type: ignore
except Exception:  # pragma: no cover
    xbmcaddon = None


_LAST_NOTIFY = 0


def _rate_notify(title, message, cooldown=10):
    """Simple error notification with cooldown (Kodi UI if available)."""
    global _LAST_NOTIFY
    now = time.time()
    if now - _LAST_NOTIFY < cooldown:
        return
    _LAST_NOTIFY = now
    try:
        if xbmcgui:
            xbmcgui.Dialog().notification(str(title), str(message), xbmcgui.NOTIFICATION_ERROR, 5000)
    except Exception:
        pass


# EPG cache file (3h TTL). If your addon id differs, adjust the path below.
def _translate_path(p):
    try:
        if xbmcvfs:
            return xbmcvfs.translatePath(p)
    except Exception:
        pass
    # best-effort fallback
    return p.replace('special://profile/', '')

epg_path = _translate_path('special://profile/addon_data/plugin.video.titanmacvodedition/epg.json')

# Some parts of the addon import this symbol directly
epg_caches = {}


def clear_epg_cache():
    """Clear EPG – both in-memory and on disk."""
    global _epg_mem, _epg_loaded_ts
    _epg_mem = None
    _epg_loaded_ts = 0
    try:
        epg_caches.clear()
    except Exception:
        pass
    try:
        if os.path.exists(epg_path):
            os.remove(epg_path)
    except Exception:
        pass


def _ensure_epg_dir():
    d = os.path.dirname(epg_path)
    try:
        if xbmcvfs:
            if not xbmcvfs.exists(d):
                xbmcvfs.mkdirs(d)
        else:
            os.makedirs(d, exist_ok=True)
    except Exception:
        # don't hard-fail on cache dir issues
        pass


_epg_mem = None
_epg_loaded_ts = 0


def get_timestamp():
    return int(time.time())


def _get_epg_interval_seconds(default_minutes=120):
    """EPG interval in seconds based on enum setting epg_interval."""
    try:
        addon = xbmcaddon.Addon('plugin.video.titanmacvodedition') if xbmcaddon else None
        raw = (addon.getSetting('epg_interval') or '').strip() if addon else ''
        options = [30, 60, 120, 180]
        if raw in map(str, options):
            return int(raw) * 60
        # Some Kodi versions return enum index instead of displayed value
        try:
            idx = int(raw)
            if 0 <= idx < len(options):
                return int(options[idx]) * 60
        except Exception:
            pass
    except Exception:
        pass
    return int(default_minutes) * 60


def is_cache_expired(timestamp):
    """Return True if the in-memory EPG cache is older than the configured TTL."""
    ttl_seconds = _get_epg_interval_seconds()
    return (get_timestamp() - int(timestamp or 0)) > int(ttl_seconds)


def get_epg_data():
    """Fetch and cache TV EPG (period=2 days). Returns raw portal list/dict."""
    _ensure_epg_dir()

    params = {
        'type': 'itv',
        'action': 'get_epg_info',
        'period': '2',
        'JsHttpRequest': '1-xml'
    }

    # If cache is fresh, return it.
    try:
        if os.path.exists(epg_path):
            last_modified = os.stat(epg_path).st_mtime
            if (time.time() - last_modified) <= _get_epg_interval_seconds():
                with open(epg_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                try:
                    os.remove(epg_path)
                except Exception:
                    pass
    except Exception:
        # ignore cache read errors and refetch
        pass

    # Fetch from portal
    try:
        root = Api._call_stalker_portal(params) or {}
        data = (root.get('js', {}) or {}).get('data', []) or []
    except Exception:
        data = []

    # Persist cache
    try:
        with open(epg_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, sort_keys=False, ensure_ascii=False)
    except Exception:
        pass

    # New EPG loaded -> invalidate per-channel rendered text cache
    try:
        epg_caches.clear()
    except Exception:
        pass

    return data



def get_epg_dict():
    """Return EPG dict from memory/file cache (robust)."""
    global _epg_mem, _epg_loaded_ts

    try:
        if _epg_mem is not None and not is_cache_expired(_epg_loaded_ts):
            return _epg_mem
    except Exception:
        pass


    # Cache expired -> drop per-channel text cache so Now/Next updates.
    try:
        epg_caches.clear()
    except Exception:
        pass

    _ensure_epg_dir()

    # Ensure we have a cache file
    try:
        if (not os.path.exists(epg_path)) or os.path.getsize(epg_path) == 0:
            get_epg_data()
    except Exception:
        pass

    # Load
    try:
        with open(epg_path, 'r', encoding='utf-8') as f:
            _epg_mem = json.load(f)
    except json.JSONDecodeError:
        # corrupt -> refetch once
        try:
            get_epg_data()
            with open(epg_path, 'r', encoding='utf-8') as f:
                _epg_mem = json.load(f)
        except Exception:
            _epg_mem = {}
    except Exception:
        _epg_mem = {}

    _epg_loaded_ts = get_timestamp()
    return _epg_mem


def short_epg_from_dict(epgid, epg_dict):
    """Build a 1-3 line EPG text (Kodi markup) from preloaded dict."""
    try:
        items = epg_dict.get(str(epgid)) or epg_dict.get(int(epgid))
    except Exception:
        items = None
    if not items:
        return "[COLOR=red]Keine Informationen vorhanden[/COLOR]"
    lines = []
    for i in items[:3]:
        try:
            lines.append(f"{i.get('t_time')} - {i.get('t_time_to')}: {i.get('name')}")
        except Exception:
            continue
    return "\n".join(lines) if lines else "[COLOR=red]Keine Informationen vorhanden[/COLOR]"



def _safe_join_portal(base: str, path: str) -> str:
    # joins base + path robustly, base must have scheme and host
    try:
        return urljoin(base if base.endswith('/') else base + '/', path.lstrip('/'))
    except Exception:
        return base + path

class Api:
    """API calls"""

    # Public wrappers (needed for module-level helpers like EPG)
    @staticmethod
    def _call_stalker_portal(params, return_response_body=True):
        return Api.__call_stalker_portal(params, return_response_body)

    @staticmethod
    def _call_stalker_portal_return_response(params):
        return Api.__call_stalker_portal_return_response(params)


    @staticmethod
    def __call_stalker_portal(params, return_response_body=True):
        """Method to call portal"""
        response = Api.__call_stalker_portal_return_response(params)
        if return_response_body:
            return response.json()
        return None

    @staticmethod
    def __call_stalker_portal_return_response(params):
        """Method to call portal"""
        retries = 0
        url = G.portal_config.portal_url
        mac_cookie = G.portal_config.mac_cookie
        referrer = G.portal_config.server_address
        auth = Auth()
        while True:
            token = auth.get_token(retries > 0)
            Logger.debug("Calling Stalker portal {} with params {}".format(url, json.dumps(params)))
            response = requests.get(url=url,
                                    headers={'Cookie': mac_cookie,
                                             'SN': G.portal_config.serial_number,
                                             'Authorization': 'Bearer ' + token,
                                             'X-User-Agent': 'Model: MAG250; Link: WiFi', 'Referrer': referrer,
                                             'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'},
                                    params=params,
                                    timeout=30
                                    )
            if response.text.find('Authorization failed') == -1 or retries == G.addon_config.max_retries:
                break
            if retries > 1:
                auth.clear_cache()
            retries += 1
        return response

    @staticmethod
    def get_vod_categories():
        """Get video categories"""
        params = {'type': 'vod', 'action': 'get_categories'}
        return Api.__call_stalker_portal(params)['js']

    @staticmethod
    def get_series_categories():
        """Get video categories"""
        params = {'type': 'series', 'action': 'get_categories'}
        return Api.__call_stalker_portal(params).get('js', False)

    @staticmethod
    def get_tv_genres():
        """Get tv genres"""
        params = {'type': 'itv', 'action': 'get_genres'}
        return Api.__call_stalker_portal(params)['js']

    @staticmethod
    def remove_favorites(video_id, _type):
        """Remove from favorites"""
        if _type == 'itv':
            Api.__remove_tv_favorites(video_id)
        else:
            params = {'type': _type, 'action': 'del_fav', 'video_id': video_id}
            Api.__call_stalker_portal(params, False)

    @staticmethod
    def add_favorites(video_id, _type):
        """Add to favorites"""
        if _type == 'itv':
            Api.__add_tv_favorites(video_id)
        else:
            params = {'type': _type, 'action': 'set_fav', 'video_id': video_id}
            Api.__call_stalker_portal(params, False)

    @staticmethod
    def __add_tv_favorites(video_id):
        """Add to tv favorites"""
        params = {'type': 'itv', 'action': 'get_all_fav_channels'}
        fav_channels = Api.__call_stalker_portal(params)['js']['data']
        fav_ch = [video_id]
        for fav_channel in fav_channels:
            fav_ch.append(fav_channel['id'])
        params = {'type': 'itv', 'action': 'set_fav', 'fav_ch': ','.join(fav_ch)}
        Api.__call_stalker_portal(params, False)

    @staticmethod
    def __remove_tv_favorites(video_id):
        """Add to tv favorites"""
        params = {'type': 'itv', 'action': 'get_all_fav_channels'}
        fav_channels = Api.__call_stalker_portal(params)['js']['data']
        fav_ch = []
        for fav_channel in fav_channels:
            if video_id != fav_channel['id']:
                fav_ch.append(fav_channel['id'])
        params = {'type': 'itv', 'action': 'set_fav', 'fav_ch': ','.join(fav_ch)}
        Api.__call_stalker_portal(params, False)

    @staticmethod
    def get_vod_favorites(page):
        """Get favorites"""
        params = {'type': 'vod', 'action': 'get_ordered_list', 'fav': '1', 'sortby': 'added'}
        return Api.get_listing(params, page)

    @staticmethod
    def get_series_favorites(page):
        """Get favorites"""
        params = {'type': 'series', 'action': 'get_ordered_list', 'fav': '1', 'sortby': 'added'}
        return Api.get_listing(params, page)

    @staticmethod
    def get_tv_favorites(page):
        """Get favorites"""
        params = {'type': 'itv', 'action': 'get_ordered_list', 'fav': '1', 'sortby': 'number'}
        return Api.get_listing(params, page)

    @staticmethod
    def get_seasons(video_id):
        """Get favorites"""
        params = {'type': 'series', 'action': 'get_ordered_list', 'movie_id': video_id, 'sortby': 'added'}
        return Api.__call_stalker_portal(params)['js']

    @staticmethod
    def get_tv_channels(category_id, page, search_term, fav):
        """Get videos for a category"""
        params = {'type': 'itv', 'action': 'get_ordered_list', 'genre': category_id, 'sortby': 'number', 'fav': fav}
        if bool(search_term.strip()):
            params.update({'search': search_term})
        return Api.get_listing(params, page)

    @staticmethod
    def get_videos(category_id, page, search_term, fav):
        """Get videos for a category"""
        params = {'type': 'vod', 'action': 'get_ordered_list', 'category': category_id, 'sortby': 'added', 'fav': fav}
        if bool(search_term.strip()):
            params.update({'search': search_term})
        return Api.get_listing(params, page)

    @staticmethod
    def get_series(category_id, page, search_term, fav):
        """Get videos for a category"""
        params = {'type': 'series', 'action': 'get_ordered_list', 'category': category_id, 'sortby': 'added', 'fav': fav}
        if bool(search_term.strip()):
            params.update({'search': search_term})
        return Api.get_listing(params, page)

    @staticmethod
    def get_listing(params, page):
        """Generic method to get listing"""
        params.update({'p': str(page)})
        response = Api.__call_stalker_portal(params)['js']
        videos = response['data']
        total_items = response['total_items']
        max_page_items = response['max_page_items']
        total_pages = int(math.ceil(float(total_items) / float(max_page_items)))
        for page_no in range(int(page) + 1, min(int(page) + G.addon_config.max_page_limit, total_pages + 1)):
            params.update({'p': str(page_no)})
            response = Api.__call_stalker_portal(params)['js']
            videos += response['data']
        return {'max_page_items': max_page_items, 'total_items': total_items, 'data': videos}

    @staticmethod
    def get_vod_stream_url(video_id, series, cmd, use_cmd):
        """Get VOD stream url"""
        if use_cmd == '0':
            response = Api.__get_vod_stream_url_video_id(video_id, series)
            if response.status_code != 200:
                stream_url = Api.__get_vod_stream_url_cmd(cmd, series)
            else:
                stream_url = response.json()['js']['cmd']
        else:
            stream_url = Api.__get_vod_stream_url_cmd(cmd, series)
        if stream_url.find(' ') != -1:
            stream_url = stream_url[(stream_url.find(' ') + 1):]
        # Api.__call_stalker_portal({'type': 'stb', 'action': 'log', 'real_action': 'play', 'param': stream_url, 'content_id': video_id})
        return stream_url

    @staticmethod
    def __get_vod_stream_url_cmd(cmd, series):
        """Get VOD stream url"""
        return Api.__call_stalker_portal({'type': 'vod', 'action': 'create_link', 'cmd': cmd, 'series': str(series)})['js']['cmd']

    @staticmethod
    def __get_vod_stream_url_video_id(video_id, series):
        """Get VOD stream url"""
        return Api.__call_stalker_portal_return_response({'type': 'vod', 'action': 'create_link', 'cmd': '/media/' + video_id + '.mpg', 'series': str(series)}
                                                         )

    @staticmethod
    def get_tv_stream_url(params):
        """Get TV Channel stream url"""
        if bool(get_int_value(params, 'use_http_tmp_link')) or bool(get_int_value(params, 'use_load_balancing')):
            cmd = Api.__call_stalker_portal(
                {'type': 'itv', 'action': 'create_link', 'cmd': params['cmd']}
            )['js']['cmd']
        else:
            cmd = params['cmd']
        if cmd.find(' ') != -1:
            cmd = cmd[(cmd.find(' ') + 1):]
        return cmd
