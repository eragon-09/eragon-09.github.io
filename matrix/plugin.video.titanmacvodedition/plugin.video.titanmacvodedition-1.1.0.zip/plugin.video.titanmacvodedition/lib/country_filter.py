# -*- coding: utf-8 -*-
"""
country_filter.py
Ländergruppen-Helfer für TiTan-Stalker-Addon.

Beschränkt auf DE / AT / CH.
"""

from __future__ import absolute_import, division, unicode_literals
import re

# Nur diese Tokens gelten als Ländergruppen
COUNTRY_TOKENS = {'DE', 'AT', 'CH'}


def get_country_tokens():
    """
    Gibt die Menge der Ländergruppen-Tokens zurück.
    Aktuell: {'DE', 'AT', 'CH'}
    """
    return set(COUNTRY_TOKENS)


def matches_country_tokens(name, tokens=None):
    """
    Prüft, ob ein Name (Channel/Genre/Kategorie) eine der Ländergruppen enthält.
    Erlaubt z.B. 'DE FILME', 'AT HD', 'CH SERIEN', etc.
    """
    if not name:
        return False
    up = str(name).upper().strip()
    if not tokens:
        tokens = COUNTRY_TOKENS

    # in einzelne "Wörter" splitten
    words = re.split(r'[^A-Z0-9]+', up)

    # direkter Token-Treffer
    if any(tok in words for tok in tokens):
        return True

    # etwas großzügigere Varianten
    for tok in tokens:
        if (
            up.startswith(tok + ' ')
            or up.endswith(' ' + tok)
            or up == tok
            or (' ' + tok + ' ') in (' ' + up + ' ')
        ):
            return True
    return False


def filter_categories_for_country_groups(categories, tokens=None):
    """
    Filtert eine Liste von Kategorien (dicts) auf Einträge,
    deren Name eine der Ländergruppen enthält.
    """
    if tokens is None:
        tokens = COUNTRY_TOKENS

    filtered = []
    for cat in categories or []:
        if not isinstance(cat, dict):
            continue
        name = (
            cat.get('title') or cat.get('name') or
            cat.get('alias') or cat.get('abbr') or ''
        )
        if matches_country_tokens(name, tokens):
            filtered.append(cat)
    return filtered
