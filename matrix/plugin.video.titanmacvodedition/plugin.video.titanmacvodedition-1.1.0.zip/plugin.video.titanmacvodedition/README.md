# TiTan MAC VOD Edition Kodi Add-on

**plugin.video.titanmacvodedition** ist ein Kodi-Addon für Stalker-/Portal-MAC-basierte IPTV- und Video-on-Demand-Dienste.  
Mit dem Addon kannst du **Live-TV**, **VoD** und **Serien** aus kompatiblen Portalen nutzen.

## Funktionen

- Live-TV, VoD und Serien
- Portal-/Server-Auswahl direkt im Addon
- MAC-Auswahl direkt im Addon
- Manuelle Eingabe der Portal-URL in den Einstellungen
- PVR-Listen-Übernahme
- Cache löschen direkt im Hauptmenü
- Favoriten-Bereiche für TV, VoD und Serien
- Menü mit angepassten Icons
- Verbesserte EPG-Logik mit robusterem Refresh-Verhalten
- Unterstützung für lokale Portal-/MAC-Auswahl
- Unterstützung für UpNext

## Hauptmenü

- TiTan TV
- TiTan VoD
- TiTan Serien
- Server wählen
- MAC wählen
- Liste in PVR Laden
- Cache löschen

## Hinweise

- Die **Portal URL** kann manuell in den Einstellungen gesetzt werden.
- Beim Wechsel von **Portal** oder **MAC** sollte der Cache gelöscht werden, damit EPG-, Token- und Sitzungsdaten sauber neu aufgebaut werden.
- Das EPG wird über das Portal geladen und durch eine verbesserte Cache-/Refresh-Logik aktuell gehalten.

## Changelog

### v1.0.0
- Basisversion von TiTan MAC VOD Edition
- Unterstützung für Live-TV, VoD und Serien
- Portal-/MAC-basierte Nutzung für Stalker-kompatible Dienste

### v1.1.0
- Hauptmenü erweitert
- Server wählen und MAC wählen integriert
- PVR-Listen-Funktion ergänzt

### v1.2.0
- Cache löschen im Hauptmenü ergänzt
- Menü-Reihenfolge und Farbdesign angepasst
- Eigene Icons für Hauptmenüeinträge eingebunden
- Favoriten-Icon ergänzt

### v1.3.0
- Manuelle Portal-URL in den Einstellungen freigeschaltet
- Verbesserte EPG-Logik übernommen
- Robusteres EPG-Caching und Refresh-Verhalten
- EPG-Hintergrundaktualisierung verbessert

## Kompatibilität

- Kodi 19.x Matrix und höher

## Lizenz

GPL-3.0-or-later
