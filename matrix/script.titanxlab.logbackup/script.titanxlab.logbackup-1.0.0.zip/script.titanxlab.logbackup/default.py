import os
import zipfile
import datetime
import xbmcgui
import xbmcvfs

ADDON_NAME = 'TitanX Lab - Log Backup'

log_path = xbmcvfs.translatePath('special://logpath/kodi.log')

dialog = xbmcgui.Dialog()
dest_folder = dialog.browse(3, 'Zielordner auswählen', 'files')

if dest_folder:
    dest_folder_real = xbmcvfs.translatePath(dest_folder)

    timestamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    zip_name = 'kodi_log_{0}.zip'.format(timestamp)
    zip_path = os.path.join(dest_folder_real, zip_name)

    try:
        # kodi.log über eine temporäre lokale Kopie einlesen, da xbmcvfs-Pfade
        # (z.B. special://) nicht direkt von zipfile gelesen werden können
        tmp_log = xbmcvfs.translatePath('special://temp/kodi_log_tmp.log')
        xbmcvfs.copy(log_path, tmp_log)

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            zf.write(tmp_log, arcname='kodi.log')

        xbmcvfs.delete(tmp_log)

        dialog.notification(ADDON_NAME, 'Log als ZIP gespeichert: ' + zip_name, xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception as e:
        dialog.notification(ADDON_NAME, 'Fehler beim Erstellen der ZIP', xbmcgui.NOTIFICATION_ERROR, 4000)
