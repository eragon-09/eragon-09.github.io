import re, json
from bs4 import BeautifulSoup
from ..models import *
from ..util import find_iframes, m3u8_src
from ..util.jsunpack import detect, unpack
from ..icons import icons
from .._core import fetch_page, get_session

class IStreamEast(JetExtractor):
    def __init__(self) -> None:
        self.domains = ["streameast.cool","gooz.aapmains.net","thestreameast.top"]
        self.name = "IStreamEast"
        self.short_name = "SE"

    def get_items(self, params: Optional[dict] = None, progress: Optional[JetExtractorProgress] = None) -> List[JetItem]:
        items = []
        if self.progress_init(progress, items):
            return items
        
        base_url = f"https://{self.domains[0]}"
        
        try:
            r = fetch_page(base_url)
            soup = BeautifulSoup(r, "html.parser")
        except Exception:
            return items
        
        event_items = soup.find_all("li", class_="f1-podium--item")
        
        for item in event_items:
            link_tag = item.find("a", class_="f1-podium--link")
            if not link_tag:
                continue
            
            href = link_tag.get("href", "")
            if not href:
                continue
            
            if href.startswith("/"):
                href = base_url + href
            
            rank_tag = item.find("span", class_="f1-podium--rank")
            league = rank_tag.text.strip() if rank_tag else ""
            
            title_tag = item.find("span", class_="f1-podium--driver")
            title = title_tag.text.strip() if title_tag else ""
            
            time_tag = item.find("span", class_="f1-podium--time")
            status = ""
            if time_tag:
                live_tag = time_tag.find("span", style=lambda x: x and "color: #930f0d" in x if x else False)
                if live_tag:
                    status = "LIVE"
                else:
                    time_text = time_tag.text.strip()
                    if time_text:
                        status = time_text
            
            full_title = f"[{status}] {title}" if status else title
            
            if full_title and href:
                links = self.get_links(href)
                
                if links:
                    jet_links = links
                else:
                    jet_links = [JetLink(href)]
                
                items.append(JetItem(
                    icon=icons[league.lower()] if league.lower() in icons else None,
                    league=league.upper(),
                    title=full_title,
                    links=jet_links
                ))
        
        return items
    
    def get_links(self, event_url) -> List[JetLink]:
        if isinstance(event_url, JetLink):
            event_url = event_url.address
        links = []
        try:
            r = fetch_page(event_url)
            
            stream_buttons = re.findall(r'<div[^>]+id="stream-btn-(\d+)"[^>]+onclick="window\.changeStream\((\d+)\)"[^>]*>\s*([^<]+)', r)
            
            if stream_buttons:
                for stream_id, _, channel_name in stream_buttons:
                    channel_name = channel_name.strip()
                    stream_url = f"https://gooz.aapmains.net/new-stream-embed/{stream_id}"
                    links.append(JetLink(stream_url, name=channel_name))
            else:
                iframe_match = re.search(r'<iframe[^>]+id="wp_player"[^>]+src="([^"]+)"', r, re.IGNORECASE)
                if not iframe_match:
                    iframe_match = re.search(r"document\.getElementById\('wp_player'\)\.src\s*=\s*'([^']+)'", r)
                
                if iframe_match:
                    iframe_url = iframe_match.group(1)
                    if not iframe_url.startswith("http"):
                        iframe_url = "https://" + iframe_url.lstrip("/")
                    links.append(JetLink(iframe_url))
                    
        except Exception:
            pass
        
        return links

    def get_link(self, url: JetLink) -> JetLink:
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        base_headers = {
            "User-Agent": user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }
        
        original_url = url.address
        
        if "gooz.aapmains.net" in original_url or "new-stream-embed" in original_url:
            stream_headers = base_headers.copy()
            stream_headers["Referer"] = f"https://{self.domains[1]}/"
            try:
                # Fetch the page to find the iframe src with query
                r = get_session().get(original_url, timeout=self.timeout, headers=stream_headers)
                iframe_match = re.search(r'<iframe[^>]+id="wp_player"[^>]+src="([^"]+)"', r.text, re.IGNORECASE)
                if iframe_match:
                    iframe_url = iframe_match.group(1)
                    if not iframe_url.startswith("http"):
                        iframe_url = "https://" + iframe_url.lstrip("/")
                    # Fetch the iframe page and find iframes or m3u8
                    resolved_list = find_iframes.find_iframes(iframe_url, "", [], [], stream_headers)
                    if resolved_list:
                        first = resolved_list[0]
                        if isinstance(first, str):
                            resolved = JetLink(first, headers=stream_headers, inputstream=JetInputstreamFFmpegDirect.default())
                        else:
                            resolved = first
                else:
                    # Fallback to scan for Clappr source in the iframe page
                    clappr_match = re.search(r'const\s+source\s+=\s+"([^"]*)"', r.text, re.IGNORECASE)
                    if clappr_match:
                        m3u8_url = clappr_match.group(1)
                        resolved = JetLink(m3u8_url, headers=stream_headers, inputstream=JetInputstreamFFmpegDirect.default())
                if resolved:
                    return resolved
            except Exception:
                pass
            return url
        
        stream_headers = base_headers.copy()
        stream_headers["Referer"] = f"https://{self.domains[1]}/"
        
        try:
            r = get_session().get(original_url, timeout=self.timeout, headers=base_headers)
            
            iframe_match = re.search(r'<iframe[^>]+id="wp_player"[^>]+src="([^"]+)"', r.text, re.IGNORECASE)
            if not iframe_match:
                iframe_match = re.search(r"document\.getElementById\('wp_player'\)\.src\s*=\s*'([^']+)'", r.text)
            
            if iframe_match:
                iframe_url = iframe_match.group(1)
                if not iframe_url.startswith("http"):
                    iframe_url = "https://" + iframe_url.lstrip("/")
                
                resolved = find_iframes.find_iframes(iframe_url, "", [], [], stream_headers)
                if resolved:
                    first = resolved[0]
                    if isinstance(first, str):
                        return JetLink(first, headers=stream_headers, inputstream=JetInputstreamFFmpegDirect.default())
                    return first
            
            m3u8_link = m3u8_src.scan_page(original_url, html=r.text)
            if m3u8_link:
                return m3u8_link
                
        except Exception:
            pass
        
        return url
