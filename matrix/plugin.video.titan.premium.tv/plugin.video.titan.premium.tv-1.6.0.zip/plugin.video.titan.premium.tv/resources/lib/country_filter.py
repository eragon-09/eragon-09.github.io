# -*- coding: utf-8 -*-
import re

try:
    import xbmcaddon
    _ADDON = xbmcaddon.Addon('plugin.video.titan.premium.tv')
except Exception:
    _ADDON = None

# Standard-Ländergruppen für Top Stream Deluxe
_DEFAULT_COUNTRIES = {"DE", "AT", "CH"}


def _parse_country_codes(raw_value):
    """
    Text-Eingabe aus den Addon-Settings in ein Set von Ländercodes umwandeln.
    Erlaubt z.B.:
      "DE,AT,CH,NL"
      "de; at ; ch"
      "Deutschland, Österreich, Schweiz" -> nimmt die ersten 2–3 Buchstaben
    """
    if not raw_value:
        return set(_DEFAULT_COUNTRIES)

    codes = set()
    # Kommas / Semikolons gleich behandeln
    for part in re.split(r"[;,]", raw_value):
        part = part.strip().upper()
        if not part:
            continue

        # Wenn der Benutzer z.B. "Deutschland" schreibt, die ersten 2–3 Buchstaben nutzen
        if len(part) > 3:
            # Versuche zuerst 2-stelligen Code, ansonsten 3-stellig
            candidate2 = part[:2]
            candidate3 = part[:3]
            if candidate2.isalpha():
                part = candidate2
            elif candidate3.isalpha():
                part = candidate3
            else:
                # Fallback: trotzdem die ersten 2 Zeichen nehmen
                part = part[:2]

        codes.add(part)

    # Fallback auf Standard, falls alles weggefiltert wurde
    if not codes:
        codes = set(_DEFAULT_COUNTRIES)

    return codes


def _get_setting_bool(addon, setting_id, default=False):
    """
    Hilfsfunktion um bool-Werte auch auf älteren Kodi-Versionen sauber zu lesen.
    """
    if addon is None:
        return default

    # Neuere Kodi-Versionen
    if hasattr(addon, "getSettingBool"):
        try:
            return addon.getSettingBool(setting_id)
        except Exception:
            pass

    # Fallback: String "true"/"false"
    try:
        value = addon.getSetting(setting_id)
    except Exception:
        return default
    return str(value).lower() == "true"


def get_country_groups_config():
    """
    Liefert eine 3er-Tuple (enabled, codes, allow_unknown).

      enabled       : True/False – Ländergruppen-Filter aktiv?
      codes         : Set von Ländercodes, z.B. {"DE","AT","CH","NL"}
      allow_unknown : True/False – Gruppen ohne Länderpräfix (also z.B. "SPORT")
                       trotzdem anzeigen?

    Standard:
      enabled       = True
      codes         = {"DE","AT","CH"}
      allow_unknown = False
    kann aber über die Addon-Settings überschrieben werden.
    """
    # Wenn Addon nicht verfügbar ist (z.B. beim Testen), statische Defaults
    if _ADDON is None:
        enabled = True
        codes = set(_DEFAULT_COUNTRIES)
        allow_unknown = False
        return enabled, codes, allow_unknown

    # 1) Filter aktivieren/deaktivieren
    enabled = _get_setting_bool(_ADDON, "country_filter_enabled", default=True)

    # 2) Liste der Länder-Codes
    try:
        raw_codes = _ADDON.getSetting("country_filter_codes")
    except Exception:
        raw_codes = ""
    codes = _parse_country_codes(raw_codes)

    # 3) Unbekannte Gruppen (ohne Ländercode im Namen) anzeigen?
    allow_unknown = _get_setting_bool(
        _ADDON,
        "country_filter_allow_unknown",
        default=False
    )

    return enabled, codes, allow_unknown
