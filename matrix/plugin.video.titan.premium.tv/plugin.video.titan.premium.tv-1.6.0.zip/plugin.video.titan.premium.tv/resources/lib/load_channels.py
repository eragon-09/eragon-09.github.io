#!/usr/bin/python
#
# -*- coding: utf-8 -*-

import os, sys, xbmc, xbmcvfs, xbmcaddon, xbmcgui, xbmcplugin, re
import urllib.request, urllib.parse, urllib.error
import uuid
import json
import hashlib
import math
import requests
from time import time
from datetime import datetime
from xml.dom import minidom

key = None;
mac = ':'.join(re.findall('..', '%012x' % uuid.getnode()));
sn = None;
device_id = None;
device_id2 = None;
signature = None;
stlink = None;
cache_version = '4'

# -------------------------------------------------------------------
# Turbo 1: EPG cache in RAM (avoid re-opening/parsing JSON per channel)
# -------------------------------------------------------------------
# Key: epg_path -> {"mtime": float, "data": dict}
_EPG_MEM = {}

def clearCache(url, path):
    """Löscht alle Cache-Dateien für dieses Portal (außer .xml Dateien)."""
    try:
        if os.path.exists(path):
            for f in os.listdir(path):
                if not f.endswith('.xml'):
                    try:
                        os.remove(os.path.join(path, f))
                    except Exception:
                        pass
        # RAM-Cache auch leeren
        _EPG_MEM.clear()
        _CACHE_MEM.clear()
        _GENRE_CHANNEL_CACHE.clear()
    except Exception:
        pass


def _epg_cache_path(portal_mac, path):
    mac_key = "_".join(re.findall(r"[A-Za-z0-9]+", portal_mac or ""))
    return os.path.join(path, f"{mac_key}-epg")

def _load_epg_cache_from_disk(epg_path):
    """Load EPG json dict from disk with mtime-based in-memory cache."""
    try:
        mtime = os.path.getmtime(epg_path)
    except Exception:
        return {}

    cached = _EPG_MEM.get(epg_path)
    if cached and cached.get("mtime") == mtime and isinstance(cached.get("data"), dict):
        return cached["data"]

    try:
        with open(epg_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if not isinstance(data, dict):
                data = {}
    except Exception:
        data = {}

    _EPG_MEM[epg_path] = {"mtime": mtime, "data": data}
    return data
dialog = xbmcgui.Dialog()
addon       = xbmcaddon.Addon('plugin.video.titan.premium.tv')
addonname   = addon.getAddonInfo('name')
addondir    = xbmcvfs.translatePath( addon.getAddonInfo('profile') ) 



# -------------------------
# Lightweight TTL cache for portal list responses (genres/channels/vod/series)
# Stored under addon profile folder to avoid repeated portal requests.
# We do NOT cache stream-link actions (create_link/get_stream).
# -------------------------
_CACHE_MEM = {}

def _cache_dir(base_path):
    try:
        p = os.path.join(base_path, "httpcache")
        if not os.path.exists(p):
            os.makedirs(p, exist_ok=True)
        return p
    except Exception:
        return base_path

def _cache_key(portal_mac, fn_name, values, extra=""):
    mac_key = "_".join(re.findall(r"[A-Za-z0-9]+", portal_mac or ""))
    try:
        payload = json.dumps(values or {}, sort_keys=True, separators=(",", ":"))
    except Exception:
        payload = str(values)
    raw = (fn_name + "|" + payload + "|" + str(extra)).encode("utf-8", "ignore")
    digest = hashlib.md5(raw).hexdigest()
    return f"{mac_key}-{fn_name}-{digest}.json"

def _cache_get(path, key, ttl_seconds):
    if not ttl_seconds or ttl_seconds <= 0:
        return None
    cache_path = os.path.join(_cache_dir(path), key)

    # in-memory fast path
    now = time.time()
    mem = _CACHE_MEM.get(cache_path)
    if mem and (now - mem.get("ts", 0) <= ttl_seconds):
        return mem.get("data")

    try:
        mtime = os.path.getmtime(cache_path)
        if now - mtime > ttl_seconds:
            return None
        with open(cache_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        _CACHE_MEM[cache_path] = {"ts": now, "data": data}
        return data
    except Exception:
        return None

def _cache_set(path, key, data):
    try:
        cache_path = os.path.join(_cache_dir(path), key)
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        _CACHE_MEM[cache_path] = {"ts": time.time(), "data": data}
    except Exception:
        pass

def _get_cache_settings():
    try:
        import xbmcaddon
        a = xbmcaddon.Addon('plugin.video.titan.premium.tv')
        enabled = (a.getSetting('cache_enabled') or 'true').lower() == 'true'
        ttl = int(a.getSetting('cache_ttl_lists') or '300')
        return enabled, max(0, ttl)
    except Exception:
        return True, 300

def _retrieveData_cached(url, values, portal_mac, addondir_path, fn_name, ttl_override=None):
    enabled, ttl_default = _get_cache_settings()
    ttl = ttl_default if ttl_override is None else int(ttl_override)
    if not enabled:
        return retrieveData(url, values)

    key = _cache_key(portal_mac, fn_name, values)
    cached = _cache_get(addondir_path, key, ttl)
    if cached is not None:
        return cached

    data = retrieveData(url, values)
    # Only cache json/dict responses
    if isinstance(data, (dict, list)):
        _cache_set(addondir_path, key, data)
    return data

def is_json(myjson):
  try:
    json_object = json.loads(myjson)
  except ValueError as e:
    return False
  return True

def setMac(nmac):
    global mac, key

    if re.match("[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$", nmac.lower()):
        if mac != nmac:
            # Anderes Portal → Token zurücksetzen damit neuer Handshake gemacht wird
            key = None
        mac = nmac


def getMac():
    global mac
    return mac


def setSerialNumber(serial):
    global sn, device_id, device_id2, signature

    if serial == None:
        return

    elif serial['custom'] == False:
        sn = hashlib.md5(mac).hexdigest().upper()[13:]
        device_id = hashlib.sha256(sn).hexdigest().upper()
        device_id2 = hashlib.sha256(mac).hexdigest().upper()
        signature = hashlib.sha256(sn + mac).hexdigest().upper()

    elif serial['custom'] == True:
        sn = serial['sn']
        device_id = serial['device_id']
        device_id2 = serial['device_id2']
        signature = serial['signature']


def handshake(url):
    global key

    if key != None:
        return

    info = retrieveData(url, values = {
        'type' : 'stb', 
        'action' : 'handshake',
        'JsHttpRequest' : '1-xml'})

    if not info or 'js' not in info:
        raise Exception('Handshake fehlgeschlagen: keine Antwort vom Server')

    js = info['js']

    # Error 512 = MAC nicht authorisiert / zu viele Sessions
    if isinstance(js, dict) and js.get('error_code') in (512, '512'):
        raise Exception('Portal-Fehler 512: MAC nicht authorisiert oder zu viele aktive Sessions.\nBitte MAC im Portal prüfen oder kurz warten.')

    if not isinstance(js, dict) or 'token' not in js:
        raise Exception('Handshake fehlgeschlagen: kein Token erhalten (Antwort: {})'.format(str(js)[:100]))

    key = js['token']

    getProfile(url)


def getProfile(url):
    global sn, device_id, device_id2, signature

    values = {
        'type' : 'stb', 
        'action' : 'get_profile',
        'hd' : '1',
        'ver' : 'ImageDescription:%200.2.18-r11-pub-254;%20ImageDate:%20Wed%20Mar%2018%2018:09:40%20EET%202015;%20PORTAL%20version:%204.9.14;%20API%20Version:%20JS%20API%20version:%20331;%20STB%20API%20version:%20141;%20Player%20Engine%20version:%200x572',
        'num_banks' : '1',
        'stb_type' : 'MAG254',
        'image_version' : '218',
        'auth_second_step' : '0',
        'hw_version' : '2.6-IB-00',
        'not_valid_token' : '0',
        'JsHttpRequest' : '1-xml'}

    if sn != None:
        values['sn'] = sn
        values['device_id'] = device_id
        values['device_id2'] = device_id2
        values['signature'] = signature

    info = retrieveData(url, values)



def retrieveData(url, values ):
    """Perform a Stalker/MAG request.

    Supports selectable header/profile behaviour to match other addons/portals.
    """
    global key, mac

    import xbmcaddon
    import urllib.error

    addon = xbmcaddon.Addon()

    # ArrowTV-like defaults (as in plugin.video.arrowtv)
    arrow_load = '/portal.php'
    arrow_refer = '/c/'
    arrow_timezone = 'Europe%2FAmsterdam'
    arrow_user_agent = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) App...like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3'
    arrow_xua = 'Model: MAG254; Link: Ethernet'

    def _headers(refer, timezone, user_agent, xua):
        if key != None:
            return {
                'User-Agent' : user_agent,
                'Cookie' : 'mac=' + mac + '; stb_lang=en; timezone=' + timezone,
                'Referer' : url + refer,
                'Accept' : '*/*',
                'Connection' : 'Keep-Alive',
                'X-User-Agent' : xua,
                'Authorization' : 'Bearer ' + key
            }
        return {
            'User-Agent' : user_agent,
            'Cookie' : 'mac=' + mac + '; stb_lang=en; timezone=' + timezone,
            'Referer' : url + refer,
            'Accept' : '*/*',
            'Connection' : 'Keep-Alive',
            'X-User-Agent' : xua
        }

    data = urllib.parse.urlencode(values).encode('utf-8')

    # ArrowTV exact profile
    timezone = addon.getSetting('timezone_override') or arrow_timezone
    user_agent = addon.getSetting('user_agent_override') or arrow_user_agent
    xua = addon.getSetting('x_user_agent_override') or arrow_xua
    headers = _headers(arrow_refer, timezone, user_agent, xua)

    req = urllib.request.Request(url + arrow_load, data, headers)
    resp = urllib.request.urlopen(req).read().decode('utf-8')

    if not is_json(resp):
        req = urllib.request.Request(url + arrow_load + '?' + urllib.parse.urlencode(values), headers=headers)
        resp = urllib.request.urlopen(req).read().decode('utf-8')

    if not is_json(resp):
        raise Exception(resp)

    result = json.loads(resp)

    # Error 512 = MAC nicht authorisiert / zu viele Sessions
    if isinstance(result, dict):
        err = result.get('js', {})
        if isinstance(err, dict) and err.get('error_code') in (512, '512'):
            raise Exception('Portal-Fehler 512: MAC nicht authorisiert oder zu viele aktive Sessions')

    return result


def getGenres(portal_mac, url, serial, path):    
    global key, cache_version

    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-genres'

    setMac(portal_mac)
    setSerialNumber(serial)

    if not os.path.exists(path): 
        os.makedirs(path)

    if os.path.exists(portalurl):
        #check last time
        with open(portalurl, 'rb') as data_file: data = json.load(data_file);
        
        if 'version' not in data or data['version'] != cache_version:
            clearCache(url, path)

        else:
            time_init = float(data['time'])
            # update 12h
            if ((now - time_init) / 3600) < 12:
                return data

    handshake(url)

    info = retrieveData(url, values = {
        'type' : 'itv', 
        'action' : 'get_genres',
        'JsHttpRequest' : '1-xml'})

    if not info or 'js' not in info or not info['js']:
        raise Exception('Server-Fehler beim Laden der Genres (möglicherweise ungültige MAC oder Portal-URL)')
        
    results = info['js']
    
    data = '{ "version" : "' + cache_version + '", "time" : "' + str(now) + '", "genres" : {  \n'

    for i in results:
        alias     = i["alias"]
        id         = i["id"]
        title     = i['title']
        
        data += '"'+ id +'" : {"alias":"'+ alias +'", "title":"'+ title +'"}, \n'

    
    data = data[:-3] + '\n}}'

    with open(portalurl, 'wb') as f: f.write(data.encode('utf-8'));
    
    return json.loads(data.encode('utf-8'))


def getAllChannels(portal_mac, url, serial, path):
    global key

    added = False

    now = time()

    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + 'channels'
    
    setMac(portal_mac)
    setSerialNumber(serial)

    if not os.path.exists(path):
        os.makedirs(path)

    if os.path.exists(portalurl):

        #check last time
        with open(portalurl, 'rb') as data_file: data = json.load(data_file);
    
        if 'version' not in data or data['version'] != cache_version:
            clearCache(url, path)

        else:
            time_init = float(data['time'])
            # update 12h
            if ((now - time_init) / 3600) < 12:
                return data

    handshake(url)
    
    epg = getEPG(portal_mac, url, serial, path)
    genres = getGenres(portal_mac, url, serial, path)
    genres = genres["genres"]

    channels = []
    
    info = retrieveData(url, values = {
        'type' : 'itv', 
        'action' : 'get_all_channels',
        'JsHttpRequest' : '1-xml'})

    for result in info['js']['data']:
        channels.append({
            "id": result['id'],
            "number": result["number"],
            "name": result["name"],
            "cmd": result['cmd'],
            "logo": result["logo"],
            "tmp": result["use_http_tmp_link"],
            "genre_id": result['tv_genre_id'],
            "epg_id": result['xmltv_id']
            })

    data = {
        "version" : cache_version,
        "time" : now,
        'channels' : channels,
    }
    with open(portalurl, 'w') as f:
        json.dump(data, f, indent=4)
    
    return data

# RAM-Cache für getChannelsByGenre: {(mac, genre_id): (timestamp, channels)}
_GENRE_CHANNEL_CACHE = {}
_GENRE_CHANNEL_TTL = 12 * 3600  # 12 Stunden


def getChannelsByGenre(portal_mac, url, serial, genre_id, page=1):
    """Lädt Kanäle einer bestimmten Genre-ID via get_ordered_list.
    Wie titanmacvodedition: type=itv, action=get_ordered_list, genre=genre_id
    Mit 12h RAM-Cache für schnelles Zurückkehren nach Wiedergabe."""
    global _GENRE_CHANNEL_CACHE

    cache_key = (str(portal_mac), str(genre_id))
    now = time()

    # Cache prüfen
    if cache_key in _GENRE_CHANNEL_CACHE:
        ts, cached_channels = _GENRE_CHANNEL_CACHE[cache_key]
        if now - ts < _GENRE_CHANNEL_TTL:
            return cached_channels

    setMac(portal_mac)
    handshake(url)

    channels = []
    p = int(page)
    max_pages = 50

    while p <= max_pages:
        info = retrieveData(url, values={
            'type': 'itv',
            'action': 'get_ordered_list',
            'genre': str(genre_id),
            'sortby': 'number',
            'fav': '0',
            'p': str(p),
            'JsHttpRequest': '1-xml'
        })

        if not info or 'js' not in info:
            break

        js = info['js']
        data = js.get('data', []) if isinstance(js, dict) else []

        if not data:
            break

        for result in data:
            try:
                channels.append({
                    'id':       str(result.get('id', '')),
                    'number':   result.get('number', 0),
                    'name':     result.get('name', ''),
                    'cmd':      result.get('cmd', ''),
                    'logo':     result.get('logo', ''),
                    'tmp':      str(result.get('use_http_tmp_link', '0')),
                    'genre_id': str(result.get('tv_genre_id', genre_id)),
                    'epg_id':   result.get('xmltv_id', ''),
                })
            except Exception:
                continue

        # Paginierung prüfen
        total = js.get('total_items', 0) if isinstance(js, dict) else 0
        max_items = js.get('max_page_items', len(data)) if isinstance(js, dict) else len(data)
        if max_items and total and p * int(max_items) >= int(total):
            break
        if len(data) == 0:
            break
        p += 1

    # Im RAM-Cache speichern
    _GENRE_CHANNEL_CACHE[cache_key] = (now, channels)

    return channels


def getVoDgenres(portal_mac, url, serial, path):    
    global key, cache_version

    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-vodgenres'

    setMac(portal_mac)
    setSerialNumber(serial)

    if not os.path.exists(path):
        os.makedirs(path)

    if os.path.exists(portalurl):
        #check last time
        with open(portalurl, 'rb') as data_file: data = json.load(data_file);
        
        if 'version' not in data or data['version'] != cache_version:
            clearCache(url, path)

        else:
            time_init = float(data['time'])
            # update 12h
            if ((now - time_init) / 3600) < 12:
                return data

    handshake(url)

    info = retrieveData(url, values = {
        'type' : 'vod', 
        'action' : 'get_categories',
        'JsHttpRequest' : '1-xml'})
        
    
    results = info['js']
    
    data = '{ "version" : "' + cache_version + '", "time" : "' + str(now) + '", "vodgenres" : {  \n'

    for i in results:
        alias     = i["alias"]
        id         = i["id"]
        title     = i['title']
        cat     = i['id']
        
        data += '"'+ id +'" : {"alias":"'+ alias +'", "title":"'+ title +'", "cat":"'+ cat +'"}, \n'

    
    data = data[:-3] + '\n}}'

    with open(portalurl, 'wb') as f: f.write(data.encode('utf-8'));
    
    return json.loads(data.encode('utf-8'))


def getVoD(portal_mac, url, serial, path):#
    global key
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    cat     = args['cat'][0]
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-vod'+cat

    setMac(portal_mac)
    #setSerialNumber(serial);
    
    if not os.path.exists(path):
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        #check last time
        with open(portalurl, 'rb') as data_file: data = json.load(data_file);
    
        if 'version' not in data or data['version'] != cache_version:
            clearCache(url, path)

        else:
            time_init = float(data['time'])
            # update 12h
            if ((now - time_init) / 3600) < 12:
                return data

    handshake(url)

    data = '{ "version" : "' + cache_version + '", "time" : "' + str(now) + '", "vod'+cat+'" : [  \n'
    
    page = 1
    pages = 300
    total_items = 1.0
    max_page_items = 1.0

    while True:
        info = retrieveData(url, values = {
            'type' : 'vod', 
            'action' : 'get_ordered_list',
            'category' : cat,
            'sortby' : 'added',
            'not_ended' : '0',
            'p' : page,
            'fav' : '0',
            'JsHttpRequest' : '1-xml'})
        
        total_items = float(info['js']['total_items'])
        max_page_items = float(info['js']['max_page_items'])
        pages = math.ceil(total_items/max_page_items)

        results = info['js']['data']


        for i in results:
            name     = i["name"]
            cmd     = i['cmd']
            logo     = i["screenshot_uri"]
            plot    = i["description"]
            plot    = plot.replace('"',"-")
            plot    = plot.replace("\r","")
            plot    = plot.replace("\n", " ")
            plot    = plot.replace("  "," ")
            genre    = i['genres_str']
            #cast     = i['actors']
            year     = i["year"]
            #imdb     = i['rating_imdb']

            data += '{'
            data += '"name":"' + name + '", '
            data += '"cmd":"' + cmd + '", '
            data += '"logo":"' + logo + '", '           
            data += '"plot":"' + plot + '", '
            data += '"genre":"' + genre + '", '
            #data += '"cast":"' + cast + '", '
            #data += '"imdb":"' + imdb + '", '           
            data += '"year":"' + year + '"}, \n'
            

        page += 1
        if page > pages or page == 300:
            break

    data = data[:-3] + '\n]}'

    with open(portalurl, 'wb') as f: f.write(data.encode('utf-8'));
    
    return json.loads(data.encode('utf-8'), strict=False)


def getSergenres(portal_mac, url, serial, path):
    global key, cache_version

    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-sergenres'

    setMac(portal_mac)
    setSerialNumber(serial)

    if not os.path.exists(path):
        os.makedirs(path)

    if os.path.exists(portalurl):
        #check last time
        with open(portalurl, 'rb') as data_file: data = json.load(data_file);
        
        if 'version' not in data or data['version'] != cache_version:
            clearCache(url, path)

        else:
            time_init = float(data['time'])
            # update 12h
            if ((now - time_init) / 3600) < 12:
                return data

    handshake(url)

    info = retrieveData(url, values = {
        'type' : 'series', 
        'action' : 'get_categories',
        'JsHttpRequest' : '1-xml'})
        
    
    results = info['js']
    
    data = '{ "version" : "' + cache_version + '", "time" : "' + str(now) + '", "sergenres" : {  \n'

    for i in results:
        alias     = i["alias"]
        id         = i["id"]
        title     = i['title']
        cat     = i['id']
        
        data += '"'+ id +'" : {"alias":"'+ alias +'", "title":"'+ title +'", "cat":"'+ cat +'"}, \n'

    
    data = data[:-3] + '\n}}'

    with open(portalurl, 'wb') as f: f.write(data.encode('utf-8'));
    
    return json.loads(data.encode('utf-8'))


def getSeries(portal_mac, url, serial, path):
    global key
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    cat     = args['cat'][0]
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-ser'+cat

    setMac(portal_mac)
    #setSerialNumber(serial);
    
    if not os.path.exists(path):
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        #check last time
        with open(portalurl, 'rb') as data_file: data = json.load(data_file);
    
        if 'version' not in data or data['version'] != cache_version:
            clearCache(url, path)

        else:
            time_init = float(data['time'])
            # update 12h
            if ((now - time_init) / 3600) < 12:
                return data

    handshake(url)
    
    series = []
    for page in range(1, 300):
        info = retrieveData(url, values = {
            'type' : 'series', 
            'action' : 'get_ordered_list',
            'category' : cat,
            'sortby' : 'added',
            'not_ended' : '0',
            'p' : page,
            'fav' : '0',
            'JsHttpRequest' : '1-xml'})
        
        total_items = info['js']['total_items']
        
        for result in info['js']['data']:
            plot = result["description"]
            plot = plot.replace('"',"-").replace("\r","").replace("\n", " ").replace("  "," ")
            series.append({
                "category": result['category_id'],
                "cat": result["id"],
                "name": result["name"],
                "cmd": result['cmd'],
                "logo": result["screenshot_uri"],
                "plot": plot,
                "genre": result['genres_str'],
                "year": result["year"]
            })
        if len(series) >= total_items:
            break

    data = {
        "version" : cache_version,
        "time" : now,
        'ser'+cat: series,
    }
    with open(portalurl, 'w') as f:
        json.dump(data, f, indent=4)
        
    
    return data


def get_seasons(portal_mac, url, serial, path):
    global key
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    cat = args['cat'][0]
    category = args['category'][0]
    
    now = time()

    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = os.path.join(path, portalurl + '-seasons'+cat)


    
    setMac(portal_mac)
    #setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        #check last time
        with open(portalurl, 'rb') as data_file:
            data = json.load(data_file)
    
        if 'version' not in data or data['version'] != cache_version:
            clearCache(url, path)
            
        else:
            time_init = float(data['time'])
            # update 12h
            if ((now - time_init) / 3600) < 12:
                return data
    
    handshake(url)
    
    seasons = []
    for page in range(1, 300):
        info = retrieveData(url, values = {
            'type' : 'series', 
            'action' : 'get_ordered_list',
            'category' : category,
            'movie_id' : cat,
            'sortby' : 'added',
            'season_id' : '0',
            'episod_id' : '0',
            'p' : page,
            'JsHttpRequest' : '1-xml'})
            
        total_items = info['js']['total_items']

        for result in info['js']['data']:
            plot = result["description"]
            plot = plot.replace('"',"-").replace("\r","").replace("\n", " ").replace("  "," ")
            seasons.append({
                "name":  result['name'],
                "category": result['category_id'],
                "cat": result["id"],
                "cmd": result['cmd'],
                "logo": result["screenshot_uri"],
                "plot": plot,
                "genre": result['genres_str'],
                "year": result["year"],
                "series": result["series"],
                })
        if len(seasons) >= total_items:
            break

    data = {
        "version" : cache_version,
        "time" : now,
        'seasons'+cat: seasons,
        }
    with open(portalurl, 'w') as f:
        json.dump(data, f, indent=4, sort_keys=False)
   
    return data

def get_episodes(portal_mac, url, serial, path):
    global key
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    cat = args['cat'][0]
    plot = args.get('plot','')
    category = args['category'][0]
    now = time()

    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = os.path.join(path, portalurl + '-episodes')

    setMac(portal_mac)
    #setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)

    handshake(url)
    
    episodes = []
    for page in range(1, 5):
        info = retrieveData(url, values = {
            'type' : 'series', 
            'action' : 'get_ordered_list',
            'category' : category,
            'movie_id' : cat,
            'plot' : plot,
            'sortby' : 'added',
            'season_id' : '0',
            'episod_id' : '0',
            'p' : page,
            'JsHttpRequest' : '1-xml'})
            
        total_items = info['js']['total_items']
        
        dicts = info['js']['data']
        
        epi = next((index for (index, d) in enumerate(dicts) if d["id"] == cat), None)
        
        for item in info['js']['data'][epi]['series']:
            for result in info['js']['data']:
                episodes.append({
                    "episode": str(item),
                    "name":  result['name'],
                    "category": result['category_id'],
                    "cat": result["id"],
                    "cmd": result['cmd'],
                    'plot' : result['description'],
                    "logo": result["screenshot_uri"],
                    "genre": result['genres_str'],
                    "year": result["year"],
                    "series": result["series"],
                    })
        if len(episodes) >= total_items:
            break

    data = {
        "version" : cache_version,
        "time" : now,
        'episodes': episodes,
        }
    with open(portalurl, 'w') as f:
        json.dump(data, f, indent=4, sort_keys=False)
   
    return data

def get_info(portal_mac, url, serial, path):
    
    now = time()

    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-xtream'

    try:
        data = getAllChannels(portal_mac, url, serial, path)
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR )

    data = data['channels'][0]['cmd']
    if str(data).startswith('ffmpeg http://localhost') is True:
        global key
        setMac(portal_mac)
        setSerialNumber(serial)

        handshake(url)

        info = retrieveData(url, values = {
           'type' : 'itv', 
                   'action' : 'create_link',
                   'cmd' : data,
                   'JsHttpRequest' : '1-xml'})

        results = info['js']['cmd']
        results = results.replace("ffmpeg ","" )
        path = urlparse(results).path
        scheme = urlparse(results).scheme
        netloc = urlparse(results).netloc
        path = path.replace("/",'player_api.php?username=',1)
        path = path.replace("/",'&password=',1)
        path = path.replace("/",'\r'+'/',1)
        with open(portalurl, 'w') as fw :fw.write(scheme+'://'+netloc+'/'+path)
        with open(portalurl,"r") as fr:
            PlayerAPI = fr.readlines()
            fr.close()
        PlayerAPI.pop(1)
        with open(portalurl, 'w') as fw :
            PlayerAPI = "".join(PlayerAPI)
            PlayerAPI.replace("\n\r","")
            fw.write(PlayerAPI)
            fw.close()
        return PlayerAPI

    else:
        data = data.replace("ffmpeg ","")
        path = urlparse(data).path
        path = path.replace("/",'player_api.php?username=',1)
        path = path.replace("/",'&password=',1)
        path = path.replace("/",'\r'+'/',1)
        path = path.replace("player",url+'/player',1)
        with open(portalurl, 'w') as fw :fw.write(path)
        with open(portalurl,"r") as fr:
            PlayerAPI = fr.readlines()
            fr.close()
        PlayerAPI.pop(1)
        with open(portalurl, 'w') as fw :
            PlayerAPI = "".join(PlayerAPI)
            PlayerAPI.replace("\n\r","")
            fw.write(PlayerAPI)
            fw.close()
        return PlayerAPI


def retriveUrl(portal_mac, url, serial, channel, tmp):
    
    setMac(portal_mac)
    setSerialNumber(serial)

    if 'matrix' in channel:
        return retrieve_matrixUrl(url, channel)

    else:
        return retrive_defaultUrl(url, channel, tmp)


def retrive_defaultUrl(url, channel, tmp):

    if tmp == '0':
        s = channel.split(' ')
        url = s[0]
        if len(s)>1:
            url = s[1]
        return url

    handshake(url)

    cmd = channel

    info = retrieveData(url, values = {
        'type' : 'itv', 
        'action' : 'create_link', 
        'cmd' : channel,
        'forced_storage' : 'undefined',
        'disable_ad' : '0',
        'JsHttpRequest' : '1-xml'})
    cmd = info['js']['cmd']

    s = cmd.split(' ')

    url = s[0]

    if len(s)>1:
        url = s[1]

    # RETRIEVE THE 1 EXTM3U
    request = urllib.request.Request(url)
    request.get_method = lambda : 'HEAD'
    response  = urllib.request.urlopen(request)
    data = response.read()

    data = data.splitlines()
    data = data[len(data) - 1]

    # RETRIEVE THE 2 EXTM3U
    url = response.geturl().split('?')[0]
    url_base = url[: -(len(url) - url.rfind('/'))]
    return url_base + '/' + data

    return url


def retrieve_matrixUrl(url, channel):

    channel = channel.split('/')
    channel = channel[len(channel) -1]

    url += '/server/api/matrix.php?channel=' + channel + '&mac=' + mac

    # RETRIEVE THE 1 EXTM3U
    request = urllib.request.Request(url)
    response  = urllib.request.urlopen(request)
    data = response.read()

    _s1 = data.split(' ')
    data = _s1[0]
    if len(_s1)>1:
        data = _s1[len(_s1) -1]

    return data


def retriveVoD(portal_mac, url, serial, video):
    
    setMac(portal_mac)
    setSerialNumber(serial)

    s = video.split(' ')
    url = s[0]
    if len(s)>1:
        url = s[1]

    url = url.replace('TOMTOM:', 'http://')

    # RETRIEVE THE 1 EXTM3U
    request = urllib.request.Request(url)
    response  = urllib.request.urlopen(request)
    url = response.geturl()

    # RETRIEVE THE 1 EXTM3U
    request = urllib.request.Request(url)
    #request.get_method = lambda : 'HEAD'
    response  = urllib.request.urlopen(request)
    data = response.read()
    data = data.splitlines()
    data = data[len(data) - 1]

    # RETRIEVE THE 2 EXTM3U
    url = response.geturl().split('?')[0]
    url_base = url[: -(len(url) - url.rfind('/'))]
    return url_base + '/' + data


def orderChannels(channels):
          n_data = {}
          for i in channels:    
              number         = i["number"]
              n_data[int(number)] = i

          ordered = sorted(n_data)
          data = {}
          for i in ordered:    
              data[i] = n_data[i]

          return list(data.values())


def getEpistream(portal_mac, url, serial, path):
    
    global key

    args = urllib.parse.parse_qs(sys.argv[2][1:])
    cmd     = args.get('cmd', [''])[0]
    episode     = args['episode'][0]
    plot = args.get('plot','')
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-stv'

    setMac(portal_mac)
    setSerialNumber(serial)

    handshake(url)

    info = retrieveData(url, values = {
        'type' : 'vod', 
        'action' : 'create_link',
        'cmd' : cmd,
        'plot' : plot,
        'series' : episode,
        'JsHttpRequest' : '1-xml'})

    results = info['js']['cmd']
    results = results.replace("ffmpeg ","" )
    

    #portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac));
    #portalurl = path + '/' + portalurl + '-token';
            
    #####response = requests.head(results)
    ##data = response.headers['Location']
    #with open(portalurl, 'wb') as f: f.write(data.encode('utf-8'));
    ##with open(portalurl, 'rb') as f:    
    ##    url = f.read()

       
    title     = args['episode'][0]
    name     = args.get('name', [''])[0]
    logo     = args.get('logo', [''])[0]
    plot     = args.get('plot', [''])[0]
    

    li = xbmcgui.ListItem(title)
    li.setArt({'icon':logo})
    li.setArt({'fanart':logo})

    li.setInfo('video', {'Title': 'Episode:'+title+'  '+name, 'plot': plot})
    xbmc.Player().play(item=results, listitem=li)


def getStream(portal_mac, url, serial, path):
    
    global key


    args = urllib.parse.parse_qs(sys.argv[2][1:])
    cmd     = args.get('cmd', [''])[0]

    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-stv'

    setMac(portal_mac)
    setSerialNumber(serial)

    handshake(url)

    info = retrieveData(url, values = {
        'type' : 'vod', 
        'action' : 'create_link',
        'cmd' : cmd,
        'JsHttpRequest' : '1-xml'})


    results = info['js']['cmd']
    results = results.replace("ffmpeg ","" )
    

    #portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac));
    #portalurl = path + '/' + portalurl + '-token';
            
    #####response = requests.head(results)
    ##data = response.headers['Location']
    #with open(portalurl, 'wb') as f: f.write(data.encode('utf-8'));
    ##with open(portalurl, 'rb') as f:    
    ##    url = f.read()

    plot     = args.get('plot', [''])[0]
    title     = args.get('title', [''])[0]
    logo     = args.get('logo', [''])[0]


    li = xbmcgui.ListItem(title)
    li.setArt({'icon':logo})
    li.setArt({'fanart':logo})

    li.setInfo('video', {'Title': title,'plot' : plot})
    xbmc.Player().play(item=results, listitem=li)


def getTvStream(portal_mac, url, serial, path):
    
    global key


    args = urllib.parse.parse_qs(sys.argv[2][1:])
    cmd     = args.get('cmd', [''])[0]

    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-stv'

    setMac(portal_mac)
    setSerialNumber(serial)

    handshake(url)

    info = retrieveData(url, values = {
        'type' : 'itv', 
        'action' : 'create_link',
        'cmd' : cmd,
        'JsHttpRequest' : '1-xml'})


    results = info['js']['cmd']
    results = results.replace("ffmpeg ","" )
    

    #portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac));
    #portalurl = path + '/' + portalurl + '-token';
            
    #####response = requests.head(results)
    ##data = response.headers['Location']
    #with open(portalurl, 'wb') as f: f.write(data.encode('utf-8'));
    ##with open(portalurl, 'rb') as f:    
    ##    url = f.read()

    plot     = args.get('plot', [''])[0]
    title    = args.get('title', [''])[0]
    logo     = args.get('logo', [''])[0]
#    xbmcgui.Dialog().textviewer('TEST_VIEWER',str(logo_url))

    li = xbmcgui.ListItem(title)
    li.setArt({'icon':logo})
    li.setArt({'fanart':logo})

    li.setInfo('video', {'Title': title,'plot' : plot})
    xbmc.Player().play(item=results, listitem=li)



def _get_epg_ttl_seconds():
    """EPG-Cache TTL aus Addon-Setting lesen.
    Enum-Werte: 0=30min, 1=60min, 2=120min, 3=180min"""
    try:
        import xbmcaddon as _xbmcaddon
        _addon = _xbmcaddon.Addon('plugin.video.titan.premium.tv')
        idx = int(_addon.getSetting('epg_interval') or '1')
        return [30, 60, 120, 180][idx] * 60
    except Exception:
        return 120 * 60  # Fallback: 2 Stunden


def ensureEPG(portal_mac, url, serial, path):
    """EPG-Cache einmal prüfen und ggf. aktualisieren.
    Soll VOR der Senderlisten-Schleife aufgerufen werden,
    damit nicht jedes Item einzeln den Cache prüft."""
    epg_path = _epg_cache_path(portal_mac, path)
    needs_refresh = False
    if not os.path.exists(epg_path):
        needs_refresh = True
    else:
        try:
            age = time() - os.path.getmtime(epg_path)
            if age > _get_epg_ttl_seconds():
                needs_refresh = True
        except Exception:
            needs_refresh = True
    if needs_refresh:
        try:
            getEPG(portal_mac, url, serial, path)
            _EPG_MEM.pop(epg_path, None)
        except Exception:
            pass


def getShortEPG(portal_mac, url, serial, path, epgid):
    """Liest kurzes EPG aus dem lokalen Cache (getEPG).
    ensureEPG() sollte einmal vor der Schleife aufgerufen werden."""

    epg_path = _epg_cache_path(portal_mac, path)

    # Nur laden wenn Datei fehlt (Refresh wird von ensureEPG gemacht)
    if not os.path.exists(epg_path):
        try:
            getEPG(portal_mac, url, serial, path)
            _EPG_MEM.pop(epg_path, None)
        except Exception:
            return ''

    info = _load_epg_cache_from_disk(epg_path)

    key = str(epgid)
    if isinstance(info, dict) and key in info:
        items = info.get(key) or []
        out_lines = []
        for idx, it in enumerate(items[:5]):
            try:
                t_time    = it.get('t_time', '')
                t_time_to = it.get('t_time_to', '')
                name      = it.get('name', '')
                descr     = it.get('descr', '') or it.get('description', '')
                # Format wie titanmacvodedition: HH:MM - HH:MM: Titel
                if t_time_to:
                    line = f"{t_time} - {t_time_to}: {name}"
                else:
                    line = f"{t_time} - {name}"
                out_lines.append(line)
                # Beschreibung nur für aktuellen Eintrag
                if idx == 0 and descr and descr.strip():
                    out_lines.append('__DESCR__' + descr.strip())
            except Exception:
                continue
        out = "\n".join([x for x in out_lines if x]).strip()
        return out if out else ''

    return ''

def getShortEPG1(portal_mac, url, serial, path, epgid):
    eexist = epgid
    xbmcgui.Dialog().notification(addonname, str(eexist), xbmcgui.NOTIFICATION_ERROR )

    return str(eexist)


def getEPG(portal_mac, url, serial, path):
    global key

    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", portal_mac))
    portalurl = path + '/' + portalurl + '-epg'

    setMac(portal_mac)
    #setSerialNumber(serial)

    handshake(url)
    
    info = retrieveData(url, values = {
        'type' : 'itv', 
        'action' : 'get_epg_info',
        'period' : '6',
        'JsHttpRequest' : '1-xml'})


    results = info['js']['data']

    with open(portalurl, 'w') as f:
        json.dump(results, f, indent=4, sort_keys=False)
   
    return


def main(argv):

      if argv[0] == 'load':
          #getAllChannels(argv[1], argv[2], None, argv[4]);
          data = getAllChannels(argv[1], argv[2], json.loads(argv[3]), argv[4])


      elif argv[0] == 'genres':
          getGenres(argv[1], argv[2], None, argv[3])

      elif argv[0] == 'vodgenres':
          getVoDgenres(argv[1], argv[2], None, argv[3])

      elif argv[0] == 'vod':
          getVoD('', argv[1], argv[2])

      elif argv[0] == 'channel':         
          url = retriveUrl(argv[1], argv[2], json.loads(argv[3]), argv[4], argv[5])
          print (url)
    
      elif argv[0] == 'vod_url':
          url = retriveVoD('', argv[1], argv[2])
          print (url)
          
      elif argv[0] == 'cache':
          clearCache(argv[1], argv[2])

      elif argv[0] == 'profile':
          handshake(argv[1])

      elif argv[0] == 'playvod':
          getVodPlay(argv[1])

      elif argv[0] == 'epg':
          url = getEPG(argv[1], argv[2], json.loads(argv[3]), argv[4])
          #print (url)

      elif argv[0] == 'series':
          getsergenres('', argv[1], argv[2])
          
      elif argv[0] == 'info':
          getsergenres('', argv[1], argv[2])


if __name__ == "__main__":
   main(sys.argv[1:])