import socket

# Telnetlib-Ersatz für neuere Python-Versionen
class Telnet:
    def __init__(self, host=None, port=0):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if host:
            self.connect(host, port)

    def connect(self, host, port):
        self.sock.connect((host, port))

    def close(self):
        self.sock.close()

    def write(self, data):
        if isinstance(data, str):
            data = data.encode('ascii')
        self.sock.send(data)

    def read_until(self, expected, timeout=None):
        if isinstance(expected, str):
            expected = expected.encode('ascii')
        response = b''
        while not response.endswith(expected):
            response += self.sock.recv(1024)
        return response

# Telnetlib-Ersatz global verfügbar machen
import sys
import threading
sys.modules['telnetlib'] = type('telnetlib', (), {'Telnet': Telnet})

import os
import json
import urllib.request, urllib.parse, urllib.error
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# --- Ressourcen-Lib Pfad einbinden ---
addon_path_fs = xbmcaddon.Addon().getAddonInfo('path')
lib_path = xbmcvfs.translatePath(os.path.join(addon_path_fs, 'resources', 'lib'))
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

from resources.lib import load_channels
from resources.lib import config
from resources.lib import country_filter
import hashlib
import re
import time
import config
import xbmcvfs
import shutil
from zipfile import ZipFile
from country_filter import get_country_groups_config

addon       = xbmcaddon.Addon('plugin.video.titan.premium.tv')
addonname   = addon.getAddonInfo('name')
addondir    = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
dialog = xbmcgui.Dialog()

# Migration: Erwachsenenbereich einmalig auf false zurücksetzen
# damit XXX-Gruppen standardmäßig sichtbar sind
try:
    if addon.getSetting('adult_filter_migrated_v2') != 'true':
        addon.setSetting('Erwachsenenbereich', 'false')
        addon.setSetting('adult_filter_migrated_v2', 'true')
except Exception:
    pass
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])
go = True
icon0 = xbmcvfs.translatePath('special://home/addons/plugin.video.titan.premium.tv/resources/icons/icon.png')
icon1 = xbmcvfs.translatePath('special://home/addons/plugin.video.titan.premium.tv/resources/icons/tv.png')
icon2 = xbmcvfs.translatePath('special://home/addons/plugin.video.titan.premium.tv/resources/icons/vod.png')
icon3 = xbmcvfs.translatePath('special://home/addons/plugin.video.titan.premium.tv/resources/icons/serien.png')
icon4 = xbmcvfs.translatePath('special://home/addons/plugin.video.titan.premium.tv/resources/icons/cache_clean.png')
icon5 = xbmcvfs.translatePath('special://home/addons/plugin.video.titan.premium.tv/resources/icons/settings.png')

xbmcplugin.setContent(addon_handle, 'movies')



# ---------------------------------------------------------------------------
# Playlist-Zapping Hilfsfunktionen (portiert aus titanmacvodedition)
# ---------------------------------------------------------------------------

def _zap_context_path(ctx_key):
    """Pfad zur JSON-Datei, die den Zap-Kontext (Senderliste) speichert."""
    base = addondir
    if not base:
        return ''
    return os.path.join(base, 'zap_{}.json'.format(ctx_key))


def _save_zap_context(ctx_key, payload):
    """Speichert die Senderliste als JSON für späteres Playlist-Zapping."""
    try:
        path = _zap_context_path(ctx_key)
        if not path:
            return False
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(payload or {}, fh, ensure_ascii=False)
        return True
    except Exception as exc:
        return False


def _load_zap_context(ctx_key):
    """Lädt die gespeicherte Senderliste für das Playlist-Zapping."""
    try:
        path = _zap_context_path(ctx_key)
        if not path or not os.path.exists(path):
            return None
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _build_zap_key(genre_id, portal_name):
    """Eindeutiger Hash-Schlüssel für eine Genre-Gruppe + Portal."""
    raw = '{}|{}'.format(genre_id, portal_name)
    return hashlib.md5(raw.encode('utf-8')).hexdigest()


def _resolve_logo(logo, portal_url):
    """Gibt eine vollständige Logo-URL zurück."""
    if not logo:
        return ''
    l = str(logo)
    if l.startswith('http://') or l.startswith('https://'):
        return l
    if l.startswith('/'):
        return portal_url.rstrip('/') + l
    return portal_url.rstrip('/') + '/stalker_portal/misc/logos/320/' + l


def _build_zap_channel_list_full(genre_id_filter=None):
    """Erstellt eine geordnete Liste aller Live-TV-Kanäle einer Genre-Gruppe
    im Format, das für den Playlist-Build benötigt wird.
    """
    try:
        data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir)
    except Exception:
        return []

    channels = []
    for i in data.get('channels', []):
        genre_id = i.get('genre_id', '')
        if genre_id == '10' and portal.get('parental') == 'true':
            continue
        if genre_id_filter and genre_id_filter != '*' and genre_id != genre_id_filter:
            continue

        logo_url = _resolve_logo(i.get('logo', ''), portal.get('url', ''))

        try:
            epg_text = load_channels.getShortEPG(portal['mac'], portal['url'], portal['serial'], addondir, i.get('id', ''))
        except Exception:
            epg_text = ''

        channels.append({
            'cmd':      i.get('cmd', ''),
            'epgid':    i.get('id', ''),
            'tmp':      str(i.get('tmp', '0')),
            'name':     i.get('name', ''),
            'logo':     logo_url,
            'number':   i.get('number', 0),
            'epg_text': epg_text or '',
        })

    try:
        channels.sort(key=lambda c: int(c['number']))
    except Exception:
        pass
    return channels



def addPortal(portal):

    if portal['url'] == '':
        return

    url = build_url({
        'mode': 'sel',
        'portal': json.dumps(portal)
    })

    li = xbmcgui.ListItem(portal['name'])
    li.setArt({'icon': icon0})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)


def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)


def homeLevel():

    global portal_1, portal_2, portal_3, portal_4, portal_5, portal_6, portal_7, portal_8, portal_9, portal_10, portal_11, portal_12, portal_13, portal_14, portal_15, go

    if go:
        # Hauptmenü anzeigen
        settings_url = build_url({'mode': 'settings'})
        li = xbmcgui.ListItem('[B][COLOR orangered]TiTan[/COLOR][/B] Einstellungen')
        li.setArt({'icon': icon5, 'fanart': icon5})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=settings_url,
            listitem=li,
            isFolder=False
        )
        # Menü abschließen
        addPortal(portal_1)
        addPortal(portal_2)
        addPortal(portal_3)
        addPortal(portal_4)
        addPortal(portal_5)
        addPortal(portal_6)
        addPortal(portal_7)
        addPortal(portal_8)
        addPortal(portal_9)
        addPortal(portal_10)
        addPortal(portal_11)
        addPortal(portal_12)
        addPortal(portal_13)
        addPortal(portal_14)
        addPortal(portal_15)

    xbmcplugin.endOfDirectory(addon_handle)


def SelectLevel():

    url = build_url({
        'mode': 'genres',
        'portal': json.dumps(portal)
    })

    li = xbmcgui.ListItem('[B][COLOR red]TiTan Live TV[/COLOR][/B]')
    li.setArt({'icon': icon1, 'fanart': icon1})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({
        'mode': 'vodgen',
        'portal': json.dumps(portal)
    })

    li = xbmcgui.ListItem('[B][COLOR blue]TiTan VoD[/COLOR][/B]')
    li.setArt({'icon': icon2, 'fanart': icon2})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({
        'mode': 'sergen',
        'portal': json.dumps(portal)
    })

    li = xbmcgui.ListItem('[B][COLOR yellow]TiTan Serien[/COLOR][/B]')
    li.setArt({'icon': icon3, 'fanart': icon3})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({
        'mode': 'cache',
        'portal': json.dumps(portal)
    })

    li = xbmcgui.ListItem('CACHE Clean')
    li.setArt({'icon': icon4, 'fanart': icon4})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

    xbmcplugin.endOfDirectory(addon_handle)


def ClearLevel():
    filelist = [f for f in os.listdir(addondir) if not f.endswith(".xml")]
    for f in filelist:
        os.remove(os.path.join(addondir, f))


def genreLevel():

    try:
        data = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], addondir)

    except Exception as e:
        msg = str(e)
        # Notification ist zu kurz für lange Fehlermeldungen - Dialog zeigen
        xbmcgui.Dialog().ok(addonname, msg)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    data = data['genres']

    # Premium Media Eintrag
    url = build_url({
        'mode': 'top_tv',
        'portal': json.dumps(portal)
    })
    li = xbmcgui.ListItem('[B][COLOR orange]TiTan [COLOR lime]Premium TV[/COLOR][/B]')
    li.setArt({'icon': icon1, 'fanart': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    for id, i in list(data.items()):

        title = i["title"]

        # Adult-Gruppen global ausblenden
        if _adult_filter_enabled() and _is_adult_title(title):
            continue

        url = build_url({
            'mode': 'channels',
            'genre_id': id,
            'genre_name': title.title(),
            'portal': json.dumps(portal)
        })

        if id == '10':
            iconImage = 'OverlayLocked.png'
        else:
            iconImage = 'DefaultVideo.png'

        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon': icon1, 'fanart': icon1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)



def _strip_kodi_markup(s):
    """Entfernt Kodi COLOR/B/I Tags."""
    if not s:
        return ''
    s = re.sub(r'\[COLOR=[^\]]*\]', '', str(s), flags=re.IGNORECASE)
    s = re.sub(r'\[/COLOR\]', '', s, flags=re.IGNORECASE)
    s = re.sub(r'\[/?[BbIi]\]', '', s)
    return s.strip()


def _remaining_minutes(start_s, end_s):
    """Verbleibende Minuten bis Sendungsende."""
    try:
        from datetime import datetime, timedelta
        now = datetime.now()
        sh, sm = [int(x) for x in str(start_s).split(':', 1)]
        eh, em = [int(x) for x in str(end_s).split(':', 1)]
        start_dt = now.replace(hour=sh, minute=sm, second=0, microsecond=0)
        end_dt   = now.replace(hour=eh, minute=em, second=0, microsecond=0)
        if end_dt <= start_dt:
            end_dt += timedelta(days=1)
        remaining = int((end_dt - now).total_seconds() // 60)
        return max(0, remaining)
    except Exception:
        return None


def _parse_epg_line(line):
    """Parst EPG-Zeilen in verschiedenen Formaten:
    'HH:MM - HH:MM: Titel'  → (start, end, title)
    'HH:MM - HH:MM - Titel' → (start, end, title)
    'HH:MM - Titel'         → (start, None, title)
    """
    s = _strip_kodi_markup(str(line or '')).strip()
    # Format mit Start UND End: HH:MM - HH:MM[: ]Titel
    m = re.match(r'^(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*[:\-]\s*(.+)$', s)
    if m:
        return m.group(1), m.group(2), m.group(3).strip()
    # Format nur Start: HH:MM - Titel
    m2 = re.match(r'^(\d{1,2}:\d{2})\s*-\s*(.+)$', s)
    if m2:
        return m2.group(1), None, m2.group(2).strip()
    return None, None, s


def _extract_now_next(epg_text):
    """Gibt (now_line, next_line) zurück — bereinigt von COLOR-Tags und __DESCR__."""
    try:
        if not epg_text or 'Keine' in str(epg_text):
            return '', ''
        clean = _strip_kodi_markup(str(epg_text))
        lines = [l.strip() for l in clean.split('\n')
                 if l.strip() and not l.strip().startswith('__DESCR__')]
        return (lines[0] if lines else ''), (lines[1] if len(lines) > 1 else '')
    except Exception:
        return '', ''


def _build_epg_plot(epg_text):
    """Info-Box Plot wie Bild2:
    JETZT (gelb)
    HH:MM - HH:MM | noch X min
    Sendungstitel
    Beschreibung...

    DANACH (cyan)
    HH:MM - HH:MM | Titel
    """
    try:
        if not epg_text or 'Keine' in str(epg_text):
            return ''

        # __DESCR__ Marker und COLOR-Tags bereinigen
        descr = ''
        clean_lines = []
        for raw in str(epg_text).split('\n'):
            stripped = raw.strip()
            if not stripped:
                continue
            if stripped.startswith('__DESCR__'):
                descr = stripped[9:].strip()
            else:
                clean_lines.append(_strip_kodi_markup(stripped))

        if not clean_lines:
            return ''

        start, end, title = _parse_epg_line(clean_lines[0])

        # Endzeit aus nächster Zeile ableiten falls nicht vorhanden
        if start and not end and len(clean_lines) > 1:
            next_start, _, _ = _parse_epg_line(clean_lines[1])
            if next_start:
                end = next_start

        parts = ['[B][COLOR=yellow]JETZT[/COLOR][/B]']

        if start and end:
            rem = _remaining_minutes(start, end)
            if rem is not None:
                parts.append('[B]{} - {} | noch {} min[/B]'.format(start, end, rem))
            else:
                parts.append('[B]{} - {}[/B]'.format(start, end))
        elif start:
            parts.append('[B]{}[/B]'.format(start))

        if title:
            parts.append(title)
        if descr:
            parts.append('')
            parts.append(descr)

        if len(clean_lines) > 1:
            parts.append('')
            parts.append('[B][COLOR=cyan]DANACH[/COLOR][/B]')
            for line in clean_lines[1:5]:
                s2, e2, t2 = _parse_epg_line(line)
                if s2 and e2:
                    parts.append('{} - {} | {}'.format(s2, e2, t2))
                elif s2 and t2:
                    parts.append('{} | {}'.format(s2, t2))
                elif t2:
                    parts.append(t2)

        return '\n'.join(parts)
    except Exception:
        return 


def _build_channel_label(channel_name, now_line):
    """Für die SENDERLISTE: Sendername  • Jetzt: Zeit - Titel
    COLOR-Tags funktionieren in der Senderliste (nicht in der Playlist).
    """
    try:
        if not now_line:
            return channel_name
        clean = _strip_kodi_markup(now_line)
        return '{} [COLOR=gray]•[/COLOR] [COLOR=yellow]Jetzt:[/COLOR] {}'.format(
            channel_name, clean)
    except Exception:
        return channel_name


def _build_zap_label(channel_name, now_line):
    """Für die VIDEOWIEDERGABELISTE: Sendername • HH:MM - HH:MM • Titel  X min
    Kein Jetzt:, Minuten in gold. Ohne COLOR-Tags da Playlist diese nicht rendert.
    """
    try:
        if not now_line:
            return channel_name
        start, end, title = _parse_epg_line(now_line)
        if start and end:
            rem = _remaining_minutes(start, end)
            body = '{} • {} - {} • {}'.format(channel_name, start, end, title)
            if rem is not None:
                body += '  {} min'.format(rem)
            return body
        if start and title:
            body = '{} • Jetzt: {} - {}'.format(channel_name, start, title)
            return body
        clean = _strip_kodi_markup(now_line)
        return '{} • {}'.format(channel_name, clean)
    except Exception:
        return channel_name


def channelLevel():
    """Senderliste einer Genre-Gruppe anzeigen.
    Speichert gleichzeitig den Zap-Kontext (alle Kanäle) für das Playlist-Zapping.
    """
    stop = False

    genre_id_main = args.get('genre_id', [None])[0]

    # Ladebalken nur beim ersten Aufruf (kein RAM-Cache vorhanden)
    _cache_key_ch = (str(portal.get('mac','')), str(genre_id_main))
    _show_progress = _cache_key_ch not in load_channels._GENRE_CHANNEL_CACHE
    _progress = xbmcgui.DialogProgressBG()
    if _show_progress:
        _progress.create(addonname, 'Lade Senderliste...')
        _progress.update(10)

    try:
        # Wie titanmacvodedition: get_ordered_list mit genre=id pro Gruppe
        # Damit werden auch XXX/Adult-Gruppen korrekt geladen
        if genre_id_main and genre_id_main != '*':
            if _show_progress:
                _progress.update(30, 'Verbinde mit Portal...')
            all_channels = load_channels.getChannelsByGenre(
                portal['mac'], portal['url'], portal['serial'], genre_id_main)
        else:
            if _show_progress:
                _progress.update(30, 'Lade alle Kanäle...')
            data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir)
            all_channels = data['channels']
        if _show_progress:
            _progress.update(70, 'Bereite Senderliste vor...')
    except Exception as e:
        if _show_progress:
            _progress.close()
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    # Genre-Name direkt aus den geladenen Genres holen (wie titanmacvodedition)
    try:
        _gdata = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], addondir)
        genre_name = _gdata.get('genres', {}).get(genre_id_main, {}).get('title', '').title()
    except Exception:
        genre_name = args.get('genre_name', [''])[0] if args.get('genre_name') else ''

    if genre_id_main == '10' and portal['parental'] == 'true':
        result = xbmcgui.Dialog().input('Parental', hashlib.md5(portal['password'].encode('utf-8')).hexdigest(),
                                        type=xbmcgui.INPUT_PASSWORD, option=xbmcgui.PASSWORD_VERIFY)
        if result == '':
            stop = True

    if stop:
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # 'files' → Kodi zeigt automatisch ".." oben (zurück zur Gruppenauswahl)
    xbmcplugin.setContent(addon_handle, 'files')
    xbmcplugin.setPluginCategory(addon_handle, 'TV - {}'.format(genre_name))

    # EPG-Cache einmal vorab prüfen/aktualisieren (nicht für Adult-Genres)
    _is_adult_genre = _is_adult_title(genre_name)
    if not _is_adult_genre:
        try:
            load_channels.ensureEPG(portal['mac'], portal['url'], portal['serial'], addondir)
        except Exception:
            pass

    # --- Zap-Kontext: geordnete Senderliste für Playlist-Zapping aufbauen ---
    ctx_key = _build_zap_key(genre_id_main, portal.get('name', ''))
    zap_channels = []   # alle Kanäle dieser Gruppe, indiziert (idx)
    idx_counter  = 0    # laufender Index der in zap_channels auftauchenden Kanäle
    idx_map      = {}   # cmd -> idx  (für URL-Bau)

    for i in all_channels:
        genre_id = i.get('genre_id', '')
        if genre_id_main == '*' and genre_id == '10' and portal['parental'] == 'true':
            continue
        if genre_id_main != '*' and genre_id != genre_id_main:
            continue
        logo_url = _resolve_logo(i.get('logo', ''), portal.get('url', ''))
        try:
            epg_text = '' if _is_adult_genre else load_channels.getShortEPG(
                portal['mac'], portal['url'], portal['serial'], addondir, i.get('id', ''))
        except Exception:
            epg_text = ''
        zap_channels.append({
            'cmd':      i.get('cmd', ''),
            'epgid':    i.get('id', ''),
            'tmp':      str(i.get('tmp', '0')),
            'name':     i.get('name', ''),
            'logo':     logo_url,
            'number':   i.get('number', 0),
            'epg_text': epg_text or '',
        })
        idx_map[i.get('cmd', '')] = idx_counter
        idx_counter += 1

    # Zap-Kontext auf Disk speichern (inkl. Portal für play_zap)
    if zap_channels:
        _save_zap_context(ctx_key, {
            'genre_id':    genre_id_main,
            'portal_name': portal.get('name', ''),
            'channels':    zap_channels,
            'portal':      portal,
        })

    # --- Verzeichnis-Einträge aufbauen ---
    for i in all_channels:
        epgid    = i["id"]
        name     = i["name"]
        cmd      = i["cmd"]
        tmp      = i["tmp"]
        number   = i["number"]
        genre_id = i["genre_id"]
        logo     = i["logo"]

        if genre_id_main == '*' and genre_id == '10' and portal['parental'] == 'true':
            continue
        if genre_id_main != '*' and genre_id != genre_id_main:
            continue

        logo_url = _resolve_logo(logo, portal.get('url', ''))
        if not logo_url:
            logo_url = 'ext.png'

        try:
            epg_raw = '' if _is_adult_genre else load_channels.getShortEPG(
                portal['mac'], portal['url'], portal['serial'], addondir, epgid)
        except Exception:
            epg_raw = ''

        now_line, next_line = _extract_now_next(epg_raw)
        plot  = _build_epg_plot(epg_raw)
        label = _build_channel_label(name, now_line)

        idx = idx_map.get(cmd, 0)

        # __DESCR__ aus dem URL-Parameter entfernen (wird in checkcmd neu aufgebaut)
        _plot_for_url = '\n'.join(
            l for l in epg_raw.split('\n') if not l.startswith('__DESCR__')
        ).strip() if epg_raw else ''

        url = build_url({
            'mode':       'check',
            'cmd':        cmd,
            'epgid':      epgid,
            'tmp':        tmp,
            'title':      name,
            'genre_name': genre_name,
            'logo':       logo,
            'logo_url':   logo_url,
            'portal':     json.dumps(portal),
            'plot':       _plot_for_url,
            'genre_id':   genre_id_main,
        })

        li = xbmcgui.ListItem(label, label2='Danach: {}'.format(next_line) if next_line else '')
        art_icon = logo_url
        try:
            if logo:
                l = str(logo)
                if l.startswith('http://') or l.startswith('https://'):
                    art_icon = l
                elif l.startswith('/'):
                    art_icon = portal['url'].rstrip('/') + l
        except Exception:
            art_icon = logo_url
        li.setArt({'icon': art_icon, 'thumb': art_icon, 'clearlogo': art_icon, 'fanart': art_icon})
        try:
            _vi = li.getVideoInfoTag()
            _vi.setTitle(name)
            _vi.setPlot(plot)
        except Exception:
            li.getVideoInfoTag().setTitle(str(name) if name else '')
        # Zap-Kontext-Menü: Nächster / Vorheriger Sender
        if zap_channels:
            next_ch  = zap_channels[(idx + 1) % len(zap_channels)]
            prev_ch  = zap_channels[(idx - 1) % len(zap_channels)]
            next_url = build_url({'mode': 'check', 'cmd': next_ch['cmd'],
                'epgid': next_ch['epgid'], 'tmp': next_ch.get('tmp','0'),
                'title': next_ch['name'], 'genre_name': genre_name,
                'logo': next_ch.get('logo',''), 'logo_url': next_ch.get('logo',''),
                'portal': json.dumps(portal), 'plot': next_ch.get('epg_text',''),
                'genre_id': genre_id_main})
            prev_url = build_url({'mode': 'check', 'cmd': prev_ch['cmd'],
                'epgid': prev_ch['epgid'], 'tmp': prev_ch.get('tmp','0'),
                'title': prev_ch['name'], 'genre_name': genre_name,
                'logo': prev_ch.get('logo',''), 'logo_url': prev_ch.get('logo',''),
                'portal': json.dumps(portal), 'plot': prev_ch.get('epg_text',''),
                'genre_id': genre_id_main})
            li.addContextMenuItems([
                ('[B]>> Nächster Sender[/B]', 'RunPlugin({})'.format(next_url)),
                ('[B]<< Vorheriger Sender[/B]', 'RunPlugin({})'.format(prev_url)),
            ])

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    if _show_progress:
        _progress.update(100)
        _progress.close()
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER)
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, cacheToDisc=False)
def vodgenreLevel():

    try:
        data = load_channels.getVoDgenres(portal['mac'], portal['url'], portal['serial'], addondir)

    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)

        return

    data = data['vodgenres']

    # Premium Media Eintrag
    url = build_url({
        'mode': 'top_vod',
        'portal': json.dumps(portal)
    })
    li = xbmcgui.ListItem('[B][COLOR orange]TiTan [COLOR lime]Premium VOD[/COLOR][/B]')
    li.setArt({'icon': icon2, 'fanart': icon2})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    for id, i in list(data.items()):

        title = i["title"]
        cat = i["cat"]

        # Adult-Gruppen global ausblenden
        if _adult_filter_enabled() and _is_adult_title(title):
            continue

        url = build_url({
            'mode': 'vod',
            'genre_name': title.title(),
            'cat': cat,
            'portal': json.dumps(portal)
        })

        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon': icon2, 'fanart': icon2})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def vodLevel():

    cat = args['cat'][0]
    _vod_cache_path = addondir + '/' + '_'.join(__import__('re').findall('[a-zA-Z0-9]+', portal['mac'])) + '-vod' + cat
    _show_vod_progress = not __import__('os').path.exists(_vod_cache_path)
    _vod_progress = xbmcgui.DialogProgressBG()
    if _show_vod_progress:
        _vod_progress.create(addonname, 'Lade VoD-Inhalte...')
        _vod_progress.update(10, 'Verbinde mit Portal...')

    try:
        data = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], addondir)
        if _show_vod_progress:
            _vod_progress.update(80, 'Bereite Liste vor...')
    except Exception as e:
        if _show_vod_progress:
            _vod_progress.close()
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    data = data['vod' + cat]

    for i in data:
        name = i["name"]
        cmd = i["cmd"]
        logo = i["logo"]
        plot = i["plot"]
        year = i["year"]
        genre = i["genre"]

        if logo != '':
            logo_url = portal['url'] + logo
        else:
            logo_url = 'DefaultVideo.png'

        url = build_url({
            'mode': 'playvod',
            'cmd': cmd,
            'tmp': '0',
            'title': name,
            'genre_name': 'VoD',
            'logo_url': logo_url,
            'logo': logo,
            'plot': plot,
            'year': year,
            'genre': genre,
            'cat': cat,
            'name': name,
            'portal': json.dumps(portal)
        })

        li = xbmcgui.ListItem(name)
        try:
            _vi = li.getVideoInfoTag()
            _vi.setTitle(name)
            _vi.setPlot(plot)
            if year: _vi.setYear(int(year)) if str(year).isdigit() else None
            if genre: _vi.setGenres([genre])
        except Exception:
            li.getVideoInfoTag().setTitle(str(name) if name else '')
        _fanart = logo if logo and logo != 'DefaultVideo.png' else icon2
        li.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': _fanart})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    if _show_vod_progress:
        _vod_progress.update(100)
        _vod_progress.close()
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE)
    xbmcplugin.endOfDirectory(addon_handle)


def SeriesGenre():

    try:
        data = load_channels.getSergenres(portal['mac'], portal['url'], portal['serial'], addondir)

    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)

        return

    data = data['sergenres']

    # Premium Media Eintrag
    url = build_url({
        'mode': 'top_series',
        'portal': json.dumps(portal)
    })
    li = xbmcgui.ListItem('[B][COLOR orange]TiTan [COLOR lime]Premium Series[/COLOR][/B]')
    li.setArt({'icon': icon3, 'fanart': icon3})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    for id, i in list(data.items()):

        title = i["title"]
        cat = i["cat"]

        # Adult-Gruppen global ausblenden
        if _adult_filter_enabled() and _is_adult_title(title):
            continue

        url = build_url({
            'mode': 'seriescat',
            'genre_name': title.title(),
            'cat': cat,
            'portal': json.dumps(portal)
        })

        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon': icon3, 'fanart': icon3})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def SeriesLevel():

    cat = args['cat'][0]
    _ser_cache_path = addondir + '/' + '_'.join(__import__('re').findall('[a-zA-Z0-9]+', portal['mac'])) + '-ser' + cat
    _show_ser_progress = not __import__('os').path.exists(_ser_cache_path)
    _ser_progress = xbmcgui.DialogProgressBG()
    if _show_ser_progress:
        _ser_progress.create(addonname, 'Lade Serien...')
        _ser_progress.update(10, 'Verbinde mit Portal...')

    try:
        data = load_channels.getSeries(portal['mac'], portal['url'], portal['serial'], addondir)
        if _show_ser_progress:
            _ser_progress.update(80, 'Bereite Liste vor...')
    except Exception as e:
        if _show_ser_progress:
            _ser_progress.close()
        return

    cat = args['cat'][0]

    data = data['ser' + cat]

    for i in data:
        name = i["name"]
        cmd = i["cmd"]
        logo = i["logo"]
        plot = i["plot"]
        year = i["year"]
        genre = i["genre"]
        cat = i['cat']
        category = i['category']

        if logo != '':
            logo_url = portal['url'] + logo
        else:
            logo_url = 'DefaultVideo.png'

        url = build_url({
            'mode': 'season',
            'cat': cat,
            'name': name,
            'cmd': cmd,
            'category': category,
            'logo_url': logo_url,
            'logo': logo,
            'plot': plot,
            'year': year,
            'genre': genre,
            'portal': json.dumps(portal)
        })

        li = xbmcgui.ListItem(name)
        try:
            _vi = li.getVideoInfoTag()
            _vi.setTitle(name)
            _vi.setPlot(plot)
            if year: _vi.setYear(int(year)) if str(year).isdigit() else None
            if genre: _vi.setGenres([genre])
        except Exception:
            li.getVideoInfoTag().setTitle(str(name) if name else '')
        _fanart = logo_url if logo_url and logo_url != 'DefaultVideo.png' else icon3
        li.setArt({'icon': logo_url, 'thumb': logo_url, 'poster': logo_url, 'fanart': _fanart})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    if _show_ser_progress:
        _ser_progress.update(100)
        _ser_progress.close()
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE)
    xbmcplugin.endOfDirectory(addon_handle)


def SeasonLevel():

    try:
        data = load_channels.get_seasons(portal['mac'], portal['url'], portal['serial'], addondir)

    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    cat = args['cat'][0]

    data = data['seasons' + cat]

    for i in data:
        name = i["name"]
        cmd = i["cmd"]
        logo = i["logo"]
        cat = i["cat"]
        category = i["category"]
        year = i['year']
        plot = i['plot']
        genre = i['genre']

        if logo != '':
            logo_url = portal['url'] + logo
        else:
            logo_url = 'DefaultVideo.png'

        url = build_url({
            'mode': 'episode',
            'cat': cat,
            'category': category,
            'name': name,
            'cmd': cmd,
            'logo': logo,
            'portal': json.dumps(portal)
        })

        li = xbmcgui.ListItem(name)
        try:
            _vi = li.getVideoInfoTag()
            _vi.setTitle(name)
            _vi.setPlot(plot)
            if genre: _vi.setGenres([genre])
        except Exception:
            li.getVideoInfoTag().setTitle(str(name) if name else '')

        li.setArt({'icon': logo})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE)
    xbmcplugin.endOfDirectory(addon_handle)


def EpisodeLevel():
    cat = args['cat'][0]
    logo = args.get('logo', [''])[0]
    plot = _build_epg_plot(args.get('plot', [''])[0])
    data = load_channels.get_episodes(portal['mac'], portal['url'], portal['serial'], addondir)

    data = data['episodes']

    for i in data:
        name = i["name"]
        cmd = i["cmd"]
        cat = i["cat"]
        category = i["category"]
        series = i["series"]
        episode = i["episode"]

        url = build_url({
            'mode': 'epiplay',
            'episode': episode,
            'name': name,
            'cat': cat,
            'category': category,
            'cmd': cmd,
            'logo': logo,
            'portal': json.dumps(portal)
        })

        cat1 = args.get('cat', None)
        cat1 = cat1[0]
        if cat1 == cat:

            li = xbmcgui.ListItem(str(episode))
            li.getVideoInfoTag().setTitle(str(episode))
            li.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo, 'clearlogo': logo})
            li.setProperty('fanart_image', logo)
            try:
                li.getVideoInfoTag().setTitle(str(episode))
            except Exception:
                pass

            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE)
    xbmcplugin.endOfDirectory(addon_handle)


def checkcmd():
    """Löst den Stream auf und startet ihn via setResolvedUrl.
    Der Background-Thread baut dann die volle Zap-Playlist auf.
    Wie titanmacvodedition: setResolvedUrl hält den Plugin-Prozess länger am Leben
    als xbmc.Player().play(), damit der Thread genug Zeit hat.
    """
    cmd          = args['cmd'][0]
    title        = args.get('title',    [''])[0]
    logo         = args.get('logo',     [''])[0]
    logo_url     = args.get('logo_url', [logo])[0]
    plot         = _build_epg_plot(args.get('plot', [''])[0])
    genre_id_zap = args.get('genre_id', ['*'])[0]
    genre_name   = args.get('genre_name', [''])[0]
    art          = logo_url or logo

    if str(cmd).startswith('ffmpeg http://localhost') is True:
        # create_link → Stream-URL auflösen
        try:
            stream_url = _resolve_ffmpeg_url(portal, cmd)
        except Exception as e:
            xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return
    else:
        # Normaler Stream via retriveUrl
        tmp = args.get('tmp', ['0'])[0]
        try:
            stream_url = load_channels.retriveUrl(
                portal['mac'], portal['url'], portal['serial'], cmd, tmp)
        except Exception as e:
            xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

    # Sofort abspielen via setResolvedUrl
    li = xbmcgui.ListItem(title, path=stream_url)
    li.setProperty('IsPlayable', 'true')
    if art:
        li.setArt({'icon': art, 'thumb': art, 'poster': art,
                   'fanart': art, 'clearlogo': art})
    try:
        vi = li.getVideoInfoTag()
        vi.setTitle(title)
        vi.setMediaType('movie')
        vi.setDuration(0)
        if plot:
            vi.setPlot(plot)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(addon_handle, True, li)

    # Zap-Kontext laden
    ctx_key  = _build_zap_key(genre_id_zap, portal.get('name', ''))
    ctx      = _load_zap_context(ctx_key)
    channels = ctx.get('channels') if isinstance(ctx, dict) else None

    if not channels:
        return

    # Portal im Kontext speichern
    ctx['portal'] = portal
    _save_zap_context(ctx_key, ctx)

    # Aktuellen Index bestimmen
    current_idx = 0
    for i, ch in enumerate(channels):
        if ch.get('cmd', '') == cmd:
            current_idx = i
            break

    _portal = portal
    # Für Adult-Genres keine Zap-Playlist aufbauen (kein Auto-Weiterschalten)
    _skip_zap_playlist = _is_adult_title(genre_name)

    def _build_zap():
        """Background-Thread: baut die Zap-Playlist.
        Oben ein Navigationspunkt zurück zur Senderliste.
        Alle Sender als play_zap URLs — kein URL-Scraping.
        """
        # Für Adult-Genres keine Playlist — kein automatisches Weiterschalten
        if _skip_zap_playlist:
            return
        try:
            player = xbmc.Player()
            for _ in range(40):
                if player.isPlaying():
                    break
                xbmc.sleep(100)
            if not player.isPlaying():
                return

            addon_base = 'plugin://plugin.video.titan.premium.tv/'
            # Genre-Name ermitteln
            try:
                all_genres_data = load_channels.getGenres(
                    _portal['mac'], _portal['url'], _portal['serial'], addondir)
                all_genres = all_genres_data.get('genres', {})
                genre_title = all_genres.get(genre_id_zap, {}).get('title', 'Senderliste').title()
            except Exception:
                genre_title = 'Senderliste'

            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()

            # Alle Sender der Gruppe
            for i, ch in enumerate(channels):
                ch_name  = ch.get('name', '')
                ch_logo  = ch.get('logo', '')
                epg_text = ch.get('epg_text', '')
                now_line, _ = _extract_now_next(epg_text)
                label = _build_zap_label(ch_name, now_line)

                if i == current_idx:
                    s_url = stream_url
                else:
                    s_url = addon_base + '?' + urllib.parse.urlencode({
                        'mode': 'play_zap', 'cmd': ch['cmd'],
                        'tmp': ch.get('tmp', '0'), 'title': ch_name,
                        'logo': ch_logo, 'ctx_key': ctx_key,
                    })

                li2 = xbmcgui.ListItem(label=label, path=s_url)
                li2.setProperty('IsPlayable', 'true')
                try:
                    vi2 = li2.getVideoInfoTag()
                    vi2.setTitle(label)
                    vi2.setOriginalTitle(ch_name)
                    vi2.setDuration(0)
                    if epg_text:
                        vi2.setPlot(_build_epg_plot(epg_text))
                except Exception:
                    pass
                if ch_logo:
                    li2.setArt({'icon': ch_logo, 'thumb': ch_logo, 'clearlogo': ch_logo})
                playlist.add(s_url, li2)

            if playlist.size() > 1:
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.sleep(200)
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')

        except Exception as exc:
            xbmc.log('TiTan ZAP build failed: {}'.format(exc), xbmc.LOGWARNING)

    t = threading.Thread(target=_build_zap, daemon=True, name='titan-zap')
    t.start()



def _resolve_ffmpeg_url(portal_data, cmd):
    """Löst eine ffmpeg:// Kanal-URL per create_link auf und gibt die HTTP-URL zurück."""
    load_channels.setMac(portal_data['mac'])
    load_channels.setSerialNumber(portal_data['serial'])
    load_channels.handshake(portal_data['url'])
    _info = load_channels.retrieveData(portal_data['url'], values={
        'type': 'itv',
        'action': 'create_link',
        'cmd': cmd,
        'JsHttpRequest': '1-xml'})
    return _info['js']['cmd'].replace('ffmpeg ', '').strip()


def _make_listitem(title, logo, plot, stream_url):
    """Erstellt ein ListItem mit allen Art-Feldern."""
    li = xbmcgui.ListItem(title, path=stream_url)
    li.setProperty('IsPlayable', 'true')
    if logo:
        li.setArt({'icon': logo, 'thumb': logo, 'poster': logo,
                   'fanart': logo, 'clearlogo': logo})
    try:
        vi = li.getVideoInfoTag()
        vi.setTitle(title)
        vi.setMediaType('movie')
        vi.setDuration(0)
        if plot:
            vi.setPlot(plot)
    except Exception:
        try:
            _vi = li.getVideoInfoTag()
            _vi.setTitle(title)
            if plot: _vi.setPlot(plot)
        except Exception:
            pass
    return li


def _play_ffmpeg_channel():
    """Spielt einen ffmpeg-Kanal ab und baut die volle Zap-Playlist für Vor/Zurück."""
    cmd          = args.get('cmd',      [''])[0]
    title        = args.get('title',    [''])[0]
    logo         = args.get('logo',     [''])[0]
    plot         = _build_epg_plot(args.get('plot', [''])[0])
    genre_id_zap = args.get('genre_id', ['*'])[0]

    # Stream-URL auflösen
    try:
        stream_url = _resolve_ffmpeg_url(portal, cmd)
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    # Zap-Kontext laden
    ctx_key  = _build_zap_key(genre_id_zap, portal.get('name', ''))
    ctx      = _load_zap_context(ctx_key)
    channels = ctx.get('channels') if isinstance(ctx, dict) else None

    if channels:
        # Portal im Kontext speichern für play_zap
        ctx['portal'] = portal
        _save_zap_context(ctx_key, ctx)

        # Aktuellen Index finden
        current_idx = 0
        for i, ch in enumerate(channels):
            if ch.get('cmd', '') == cmd:
                current_idx = i
                break

        # Volle Playlist aufbauen inkl. Gruppen-Navigation oben/unten
        playlist, start_pos = _build_zap_playlist_with_resolved(
            channels, current_idx, stream_url, portal, ctx_key,
            genre_id=genre_id_zap)

        xbmc.Player().play(playlist, startpos=start_pos)
    else:
        # Kein Kontext: einfach direkt spielen
        li = _make_listitem(title, logo, plot, stream_url)
        xbmc.Player().play(item=stream_url, listitem=li)


def _build_zap_playlist_with_resolved(channels, current_idx, current_stream_url,
                                       portal_data, ctx_key, genre_id=None):
    """Baut eine Playlist mit allen Sendern der Gruppe + Navigationspunkte
    für Vorherige/Nächste Sendergruppe am Anfang und Ende der Liste.
    """
    addon_base = 'plugin://plugin.video.titan.premium.tv/'
    icon_prev  = xbmcvfs.translatePath(
        'special://home/addons/plugin.video.titan.premium.tv/resources/media/pagePrevious.png')
    icon_next  = xbmcvfs.translatePath(
        'special://home/addons/plugin.video.titan.premium.tv/resources/media/pageNext.png')

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    # --- Alle Sender der aktuellen Gruppe ---
    adjusted_idx = current_idx

    for i, ch in enumerate(channels):
        ch_name  = ch.get('name', '')
        ch_logo  = ch.get('logo', '')
        epg_text = ch.get('epg_text', '')
        now_line, _ = _extract_now_next(epg_text)
        label = _build_zap_label(ch_name, now_line)

        if i == current_idx:
            s_url = current_stream_url
        else:
            zap_params = urllib.parse.urlencode({
                'mode': 'play_zap', 'cmd': ch['cmd'], 'tmp': ch.get('tmp', '0'),
                'title': ch_name, 'logo': ch_logo, 'ctx_key': ctx_key,
            })
            s_url = addon_base + '?' + zap_params

        li2 = xbmcgui.ListItem(label=label, path=s_url)
        li2.setProperty('IsPlayable', 'true')
        try:
            vi = li2.getVideoInfoTag()
            vi.setTitle(label)
            vi.setOriginalTitle(ch_name)
            vi.setDuration(0)
            if epg_text:
                vi.setPlot(_build_epg_plot(epg_text))
        except Exception:
            pass
        if ch_logo:
            li2.setArt({'icon': ch_logo, 'thumb': ch_logo, 'clearlogo': ch_logo})
        playlist.add(s_url, li2)

    return playlist, adjusted_idx


def playLevel():

    dp = xbmcgui.DialogProgressBG()
    dp.create('TiTan Premium TV', 'Loading....')

    title = args.get('title', [''])[0]
    cmd = args.get('cmd', [''])[0]
    tmp = args.get('tmp', [''])[0]
    genre_name = args.get('genre_name', [''])[0]
    logo_url = args.get('logo_url', [''])[0]
    logo = args.get('logo', [logo_url])[0]
    plot = _build_epg_plot(args.get('plot', [''])[0])
    cat = args.get('cat', [''])[0]
    # Fallback: wenn Plot/Artwork leer sind, Details aus VOD-Liste nachladen (Stalker liefert bei Play oft nichts mit)
    try:
        if genre_name == 'VoD' and (not plot or str(plot).strip() == '' or not logo or str(logo).strip() == '') and cat:
            voddata = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], addondir)
            vodlist = voddata.get('vod'+str(cat), [])
            for it in vodlist:
                if str(it.get('cmd','')) == str(cmd) or str(it.get('name','')) == str(title):
                    if not plot: plot = it.get('plot','') or plot
                    if not year: year = it.get('year','') or year
                    if not genre or genre==genre_name: genre = it.get('genre','') or genre
                    if not logo: logo = it.get('logo','') or logo
                    break
    except Exception as _e:
        pass
    year = args.get('year', [''])[0]
    genre = args.get('genre', [genre_name])[0]
    # Artwork-URL normalisieren (manche Portale liefern nur relative Logo-Pfade)
    art_url = logo
    if not art_url or str(art_url).strip() == '':
        art_url = logo_url
    if art_url and not str(art_url).lower().startswith('http'):
        try:
            baseu = portal.get('url','').rstrip('/')
            if str(art_url).startswith('/'):
                art_url = baseu + str(art_url)
            else:
                art_url = baseu + '/' + str(art_url)
        except Exception:
            art_url = logo_url
    if not plot or str(plot).strip() == '':
        plot = 'Keine Informationen'
    logo = args.get('logo', [''])[0]
    plot = _build_epg_plot(args.get('plot', [''])[0])
    year = args.get('year', [''])[0]
    genre = args.get('genre', [genre_name])[0]
    logo_url = args.get('logo_url', [''])[0]
    logo = args.get('logo', [logo_url])[0]
    plot = _build_epg_plot(args.get('plot', [''])[0])
    year = args.get('year', [''])[0]
    genre = args.get('genre', [genre_name])[0]

    try:
        if genre_name != 'VoD':
            url = load_channels.retriveUrl(portal['mac'], portal['url'], portal['serial'], cmd, tmp)
        else:
            url = load_channels.retrive_defaultUrl(portal['mac'], portal['url'], portal['serial'], cmd)

    except Exception as e:
        dp.close()
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    dp.update(80)

    title = title

    title += ' (' + portal['name'] + ')'

    li = xbmcgui.ListItem(title)
    try:
        _vi = li.getVideoInfoTag()
        _vi.setTitle(title)
        _vi.setMediaType('movie')
        if plot: _vi.setPlot(plot)
        if year and str(year).isdigit(): _vi.setYear(int(year))
        if genre: _vi.setGenres([genre])
    except Exception:
        pass
    # Ensure channel logo/poster are available in the player INFO dialog (Kodi 21)
    if art_url:
        li.setArt({'icon': art_url, 'thumb': art_url, 'poster': art_url, 'fanart': art_url, 'clearlogo': art_url, 'banner': art_url})
        li.setProperty('thumb', art_url)
    # Playback via setResolvedUrl, damit Kodi Info/Poster im Player korrekt übernimmt
    li.setPath(url)
    li.setProperty('IsPlayable', 'true')

    xbmcplugin.setResolvedUrl(addon_handle, True, li)

    dp.update(100)
    dp.close()


def navGroupLevel():
    """Gruppennavigation: manueller Auswahldialog mit allen verfügbaren Sendergruppen."""
    direction = args.get('direction', ['select'])[0]
    genre_id  = args.get('genre_id',  [''])[0]

    try:
        all_genres_data = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], addondir)
        all_genres = all_genres_data.get('genres', {})
        genre_ids = [gid for gid, g in all_genres.items()
                     if not (_adult_filter_enabled() and _is_adult_title(g.get('title', '')))]

        if not genre_ids:
            return

        if genre_id in genre_ids:
            cur_pos = genre_ids.index(genre_id)
        else:
            cur_pos = 0

        if direction == 'select':
            # Auswahldialog mit allen Gruppen
            genre_names = [all_genres[gid]['title'].title() for gid in genre_ids]
            chosen = xbmcgui.Dialog().select('Sendergruppe wählen', genre_names, preselect=cur_pos)
            if chosen < 0:
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
                return
            target_gid = genre_ids[chosen]
        elif direction == 'next':
            target_gid = genre_ids[(cur_pos + 1) % len(genre_ids)]
        else:
            target_gid = genre_ids[(cur_pos - 1) % len(genre_ids)]

        target_genre = all_genres[target_gid]

        # Kanäle der Zielgruppe laden
        all_ch_data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir)
        target_channels = [ch for ch in all_ch_data.get('channels', [])
                           if ch.get('genre_id', '') == target_gid]

        if not target_channels:
            xbmcgui.Dialog().notification(addonname,
                'Keine Sender in Gruppe: {}'.format(target_genre['title']),
                xbmcgui.NOTIFICATION_INFO)
            return

        # Ersten Sender der Zielgruppe starten
        first_ch = target_channels[0]
        first_cmd = first_ch['cmd']
        first_name = first_ch.get('name', '')
        first_logo = _resolve_logo(first_ch.get('logo', ''), portal.get('url', ''))
        first_tmp = str(first_ch.get('tmp', '0'))

        try:
            first_url = _resolve_ffmpeg_url(portal, first_cmd)
        except Exception as e:
            xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        # Zap-Kontext für neue Gruppe aufbauen und speichern
        new_ctx_key = _build_zap_key(target_gid, portal.get('name', ''))
        zap_channels = []
        for ch in target_channels:
            logo_url = _resolve_logo(ch.get('logo', ''), portal.get('url', ''))
            try:
                epg_text = load_channels.getShortEPG(portal['mac'], portal['url'],
                                                      portal['serial'], addondir, ch.get('id', ''))
            except Exception:
                epg_text = ''
            zap_channels.append({
                'cmd': ch['cmd'], 'epgid': ch.get('id', ''),
                'tmp': str(ch.get('tmp', '0')), 'name': ch.get('name', ''),
                'logo': logo_url, 'number': ch.get('number', 0), 'epg_text': epg_text or '',
            })
        _save_zap_context(new_ctx_key, {
            'genre_id': target_gid, 'portal_name': portal.get('name', ''),
            'channels': zap_channels, 'portal': portal,
        })

        # Playlist mit neuer Gruppe aufbauen
        playlist, start_pos = _build_zap_playlist_with_resolved(
            zap_channels, 0, first_url, portal, new_ctx_key, genre_id=target_gid)

        # Titel der Gruppe als Notification
        xbmcgui.Dialog().notification(
            addonname, target_genre['title'].title(), first_logo, 2000)

        li = _make_listitem(first_name, first_logo, '', first_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, li)
        xbmc.Player().play(playlist, startpos=start_pos)

    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())


def playZapLevel():
    """Löst die Stream-URL für einen Zap-Playlist-Eintrag auf.
    Wird von Kodi aufgerufen wenn der User zum nächsten/vorherigen Sender springt.
    Portal wird aus dem gespeicherten Zap-Kontext geladen (keine langen URL-Parameter).
    """
    zap_cmd   = args.get('cmd',     [''])[0]
    zap_tmp   = args.get('tmp',     ['0'])[0]
    zap_title = args.get('title',   [''])[0]
    zap_logo  = args.get('logo',    [''])[0]
    ctx_key   = args.get('ctx_key', [''])[0]


    # Portal aus Zap-Kontext laden
    zap_portal = portal  # Fallback auf globales portal
    if ctx_key:
        ctx = _load_zap_context(ctx_key)
        if isinstance(ctx, dict) and ctx.get('portal'):
            zap_portal = ctx['portal']

    try:
        load_channels.setMac(zap_portal['mac'])
        load_channels.setSerialNumber(zap_portal['serial'])
        load_channels.handshake(zap_portal['url'])
        _info = load_channels.retrieveData(zap_portal['url'], values={
            'type': 'itv',
            'action': 'create_link',
            'cmd': zap_cmd,
            'JsHttpRequest': '1-xml'})
        stream_url = _info['js']['cmd'].replace('ffmpeg ', '').strip()
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return


    li = xbmcgui.ListItem(zap_title, path=stream_url)
    li.setProperty('IsPlayable', 'true')
    try:
        vi = li.getVideoInfoTag()
        vi.setTitle(zap_title)
        vi.setDuration(0)
        vi.setMediaType('movie')
    except Exception:
        pass
    if zap_logo:
        li.setArt({'icon': zap_logo, 'thumb': zap_logo, 'poster': zap_logo, 'fanart': zap_logo, 'clearlogo': zap_logo})
    xbmcplugin.setResolvedUrl(addon_handle, True, li)


def playStreamLevel():

    load_channels.getStream(portal['mac'], portal['url'], portal['serial'], addondir)


def PlayEpisode():

    load_channels.getEpistream(portal['mac'], portal['url'], portal['serial'], addondir)


mode = args.get('mode', None)
portal = args.get('portal', None)

if portal is None:
    portal_15 = config.portalConfig('15')
    portal_14 = config.portalConfig('14')
    portal_13 = config.portalConfig('13')
    portal_12 = config.portalConfig('12')
    portal_11 = config.portalConfig('11')
    portal_10 = config.portalConfig('10')
    portal_9 = config.portalConfig('9')
    portal_8 = config.portalConfig('8')
    portal_7 = config.portalConfig('7')
    portal_6 = config.portalConfig('6')
    portal_5 = config.portalConfig('5')
    portal_4 = config.portalConfig('4')
    portal_3 = config.portalConfig('3')
    portal_2 = config.portalConfig('2')
    portal_1 = config.portalConfig('1')

else:
    portal = json.loads(portal[0])
    portal_2 = config.portalConfig('2')
    portal_3 = config.portalConfig('3')
    portal_4 = config.portalConfig('4')
    portal_5 = config.portalConfig('5')
    portal_6 = config.portalConfig('6')
    portal_7 = config.portalConfig('7')
    portal_8 = config.portalConfig('8')
    portal_9 = config.portalConfig('9')
    portal_10 = config.portalConfig('10')
    portal_11 = config.portalConfig('11')
    portal_12 = config.portalConfig('12')
    portal_13 = config.portalConfig('13')
    portal_14 = config.portalConfig('14')
    portal_15 = config.portalConfig('15')

    if not (portal['name'] == portal_2['name'] or portal['name'] == portal_3['name'] or portal['name'] == portal_4['name'] or portal['name'] == portal_5['name'] or portal['name'] == portal_6['name'] or portal['name'] == portal_7['name'] or portal['name'] == portal_8['name'] or portal['name'] == portal_9['name'] or portal['name'] == portal_10['name'] or portal['name'] == portal_11['name'] or portal['name'] == portal_12['name'] or portal['name'] == portal_13['name'] or portal['name'] == portal_14['name'] or portal['name'] == portal_15['name'] or portal['name']):
        portal = config.portalConfig('1')


def _check_country_prefix_match(genre_title, code_to_check):
    """Prüft, ob der Genre-Titel mit einem bestimmten Ländercode (DE, AT, CH, ...) beginnt.
    Erlaubt z.B. "DE", "DE SPORT", "DE-HD", "DE/SPORT" usw.
    """
    if not genre_title or not code_to_check:
        return False
    genre_title = str(genre_title).strip().upper()
    code_to_check = str(code_to_check).strip().upper()

    # Exakter Match
    if genre_title == code_to_check:
        return True

    # Startet mit Code, gefolgt von einem Nicht-Buchstaben ("DE ", "DE-", "DE/")
    if genre_title.startswith(code_to_check) and len(genre_title) > len(code_to_check):
        next_char = genre_title[len(code_to_check)]
        return not next_char.isalpha()

    return False


def _adult_filter_enabled():
    """
    Liest das Setting 'Erwachsenenbereich' aus addon-settings.xml.
    Nur wenn der User es explizit auf 'true' gesetzt hat wird gefiltert.
    Default ist immer false (keine Filterung).
    """
    try:
        val = addon.getSetting('Erwachsenenbereich')
        return val == 'true'
    except Exception:
        return False


def _is_adult_title(title):
    """
    Erkennung von Erwachsenen-Genres anhand des Titels / Namens.
    Beispiele: 'XXX', 'Adult Erotik', 'Erotik TV', 'Porn HD', '18+' etc.
    """
    if not title:
        return False

    t = str(title).strip().upper()

    adult_keywords = (
        'XXX',
        'ADULT',
        'EROTIK',
        'EROTIC',
        'PORN',
        '18+',
    )

    return any(kw in t for kw in adult_keywords)


def _list_content_by_country(content_type):
    """Premium Media – Ländergruppen DE/AT/CH (plus Zusatzcodes aus Settings)
    als eine komplette Liste anzeigen.
    content_type: 'tv', 'vod', 'series'
    Die Funktion orientiert sich an den bestehenden *genre*-Funktionen des Addons,
    filtert deren Ergebnis nach Ländercodes im Titel und blendet Adult-Gruppen aus.
    """
    try:
        if content_type == 'tv':
            data = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], addondir)
            key = 'genres'
            mode = 'channels'
            icon = icon1
        elif content_type == 'vod':
            data = load_channels.getVoDgenres(portal['mac'], portal['url'], portal['serial'], addondir)
            key = 'vodgenres'
            mode = 'vod'
            icon = icon2
        elif content_type == 'series':
            data = load_channels.getSergenres(portal['mac'], portal['url'], portal['serial'], addondir)
            key = 'sergenres'
            mode = 'seriescat'
            icon = icon3
        else:
            return
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    genres = data.get(key, {})

    enabled, allowed_codes, allow_unknown = get_country_groups_config()
    if not enabled:
        xbmcgui.Dialog().notification(addonname, 'Ländergruppen-Filter ist deaktiviert', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Über alle Genres iterieren und nur solche anzeigen, die mit einem erlaubten Country-Code beginnen
    for gid, item in list(genres.items()):
        title = item.get('title', '')
        title_upper = title.strip().upper()

        # Adult-Gruppen auch hier ausblenden
        if _adult_filter_enabled() and _is_adult_title(title):
            continue

        found_code = None
        for code in allowed_codes:
            if _check_country_prefix_match(title_upper, code):
                found_code = code
                break

        if not found_code and not allow_unknown:
            continue  # weder erlaubter Code noch Unknown erlaubt

        # URL analog zu den bestehenden Genre-Funktionen aufbauen
        if content_type in ('vod', 'series'):
            cat = item.get('cat')
            url = build_url({
                'mode': mode,
                'genre_name': title.title(),
                'cat': cat,
                'portal': json.dumps(portal)
            })
        else:
            url = build_url({
                'mode': mode,
                'genre_id': gid,
                'genre_name': title.title(),
                'portal': json.dumps(portal)
            })

        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon': icon, 'fanart': icon})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def TopStreamDeluxeTV():
    _list_content_by_country('tv')


def TopStreamDeluxeVOD():
    _list_content_by_country('vod')


def TopStreamDeluxeSeries():
    _list_content_by_country('series')


if mode is None:
    homeLevel()

elif mode[0] == 'cacheoptions':
    CacheLevel()

elif mode[0] == 'downcache':
    getCache()

elif mode[0] == 'cache':
    ClearLevel()

elif mode[0] == 'sel':
    SelectLevel()

elif mode[0] == 'genres':
    genreLevel()

elif mode[0] == 'vodgen':
    vodgenreLevel()

elif mode[0] == 'vod':
    vodLevel()

elif mode[0] == 'channels':
    channelLevel()

elif mode[0] == 'play':
    playLevel()

elif mode[0] == 'playvod':
    playStreamLevel()

elif mode[0] == 'check':
    checkcmd()

elif mode[0] == 'sergen':
    SeriesGenre()

elif mode[0] == 'seriescat':
    SeriesLevel()

elif mode[0] == 'season':
    SeasonLevel()

elif mode[0] == 'episode':
    EpisodeLevel()

elif mode[0] == 'epiplay':
    PlayEpisode()

elif mode[0] == 'top_tv':
    TopStreamDeluxeTV()

elif mode[0] == 'top_vod':
    TopStreamDeluxeVOD()

elif mode[0] == 'top_series':
    TopStreamDeluxeSeries()

elif mode[0] == 'play_zap':
    playZapLevel()

elif mode[0] == 'nav_group':
    navGroupLevel()


elif mode[0] == 'open_channels':
    # Öffnet die Senderliste der Gruppe im Hauptfenster (aus der Videowiedergabeliste heraus)
    _genre_id   = args.get('genre_id',   [''])[0]
    _genre_name = args.get('genre_name', [''])[0]
    _ch_url = build_url({
        'mode':       'channels',
        'genre_id':   _genre_id,
        'genre_name': _genre_name,
        'portal':     json.dumps(portal),
    })
    xbmc.Player().stop()
    xbmc.sleep(300)
    xbmc.executebuiltin('ActivateWindow(Videos,{},return)'.format(_ch_url))
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

elif mode[0] == 'settings':
    # Einstellungen öffnen
    addon.openSettings()