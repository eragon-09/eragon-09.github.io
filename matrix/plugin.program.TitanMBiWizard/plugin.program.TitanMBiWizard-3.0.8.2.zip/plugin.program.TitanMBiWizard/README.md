# plugin.program.TitanMBiWizard
Titan MBi Wizard for Kodi

THX Slam, Sarge, Funsterbe, BYB ;)
