# -*- coding: utf-8 -*-
"""Live TV menu view."""
from .runtime import get
from utils import strings


def show():
    xbmcplugin = get("xbmcplugin")
    handle = get("HANDLE")
    api = get("api")
    get_active_countries = get("get_active_countries")
    live_status = get("_live_tv_status")
    make_item = get("_make_menu_item")
    build_url = get("build_url")

    xbmcplugin.setContent(handle, "files")
    all_countries = api.get_available_countries()
    selected = get_active_countries(all_countries)
    countries_str = ",".join(selected)
    _, status_text, attention = live_status()

    items = [
        (strings.LIVE_FAVORITES, "live_favorites", True, status_text),
        (strings.LIVE_AZ, "live_az", True, strings.PLOT_LIVE_AZ),
        (strings.LIVE_GENRES, "live_genres", True, strings.PLOT_LIVE_GENRES),
        (strings.LIVE_COUNTRIES, "live_countries", True, strings.PLOT_LIVE_COUNTRIES),
        (strings.LIVE_MANAGE_FAVORITES, "favorites_manager", True, strings.PLOT_LIVE_MANAGE),
        (strings.LIVE_MANAGE_SOURCES, "favorites_source_manager", False, strings.PLOT_LIVE_SOURCES),
        (strings.LIVE_HELP, "favorites_help", False, strings.PLOT_LIVE_HELP),
    ]
    if attention:
        items.insert(1, (
            status_text,
            "grp_sync_all_defects",
            False,
            strings.PLOT_LIVE_ATTENTION,
        ))

    icons = {
        "live_favorites": "meine_favoriten.png",
        "live_az": "live_a_bis_z.png",
        "live_genres": "live_genres.png",
        "live_countries": "laender.png",
        "favorites_manager": "favoriten_verwalten.png",
        "favorites_source_manager": "quellen_verwalten.png",
        "favorites_help": "hilfe.png",
        "grp_sync_all_defects": "favoriten_verwalten.png",
    }
    for label, action, is_folder, plot in items:
        li = make_item(label, icons[action], plot)
        kwargs = {"action": action}
        if action in ("live_favorites", "live_az", "live_genres", "live_countries"):
            kwargs["countries"] = countries_str
        xbmcplugin.addDirectoryItem(handle, build_url(**kwargs), li, is_folder)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
