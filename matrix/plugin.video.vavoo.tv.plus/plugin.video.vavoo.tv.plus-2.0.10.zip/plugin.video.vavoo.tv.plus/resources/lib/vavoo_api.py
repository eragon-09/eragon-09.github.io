# -*- coding: utf-8 -*-
"""
vavoo_api.py
"""

import json
import os
import re
import uuid
import time
import threading
import xbmc
import xbmcaddon
import xbmcvfs

from vavoo.client import get_session as _get_session, decode_response as _decode

ADDON = xbmcaddon.Addon()

# Öffentliche Kompatibilitäts-Map für addon.py.
CHANNEL_EPG_MAP = {}

from vavoo.cache import cache_set, cache_get, cache_del

# ---------------------------------------------------------------------------
# API-Endpunkte
# ---------------------------------------------------------------------------
AUTH_URL = "https://vavoo.tv/api/app/ping"
INDEX_URL   = "https://geil.to/live/catalog/live/channels.json"
CATALOG_URL = "https://geil.to/live/catalog/live/channels.json"
RESOLVE_URL = "https://vavoo.to/mediahubmx-resolve.json"
SOURCE_URL  = "https://vavoo.to/mediahubmx-source.json"   # VoD + Serien
CCAPI_URL   = "https://vavoo.to/ccapi/"                    # VoD-Metadaten

CATALOG_ID        = "vto-iptv"
CLIENT_VERSION    = "3.1.4"
CATALOG_USER_AGENT = "MediaHubMX/2"

# Android Lokke-App-Token – kann über externe Config-URL überschrieben werden
_APP_TOKEN_BUILTIN = (
    "ldCvE092e7gER0rVIajfsXIvRhwlrAzP6_1oEJ4q6HH89QHt24v6NNL_jQJO219hi"
    "LOXIjF2hqEfsUuEWitEIGN4EaHHEHb7Cd7gojc5SQYRFzU3XWo_kMeryAUbcwWnQr"
    "nf0-"
)
CONFIG_URL = "https://raw.githubusercontent.com/vavoo-kodi/config/main/config.json"
_CONFIG_CACHE_FILE = ""

def _load_app_token():
    """Lädt APP_TOKEN: erst aus externem Config-Cache (24h), dann Builtin-Fallback."""
    global _CONFIG_CACHE_FILE
    if not _CONFIG_CACHE_FILE:
        try:
            profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
            _CONFIG_CACHE_FILE = os.path.join(profile, "cache", "remote_config.json")
        except Exception:
            return _APP_TOKEN_BUILTIN
    try:
        if os.path.exists(_CONFIG_CACHE_FILE):
            if (time.time() - os.path.getmtime(_CONFIG_CACHE_FILE)) < 86400:
                with open(_CONFIG_CACHE_FILE, encoding="utf-8") as _f:
                    _cfg = json.load(_f)
                _token = _cfg.get("app_token", "")
                if _token:
                    return _token
    except Exception:
        pass
    return _APP_TOKEN_BUILTIN

def get_app_token():
    return _load_app_token()

def refresh_remote_config():
    """Holt externe Config (Token etc.) und speichert sie im Cache (24h)."""
    global _CONFIG_CACHE_FILE
    try:
        r = _get_session().get(CONFIG_URL, timeout=8)
        if r.status_code == 200:
            cfg = r.json()
            if not _CONFIG_CACHE_FILE:
                profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
                _CONFIG_CACHE_FILE = os.path.join(profile, "cache", "remote_config.json")
            os.makedirs(os.path.dirname(_CONFIG_CACHE_FILE), exist_ok=True)
            with open(_CONFIG_CACHE_FILE, "w", encoding="utf-8") as _f:
                json.dump(cfg, _f)
            log("Remote-Config aktualisiert", xbmc.LOGINFO)
            return cfg
    except Exception as e:
        log(f"Remote-Config nicht erreichbar: {e}", xbmc.LOGDEBUG)
    return {}

# ---------------------------------------------------------------------------
# Länderkürzel-Map
# ---------------------------------------------------------------------------
COUNTRY_CODE_MAP = {
    "AL": "Albania",   "AT": "Austria",       "BA": "Bosnia",
    "BE": "Belgium",   "BG": "Bulgaria",      "CH": "Switzerland",
    "CR": "Croatia",   "CZ": "Czech Republic","DE": "Germany",
    "DK": "Denmark",   "ES": "Spain",         "FI": "Finland",
    "FR": "France",    "GB": "United Kingdom","GR": "Greece",
    "HR": "Croatia",   "HU": "Hungary",       "IT": "Italy",
    "MK": "Macedonia", "NL": "Netherlands",   "NO": "Norway",
    "PL": "Poland",    "PT": "Portugal",      "RO": "Romania",
    "RS": "Serbia",    "RU": "Russia",        "SE": "Sweden",
    "SI": "Slovenia",  "SK": "Slovakia",      "TR": "Turkey",
    "UA": "Ukraine",   "US": "USA",
}
COUNTRY_NAME_TO_CODE = {v: k for k, v in COUNTRY_CODE_MAP.items()}

def code_to_country(code):
    return COUNTRY_CODE_MAP.get(code.strip().upper(), code.strip())

def country_to_code(name):
    return COUNTRY_NAME_TO_CODE.get(name, "")

def parse_country_codes(setting_str):
    if not setting_str or not setting_str.strip():
        return []
    result = []
    for part in setting_str.split(","):
        part = part.strip()
        if not part:
            continue
        result.append(COUNTRY_CODE_MAP.get(part.upper(), part))
    return result


# ---------------------------------------------------------------------------
# Genre-Klassifizierung
# ---------------------------------------------------------------------------
GENRE_RULES = [
    # 1. Private
    ("Private", [
        "rtl", "sat.1", "sat1", "pro7", "prosieben", "vox", "kabel eins", "kabeleins",
        "rtl2", "rtl zwei", "sixx", "sat.1 gold", "sat1 gold", "prosieben maxx",
        "nitro", "rtlup", "rtl up", "voxup", "vox up", "superrtl", "super rtl",
        "tele 5", "tele5", "dmax", "romance tv", "heimatkanal", "comedy central",
        "tnt", "warner", "axn", "syfy", "13th street", "universal tv",
        "canale 5", "italia 1", "rete 4", "la7", "tv8", "nove", "real time",
        "tf1", "m6", "tmc", "tfx", "w9", "c8", "cstar", "6ter", "nrj12",
        "itv", "channel 4", "channel 5", "e4", "more4", "dave", "w tv",
        "antena 3", "telecinco", "cuatro", "la sexta", "neox", "nova",
        "rtl 4", "rtl 5", "rtl 7", "rtl 8", "sbs6", "net 5", "veronica",
        "atv", "puls 4", "puls4", "servus",
        "nova tv", "pink", "prva", "happy tv",
        "btv", "pro tv", "antena 1",
        "tvn", "polsat",
    ]),
    # 2. Oeffentlich-Rechtlich
    ("Oeffentlich-Rechtlich", [
        "das erste", "ard", "zdf", "zdfneo", "zdfinfo",
        "ndr", "wdr", "mdr", "swr", "rbb", "br fernsehen", "hr fernsehen", "sr fernsehen",
        "arte", "3sat", "one ", "ard alpha", "tagesschau", "kika",
        "orf 1", "orf 2", "orf 3", "orf sport",
        "srf 1", "srf 2", "srf info", "rts 1", "rts 2", "rsi",
        "npo 1", "npo 2", "npo 3",
        "rai 1", "rai 2", "rai 3", "rai news", "rai movie", "rai sport",
        "france 2", "france 3", "france 4", "france 5", "france info",
        "bbc one", "bbc two", "bbc three", "bbc four", "bbc news", "bbc alba", "cbbc", "cbeebies",
        "tve", "la 1", "la 2", "clan tv",
        "rtp 1", "rtp 2", "rtp 3", "rtp internacional",
        "tvp 1", "tvp 2", "tvp info", "tvp sport", "tvp world",
        "tvr 1", "tvr 2", "tvr international",
        "hrt 1", "hrt 2", "hrt 3",
        "rts 1", "rts 2", "rts 3",
        "trt 1", "trt 2", "trt haber", "trt cocuk", "trt belgesel", "trt world",
        "tvp", "yle", "nrk", "svt", "dr tv",
    ]),
    # 3. Film & Serien
    ("Film & Serien", [
        "cinema", "kino", "film", "movie", "movies", "cine",
        "sky cinema", "sky atlantic", "sky one", "sky showcase",
        "hbo", "showtime", "starz", "cinemax",
        "fox", "tnt film", "tnt serie", "tlc",
        "sixx", "nitro", "rtlup", "super rtl", "heimatkanal",
        "romance tv", "13th street", "universal tv",
        "film 4", "film4", "5star", "5 star",
        "giallo", "iris", "top crime", "mediaset extra",
        "cine", "serie", "serien",
    ]),
    # 4. Dokumentation
    ("Dokumentation", [
        "doku", "documentary", "dokumentation",
        "national geographic", "nat geo", "natgeo",
        "discovery", "animal planet", "curiosity",
        "history", "spiegel geschichte", "n24 doku",
        "sky documentaries", "sky nature", "sky crime",
        "hgtv", "travelxp", "wissen", "geo television",
        "focus", "arte doku", "rmc decouverte", "rmc decouvert",
        "yesterday", "alibi", "crime", "investigation",
        "bbc earth", "bbc select",
    ]),
    # 5. Kinder
    ("Kinder", [
        "kinder", "kids", "junior", "junior",
        "cartoon", "nickelodeon", "nick jr", "nickjr",
        "disney junior", "disney channel", "disney",
        "boomerang", "baby tv", "toggolino", "kika",
        "minimax", "gulli", "tfou", "cbbc", "cbeebies",
        "trt cocuk", "clan", "super rtl", "boing",
        "rai gulp", "rai yoyo",
    ]),
    # 6. Sport
    ("Sport", [
        "sport", "sports", "football", "fussball", "soccer",
        "bundesliga", "premier league", "serie a", "la liga",
        "champions", "formula", "f1", "moto", "motogp",
        "nfl", "nba", "mlb", "nhl", "tennis", "golf",
        "dazn", "eurosport", "bein sport", "sport1",
        "sportdigital", "olympic", "wrestling", "boxing",
        "ufc", "fight", "arena sport", "motorsport",
        "racing", "cycling", "handball", "basketball",
        "rugby", "cricket", "snooker", "red bull tv",
        "sky sport", "polsat sport", "tvp sport",
        "digi sport", "gol tv", "eleven sports",
        "sport klub", "arena sport",
    ]),
    # 7. News
    ("News", [
        "news", "nachrichten", "haber",
        "phoenix", "tagesschau", "welt", "n-tv", "ntv",
        "n24", "cnn", "bbc news", "al jazeera", "euronews",
        "bloomberg", "france 24", "dw", "zdfinfo",
        "sky news", "lci", "bfm", "cnews", "rtl info",
        "tgcom", "rai news", "antena 3 news",
        "realitatea", "digi 24", "tvn 24",
        "haberturk", "cnn turk", "ntv tr", "trt haber",
        "rtp noticias", "sic noticias", "tvi 24", "cmtv",
        "n1", "nova s", "24 sata",
    ]),
    # 8. Musik
    ("Musik", [
        "musik", "music", "mtv", "viva", "vh1",
        "mezzo", "trace", "clubbing", "dance",
        "hits", "charts", "rock", "jazz", "klasik",
        "nrj", "mcm", "m music", "tv5 music",
    ]),
    # 9. Shopping
    ("Shopping", [
        "shop", "shopping", "qvc", "hsn", "teleshopping",
        "jewelry", "jewellery", "channel 21", "channel21",
        "sonnenklar", "pearl tv", "1-2-3 tv", "123tv",
        "tv direktversand", "juwelo", "gemporia",
    ]),
]
GENRE_OTHER = "Sonstige"

def classify_channel_genre(name):
    nl = name.lower()
    for genre, keywords in GENRE_RULES:
        for kw in keywords:
            if kw in nl:
                return genre
    return GENRE_OTHER

def group_channels_by_genre(channels):
    result = {}
    for name, urls in channels.items():
        genre = classify_channel_genre(name)
        result.setdefault(genre, {})[name] = urls
    order = [g for g, _ in GENRE_RULES] + [GENRE_OTHER]
    return {g: result[g] for g in order if g in result}


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def log(msg, level=xbmc.LOGDEBUG):
    try:
        debug = ADDON.getSettingBool("debug")
    except Exception:
        debug = False
    if level == xbmc.LOGDEBUG and not debug:
        return
    xbmc.log(f"[plugin.video.vavoo.tv.plus] {msg}", level)


# ---------------------------------------------------------------------------
# Authentifizierung
# ---------------------------------------------------------------------------
_auth_cache = {"sig": None, "expires": 0, "last_error": ""}
AUTH_CACHE_TTL = 3600
_auth_lock = threading.Lock()


def get_auth_signature(force=False):
    """Holt die addonSig direkt von Vavoo und cached sie threadsicher.

    Normalfall: RAM -> Disk -> genau ein POST an ``AUTH_URL``. Parallele
    Aufrufer teilen sich dieselbe Aktualisierung (Single-Flight-Lock).
    """
    global _auth_cache

    now = time.time()
    if not force and _auth_cache["sig"] and now < _auth_cache["expires"]:
        return _auth_cache["sig"]

    with _auth_lock:
        now = time.time()
        if not force and _auth_cache["sig"] and now < _auth_cache["expires"]:
            return _auth_cache["sig"]

        if not force:
            ok, cached_sig = cache_get("auth_sig")
            if ok and cached_sig:
                _auth_cache["sig"] = cached_sig
                _auth_cache["expires"] = now + AUTH_CACHE_TTL
                log("addonSig aus Disk-Cache", xbmc.LOGINFO)
                return cached_sig

        now_ms = int(time.time() * 1000)
        data = {
            "reason": "app-focus",
            "locale": "de",
            "theme": "dark",
            "metadata": {
                "device": {"type": "desktop", "uniqueId": uuid.uuid4().hex[:16]},
                "os": {
                    "name": "win32", "version": "Windows 10 Pro",
                    "abis": ["x64"], "host": "Lenovo",
                },
                "app": {"platform": "electron"},
                "version": {
                    "package": "net.vypn.app", "binary": "3.1.0", "js": "3.1.0",
                },
            },
            "appFocusTime": 0,
            "playerActive": False,
            "playDuration": 0,
            "devMode": False,
            "hasAddon": True,
            "castConnected": False,
            "package": "net.vypn.app",
            "version": "3.1.0",
            "process": "app",
            "firstAppStart": now_ms - 86400000,
            "lastAppStart": now_ms,
            "ipLocation": None,
            "adblockEnabled": True,
            "proxy": {
                "supported": ["ss"], "engine": "Mu", "enabled": False,
                "autoServer": True,
            },
            "iap": {"supported": False},
        }
        headers = {
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                           "Chrome/124.0.0.0 Safari/537.36"),
            "Accept": "*/*",
            "Content-Type": "application/json; charset=utf-8",
        }

        try:
            log(f"Auth POST -> {AUTH_URL}", xbmc.LOGINFO)
            response = _get_session().post(AUTH_URL, json=data, headers=headers, timeout=(3, 8))
            log(f"Auth HTTP {response.status_code}", xbmc.LOGINFO)
            result = _decode(response)
            sig = (result.get("addonSig") or result.get("sig") or "") if isinstance(result, dict) else ""
            if not sig:
                _auth_cache["last_error"] = f"addonSig fehlt (HTTP {response.status_code})"
                log(f"Auth fehlgeschlagen: {_auth_cache['last_error']}", xbmc.LOGERROR)
                return None

            refreshed_at = time.time()
            _auth_cache["sig"] = sig
            _auth_cache["expires"] = refreshed_at + AUTH_CACHE_TTL
            _auth_cache["last_error"] = ""
            cache_set("auth_sig", sig, AUTH_CACHE_TTL)
            log(f"addonSig OK ({len(sig)} Zeichen)", xbmc.LOGINFO)
            return sig
        except Exception as exc:
            _auth_cache["last_error"] = str(exc)
            log(f"Vavoo-Authentifizierung fehlgeschlagen: {exc}", xbmc.LOGERROR)
            return None


def _api_headers(sig):
    """Header für Katalog-, Resolve- und Source-Anfragen."""
    return {
        "User-Agent": CATALOG_USER_AGENT,
        "Accept": "application/json",
        "Accept-Language": "de",
        "Content-Type": "application/json; charset=utf-8",
        "Accept-Encoding": "gzip",
        "mediahubmx-signature": sig,
    }


# ---------------------------------------------------------------------------
# Länder- und Senderkatalog (ausgelagert)
# ---------------------------------------------------------------------------
from vavoo import catalog as _catalog


# Live-TV JSON backend (www2.vavoo.to). VoD bleibt separat.
LIVE_JSON_URL = "https://www2.vavoo.to/live2/index?output=json"
_live_json_cache = {"items": None, "ts": 0}

def _live_items(force=False):
    now = time.time()
    if not force and _live_json_cache["items"] is not None and now - _live_json_cache["ts"] < 900:
        return _live_json_cache["items"]
    ok, disk = cache_get("www2_live_json")
    if not force and ok and isinstance(disk, list):
        _live_json_cache.update(items=disk, ts=now)
        return disk
    try:
        r = _get_session().get(LIVE_JSON_URL, headers={"User-Agent": "okhttp/4.11.0", "Accept": "application/json"}, timeout=(5, 25))
        r.raise_for_status()
        payload = r.json()
        if isinstance(payload, dict):
            payload = next((payload[k] for k in ("channels", "items", "data", "results") if isinstance(payload.get(k), list)), [])
        if not isinstance(payload, list):
            raise ValueError("JSON-Quelle liefert keine Senderliste")
        items = []
        for item in payload:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or item.get("title") or "").strip()
            url = str(item.get("url") or item.get("stream") or "").strip()
            country = str(item.get("country") or item.get("country_name") or item.get("countryName") or item.get("group") or item.get("group-title") or "Other").strip()
            if name and url and url.startswith(("http://", "https://")):
                items.append((country, name, url))
        if not items:
            raise ValueError("JSON-Quelle enthaelt keine gueltigen Streams")
        _live_json_cache.update(items=items, ts=now)
        cache_set("www2_live_json", items, 900)
        return items
    except Exception as exc:
        log("www2 Live JSON nicht erreichbar: %s" % exc, xbmc.LOGWARNING)
        if _live_json_cache["items"] is not None:
            return _live_json_cache["items"]
        if isinstance(disk, list) and disk:
            return disk
        raise

def get_available_countries(force=False):
    return sorted({entry[0] for entry in _live_items(force)}, key=str.casefold)

def _fetch_channels_page(sig, group, cursor=0):
    return {"items": [{"name": name, "url": url} for country, name, url in _live_items() if country == group], "nextCursor": None}

def _normalize_name(name):
    return name.strip()

def fetch_channels_for_group(group, force=False, strict_refresh=False):
    channels = {}
    for country, name, url in _live_items(force):
        if country == group:
            channels.setdefault(name, []).append(url)
    if strict_refresh and not channels:
        raise RuntimeError("Keine Sender fuer %s" % group)
    return channels


# ---------------------------------------------------------------------------
# Stream aufloesen
# ---------------------------------------------------------------------------

from vavoo import resolver as _resolver
from vavoo import streamtest as _streamtest


def check_stream(url, headers=None, timeout=8):
    return _streamtest.check_stream(
        url, headers=headers, timeout=timeout, session=_get_session(),
        user_agent=CATALOG_USER_AGENT, log=log, xbmc=xbmc,
    )


def validate_hls_stream(url, headers=None, timeout=8):
    return _streamtest.validate_hls_stream(
        url, headers=headers, timeout=timeout, session=_get_session(),
        user_agent=CATALOG_USER_AGENT, log=log, xbmc=xbmc,
    )


def resolve_stream(url, name="", tvg_id=""):
    """www2 JSON enthaelt direkte URLs; alte Favoriten per Sendernamen zuordnen."""
    from urllib.parse import urlsplit
    if not url or not urlsplit(url).scheme in ("http", "https"):
        return None, {}
    # Alte GEIL-/live/play-Adressen nicht an den alten Resolver senden.
    parsed = urlsplit(url)
    if parsed.hostname in ("geil.to", "www.geil.to") or parsed.path.startswith("/live/play/"):
        if not name:
            return None, {}
        target = name.casefold().strip()
        for country, channel, candidate in _live_items():
            if channel.casefold().strip() == target:
                return candidate, {}
        return None, {}
    return url, {}

def fetch_vod_list(vod_type="movie.popular", cursor=None):
    """
    Holt eine Liste von Filmen oder Serien.
    vod_type: "movie.popular", "movie.trending", "series.popular", "series.trending"
              oder "movie.genre=Action", "series.genre=Drama" etc.
    Gibt {"data": [...], "next": cursor_oder_None} zurück.
    """
    sig = get_auth_signature()
    if not sig:
        return {"data": [], "next": None}

    headers = {
        "user-agent":      "okhttp/4.11.0",
        "accept":          "application/json",
        "content-type":    "application/json; charset=utf-8",
        "accept-encoding": "gzip",
        "auth-token":      sig,
    }
    params = {"id": vod_type}
    if cursor:
        params["cursor"] = cursor

    try:
        r = _get_session().get(CCAPI_URL + "list", params=params, headers=headers, timeout=10)
        log(f"VoD list HTTP {r.status_code} type={vod_type}", xbmc.LOGINFO)
        result = _decode(r)
        return {
            "data": result.get("data", []) if isinstance(result, dict) else [],
            "next": result.get("next") if isinstance(result, dict) else None,
        }
    except Exception as e:
        log(f"fetch_vod_list FAILED: {e}", xbmc.LOGERROR)
        return {"data": [], "next": None}


def fetch_vod_meta(item_id):
    """
    Holt Metadaten für Film/Serie vom CCAPI info-Endpunkt.
    Gibt ein normalisiertes Dict zurück mit:
      seasons: Liste von {"season_number": int, "episode_count": int}
    """
    sig = get_auth_signature()
    if not sig:
        return {}

    headers = {
        "user-agent":      "okhttp/4.11.0",
        "accept":          "application/json",
        "content-type":    "application/json; charset=utf-8",
        "accept-encoding": "gzip",
        "auth-token":      sig,
    }
    try:
        r = _get_session().get(CCAPI_URL + "info", params={"id": item_id}, headers=headers, timeout=10)
        log(f"Meta HTTP {r.status_code} id={item_id}", xbmc.LOGINFO)
        raw = _decode(r)
        log(f"Meta raw FULL: {str(raw)[:1000]}", xbmc.LOGINFO)
        return _normalize_meta(raw)

    except Exception as e:
        log(f"fetch_vod_meta FAILED: {e}", xbmc.LOGERROR)
        return {}


def _normalize_meta(raw):
    """
    Normalisiert die CCAPI-Antwort.

    Tatsächliches API-Format:
      seasons = {
        "1": [{"id": "series.79744.1.1", "episode": 1, "name": "..."}, ...],
        "2": [...],
      }
    → Key = Staffelnummer, Value = Liste der Episoden-Objekte
    → episode_count = len(value)
    → Episoden-IDs direkt verfügbar
    """
    if not isinstance(raw, dict):
        return {}

    data = raw
    if "data" in raw and isinstance(raw["data"], dict):
        data = raw["data"]

    seasons_raw = data.get("seasons", {})
    log(f"seasons_raw type={type(seasons_raw).__name__} value={str(seasons_raw)[:300]}", xbmc.LOGINFO)

    seasons  = []
    episodes = {}  # {season_number: [episode_objects]}

    if isinstance(seasons_raw, dict):
        for key, val in seasons_raw.items():
            try:
                snum = int(key)
            except (ValueError, TypeError):
                continue

            if isinstance(val, list):
                ecount = len(val)
                # Episode-Objekte speichern für spätere direkte Nutzung
                episodes[snum] = val
            elif isinstance(val, int):
                ecount = val
            else:
                ecount = 0

            if ecount > 0:
                seasons.append({"season_number": snum, "episode_count": ecount})

        seasons.sort(key=lambda x: x["season_number"])

    elif isinstance(seasons_raw, list):
        for s in seasons_raw:
            if isinstance(s, dict):
                snum   = int(s.get("season_number", s.get("season", 0)))
                ecount = int(s.get("episode_count",
                               s.get("episodes",
                               s.get("sortepisode", 0))))
                if snum > 0 and ecount > 0:
                    seasons.append({"season_number": snum, "episode_count": ecount})

    # Fallback: sortepisode aus infos
    if not seasons:
        infos = data.get("infos", {})
        if isinstance(infos, dict):
            sortepisode = int(infos.get("sortepisode", 0))
            if sortepisode > 0:
                seasons = [{"season_number": 1, "episode_count": sortepisode}]

    log(f"Normalisierte Staffeln: {seasons}", xbmc.LOGINFO)
    data["seasons"]  = seasons
    data["episodes"] = episodes  # direkt verfügbare Episode-Objekte
    return data


# ---------------------------------------------------------------------------
# TMDB – Staffeln & Episoden
# ---------------------------------------------------------------------------

TMDB_API_KEY = "86dd18b04874d9c94afadde7993d94e3"
TMDB_BASE    = "https://api.themoviedb.org/3"
TMDB_POSTER  = "https://image.tmdb.org/t/p/w342"
TMDB_STILL   = "https://image.tmdb.org/t/p/w300"


def _tmdb_params(extra=None):
    p = {"api_key": TMDB_API_KEY, "language": "de-DE"}
    if extra:
        p.update(extra)
    return p


def fetch_tmdb_seasons(tmdb_id):
    """
    Holt Staffelliste von TMDB für eine Serie.
    Gibt Liste von {"season_number": int, "episode_count": int, "name": str, "poster": str} zurück.
    Staffel 0 (Specials) wird übersprungen.
    """
    cache_key = f"tmdb_seasons_{tmdb_id}"
    _cache = _auth_cache.get(cache_key)
    if _cache:
        return _cache

    try:
        url = f"{TMDB_BASE}/tv/{tmdb_id}"
        r   = _get_session().get(url, params=_tmdb_params({"append_to_response": ""}), timeout=10)
        log(f"TMDB TV HTTP {r.status_code} tmdb_id={tmdb_id}", xbmc.LOGINFO)
        data = r.json()

        seasons = []
        for s in data.get("seasons", []):
            snum = s.get("season_number", 0)
            if snum == 0:
                continue   # Specials überspringen
            seasons.append({
                "season_number": snum,
                "episode_count": s.get("episode_count", 0),
                "name":          s.get("name", f"Staffel {snum}"),
                "overview":      s.get("overview", ""),
                "air_date":      s.get("air_date", ""),
                "poster":        (TMDB_POSTER + s["poster_path"]) if s.get("poster_path") else "",
            })

        seasons.sort(key=lambda x: x["season_number"])
        _auth_cache[cache_key] = seasons
        return seasons

    except Exception as e:
        log(f"fetch_tmdb_seasons FAILED: {e}", xbmc.LOGERROR)
        return []


def fetch_tmdb_episodes(tmdb_id, season_number):
    """
    Holt alle Episoden einer Staffel von TMDB.
    Gibt Liste von Episode-Dicts zurück mit name, overview, still, episode_number, air_date.
    """
    cache_key = f"tmdb_eps_{tmdb_id}_s{season_number}"
    _cache = _auth_cache.get(cache_key)
    if _cache:
        return _cache

    try:
        url = f"{TMDB_BASE}/tv/{tmdb_id}/season/{season_number}"
        r   = _get_session().get(url, params=_tmdb_params(), timeout=10)
        log(f"TMDB Season HTTP {r.status_code} tmdb_id={tmdb_id} s={season_number}", xbmc.LOGINFO)
        data = r.json()

        episodes = []
        for ep in data.get("episodes", []):
            episodes.append({
                "episode_number": ep.get("episode_number", 0),
                "name":           ep.get("name", ""),
                "overview":       ep.get("overview", ""),
                "air_date":       ep.get("air_date", ""),
                "vote_average":   ep.get("vote_average", 0),
                "runtime":        ep.get("runtime", 0),
                "still":          (TMDB_STILL + ep["still_path"]) if ep.get("still_path") else "",
            })

        _auth_cache[cache_key] = episodes
        return episodes

    except Exception as e:
        log(f"fetch_tmdb_episodes FAILED: {e}", xbmc.LOGERROR)
        return []


def fetch_episode_count(item_id, season_number):
    """
    Fragt die Episodenanzahl einer bestimmten Staffel ab.
    Nutzt den CCAPI episodes-Endpunkt.
    Gibt die Anzahl zurück oder 0 bei Fehler.
    """
    sig = get_auth_signature()
    if not sig:
        return 0

    headers = {
        "user-agent":      "okhttp/4.11.0",
        "accept":          "application/json",
        "content-type":    "application/json; charset=utf-8",
        "accept-encoding": "gzip",
        "auth-token":      sig,
    }
    try:
        params = {"id": item_id, "season": season_number}
        r = _get_session().get(CCAPI_URL + "episodes", params=params,
                               headers=headers, timeout=10)
        log(f"Episodes HTTP {r.status_code} id={item_id} s={season_number}", xbmc.LOGINFO)
        result = _decode(r)

        # Mögliche Antwortformate
        if isinstance(result, list):
            count = len(result)
        elif isinstance(result, dict):
            data = result.get("data", result.get("episodes", result))
            if isinstance(data, list):
                count = len(data)
            elif isinstance(data, dict):
                count = len(data)
            else:
                count = int(data) if str(data).isdigit() else 0
        else:
            count = 0

        log(f"Episode count s{season_number}: {count}", xbmc.LOGINFO)
        return count

    except Exception as e:
        log(f"fetch_episode_count FAILED s{season_number}: {e}", xbmc.LOGWARNING)
        return 0


def _resolve_hoster_builtin(url):
    """
    Eingebauter Fallback für häufige Hoster wenn ResolveURL nicht verfügbar.
    Unterstützt: voe.sx, streamtape, dood.*, vidara.so, vidsonic.net, veev.to, luluvdo.com
    Gibt direkte Stream-URL zurück oder None.
    """
    from urllib.parse import urlparse as _up
    host = _up(url).netloc.lower()
    session = _get_session()
    headers_web = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "de-DE,de;q=0.9,en;q=0.8",
        "Referer": url,
    }

    try:
        # ── voe.sx ──────────────────────────────────────────────────────────
        if "voe.sx" in host or "voe." in host:
            r = session.get(url, headers=headers_web, timeout=10, allow_redirects=True)
            # Suche nach HLS-URL in JS
            m = re.search(r"'hls'\s*:\s*'(https?://[^']+\.m3u8[^']*)'", r.text)
            if not m:
                m = re.search(r'"hls"\s*:\s*"(https?://[^"]+\.m3u8[^"]*)"', r.text)
            if not m:
                m = re.search(r"(https?://[^\s\"'<>]+\.m3u8[^\s\"'<>]*)", r.text)
            if m:
                log(f"voe.sx builtin: {m.group(1)[:80]}", xbmc.LOGINFO)
                return m.group(1)

        # ── dood.* ──────────────────────────────────────────────────────────
        elif "dood" in host:
            r = session.get(url, headers=headers_web, timeout=10)
            # dood Pass-through: /pass_md5/...
            m = re.search(r"(/pass_md5/[^'\"]+)", r.text)
            if m:
                pass_url = "https://" + _up(url).netloc + m.group(1)
                r2 = session.get(pass_url, headers={**headers_web, "Referer": url}, timeout=10)
                # dood baut den stream aus: base_url + zufallsstring + timestamp
                rand_str = re.search(r"MD5\(['\"]([^'\"]{10,})['\"]", r.text)
                if not rand_str:
                    rand_str = re.search(r"['\"]([A-Za-z0-9]{10,})['\"]", r.text)
                if r2.ok and rand_str:
                    stream = r2.text.strip() + rand_str.group(1) + f"?token={rand_str.group(1)}&expiry={int(time.time() * 1000)}"
                    log(f"dood builtin: {stream[:80]}", xbmc.LOGINFO)
                    return stream

        # ── streamtape.com ──────────────────────────────────────────────────
        elif "streamtape" in host:
            r = session.get(url, headers=headers_web, timeout=10)
            m = re.search(r"(https?://[^\s\"'<>]*streamtape[^\s\"'<>]*\.mp4[^\s\"'<>]*)", r.text)
            if not m:
                # robotlink pattern
                m = re.search(r"robotlink.*?['\"]([^'\"]+)['\"]", r.text, re.DOTALL)
            if m:
                stream = m.group(1)
                if stream.startswith("//"):
                    stream = "https:" + stream
                log(f"streamtape builtin: {stream[:80]}", xbmc.LOGINFO)
                return stream

        # ── vidara.so / vidsonic.net / veev.to / luluvdo.com ────────────────
        elif any(h in host for h in ["vidara", "vidsonic", "veev", "luluvdo"]):
            # /api/stream gibt HTTP 405 – Player-Seite laden und Stream-URL extrahieren
            from urllib.parse import urlparse as _up2, parse_qs as _pqs
            _parsed  = _up2(url)
            _qs      = _pqs(_parsed.query)
            filecode = _qs.get("filecode", [""])[0] or _qs.get("id", [""])[0]
            if filecode:
                player_url = f"https://{host}/v/{filecode}"
            else:
                player_url = f"https://{host}/v/" + _parsed.path.split("/")[-1]
            log(f"{host}: lade Player-Seite {player_url[:80]}", xbmc.LOGDEBUG)
            r = session.get(player_url, headers=headers_web, timeout=12, allow_redirects=True)
            txt = r.text

            # 1. m3u8 in Anführungszeichen
            m = re.search(r'["\x27](https?://[^"\x27<>\s]+\.m3u8[^"\x27<>\s]*)["\x27]', txt)
            if not m:
                m = re.search(r"(https?://[^\s<>\"\x27]+\.m3u8[^\s<>\"\x27]*)", txt)
            if m:
                log(f"{host} builtin m3u8: {m.group(1)[:80]}", xbmc.LOGINFO)
                return m.group(1)

            # 2. JSON-Felder (jwplayer, plyr, videojs)
            m = re.search(r'"(?:file|src|source)"\s*:\s*"(https?://[^"]+\.(?:mp4|m3u8)[^"]*)"', txt)
            if m:
                log(f"{host} builtin json-src: {m.group(1)[:80]}", xbmc.LOGINFO)
                return m.group(1)

            # 3. /api/stream per POST mit Referer (manche Hoster akzeptieren das)
            if filecode:
                try:
                    api_url = f"https://{host}/api/stream"
                    rp = session.post(api_url,
                                      data={"filecode": filecode},
                                      headers={**headers_web, "Origin": f"https://{host}"},
                                      timeout=10, allow_redirects=True)
                    if rp.status_code < 400 and rp.url != api_url:
                        log(f"{host} POST-redirect: {rp.url[:80]}", xbmc.LOGINFO)
                        return rp.url
                    try:
                        j = rp.json()
                        stream = j.get("url") or j.get("src") or j.get("file")
                        if stream:
                            log(f"{host} POST-json: {stream[:80]}", xbmc.LOGINFO)
                            return stream
                    except Exception:
                        pass
                except Exception:
                    pass

            # 4. mp4 als letzter Fallback
            m = re.search(r'(?:file|src)[\s"\x27:=]+?(https?://[^\s"\x27<>]+\.mp4[^\s"\x27<>]*)', txt)
            if m:
                log(f"{host} builtin mp4: {m.group(1)[:80]}", xbmc.LOGINFO)
                return m.group(1)

    except Exception as e:
        log(f"_resolve_hoster_builtin ({host}): {e}", xbmc.LOGDEBUG)

    return None


def _resolve_mirror(mirror_url, sig):
    """
    Löst eine einzelne Mirror-URL auf — exakt wie resolve() in vjackson.py.
    Strategie:
      1. ResolveURL direkt versuchen
      2. Vavoo mediahubmx-resolve.json → dann nochmal ResolveURL
      3. Eingebaute Hoster-Extraktion (Fallback ohne ResolveURL)
    Gibt abspielbare URL zurück oder None.
    """
    # Schritt 1: ResolveURL direkt
    try:
        import resolveurl
        if resolveurl.HostedMediaFile(mirror_url).valid_url():
            resolved = resolveurl.resolve(mirror_url)
            if resolved:
                log(f"ResolveURL direkt: {resolved[:80]}", xbmc.LOGINFO)
                return resolved
    except Exception as e:
        log(f"ResolveURL nicht verfügbar: {e}", xbmc.LOGDEBUG)

    # Schritt 2: Vavoo-Resolve → dann ResolveURL
    try:
        headers = {
            "user-agent":      CATALOG_USER_AGENT,
            "content-type":    "application/json; charset=utf-8",
            "accept-encoding": "gzip",
            "mediahubmx-signature": sig,
        }
        data = {"language": "de", "region": "AT", "url": mirror_url, "clientVersion": CLIENT_VERSION}
        r = _get_session().post(RESOLVE_URL, json=data, headers=headers, timeout=10)
        # Bei 403: Signature erneuern und nochmal versuchen
        if r.status_code in (401, 403):
            log("VoD-Resolve 403 – erneuere Signature", xbmc.LOGWARNING)
            _auth_cache["sig"]     = None
            _auth_cache["expires"] = 0
            cache_del("auth_sig")
            sig = get_auth_signature(force=True)
            if sig:
                headers["mediahubmx-signature"] = sig
                r = _get_session().post(RESOLVE_URL, json=data, headers=headers, timeout=10)
        result = _decode(r)
        vavoo_url = ""
        if isinstance(result, dict):
            # API liefert {"url": "..."} direkt – "data"-Wrapper als Fallback
            vavoo_url = result.get("url", "") or result.get("data", {}).get("url", "")
        elif isinstance(result, list) and result:
            vavoo_url = result[0].get("url", "")

        if vavoo_url and vavoo_url != mirror_url:
            # Nochmal ResolveURL auf die aufgelöste URL
            try:
                import resolveurl
                resolved = resolveurl.resolve(vavoo_url)
                if resolved:
                    log(f"Vavoo+ResolveURL: {resolved[:80]}", xbmc.LOGINFO)
                    return resolved
            except Exception:
                pass
            # Eingebauten Hoster-Resolver auf die aufgelöste URL anwenden
            builtin = _resolve_hoster_builtin(vavoo_url)
            if builtin:
                return builtin
            # Direkte URL nur zurückgeben wenn sie KEIN bekannter Hoster-Endpunkt ist
            # (z.B. /api/stream gibt HTTP 405 → nicht direkt an Kodi übergeben)
            from urllib.parse import urlparse as _up_check
            _path = _up_check(vavoo_url).path.lower()
            _is_api_endpoint = any(x in _path for x in ["/api/stream", "/api/", "/embed/", "/e/"])
            if _is_api_endpoint:
                log(f"Vavoo-URL ist Hoster-Endpunkt, überspringe direkte Übergabe: {vavoo_url[:80]}", xbmc.LOGWARNING)
            else:
                log(f"Vavoo-Resolve direkt: {vavoo_url[:80]}", xbmc.LOGINFO)
                return vavoo_url

    except Exception as e:
        log(f"Vavoo-Resolve fehlgeschlagen: {e}", xbmc.LOGDEBUG)

    # Schritt 3: Eingebauter Hoster-Resolver
    builtin = _resolve_hoster_builtin(mirror_url)
    if builtin:
        return builtin

    # Schritt 4: CCAPI-Proxy-Fallback (wie callApi2("open") in vjackson.py)
    try:
        sig = get_auth_signature()
        if sig:
            proxy_headers = {
                "user-agent":      "okhttp/4.11.0",
                "accept":          "application/json",
                "content-type":    "application/json; charset=utf-8",
                "accept-encoding": "gzip",
                "auth-token":      sig,
            }
            r = _get_session().get(
                CCAPI_URL + "open",
                params={"link": mirror_url},
                headers=proxy_headers,
                timeout=10,
            )
            result = _decode(r)
            # callApi2 gibt Liste zurück, letzter Eintrag ist die finale URL
            if isinstance(result, list) and result:
                entry = result[-1]
                proxy_url = entry.get("url", "")
                proxy_hdrs = entry.get("headers", {})
                if proxy_url:
                    if proxy_hdrs:
                        hdr_str = "&".join(
                            f"{k}={v}" for k, v in proxy_hdrs.items()
                        )
                        proxy_url = f"{proxy_url}|{hdr_str}"
                    log(f"CCAPI-Proxy OK: {proxy_url[:80]}", xbmc.LOGINFO)
                    return proxy_url
            elif isinstance(result, dict):
                proxy_url = result.get("url", "")
                if proxy_url:
                    log(f"CCAPI-Proxy OK (dict): {proxy_url[:80]}", xbmc.LOGINFO)
                    return proxy_url
    except Exception as e:
        log(f"CCAPI-Proxy fehlgeschlagen: {e}", xbmc.LOGDEBUG)

    return None


def resolve_vod_stream(item_id, media_type="movie", tmdb_id=None,
                       season=None, episode=None, name=""):
    """
    Holt Stream-Mirrors für Film/Serie und löst die beste URL auf.
    Exakt wie get() in vjackson.py:
    - Source-API anfragen
    - Nach Sprache (de) filtern + nach Qualität gewichten
    - Jeden Mirror der Reihe nach durch _resolve_mirror() schicken
    - Ersten funktionierenden Stream zurückgeben
    """
    import random

    sig = get_auth_signature()
    if not sig:
        return None

    headers = {
        "user-agent":      CATALOG_USER_AGENT,
        "content-type":    "application/json; charset=utf-8",
        "accept-encoding": "gzip",
        "mediahubmx-signature": sig,
    }

    if season and episode:
        data = {
            "language": "de", "region": "AT", "type": "series",
            "ids":      {"tmdb_id": tmdb_id},
            "name":     name,
            "episode":  {"season": int(season), "episode": int(episode)},
            "clientVersion": CLIENT_VERSION,
        }
    else:
        data = {
            "language": "de", "region": "AT", "type": "movie",
            "ids":      {"tmdb_id": tmdb_id},
            "name":     name,
            "episode":  {},
            "clientVersion": CLIENT_VERSION,
        }

    try:
        r = _get_session().post(SOURCE_URL, json=data, headers=headers, timeout=15)
        log(f"Source HTTP {r.status_code}", xbmc.LOGINFO)
        mirrors_raw = _decode(r)
    except Exception as e:
        log(f"Source-Anfrage fehlgeschlagen: {e}", xbmc.LOGERROR)
        return None

    if not mirrors_raw or not isinstance(mirrors_raw, list):
        log("Keine Mirrors in Source-Antwort", xbmc.LOGWARNING)
        return None

    # Filtern + Gewichten (wie in vjackson.py get())
    ranked = []
    from urllib.parse import urlparse as _urlparse
    for m in mirrors_raw:
        if "de" not in m.get("languages", []):
            continue
        hoster = _urlparse(m.get("url", "")).netloc
        if "streamz" in hoster:
            continue
        quali = m.get("tag", "SD")
        if quali in ("1080p", "FHD"):
            weight = 1080 + random.randint(0, 9)
        elif quali in ("720p", "HD"):
            weight = 720 + random.randint(0, 9)
        else:
            weight = random.randint(0, 9)
        ranked.append({"url": m["url"], "hoster": hoster, "weight": weight})

    if not ranked:
        log("Keine deutschen Mirrors gefunden", xbmc.LOGWARNING)
        return None

    ranked.sort(key=lambda x: x["weight"], reverse=True)
    log(f"{len(ranked)} Mirrors gefunden: {[m['hoster'] for m in ranked]}", xbmc.LOGINFO)

    # Jeden Mirror der Reihe nach versuchen
    for mirror in ranked:
        log(f"Versuche Mirror: {mirror['hoster']}", xbmc.LOGINFO)
        resolved = _resolve_mirror(mirror["url"], sig)
        if resolved:
            # Stream-Check: sicherstellen dass die URL wirklich Video liefert
            try:
                stream_check = ADDON.getSettingBool("stream_check")
            except Exception:
                stream_check = False
            if stream_check:
                if check_stream(resolved):
                    return resolved
                log(f"Stream-Check fehlgeschlagen für {mirror['hoster']}, nächster Mirror", xbmc.LOGWARNING)
            else:
                return resolved

    log("Alle Mirrors fehlgeschlagen", xbmc.LOGWARNING)
    return None


# ---------------------------------------------------------------------------
# Logo-Datenbank
# ---------------------------------------------------------------------------

# Basis-URL für TV-Logos (community repository)
_LOGO_BASE = "https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries"

# Online-Logo-Index
_LOGO_INDEX_FILE      = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "logo_index.json")
_LOGO_INDEX_META_FILE = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "logo_index_meta.json")
_LOGO_INDEX_TTL       = 7 * 24 * 3600
_ONLINE_LOGO_REPO_API = "https://api.github.com/repos/tv-logo/tv-logos/git/trees/main?recursive=1"
_ONLINE_LOGO_REPO_HTML = "https://github.com/tv-logo/tv-logos/tree/main/{path}"
_ONLINE_LOGO_RAW      = "https://raw.githubusercontent.com/tv-logo/tv-logos/main/{path}"
_ONLINE_LOGO_ALLOWED_PREFIXES = (
    "countries/germany/",
    "countries/germany/hd/",
    "countries/germany/sky-sport/",
    "countries/austria/",
    "countries/austria/hd/",
    "countries/switzerland/",
)
_ONLINE_LOGO_HTML_PATHS = [
    "countries/germany",
    "countries/germany/hd",
    "countries/germany/sky-sport",
    "countries/austria",
    "countries/austria/hd",
    "countries/switzerland",
]
_logo_index_mem = None

# Mapping: normalisierter Kanalname → Logo-Pfad relativ zu _LOGO_BASE
CHANNEL_LOGO_MAP = {

    # -----------------------------------------------------------------------
    # Deutschland – Öffentlich-Rechtlich
    # -----------------------------------------------------------------------
    "daserrste":              "germany/das-erste-de.png",
    "daserstehd":             "germany/hd/das-erste-hd-de.png",
    "ard":                    "germany/das-erste-de.png",
    "ardhd":                  "germany/hd/das-erste-hd-de.png",
    "zdf":                    "germany/zdf-de.png",
    "zdfhd":                  "germany/hd/zdf-hd-de.png",
    "zdfneo":                 "germany/zdfneo-de.png",
    "zdfinfo":                "germany/zdfinfo-de.png",
    "arte":                   "germany/arte-de.png",
    "artehd":                 "germany/arte-de.png",
    "3sat":                   "germany/3sat-de.png",
    "phoenix":                "germany/phoenix-de.png",
    "one":                    "germany/one-de.png",
    "ardalpha":               "germany/ard-alpha-de.png",
    "tagesschau24":           "germany/tagesschau24-de.png",
    "kika":                   "germany/kika-de.png",
    "wdr":                    "germany/wdr-de.png",
    "ndr":                    "germany/ndr-de.png",
    "mdr":                    "germany/mdr-de.png",
    "swr":                    "germany/swr-de.png",
    "rbb":                    "germany/rbb-de.png",
    "br":                     "germany/br-de.png",
    "hr":                     "germany/hr-de.png",
    "sr":                     "germany/sr-de.png",
    # Deutschland – Private
    "rtl":                    "germany/rtl-de.png",
    "rtlhd":                  "germany/hd/rtl-hd-de.png",
    "sat1":                   "germany/sat-1-de.png",
    "sat1hd":                 "germany/hd/sat-1-hd-de.png",
    "prosieben":              "germany/prosieben-de.png",
    "prosiebenmaxx":          "germany/prosieben-maxx-de.png",
    "prosiebenmaxxhd":        "germany/hd/prosieben-maxx-hd-de.png",
    "kabeleins":              "germany/kabel-eins-de.png",
    "kabeleinsklassics":      "germany/kabel-eins-classics-de.png",
    "kabeleinsdoku":          "germany/kabel-eins-doku-de.png",
    "rtlzwei":                "germany/rtl-zwei-de.png",
    "rtl2":                   "germany/rtl-zwei-de.png",
    "vox":                    "germany/vox-de.png",
    "voxup":                  "germany/voxup-de.png",
    "superrtl":               "germany/super-rtl-de.png",
    "nitro":                  "germany/nitro-de.png",
    "rtlup":                  "germany/rtlup-de.png",
    "rtlcrime":               "germany/rtl-crime-de.png",
    "rtlpassion":             "germany/rtl-passion-de.png",
    "sat1gold":               "germany/sat-1-gold-de.png",
    "sat1emotions":           "germany/sat-1-emotions-de.png",
    "sixx":                   "germany/sixx-de.png",
    "dmax":                   "germany/dmax-de.png",
    "tele5":                  "germany/tele-5-de.png",
    "ntv":                    "germany/n-tv-de.png",
    "ntvhd":                  "germany/n-tv-de.png",
    "welt":                   "germany/welt-de.png",
    "welthd":                 "germany/welt-de.png",
    "n24doku":                "germany/n24-doku-de.png",
    "sport1":                 "germany/sport1-de.png",
    "sport1hd":               "germany/sport1-de.png",
    "heimatkanal":            "germany/heimatkanal-de.png",
    "romancetv":              "germany/romance-tv-de.png",
    "tntfilm":                "germany/tnt-film-de.png",
    "tntserie":               "germany/tnt-serie-de.png",
    "comedycentral":          "germany/comedy-central-de.png",
    "tlc":                    "germany/tlc-de.png",
    # Sky Deutschland
    "skyone":                 "germany/sky-one-de.png",
    "skyatlantic":            "germany/sky-atlantic-de.png",
    "skycrimehd":             "germany/hd/sky-crime-hd-de.png",
    "skydocumentarieshd":     "germany/hd/sky-documentaries-hd-de.png",
    "skynaturehd":            "germany/hd/sky-nature-hd-de.png",
    "skykrimi":               "germany/sky-krimi-de.png",
    "skyreplay":              "germany/sky-replay-de.png",
    "skyshowcase":            "germany/sky-showcase-de.png",
    "skycinemaaction":        "germany/sky-cinema-action-de.png",
    "skycinemaclassics":      "germany/sky-cinema-classics-de.png",
    "skycinemafamily":        "germany/sky-cinema-family-de.png",
    "skycinemahighlights":    "germany/sky-cinema-highlights-de.png",
    "skycinemapremieren":     "germany/sky-cinema-premieren-de.png",
    "skysportnews":           "germany/sky-sport-news-de.png",
    "skysportbundesliga1":    "germany/hd/sky-sport-bundesliga-1-hd-de.png",
    "skysportbundesliga2":    "germany/hd/sky-sport-bundesliga-2-hd-de.png",
    "skysport1":              "germany/hd/sky-sport-1-hd-de.png",
    "skysport2":              "germany/hd/sky-sport-2-hd-de.png",
    # Sport DE
    "eurosport1":             "germany/eurosport-1-de.png",
    "eurosport1hd":           "germany/hd/eurosport-1-hd-de.png",
    "eurosport2":             "germany/eurosport-2-de.png",
    "eurosport2hd":           "germany/hd/eurosport-2-hd-de.png",
    "dazn1":                  "germany/dazn-1-de.png",
    "dazn2":                  "germany/dazn-2-de.png",
    "sportdigitalfussball":   "germany/sportdigital-fussball-de.png",
    # Doku DE
    "history":                "germany/history-de.png",
    "historyhd":              "germany/hd/history-hd-de.png",
    "nationalgeographic":     "germany/national-geographic-de.png",
    "natgeowild":             "germany/nat-geo-wild-de.png",
    "discoverychannel":       "germany/discovery-channel-de.png",
    "discovery":              "germany/discovery-channel-de.png",
    "animalplanet":           "germany/animal-planet-de.png",
    "geotelevision":          "germany/geo-television-de.png",
    "spiegelgeschichte":      "germany/spiegel-geschichte-de.png",
    "curiositychannel":       "germany/curiosity-channel-de.png",
    "hgtv":                   "germany/hgtv-de.png",
    # Kinder DE
    "nickelodeon":            "germany/nickelodeon-de.png",
    "cartoonnetwork":         "germany/cartoon-network-de.png",
    "disney":                 "germany/disney-channel-de.png",
    "disneychannel":          "germany/disney-channel-de.png",
    "disneyjunior":           "germany/disney-junior-de.png",
    # Musik DE
    "mtv":                    "germany/mtv-de.png",
    "viva":                   "germany/viva-de.png",
    # Warner / Universal DE
    "warnertvfilm":           "germany/warner-tv-film-de.png",
    "warnertvserie":          "germany/warner-tv-serie-de.png",
    "warnertvcomedy":         "germany/warner-tv-comedy-de.png",
    "universaltv":            "germany/universal-tv-de.png",
    "syfy":                   "germany/syfy-de.png",
    "13thstreet":             "germany/13th-street-de.png",

    # -----------------------------------------------------------------------
    # Österreich
    # -----------------------------------------------------------------------
    "orf1":                   "austria/orf-1-at.png",
    "orf2":                   "austria/orf-2-at.png",
    "orf3":                   "austria/orf-3-at.png",
    "orfsport":               "austria/orf-sport-plus-at.png",
    "orfsportplus":           "austria/orf-sport-plus-at.png",
    "servustv":               "austria/servus-tv-at.png",
    "puls4":                  "austria/puls-4-at.png",
    "puls24":                 "austria/puls-24-at.png",
    "atv":                    "austria/atv-at.png",
    "atv2":                   "austria/atv-2-at.png",

    # -----------------------------------------------------------------------
    # Schweiz
    # -----------------------------------------------------------------------
    "srf1":                   "switzerland/srf-1-ch.png",
    "srf2":                   "switzerland/srf-2-ch.png",
    "srfinfo":                "switzerland/srf-info-ch.png",
    "srftwo":                 "switzerland/srf-two-ch.png",
    "rts1":                   "switzerland/rts-1-ch.png",
    "rts2":                   "switzerland/rts-2-ch.png",
    "3plus":                  "switzerland/3plus-ch.png",
    "4plus":                  "switzerland/4plus-ch.png",
    "5plus":                  "switzerland/5plus-ch.png",
    "tv24":                   "switzerland/tv24-ch.png",
    "tv25":                   "switzerland/tv25-ch.png",

    # -----------------------------------------------------------------------
    # Niederlande
    # -----------------------------------------------------------------------
    "npo1":                   "netherlands/npo-1-nl.png",
    "npo2":                   "netherlands/npo-2-nl.png",
    "npo3":                   "netherlands/npo-3-nl.png",
    "rtl4":                   "netherlands/rtl-4-nl.png",
    "rtl5":                   "netherlands/rtl-5-nl.png",
    "rtl7":                   "netherlands/rtl-7-nl.png",
    "rtl8":                   "netherlands/rtl-8-nl.png",
    "sbs6":                   "netherlands/sbs-6-nl.png",
    "net5":                   "netherlands/net-5-nl.png",
    "veronica":               "netherlands/veronica-nl.png",
    "veronicatv":             "netherlands/veronica-nl.png",
    "kroncrv":                "netherlands/kro-ncrv-nl.png",
    "bnnvara":                "netherlands/bnnvara-nl.png",
    "avrotros":               "netherlands/avrotros-nl.png",

    # -----------------------------------------------------------------------
    # Italien
    # -----------------------------------------------------------------------
    "rai1":                   "italy/rai-1-it.png",
    "rai2":                   "italy/rai-2-it.png",
    "rai3":                   "italy/rai-3-it.png",
    "raiuno":                 "italy/rai-1-it.png",
    "raidue":                 "italy/rai-2-it.png",
    "raitre":                 "italy/rai-3-it.png",
    "raimovie":               "italy/rai-movie-it.png",
    "raigulp":                "italy/rai-gulp-it.png",
    "raiyoyo":                "italy/rai-yoyo-it.png",
    "rainews24":              "italy/rai-news-24-it.png",
    "raisport":               "italy/rai-sport-it.png",
    "canale5":                "italy/canale-5-it.png",
    "italia1":                "italy/italia-1-it.png",
    "rete4":                  "italy/rete-4-it.png",
    "retequattro":            "italy/rete-4-it.png",
    "la7":                    "italy/la7-it.png",
    "la7d":                   "italy/la7d-it.png",
    "tv8":                    "italy/tv8-it.png",
    "nove":                   "italy/nove-it.png",
    "realtime":               "italy/real-time-it.png",
    "focus":                  "italy/focus-it.png",
    "iris":                   "italy/iris-it.png",
    "topcrime":               "italy/top-crime-it.png",
    "giallo":                 "italy/giallo-it.png",
    "tgcom24":                "italy/tgcom24-it.png",

    # -----------------------------------------------------------------------
    # Frankreich
    # -----------------------------------------------------------------------
    "tf1":                    "france/tf1-fr.png",
    "france2":                "france/france-2-fr.png",
    "france3":                "france/france-3-fr.png",
    "france4":                "france/france-4-fr.png",
    "france5":                "france/france-5-fr.png",
    "m6":                     "france/m6-fr.png",
    "c8":                     "france/c8-fr.png",
    "w9":                     "france/w9-fr.png",
    "tmc":                    "france/tmc-fr.png",
    "tfx":                    "france/tfx-fr.png",
    "lci":                    "france/lci-fr.png",
    "bfmtv":                  "france/bfm-tv-fr.png",
    "cnews":                  "france/cnews-fr.png",
    "cstar":                  "france/cstar-fr.png",
    "gulli":                  "france/gulli-fr.png",
    "6ter":                   "france/6ter-fr.png",
    "rmcstory":               "france/rmc-story-fr.png",
    "rmcdecouverte":          "france/rmc-decouverte-fr.png",
    "cherie25":               "france/cherie-25-fr.png",
    "nrj12":                  "france/nrj12-fr.png",
    "tv5monde":               "france/tv5monde-fr.png",

    # -----------------------------------------------------------------------
    # England / UK
    # -----------------------------------------------------------------------
    "bbcone":                 "united-kingdom/bbc-one-uk.png",
    "bbc1":                   "united-kingdom/bbc-one-uk.png",
    "bbctwo":                 "united-kingdom/bbc-two-uk.png",
    "bbc2":                   "united-kingdom/bbc-two-uk.png",
    "bbcthree":               "united-kingdom/bbc-three-uk.png",
    "bbc3":                   "united-kingdom/bbc-three-uk.png",
    "bbcfour":                "united-kingdom/bbc-four-uk.png",
    "bbc4":                   "united-kingdom/bbc-four-uk.png",
    "bbcnews":                "united-kingdom/bbc-news-uk.png",
    "bbcnewshd":              "united-kingdom/bbc-news-uk.png",
    "bbcalba":                "united-kingdom/bbc-alba-uk.png",
    "cbbc":                   "united-kingdom/cbbc-uk.png",
    "cbeebies":               "united-kingdom/cbeebies-uk.png",
    "itv":                    "united-kingdom/itv1-uk.png",
    "itv1":                   "united-kingdom/itv1-uk.png",
    "itv2":                   "united-kingdom/itv2-uk.png",
    "itv3":                   "united-kingdom/itv3-uk.png",
    "itv4":                   "united-kingdom/itv4-uk.png",
    "itvbe":                  "united-kingdom/itvbe-uk.png",
    "channel4":               "united-kingdom/channel-4-uk.png",
    "ch4":                    "united-kingdom/channel-4-uk.png",
    "channel5":               "united-kingdom/channel-5-uk.png",
    "ch5":                    "united-kingdom/channel-5-uk.png",
    "5usa":                   "united-kingdom/5usa-uk.png",
    "5star":                  "united-kingdom/5star-uk.png",
    "e4":                     "united-kingdom/e4-uk.png",
    "more4":                  "united-kingdom/more4-uk.png",
    "film4":                  "united-kingdom/film4-uk.png",
    "skyoneuk":               "united-kingdom/sky-one-uk.png",
    "skynews":                "united-kingdom/sky-news-uk.png",
    "skysportsnews":          "united-kingdom/sky-sports-news-uk.png",
    "skysports1":             "united-kingdom/sky-sports-1-uk.png",
    "skysports2":             "united-kingdom/sky-sports-2-uk.png",
    "dave":                   "united-kingdom/dave-uk.png",
    "alibi":                  "united-kingdom/alibi-uk.png",
    "yesterday":              "united-kingdom/yesterday-uk.png",

    # -----------------------------------------------------------------------
    # Spanien
    # -----------------------------------------------------------------------
    "tve1":                   "spain/tve-1-es.png",
    "la1":                    "spain/tve-1-es.png",
    "tve2":                   "spain/tve-2-es.png",
    "la2":                    "spain/tve-2-es.png",
    "antena3":                "spain/antena-3-es.png",
    "cuatro":                 "spain/cuatro-es.png",
    "telecinco":              "spain/telecinco-es.png",
    "lasexta":                "spain/la-sexta-es.png",
    "24h":                    "spain/24h-es.png",
    "clan":                   "spain/clan-es.png",
    "boing":                  "spain/boing-es.png",
    "trece":                  "spain/trece-es.png",
    "neox":                   "spain/neox-es.png",
    "nova":                   "spain/nova-es.png",
    "atreseries":             "spain/atreseries-es.png",
    "mega":                   "spain/mega-es.png",
    "gol":                    "spain/gol-es.png",

    # -----------------------------------------------------------------------
    # Portugal
    # -----------------------------------------------------------------------
    "rtp1":                   "portugal/rtp1-pt.png",
    "rtp2":                   "portugal/rtp2-pt.png",
    "rtp3":                   "portugal/rtp3-pt.png",
    "rtpinternacional":       "portugal/rtp-internacional-pt.png",
    "sic":                    "portugal/sic-pt.png",
    "sicnoticias":            "portugal/sic-noticias-pt.png",
    "sicradical":             "portugal/sic-radical-pt.png",
    "sicmulher":              "portugal/sic-mulher-pt.png",
    "tvi":                    "portugal/tvi-pt.png",
    "tvi24":                  "portugal/tvi24-pt.png",
    "cmtv":                   "portugal/cmtv-pt.png",

    # -----------------------------------------------------------------------
    # Polen
    # -----------------------------------------------------------------------
    "tvp1":                   "poland/tvp-1-pl.png",
    "tvp2":                   "poland/tvp-2-pl.png",
    "tvp3":                   "poland/tvp-3-pl.png",
    "tvpinfo":                "poland/tvp-info-pl.png",
    "tvpsport":               "poland/tvp-sport-pl.png",
    "tvpworld":               "poland/tvp-world-pl.png",
    "polsat":                 "poland/polsat-pl.png",
    "polsatplay":             "poland/polsat-play-pl.png",
    "polsatnews":             "poland/polsat-news-pl.png",
    "polsatfilm":             "poland/polsat-film-pl.png",
    "polsatsport":            "poland/polsat-sport-pl.png",
    "tvn":                    "poland/tvn-pl.png",
    "tvn7":                   "poland/tvn-7-pl.png",
    "tvn24":                  "poland/tvn24-pl.png",
    "tvnstyle":               "poland/tvn-style-pl.png",
    "tvnturbo":               "poland/tvn-turbo-pl.png",

    # -----------------------------------------------------------------------
    # Bulgarien
    # -----------------------------------------------------------------------
    "btv":                    "bulgaria/btv-bg.png",
    "btvcinema":              "bulgaria/btv-cinema-bg.png",
    "btvaction":              "bulgaria/btv-action-bg.png",
    "btvcomedy":              "bulgaria/btv-comedy-bg.png",
    "btvlady":                "bulgaria/btv-lady-bg.png",
    "novatv":                 "bulgaria/nova-bg.png",
    "diema":                  "bulgaria/diema-bg.png",
    "diemafamily":            "bulgaria/diema-family-bg.png",
    "kinonova":               "bulgaria/kino-nova-bg.png",

    # -----------------------------------------------------------------------
    # Rumänien
    # -----------------------------------------------------------------------
    "tvr1":                   "romania/tvr-1-ro.png",
    "tvr2":                   "romania/tvr-2-ro.png",
    "tvrinternational":       "romania/tvr-international-ro.png",
    "protv":                  "romania/pro-tv-ro.png",
    "antena1":                "romania/antena-1-ro.png",
    "antena3ro":              "romania/antena-3-ro.png",
    "primatv":                "romania/prima-tv-ro.png",
    "kanald":                 "romania/kanal-d-ro.png",
    "digi24":                 "romania/digi-24-ro.png",
    "digisport1":             "romania/digi-sport-1-ro.png",
    "digisport2":             "romania/digi-sport-2-ro.png",

    # -----------------------------------------------------------------------
    # Kroatien
    # -----------------------------------------------------------------------
    "hrt1":                   "croatia/hrt-1-hr.png",
    "hrt2":                   "croatia/hrt-2-hr.png",
    "hrt3":                   "croatia/hrt-3-hr.png",
    "hrt4":                   "croatia/hrt-4-hr.png",
    "novatvhr":               "croatia/nova-tv-hr.png",
    "rtlhr":                  "croatia/rtl-hr.png",
    "rtlkockica":             "croatia/rtl-kockica-hr.png",
    "sportklub1":             "croatia/sport-klub-1-hr.png",

    # -----------------------------------------------------------------------
    # Serbien / Bosnien
    # -----------------------------------------------------------------------
    "rts1":                   "serbia/rts-1-rs.png",
    "rts2":                   "serbia/rts-2-rs.png",
    "pink":                   "serbia/pink-rs.png",
    "happytv":                "serbia/happy-tv-rs.png",
    "prva":                   "serbia/prva-rs.png",
    "n1rs":                   "serbia/n1-rs.png",
    "federalna":              "bosnia-and-herzegovina/federalna-tv-ba.png",
    "rtrs":                   "bosnia-and-herzegovina/rtrs-ba.png",
    "hayat":                  "bosnia-and-herzegovina/hayat-ba.png",
    "pinkbih":                "bosnia-and-herzegovina/pink-bih-ba.png",

    # -----------------------------------------------------------------------
    # Türkei
    # -----------------------------------------------------------------------
    "trt1":                   "turkey/trt-1-tr.png",
    "trt2":                   "turkey/trt-2-tr.png",
    "trtworld":               "turkey/trt-world-tr.png",
    "trtbelgesel":            "turkey/trt-belgesel-tr.png",
    "trtcocuk":               "turkey/trt-cocuk-tr.png",
    "trthaber":               "turkey/trt-haber-tr.png",
    "atvtr":                  "turkey/atv-tr.png",
    "foxtr":                  "turkey/fox-tr.png",
    "showtv":                 "turkey/show-tv-tr.png",
    "kanaldtr":               "turkey/kanal-d-tr.png",
    "startv":                 "turkey/star-tv-tr.png",
    "cnnturk":                "turkey/cnn-turk-tr.png",
    "ntvtr":                  "turkey/ntv-tr.png",
    "haberturk":              "turkey/haberturk-tr.png",
    "tv8tr":                  "turkey/tv-8-tr.png",

    # -----------------------------------------------------------------------
    # International
    # -----------------------------------------------------------------------
    "cnninternational":       "united-kingdom/cnn-international-uk.png",
    "bbcworldnews":           "united-kingdom/bbc-world-news-uk.png",
    "euronews":               "france/euronews-fr.png",
    "aljazeera":              "united-kingdom/al-jazeera-english-uk.png",
    "dw":                     "germany/dw-de.png",
    "deutschewelle":          "germany/dw-de.png",
    "tv5monde":               "france/tv5monde-fr.png",
}

# EPG-ID Mapping: normalisierter Name → tvg-id
CHANNEL_EPG_MAP = {
    # xmltv.info IDs für deutsche Sender (Format: Name.de oder Name.land)
    "daserstehd":          "Das.Erste.de",
    "daserrste":           "Das.Erste.de",
    "ard":                 "Das.Erste.de",
    "zdf":                 "ZDF.de",
    "zdfhd":               "ZDF.de",
    "zdfneo":              "ZDFneo.de",
    "zdfinfo":             "ZDFinfo.de",
    "arte":                "Arte.de",
    "3sat":                "3sat.de",
    "phoenix":             "Phoenix.de",
    "one":                 "One.de",
    "ardalpha":            "ARD-alpha.de",
    "tagesschau24":        "tagesschau24.de",
    "kika":                "KiKA.de",
    "wdr":                 "WDR.de",
    "ndr":                 "NDR.de",
    "mdr":                 "MDR.de",
    "swr":                 "SWR.de",
    "rbb":                 "rbb.de",
    "br":                  "BR.de",
    "hr":                  "hr.de",
    "sr":                  "SR.de",
    # Private DE
    "rtl":                 "RTL.de",
    "rtlhd":               "RTL.de",
    "sat1":                "SAT.1.de",
    "sat1hd":              "SAT.1.de",
    "prosieben":           "ProSieben.de",
    "prosiebenmaxx":       "ProSieben.MAXX.de",
    "kabeleins":           "Kabel.Eins.de",
    "kabeleinsklassics":   "Kabel.Eins.Classics.de",
    "kabeleinsdoku":       "Kabel.Eins.Doku.de",
    "rtlzwei":             "RTL2.de",
    "vox":                 "VOX.de",
    "voxup":               "VOX.Up.de",
    "superrtl":            "Super.RTL.de",
    "nitro":               "NITRO.de",
    "rtlup":               "RTL.Up.de",
    "rtlcrime":            "RTL.Crime.de",
    "rtlpassion":          "RTL.Passion.de",
    "sat1gold":            "SAT.1.Gold.de",
    "sat1emotions":        "SAT.1.Emotions.de",
    "sixx":                "sixx.de",
    "dmax":                "DMAX.de",
    "tele5":               "Tele5.de",
    "ntv":                 "n-tv.de",
    "welt":                "WELT.de",
    "n24doku":             "N24.Doku.de",
    "sport1":              "Sport1.de",
    # Sky
    "skyone":              "Sky.One.de",
    "skyatlantic":         "Sky.Atlantic.de",
    "skykrimi":            "Sky.Krimi.de",
    "skyreplay":           "Sky.Replay.de",
    "skyshowcase":         "Sky.Showcase.de",
    "skysportnews":        "Sky.Sport.News.de",
    # Sport
    "eurosport1":          "Eurosport.1.de",
    "eurosport2":          "Eurosport.2.de",
    "sport1":              "Sport1.de",
    # Doku
    "history":             "History.de",
    "nationalgeographic":  "National.Geographic.de",
    "natgeowild":          "Nat.Geo.Wild.de",
    "discoverychannel":    "Discovery.Channel.de",
    "animalplanet":        "Animal.Planet.de",
    "tlc":                 "TLC.de",
    "dmax":                "DMAX.de",
    "hgtv":                "HGTV.de",
    # Kinder
    "nickelodeon":         "Nickelodeon.de",
    "cartoonnetwork":      "Cartoon.Network.de",
    "kika":                "KiKA.de",
    "disney":              "Disney.Channel.de",
    # Musik
    "mtv":                 "MTV.de",
    # Österreich
    "orf1":                "ORF1.at",
    "orf2":                "ORF2.at",
    "orf3":                "ORF3.at",
    "orfsport":            "ORF.Sport.Plus.at",
    "servustv":            "ServusTV.at",
    "puls4":               "Puls4.at",
    "puls24":              "Puls24.at",
    "atv":                 "ATV.at",
    # Schweiz
    "srf1":                "SRF1.ch",
    "srf2":                "SRF2.ch",
    "srfinfo":             "SRF.Info.ch",
}


def _norm_logo_key(name):
    """Normalisiert Kanalnamen für Logo/EPG-Lookup."""
    import re as _re
    n = name.lower()
    n = _re.sub(r'\s+', '', n)          # Leerzeichen entfernen
    n = _re.sub(r'[^a-z0-9]', '', n)    # Sonderzeichen entfernen
    return n


def _safe_json_load(path, default):
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
    except Exception as e:
        log(f"JSON lesen fehlgeschlagen ({path}): {e}", xbmc.LOGWARNING)
    return default


def _safe_json_save(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
        return True
    except Exception as e:
        log(f"JSON schreiben fehlgeschlagen ({path}): {e}", xbmc.LOGWARNING)
        return False


def _normalize_logo_filename_stem(stem):
    s = stem.lower().strip()
    s = re.sub(r"\.(de|at|ch)$", "", s)
    s = re.sub(r"-(de|at|ch)$", "", s)
    s = s.replace("_", "-")
    s = s.replace("+", "-plus-")
    s = s.replace("&", "-und-")
    s = re.sub(r"[^a-z0-9-]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s


def _logo_keys_from_stem(stem):
    base = _normalize_logo_filename_stem(stem)
    keys = set()
    if not base:
        return keys

    def _add_variants(value):
        value = value.strip("-")
        if not value:
            return
        keys.add(value)
        keys.add(value.replace("-", " "))
        keys.add(value.replace("-", ""))

    _add_variants(base)

    for suffix in ("-hd", "-hz", "-alt", "-plus", "-neu"):
        if base.endswith(suffix):
            _add_variants(base[: -len(suffix)])

    if "classics" in base:
        _add_variants(base.replace("classics", "classic"))
    if "classic" in base:
        _add_variants(base.replace("classic", "classics"))
    if "und" in base:
        _add_variants(base.replace("und", "and"))
    if "and" in base:
        _add_variants(base.replace("and", "und"))
    if "pro-sieben" in base:
        _add_variants(base.replace("pro-sieben", "prosieben"))
    if "prosieben" in base:
        _add_variants(base.replace("prosieben", "pro-sieben"))
    if "sat-1" in base:
        _add_variants(base.replace("sat-1", "sat1"))
    if "sat1" in base:
        _add_variants(base.replace("sat1", "sat-1"))
    if "kabel-eins" in base:
        _add_variants(base.replace("kabel-eins", "kabeleins"))
    if "kabeleins" in base:
        _add_variants(base.replace("kabeleins", "kabel-eins"))
    return keys


def _channel_lookup_variants(name):
    s = (name or "").strip().lower()
    s = s.replace("+", " plus ")
    s = s.replace("&", " und ")
    s = re.sub(r"\[[^\]]*\]", " ", s)
    s = re.sub(r"\([^\)]*\)", " ", s)
    s = re.sub(r"\b(back-?up|backup|fhd|uhd|4k|sd)\b", " ", s)
    s = re.sub(r"hd\+", " hd plus ", s)
    s = re.sub(r"\bhd\b", " ", s)
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    keys = set()
    if not s:
        return keys

    def _add(v):
        v = v.strip("-")
        if not v:
            return
        keys.add(v)
        keys.add(v.replace("-", " "))
        keys.add(v.replace("-", ""))

    _add(s)
    if "plus" in s:
        _add(s.replace("-plus", ""))
        _add(s.replace("plus", ""))
        _add(s.replace("-hd-plus", "-hd"))
        _add(s.replace("-hd-plus", ""))
        _add(s.replace("-plus", "-hd"))
    if "moto" in s:
        _add(s.replace("moto", "motor"))
    if "motor" in s:
        _add(s.replace("motor", "moto"))
    if "and" in s:
        _add(s.replace("and", "und"))
    if "und" in s:
        _add(s.replace("und", "and"))
    if "prosieben" in s:
        _add(s.replace("prosieben", "pro-sieben"))
    if "pro-sieben" in s:
        _add(s.replace("pro-sieben", "prosieben"))
    if "sat1" in s:
        _add(s.replace("sat1", "sat-1"))
    if "sat-1" in s:
        _add(s.replace("sat-1", "sat1"))
    if "rtlzwei" in s:
        _add(s.replace("rtlzwei", "rtl-zwei"))
    if "rtl-2" in s:
        _add(s.replace("rtl-2", "rtl-zwei"))
    if "kabeleins" in s:
        _add(s.replace("kabeleins", "kabel-eins"))
    if "kabel-eins" in s:
        _add(s.replace("kabel-eins", "kabeleins"))
    if "superrtl" in s:
        _add(s.replace("superrtl", "super-rtl"))
        _add(s.replace("superrtl", "rtl-super"))
    if "super-rtl" in s:
        _add(s.replace("super-rtl", "superrtl"))
        _add(s.replace("super-rtl", "rtl-super"))
    if "ard-das-erste" in s:
        _add(s.replace("ard-das-erste", "das-erste"))
    if s.startswith("ard-"):
        _add(s[4:])
    if s.endswith("-tv"):
        _add(s[:-3])

    for pattern, templates in (
        (r"\bdb-liga-(\d{1,2})\b", ("sky-sport-bundesliga-{n}", "sky-bundesliga-{n}", "bundesliga-{n}", "db-liga-{n}")),
        (r"\bsky-bundesliga-?(\d{1,2})\b", ("sky-sport-bundesliga-{n}", "sky-bundesliga-{n}", "bundesliga-{n}", "db-liga-{n}")),
        (r"\bsky-sport-bundesliga-(\d{1,2})\b", ("sky-sport-bundesliga-{n}", "sky-bundesliga-{n}", "bundesliga-{n}", "db-liga-{n}")),
        (r"\bbundesliga-(\d{1,2})\b", ("sky-sport-bundesliga-{n}", "sky-bundesliga-{n}", "bundesliga-{n}", "db-liga-{n}")),
    ):
        m = re.search(pattern, s)
        if m:
            num = m.group(1)
            for tmpl in templates:
                _add(tmpl.format(n=num))

    for pattern, templates in (
        (r"\bs-sport-(\d{1,2})\b", ("sky-sport-{n}", "sky-sport-de-{n}", "skysport{n}")),
        (r"\bsky-sport-(\d{1,2})\b", ("sky-sport-{n}", "skysport{n}", "s-sport-{n}")),
        (r"\bskysport(\d{1,2})\b", ("sky-sport-{n}", "skysport{n}", "s-sport-{n}")),
    ):
        m = re.search(pattern, s)
        if m:
            num = m.group(1)
            for tmpl in templates:
                _add(tmpl.format(n=num))

    for pattern, variants in (
        (r"\bpro7-maxx\b", ("pro-sieben-maxx", "prosiebenmaxx", "pro7maxx", "pro sieben maxx")),
        (r"\bprosieben-maxx\b", ("pro-sieben-maxx", "prosiebenmaxx", "pro7maxx", "pro sieben maxx")),
        (r"\bprosieben\b", ("pro-sieben", "prosieben", "pro7", "pro sieben")),
        (r"\bpro7\b", ("pro-sieben", "prosieben", "pro7", "pro sieben")),
    ):
        if re.search(pattern, s):
            for v in variants:
                _add(v)

    for pattern, variants in (
        (r"\bwarner-comedy\b", ("warner-tv-comedy", "warnercomedy", "warner comedy", "warner tv comedy")),
        (r"\bwarner-film\b", ("warner-tv-film", "warnerfilm", "warner film", "warner tv film")),
        (r"\bwarner-serie\b", ("warner-tv-serie", "warnerserie", "warner serie", "warner tv serie")),
        (r"\bwarner-tv-comedy\b", ("warner-tv-comedy", "warnercomedy", "warner comedy", "warner tv comedy")),
        (r"\bwarner-tv-film\b", ("warner-tv-film", "warnerfilm", "warner film", "warner tv film")),
        (r"\bwarner-tv-serie\b", ("warner-tv-serie", "warnerserie", "warner serie", "warner tv serie")),
    ):
        if re.search(pattern, s):
            for v in variants:
                _add(v)

    return keys


def _fetch_online_logo_index_via_api():
    log("Baue Online-Logo-Index via GitHub API", xbmc.LOGINFO)
    session = _get_session()
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "Kodi/plugin.video.vavoo.tv.plus",
    }
    resp = session.get(_ONLINE_LOGO_REPO_API, headers=headers, timeout=30)
    resp.raise_for_status()
    data = resp.json() if resp.content else {}
    tree = data.get("tree") or []
    index = {}
    for item in tree:
        if item.get("type") != "blob":
            continue
        path = item.get("path", "")
        if not path.lower().endswith(".png"):
            continue
        if not any(path.startswith(prefix) for prefix in _ONLINE_LOGO_ALLOWED_PREFIXES):
            continue
        stem = os.path.splitext(os.path.basename(path))[0]
        url = _ONLINE_LOGO_RAW.format(path=path)
        for key in _logo_keys_from_stem(stem):
            index.setdefault(key, url)
    return index


def _fetch_online_logo_index_via_html():
    log("Baue Online-Logo-Index via GitHub HTML-Fallback", xbmc.LOGINFO)
    session = _get_session()
    headers = {"User-Agent": "Kodi/plugin.video.vavoo.tv.plus"}
    index = {}
    for rel_path in _ONLINE_LOGO_HTML_PATHS:
        try:
            url = _ONLINE_LOGO_REPO_HTML.format(path=rel_path)
            resp = session.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            html = resp.text
            names = set(re.findall(r">([A-Za-z0-9._+\-]+\.(?:png|PNG))<", html))
            if not names:
                names = set(re.findall(r"/blob/main/%s/([A-Za-z0-9._+\-]+\.(?:png|PNG))" % re.escape(rel_path), html))
            for filename in names:
                stem = os.path.splitext(filename)[0]
                path = f"{rel_path}/{filename}"
                file_url = _ONLINE_LOGO_RAW.format(path=path)
                for key in _logo_keys_from_stem(stem):
                    index.setdefault(key, file_url)
        except Exception as e:
            log(f"HTML-Logo-Index für {rel_path} fehlgeschlagen: {e}", xbmc.LOGWARNING)
    return index


def _load_or_build_online_logo_index(force=False):
    global _logo_index_mem
    if _logo_index_mem is not None and not force:
        return _logo_index_mem

    if not force and os.path.exists(_LOGO_INDEX_FILE):
        meta = _safe_json_load(_LOGO_INDEX_META_FILE, {})
        ts = int(meta.get("timestamp", 0) or 0)
        if ts and (time.time() - ts) < _LOGO_INDEX_TTL:
            cached = _safe_json_load(_LOGO_INDEX_FILE, {})
            if cached:
                _logo_index_mem = cached
                return _logo_index_mem

    index = {}
    errors = []
    try:
        index = _fetch_online_logo_index_via_api()
    except Exception as e:
        errors.append(f"api:{e}")
        log(f"Online-Logo-Index via API fehlgeschlagen: {e}", xbmc.LOGWARNING)

    if not index:
        try:
            index = _fetch_online_logo_index_via_html()
        except Exception as e:
            errors.append(f"html:{e}")
            log(f"Online-Logo-Index via HTML fehlgeschlagen: {e}", xbmc.LOGWARNING)

    if index:
        _safe_json_save(_LOGO_INDEX_FILE, index)
        _safe_json_save(_LOGO_INDEX_META_FILE, {"timestamp": int(time.time()), "entries": len(index), "errors": errors})
        log(f"Online-Logo-Index aufgebaut: {len(index)} Einträge", xbmc.LOGINFO)
        _logo_index_mem = index
        return index

    cached = _safe_json_load(_LOGO_INDEX_FILE, {})
    if cached:
        log(f"Verwende vorhandenen Logo-Index aus Cache: {len(cached)} Einträge", xbmc.LOGINFO)
        _logo_index_mem = cached
        return cached

    log("Online-Logo-Index konnte nicht aufgebaut werden", xbmc.LOGWARNING)
    _logo_index_mem = {}
    return _logo_index_mem


# ---------------------------------------------------------------------------
# Logo-Index aus benutzerdefinierter M3U
# ---------------------------------------------------------------------------

_M3U_LOGO_INDEX_FILE = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "logo_m3u_index.json")
_m3u_logo_index_mem  = None   # normalisierter_key → logo_url


def _load_m3u_logo_index():
    """Lädt den M3U-Logo-Index aus dem Speicher- oder Disk-Cache."""
    global _m3u_logo_index_mem
    if _m3u_logo_index_mem is not None:
        return _m3u_logo_index_mem
    cached = _safe_json_load(_M3U_LOGO_INDEX_FILE, {})
    _m3u_logo_index_mem = cached
    return _m3u_logo_index_mem


def build_m3u_logo_index(force=False):
    """
    Liest die vom Benutzer hinterlegte Logo-M3U (URL oder lokaler Pfad)
    und baut daraus einen normName → logo_url Index.
    Wird in den Settings unter 'logo_m3u_url' konfiguriert.
    """
    global _m3u_logo_index_mem
    try:
        m3u_src = ADDON.getSetting("logo_m3u_url").strip()
    except Exception:
        m3u_src = ""

    if not m3u_src:
        return {}

    log(f"Lade Logo-M3U: {m3u_src}", xbmc.LOGINFO)
    try:
        if m3u_src.startswith("http://") or m3u_src.startswith("https://"):
            resp = _get_session().get(m3u_src, timeout=30)
            resp.raise_for_status()
            text = resp.text
        else:
            path = xbmcvfs.translatePath(m3u_src)
            with open(path, encoding="utf-8", errors="ignore") as f:
                text = f.read()
    except Exception as e:
        log(f"Logo-M3U laden fehlgeschlagen: {e}", xbmc.LOGWARNING)
        return {}

    index = {}
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("#EXTINF:"):
            continue
        # tvg-name extrahieren
        m_name = re.search(r'tvg-name="([^"]*)"|\,(.+)$', line)
        if m_name:
            name = m_name.group(1).strip()
        else:
            # Fallback: Komma-Name am Ende der EXTINF-Zeile
            m_comma = re.search(r',([^,]+)$', line)
            if m_comma:
                name = m_comma.group(1).strip()
            else:
                continue
        # tvg-logo extrahieren
        m_logo = re.search(r'tvg-logo="([^"]*)"', line)
        if not m_logo or not m_logo.group(1).strip():
            continue
        logo_url = m_logo.group(1).strip()
        if not logo_url.startswith("http"):
            continue
        # Alle Normalisierungsvarianten eintragen
        for key in _channel_lookup_variants(name):
            index.setdefault(key, logo_url)
        index.setdefault(_norm_logo_key(name), logo_url)

    if index:
        _safe_json_save(_M3U_LOGO_INDEX_FILE, index)
        log(f"Logo-M3U Index: {len(index)} Einträge gespeichert", xbmc.LOGINFO)

    _m3u_logo_index_mem = index
    return index


def get_channel_logo(name):
    """
    Gibt Logo-URL für einen Kanal zurück oder leeren String.
    Suchreihenfolge:
      1. Benutzer-M3U Logo-Index (tvg-logo aus hinterlegter M3U, höchste Priorität)
      2. Online-Logo-Index (GitHub-Dateiliste, 7-Tage-Cache)
      3. Statisches CHANNEL_LOGO_MAP
      4. Teilstring-Suche im statischen Mapping
    """
    # 1. Benutzer-M3U Logo-Index
    try:
        m3u_index = _load_m3u_logo_index()
        if m3u_index:
            for key in _channel_lookup_variants(name):
                url = m3u_index.get(key) or m3u_index.get(_norm_logo_key(key))
                if url:
                    return url
    except Exception as e:
        log(f"M3U-Logo-Lookup fehlgeschlagen für {name}: {e}", xbmc.LOGWARNING)

    # 2. Online-Logo-Index (GitHub)
    try:
        online_index = _load_or_build_online_logo_index(force=False)
        for key in _channel_lookup_variants(name):
            url = online_index.get(key)
            if url:
                return url
            norm_key = _norm_logo_key(key)
            url = online_index.get(norm_key)
            if url:
                return url
    except Exception as e:
        log(f"Online-Logo-Lookup fehlgeschlagen für {name}: {e}", xbmc.LOGWARNING)

    # 3. + 4. Statisches CHANNEL_LOGO_MAP
    key = _norm_logo_key(name)
    path = CHANNEL_LOGO_MAP.get(key, "")
    if not path:
        for k, v in CHANNEL_LOGO_MAP.items():
            if k in key or key in k:
                path = v
                break

    return f"{_LOGO_BASE}/{path}" if path else ""


def get_channel_epg_id(name):
    """EPG nur fuer eindeutige Senderidentitaeten, niemals per Teilstring."""
    key = _norm_logo_key(name)
    # Qualitaetsangaben sind keine eigene Senderidentitaet.
    for suffix in ("uhd", "fhd", "hd"):
        if key.endswith(suffix):
            key = key[:-len(suffix)]
            break
    aliases = {
        "rtltelevision": "rtl", "rtl2": "rtlzwei", "rtlzwei": "rtlzwei",
        "rtlplus": "rtlup", "rtlup": "rtlup",
        "eurosport1deutschland": "eurosport1", "eurosport2deutschland": "eurosport2",
        "radio bremen": "radiobremen", "radiobremen": "radiobremen",
    }
    key = aliases.get(key, key)
    return CHANNEL_EPG_MAP.get(key, "")


# ---------------------------------------------------------------------------
# M3U Generierung
# ---------------------------------------------------------------------------

def generate_m3u(channels, group, epg_url=""):
    """
    Erzeugt eine vollständige M3U-Playlist mit:
    - tvg-logo (aus CHANNEL_LOGO_MAP)
    - tvg-id   (aus CHANNEL_EPG_MAP)
    - group-title = Genre | Land
    - Plugin-URLs für Kodi-Wiedergabe
    - Optional: EPG-Quell-URL im Header
    """
    addon_id = "plugin.video.vavoo.tv.plus"

    header = "#EXTM3U"
    if epg_url:
        header += f' url-tvg="{epg_url}"'
    lines = [header, ""]

    for name in sorted(channels.keys()):
        urls = channels[name]
        if not urls:
            continue

        # Genre ermitteln
        genre     = classify_channel_genre(name)
        genre_clean = genre.split("  ", 1)[-1] if "  " in genre else genre

        group_title = f"{genre_clean} | {group}"
        logo        = ""   # tvg-logo leer lassen – wird aus Logo-Cache oder EPG befüllt
        epg_id      = get_channel_epg_id(name)
        safe_name   = name.replace('"', "'")

        from urllib.parse import quote_plus
        plugin_url = (
            f"plugin://{addon_id}/"
            f"?action=play"
            f"&name={quote_plus(name)}"
            f"&url={quote_plus(urls[0])}"
        )

        extinf = (
            f'#EXTINF:-1'
            f' tvg-name="{safe_name}"'
            f' tvg-id="{epg_id}"'
            f' tvg-logo="{logo}"'
            f' group-title="{group_title}"'
            f',{safe_name}'
        )
        lines.append(extinf)
        lines.append(plugin_url)
        lines.append("")

    return "\n".join(lines)


def generate_favorites_m3u(favs, epg_url=""):
    """
    Erzeugt M3U aus der Favoriten-Liste (mit Marker-Unterstützung).
    Marker werden als group-title-Wechsel abgebildet.
    """
    addon_id = "plugin.video.vavoo.tv.plus"

    header = "#EXTM3U"
    if epg_url:
        header += f' url-tvg="{epg_url}"'
    lines = [header, ""]

    current_group = "Favoriten"

    for fav in favs:
        ftype = fav.get("type", "channel")

        if ftype == "marker":
            # Marker → neuer group-title (Sonderzeichen entfernen)
            marker_text = fav.get("name", "")
            # "--- Sport ---" → "Sport"
            import re as _re
            current_group = _re.sub(r'^[-\s*]+|[-\s*]+$', '', marker_text).strip()
            if not current_group:
                current_group = marker_text
            continue

        name = fav.get("name", "")
        url  = fav.get("url", "")
        if not name or not url:
            continue

        logo   = get_channel_logo(name)
        epg_id = get_channel_epg_id(name)
        safe   = name.replace('"', "'")

        from urllib.parse import quote_plus
        plugin_url = (
            f"plugin://{addon_id}/"
            f"?action=play"
            f"&name={quote_plus(name)}"
            f"&url={quote_plus(url)}"
        )

        extinf = (
            f'#EXTINF:-1'
            f' tvg-name="{safe}"'
            f' tvg-id="{epg_id}"'
            f' tvg-logo="{logo}"'
            f' group-title="{current_group}"'
            f',{safe}'
        )
        lines.append(extinf)
        lines.append(plugin_url)
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# EPG – XMLTV Parser & aktuelle Sendung
# ---------------------------------------------------------------------------

_epg_cache        = {}     # tvg_id → [(start_dt, stop_dt, title, desc), ...]
_epg_lookup       = {}     # normalisierter_key → channel_id
_epg_load_attempted = False  # Session-Flag: wurde in dieser Kodi-Session bereits versucht?


def _parse_xmltv_dt(s):
    """Parse XMLTV timestamps without ``datetime.strptime``.

    Kodi environments can exhibit strptime-related module/name conflicts in
    addons. Parse the numeric XMLTV fields directly and normalize the optional
    UTC offset to a naive UTC datetime.
    """
    import datetime
    import re

    try:
        value = (s or "").strip()
        if not value:
            return None

        # Accept canonical/reduced XMLTV plus common ISO-like separators:
        # YYYYMMDDHHMMSS +0000, YYYYMMDDHHMM +0200, ... Z, +02:00.
        m = re.match(
            r"^\s*(\d{4})[-/]?(\d{2})[-/]?(\d{2})"
            r"(?:[ T]?(\d{2})(?::?(\d{2}))?(?::?(\d{2}))?)?"
            r"\s*(Z|[+-]\d{2}:?\d{2})?\s*$", value, re.I)
        if not m:
            return None

        year = int(m.group(1))
        month = int(m.group(2))
        day = int(m.group(3))
        hour = int(m.group(4) or 0)
        minute = int(m.group(5) or 0)
        second = int(m.group(6) or 0)
        dt = datetime.datetime(year, month, day, hour, minute, second)

        tz_str = m.group(7)
        if tz_str and tz_str.upper() != "Z":
            clean = tz_str.replace(":", "")
            sign = 1 if clean[0] == "+" else -1
            offset = datetime.timedelta(
                hours=int(clean[1:3]), minutes=int(clean[3:5]))
            # XMLTV offset describes local time relative to UTC.
            dt -= sign * offset
        return dt
    except (TypeError, ValueError, OverflowError, IndexError):
        return None


def _epg_disk_path():
    """Pfad zur EPG-Disk-Cache-Datei."""
    try:
        import xbmcvfs, xbmcaddon, os
        profile = xbmcvfs.translatePath(
            xbmcaddon.Addon("plugin.video.vavoo.tv.plus").getAddonInfo("profile"))
        return os.path.join(profile, "epg_cache.json")
    except Exception:
        return ""


def _epg_save_disk(data, epg_url, cache_hours):
    """Speichert EPG-Cache auf Disk."""
    import json, time, os
    path = _epg_disk_path()
    if not path:
        return
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        # Datetime-Objekte in ISO-Strings konvertieren
        serializable = {}
        for ch_id, progs in data.items():
            serializable[ch_id] = [
                (s.isoformat(), e.isoformat(), t, d)
                for s, e, t, d in progs
            ]
        tmp_path = path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump({
                "url":     epg_url,
                "expires": time.time() + cache_hours * 3600,
                "data":    serializable
            }, f)
        os.replace(tmp_path, path)
    except Exception as ex:
        log(f"EPG Disk-Save Fehler: {ex}", xbmc.LOGWARNING)


def _epg_load_disk(epg_url):
    """Lädt EPG-Cache von Disk. Gibt Dict oder None zurück."""
    import json, time, datetime, os
    path = _epg_disk_path()
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            saved = json.load(f)
        if saved.get("url") != epg_url:
            return None
        if saved.get("expires", 0) < time.time():
            return None
        # ISO-Strings zurück in datetime
        result = {}
        for ch_id, progs in saved["data"].items():
            result[ch_id] = [
                (datetime.datetime.fromisoformat(s),
                 datetime.datetime.fromisoformat(e),
                 t, d)
                for s, e, t, d in progs
            ]
        return result
    except Exception as ex:
        log(f"EPG Disk-Load Fehler: {ex}", xbmc.LOGWARNING)
        return None


def _build_epg_lookup(epg_data):
    """
    Baut eine Lookup-Tabelle: normalisierter_key → channel_id
    Damit können wir flexibel verschiedene ID-Formate (xmltv.info etc.) matchen.
    """
    import re as _re
    lookup = {}
    for ch_id in epg_data.keys():
        # Normalisiere: kleinbuchstaben, nur alphanumerisch
        norm = _re.sub(r'[^a-z0-9]', '', ch_id.lower())
        lookup[norm] = ch_id
    return lookup


_epg_lookup = {}   # normalisierter_key → channel_id


def fetch_epg(epg_url, force=False):
    """Lädt XMLTV-EPG robust und cached das bereits geparste Ergebnis.

    ``force=True`` überspringt nur den gültigen Disk-Cache. Der bestehende
    RAM-/Disk-EPG wird erst ersetzt, nachdem Download und Parsing erfolgreich
    abgeschlossen wurden. Bei Fehler bleibt der letzte funktionierende RAM-EPG.
    """
    global _epg_cache, _epg_lookup, _epg_load_attempted

    if not epg_url:
        return False

    _epg_load_attempted = True

    if not force:
        disk_data = _epg_load_disk(epg_url)
        if disk_data:
            _epg_cache = disk_data
            _epg_lookup = _build_epg_lookup(disk_data)
            log(f"EPG von Disk geladen: {len(disk_data)} Kanaele", xbmc.LOGINFO)
            return True

    # Schutz vor unbeschraenkten XMLTV-/GZIP-Downloads.
    max_download = 50 * 1024 * 1024      # 50 MiB komprimiert/unkomprimiert
    max_xml = 200 * 1024 * 1024          # 200 MiB nach GZIP-Dekompression
    tmp_path = ""
    xml_path = ""
    try:
        import tempfile
        import gzip
        import shutil
        import xml.etree.ElementTree as ET

        log(f"Lade EPG: {epg_url}{' (force)' if force else ''}", xbmc.LOGINFO)
        response = _get_session().get(epg_url, timeout=(10, 60), stream=True)
        response.raise_for_status()
        content_length = response.headers.get("Content-Length")
        if content_length:
            try:
                if int(content_length) > max_download:
                    raise ValueError("EPG-Download ist groesser als 50 MiB")
            except ValueError as exc:
                if "groesser" in str(exc):
                    raise

        fd, tmp_path = tempfile.mkstemp(prefix="vavoo_epg_", suffix=".download")
        os.close(fd)
        total = 0
        first_two = b""
        with open(tmp_path, "wb") as out:
            for chunk in response.iter_content(chunk_size=256 * 1024):
                if not chunk:
                    continue
                if len(first_two) < 2:
                    first_two = (first_two + chunk[:2])[:2]
                total += len(chunk)
                if total > max_download:
                    raise ValueError("EPG-Download ueberschreitet 50 MiB")
                out.write(chunk)

        is_gzip = epg_url.lower().endswith(".gz") or first_two == b"\x1f\x8b"
        if is_gzip:
            fd, xml_path = tempfile.mkstemp(prefix="vavoo_epg_", suffix=".xml")
            os.close(fd)
            written = 0
            with gzip.open(tmp_path, "rb") as src, open(xml_path, "wb") as dst:
                while True:
                    chunk = src.read(256 * 1024)
                    if not chunk:
                        break
                    written += len(chunk)
                    if written > max_xml:
                        raise ValueError("Entpacktes EPG ueberschreitet 200 MiB")
                    dst.write(chunk)
        else:
            xml_path = tmp_path

        new_cache = {}
        programme_count = 0
        invalid_count = 0

        def _local_name(tag):
            # Namespace-tolerant: {urn:xmltv}programme -> programme
            return str(tag).rsplit("}", 1)[-1].lower()

        def _child_text(parent, wanted):
            fallback = ""
            for node in list(parent):
                if _local_name(node.tag) != wanted:
                    continue
                text = (node.text or "").strip()
                if not text:
                    continue
                lang = (node.get("lang") or "").lower()
                if lang in ("de", "deu", "ger", "de-de"):
                    return text
                if not fallback:
                    fallback = text
            return fallback

        # Iterparse keeps memory usage low. Use local tag names so XMLTV feeds
        # with a default namespace are accepted as well.
        for event, elem in ET.iterparse(xml_path, events=("end",)):
            if _local_name(elem.tag) != "programme":
                continue
            programme_count += 1
            ch_id = (elem.get("channel") or "").strip()
            start = _parse_xmltv_dt(elem.get("start", ""))
            stop = _parse_xmltv_dt(elem.get("stop", ""))
            if ch_id and start and stop and stop > start:
                title = _child_text(elem, "title")
                desc = _child_text(elem, "desc")
                new_cache.setdefault(ch_id, []).append((start, stop, title, desc))
            else:
                invalid_count += 1
                if invalid_count <= 3:
                    log(
                        "EPG Parser verworfen: channel=%r start=%r stop=%r parsed_start=%r parsed_stop=%r"
                        % (ch_id, elem.get("start"), elem.get("stop"), start, stop),
                        xbmc.LOGWARNING,
                    )
            elem.clear()

        if not new_cache:
            raise ValueError(
                f"EPG enthaelt keine gueltigen Programme "
                f"(programme={programme_count}, ungueltig={invalid_count})"
            )

        for programmes in new_cache.values():
            programmes.sort(key=lambda item: item[0])
        log(
            f"EPG Parser: {programme_count} Programme, "
            f"{invalid_count} verworfen, {len(new_cache)} Kanaele",
            xbmc.LOGINFO,
        )

        try:
            cache_h = int(xbmcaddon.Addon("plugin.video.vavoo.tv.plus").getSetting("epg_cache_hours") or 2)
            cache_h = max(1, min(cache_h, 168))
        except Exception:
            cache_h = 2

        # Erst jetzt den aktiven Cache ersetzen.
        _epg_cache = new_cache
        _epg_lookup = _build_epg_lookup(new_cache)
        _epg_save_disk(new_cache, epg_url, cache_h)
        log(f"EPG geladen und gespeichert: {len(new_cache)} Kanaele", xbmc.LOGINFO)
        return True

    except Exception as exc:
        log(f"EPG-Ladefehler: {exc}; vorhandener Cache bleibt aktiv", xbmc.LOGERROR)
        return False
    finally:
        for path in {tmp_path, xml_path}:
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass


def _utc_to_local_str(dt_utc):
    """Konvertiert UTC-datetime in lokale Uhrzeit als HH:MM String."""
    import datetime
    if dt_utc is None:
        return ""
    try:
        ts = dt_utc.replace(tzinfo=datetime.timezone.utc).timestamp()
        local_dt = datetime.datetime.fromtimestamp(ts)
        return local_dt.strftime("%H:%M")
    except Exception:
        return ""


def get_current_programme(tvg_id):
    """
    Gibt die aktuell laufende Sendung für eine tvg-id zurück.
    Sucht flexibel: direkte ID, normalisiert, bereinigt (HD/Noise), Teilstring.
    Rückgabe bei Treffer:
        (title, desc, start_str, stop_str, remaining_minutes, next_title, next_start)
    Rückgabe ohne Treffer bleibt aus Kompatibilitätsgründen eine leere Tupelvariante.
    """
    import datetime, re as _re

    if not tvg_id or not _epg_cache:
        return "", "", "", ""

    def _norm(s):
        return _re.sub(r'[^a-z0-9]', '', s.lower())

    def _clean_name(s):
        s = s.strip()
        s = _re.sub(r'\[[^\]]*\]', '', s)
        s = _re.sub(r'\([^\)]*\)', '', s)
        s = _re.sub(r'\s*-\s*HD\b', ' HD', s, flags=_re.IGNORECASE)
        s = _re.sub(r'\s+(HD\+?|FHD|UHD|4K|HEVC(?:\s+H\.?265)?|SD)(\s+.*)?$', '', s, flags=_re.IGNORECASE)
        return s.strip()

    clean = _clean_name(tvg_id)
    variants_norm = list(dict.fromkeys(filter(None, [_norm(tvg_id), _norm(clean)])))

    # 1. Direkte Suche
    programmes = _epg_cache.get(tvg_id, [])

    # 2. Normalisierte Suche via Lookup-Tabelle
    if not programmes and _epg_lookup:
        for v in variants_norm:
            mapped_id = _epg_lookup.get(v, "")
            if mapped_id:
                programmes = _epg_cache.get(mapped_id, [])
                if programmes:
                    break

    # 3. Direkter Key-Vergleich mit allen Varianten
    if not programmes:
        for v in variants_norm:
            for key in _epg_cache:
                if _norm(key) == v:
                    programmes = _epg_cache[key]
                    break
            if programmes:
                break

    # 4. Teilstring-Suche als letzter Fallback
    if not programmes:
        for v in variants_norm:
            for key in _epg_cache:
                key_norm = _norm(key)
                key_clean = _norm(_clean_name(key))
                if (v in key_norm or key_norm in v or v == key_clean or key_clean in variants_norm):
                    programmes = _epg_cache[key]
                    break
            if programmes:
                break

    if not programmes:
        return "", "", "", "", "", ""

    now = datetime.datetime.utcnow()
    sorted_progs = sorted(programmes, key=lambda x: x[0] or datetime.datetime.min)
    for i, (start, stop, title, desc) in enumerate(sorted_progs):
        if start and stop and start <= now <= stop:
            remaining = int((stop - now).total_seconds() / 60)
            remaining_str = f"{remaining} min" if remaining > 0 else ""
            if i + 1 < len(sorted_progs):
                n_start, n_stop, next_title, _ = sorted_progs[i + 1]
                next_time = f"{_utc_to_local_str(n_start)} – {_utc_to_local_str(n_stop)}"
            else:
                next_title = ""
                next_time  = ""
            return title, desc, _utc_to_local_str(start), _utc_to_local_str(stop), remaining_str, next_title, next_time

    return "", "", "", "", "", "", ""


def get_current_programme_by_name(channel_name):
    """
    Sucht EPG nach Kanalnamen. Bereinigt Noise-Tokens:
    [SAT] [] (BACKUP) (LOCAL) (MATCH TIME) -HD HEVC HD FHD UHD 4K.
    """
    import re as _re, datetime

    if not _epg_cache or not channel_name:
        return "", ""

    def _norm(s):
        return _re.sub(r'[^a-z0-9]', '', s.lower())

    def _clean_name(s):
        s = s.strip()
        s = _re.sub(r'\[[^\]]*\]', '', s)
        s = _re.sub(r'\([^\)]*\)', '', s)
        s = _re.sub(r'\s*-\s*HD\b', ' HD', s, flags=_re.IGNORECASE)
        s = _re.sub(r'\s+(HD\+?|FHD|UHD|4K|HEVC(?:\s+H\.?265)?|SD)(\s+.*)?$', '', s, flags=_re.IGNORECASE)
        return s.strip()

    canonical_id = get_channel_epg_id(channel_name)
    if canonical_id:
        return get_current_programme(canonical_id)

    clean = _clean_name(channel_name)
    variants_norm = list(dict.fromkeys(filter(None, [_norm(channel_name), _norm(clean)])))

    best_key = ""
    best_score = 0

    for key in _epg_cache:
        key_norm = _norm(key)
        key_clean_norm = _norm(_clean_name(key))

        for variant in variants_norm:
            if (variant == key_norm or variant == key_clean_norm):
                score = min(len(variant), len(key_norm))
                if score > best_score:
                    best_score = score
                    best_key = key
                break

    if not best_key:
        return "", ""

    now = datetime.datetime.utcnow()
    sorted_progs = sorted(_epg_cache.get(best_key, []), key=lambda x: x[0] or datetime.datetime.min)
    for i, (start, stop, title, desc) in enumerate(sorted_progs):
        if start and stop and start <= now <= stop:
            log(f"EPG by name match: {channel_name} → {best_key} → {title}", xbmc.LOGINFO)
            remaining = int((stop - now).total_seconds() / 60)
            remaining_str = f"{remaining} min" if remaining > 0 else ""
            if i + 1 < len(sorted_progs):
                n_start, n_stop, next_title, _ = sorted_progs[i + 1]
                next_time = f"{_utc_to_local_str(n_start)} – {_utc_to_local_str(n_stop)}"
            else:
                next_title = ""
                next_time  = ""
            return title, desc, _utc_to_local_str(start), _utc_to_local_str(stop), remaining_str, next_title, next_time

    return "", "", "", "", "", "", ""


def get_epg_url():
    """Liest EPG-URL aus den Addon-Settings."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon("plugin.video.vavoo.tv.plus").getSetting("epg_url").strip()
    except Exception:
        return ""


def epg_show_enabled():
    """Prüft ob 'Aktuelle Sendung anzeigen' aktiviert ist."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon("plugin.video.vavoo.tv.plus").getSetting("epg_show_current").lower() in ("true", "1")
    except Exception:
        return False

# VOD nutzt wieder die integrierte Vavoo-API (CCAPI, Source und Resolve).

# Quellenauswahl wie im Referenz-Addon fuer Filme und Serien.
from geil_vod import resolve as resolve_vod_stream
