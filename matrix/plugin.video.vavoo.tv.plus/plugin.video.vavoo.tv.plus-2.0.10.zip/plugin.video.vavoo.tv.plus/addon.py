# -*- coding: utf-8 -*-
import sys
import os
import json
import threading
from urllib.parse import parse_qsl, urlencode, quote as url_quote

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON      = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ADDON_PATH = ADDON.getAddonInfo("path")

_LIB_PATH = xbmcvfs.translatePath(os.path.join(ADDON_PATH, "resources", "lib"))
if _LIB_PATH not in sys.path:
    sys.path.insert(0, _LIB_PATH)
from utils import paths as addon_paths

DEFAULT_ICON = addon_paths.default_channel_path(ADDON)
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
_SCAN_FLAG_FILE = os.path.join(PROFILE_PATH, "scan_done.flag")
_MAINTENANCE_REPORT_FILE = os.path.join(PROFILE_PATH, "maintenance_report.txt")
_INTERNAL_LOG_FILE = os.path.join(PROFILE_PATH, "activity_log.txt")
_INITIAL_EPG_REFRESH_FILE = os.path.join(PROFILE_PATH, "initial_epg_refresh.json")

_RELEASE_VERSION = "2.0.10"
_RELEASE_STATUS = "Premium Kino Edition"


def _release_information_text():
    return (
        "Vavoo TV Plus\n\n"
        f"Version {_RELEASE_VERSION}\n"
        f"{_RELEASE_STATUS}\n\n"
        "Willkommen in der Premium Kino Edition!\n\n"
        "Entdeckt echte Filmreihen und Filmempfehlungen im großen Premium-Fenster.\n"
        "Mit Premium-Serienfenster, Episodenbildern und Autoplay.\n"
        "Gesehen-Status, Filmreihen-Fortschritt und zusätzliche Filminformationen.\n\n"
        "Vielen Dank für eure Unterstützung,\n"
        "eure Tests und euer Feedback.\n\n"
        "Viel Spaß mit Vavoo TV Plus!"
    )


def show_release_information():
    """Zeigt die dauerhaft abrufbaren Informationen zur Stable-Version."""
    xbmcgui.Dialog().textviewer("Vavoo TV Plus", _release_information_text())


def show_release_dialog_once():
    """Zeigt den Stable-Hinweis genau einmal nach Installation oder Update."""
    try:
        if ADDON.getSetting("last_release_dialog") == _RELEASE_VERSION:
            return
        xbmcgui.Dialog().ok("Vavoo TV Plus", _release_information_text())
        ADDON.setSetting("last_release_dialog", _RELEASE_VERSION)
    except Exception as exc:
        xbmc.log(f"[{ADDON_NAME}] Release-Dialog konnte nicht angezeigt werden: {exc}", xbmc.LOGWARNING)


def _scan_done_this_session():
    """Prüft, ob sich seit dem letzten M3U-Scan eine Quelldatei geändert hat."""
    try:
        if not os.path.exists(_SCAN_FLAG_FILE):
            return False
        with open(_SCAN_FLAG_FILE, encoding="utf-8") as handle:
            state = json.load(handle)
        return state.get("signature", "") == gf.m3u_scan_signature()
    except Exception:
        # Alte Flag-Dateien aus 1.x werden dadurch automatisch ersetzt.
        return False


def _mark_scan_done():
    """Speichert die aktuelle M3U-Ordnersignatur nach einem vollständigen Scan."""
    try:
        os.makedirs(PROFILE_PATH, exist_ok=True)
        state = {"signature": gf.m3u_scan_signature()}
        with open(_SCAN_FLAG_FILE, "w", encoding="utf-8") as handle:
            json.dump(state, handle, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _write_text_file(path, text):
    return favorites_maintenance.write_text_file(path, text)



def _read_text_file(path):
    return favorites_maintenance.read_text_file(path)



def _append_internal_log(message):
    return favorites_maintenance.append_internal_log(PROFILE_PATH, _INTERNAL_LOG_FILE, message)



def favorites_show_last_report():
    return favorites_maintenance.show_last_report(ADDON_NAME, _MAINTENANCE_REPORT_FILE)



def favorites_show_activity_log():
    return favorites_maintenance.show_activity_log(ADDON_NAME, _INTERNAL_LOG_FILE)



def favorites_clear_activity_log():
    return favorites_maintenance.clear_activity_log(ADDON_NAME, _INTERNAL_LOG_FILE)



def _ensure_dir(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
def _safe_logo_param(logo):
    """Gibt Logo-URL nur zurück wenn es eine HTTP-URL ist (kein lokaler Pfad)."""
    if logo and logo.startswith("http"):
        return logo
    return ""
def _play_url(name, url, tvg_id="", logo=""):
    params = {"action": "play", "url": url, "name": name}
    if tvg_id:
        params["tvg_id"] = tvg_id
    safe_logo = _safe_logo_param(logo)
    if safe_logo:
        params["logo"] = safe_logo
    return build_url(**params)

import vavoo_api as api
import group_favs as gf
from favorites import maintenance as favorites_maintenance
from favorites import sources as favorites_sources
from favorites import backup as favorites_backup
from favorites import repair_engine as favorites_repair
import vod_comfort as comfort
import router as addon_router
import menus as addon_menus

def build_url(**params):
    return f"{BASE_URL}?{urlencode(params)}"

def get_params():
    return dict(parse_qsl(sys.argv[2][1:]))

def get_selected_countries_setting():
    return ADDON.getSetting("selected_countries").strip()

def set_selected_countries_setting(codes_str):
    ADDON.setSetting("selected_countries", codes_str)

def is_first_run():
    return ADDON.getSetting("first_run").lower() in ("true", "1", "yes", "")

def mark_first_run_done():
    ADDON.setSetting("first_run", "false")

def get_active_countries(all_countries):
    codes_str = get_selected_countries_setting()
    if not codes_str:
        return all_countries

    wanted  = api.parse_country_codes(codes_str)
    all_set = set(all_countries)
    filtered = [c for c in wanted if c in all_set]
    for c in wanted:
        if c not in all_set and c not in filtered:
            filtered.append(c)
    return filtered if filtered else all_countries

def run_wizard(all_countries):
    if not all_countries:
        return all_countries

    labels = []
    for country in all_countries:
        code = api.country_to_code(country)
        labels.append(f"{country}  [{code}]" if code else country)

    chosen_indices = xbmcgui.Dialog().multiselect(
        f"{ADDON_NAME} – Ländergruppen auswählen",
        labels,
        preselect=[]
    )

    if chosen_indices is None:
        mark_first_run_done()
        return None

    if not chosen_indices:
        set_selected_countries_setting("")
        mark_first_run_done()
        xbmcgui.Dialog().notification(
            ADDON_NAME, "Alle Länder werden angezeigt",
            xbmcgui.NOTIFICATION_INFO, 2000)
        return all_countries

    selected = [all_countries[i] for i in chosen_indices]

    codes = []
    for country in selected:
        code = api.country_to_code(country)
        codes.append(code if code else country)
    set_selected_countries_setting(",".join(codes))
    mark_first_run_done()

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        f"{len(selected)} Länder ausgewählt",
        xbmcgui.NOTIFICATION_INFO, 2000
    )
    return selected

def _write_initial_epg_refresh_state(status, epg_url="", detail=""):
    """Speichert den Erststart-EPG-Status atomar außerhalb der Einstellungen."""
    try:
        import time
        os.makedirs(PROFILE_PATH, exist_ok=True)
        payload = {
            "status": str(status or ""),
            "epg_url": str(epg_url or ""),
            "detail": str(detail or ""),
            "timestamp": int(time.time()),
        }
        tmp_path = _INITIAL_EPG_REFRESH_FILE + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        os.replace(tmp_path, _INITIAL_EPG_REFRESH_FILE)
    except Exception as exc:
        try:
            api.log(f"EPG-Erststartstatus konnte nicht gespeichert werden: {exc}", xbmc.LOGWARNING)
        except Exception:
            pass


def _refresh_epg_after_channel_update():
    """Aktualisiert das EPG einmal nach der Senderlisten-Aktualisierung.

    Ohne konfigurierte URL wird der Schritt sofort als uebersprungen markiert.
    Dadurch kann weder ein Container-Refresh noch ein erneuter Addon-Aufruf eine
    Warteschleife ausloesen. Fehler blockieren den weiteren Erststart nicht.
    """
    epg_url = ADDON.getSetting("epg_url").strip()
    if not epg_url:
        _write_initial_epg_refresh_state("skipped_no_url")
        api.log("EPG-Aktualisierung uebersprungen: keine EPG-Quelle konfiguriert", xbmc.LOGINFO)
        return "skipped"

    # Vor dem Netzwerkzugriff markieren. Selbst ein Abbruch kann dadurch keinen
    # wiederholten automatischen Aufruf innerhalb desselben Erststarts erzeugen.
    _write_initial_epg_refresh_state("running", epg_url)
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "EPG wird aktualisiert ...")
    try:
        progress.update(10, "EPG-Quelle wird geladen ...")
        api._auth_cache.pop(f"epg_{epg_url}", None)
        ok = bool(api.fetch_epg(epg_url, force=True))
        if ok:
            progress.update(100, "EPG aktualisiert")
            _write_initial_epg_refresh_state(
                "success", epg_url, f"{len(api._epg_cache)} Kanaele"
            )
            xbmcgui.Dialog().notification(
                ADDON_NAME, "EPG aktualisiert", xbmcgui.NOTIFICATION_INFO, 2200
            )
            return "success"

        _write_initial_epg_refresh_state("failed", epg_url, "Keine EPG-Daten geladen")
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            "EPG konnte nicht aktualisiert werden",
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )
        return "failed"
    except Exception as exc:
        _write_initial_epg_refresh_state("failed", epg_url, str(exc))
        api.log(f"Automatische EPG-Aktualisierung fehlgeschlagen: {exc}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            "EPG konnte nicht aktualisiert werden",
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )
        return "failed"
    finally:
        progress.close()


def _refresh_selected_countries_and_offer_favorites(selected):
    """Lädt nach der Länderauswahl den Senderkatalog neu und bietet die Favoriten-Aktualisierung an."""
    if not selected:
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Senderlisten werden neu geladen ...")
    loaded = 0
    try:
        for i, country in enumerate(selected):
            if progress.iscanceled():
                break
            pct = int((i / max(len(selected), 1)) * 100)
            progress.update(pct, f"Aktualisiere {country} ...")
            channels = api.fetch_channels_for_group(country, force=True)
            if channels:
                loaded += 1
        progress.update(100, "Senderlisten aktualisiert")
    finally:
        progress.close()

    if loaded == 0:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            "Die Senderlisten konnten nicht geladen werden.\n"
            "Die Favoriten wurden deshalb nicht veraendert."
        )
        return

    # Erst nach erfolgreich geladenen Senderlisten das EPG aktualisieren.
    # Ohne URL wird dieser Schritt still und dauerhaft als erledigt markiert.
    _refresh_epg_after_channel_update()

    groups = gf.load_groups()
    if not groups:
        xbmcgui.Dialog().notification(
            ADDON_NAME, "Senderlisten aktualisiert",
            xbmcgui.NOTIFICATION_INFO, 2500
        )
        return

    update_favorites = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "Senderlisten wurden neu geladen.\n\n"
        "Vorhandene Sender in den Favoritengruppen jetzt aktualisieren?\n\n"
        "Gruppen- und Senderreihenfolge bleiben unverändert."
    )
    if update_favorites:
        # Vor dem Start dauerhaft markieren, damit ein Container-Refresh oder
        # Neustart den Erststart-Sync nicht erneut ausloest.
        ADDON.setSetting("initial_favorites_sync_prompted", "true")
        ADDON.setSetting("initial_favorites_sync_running", "true")
        try:
            _sync_favorite_groups("", force_reload=False, mode="quick")
            ADDON.setSetting("initial_favorites_sync_done", "true")
        finally:
            ADDON.setSetting("initial_favorites_sync_running", "false")
    else:
        ADDON.setSetting("initial_favorites_sync_prompted", "true")

def _menu_icon(filename):
    """Resolve bundled icons or Kodi skin-provided Default*.png textures."""
    if filename and filename.startswith("Default") and filename.endswith(".png"):
        return filename
    path = addon_paths.media_icon_path(ADDON, filename)
    return path if xbmcvfs.exists(path) else DEFAULT_ICON


def _standard_list_icon(icon_name):
    """Return a skin-provided Kodi icon for the small list marker.

    The bundled PNG remains the large preview artwork (thumb/poster/fanart).
    """
    name = (icon_name or "").lower()
    if icon_name and icon_name.startswith("Default") and icon_name.endswith(".png"):
        return icon_name
    if "filme" in name or "movie" in name:
        return "DefaultMovies.png"
    if "serien" in name or "tvshow" in name:
        return "DefaultTVShows.png"
    if "search" in name:
        return "DefaultAddonsSearch.png"
    if "add" in name or "import" in name:
        return "DefaultAddSource.png"
    if "settings" in name or "backup" in name or "rename" in name or "move" in name or "remove" in name:
        return "DefaultAddonService.png"
    if "tv" in name or "favoriten" in name:
        return "DefaultVideo.png"
    return "DefaultFolder.png"


def _make_menu_item(label, icon_name, plot="", list_icon=None):
    li = xbmcgui.ListItem(label)
    _set_info_tag(li, label, plot=plot)
    preview = _menu_icon(icon_name)
    small_icon = list_icon or _standard_list_icon(icon_name)
    fanart = os.path.join(addon_paths.media_dir(ADDON), "fanart.jpg")
    li.setArt({
        "icon":      small_icon,
        "thumb":     preview,
        "poster":    preview,
        "fanart":    fanart,
        "banner":    preview,
        "landscape": preview,
        "clearlogo": preview,
    })
    li.setProperty("Fanart_Image", fanart)
    return li


def _check_for_update_async():
    """Prueft im Hintergrund ob eine neuere Addon-Version verfuegbar ist."""
    def _check():
        try:
            api.refresh_remote_config()
            config_path = api._CONFIG_CACHE_FILE
            if config_path and os.path.exists(config_path):
                import json as _j
                with open(config_path, encoding="utf-8") as _f:
                    _cfg = _j.load(_f)
                latest = _cfg.get("addon_version", "")
                current = ADDON.getAddonInfo("version")
                if latest and latest != current:
                    api.log(f"Update verfuegbar: {latest}", xbmc.LOGINFO)
                    xbmcgui.Dialog().notification(
                        ADDON_NAME, f"Update verfuegbar: v{latest}",
                        xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception as e:
            api.log(f"Update-Check: {e}", xbmc.LOGDEBUG)
    threading.Thread(target=_check, daemon=True).start()




def _expert_mode_enabled():
    return ADDON.getSetting("expert_mode").lower() in ("true", "1", "yes")


def _favorites_attention_count():
    """Schnelle lokale Statuspruefung ohne Netzwerkzugriff oder M3U-Aenderung."""
    attention = 0
    try:
        groups = gf.load_groups()
        for group in groups:
            filename = group.get("file", "")
            if not filename:
                continue
            for channel in gf.load_group_channels(filename):
                if not (channel.get("url") or "").strip():
                    attention += 1
                    continue
                status = (gf.get_source_meta(filename, channel).get("last_status") or "").lower()
                if any(word in status for word in ("defekt", "fehler", "nicht gefunden", "kein stream", "nicht erreichbar")):
                    attention += 1
    except Exception as exc:
        xbmc.log(f"[VavooTV] Systemstatus konnte nicht gelesen werden: {exc}", xbmc.LOGDEBUG)
    return attention


def favorites_help():
    topics = [
        ("Erste Schritte", "Waehlen Sie zuerst Ihre Laender aus. Oeffnen Sie danach Live TV oder importieren Sie eine vorhandene M3U-Datei als Favoritengruppe."),
        ("Sender aktualisieren", "Ein Klick auf 'Sender aktualisieren' erneuert die gespeicherten Senderdaten. Reihenfolge und Favoritengruppen bleiben erhalten."),
        ("Sender reparieren", "Verwenden Sie 'Sender reparieren', wenn ein Favorit nicht mehr funktioniert. Das Addon sucht nach einer passenden Ersatzquelle."),
        ("Quellen verwalten", "Hier koennen Sie die bevorzugte Quelle eines einzelnen Senders ansehen, wechseln oder zuruecksetzen."),
        ("Backups", "Erstellen Sie vor groesseren Aenderungen ein Backup. Die Sicherung veraendert weder EPG-ID noch Sendernamen."),
    ]
    choice = xbmcgui.Dialog().select("Hilfe", [title for title, _ in topics])
    if choice >= 0:
        title, text = topics[choice]
        xbmcgui.Dialog().textviewer(title, text)

def _live_tv_status():
    """Liefert Menuebezeichnung, Detailtext und Anzahl lokaler Auffaelligkeiten."""
    attention = _favorites_attention_count()
    if attention <= 0:
        return "Live TV", "Systemstatus: Alles in Ordnung", 0
    if attention < 5:
        return f"Live TV ({attention})", f"Systemstatus: {attention} Sender benoetigen Aufmerksamkeit", attention
    return "Live TV (!)", f"Systemstatus: {attention} Sender benoetigen Aufmerksamkeit", attention


def main_menu():
    return addon_menus.main_menu()

def favorites_manager_menu():
    """Uebersichtliche Favoritenverwaltung mit optionalem Expertenmodus."""
    xbmcplugin.setContent(HANDLE, "files")
    items = [
        ("Sender aktualisieren", "grp_sync_all_quick", False,
         "Favoritensender schnell und ohne Streamtest aktualisieren."),
        ("Sender reparieren", "grp_sync_all_defects", False,
         "Nur nicht funktionierende Favoritensender suchen und reparieren."),
        ("Sicherungen", "favorites_backups", True,
         "Favoriten, eigene Bilder und Einstellungen sichern oder wiederherstellen."),
        ("Favoriten als M3U exportieren", "export_favorites_m3u", False,
         "Favoritengruppen als M3U-Datei exportieren."),
        ("Favoriten aus M3U importieren", "grp_import_m3u", False,
         "Eine vorhandene M3U-Datei als Favoritengruppe importieren."),
    ]
    if _expert_mode_enabled():
        items.extend([
            ("Favoritengruppen anzeigen", "live_favorites", True,
             "Vorhandene Favoritengruppen und Sender oeffnen."),
            ("Senderinformationen", "favorites_channel_info", False,
             "Technische Informationen zu einem Favoritensender anzeigen."),
            ("Wartungscenter", "favorites_maintenance", True,
             "Berichte, Protokolle und lokale Pruefungen oeffnen."),
            ("Alle Sender pruefen und reparieren", "grp_sync_all_repair", False,
             "Alle Favoritensender mit Streamtest pruefen."),
        ])
    for label, action, is_folder, plot in items:
        li = _make_menu_item(label, "favoriten.png", plot)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action), li, is_folder)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def favorites_backup_menu():
    """Komfortable Sicherung und Wiederherstellung der Benutzerdaten."""
    xbmcplugin.setContent(HANDLE, "files")
    items = [
        (favorites_backup.last_backup_label(ADDON), "favorites_backup_info",
         "Informationen zur zuletzt erstellten Sicherung anzeigen."),
        ("Sicherung erstellen", "favorites_backup_create",
         "Favoriten, eigene Favoritenbilder, Einstellungen und Quellen-Metadaten als ZIP sichern."),
        ("Sicherung wiederherstellen", "favorites_backup_restore",
         "Eine zuvor erstellte Komplettsicherung aus der Sicherungsliste oder einer Datei einspielen."),
    ]
    for label, action, plot in items:
        li = _make_menu_item(label, "favoriten.png", plot)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action), li, False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def favorites_backup_info():
    return favorites_backup.show_last_backup(ADDON, ADDON_NAME)


def favorites_backup_create():
    created = favorites_backup.create_complete(ADDON, ADDON_NAME)
    if created:
        xbmc.executebuiltin("Container.Refresh")
    return created


def favorites_backup_restore():
    restored = favorites_backup.restore_complete(ADDON, ADDON_NAME)
    if restored:
        xbmc.executebuiltin("Container.Refresh")
    return restored


def favorites_maintenance_menu():
    """Lokales Wartungscenter ohne automatische Aenderungen an M3U oder EPG."""
    xbmcplugin.setContent(HANDLE, "files")
    items = [
        ("System prüfen", "favorites_maintenance_scan", False,
         "Lokale Favoritendaten pruefen, anzeigen und speichern."),
        ("Letzten Wartungsbericht anzeigen", "favorites_maintenance_report", False,
         "Den zuletzt gespeicherten lokalen Wartungsbericht anzeigen."),
        ("Änderungsprotokoll anzeigen", "favorites_activity_log", False,
         "Die letzten Aktionen des Addons anzeigen."),
        ("Änderungsprotokoll leeren", "favorites_activity_log_clear", False,
         "Das interne lokale Protokoll nach Bestaetigung leeren."),
        ("Defekte Sender suchen", "grp_sync_all_defects", False,
         "Aktuelle Streams testen und nur defekte Sender reparieren."),
        ("Alle Sender pruefen und reparieren", "grp_sync_all_repair", False,
         "Alle Favoritensender mit Streamtest und Fallback pruefen."),
        ("Standardgruppen aktualisieren", "grp_update_standard_groups", False,
         "Mitgelieferte Favoritenlisten prüfen, fehlende ergänzen und nur leere Platzhalter ersetzen."),
        ("Backup aller Favoritengruppen", "grp_backup", False,
         "Vor Wartungsarbeiten eine Sicherung anlegen."),
    ]
    for label, action, is_folder, plot in items:
        li = _make_menu_item(label, "favoriten.png", plot)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action), li, is_folder)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _maintenance_channel_key(channel):
    return favorites_maintenance._channel_key(channel)



def favorites_maintenance_scan():
    return favorites_maintenance.scan(ADDON, ADDON_NAME, gf, _MAINTENANCE_REPORT_FILE, _append_internal_log)


def favorites_channel_info():
    return favorites_sources.channel_info(
        ADDON_NAME, gf, _manual_select_single_favorite,
        lambda filename, pos: _sync_single_favorite(filename, pos, mode="quick"),
        lambda filename, pos: _sync_single_favorite(filename, pos, mode="repair"),
    )



def favorites_source_manager():
    return favorites_sources.source_manager(ADDON_NAME, gf)



def live_tv_menu():
    return addon_menus.live_tv_menu()

def _sync_favorite_groups(group_file="", force_reload=True, mode="quick"):
    """Kompatibilitäts-Wrapper für Gruppenaktualisierung und Reparatur."""
    return favorites_repair.sync_favorite_groups(
        group_file, force_reload, mode,
        addon_name=ADDON_NAME,
        api_module=api,
        group_favs=gf,
        get_active_countries=get_active_countries,
        append_internal_log=_append_internal_log,
    )




def _sync_single_favorite(group_file, channel_index, mode="quick"):
    """Kompatibilitäts-Wrapper für die Aktualisierung eines Senders."""
    return favorites_repair.sync_single_favorite(
        group_file, channel_index, mode,
        addon_name=ADDON_NAME,
        api_module=api,
        group_favs=gf,
        get_active_countries=get_active_countries,
    )



def _show_single_favorite_source_info(group_file, channel_index):
    try:
        channel_index = int(channel_index)
    except (TypeError, ValueError):
        return False
    channels = gf.load_group_channels(group_file)
    if channel_index < 0 or channel_index >= len(channels):
        return False
    return favorites_sources.show_source_information(
        ADDON_NAME, gf, group_file, channels[channel_index]
    )


def _manual_select_single_favorite(group_file, channel_index):
    """Kompatibilitäts-Wrapper für die manuelle Quellenauswahl."""
    return favorites_repair.manual_select_single_favorite(
        group_file, channel_index,
        addon_name=ADDON_NAME,
        api_module=api,
        group_favs=gf,
        get_active_countries=get_active_countries,
        append_internal_log=_append_internal_log,
    )


def live_favorites():
    xbmcplugin.setContent(HANDLE, "files")
    if not _scan_done_this_session():
        # Neue Paketlisten übernehmen. Bereits befüllte Benutzerlisten bleiben
        # geschützt; nur fehlende Dateien und leere Platzhalter werden ergänzt.
        supplemented = gf.sync_bundled_m3u()
        if supplemented:
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                "{} Favoritenliste(n) ergänzt.".format(supplemented),
                xbmcgui.NOTIFICATION_INFO,
                3500,
            )

        # Wirklich unbekannte Dateinamen weiterhin zur Registrierung anbieten.
        if gf._scan_unregistered_m3u():
            gf.register_unregistered_m3u(ADDON_NAME)
        _mark_scan_done()

    groups = gf.load_groups()

    for g in groups:
        icon_path = gf.get_group_icon_optional(g["file"])
        li = xbmcgui.ListItem(g["name"])
        _set_info_tag(li, g["name"])
        if icon_path:
            li.setArt({
                "icon": icon_path,
                "thumb": icon_path,
                "poster": icon_path,
                "fanart": icon_path,
            })
            li.setProperty("Fanart_Image", icon_path)
        else:
            li.setArt({
                "icon": "DefaultFolder.png",
                "thumb": "DefaultFolder.png",
                "poster": "DefaultFolder.png",
                "fanart": "DefaultFolder.png",
            })
        cm = [
            ("Gruppe verwalten ...", f"RunPlugin({build_url(action='ctx_group', file=g['file'], gname=g['name'])})"),
            ("Gruppe aktualisieren / reparieren ...", f"RunPlugin({build_url(action='ctx_group_sync', file=g['file'], gname=g['name'])})"),
        ]
        li.addContextMenuItems(cm)
        # Favoritengruppen als echte Kodi-Ordner eintragen. Nur so öffnet
        # Kodi die Gruppenansicht zuverlässig und führt den Verzeichnis-
        # Verlauf korrekt. Estuary verwendet für echte Ordner sein eigenes
        # kleines Ordnersymbol; das individuelle favo_icon bleibt als große
        # Vorschau (Poster/Fanart) erhalten.
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(action="grp_show", file=g["file"], gname=g["name"]),
            li, True
        )

    # Einziger fester Button: Neue Gruppe – wird gebraucht wenn Liste noch leer ist
    _ico_add = addon_paths.media_icon_path(ADDON, "grp_add.png")
    li_new = xbmcgui.ListItem("[Neue Gruppe erstellen]")
    _set_info_tag(li_new, "Neue Gruppe erstellen")
    li_new.setArt({"icon": "DefaultAddSource.png", "thumb": _ico_add, "poster": _ico_add, "fanart": _ico_add})
    li_new.setProperty("Fanart_Image", _ico_add)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="grp_create"), li_new, False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def export_favorite_group_m3u(group_file, group_name):
    """Exportiert genau die aktuell geöffnete Favoritengruppe unverändert als M3U."""
    if not group_file:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Favoritengruppe angegeben.")
        return False

    try:
        source_path = os.path.join(gf._favgroups_dir(), os.path.basename(group_file))
        if not os.path.exists(source_path):
            xbmcgui.Dialog().ok(ADDON_NAME, "Die Favoritengruppe wurde nicht gefunden.")
            return False
        with open(source_path, "r", encoding="utf-8", errors="ignore") as handle:
            content = handle.read()
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Fehler beim Lesen der Favoritengruppe\n{exc}")
        return False

    import datetime
    date_str = datetime.date.today().strftime("%Y-%m-%d")
    safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", group_name or os.path.splitext(os.path.basename(group_file))[0]).strip("_")
    filename = f"VavooTV-{safe_name or 'Favoritengruppe'}-{date_str}.m3u"
    return _save_m3u_file(content, filename)


def grp_play(group_file, group_name):
    grp_show(group_file, group_name)


def _group_workspace_context_menu(group_file, group_name):
    """Group-wide actions via a compact selection dialog."""
    return [("Gruppenfunktionen ...", f"RunPlugin({build_url(action='ctx_workspace', file=group_file, gname=group_name)})")]


def _context_choice(title, entries):
    """Show Kodi's native selector and invoke the original route unchanged."""
    selection = xbmcgui.Dialog().select(title, [label for label, _ in entries])
    if 0 <= selection < len(entries):
        xbmc.executebuiltin("RunPlugin({})".format(build_url(**entries[selection][1])))


def context_actions(params):
    action = params.get("action", "")
    file = params.get("file", "")
    idx = params.get("idx", -1)
    gname = params.get("gname", "")
    name = params.get("name", "")
    url = params.get("url", "")
    if action == "ctx_channel_move":
        entries = [(label, dict(action="grp_ch_move", file=file, idx=idx, direction=direction)) for label, direction in
                   [("Nach oben", "up"), ("Nach unten", "down"), ("Ganz nach oben", "top"), ("Ganz nach unten", "bottom")]]
    elif action == "ctx_channel_repair":
        entries = [("Schnell aktualisieren", dict(action="grp_ch_sync_quick", file=file, idx=idx)),
                   ("Prüfen und reparieren", dict(action="grp_ch_sync_repair", file=file, idx=idx)),
                   ("Sender manuell auswählen", dict(action="grp_ch_select_manual", file=file, idx=idx))]
    elif action == "ctx_channel_more":
        entries = [("Zu anderer Gruppe hinzufügen", dict(action="grp_ch_add", name=name, url=url)),
                   ("Sender manuell auswählen", dict(action="grp_ch_select_manual", file=file, idx=idx)),
                   ("Sender schnell aktualisieren", dict(action="grp_ch_sync_quick", file=file, idx=idx))]
    elif action == "ctx_group_sync":
        entries = [(label, dict(action=route, **kwargs)) for label, route, kwargs in [
            ("Diese Gruppe schnell aktualisieren", "grp_sync_quick", {"file": file}),
            ("Diese Gruppe prüfen und reparieren", "grp_sync_repair", {"file": file}),
            ("Defekte Sender dieser Gruppe suchen", "grp_sync_defects", {"file": file}),
            ("Alle Gruppen schnell aktualisieren", "grp_sync_all_quick", {}),
            ("Alle Gruppen prüfen und reparieren", "grp_sync_all_repair", {}),
            ("Defekte Sender aller Gruppen suchen", "grp_sync_all_defects", {})]]
    elif action == "ctx_group":
        entries = [("Gruppe verschieben ...", dict(action="ctx_group_move", file=file)),
                   ("Gruppe umbenennen", dict(action="grp_rename", file=file, gname=gname)),
                   ("Gruppenbild ändern", dict(action="grp_set_icon", file=file)),
                   ("M3U verwalten ...", dict(action="ctx_group_m3u", file=file, gname=gname)),
                   ("Weitere Gruppenfunktionen ...", dict(action="ctx_group_more", file=file, gname=gname)),
                   ("Gruppe entfernen", dict(action="grp_remove", file=file, gname=gname))]
    elif action == "ctx_group_move":
        entries = [("Gruppe nach oben", dict(action="grp_move", file=file, direction="up")),
                   ("Gruppe nach unten", dict(action="grp_move", file=file, direction="down"))]
    elif action == "ctx_group_m3u":
        entries = [("M3U importieren (eine)", dict(action="grp_import_m3u", file=file)),
                   ("M3U importieren (mehrere)", dict(action="grp_import_m3u_multi")),
                   ("M3U erkennen", dict(action="grp_scan_m3u")),
                   ("Gruppe als M3U exportieren", dict(action="grp_export_m3u", file=file, gname=gname))]
    elif action == "ctx_group_more":
        entries = [("Neue Gruppe erstellen", dict(action="grp_create")),
                   ("Backup aller Gruppen", dict(action="grp_backup")),
                   ("Gruppe schnell aktualisieren", dict(action="grp_sync_quick", file=file)),
                   ("Alle Gruppen aktualisieren", dict(action="grp_sync_all_quick"))]
    elif action == "ctx_workspace":
        entries = [("Sender aktualisieren", dict(action="grp_sync_quick", file=file, gname=gname)),
                   ("Sender reparieren", dict(action="grp_sync_defects", file=file, gname=gname)),
                   ("Gruppe umbenennen", dict(action="grp_rename", file=file, gname=gname)),
                   ("Gruppe als M3U exportieren", dict(action="grp_export_m3u", file=file, gname=gname))]
    else:
        return
    _context_choice("Vavoo TV Plus – " + {"ctx_channel_move":"Sender verschieben", "ctx_channel_repair":"Sender reparieren", "ctx_channel_more":"Weitere Senderaktionen", "ctx_group_sync":"Aktualisieren / reparieren", "ctx_group":"Gruppe verwalten", "ctx_group_move":"Gruppe verschieben", "ctx_group_m3u":"M3U verwalten", "ctx_group_more":"Weitere Gruppenfunktionen", "ctx_workspace":"Gruppenfunktionen"}.get(action, "Optionen"), entries)



def _safe_epg_id(name, stored_id=""):
    """Never trust a persisted tvg-id over the sender's verified identity."""
    expected = api.get_channel_epg_id(name) or ""
    stored_id = (stored_id or "").strip()
    if stored_id and stored_id != expected:
        api.log("EPG-ID verworfen fuer {}: {} (erwartet {})".format(name, stored_id, expected or "leer"), xbmc.LOGWARNING)
    return expected


def grp_show(group_file, group_name):
    """Zeigt die Sender einer Favoritengruppe als navigierbare Liste."""
    try:
        _ensure_epg_loaded()
        channels = gf.load_group_channels(group_file)
    except Exception as exc:
        xbmc.log("[VavooTV] Favoritengruppe konnte nicht geladen werden: {}".format(exc), xbmc.LOGERROR)
        channels = []

    # Wie bei Kodis Standard-Navigatoren kein spezieller Content-Typ: Dadurch
    # verwendet der Skin fuer den automatisch erzeugten ``..``-Eintrag sein
    # eigenes DefaultFolderBack.png.
    xbmcplugin.setContent(HANDLE, "")

    _add_preview = addon_paths.media_icon_path(ADDON, "add_channel.png")
    li_add = xbmcgui.ListItem("Sender hinzufügen")
    _set_info_tag(li_add, "Sender hinzufügen", plot=f"Sender direkt zur Favoritengruppe '{group_name}' hinzufügen.")
    li_add.setArt({"poster": _add_preview, "icon": "DefaultAddSource.png"})
    li_add.setProperty("Fanart_Image", _add_preview)
    li_add.setIsFolder(True)
    li_add.addContextMenuItems(_group_workspace_context_menu(group_file, group_name))
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url(action="grp_add_multi", file=group_file, gname=group_name),
        li_add,
        True
    )

    if channels:
        _search_preview = addon_paths.media_icon_path(ADDON, "search_channel.png")
        li_search = xbmcgui.ListItem("Sender suchen")
        _set_info_tag(li_search, "Sender suchen", plot="Sender in dieser Gruppe nach Name filtern.")
        li_search.setArt({"poster": _search_preview, "icon": "DefaultPVRSearch.png"})
        li_search.setProperty("Fanart_Image", _search_preview)
        li_search.setIsFolder(True)
        li_search.addContextMenuItems(_group_workspace_context_menu(group_file, group_name))
        xbmcplugin.addDirectoryItem(
            HANDLE, build_url(action="grp_search", file=group_file, gname=group_name), li_search, True)

    _url_count = {}
    for _ch in channels:
        _u = _ch.get("url", "")
        if _u:
            _url_count[_u] = _url_count.get(_u, 0) + 1

    for i, ch in enumerate(channels):
        try:
            name   = ch.get("name", "")
            url    = ch.get("url", "")
            if not name or not url:
                continue
            tvg_id = _safe_epg_id(name, ch.get("tvg_id", ""))
            logo   = ch.get("logo", "")   or api.get_channel_logo(name)   or DEFAULT_ICON
            _dup   = " [gleicher Stream]" if _url_count.get(url, 1) > 1 else ""
            plot   = _dup

            li = _make_channel_list_item(name, logo, plot or _dup, tvg_id=tvg_id)
            li.setProperty("IsPlayable", "true")

            cm = [
                ("Sender verschieben ...", f"RunPlugin({build_url(action='ctx_channel_move', file=group_file, idx=i)})"),
                ("Sender aktualisieren / reparieren ...", f"RunPlugin({build_url(action='ctx_channel_repair', file=group_file, idx=i)})"),
                ("In andere Gruppe verschieben", f"RunPlugin({build_url(action='grp_ch_move_to', file=group_file, idx=i)})"),
                ("Sender umbenennen", f"RunPlugin({build_url(action='grp_ch_rename', file=group_file, idx=i)})"),
                ("Quelleninformation", f"RunPlugin({build_url(action='grp_ch_source_info', file=group_file, idx=i)})"),
                ("Weitere Senderaktionen ...", f"RunPlugin({build_url(action='ctx_channel_more', file=group_file, idx=i, name=name, url=url)})"),
                ("Aus Gruppe entfernen", f"RunPlugin({build_url(action='grp_ch_remove', file=group_file, idx=i)})"),
            ]
            li.addContextMenuItems(cm)

            xbmcplugin.addDirectoryItem(
                HANDLE, _play_url(name, url, tvg_id, logo), li, False)

        except Exception as exc:
            xbmc.log("[VavooTV] Favoriteneintrag {} konnte nicht angezeigt werden: {}".format(i, exc), xbmc.LOGWARNING)
            continue

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def grp_search(group_file, group_name):
    """Suche innerhalb einer Favoritengruppe."""
    channels = gf.load_group_channels(group_file)
    if not channels:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Sender in dieser Gruppe.")
        return

    kb = xbmc.Keyboard("", f"Suche in '{group_name}'")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip().lower()
    if not query:
        return

    matches = [ch for ch in channels if query in ch.get("name", "").lower()]
    if not matches:
        xbmcgui.Dialog().notification(ADDON_NAME, f"Keine Treffer für '{query}'",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        return

    _ensure_epg_loaded()
    xbmcplugin.setContent(HANDLE, "files")

    for ch in matches:
        name   = ch.get("name", "")
        url    = ch.get("url", "")
        if not name or not url:
            continue
        tvg_id = _safe_epg_id(name, ch.get("tvg_id", ""))
        logo   = ch.get("logo", "")   or api.get_channel_logo(name)   or DEFAULT_ICON
        plot   = _epg_plot(name, tvg_id)
        li     = _make_channel_list_item(name, logo, plot, tvg_id=tvg_id)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            HANDLE, _play_url(name, url, tvg_id, logo), li, False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _picker_search_key(value):
    """Ignore punctuation and whitespace, but keep source numbers."""
    return "".join(c for c in value.casefold() if c.isalnum())


def grp_catalog_picker(group_file, group_name, country="", query="", ask=False):
    """Full alphabetical catalogue with persistent favorite toggles."""
    if not country:
        countries = api.get_available_countries()
        idx = xbmcgui.Dialog().select("Ländergruppe wählen", countries)
        if idx < 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        country = countries[idx]
    if ask:
        kb = xbmc.Keyboard(query, "Sender suchen")
        kb.doModal()
        if not kb.isConfirmed():
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        query = kb.getText().strip()
    channels = api.fetch_channels_for_group(country)
    existing = gf.load_group_channels(group_file)
    urls = {c.get("url") for c in existing}
    names = {c.get("name") for c in existing}
    base = dict(file=group_file, gname=group_name, country=country)
    xbmcplugin.setContent(HANDLE, "files")
    def control(label, **params):
        li = xbmcgui.ListItem(label)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(**base, **params), li, True)
    control("Sender suchen", action="grp_catalog_search", q=query)
    if query:
        control("Suche zurücksetzen", action="grp_catalog_picker")
    key = _picker_search_key(query)
    count = 0
    for name, sources in sorted(channels.items(), key=lambda item: item[0].casefold()):
        if not sources or (key and key not in _picker_search_key(name)):
            continue
        url = sources[0]
        checked = name in names or url in urls
        li = xbmcgui.ListItem(f"[COLOR gold]* {name}[/COLOR]" if checked else name)
        li.setProperty("IsPlayable", "false")
        target = build_url(action="grp_catalog_toggle", **base, name=name, url=url, q=query)
        li.addContextMenuItems([("Aus Gruppe entfernen" if checked else "Zu Gruppe hinzufügen", "RunPlugin(" + target + ")")])
        xbmcplugin.addDirectoryItem(HANDLE, target, li, False)
        count += 1
    if not count:
        xbmcgui.Dialog().notification(ADDON_NAME, "Keine passenden Sender gefunden", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def grp_catalog_toggle(group_file, name, url):
    if not group_file or not name or not url:
        return
    existing = gf.load_group_channels(group_file)
    matches = [i for i, c in enumerate(existing) if c.get("url") == url or c.get("name") == name]
    if matches:
        # Remove only the selected entry, not other source variants.
        existing.pop(matches[0])
    else:
        existing.append(dict(name=name, url=url, logo="", tvg_id=api.get_channel_epg_id(name) or ""))
    if gf.save_group_channels(group_file, existing, ADDON.getSetting("epg_url").strip()):
        xbmc.executebuiltin("Container.Refresh")


def _favorites_add_multiselect():
    all_countries = api.get_available_countries()
    selected      = get_active_countries(all_countries)

    if not selected:
        xbmcgui.Dialog().ok(ADDON_NAME,
            "Keine Laendergruppen ausgewaehlt.\n"
            "Bitte zuerst unter Einstellungen Laendergruppen auswaehlen.")
        return

    country_idx = xbmcgui.Dialog().select("Laendergruppe waehlen", selected)
    if country_idx < 0:
        return

    group = selected[country_idx]

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Lade Sender fuer {group} ...")
    channels = api.fetch_channels_for_group(group)
    progress.close()

    if not channels:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Keine Sender fuer '{group}' gefunden.")
        return

    existing_favs = {f.get("name") for f in _load_favorites()
                     if f.get("type", "channel") == "channel"}
    sorted_names  = sorted(channels.keys())

    labels    = []
    preselect = []
    for i, name in enumerate(sorted_names):
        if name in existing_favs:
            labels.append(f"[COLOR gold]{name}[/COLOR]")
            preselect.append(i)
        else:
            labels.append(name)

    chosen = xbmcgui.Dialog().multiselect(
        f"Sender auswahlen – {group}",
        labels,
        preselect=preselect
    )
    if chosen is None:
        return

    chosen_names = {sorted_names[i] for i in chosen}
    group_names  = set(sorted_names)

    favs = _load_favorites()
    favs = [f for f in favs
            if f.get("type") == "marker"
            or f.get("name") not in group_names
            or f.get("name") in chosen_names]
    existing_now = {f.get("name") for f in favs}
    for name in sorted_names:
        if name in chosen_names and name not in existing_now:
            favs.append({"type": "channel", "name": name, "url": channels[name][0]})

    _save_favorites(favs)

    added   = len(chosen_names - existing_favs)
    removed = len((existing_favs & group_names) - chosen_names)
    parts   = []
    if added:   parts.append(f"{added} hinzugefuegt")
    if removed: parts.append(f"{removed} entfernt")
    if not parts: parts.append("Keine Aenderungen")

    xbmcgui.Dialog().notification(ADDON_NAME, " | ".join(parts),
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def _favorites_add_marker():
    kb = xbmc.Keyboard("", "Marker-Text eingeben (z.B. --- Sport ---)")
    kb.doModal()
    if not kb.isConfirmed():
        return
    text = kb.getText().strip()
    if not text:
        return
    favs = _load_favorites()
    favs.append({"type": "marker", "name": text})
    _save_favorites(favs)
    xbmcgui.Dialog().notification(ADDON_NAME, f"Marker gespeichert: {text}",
                                  xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _fav_path():
    return os.path.join(
        xbmcvfs.translatePath(ADDON.getAddonInfo("profile")),
        "live_favorites.m3u"
    )

def _handle_favorites_epg_url(epg_url):
    current_setting = ADDON.getSetting("epg_url").strip()
    if not epg_url or epg_url == current_setting:
        return
    if xbmcgui.Dialog().yesno(
        ADDON_NAME,
        f"EPG-Quelle in der M3U gefunden:\n{epg_url}\n\nJetzt als EPG-Quelle übernehmen?"
    ):
        ADDON.setSetting("epg_url", epg_url)
        xbmcgui.Dialog().notification(
            ADDON_NAME, "EPG-Quelle gespeichert",
            xbmcgui.NOTIFICATION_INFO, 2000
        )


def _load_favorites():
    from favorites.reader import load_favorites
    return load_favorites(
        _fav_path(),
        save_callback=_save_favorites,
        epg_url_callback=_handle_favorites_epg_url,
    )


def _save_favorites(favs):
    from favorites.writer import save_favorites
    try:
        save_favorites(_fav_path(), favs, api.get_channel_epg_id)
    except Exception as e:
        api.log(f"_save_favorites error: {e}", xbmc.LOGERROR)

def live_countries(countries_param):
    xbmcplugin.setContent(HANDLE, "files")
    all_countries = api.get_available_countries()
    countries     = _parse_countries_param(countries_param, all_countries)

    for country in countries:
        code      = api.country_to_code(country)
        label     = f"[{code}]  {country}" if code else country
        li        = xbmcgui.ListItem(label)
        _set_info_tag(li, country)
        flag_name = code.lower() if code else country.lower().replace(" ", "_")
        flag_path = addon_paths.country_flag_path(ADDON, flag_name)
        li.setArt({"icon": flag_path, "thumb": flag_path, "fanart": flag_path})
        li.addContextMenuItems([
            ("M3U exportieren",
             f"RunPlugin({build_url(action='export_m3u', group=country)})"),
            ("Senderliste aktualisieren",
             f"RunPlugin({build_url(action='refresh_channels', group=country)})"),
        ])
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(action="channels", group=country),
            li, True
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def live_genres(countries_param):
    xbmcplugin.setContent(HANDLE, "files")
    all_countries = api.get_available_countries()
    countries     = _parse_countries_param(countries_param, all_countries)

    sig = api.get_auth_signature()
    if not sig:
        xbmcgui.Dialog().ok(ADDON_NAME, "Authentifizierung fehlgeschlagen.")
        return

    all_channels = {}
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Lade Kanäle …")

    for i, country in enumerate(countries):
        if progress.iscanceled():
            break
        progress.update(int(i / max(len(countries), 1) * 90), f"Lade {country} …")
        all_channels.update(api.fetch_channels_for_group(country))

    progress.update(95, "Sortiere nach Genre …")
    genres = api.group_channels_by_genre(all_channels)
    progress.close()

    if not genres:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Kanäle gefunden.")
        return

    for genre, ch_dict in genres.items():
        li = xbmcgui.ListItem(f"{genre}  ({len(ch_dict)})")
        _set_info_tag(li, genre)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(action="genre_channels", genre=genre, countries=countries_param),
            li, True
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def live_az(countries_param):
    xbmcplugin.setContent(HANDLE, "files")
    all_countries = api.get_available_countries()
    countries     = _parse_countries_param(countries_param, all_countries)

    sig = api.get_auth_signature()
    if not sig:
        xbmcgui.Dialog().ok(ADDON_NAME, "Authentifizierung fehlgeschlagen.")
        return

    all_channels = {}
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Lade Kanäle …")

    for i, country in enumerate(countries):
        if progress.iscanceled():
            break
        progress.update(int(i / max(len(countries), 1) * 95), f"Lade {country} …")
        all_channels.update(api.fetch_channels_for_group(country))

    progress.close()

    if not all_channels:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Kanäle gefunden.")
        return

    buckets = {}
    for name in all_channels:
        first = name[0].upper() if name else "#"
        if not first.isalpha():
            first = "#"
        buckets.setdefault(first, {})[name] = all_channels[name]

    _ensure_epg_loaded()
    for letter in sorted(buckets.keys()):
        ch_dict = buckets[letter]
        li = xbmcgui.ListItem(f"{letter}  ({len(ch_dict)})")
        _set_info_tag(li, letter)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(action="az_channels", letter=letter, countries=countries_param),
            li, True
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _parse_countries_param(countries_param, all_countries):
    if not countries_param:
        return get_active_countries(all_countries)
    return [c for c in countries_param.split(",") if c]


def _render_genre_overview(countries):
    sig = api.get_auth_signature()
    if not sig:
        err = api._auth_cache.get("last_error", "Unbekannt")
        xbmcgui.Dialog().ok(ADDON_NAME, f"Authentifizierung fehlgeschlagen:\n{err}")
        return

    all_channels = {}
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Lade Kanäle …")

    for i, country in enumerate(countries):
        if progress.iscanceled():
            break
        pct = int((i / max(len(countries), 1)) * 90)
        progress.update(pct, f"Lade {country} …")
        ch = api.fetch_channels_for_group(country)
        all_channels.update(ch)

    progress.update(95, "Klassifiziere Genres …")
    genres = api.group_channels_by_genre(all_channels)
    progress.close()

    if not genres:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Kanäle gefunden.")
        return

    for genre, ch_dict in genres.items():
        genre_label = genre.split("  ", 1)[-1] if "  " in genre else genre
        li = xbmcgui.ListItem(f"{genre_label}  ({len(ch_dict)})")
        _set_info_tag(li, genre_label)
        countries_param = ",".join(countries)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(action="genre_channels", genre=genre, countries=countries_param),
            li, True
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def show_genre_channels(genre, countries_param):
    """
    Zeigt Genre-Kanaele als navigierbare Senderliste.
    """
    countries = [c for c in countries_param.split(",") if c]

    sig = api.get_auth_signature()
    if not sig:
        xbmcgui.Dialog().ok(ADDON_NAME, "Authentifizierung fehlgeschlagen.")
        return

    all_channels = {}
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Lade Kanäle für {genre} …")

    for i, country in enumerate(countries):
        if progress.iscanceled():
            break
        pct = int((i / max(len(countries), 1)) * 90)
        progress.update(pct, f"Lade {country} …")
        ch = api.fetch_channels_for_group(country)
        all_channels.update(ch)

    progress.update(95, "Filtere Genre …")
    genres   = api.group_channels_by_genre(all_channels)
    progress.close()

    channels = genres.get(genre, {})
    if not channels:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Keine Kanäle im Genre '{genre}' gefunden.")
        return

    _ensure_epg_loaded()
    xbmcplugin.setContent(HANDLE, "files")

    ordered_channels  = sorted(channels.items())
    playlist_channels = [
        {
            "name":   name,
            "url":    urls[0],
            "logo":   api.get_channel_logo(name) or "",
            "tvg_id": api.get_channel_epg_id(name) or "",
        }
        for name, urls in ordered_channels if urls
    ]

    for ch in playlist_channels:
        name   = ch["name"]
        url    = ch["url"]
        tvg_id = ch["tvg_id"]
        logo   = ch["logo"] or DEFAULT_ICON
        plot   = _epg_plot(name, tvg_id)
        li     = _make_channel_list_item(name, logo, plot, tvg_id=tvg_id)
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems([
            ("Zu Gruppe hinzufügen",
             f"RunPlugin({build_url(action='grp_ch_add', name=name, url=url)})"),
        ])
        xbmcplugin.addDirectoryItem(
            HANDLE, _play_url(name, url, tvg_id, logo), li, False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _render_country_list(countries, all_countries):
    for country in countries:
        code      = api.country_to_code(country)
        label     = f"[{code}]  {country}" if code else country
        li        = xbmcgui.ListItem(label)
        _set_info_tag(li, country)
        flag_name = code.lower() if code else country.lower().replace(" ", "_")
        flag_path = addon_paths.country_flag_path(ADDON, flag_name)
        li.setArt({"icon": flag_path, "thumb": flag_path, "fanart": flag_path})
        li.addContextMenuItems([
            ("M3U exportieren",
             f"RunPlugin({build_url(action='export_m3u', group=country)})"),
            ("Senderliste aktualisieren",
             f"RunPlugin({build_url(action='refresh_channels', group=country)})"),
        ])
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(action="channels", group=country),
            li, True
        )
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _set_info_tag(li, title, genre="", media_type="video",
                  plot="", season=None, episode=None):
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        if genre:
            tag.setGenres([genre])
        if plot:
            tag.setPlot(plot)
        if media_type == "tvshow":
            tag.setMediaType("tvshow")
        elif media_type == "episode":
            tag.setMediaType("episode")
            if season is not None:
                tag.setSeason(int(season))
            if episode is not None:
                tag.setEpisode(int(episode))
        elif media_type == "movie":
            tag.setMediaType("movie")
    except (AttributeError, TypeError, ValueError) as exc:
        api.log(f"InfoTagVideo metadata skipped: {exc}", xbmc.LOGWARNING)


def _make_li(label, is_folder=False):
    li = xbmcgui.ListItem(label)
    _set_info_tag(li, label)
    return li


def show_channels(group):
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Authentifiziere …")

    sig = api.get_auth_signature()
    if not sig:
        progress.close()
        err = api._auth_cache.get("last_error", "Unbekannt")
        xbmcgui.Dialog().ok(ADDON_NAME, f"[B]Authentifizierung fehlgeschlagen[/B]\n\nFehler: {err}")
        return

    progress.update(40, f"Lade Kanäle für {group} …")
    hours = int(ADDON.getSetting("cache_channels_hours") or "3")
    api.CHANNEL_CACHE_TTL = hours * 3600
    channels = api.fetch_channels_for_group(group)
    progress.close()

    if not channels:
        xbmcgui.Dialog().ok(ADDON_NAME,
            f"Keine Kanäle für '{group}' gefunden.\nDebug-Log prüfen oder Kanäle aktualisieren.")
        return

    view_mode = ADDON.getSetting("view_mode")

    if view_mode == "2":
        genres = api.group_channels_by_genre(channels)

        xbmcplugin.addDirectoryItem(HANDLE,
            build_url(action="refresh_channels", group=group),
            _make_li("Kanäle aktualisieren"), False)

        xbmcplugin.addDirectoryItem(HANDLE,
            build_url(action="channels_flat", group=group),
            _make_li(f"Alle Kanäle  ({len(channels)})"), False)

        for genre, ch_dict in genres.items():
            li = xbmcgui.ListItem(f"{genre}  ({len(ch_dict)})")
            _set_info_tag(li, genre, genre)
            xbmcplugin.addDirectoryItem(HANDLE,
                build_url(action="genre_channels", genre=genre, countries=group),
                li, True)

        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    else:
        _render_channel_list(channels)


def _epg_meta(result):
    if isinstance(result, (list, tuple)) and len(result) >= 7:
        return {
            "title":      result[0] if result[0] else "",
            "desc":       result[1] if result[1] else "",
            "start":      result[2] if result[2] else "",
            "stop":       result[3] if result[3] else "",
            "remaining":  result[4] if result[4] else "",
            "next_title": result[5] if result[5] else "",
            "next_time":  result[6] if result[6] else "",
        }
    return {
        "title": "", "desc": "", "start": "", "stop": "",
        "remaining": "", "next_title": "", "next_time": "",
    }


def _get_epg_meta_for_channel(name, tvg_id=""):
    if not api.epg_show_enabled():
        return _epg_meta(())

    if not api._epg_cache:
        api.log(f"EPG-Plot: Cache leer fuer {name}", xbmc.LOGDEBUG)
        return _epg_meta(())

    epg_id = _safe_epg_id(name, tvg_id)
    api.log(f"EPG-Plot: name={name} epg_id={epg_id} cache_size={len(api._epg_cache)}", xbmc.LOGINFO)

    meta = _epg_meta(api.get_current_programme(epg_id)) if epg_id else _epg_meta(())
    return meta


def _epg_list_label(name, tvg_id=""):
    label, _label2 = _epg_list_labels(name, tvg_id)
    return label


def _truncate_epg_text(text, max_len=72):
    text = (text or "").strip()
    if not text or len(text) <= max_len:
        return text
    return text[:max_len - 1].rstrip() + "…"


def _pad_epg_column(text, width):
    text = (text or "").strip()
    if len(text) > width:
        return text[:width - 1].rstrip() + "…"
    return text.ljust(width)


def _epg_list_labels(name, tvg_id=""):
    meta      = _get_epg_meta_for_channel(name, tvg_id)
    title     = (meta.get("title", "") or "").strip()
    start     = (meta.get("start", "") or "").strip()
    stop      = (meta.get("stop",  "") or "").strip()
    remaining = (meta.get("remaining", "") or "").strip()

    if not title:
        return name, ""

    time_part     = f"{start} - {stop}" if start and stop else ""
    display_name  = _truncate_epg_text(name, 18)
    display_title = _truncate_epg_text(title, 42)
    bullet        = "[COLOR FF7F8FA6] • [/COLOR]"
    time_color    = "FFF3F8FF"
    title_color   = "FFF7FBFF"
    remaining_color = "FFFFCC33"

    parts = [display_name]
    if time_part:
        parts.append(f"{bullet}[COLOR {time_color}]{time_part}[/COLOR]")
    parts.append(f"{bullet}[COLOR {title_color}]{display_title}[/COLOR]")

    label = "".join(parts)
    if remaining:
        label = f"{label}  [COLOR {remaining_color}]noch {remaining}[/COLOR]"

    return label, ""


def _make_channel_list_item(name, logo, plot, genre="", tvg_id=""):
    label, label2 = _epg_list_labels(name, tvg_id)
    display_title = label

    li = xbmcgui.ListItem(label=label, label2=label2)
    try:
        li.setLabel(label)
        if label2:
            li.setLabel2(label2)
    except Exception:
        pass

    li.setArt({"icon": logo, "thumb": logo, "poster": logo, "fanart": logo, "clearlogo": logo})
    _set_info_tag(li, display_title, genre, plot=plot)

    try:
        tag = li.getVideoInfoTag()
        tag.setSortTitle(name)
        tag.setOriginalTitle(name)
        if hasattr(tag, 'setTvShowTitle'):
            tag.setTvShowTitle(name)
    except Exception:
        pass

    li.setProperty("ChannelName", name)
    li.setProperty("ListItem.ChannelName", name)
    li.setProperty("ListItem.Title", display_title)
    li.setProperty("VideoPlayer.Title", display_title)
    li.setProperty("Addon.DisplayTitle", display_title)
    if label2:
        li.setProperty("Addon.Label2", label2)
        li.setProperty("Addon.EPG", label2)
        li.setProperty("PlotOutline", label2)
        li.setProperty("ListItem.Label2", label2)
    return li


def _epg_plot(name, tvg_id=""):
    meta      = _get_epg_meta_for_channel(name, tvg_id)
    title     = meta.get("title", "")
    desc      = meta.get("desc", "")
    start     = meta.get("start", "")
    stop      = meta.get("stop", "")
    remaining = meta.get("remaining", "")

    if not title:
        return ""

    header_lines = []
    if stop:
        header_lines.append(f"[B]Läuft bis {stop}[/B]")
    elif start:
        header_lines.append(f"[B]Beginn {start}[/B]")
    if remaining:
        header_lines.append(f"[COLOR FFFFCC33]Noch {remaining}[/COLOR]")

    header = "\n".join(header_lines)
    plot = f"{header}\n{title}" if header else title
    if desc:
        plot += f"\n\n{desc}"
    return plot


_epg_load_thread = None

def _ensure_epg_loaded():
    """Startet EPG-Ladevorgang im Hintergrund-Thread (nicht-blockierend)."""
    global _epg_load_thread
    epg_url = _get_epg_url()
    if not epg_url:
        return
    if api._epg_cache or api._epg_load_attempted:
        return
    if _epg_load_thread and _epg_load_thread.is_alive():
        return
    def _load():
        api.log(f"EPG: Lade im Hintergrund von {epg_url}", xbmc.LOGINFO)
        api.fetch_epg(epg_url)
        api.log(f"EPG: {len(api._epg_cache)} Kanäle geladen", xbmc.LOGINFO)
    _epg_load_thread = threading.Thread(target=_load, daemon=True)
    _epg_load_thread.start()
def _render_channel_list(channels):
    """Rendert eine navigierbare Senderliste (dict name→[urls])."""
    _ensure_epg_loaded()
    xbmcplugin.setContent(HANDLE, "files")
    for name, urls in sorted(channels.items()):
        try:
            if not urls:
                continue
            url    = urls[0]
            tvg_id = api.get_channel_epg_id(name) or ""
            logo   = api.get_channel_logo(name)   or DEFAULT_ICON
            plot   = _epg_plot(name, tvg_id)
            li     = _make_channel_list_item(name, logo, plot, tvg_id=tvg_id)
            li.setProperty("IsPlayable", "true")
            li.addContextMenuItems([
                ("Zu Gruppe hinzufügen",
                 f"RunPlugin({build_url(action='grp_ch_add', name=name, url=url)})"),
            ])
            xbmcplugin.addDirectoryItem(HANDLE, _play_url(name, url, tvg_id, logo), li, False)
        except Exception as exc:
            api.log("Senderliste: {} uebersprungen: {}".format(name, exc), xbmc.LOGWARNING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)


def _handle_stream_unavailable(name):
    """Wird aufgerufen wenn Stream nicht gefunden / Timeout."""
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    choice = xbmcgui.Dialog().select(
        f"{ADDON_NAME} – Stream nicht erreichbar",
        [
            f"[B]{name}[/B] – Stream nicht verfügbar",
            "Zurück zur Senderliste",
            "Abbrechen",
        ]
    )
    # 0 = Titelzeile, 1 = Zurück, 2 = Abbrechen, -1 = ESC
    if choice == 1:
        xbmc.sleep(100)
        xbmc.executebuiltin("Action(Back)")


def play_channel(url, name="", tvg_id="", logo=""):
    play_channel_resolved(url, name, tvg_id=tvg_id, logo=logo)


def play_channel_resolved(url, name="", tvg_id="", logo=""):

    # ── Countdown-Dialog während Stream gesucht wird ──────────────────────
    try:
        timeout_sec = int(ADDON.getSetting("connection_timeout") or "15")
        timeout_sec = max(5, min(timeout_sec, 60))
    except Exception:
        timeout_sec = 15

    stream_url, stream_headers = None, {}
    import threading

    result_holder = [None, {}]
    done_event = threading.Event()

    def _resolve_thread():
        try:
            u, h = api.resolve_stream(url, name=name, tvg_id=tvg_id)
            result_holder[0] = u
            result_holder[1] = h
        except Exception as e:
            api.log(f"resolve_stream Exception: {e}", xbmc.LOGERROR)
        finally:
            done_event.set()

    t = threading.Thread(target=_resolve_thread, daemon=True)
    t.start()
    done_event.wait(timeout=timeout_sec)

    stream_url     = result_holder[0]
    stream_headers = result_holder[1]

    # Kein zweiter Resolver-Thread bei UI-Timeout: Der erste Request besitzt
    # eigene Netzwerk-Timeouts. So entstehen keine parallelen Doppelaufrufe.
    if not stream_url and not done_event.is_set():
        api.log(f"Stream Timeout: {name}", xbmc.LOGWARNING)

    if not stream_url:
        api.log(f"Stream endgueltig nicht erreichbar: {name}", xbmc.LOGWARNING)
        _handle_stream_unavailable(name)
        return

    api.log(f"Starte Wiedergabe: {stream_url[:80]}", xbmc.LOGINFO)

    if stream_headers:
        header_str = "|" + "&".join(f"{k}={url_quote(str(v))}" for k, v in stream_headers.items())
        full_url   = stream_url + header_str
    else:
        full_url = stream_url

    li = xbmcgui.ListItem(label=name, path=full_url)
    from urllib.parse import urlsplit as _urlsplit
    is_hls = _urlsplit(stream_url).path.lower().endswith(".m3u8")
    is_dash = _urlsplit(stream_url).path.lower().endswith(".mpd")
    engine = ADDON.getSetting("playback_engine") or "0"
    li.setContentLookup(False)
    if engine == "1":
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        li.setProperty("inputstream.ffmpegdirect.stream_mode", "default")
        if is_hls:
            li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
    else:
        li.setProperty("inputstream", "inputstream.adaptive")
        if is_hls:
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
        elif is_dash:
            li.setProperty("inputstream.adaptive.manifest_type", "mpd")
    if is_hls:
        li.setMimeType("application/vnd.apple.mpegurl")
    elif is_dash:
        li.setMimeType("application/dash+xml")
    li.setProperty("IsPlayable", "true")

    plot = ""
    try:
        plot = _epg_plot(name, tvg_id)
    except Exception:
        plot = ""

    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(name)
        tag.setMediaType("video")
        if plot:
            tag.setPlot(plot)
    except (AttributeError, TypeError, ValueError) as exc:
        api.log(f"InfoTagVideo playback metadata skipped: {exc}", xbmc.LOGWARNING)
    display_logo = api.get_channel_logo(name) or DEFAULT_ICON
    li.setArt({"icon": display_logo, "thumb": display_logo, "poster": display_logo,
               "fanart": display_logo, "clearlogo": display_logo})

    openmode = ADDON.getSetting("openmode")
    if engine == "1" and openmode == "1":
        li.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
    elif engine == "1" and openmode == "2":
        li.setProperty("inputstream.ffmpegdirect.open_mode", "curl")

    if engine == "1" and stream_headers:
        hdr_val = "&".join(f"{k}={v}" for k, v in stream_headers.items())
        li.setProperty("inputstream.ffmpegdirect.headers", hdr_val)
    try:
        stream_timeout = int(ADDON.getSetting("stream_timeout") or "30")
        if engine == "1":
            li.setProperty("inputstream.ffmpegdirect.open_timeout", str(stream_timeout))
    except Exception:
        pass

    # Kodi steuert den Übergang zum Vollbild selbst. Ein zusätzliches
    # ActivateWindow(fullscreenvideo) kann beim Playerstart flackern.
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def settings_menu():
    return addon_menus.settings_menu()

def country_select():
    all_countries = api.get_available_countries()
    if not all_countries:
        xbmcgui.Dialog().ok(ADDON_NAME, "Länderliste konnte nicht geladen werden.")
        return

    current_codes = get_selected_countries_setting()
    if current_codes:
        current_names = set(api.parse_country_codes(current_codes))
        preselect     = [i for i, c in enumerate(all_countries) if c in current_names]
    else:
        current_names = set()
        preselect     = []

    labels = []
    for country in all_countries:
        code  = api.country_to_code(country)
        label = f"{country}  [{code}]" if code else country
        if country in current_names:
            labels.append(f"[COLOR gold]{label}[/COLOR]")
        else:
            labels.append(label)

    chosen = xbmcgui.Dialog().multiselect(
        "Ländergruppen auswählen",
        labels,
        preselect=preselect
    )

    if chosen is None:
        return

    if not chosen:
        set_selected_countries_setting("")
        xbmcgui.Dialog().notification(ADDON_NAME, "Alle Länder ausgewählt",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    selected = [all_countries[i] for i in chosen]

    codes = []
    for country in selected:
        code = api.country_to_code(country)
        codes.append(code if code else country)
    set_selected_countries_setting(",".join(codes))
    mark_first_run_done()

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        f"{len(selected)} Länder ausgewählt",
        xbmcgui.NOTIFICATION_INFO, 2000
    )
    xbmc.executebuiltin("Container.Refresh")


def config_menu():
    xbmcplugin.setContent(HANDLE, "files")

    epg_url   = ADDON.getSetting("epg_url").strip()
    epg_label = f"EPG-Quelle: {epg_url[:50]}..." if len(epg_url) > 50 else \
                f"EPG-Quelle: {epg_url}" if epg_url else "EPG-Quelle konfigurieren ..."

    items = [
        ("Länderliste aktualisieren",     "do_refresh_countries",  False),
        ("Senderliste aktualisieren",     "do_refresh_channels",   False),
        (epg_label,                       "config_epg_url",        False),
        ("EPG jetzt laden",               "do_load_epg",           False),
        ("Erweiterte Einstellungen",      "settings",              False),
    ]
    for label, action, is_folder in items:
        li = xbmcgui.ListItem(label)
        _set_info_tag(li, label)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action), li, is_folder)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def config_epg_url():
    current = ADDON.getSetting("epg_url").strip()
    kb = xbmc.Keyboard(current, "EPG-Quelle (XMLTV-URL) eingeben")
    kb.doModal()
    if kb.isConfirmed():
        url = kb.getText().strip()
        ADDON.setSetting("epg_url", url)
        api._auth_cache.pop(f"epg_{current}", None)
        api._epg_cache.clear()
        if url:
            xbmcgui.Dialog().notification(ADDON_NAME, "EPG-Quelle gespeichert",
                                          xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")


def do_load_epg():
    epg_url = ADDON.getSetting("epg_url").strip()
    if not epg_url:
        xbmcgui.Dialog().ok(ADDON_NAME,
            "Keine EPG-Quelle konfiguriert.\n"
            "Bitte zuerst unter Einstellungen eine XMLTV-URL eingeben.")
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "EPG wird geladen ...")
    ok = api.fetch_epg(epg_url, force=True)
    progress.close()

    if ok:
        ch_count = len(api._epg_cache)
        sample   = list(api._epg_cache.keys())[:5]
        api.log(f"EPG Channel-IDs (erste 5): {sample}", xbmc.LOGINFO)
        xbmcgui.Dialog().ok(ADDON_NAME,
            f"EPG geladen: {ch_count} Kanäle\n\n"
            f"Beispiel-IDs:\n" + "\n".join(sample[:5]))
    else:
        xbmcgui.Dialog().ok(ADDON_NAME,
            "EPG konnte nicht geladen werden.\nURL prüfen und erneut versuchen.")
    xbmc.executebuiltin("Container.Refresh")


def do_refresh_countries():
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Länderliste wird aktualisiert …")
    api.get_available_countries(force=True)
    progress.close()
    xbmcgui.Dialog().notification(ADDON_NAME, "Länderliste aktualisiert",
                                  xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def do_refresh_channels():
    all_countries = api.get_available_countries()
    selected      = get_active_countries(all_countries)

    if not selected:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Länder ausgewählt.")
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Senderliste wird aktualisiert …")

    for i, country in enumerate(selected):
        if progress.iscanceled():
            break
        pct = int(i / max(len(selected), 1) * 100)
        progress.update(pct, f"Aktualisiere {country} …")
        api.fetch_channels_for_group(country, force=True)

    progress.close()
    xbmcgui.Dialog().notification(ADDON_NAME, "Senderliste aktualisiert",
                                  xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def action_run_wizard():
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Lade Länderliste …")
    all_countries = api.get_available_countries()
    progress.close()

    if not all_countries:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Länder gefunden.")
        return

    selected = run_wizard(all_countries)
    if selected is not None:
        _refresh_selected_countries_and_offer_favorites(selected)
    xbmc.executebuiltin("Container.Refresh")

def _ask_epg_url():
    use_epg = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "EPG-Quelle einbinden?\n(z.B. https://epg.example.com/epg.xml)"
    )
    if not use_epg:
        return ""
    kb = xbmc.Keyboard("", "EPG-URL eingeben")
    kb.doModal()
    if kb.isConfirmed():
        return kb.getText().strip()
    return ""


def _save_m3u_file(content, filename):
    start_dir = "/storage/emulated/0/Download"
    if not os.path.exists(start_dir):
        start_dir = "/"

    save_dir = xbmcgui.Dialog().browse(3, "Speicherort wählen", "files", "", False, False, start_dir)

    if not save_dir:
        return False

    full_path = os.path.join(save_dir, filename)

    try:
        os.makedirs(save_dir, exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            f"M3U gespeichert:\n{full_path}"
        )
        return True
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Fehler beim Speichern:\n{e}")
        return False


def _get_epg_url():
    return ADDON.getSetting("epg_url").strip()


def export_m3u(group):
    if not group:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Gruppe angegeben.")
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Lade Kanaele fuer {group} ...")
    channels = api.fetch_channels_for_group(group)
    progress.close()

    if not channels:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Keine Kanaele fuer '{group}' gefunden.")
        return

    epg_url  = _get_epg_url()
    content  = api.generate_m3u(channels, group, epg_url=epg_url)

    import datetime
    date_str = datetime.date.today().strftime("%Y-%m-%d")
    code     = api.country_to_code(group)
    filename = f"VavooTV-{code or group}-{date_str}.m3u"
    _save_m3u_file(content, filename)


def export_favorites_m3u():
    favs           = _load_favorites()
    channels_count = sum(1 for f in favs if f.get("type", "channel") == "channel")

    if not favs or channels_count == 0:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Favoriten vorhanden.")
        return

    epg_url = _get_epg_url()
    if epg_url:
        content = api.generate_favorites_m3u(favs, epg_url=epg_url)
    else:
        try:
            with open(_fav_path(), encoding="utf-8") as f:
                content = f.read()
        except Exception:
            content = api.generate_favorites_m3u(favs)

    import datetime
    date_str = datetime.date.today().strftime("%Y-%m-%d")
    filename = f"VavooTV-Favoriten-{date_str}.m3u"
    _save_m3u_file(content, filename)

def movies_index():
    xbmcplugin.setContent(HANDLE, "movies")
    items = [
        ("Beliebte Filme",  "movie.popular"),
        ("Angesagte Filme", "movie.trending"),
    ]
    for label, vod_id in items:
        li = xbmcgui.ListItem(label)
        _set_info_tag(li, label)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="vod_list", id=vod_id), li, True)

    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="vod_collections"), _make_li("Film-Collections"), True)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="vod_genres", id="movie.popular"),
        _make_li("Genres"), True)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="vod_search", id="movie.popular"),
        _make_li("Suche"), True)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def series_index():
    xbmcplugin.setContent(HANDLE, "tvshows")
    items = [
        ("Beliebte Serien",  "series.popular"),
        ("Angesagte Serien", "series.trending"),
    ]
    for label, vod_id in items:
        li = xbmcgui.ListItem(label)
        _set_info_tag(li, label)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action="vod_list", id=vod_id), li, True)

    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="vod_genres", id="series.popular"),
        _make_li("Genres"), True)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action="vod_search", id="series.popular"),
        _make_li("Suche"), True)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def show_vod_list(vod_id, cursor=None):
    is_movie = vod_id.startswith("movie")
    xbmcplugin.setContent(HANDLE, "movies" if is_movie else "tvshows")

    result = api.fetch_vod_list(vod_id, cursor)
    items  = result.get("data", [])
    next_c = result.get("next")

    if not items:
        xbmcgui.Dialog().ok(ADDON_NAME, "Keine Inhalte gefunden.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return

    comfort.remember_years(items)
    state = comfort.rows()
    for item in items:
        item_id   = item.get("id", "")
        title     = item.get("name", "") or item.get("title", "")
        plot      = item.get("description", "")
        poster    = item.get("poster", "") or item.get("backdrop", "")
        tmdb_id   = item_id.split(".")[-1] if "." in item_id else item_id
        is_series = item_id.startswith("series")

        if not title:
            continue

        year = comfort.release_year(item.get("releaseDate") or item.get("year"))
        li = xbmcgui.ListItem(comfort.year_label(title, year))
        _set_info_tag(li, title, plot=plot,
                      media_type="tvshow" if is_series else "movie")

        if year:
            li.getVideoInfoTag().setYear(year)
        if poster:
            li.setArt({"poster": poster, "thumb": poster, "fanart": poster})

        comfort.decorate(li, dict(id=item_id,n=title,tmdb=tmdb_id,poster=poster,plot=plot), state)
        if is_series:
            xbmcplugin.addDirectoryItem(HANDLE,
                build_url(action="vod_seasons", id=item_id, n=title, tmdb=tmdb_id, poster=poster, plot=plot),
                li, True)
        else:
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(HANDLE,
                build_url(action="play_vod", id=item_id, n=title, tmdb=tmdb_id, poster=poster, plot=plot),
                li, False)

    if next_c:
        li = _make_li(">>> Weiter")
        xbmcplugin.addDirectoryItem(HANDLE,
            build_url(action="vod_list", id=vod_id, cursor=next_c), li, True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_vod_seasons(item_id, name, tmdb_id):
    xbmcplugin.setContent(HANDLE, "seasons")

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Lade Staffeln fuer {name} ...")
    seasons = api.fetch_tmdb_seasons(tmdb_id)
    progress.close()

    if not seasons:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Keine Staffeln gefunden fuer '{name}'.")
        return

    if len(seasons) == 1:
        show_vod_episodes(item_id, name, tmdb_id, seasons[0]["season_number"])
        return

    for s in seasons:
        snum   = s["season_number"]
        ecount = s["episode_count"]
        sname  = s.get("name", f"Staffel {snum}")
        label  = f"{sname}  ({ecount} Episoden)" if ecount > 1 else sname
        li     = xbmcgui.ListItem(label)
        if s.get("poster"):
            li.setArt({"thumb": s["poster"], "poster": s["poster"]})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setMediaType("season")
            tag.setSeason(snum)
            if s.get("overview"):
                tag.setPlot(s["overview"])
        except (AttributeError, TypeError, ValueError) as exc:
            api.log(f"InfoTagVideo season metadata skipped: {exc}", xbmc.LOGWARNING)
        xbmcplugin.addDirectoryItem(HANDLE,
            build_url(action="vod_episodes", id=item_id, n=name, tmdb=tmdb_id, s=snum, poster=s.get("poster", "")),
            li, True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_vod_episodes(item_id, name, tmdb_id, season, episode_count=0):
    xbmcplugin.setContent(HANDLE, "episodes")

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Lade Episoden Staffel {season} ...")
    episodes = api.fetch_tmdb_episodes(tmdb_id, season)
    progress.close()

    if not episodes:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Keine Episoden fuer Staffel {season} gefunden.")
        return

    ccapi_eps = {}

    _ep_season_posters = []
    try:
        _ep_season_posters = api.fetch_tmdb_seasons(tmdb_id)
    except Exception:
        pass

    state = comfort.rows()
    for ep in episodes:
        ep_num  = ep["episode_number"]
        ep_name = ep.get("name") or f"Episode {ep_num}"
        label   = f"S{int(season):02d}E{ep_num:02d} – {ep_name}"
        li      = xbmcgui.ListItem(label)
        ep_still = ep.get("still", "")
        ep_art   = {}
        if ep_still:
            ep_art["thumb"] = ep_still
        for s in _ep_season_posters:
            if s.get("season_number") == int(season):
                if s.get("poster"):
                    ep_art["poster"] = s["poster"]
                    ep_art["fanart"] = s.get("poster", "")
                break
        if ep_art:
            li.setArt(ep_art)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(ep_name)
            tag.setMediaType("episode")
            tag.setSeason(int(season))
            tag.setEpisode(ep_num)
            if ep.get("overview"):
                tag.setPlot(ep["overview"])
            if ep.get("air_date"):
                tag.setFirstAired(ep["air_date"])
            if ep.get("runtime"):
                tag.setDuration(ep["runtime"] * 60)
            if ep.get("vote_average"):
                tag.setRating(ep["vote_average"])
        except (AttributeError, TypeError, ValueError) as exc:
            api.log(f"InfoTagVideo episode metadata skipped: {exc}", xbmc.LOGWARNING)
        li.setProperty("IsPlayable", "true")
        comfort.decorate(li, dict(id=item_id,n=name,tmdb=tmdb_id,s=season,e=ep_num,ep_name=ep_name,poster=ep_art.get("poster",ep_still),plot=ep.get("overview","")),state)
        ep_id = ccapi_eps.get(ep_num, "")
        xbmcplugin.addDirectoryItem(HANDLE,
            build_url(action="play_vod", id=item_id, n=name, tmdb=tmdb_id,
                      s=season, e=ep_num, ep_id=ep_id, poster=ep_art.get("poster",ep_still), plot=ep.get("overview",""), ep_name=ep_name),
            li, False)

    xbmcplugin.endOfDirectory(HANDLE)


def show_vod_genres(vod_id):
    is_movie = vod_id.startswith("movie")
    if is_movie:
        genres = [
            "Action", "Abenteuer", "Animation", "Komödie", "Krimi",
            "Dokumentarfilm", "Drama", "Familie", "Fantasy", "Historie",
            "Horror", "Musik", "Mystery", "Liebesfilm", "Science Fiction",
            "Thriller", "Kriegsfilm", "Western",
        ]
    else:
        genres = [
            "Action & Adventure", "Animation", "Komödie", "Krimi",
            "Dokumentarfilm", "Drama", "Familie", "Kids", "Mystery",
            "Sci-Fi & Fantasy", "Thriller", "Western",
        ]
    for genre in genres:
        li = _make_li(genre)
        xbmcplugin.addDirectoryItem(HANDLE,
            build_url(action="vod_list", id=f"{vod_id}.genre={genre}"),
            li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def vod_search(vod_id):
    kb = xbmc.Keyboard("", "Suche …")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    search_id = f"{vod_id}.search={url_quote(query, safe='')}"
    show_vod_list(search_id)


def play_vod(item_id, name, tmdb_id, season=None, episode=None, ep_id="", poster="", plot="", auto=False, restart=False, ep_name=""):
    d=dict(id=item_id,n=name,tmdb=tmdb_id,s=season,e=episode,poster=poster,plot=plot,ep_name=ep_name)
    r=comfort.rows().get(comfort.key(d),{})
    resume=0
    if not restart and r.get('pos',0)>10 and not r.get('seen'):
        if auto: resume=r['pos']
        else:
            choice=xbmcgui.Dialog().select(name,['Fortsetzen bei '+comfort.stamp(r['pos']),'Von Anfang an'])
            if choice<0:
                xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem()); return
            if choice==0: resume=r['pos']


    stream_url = api.resolve_vod_stream(
        item_id=item_id,
        media_type="series" if season else "movie",
        tmdb_id=tmdb_id,
        season=season,
        episode=episode,
        name=name,
        auto_start=auto,
    )
    if not stream_url:
        xbmcgui.Dialog().ok(ADDON_NAME,
            f"Kein Stream gefunden.\n\n{name}\n\n"
            "Bitte eine andere Quelle auswählen.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # Die integrierte Vavoo-API liefert eine URL (ggf. mit Kodi-Headern).
    # Der vorherige GEIL-Adapter lieferte dagegen ein Dict.
    if isinstance(stream_url, dict):
        fmt = stream_url.get("format")
        stream_url = stream_url.get("url", "")
    else:
        fmt = "hls" if ".m3u8" in stream_url.split("|", 1)[0].lower() else "mp4"
    if not stream_url:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    api.log("VoD play: native Kodi, format=" + str(fmt), xbmc.LOGINFO)
    li = xbmcgui.ListItem(name, path=stream_url)
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    _set_info_tag(li, name, plot=plot,
                  media_type="episode" if season and episode else ("tvshow" if season else "movie"),
                  season=season, episode=episode)
    if poster:
        li.setArt({"thumb": poster, "poster": poster, "fanart": poster, "icon": poster})
    li.setMimeType("application/vnd.apple.mpegurl" if fmt == "hls" else "video/mp4")

    # Explicit start position for Kodi's player, including zero for Restart.
    # This is separate from our SQLite progress and episode tracking.
    li.setProperty("StartOffset", str(max(0, int(resume))))
    comfort.prepare(d,stream_url,resume)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)



def collections_index(search=False):
    import tmdb_collections as tc
    xbmcplugin.setContent(HANDLE,'sets')
    if search:
        if not tc.credential():
            xbmcgui.Dialog().ok(ADDON_NAME,'Für die weltweite Collection-Suche bitte einen eigenen TMDB API-Schlüssel in den VoD-Einstellungen eintragen.')
            xbmcplugin.endOfDirectory(HANDLE,succeeded=False,cacheToDisc=False); return
        kb=xbmc.Keyboard('', 'Film-Collections suchen'); kb.doModal()
        items=tc.search(kb.getText()) if kb.isConfirmed() and kb.getText().strip() else []
    else:
        items=[(i,n,None) for i,(n,_) in sorted(tc.SERIES.items(),key=lambda x:x[1][0])]
        xbmcplugin.addDirectoryItem(HANDLE,build_url(action='vod_collections_search'),_make_li('Weitere Film-Collections suchen (TMDB)'),True)
    for i,n,poster in items:
        li=_make_li(n)
        if poster: li.setArt({'thumb':'https://image.tmdb.org/t/p/w500'+poster,'poster':'https://image.tmdb.org/t/p/w500'+poster})
        xbmcplugin.addDirectoryItem(HANDLE,build_url(action='vod_collection',cid=i),li,True)
    xbmcplugin.endOfDirectory(HANDLE,cacheToDisc=False)


def show_collection(d):
    if d.get('cid'):
        import tmdb_collections as tc
        name,entries=tc.load(d['cid'])
        comfort.remember_years(entries)
    else:
        name, entries=comfort.collection(d)
    if not entries:
        xbmcgui.Dialog().ok(ADDON_NAME,'Keine bestätigte Filmreihe verfügbar.')
        xbmcplugin.endOfDirectory(HANDLE,succeeded=False,cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE,name)
    xbmcplugin.setContent(HANDLE,'movies')
    state=comfort.rows()
    for x in entries:
        li=xbmcgui.ListItem(comfort.title(x))
        _set_info_tag(li,x['n'],plot=x.get('plot',''),media_type='movie')
        year=comfort.year_for(x)
        if year: li.getVideoInfoTag().setYear(year)
        if x.get('poster'): li.setArt({'poster':x['poster'],'thumb':x['poster']})
        comfort.decorate(li,x,state)
        li.setProperty('IsPlayable','true')
        xbmcplugin.addDirectoryItem(HANDLE,comfort.url(x),li,False)
    xbmcplugin.endOfDirectory(HANDLE,cacheToDisc=False)

def comfort_menu(mode):
    if mode=='continue':
        for label, m, icon in [('Filme fortsetzen','continue_movie','filme_fortsetzen.png'),('Serien fortsetzen','continue_series','serien_fortsetzen.png')]:
            xbmcplugin.addDirectoryItem(HANDLE,build_url(action='comfort_menu',mode=m),_make_menu_item(label,icon,label),True)
    else:
        state=comfort.rows(); entries=[]; series_seen=set()
        for d in sorted(state.values(),key=lambda x:x.get('updated',0),reverse=True):
            movie=d['id'].startswith('movie')
            if mode=='fav_movie' and movie and d.get('fav'): entries.append(d)
            elif mode=='fav_series' and not movie and d.get('fav') and not d.get('e'): entries.append(d)
            elif mode=='continue_movie' and movie and d.get('pos',0)>10 and not d.get('seen') and not d.get('hidden'): entries.append(d)
            elif mode=='continue_series' and d.get('e') and d['id'] not in series_seen and not d.get('hidden'):
                if d.get('seen') or d.get('pos',0)>10:
                    series_seen.add(d['id'])
                    nxt=comfort.next_episode(d) if d.get('seen') else d
                    if nxt: entries.append(nxt)
        xbmcplugin.setContent(HANDLE,'videos')
        for d in entries:
            folder=not d['id'].startswith('movie') and not d.get('e')
            r=state.get(comfort.key(d),{}); year=comfort.year_for(d,fetch=True); label=comfort.title(dict(d,year=year))
            if mode.startswith('continue'):
                label += ' | '+('Fortsetzen bei '+comfort.stamp(r['pos']) if r.get('pos',0)>10 else 'Nächste Episode')
            li=xbmcgui.ListItem(label)
            _set_info_tag(li,d['n'],plot=d.get('plot',''),media_type='tvshow' if folder else 'episode' if d.get('e') else 'movie')
            if year: li.getVideoInfoTag().setYear(year)
            if d.get('poster'): li.setArt({'poster':d['poster'],'thumb':d['poster']})
            comfort.decorate(li,d,state)
            if not folder: li.setProperty('IsPlayable','true')
            xbmcplugin.addDirectoryItem(HANDLE,comfort.url(d,'vod_seasons' if folder else 'play_vod'),li,folder)
    xbmcplugin.endOfDirectory(HANDLE,cacheToDisc=False)

if __name__ == "__main__":
    params = get_params()
    addon_menus.configure(globals())
    if not params:
        show_release_dialog_once()
        main_menu()
    else:
        addon_router.configure(globals())
        addon_router.route(params)
