# -*- coding: utf-8 -*-
"""Aktualisiert die ausdrücklich ausgewählten Länder beim Kodi-Start."""
import os
import json
import hashlib
import time
import xbmcgui
import sys
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon(id="plugin.video.vavoo.tv.plus")
PREFIX = "[Vavoo TV Plus Startup] "
MAX_ATTEMPTS = 3
RETRY_SECONDS = (15, 30)


def log(message, level=xbmc.LOGINFO):
    xbmc.log(PREFIX + str(message), level)


def list_fingerprint(channels):
    """Stable digest of channel names and their source URLs, independent of dict ordering."""
    canonical = []
    for name, urls in channels.items():
        canonical.append((str(name), sorted(str(url) for url in urls)))
    payload = json.dumps(sorted(canonical), ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def read_snapshots(path):
    try:
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def save_snapshots(path, data):
    temp = path + ".tmp"
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, sort_keys=True)
    os.replace(temp, path)


def refresh(monitor):
    selected = ADDON.getSetting("selected_countries").strip()
    if not selected:
        log("Keine Länder explizit ausgewählt; Aktualisierung übersprungen.")
        return
    lib = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))
    if lib not in sys.path:
        sys.path.insert(0, lib)
    import vavoo_api as api

    codes = api.parse_country_codes(selected)
    if not codes:
        log("Keine gültige Länderauswahl gefunden.", xbmc.LOGWARNING)
        return
    # Die verfügbare Länderliste kann bei Netzwerkausfall auf Fallback-Daten zurückgreifen.
    try:
        countries = api.get_available_countries()
    except Exception as exc:
        log("Länderkatalog nicht erreichbar: %s" % exc, xbmc.LOGWARNING)
        countries = []
    known = {api.country_to_code(country).upper(): country for country in countries}
    names = []
    for code in codes:
        name = known.get(str(code).upper(), code)
        if name not in names:
            names.append(name)

    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    os.makedirs(profile, exist_ok=True)
    snapshot_path = os.path.join(profile, "startup_country_snapshots.json")
    snapshots = read_snapshots(snapshot_path)
    changed_countries = []
    fresh_catalog = {}
    failed_countries = []
    for country in names:
        if monitor.abortRequested():
            return
        for attempt in range(1, MAX_ATTEMPTS + 1):
            if monitor.abortRequested():
                return
            try:
                # strict_refresh verhindert, dass alte Cache-Daten als neuer Download gelten.
                channels = api.fetch_channels_for_group(country, force=True, strict_refresh=True)
                log("%s: %d Sender frisch geladen (Versuch %d)." % (country, len(channels), attempt))
                fresh_catalog.update(channels)
                fingerprint = list_fingerprint(channels)
                previous = snapshots.get(str(country))
                if previous is not None and previous != fingerprint:
                    changed_countries.append(str(country))
                    log("%s: Senderliste hat sich geändert." % country)
                elif previous is None:
                    log("%s: Erste Vergleichsbasis gespeichert; kein Änderungsalarm." % country)
                snapshots[str(country)] = fingerprint
                try:
                    save_snapshots(snapshot_path, snapshots)
                except OSError as exc:
                    log("Vergleichsbasis konnte nicht gespeichert werden: %s" % exc, xbmc.LOGWARNING)
                break
            except Exception as exc:
                log("%s: Versuch %d/%d fehlgeschlagen: %s; vorhandener Cache bleibt erhalten." %
                    (country, attempt, MAX_ATTEMPTS, exc), xbmc.LOGWARNING)
                if attempt == MAX_ATTEMPTS:
                    log("%s: Kein frisches Update; bisherige Liste bleibt erhalten." % country, xbmc.LOGWARNING)
                    failed_countries.append(country)
                elif monitor.waitForAbort(RETRY_SECONDS[attempt - 1]):
                    return
    if failed_countries or not fresh_catalog or monitor.abortRequested():
        log("Favoriten-Abgleich übersprungen: Katalog nicht vollständig frisch.")
        return
    try:
        import group_favs as gf
        from favorites.sync_engine import sync_name_key
        groups = gf.load_groups()
        # Alias-Erkennung aus der vorhandenen Sync-Engine verwenden.
        # Jede Katalogvariante bleibt separat: HD, HD+, RAW, BACKUP usw.
        indexed = {}
        for name, urls in fresh_catalog.items():
            key = sync_name_key(name)
            if not key:
                continue
            if isinstance(urls, (str, dict)):
                urls = [urls]
            for item in urls or []:
                url = item.get("url", "") if isinstance(item, dict) else item
                if url:
                    indexed.setdefault(key, []).append((name, str(url).strip()))

        import re
        def variant(name):
            text = (name or "").lower()
            if re.search(r"\b(?:uhd|4k)\b", text):
                return "uhd"
            if re.search(r"\b(?:fhd|full\s*hd)\b", text):
                return "fhd"
            if re.search(r"\bhd\+?\b|\bhd\+", text):
                return "hd"
            return "sd"

        def candidate_rank(name, wanted):
            """Qualitaet beibehalten; Backup nur als schlechtere Alternative."""
            text = (name or "").lower()
            score = 100 if variant(name) == variant(wanted) else 0
            if variant(wanted) == "hd" and variant(name) == "fhd":
                score += 10
            if "backup" in text or "test" in text or "match time" in text:
                score -= 50
            if "raw" in text or "hevc" in text:
                score -= 10
            # Exakter Anzeigename hat Vorrang vor einem Alias.
            if name.casefold().strip() == wanted.casefold().strip():
                score += 20
            return score

        def unique_replacement(wanted, old_url):
            key = sync_name_key(wanted)
            matches = indexed.get(key, [])
            # Bereits vorhandene URLs bleiben auch bei anderen Schreibweisen.
            if any(url == old_url for _, url in matches):
                return None, False
            ranks = {}
            for name, url in matches:
                if url and url != old_url:
                    ranks[url] = max(ranks.get(url, -10000), candidate_rank(name, wanted))
            if not ranks:
                return None, True
            best = max(ranks.values())
            winners = [url for url, rank in ranks.items() if rank == best]
            # Bei gleichwertigen Quellen niemals zufaellig ersetzen.
            return (winners[0], False) if len(winners) == 1 else (None, True)
        updated = 0
        unresolved = 0
        for group in groups:
            if monitor.abortRequested():
                return
            filename = group.get("file", "")
            if not filename or filename.lower() == "alle_favoriten.m3u":
                continue
            channels = gf.load_group_channels(filename)
            eligible = {}
            for channel in channels:
                old = (channel.get("url") or "").strip()
                if not old:
                    continue
                candidate, uncertain = unique_replacement(channel.get("name", ""), old)
                if candidate:
                    # Originalname verwenden; die vorhandene Sync-Engine
                    # prueft den Stream vor dem Schreiben und legt Backups an.
                    eligible[channel["name"]] = [candidate]
                elif uncertain:
                    unresolved += 1
            if not eligible:
                continue
            # Vor jedem Schreiben sichert die vorhandene Sync-Engine die M3U.
            result = gf.sync_group_channels(
                filename, eligible, api_module=api,
                max_candidates=1, validation_timeout=5,
                validate_streams=True)
            updated += result.get("updated", 0)
            unresolved += result.get("unreachable", 0)
            if result.get("error"):
                log("Abgleich %s: %s" % (filename, result["error"]), xbmc.LOGWARNING)
        if updated:
            gf.rebuild_all_favorites_m3u(groups)
            log("Favoriten automatisch aktualisiert: %d Sender." % updated)
        if unresolved:
            xbmcgui.Dialog().notification(
                "Vavoo TV Plus", "%d Sender bitte manuell prüfen" % unresolved,
                xbmcgui.NOTIFICATION_INFO, 7000, False)
    except Exception as exc:
        log("Automatischer Favoriten-Abgleich fehlgeschlagen: %s" % exc, xbmc.LOGERROR)



def monitor_epg_playback_failures():
    """Wiedergabestatus verfolgen und nach einem Fehler zurück ins MultiEPG springen.

    Fehler-Rücksprung: Nach einem Wiedergabefehler wird der Kodi-Fehlerdialog
    ("Wiedergabe nicht möglich") nach FAIL_AUTO_SECONDS automatisch geschlossen
    oder sofort, sobald der Nutzer OK drückt. Danach öffnet das MultiEPG wieder
    auf dem zuletzt gewählten Sender.
    """
    import time
    from urllib.parse import quote
    FAIL_AUTO_SECONDS = 4.0     # automatischer Rücksprung (3-5 s)
    NO_DIALOG_SECONDS = 1.5     # Fehler ohne Dialog: fast sofort zurück
    STUCK_SECONDS = 35          # Stream startet gar nicht
    home = xbmcgui.Window(10000)
    monitor = xbmc.Monitor()

    def is_vavoo_file(actual):
        session_url = home.getProperty("VavooTVPlus.PlayingURL")
        if not (session_url and actual):
            return False
        return (actual.split("|", 1)[0] == session_url.split("|", 1)[0]
                or (session_url.startswith("plugin://plugin.video.vavoo.tv.plus/")
                    and actual.startswith("plugin://plugin.video.vavoo.tv.plus/")))

    def preview_guard():
        """Live-Vorschau der dritten EPG-Ansicht aktiv (oder gerade beendet)?

        Dann darf der Service weder ein zweites EPG-Fenster öffnen noch einen
        Sendungswechsel als "Live-TV beendet" werten.
        """
        try:
            now = time.time()
            if now - float(home.getProperty("VavooTVPlus.PreviewActive") or 0) < 4.0:
                return True
            return now < float(home.getProperty("VavooTVPlus.SuppressReturnUntil") or 0)
        except ValueError:
            return False

    cover = {'win': None, 'since': 0.0}

    def show_cover():
        """Blickdichtes Dunkelbild, bis das Live Guide nach STOP/Zurück offen ist."""
        if cover['win'] or xbmcaddon.Addon().getSetting('epg_view_style') != '2':
            return
        try:
            win = xbmcgui.WindowXMLDialog('LiveGuideCover.xml', ADDON.getAddonInfo('path'), 'Default', '1080i')
            win.show()
            cover.update(win=win, since=time.time())
        except Exception as exc:
            log('Übergangsbild: %s' % exc, xbmc.LOGWARNING)

    def hide_cover():
        win, cover['win'] = cover['win'], None
        if win:
            try:
                win.close()
            except Exception:
                pass

    class Playback(xbmc.Player):
        def __init__(self):
            super().__init__()
            self.av_time = 0.0
            self.err_time = 0.0
            self.info_deadline = 0.0
            self.live_active = False
            self.stop_return = None

        def onPlayBackError(self):
            self.live_active = False
            self.stop_return = None
            self.info_deadline = 0.0
            self.err_time = time.time()
            home.clearProperty("VavooTVPlus.Playing")

        def onAVStarted(self):
            self.av_time = time.time()
            self.stop_return = None
            try:
                ok = is_vavoo_file(self.getPlayingFile())
            except Exception:
                ok = False
            self.info_deadline = 0.0
            self.live_active = ok
            if ok:
                home.clearProperty("VavooTVPlus.NativeAttempt")
                home.clearProperty("VavooTVPlus.SkipCount")
                home.setProperty("VavooTVPlus.Playing", "1")
                try:
                    candidate = json.loads(home.getProperty("VavooTVPlus.Candidate") or '{}')
                    actual = self.getPlayingFile().split('|', 1)[0]
                    if candidate.get('file') == actual and candidate.get('url'):
                        from favorites_epg_window import save_last_channel, load_last_channel
                        save_last_channel(candidate['url'], candidate.get('name', ''), candidate.get('group_file'))
                        last = load_last_channel()
                        home.setProperty('VavooTVPlus.ConfirmedFile', actual)
                        home.setProperty('VavooTVPlus.ConfirmedURL', candidate['url'])
                        home.setProperty('VavooTVPlus.ConfirmedGroup', last.get('group_file', ''))
                        home.clearProperty('VavooTVPlus.Candidate')
                        self.info_deadline = time.monotonic() + 3.0
                        if (candidate.get('return_fullscreen')
                                and xbmcgui.getCurrentWindowId() == 10028):
                            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                except Exception as exc:
                    log('Sendererinnerung: %s' % exc, xbmc.LOGWARNING)
            else:
                home.clearProperty("VavooTVPlus.Playing")

        def onPlayBackStopped(self):
            self.info_deadline = 0.0
            was_live = self.live_active
            self.live_active = False
            home.clearProperty("VavooTVPlus.Playing")
            # A newer resolution belongs to a channel transition, not a stop.
            try:
                pending = float(home.getProperty("VavooTVPlus.PendingEPGTime") or '0')
            except ValueError:
                pending = 0.0
            if was_live and pending <= self.av_time and not preview_guard():
                live_guide = home.getProperty("VavooTVPlus.LiveGuideFullscreen") == "1"
                home.clearProperty("VavooTVPlus.LiveGuideFullscreen")
                self.stop_return = (time.monotonic() + (0.0 if live_guide else 0.8), self.av_time)
                cover['want'] = True
                for prop in ('PendingEPGURL', 'PendingEPGTime', 'NativeAttempt', 'SkipCount', 'Candidate'):
                    home.clearProperty('VavooTVPlus.' + prop)


        def onPlayBackEnded(self):
            self.live_active = False
            self.stop_return = None
            self.info_deadline = 0.0
            home.clearProperty("VavooTVPlus.Playing")

    player = Playback()
    last_key = ""
    fail_since = 0.0
    dialog_seen = False

    def clear_pending():
        home.clearProperty("VavooTVPlus.PendingEPGURL")
        home.clearProperty("VavooTVPlus.PendingEPGTime")

    guide_was_fullscreen = False
    while not monitor.abortRequested():
        try:
            if cover.pop('want', False) and player.stop_return:
                show_cover()
            if cover['win']:
                beat = time.time() - float(home.getProperty("VavooTVPlus.PreviewActive") or 0)
                if beat < 2.5 or time.time() - cover['since'] > 10 or player.isPlaying():
                    hide_cover()
        except Exception as exc:
            log('Übergangsbild: %s' % exc, xbmc.LOGWARNING)
        # Only a confirmed Live Guide fullscreen session may return on Back.
        # OSD/dialogs do not count as leaving the fullscreen video window.
        try:
            guide_session = home.getProperty('VavooTVPlus.LiveGuideFullscreen') == '1'
            fullscreen = xbmcgui.getCurrentWindowId() == 12005
            if not guide_session or preview_guard() or not player.isPlayingVideo():
                guide_was_fullscreen = False
            elif fullscreen:
                guide_was_fullscreen = is_vavoo_file(player.getPlayingFile())
            elif guide_was_fullscreen:
                guide_was_fullscreen = False
                if (xbmcgui.getCurrentWindowId() in (10000, 10025)
                        and is_vavoo_file(player.getPlayingFile())
                        and not home.getProperty('VavooTVPlus.PendingEPGTime')
                        and xbmcaddon.Addon().getSetting('epg_view_style') == '2'):
                    home.clearProperty('VavooTVPlus.LiveGuideFullscreen')
                    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.vavoo.tv.plus/?action=favorites_epg&overlay=1)')
        except Exception as exc:
            log('Live Guide Zurück: %s' % exc, xbmc.LOGWARNING)
        if player.stop_return:
            deadline, av_at_stop = player.stop_return
            if (player.isPlaying() or player.av_time != av_at_stop
                    or home.getProperty('VavooTVPlus.PendingEPGTime')):
                player.stop_return = None
            elif time.monotonic() >= deadline:
                player.stop_return = None
                # Existing EPG entry point restores the saved group and channel.
                if (not xbmc.getCondVisibility('Window.IsActive(okdialog)')
                        and not preview_guard()):
                    log('Live-TV beendet: Rückkehr zur bevorzugten EPG-Ansicht.')
                    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.vavoo.tv.plus/?action=favorites_epg)')
        # Einmalig, nur im Vollbild und nur für den bestätigten Live-Sender.
        if player.info_deadline and time.monotonic() >= player.info_deadline:
            player.info_deadline = 0.0
            try:
                if (player.isPlayingVideo() and is_vavoo_file(player.getPlayingFile())
                        and player.getPlayingFile().split('|', 1)[0] == home.getProperty('VavooTVPlus.ConfirmedFile')
                        and xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
                        and xbmc.getCondVisibility('Player.ShowInfo')):
                    xbmc.executebuiltin('Action(Info)')
            except Exception as exc:
                log('Wiedergabeinfo: %s' % exc, xbmc.LOGWARNING)
        url = home.getProperty("VavooTVPlus.PendingEPGURL")
        raw_time = home.getProperty("VavooTVPlus.PendingEPGTime")
        try:
            started = float(raw_time)
        except (ValueError, TypeError):
            started = 0
        if not url or not started:
            fail_since = 0.0
            dialog_seen = False
            monitor.waitForAbort(0.5)
            continue
        key = raw_time + url
        if key != last_key:
            last_key = key
            fail_since = 0.0
            dialog_seen = False

        # Erfolg zählt erst, wenn der NEUE Stream gestartet ist (der alte kann
        # beim Senderwechsel noch laufen).
        if player.av_time >= started:
            clear_pending()
            monitor.waitForAbort(0.5)
            continue

        failed = player.err_time >= started
        elapsed = time.time() - started
        try:
            native = json.loads(home.getProperty("VavooTVPlus.NativeAttempt") or '{}')
        except ValueError:
            native = {}
        if native.get('url') == url:
            # Give Kodi's own playlist error handling priority. Never race a new entry.
            if failed or elapsed >= 8.0:
                try:
                    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    pos = pl.getposition()
                    if (pos == native['pos'] and pl.size() == native['size']
                            and pl[pos].getPath() == native['path']
                            and not player.isPlaying()
                            and home.getProperty("VavooTVPlus.PendingEPGTime") == raw_time):
                        if not fail_since:
                            fail_since = time.time()
                        if time.time() - fail_since >= 1.5:
                            count = int(home.getProperty("VavooTVPlus.SkipCount") or '0')
                            clear_pending()
                            home.clearProperty("VavooTVPlus.NativeAttempt")
                            if count < 3 and pos + 1 < pl.size():
                                nxt = pl[pos + 1].getPath()
                                if nxt.startswith('plugin://plugin.video.vavoo.tv.plus/?action=play_live_zap&'):
                                    home.setProperty("VavooTVPlus.SkipCount", str(count + 1))
                                    if xbmc.getCondVisibility("Window.IsActive(okdialog)"):
                                        xbmc.executebuiltin("Dialog.Close(okdialog,true)")
                                    log("Native Senderliste: fehlerhaften Sender überspringen.")
                                    player.play(pl, startpos=pos + 1)
                except Exception as exc:
                    log("Sender-Fehlerautomatik: %s" % exc, xbmc.LOGWARNING)
            monitor.waitForAbort(0.25)
            continue
        if failed or elapsed > STUCK_SECONDS:
            now = time.time()
            if not fail_since:
                fail_since = now
            dialog_open = xbmc.getCondVisibility("Window.IsActive(okdialog)")
            if dialog_open:
                dialog_seen = True
            waited = now - fail_since
            go = ((dialog_seen and not dialog_open)              # OK gedrückt
                  or waited >= FAIL_AUTO_SECONDS                 # 3-5 s Auto-Rücksprung
                  or (not dialog_seen and waited >= NO_DIALOG_SECONDS))
            if go:
                clear_pending()
                fail_since = 0.0
                dialog_seen = False
                if not failed and player.isPlaying():
                    player.stop()
                if dialog_open:
                    xbmc.executebuiltin("Dialog.Close(okdialog,true)")
                    monitor.waitForAbort(0.3)
                if preview_guard():
                    log("Wiedergabefehler in der Live-Vorschau: Fenster bleibt offen.")
                    monitor.waitForAbort(0.25)
                    continue
                log("Wiedergabefehler: Rückkehr zum ausgewählten MultiEPG-Sender.")
                xbmc.executebuiltin(
                    "RunPlugin(plugin://plugin.video.vavoo.tv.plus/"
                    "?action=favorites_epg&url=%s)" % quote(url, safe="")
                )
        monitor.waitForAbort(0.25)


def install_epg_keymap():
    """Keymap mit dem tatsächlichen Addon-Pfad im Profil ablegen und neu laden."""
    try:
        from xml.sax.saxutils import quoteattr
        script = xbmcvfs.translatePath(
            os.path.join(ADDON.getAddonInfo("path"), "epg_hotkey.py")).replace("\\", "/")
        cmd = 'RunScript("%s")' % script
        keys = (
            '    <keyboard>\n'
            '      <backspace>%(c)s</backspace>\n'
            '      <escape>%(c)s</escape>\n'
            '      <browser_back>%(c)s</browser_back>\n'
            '    </keyboard>\n    <remote>\n'
            '      <back>%(c)s</back>\n'
            '    </remote>\n'
        )
        # Auch bei geöffneter Wiedergabe-Info (Kodi-Skin) soll Zurück das MultiEPG öffnen;
        # sonst schließt die erste Zurück-Taste nur diese Info.
        content = (
            '<?xml version="1.0" encoding="UTF-8"?>\n<keymap>\n'
            '  <FullscreenVideo>\n' + keys + '  </FullscreenVideo>\n'
            '  <FullscreenInfo>\n' + keys + '  </FullscreenInfo>\n'
            '</keymap>\n'
        ) % {"c": quoteattr(cmd)[1:-1]}
        content = content.encode("utf-8")
        destdir = xbmcvfs.translatePath("special://profile/keymaps")
        os.makedirs(destdir, exist_ok=True)
        dest = os.path.join(destdir, "vavoo_multiepg.xml")
        previous = None
        if os.path.isfile(dest):
            with open(dest, "rb") as stream:
                previous = stream.read()
        if previous != content:
            with open(dest, "wb") as stream:
                stream.write(content)
            xbmc.executebuiltin("Action(reloadkeymaps)")
            log("FullscreenVideo-Zurück-Taste für MultiEPG eingerichtet.")
    except Exception as exc:
        log("EPG-Tastenbelegung konnte nicht eingerichtet werden: %s" % exc, xbmc.LOGWARNING)


def _lower_thread_priority(nice_value=15):
    """Hintergrundarbeit niedriger priorisieren, damit Video-Wiedergabe nicht ruckelt.

    Unter Linux/Android gilt der Nice-Wert pro Thread: Nur der aufrufende
    Hintergrund-Thread wird langsamer, Kodi-Oberflaeche und Videodecoder nicht.
    """
    try:
        os.nice(nice_value)
    except Exception:
        pass


def main():
    _lower_thread_priority()
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(10):
        return
    try:
        if ADDON.getSetting("refresh_selected_on_startup").lower() not in ("true", "1", "yes"):
            log("Automatische Aktualisierung deaktiviert.")
            return
        refresh(monitor)
    except Exception as exc:
        log("Startaktualisierung fehlgeschlagen: %s" % exc, xbmc.LOGERROR)


def _epg_refresh_urgent(api):
    """True, wenn der EPG-Cache fehlt oder sehr alt ist (dann auch waehrend Video aktualisieren)."""
    try:
        path = api._epg_disk_path()
        return (not path) or (time.time() - os.path.getmtime(path) > 12 * 3600)
    except OSError:
        return True


def epg_refresh_service():
    _lower_thread_priority()
    import vavoo_api as api
    api._EPG_BACKGROUND_THROTTLE = True        # Parser gibt zwischendurch CPU ab
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(15):
        return
    player = xbmc.Player()
    while not monitor.abortRequested():
        # Das Parsen von ~120.000 Sendungen belastet schwache 2-Kern-Geraete
        # (Fire TV Stick) stark. Waehrend ein Video laeuft, wird die
        # Aktualisierung zurueckgestellt, ausser der Cache ist sehr alt.
        try:
            playing = player.isPlayingVideo()
        except Exception:
            playing = False
        if playing and not _epg_refresh_urgent(api):
            if monitor.waitForAbort(300):
                return
            continue
        ok = False
        try:
            ok = api.fetch_epg(api.get_epg_url(), background=True)
        except Exception as exc:
            log("EPG Service: %s" % exc, xbmc.LOGWARNING)
        finally:
            # Service benoetigt keinen dauerhaften RAM-EPG.
            api._epg_cache = {}
            api._epg_lookup = {}
        if monitor.waitForAbort(api.EPG_REFRESH_SECONDS if ok else 300):
            return


def maintenance_service():
    _lower_thread_priority()
    import vavoo_api as api
    import group_favs as gf
    from epg_group_data import refresh_all_favorites_m3u
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    if monitor.waitForAbort(20):
        return
    while not monitor.abortRequested():
        try:
            if not player.isPlayingVideo():
                api.refresh_online_logo_index_if_stale()
                if os.path.isfile(gf._groups_json_path()):
                    refresh_all_favorites_m3u(gf, gf.load_groups())
        except Exception as exc:
            log("Wartungsservice: %s" % exc, xbmc.LOGWARNING)
        if monitor.waitForAbort(60):
            return


if __name__ == "__main__":
    import threading
    install_epg_keymap()
    lib = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))
    sys.path.insert(0, lib)
    import vod_comfort
    threading.Thread(target=main, daemon=True).start()
    threading.Thread(target=epg_refresh_service, daemon=True).start()
    threading.Thread(target=maintenance_service, daemon=True).start()
    threading.Thread(target=monitor_epg_playback_failures, daemon=True).start()
    vod_comfort.run(xbmc.Monitor())
