# -*- coding: utf-8 -*-
"""Vavoo Kanalliste: Sender | kommende Sendungen | Beschreibung (Kodi 21, 1080p).

Die Spalten sind echte Kodi-Listen-Container (virtualisiert, Batch-Befüllung mit
offscreen-ListItems). Rechte Spalte und Infoleiste lesen direkt per Skin-Infolabels
aus den ausgewählten Einträgen, dafür braucht es keinen Python-Code beim Blättern.
Nur die mittlere Spalte wird bei Senderwechsel nachgeladen (entprellt).
"""
import datetime
import os
import threading

import xbmc
import xbmcaddon
import xbmcgui

import epg_common as E
from epg_group_data import visible_groups, favorite_channels, vavoo_channels

ADDON = xbmcaddon.Addon('plugin.video.vavoo.tv.plus')
DEFAULT_ICON = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'default_channel.png')

CH_LIST, EV_LIST = 100, 200
MENU_IDS = (11,)
MAX_EVENTS = 40
CHUNK = 60                      # Sender pro Paket beim gestaffelten Aufbau

ACT_CLOSE = (9, 10, 92)         # PARENT_DIR, PREVIOUS_MENU, NAV_BACK
ACT_RED = getattr(xbmcgui, 'ACTION_TELETEXT_RED', 215)
ACT_GREEN = getattr(xbmcgui, 'ACTION_TELETEXT_GREEN', 216)
ACT_YELLOW = getattr(xbmcgui, 'ACTION_TELETEXT_YELLOW', 217)
ACT_BLUE = getattr(xbmcgui, 'ACTION_TELETEXT_BLUE', 218)


def _set_progress(li, elapsed_s, total_s):
    """Fortschritt über den Resume-Punkt: Kodi liefert daraus ListItem.PercentPlayed."""
    if elapsed_s > 0 and total_s > 0:
        try:
            li.getVideoInfoTag().setResumePoint(float(elapsed_s), float(total_s))
        except Exception:
            pass


class ChannelListEPG(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.gf = kwargs['groups_module']
        self._repair_callback = kwargs['repair_callback']
        self._sender_dialog_active = False
        self.api = kwargs['api']
        self.groups = visible_groups(self.gf.load_groups())
        self.group_index = -1                  # -1 = Alle Favoriten
        start_file = kwargs.get('start_file', '')
        self._last_group_file = start_file
        start_file = start_file or ADDON.getSetting('multiepg_last_group_file')
        if start_file == '__vavoo_channels__':
            self.group_index = -2
        for i, g in enumerate(self.groups):
            if start_file and g.get('file') == start_file:
                self.group_index = i
                break
        self.start_url = kwargs.get('start_url', '')
        self.jump_to_playing = kwargs.get('jump_to_playing', False)
        if not self.start_url and not kwargs.get('start_file', ''):
            from favorites_epg_window import load_last_channel
            last = load_last_channel()
            if last.get('url'):
                self.start_url = last['url']
                self._last_group_file = last.get('group_file', '')
                self.jump_to_playing = True
        self.all_channels = []
        self.channels = []                     # nach Suchfilter
        self.query = ''
        self.chosen = None
        self.chosen_num = 0
        self.switch_to = ''
        self.next_path = ''
        self.resume_video = False              # Zurück bei laufendem Sender: zurück zum Vollbild
        self._restore_pos = None
        self._restore_ticks = 0
        self._gen = 0                          # Version der Senderliste (bricht Nachladen ab)
        self._list_lock = threading.Lock()
        self._shown_pos = -1
        self._cand, self._stable = -1, 0
        self._stop = threading.Event()
        self._lock = threading.Lock()

    # ── Lebenszyklus ────────────────────────────────────────────────────────
    def onInit(self):
        self.ch_list = self.getControl(CH_LIST)
        self.ev_list = self.getControl(EV_LIST)
        self.setProperty('date', E.date_long())
        self._load_channels()
        from epg_group_data import find_start_channel
        index = find_start_channel(self) if self.start_url else None
        self._fill_channels(fallback_pos=index if index is not None else 0, restore_start=index is not None)
        if self.ch_list.size():
            self.setFocusId(CH_LIST)
        xbmc.log('VAVOO Guide Plus: Startposition {}, Treffer {}'.format(
            self.ch_list.getSelectedPosition(), index is not None), xbmc.LOGINFO)
        self.start_url = ''
        if not getattr(self, '_poller', None):
            self._poller = threading.Thread(target=self._poll, daemon=True)
            self._poller.start()

    def close(self):
        self._stop.set()
        super().close()

    def state(self):
        group = '__vavoo_channels__' if self.group_index == -2 else ('' if self.group_index == -1 else self.groups[self.group_index].get('file', ''))
        pos = self.ch_list.getSelectedPosition() if getattr(self, 'ch_list', None) else -1
        url = self.channels[pos].get('url', '') if 0 <= pos < len(self.channels) else ''
        return group, url

    # ── Daten ───────────────────────────────────────────────────────────────
    def _load_channels(self):
        if self.group_index == -2:
            try:
                self.all_channels = vavoo_channels(ADDON)
            except Exception as exc:
                xbmc.log('VAVOO Senderliste: {}'.format(exc), xbmc.LOGWARNING)
                self.all_channels = []
        else:
            self.all_channels = favorite_channels(self.gf, self.groups, self.group_index)
        self._apply_filter()

    def _apply_filter(self):
        q = self.query.casefold().strip()
        self.channels = [c for c in self.all_channels if (c.get('_header') or q in c['name'].casefold())] if q else list(self.all_channels)

    # ── Linke Spalte: Senderliste ───────────────────────────────────────────
    def _channel_item(self, n, ch, now_utc, shift):
        li = xbmcgui.ListItem(ch['name'], offscreen=True)
        if ch.get('_header'):
            li.setProperty('group_header', '1')
            li.setArt({'icon': ch.get('logo') or DEFAULT_ICON, 'thumb': ch.get('logo') or DEFAULT_ICON})
            return li
        logo = ch.get('logo') or DEFAULT_ICON
        li.setArt({'icon': logo, 'thumb': logo})
        li.setProperty('num', str(n))
        progs = E.sorted_programmes(self.api, ch)
        i = E.current_index(progs, now_utc)
        if i >= 0:
            start, stop, title, _desc = progs[i]
            li.setLabel2(title or '')
            li.setProperty('cur_span', E.span(start - shift, stop - shift))
            left = max(1, int((stop - now_utc).total_seconds() // 60))
            li.setProperty('remain', 'noch {} Min.'.format(left))
            _set_progress(li, (now_utc - start).total_seconds(), (stop - start).total_seconds())
            if i + 1 < len(progs):
                ns, ne, nt, _nd = progs[i + 1]
                li.setProperty('nxt_span', E.span(ns - shift, ne - shift))
                li.setProperty('nxt_title', nt or '')
        return li

    def _fill_channels(self, select_url='', select_group=None, fallback_pos=0, restore_start=False):
        """Erste Sender sofort anzeigen, den Rest in kleinen Paketen nachladen.

        Das hält das Öffnen schnell und belastet ein laufendes Fernsehbild nicht
        (wichtig bei schwachen Geräten wie Fire TV Stick).
        """
        with self._list_lock:
            self._gen += 1
            self._restore_pos = None
            gen = self._gen
            now_utc = datetime.datetime.utcnow()
            shift = E.utc_shift()
            select = max(0, min(fallback_pos, len(self.channels) - 1))
            from epg_group_data import same_channel_url
            for n, ch in enumerate(self.channels):
                if (select_url and not ch.get('_header') and same_channel_url(ch.get('url'), select_url)
                        and (select_group is None or ch.get('_group_file', '') == select_group)):
                    select = n
                    break
            if self.channels and self.channels[select].get('_header'):
                select = next((i for i in range(select, len(self.channels)) if not self.channels[i].get('_header')), select)
            first = min(len(self.channels), max(CHUNK, select + CHUNK))
            items = [self._channel_item(n + 1, self.channels[n], now_utc, shift) for n in range(first)]
            self.ch_list.reset()
            self.ch_list.addItems(items)
            if items:
                self.ch_list.selectItem(select)
                if restore_start:
                    self._restore_pos = select
                    self._restore_ticks = 5
        name = ('VAVOO Channels' if self.group_index == -2 else
                ('Alle Favoriten' if self.group_index == -1 else self.groups[self.group_index]['name']))
        label = 'Kanalliste  ·  {}  ·  {} Sender'.format(name, sum(not c.get('_header') for c in self.channels))
        if self.query:
            label += '  ·  Suche: "{}"'.format(self.query)
        self.setProperty('selected_group', name)
        self.setProperty('header', label)
        self._shown_pos = -1                  # Mittelspalte neu laden
        self._cand, self._stable = -1, 0
        self._fill_events(select if items else -1)
        if first < len(self.channels):
            threading.Thread(target=self._append_rest, args=(gen, first), daemon=True).start()

    def _append_rest(self, gen, start):
        monitor = xbmc.Monitor()
        now_utc = datetime.datetime.utcnow()
        shift = E.utc_shift()
        pos = start
        while pos < len(self.channels):
            if self._stop.is_set() or gen != self._gen or monitor.abortRequested():
                return
            chunk = [self._channel_item(n + 1, self.channels[n], now_utc, shift)
                     for n in range(pos, min(pos + CHUNK, len(self.channels)))]
            with self._list_lock:
                if gen != self._gen or self._stop.is_set():
                    return
                selected = self.ch_list.getSelectedPosition()
                self.ch_list.addItems(chunk)
                target = self._restore_pos if self._restore_pos is not None else selected
                if 0 <= target < self.ch_list.size() and self.ch_list.getSelectedPosition() != target:
                    self.ch_list.selectItem(target)
            pos += CHUNK
            monitor.waitForAbort(0.05)        # zwischen den Paketen Luft für Video und Oberfläche

    @staticmethod
    def _clean_epg_description(value):
        """Normalize escaped XMLTV line breaks for Kodi's textbox."""
        text = value or 'Keine Beschreibung vorhanden.'
        # Some EPG feeds escape the backslash itself; normalize both forms.
        text = text.replace('\\\\r\\\\n', '\n').replace('\\\\n', '\n')
        text = text.replace('\\r\\n', '\n').replace('\\n', '\n').replace('\\r', '\n')
        return text.replace('\r\n', '\n').replace('\r', '\n')

    # ── Mittlere Spalte: kommende Sendungen ─────────────────────────────────
    def _fill_events(self, pos):
        with self._lock:
            self._shown_pos = pos
            self.ev_list.reset()
            if not (0 <= pos < len(self.channels)):
                return
            ch = self.channels[pos]
            if ch.get('_header'):
                return
            now_utc = datetime.datetime.utcnow()
            shift = E.utc_shift()
            progs = E.sorted_programmes(self.api, ch)
            i = E.current_index(progs, now_utc)
            if i < 0:                         # nichts läuft: ab der nächsten Sendung
                i = next((k for k, p in enumerate(progs) if p[0] > now_utc), len(progs))
            items = []
            for start, stop, title, desc in progs[i:i + MAX_EVENTS]:
                ls, le = start - shift, stop - shift
                li = xbmcgui.ListItem(title or 'Ohne Titel', '{} {:02d}.{:02d}, {}'.format(
                    E.WD_SHORT[ls.weekday()], ls.day, ls.month, E.hhmm(ls)), offscreen=True)
                running = start <= now_utc < stop
                li.setProperty('now', '1' if running else '')
                li.setProperty('past', '1' if stop <= now_utc else '')
                li.setProperty('desc', self._clean_epg_description(desc))
                li.setProperty('span', E.span(ls, le))
                li.setProperty('dur', '{} min'.format(E.minutes(start, stop)))
                items.append(li)
            if not items:
                li = xbmcgui.ListItem('Keine EPG-Daten', '', offscreen=True)
                li.setProperty('desc', 'Für diesen Sender liegen keine Programmdaten vor.')
                items.append(li)
            self.ev_list.addItems(items)
            self.ev_list.selectItem(0)

    def _restore_start_selection(self):
        """Apply the shared startup target after Kodi has initialized the dialog."""
        with self._list_lock:
            target = self._restore_pos
            if target is None or self._stop.is_set():
                return
            if 0 <= target < self.ch_list.size():
                if self.ch_list.getSelectedPosition() != target:
                    self.ch_list.selectItem(target)
                self._restore_ticks -= 1
                if self._restore_ticks <= 0:
                    xbmc.log("VAVOO Guide Plus: Fokus Ziel {}, Ist {}".format(target, self.ch_list.getSelectedPosition()), xbmc.LOGINFO)
                    self._restore_pos = None

    def _poll(self):
        """Senderwechsel erkennen (Tasten, Maus, Touch) und die Mittelspalte entprellt nachladen."""
        while not self._stop.wait(0.1):
            if self._sender_dialog_active:
                continue
            try:
                self._restore_start_selection()
                pos = self.ch_list.getSelectedPosition()
                if pos == self._shown_pos:
                    self._cand, self._stable = pos, 0
                    continue
                if pos == self._cand:
                    self._stable += 1
                else:
                    self._cand, self._stable = pos, 0
                if self._stable >= 2:         # ~0,2 s Ruhe
                    self._fill_events(pos)
            except Exception:
                continue

    # ── Aktionen ────────────────────────────────────────────────────────────
    def _choose_group(self):
        options = ['Alle Favoriten'] + [g['name'] for g in self.groups] + ['VAVOO Channels']
        choice = xbmcgui.Dialog().select('Sendergruppe wählen', options, preselect=(len(options)-1 if self.group_index == -2 else self.group_index + 1))
        if choice >= 0:
            self.group_index = -2 if choice == len(options)-1 else choice - 1
            ADDON.setSetting('multiepg_last_group_file',
                '__vavoo_channels__' if self.group_index == -2 else
                (self.groups[self.group_index]['file'] if self.group_index >= 0 else ''))
            self._load_channels()
            self._fill_channels()

    def _search(self):
        text = xbmcgui.Dialog().input('Sender suchen (leer = alle)', defaultt=self.query,
                                      type=xbmcgui.INPUT_ALPHANUM)
        self.query = text.strip()
        self._apply_filter()
        self._fill_channels()

    def _jump_event(self, hour=None):
        """hour=None: laufende Sendung; sonst erste Sendung ab hour:15 (Primetime)."""
        n = self.ev_list.size()
        if n == 0:
            return
        if hour is None:
            self.ev_list.selectItem(0)
            return
        target = datetime.datetime.now().replace(hour=hour, minute=15, second=0, microsecond=0)
        if target < datetime.datetime.now():
            target += datetime.timedelta(days=1)
        pos = self._shown_pos
        progs = E.sorted_programmes(self.api, self.channels[pos]) if 0 <= pos < len(self.channels) else []
        shift = E.utc_shift()
        now_utc = datetime.datetime.utcnow()
        i0 = E.current_index(progs, now_utc)
        if i0 < 0:
            i0 = next((k for k, p in enumerate(progs) if p[0] > now_utc), len(progs))
        for k, p in enumerate(progs[i0:i0 + n]):
            if p[1] - shift > target:
                self.ev_list.selectItem(k)
                return
        self.ev_list.selectItem(n - 1)

    def _play(self):
        pos = self.ch_list.getSelectedPosition()
        if 0 <= pos < len(self.channels) and not self.channels[pos].get('_header'):
            self.chosen = self.channels[pos]
            self.chosen_num = pos + 1
            self.close()

    def onClick(self, controlId):
        self._restore_pos = None
        if self._sender_dialog_active:
            return
        if controlId in (CH_LIST, EV_LIST):
            self._play()
        elif controlId == 11:
            self._choose_group()

    def _context_actions(self):
        if self.getFocusId() not in (CH_LIST, EV_LIST):
            return
        pos = self.ch_list.getSelectedPosition()
        if not 0 <= pos < len(self.channels):
            return
        channel = self.channels[pos]
        if channel.get('_header'):
            return
        from epg_sender_actions import context_actions
        self._sender_dialog_active = True
        try:
            operation = context_actions(self.gf, self.groups, channel, self._repair_callback)
        finally:
            self._sender_dialog_active = False
        if not operation:
            return
        # Stop the old batch before replacing its backing data.
        with self._list_lock:
            self._gen += 1
        self._load_channels()
        self._fill_channels(select_url='' if operation == 'remove' else channel.get('url', ''),
                            select_group=channel.get('_group_file', ''), fallback_pos=pos)
        if self.ch_list.size():
            self.setFocusId(CH_LIST)

    def onAction(self, action):
        if self._sender_dialog_active:
            return
        code = action.getId()
        if code:
            self._restore_pos = None
        if code in ACT_CLOSE:
            self.resume_video = bool(xbmc.getCondVisibility('Player.HasVideo'))
            self.close()
        elif code in (117, 101):
            self._context_actions()
        elif code == ACT_GREEN:
            self._jump_event(None)
        elif code == ACT_YELLOW:
            self._jump_event(20)
        elif code == ACT_BLUE:
            self._choose_group()
