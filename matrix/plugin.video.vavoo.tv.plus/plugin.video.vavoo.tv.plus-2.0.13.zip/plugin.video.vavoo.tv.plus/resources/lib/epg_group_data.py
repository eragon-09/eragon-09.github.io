# -*- coding: utf-8 -*-
"""Gemeinsame Gruppenauswahl und Senderdaten für beide EPG-Ansichten."""
import os

import xbmc


def visible_groups(groups):
    result, files, names = [], set(), set()
    for group in groups:
        filename = (group.get('file') or '').strip().casefold()
        name = (group.get('name') or '').strip().casefold()
        if (not filename or filename in files or name in names
                or filename in ('alle_favoriten.m3u', 'all_favorites.m3u')
                or name in ('alle favoriten', 'meine favoriten')):
            continue
        files.add(filename)
        names.add(name)
        result.append(group)
    return result


def favorite_channels(gf, groups, group_index):
    selected = groups if group_index == -1 else [groups[group_index]]
    channels = []
    for group in selected:
        valid = [dict(ch, _group_file=group['file'])
                 for ch in gf.load_group_channels(group['file'])
                 if ch.get('name') and ch.get('url')]
        if group_index == -1 and valid:
            channels.append({'_header': True, 'name': group['name'],
                             '_group_file': group['file'],
                             'logo': gf.get_group_icon(group['file'])})
        channels.extend(valid)
    return channels


def vavoo_channels(addon):
    from vavoo_api import (get_available_countries, fetch_channels_for_group,
                           get_channel_logo, get_channel_epg_id, parse_country_codes)
    countries = get_available_countries()
    selected = addon.getSetting('selected_countries').strip()
    if selected:
        wanted = parse_country_codes(selected)
        countries = [country for country in countries if country in wanted] or countries
    channels = []
    for country in countries:
        for name, urls in (fetch_channels_for_group(country) or {}).items():
            for url in (urls if isinstance(urls, (list, tuple)) else [urls]):
                if url:
                    channels.append({'name': name, 'url': url,
                                     'logo': get_channel_logo(name) or '',
                                     'tvg_id': get_channel_epg_id(name) or '',
                                     '_vavoo_catalog': True})
    return channels


def refresh_all_favorites_m3u(gf, groups):
    """Alle_Favoriten.m3u nur bei Bedarf und im dauerhaft laufenden Service.

    Frueher wurden bei JEDEM Oeffnen alle Favoritenlisten ein zweites Mal geparst
    und die Gesamtliste neu aufgebaut. Jetzt wird nur anhand der Dateizeiten
    geprueft; ist etwas neuer, laeuft der Neuaufbau im Hintergrund.
    """
    target = ''
    try:
        target = gf._group_m3u_path('Alle_Favoriten.m3u')
        stale = True
        if os.path.isfile(target):
            built = os.path.getmtime(target)
            sources = [gf._groups_json_path()]
            for group in groups:
                filename = group.get('file', '')
                if filename:
                    sources.append(gf._group_m3u_path(filename))
            icons = getattr(gf, '_group_icons', None)
            if icons is not None:
                sources.append(icons.user_icons_dir())
            newest = max((os.path.getmtime(p) for p in sources if os.path.exists(p)), default=0)
            stale = newest > built
    except Exception:
        stale = True
    if not stale:
        return
    # Only called by the persistent service. Explicit edits use the same lock.
    try:
        started = __import__('time').time()
        result = gf.rebuild_all_favorites_m3u()
        if result and os.path.isfile(result):
            # Never mark edits made during the rebuild as already processed.
            os.utime(result, (started, started))
    except Exception as exc:
        xbmc.log('VAVOO: Gesamt-M3U: {}'.format(exc), xbmc.LOGWARNING)



def same_channel_url(a, b):
    return bool(a and b and a.split('|', 1)[0].strip() == b.split('|', 1)[0].strip())


def clean_description(text):
    return (text.replace('\\\\r\\\\n', '\n').replace('\\\\n', '\n')
            .replace('\\r\\n', '\n').replace('\\n', '\n').replace('\\r', '\n')
            .replace('\r\n', '\n').replace('\r', '\n'))


def find_start_channel(window):
    """Shared startup lookup; preserve the timeline's group fallback order."""
    def locate():
        for i, channel in enumerate(window.channels):
            if not channel.get('_header') and same_channel_url(channel.get('url'), window.start_url):
                return i
        return None

    found = locate()
    if found is not None or not window.jump_to_playing:
        return found
    if window._last_group_file:
        for i, group in enumerate(window.groups):
            if group.get('file') == window._last_group_file:
                if window.group_index != i:
                    window.group_index = i
                    window._load_channels()
                found = locate()
                if found is not None:
                    return found
                break
    if window.group_index != -1:
        window.group_index = -1
        window._load_channels()
    return locate()
