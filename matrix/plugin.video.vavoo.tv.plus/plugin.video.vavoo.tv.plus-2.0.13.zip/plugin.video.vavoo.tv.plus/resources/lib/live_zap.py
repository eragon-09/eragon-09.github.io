# -*- coding: utf-8 -*-
"""Native Kodi video playlist; resolve only the selected live channel."""
from urllib.parse import urlencode
import xbmc
import xbmcgui


def channel_entries(channels, chosen):
    valid = [c for c in channels if not c.get('_header') and c.get('url') and c.get('name')]
    index = next((i for i, c in enumerate(valid) if c is chosen), None)
    if index is None:
        index = next((i for i, c in enumerate(valid) if c == chosen), None)
    if index is None:
        valid = [chosen]
        index = 0
    return valid, index


def start_channel_playlist(channels, chosen, direct_item=None):
    """direct_item=(Stream-URL, ListItem): bereits aufgelöster Sender der Live-Vorschau.

    Er wird für den gewählten Eintrag verwendet, damit das Vollbild ohne erneutes
    Auflösen startet. Alle anderen Einträge bleiben normale Zap-Plugin-Pfade.
    """
    valid, index = channel_entries(channels, chosen)
    paths = []
    for channel in valid:
        params = dict(action='play_live_zap', url=channel['url'], name=channel['name'],
                      tvg_id=channel.get('tvg_id') or '', logo=channel.get('logo') or '',
                      file=channel.get('_group_file') or ('__vavoo_channels__' if channel.get('_vavoo_catalog') else ''))
        paths.append('plugin://plugin.video.vavoo.tv.plus/?' + urlencode(params))
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    player = xbmc.Player()
    # Reuse the active native playlist when its contents and position match.
    # Let Kodi handle stream transitions; do not stop or wait explicitly.
    if player.isPlayingVideo():
        try:
            if (playlist.size() == len(paths) and playlist.getposition() == index
                    and all(playlist[i].getPath() == path for i, path in enumerate(paths))
                    and xbmcgui.Window(10000).getProperty('VavooTVPlus.ConfirmedURL') == chosen['url']
                    and player.getPlayingFile().split('|', 1)[0] == xbmcgui.Window(10000).getProperty('VavooTVPlus.ConfirmedFile')):
                return False          # läuft schon, nichts neu gestartet
        except Exception:
            pass
    xbmcgui.Window(10000).clearProperty("VavooTVPlus.SkipCount")
    playlist.clear()
    playlist.unshuffle()
    for n, (channel, path) in enumerate(zip(valid, paths)):
        if direct_item and n == index:
            playlist.add(direct_item[0], direct_item[1])
            continue
        item = xbmcgui.ListItem(label=channel['name'], path=path)
        item.setProperty('IsPlayable', 'true')
        logo = channel.get('logo') or ''
        if logo:
            item.setArt({'thumb': logo, 'icon': logo})
        item.getVideoInfoTag().setTitle(channel['name'])
        playlist.add(path, item)
    player.play(playlist, startpos=index)
    return True
