"""Confirmed film series; optional official TMDB API for additional collections."""
import xbmc, xbmcaddon
from concurrent.futures import ThreadPoolExecutor
import geil_vod as api


class _LazyRequests(object):
    """Laedt ``requests`` erst bei der ersten Benutzung (schnellerer Skriptstart)."""
    def __getattr__(self, name):
        import requests as _requests
        return getattr(_requests, name)


requests = _LazyRequests()

# TMDB movie IDs in theatrical release order; no similarity-based grouping.
SERIES = {
  84: ('Indiana Jones', [(85,'Jäger des verlorenen Schatzes','1981-06-12'),(87,'Indiana Jones und der Tempel des Todes','1984-05-23'),(89,'Indiana Jones und der letzte Kreuzzug','1989-05-24'),(217,'Indiana Jones und das Königreich des Kristallschädels','2008-05-21'),(335977,'Indiana Jones und das Rad des Schicksals','2023-06-28')]),
  263: ('Batman – The Dark Knight', [(272,'Batman Begins','2005-06-10'),(155,'The Dark Knight','2008-07-16'),(49026,'The Dark Knight Rises','2012-07-17')]),
  1241: ('Harry Potter', [(671,'Harry Potter und der Stein der Weisen','2001-11-16'),(672,'Harry Potter und die Kammer des Schreckens','2002-11-13'),(673,'Harry Potter und der Gefangene von Askaban','2004-05-31'),(674,'Harry Potter und der Feuerkelch','2005-11-16'),(675,'Harry Potter und der Orden des Phönix','2007-07-08'),(767,'Harry Potter und der Halbblutprinz','2009-07-15'),(12444,'Harry Potter und die Heiligtümer des Todes – Teil 1','2010-11-17'),(12445,'Harry Potter und die Heiligtümer des Todes – Teil 2','2011-07-12')]),
  264: ('Zurück in die Zukunft', [(105,'Zurück in die Zukunft','1985-07-03'),(165,'Zurück in die Zukunft II','1989-11-22'),(196,'Zurück in die Zukunft III','1990-05-25')]),
  131292: ('Iron Man', [(1726,'Iron Man','2008-04-30'),(10138,'Iron Man 2','2010-04-28'),(68721,'Iron Man 3','2013-04-18')]),
  531241: ('Spider-Man (MCU)', [(315635,'Spider-Man: Homecoming','2017-07-05'),(429617,'Spider-Man: Far From Home','2019-06-28'),(634649,'Spider-Man: No Way Home','2021-12-15'),(969681,'Spider-Man: Brand New Day','2026-07-31')]),
  556: ('Spider-Man (Sam Raimi)', [(557,'Spider-Man','2002-05-01'),(558,'Spider-Man 2','2004-06-25'),(559,'Spider-Man 3','2007-05-01')]),
  125574: ('The Amazing Spider-Man', [(1930,'The Amazing Spider-Man','2012-06-23'),(102382,'The Amazing Spider-Man 2: Rise of Electro','2014-04-16')]),
  119: ('Der Herr der Ringe', [(120,'Der Herr der Ringe: Die Gefährten','2001-12-18'),(121,'Der Herr der Ringe: Die zwei Türme','2002-12-18'),(122,'Der Herr der Ringe: Die Rückkehr des Königs','2003-12-17')]),
  121938: ('Der Hobbit', [(49051,'Der Hobbit: Eine unerwartete Reise','2012-12-12'),(57158,'Der Hobbit: Smaugs Einöde','2013-12-11'),(122917,'Der Hobbit: Die Schlacht der Fünf Heere','2014-12-10')]),
  10: ('Star Wars – Skywalker-Saga', [(11,'Krieg der Sterne','1977-05-25'),(1891,'Das Imperium schlägt zurück','1980-05-20'),(1892,'Die Rückkehr der Jedi-Ritter','1983-05-25'),(1893,'Star Wars: Episode I','1999-05-19'),(1894,'Star Wars: Episode II','2002-05-15'),(1895,'Star Wars: Episode III','2005-05-17'),(140607,'Das Erwachen der Macht','2015-12-15'),(181808,'Die letzten Jedi','2017-12-13'),(181812,'Der Aufstieg Skywalkers','2019-12-18')]),
  328: ('Jurassic Park / Jurassic World', [(329,'Jurassic Park','1993-06-11'),(330,'Vergessene Welt: Jurassic Park','1997-05-23'),(331,'Jurassic Park III','2001-07-18'),(135397,'Jurassic World','2015-06-06'),(351286,'Jurassic World: Das gefallene Königreich','2018-06-06'),(507086,'Jurassic World: Ein neues Zeitalter','2022-06-01'),(1234821,'Jurassic World: Die Wiedergeburt','2025-07-02')]),
  9485: ('Fast & Furious', [(9799,'The Fast and the Furious','2001-06-22'),(584,'2 Fast 2 Furious','2003-06-05'),(9615,'The Fast and the Furious: Tokyo Drift','2006-06-03'),(13804,'Fast & Furious – Neues Modell. Originalteile.','2009-04-02'),(51497,'Fast & Furious Five','2011-04-20'),(82992,'Fast & Furious 6','2013-05-21'),(168259,'Fast & Furious 7','2015-04-01'),(337339,'Fast & Furious 8','2017-04-12'),(385128,'Fast & Furious 9','2021-05-19'),(385687,'Fast & Furious 10','2023-05-17')]),
}

def credential():
    return xbmcaddon.Addon().getSetting('tmdb_collection_key').strip() or '0b529d296545c2545a68db5cb903cd94'

def get(path, **params):
    token=credential()
    if not token: return {}
    headers={'Accept':'application/json'}
    if len(token)>40: headers['Authorization']='Bearer '+token
    else: params['api_key']=token
    try:
        r=requests.get('https://api.themoviedb.org/3'+path,params=dict(params,language='de-DE'),headers=headers,timeout=(3,8))
        r.raise_for_status(); data=r.json()
        return data if isinstance(data,dict) else {}
    except (requests.RequestException,ValueError) as e:
        xbmc.log('TMDB collections: request failed HTTP %s'%getattr(getattr(e,'response',None),'status_code',None),xbmc.LOGWARNING)
        return {}

def convert(x):
    i=str(x['id']); poster=x.get('poster_path')
    return dict(id='movie.'+i,tmdb=i,n=x.get('title') or x.get('original_title') or i,poster='https://image.tmdb.org/t/p/w500'+poster if poster else '',fanart='https://image.tmdb.org/t/p/w1280'+x['backdrop_path'] if x.get('backdrop_path') else '',plot=x.get('overview') or '',releaseDate=x.get('release_date') or '')

def load(cid):
    cid=int(cid)
    data=get('/collection/'+str(cid))
    if data.get('parts'):
        return data.get('name') or 'Filmreihe', sorted([convert(x) for x in data['parts'] if x.get('id')],key=lambda x:(x['releaseDate'] or '9999',x['id']))
    if cid not in SERIES: return '',[]
    name, parts=SERIES[cid]
    def detail(part):
        i,n,date=part; x=api.get(api.META,'/item/video/'+str(i)+'.json')
        return dict(id='movie.'+str(i),tmdb=str(i),n=x.get('name') or n,poster=(x.get('images') or {}).get('poster',''),plot=x.get('description') or '',releaseDate=x.get('releaseDate') or date)
    with ThreadPoolExecutor(max_workers=5) as pool: entries=list(pool.map(detail,parts))
    return name,sorted(entries,key=lambda x:(x['releaseDate'] or '9999',x['id']))

def find(movie):
    movie=str(movie)
    if not movie.isdigit(): return '',[]
    data=get('/movie/'+movie)
    cid=(data.get('belongs_to_collection') or {}).get('id')
    if cid:
        name,entries=load(cid)
        if any(x['tmdb']==movie for x in entries): return name,entries
    for cid,(_,parts) in SERIES.items():
        if any(str(x[0])==movie for x in parts): return load(cid)
    return '',[]

def search(query):
    data=get('/search/collection',query=query)
    return [(x['id'],x.get('name') or str(x['id']),x.get('poster_path')) for x in data.get('results',[]) if x.get('id')]
