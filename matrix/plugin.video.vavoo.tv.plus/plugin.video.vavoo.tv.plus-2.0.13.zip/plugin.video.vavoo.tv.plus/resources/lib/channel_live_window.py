# -*- coding: utf-8 -*-
"""Vavoo Live-Guide: Senderliste mit Live-TV-Vorschau (dritte EPG-Ansicht).

Erbt alles von ChannelListEPG (Gruppenwahl, Kontextaktionen, Farbtasten,
Sendungsliste, Beschreibung, Start auf dem laufenden Sender, Zap-Liste beim
Bestätigen). Neu ist nur: Bleibt die Auswahl kurz auf einem Sender stehen,
wird dieser Sender im Vorschaufenster rechts oben abgespielt.

Das eigentliche Abspielen übernimmt ``preview_callback`` (addon.py). Es nutzt
denselben Auflöse- und Wiedergabeweg wie der normale Senderstart, startet aber
fensterweise (windowed), damit das Fenster geöffnet bleibt.
"""
import threading
import time

import xbmc
import xbmcgui

from channel_list_window import ChannelListEPG, ACT_CLOSE
from epg_group_data import same_channel_url

HOME_ID = 10000
PREVIEW_STABLE_TICKS = 7        # 7 x 0,1 s Ruhe, bevor der Sender umgeschaltet wird
HEARTBEAT_TICKS = 10            # alle ~1 s meldet das Fenster dem Service "ich bin offen"
PREVIEW_TIMEOUT = 25            # Sekunden bis "Stream nicht verfügbar"
START_TIMEOUT = 25              # Sekunden bis der gewählte Sender im Vollbild laufen muss
FULLSCREEN_VIDEO = 12005

MSG_LOADING = 'Live-Vorschau wird geladen …'
MSG_FAILED = 'Stream nicht verfügbar'
MSG_STARTING = 'Sender wird gestartet …'


class ChannelListLive(ChannelListEPG):
    def __init__(self, *args, **kwargs):
        self._return_from_fullscreen = kwargs.pop("return_from_fullscreen", False)
        self._preview_callback = kwargs.pop('preview_callback', None)
        self._start_callback = kwargs.pop('start_callback', None)
        super().__init__(*args, **kwargs)
        self._home = xbmcgui.Window(HOME_ID)
        self._preview_url = ''            # Sender, für den zuletzt eine Vorschau angefordert wurde
        self._pending_url = ''            # Vorschau, deren Start noch bestätigt werden muss
        self._pending_since = 0.0
        self._stream_properties = {}
        self._stream_info_due = 0.0
        self._stream_info_url = ""
        self._preview_started = False     # in dieser Sitzung wurde ein Sender umgeschaltet
        self._was_playing = False
        self.stop_on_exit = False         # Zurück ohne vorherige Wiedergabe: Vorschau beenden
        self._starting = False            # gewählter Sender wird gerade im Vollbild gestartet
        self.started = False              # Wiedergabe wurde schon vom Fenster aus gestartet

    # ── Lebenszyklus ────────────────────────────────────────────────────────
    def onInit(self):
        self._was_playing = bool(self._playing_channel_url())
        self._home.clearProperty("VavooTVPlus.LiveGuideFullscreen")
        self._beat()
        super().onInit()
        if self._return_from_fullscreen and xbmcgui.getCurrentWindowId() == 12005:
            # The opaque guide is already open; change the underlying window now.
            xbmc.executebuiltin("ActivateWindow(videos)", True)
        self._preview_url = self._playing_channel_url()
        self.setProperty('preview_msg', '')
        if not getattr(self, '_preview_thread', None):
            self._preview_thread = threading.Thread(target=self._preview_loop, daemon=True)
            self._preview_thread.start()

    def close(self):
        # Service soll das Beenden/Umschalten der Vorschau nicht als "Live-TV beendet"
        # werten und kein zweites Fenster öffnen.
        self._stop.set()
        if self.chosen and self._playing_channel_url():
            xbmc.executebuiltin("ActivateWindow(fullscreenvideo)", True)
        self._home.setProperty('VavooTVPlus.SuppressReturnUntil', str(time.time() + (0.0 if self.chosen else 1.5)))
        self._home.clearProperty('VavooTVPlus.PreviewActive')
        super().close()

    def _beat(self):
        self._home.setProperty('VavooTVPlus.PreviewActive', str(time.time()))

    # ── Hilfen ──────────────────────────────────────────────────────────────
    def _playing_channel_url(self):
        """URL des Senders, der gerade bestätigt läuft ('' wenn keiner)."""
        try:
            player = xbmc.Player()
            if not player.isPlayingVideo():
                return ''
            confirmed_file = self._home.getProperty('VavooTVPlus.ConfirmedFile')
            if confirmed_file and player.getPlayingFile().split('|', 1)[0] == confirmed_file:
                return self._home.getProperty('VavooTVPlus.ConfirmedURL')
        except Exception:
            pass
        return ''

    def _fill_channels(self, *args, **kwargs):
        super()._fill_channels(*args, **kwargs)
        # Kurze Kopfzeile: Die Gruppe steht schon im Auswahlknopf.
        label = '{} Sender'.format(sum(not c.get('_header') for c in self.channels))
        if self.query:
            label += '  ·  Suche: "{}"'.format(self.query)
        self.setProperty('header', label)

    def _fill_events(self, pos):
        super()._fill_events(pos)
        for field in ('title', 'desc', 'span', 'dur', 'now'):
            self.setProperty('live_current_' + field, '')
        for i in (1, 2):
            for field in ('time', 'title'):
                self.setProperty('live_next_{}_{}'.format(i, field), '')
        if not self.ev_list.size():
            return
        current = self.ev_list.getListItem(0)
        if current.getProperty('now') or not current.getLabel2():
            self.setProperty('live_current_title', current.getLabel())
            for field in ('desc', 'span', 'dur', 'now'):
                self.setProperty('live_current_' + field, current.getProperty(field))
        else:
            self.setProperty('live_current_title', 'Keine laufende Sendung')
        offset = 1 if current.getProperty('now') else 0
        for i in (1, 2):
            index = offset + i - 1
            if index < self.ev_list.size():
                item = self.ev_list.getListItem(index)
                if item.getLabel2():
                    self.setProperty('live_next_{}_time'.format(i), item.getLabel2())
                    self.setProperty('live_next_{}_title'.format(i), item.getLabel())

    # ── Live-Vorschau ───────────────────────────────────────────────────────
    def _set_stream_property(self, name, value):
        if self._stream_properties.get(name) != value:
            self.setProperty(name, value)
            self._stream_properties[name] = value

    def _update_stream_info(self):
        resolution = xbmc.getInfoLabel('VideoPlayer.VideoResolution').strip().lower()
        scan = xbmc.getInfoLabel('VideoPlayer.VideoScanType').strip().lower()
        height = resolution.rstrip('pi')
        if 'x' in height:
            height = height.split('x')[-1].strip()
        suffix = resolution[-1:] if resolution[-1:] in ('p', 'i') else {'progressive': 'p', 'interlaced': 'i', 'p': 'p', 'i': 'i'}.get(scan, '')
        quality = {'480': 'SD', '576': 'SD', '720': 'HD', '1080': 'Full HD', '1440': 'QHD', '2160': 'UHD', '4320': '8K'}.get(height, '')
        resolution = (' '.join(filter(None, (quality, height + suffix))) if height.isdigit() else resolution.upper())
        codec = xbmc.getInfoLabel('VideoPlayer.VideoCodec').strip()
        codec = {'h264': 'H.264', 'avc': 'H.264', 'hevc': 'H.265', 'h265': 'H.265', 'mpeg2video': 'MPEG-2', 'av1': 'AV1', 'vp9': 'VP9'}.get(codec.lower(), codec.upper())
        aspect = xbmc.getInfoLabel('VideoPlayer.VideoAspect').strip()
        try:
            ratio = float(aspect)
            for value, label in ((16/9, '16:9'), (4/3, '4:3'), (21/9, '21:9')):
                if abs(ratio - value) < 0.04:
                    aspect = label
                    break
        except ValueError:
            pass
        parts = ['[COLOR FFEAC34F][B]' + resolution + '[/B][/COLOR]' if resolution else '', codec, aspect]
        self._set_stream_property('metrix_stream_info', ''.join('  │  ' + part for part in parts if part))

    def _preview_loop(self):
        cand, stable, ticks = None, 0, 0
        while not self._stop.wait(0.1):
            try:
                ticks += 1
                if ticks % HEARTBEAT_TICKS == 0:
                    self._beat()
                self._check_preview_state()
                if ticks % 10 == 0:
                    pos_live = self.ch_list.getSelectedPosition()
                    selected = self.channels[pos_live].get("url", "") if 0 <= pos_live < len(self.channels) else ""
                    playing = self._playing_channel_url()
                    live = bool(selected and playing and same_channel_url(selected, playing) and not self._pending_url)
                    self._set_stream_property("metrix_live", "1" if live else "")
                    now = time.monotonic()
                    if live:
                        if playing != self._stream_info_url or now >= self._stream_info_due:
                            self._update_stream_info()
                            self._stream_info_url = playing
                            self._stream_info_due = now + 5.0
                    else:
                        self._stream_info_url = ""
                        self._set_stream_property("metrix_stream_info", "")
                if self._starting or self._sender_dialog_active or self._restore_pos is not None:
                    continue
                pos = self.ch_list.getSelectedPosition()
                key = (pos, self.channels[pos].get("url", ""), self.channels[pos].get("_group_file", "")) if 0 <= pos < len(self.channels) else None
                if key != cand:
                    cand, stable = key, 0
                    continue
                stable += 1
                if stable == PREVIEW_STABLE_TICKS:
                    self._start_preview(pos)
            except Exception as exc:
                xbmc.log('VAVOO Live-Vorschau: {}'.format(exc), xbmc.LOGWARNING)

    def _start_preview(self, pos):
        if not self._preview_callback or not (0 <= pos < len(self.channels)):
            return
        channel = self.channels[pos]
        url = channel.get('url', '')
        if channel.get('_header') or not url:
            return
        if self._preview_url and same_channel_url(self._preview_url, url):
            return                                    # läuft bereits / wurde schon angefordert
        playing = self._playing_channel_url()
        if playing and same_channel_url(playing, url):
            self._preview_url = url
            self.setProperty('preview_msg', '')
            return
        self._preview_url = url
        self._pending_url = url
        self._pending_since = time.time()
        self._preview_started = True
        self._set_stream_property('metrix_live', '')
        self._set_stream_property('metrix_stream_info', '')
        self._stream_info_url = ''
        self.setProperty('preview_msg', MSG_LOADING)
        try:
            def cancelled():
                if self._stop.is_set() or self._sender_dialog_active:
                    return True
                current = self.ch_list.getSelectedPosition()
                return not (0 <= current < len(self.channels) and self.channels[current] is channel)
            ok = self._preview_callback(channel, cancelled)
            if cancelled():
                self._preview_url = self._pending_url = ""
                return
        except Exception as exc:
            xbmc.log('VAVOO Live-Vorschau: Start fehlgeschlagen: {}'.format(exc), xbmc.LOGWARNING)
            ok = False
        if not ok and not self._stop.is_set():
            self._pending_url = ''
            self.setProperty('preview_msg', MSG_FAILED)

    def _check_preview_state(self):
        """Blendet die Meldung aus, sobald der Vorschau-Sender wirklich läuft."""
        if not self._pending_url:
            return
        playing = self._playing_channel_url()
        if playing and same_channel_url(playing, self._pending_url):
            self._pending_url = ''
            self.setProperty('preview_msg', '')
            return
        elapsed = time.time() - self._pending_since
        # Service räumt "Pending" nach einem Fehler auf; so wird der Fehler früh erkannt.
        failed = elapsed > 3.0 and not self._home.getProperty('VavooTVPlus.PendingEPGURL')
        if failed or elapsed > PREVIEW_TIMEOUT:
            self._pending_url = ''
            self.setProperty('preview_msg', MSG_FAILED)

    # ── Auswahl bestätigen: Fenster bleibt bis zum Vollbild stehen ──────────
    def _play(self):
        """Startet den Sender, während das (blickdichte) Guide-Fenster offen bleibt.

        Früher wurde das Fenster zuerst geschlossen und der Player danach neu gestartet.
        Dabei war kurz das darunterliegende Videos-Menü (Addon-Ordner) mit Ladekreis
        zu sehen. Jetzt schließt Kodi das Fenster selbst, sobald das Vollbild aktiv ist.
        """
        if not self._start_callback:
            return super()._play()
        pos = self.ch_list.getSelectedPosition()
        if self._starting or not (0 <= pos < len(self.channels)) or self.channels[pos].get('_header'):
            return
        self.chosen = self.channels[pos]
        self.chosen_num = pos + 1
        self._starting = True
        self._pending_url = ''
        self.setProperty('preview_msg', MSG_STARTING)
        threading.Thread(target=self._start_chosen, args=(list(self.channels), self.chosen),
                         daemon=True).start()

    def _start_chosen(self, channels, chosen):
        reached = False
        try:
            restarted = self._start_callback(channels, chosen)
            self.started = True
            if restarted is False:                # Sender lief schon: nur ins Vollbild
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            begin = time.time()
            while not self._stop.is_set():
                if xbmcgui.getCurrentWindowId() == FULLSCREEN_VIDEO:
                    reached = True
                    break
                elapsed = time.time() - begin
                if elapsed > START_TIMEOUT or (
                        elapsed > 6 and not self._playing_channel_url()
                        and not self._home.getProperty('VavooTVPlus.PendingEPGURL')):
                    break
                self._stop.wait(0.1)
        except Exception as exc:
            xbmc.log('VAVOO Live-Guide: Start fehlgeschlagen: {}'.format(exc), xbmc.LOGWARNING)
        if self._stop.is_set():
            return
        if reached:
            self._stop.wait(1.5)                  # Kodi schließt das Fenster normalerweise selbst
            if not self._stop.is_set():
                self.close()
            return
        self.started = False
        self.chosen = None
        self._starting = False
        self.setProperty('preview_msg', MSG_FAILED)

    # ── Aktionen ────────────────────────────────────────────────────────────
    def onClick(self, controlId):
        if controlId == 12 and not self._sender_dialog_active:
            self.stop_on_exit = True
            self._home.clearProperty("VavooTVPlus.LiveGuideFullscreen")
            self.close()
            return
        super().onClick(controlId)

    def onAction(self, action):
        if not self._sender_dialog_active and action.getId() in ACT_CLOSE:
            # Lief vorher nichts, dann soll die Vorschau nicht unsichtbar weiterlaufen.
            if self._starting:                    # Zurück während des Startens: abbrechen
                self.chosen, self.started = None, False
            self.stop_on_exit = bool(self._playing_channel_url() or self._preview_started or self._starting)
            self._home.clearProperty("VavooTVPlus.LiveGuideFullscreen")
        super().onAction(action)
