# -*- coding: utf-8 -*-
"""Gemeinsamer HTTP-Client fuer Vavoo TV Plus.

Dieses Modul kapselt nur Session-Aufbau, Retry-Verhalten und JSON-/GZIP-Dekodierung.
Die fachliche API-Logik bleibt in ``vavoo_api.py``.
"""

import gzip
import json

# ``requests`` (inkl. urllib3, ssl, idna ...) ist auf Fire TV / ARM-Geraeten teuer
# zu importieren. Es wird deshalb erst beim ersten echten Netzwerkzugriff geladen,
# damit EPG-Fenster und Senderstart nicht darauf warten muessen.
_session = None


def get_session():
    """Liefert eine wiederverwendbare requests.Session mit sicheren Retries."""
    global _session
    if _session is None:
        import requests
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        session = requests.Session()
        session.headers.update({
            "User-Agent": "okhttp/4.11.0",
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
            "Connection": "keep-alive",
        })
        retry = Retry(
            total=0,
            connect=0,
            read=0,
            status=0,
            backoff_factor=0.4,
            status_forcelist={429, 500, 502, 503, 504},
            allowed_methods={"GET"},
            respect_retry_after_header=True,
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        _session = session
    return _session


def decode_response(response):
    """Dekodiert JSON-Antworten, einschliesslich manuell gzip-komprimierter Daten."""
    content = response.content
    if content[:2] == b"\x1f\x8b":
        try:
            content = gzip.decompress(content)
        except Exception:
            pass
    try:
        return json.loads(content)
    except Exception:
        return {}
