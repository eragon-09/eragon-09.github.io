#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
sxManager - Main Entry Point
"""

import xbmcgui
from lib.sxmanager_gui import show_gui

if __name__ == '__main__':
    show_gui()