#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
sxManager Service Starter
Starts the background service for automatic domain synchronization
"""

import xbmc
import xbmcaddon
from lib.sxmanager_addon import sxmanagerService

if __name__ == '__main__':
    # Log service start
    xbmc.log("[script.module.sxManager] Service starting...", xbmc.LOGINFO)
    
    try:
        # Create and run service
        service = sxmanagerService()
        service.run()
    except Exception as e:
        xbmc.log(f"[script.module.sxManager] Service error: {str(e)}", xbmc.LOGERROR)
    
    xbmc.log("[script.module.sxManager] Service stopped", xbmc.LOGINFO)