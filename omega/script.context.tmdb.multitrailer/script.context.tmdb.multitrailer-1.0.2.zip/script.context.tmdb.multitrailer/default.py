# -*- coding: utf-8 -*-
"""Kodi context menu action: start MultiTrailer without modifying other add-ons."""
import re
from urllib.parse import urlencode

import xbmc
import xbmcgui


def info(label):
    try:
        return (xbmc.getInfoLabel(label) or '').strip()
    except Exception:
        return ''


def first(*labels):
    for label in labels:
        value = info(label)
        if value:
            return value
    return ''


def main():
    dbtype = first('ListItem.DBTYPE', 'ListItem.Property(type)', 'ListItem.Property(media_type)').lower()
    content = first('Container.Content').lower()
    media_type = 'tv' if dbtype in ('tvshow', 'season', 'episode', 'tv', 'series') or content in ('tvshows', 'seasons', 'episodes') else 'movie'
    tmdb_id = first('ListItem.UniqueID(tmdb)', 'ListItem.Property(tmdb_id)', 'ListItem.Property(tmdb)', 'ListItem.Property(TMDB_ID)')
    imdb_id = first('ListItem.UniqueID(imdb)', 'ListItem.Property(imdb_id)', 'ListItem.Property(imdb)')
    if not tmdb_id.isdigit():
        tmdb_id = ''
    if not re.fullmatch(r'tt\d+', imdb_id, re.IGNORECASE):
        imdb_id = ''
    title = first('ListItem.TVShowTitle', 'ListItem.Title', 'ListItem.Label') if media_type == 'tv' else first('ListItem.Title', 'ListItem.Label')
    year = first('ListItem.Year')
    if not re.fullmatch(r'\d{4}', year):
        year = ''
    if not (tmdb_id or imdb_id or title):
        xbmcgui.Dialog().notification('MultiTrailer', 'Keine Film- oder Serieninformationen gefunden', xbmcgui.NOTIFICATION_WARNING, 3500)
        return
    params = {'action': 'play', 'media_type': media_type}
    if tmdb_id:
        params['tmdb_id'] = tmdb_id
    if imdb_id:
        params['imdb_id'] = imdb_id
    if title:
        params['title'] = title
    if year:
        params['year'] = year
    url = 'plugin://plugin.video.multitrailer/?' + urlencode(params)
    xbmc.executebuiltin('PlayMedia("{}")'.format(url))


if __name__ == '__main__':
    main()
