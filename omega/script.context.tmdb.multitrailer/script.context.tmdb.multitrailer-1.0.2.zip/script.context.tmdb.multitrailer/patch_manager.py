# -*- coding: utf-8 -*-
# Manual TMDb Helper patch
import os
import ast
import shutil
import tempfile
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

TARGET = 'plugin.video.themoviedb.helper'
RELATIVE = os.path.join('resources', 'tmdbhelper', 'lib', 'items', 'listitem.py')
MARKER = "self.context_menu.insert(0, ('Trailer ansehen', f'PlayMedia({trailer_url})'))"
ANCHOR = '        return self.context_menu'
PATCH = '''        if self.tmdb_type in ('movie', 'tv') and self.mediatype not in ('season', 'episode'):
            from urllib.parse import urlencode
            trailer_params = {'action': 'play', 'media_type': self.tmdb_type}
            tmdb_id = self.unique_ids.get('tmdb') or self.params.get('tmdb_id')
            imdb_id = self.unique_ids.get('imdb')
            if tmdb_id:
                trailer_params['tmdb_id'] = tmdb_id
            elif imdb_id:
                trailer_params['imdb_id'] = imdb_id
            else:
                trailer_params['title'] = self.infolabels.get('title') or self.label
                year = self.infolabels.get('year')
                if year:
                    trailer_params['year'] = year
            trailer_url = 'plugin://plugin.video.multitrailer/?' + urlencode(trailer_params)
            self.context_menu.insert(0, ('Trailer ansehen', f'PlayMedia({trailer_url})'))
'''

def apply_patch(interactive=True):
    dialog = xbmcgui.Dialog()
    if interactive and not dialog.yesno('MultiTrailer Kontextmenü', 'Möchten Sie den Menüpunkt „Trailer ansehen“ im TMDb Helper hinzufügen?'):
        return
    try:
        addon = xbmcaddon.Addon(TARGET)
        root = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        path = os.path.join(root, RELATIVE)
        if not os.path.isfile(path):
            raise RuntimeError('Die erwartete TMDb-Helper-Datei wurde nicht gefunden.')
        with open(path, 'rb') as handle:
            raw = handle.read()
        text = raw.decode('utf-8-sig')
        if MARKER in text:
            if interactive:
                dialog.ok('MultiTrailer Kontextmenü', '„Trailer ansehen“ ist bereits im TMDb Helper vorhanden.')
            return
        # Support both verified TMDb Helper context menu signatures.
        signatures = (
            'self.context_menu += ContextMenu(self).get()',
            'self.context_menu += ContextMenu(self, self.context_menu_config).get()',
        )
        method = '    def finalise_context_menu(self):'
        start = text.find(method)
        while start >= 0:
            probe = text.find('\n    def ', start + len(method))
            if probe < 0:
                probe = text.find('\n    @', start + len(method))
            if probe >= 0 and any(signature in text[start:probe] for signature in signatures):
                break
            start = text.find(method, start + len(method))
        if start < 0:
            raise RuntimeError('Die Menüstruktur dieser TMDb-Helper-Version ist nicht kompatibel.')
        end = text.find('\n    def ', start + len(method))
        if end < 0:
            end = text.find('\n    @', start + len(method))
        if end < 0:
            raise RuntimeError('Die Menüstruktur konnte nicht eindeutig erkannt werden.')
        section = text[start:end]
        if section.count(ANCHOR) != 1 or sum(section.count(signature) for signature in signatures) != 1:
            raise RuntimeError('Die Menüstruktur dieser TMDb-Helper-Version hat sich geändert.')
        patched = text[:start] + section.replace(ANCHOR, PATCH + ANCHOR, 1) + text[end:]
        ast.parse(patched, filename=path)
        # Preserve original newline style and file permissions.
        newline = '\r\n' if b'\r\n' in raw else '\n'
        data = patched.replace('\n', newline).encode('utf-8')
        backup = path + '.multitrailer.bak'
        if not os.path.exists(backup):
            shutil.copy2(path, backup)
        fd, temp = tempfile.mkstemp(prefix='.multitrailer-', suffix='.py', dir=os.path.dirname(path))
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(data)
            os.chmod(temp, os.stat(path).st_mode)
            os.replace(temp, path)
        finally:
            if os.path.exists(temp):
                os.remove(temp)
        xbmc.log('[script.context.tmdb.multitrailer] TMDb Helper context menu patched: ' + path, xbmc.LOGINFO)
        if interactive:
            dialog.ok('MultiTrailer Kontextmenü', '„Trailer ansehen“ wurde hinzugefügt. Bitte Kodi neu starten, damit die Änderung wirksam wird.')
    except Exception as exc:
        xbmc.log('[script.context.tmdb.multitrailer] Patch failed: {}'.format(exc), xbmc.LOGERROR)
        if interactive:
            dialog.ok('MultiTrailer Kontextmenü', 'Die Anpassung konnte nicht durchgeführt werden.\n{}'.format(exc))

def main():
    apply_patch(interactive=True)


if __name__ == '__main__':
    main()
