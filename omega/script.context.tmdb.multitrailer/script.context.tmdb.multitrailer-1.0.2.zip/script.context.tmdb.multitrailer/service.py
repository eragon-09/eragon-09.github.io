# -*- coding: utf-8 -*-
"""Apply the TMDb Helper context-menu patch silently when Kodi starts."""
import xbmc
from patch_manager import apply_patch

if __name__ == '__main__':
    monitor = xbmc.Monitor()
    if not monitor.waitForAbort(5):
        apply_patch(interactive=False)
