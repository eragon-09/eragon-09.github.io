# Authors and contributors

Known project credits from the supplied source package:

- aenema — original EZ Maintenance+ credit
- peno — original EZ Maintenance+ credit
- The Cleaner — Truncate Tables functionality credit

The current BuildGuard maintainer and later contributors were not identified in the supplied files. Add names or pseudonyms only with their consent, and distinguish original authorship from later modifications. See `THIRD_PARTY_NOTICES.md`.
