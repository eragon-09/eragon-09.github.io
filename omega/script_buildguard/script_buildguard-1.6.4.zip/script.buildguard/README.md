# BuildGuard

BuildGuard is an open-source Kodi program add-on for maintenance, ZIP backup and restore, log handling, and optional installation of complete Kodi builds.

> **Important:** BuildGuard can delete and overwrite Kodi data. Archive validation reduces technical extraction risks, but it cannot establish that third-party code is trustworthy or compatible. Keep a current backup and use only sources you trust.

## Features

- Cache, packages, thumbnails and Python cache cleanup
- ZIP backup and restore with archive validation
- Optional third-party build installation over HTTPS
- Kodi log viewing, local ZIP export and optional anonymous paste.rs upload with privacy mode
- Add-on database maintenance and post-restore skin handling

## Privacy

Log upload is optional, anonymous and uses the external service paste.rs without an account or API key. Privacy mode removes common usernames, paths, addresses and credentials before upload, but no automatic filter can guarantee that every sensitive value is detected. Complete-log upload remains available only after an explicit warning. Generated share links are stored locally in the add-on profile.

## WebDAV preparation

The WebDAV provider remains included as a prepared extension point for future compatible hosting providers. It is not exposed as a primary provider until configuration and runtime testing across Kodi 19, 20 and 21 are complete.

## Installation

Install the release ZIP through Kodi's **Install from ZIP file** function. Do not install development folders directly over a working system without a backup.

## Development validation

From the add-on directory:

```bash
python3 -m compileall -q .
python3 -c "import xml.etree.ElementTree as E; E.parse('addon.xml'); E.parse('resources/settings.xml')"
```

Runtime testing requires Kodi and the declared dependency `script.module.requests`.

## Licensing and provenance

BuildGuard is distributed under `GPL-3.0-or-later`. Existing upstream GPL notices are retained. Known provenance and unresolved attribution details are documented in `THIRD_PARTY_NOTICES.md`; contributors must not remove those notices.

## Security

Read `SECURITY.md` before using restore or build installation. Please report vulnerabilities privately to the project maintainer through the project's configured support channel. A public repository URL and security contact must be added to `addon.xml`, `README.md`, and `SECURITY.md` before a public release.

## Contributing

See `CONTRIBUTING.md` and `CODE_OF_CONDUCT.md`.
## Architektur

BuildGuard verwendet keine allgemeine Wizard-Klasse mehr. Die aktiven Bereiche sind nach Verantwortung getrennt:

- `buildbackup.py`: vollständige Sicherung und Wiederherstellung
- `builds.py`: validierter Download und Installation externer Builds
- `skin_guard.py`: Schutz vor dem Löschen des aktiven Drittanbieter-Skins
- `safezip.py`: zentrale Archiv- und Pfadvalidierung
- `maintenance.py`: Cache-, Paket-, Thumbnail- und Datenbankwartung

Die historischen Einstellungs-IDs `enable_wiz1` bis `enable_wiz5` bleiben vorerst ausschließlich zur rückwärtskompatiblen Übernahme bestehender Konfigurationen erhalten. In Oberfläche und Code werden sie als Build-Quellen behandelt.

