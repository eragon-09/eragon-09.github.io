# SPDX-License-Identifier: GPL-3.0-or-later
import sys
from resources.lib.modules import webdav_provider

if __name__ == '__main__':
    action = sys.argv[1] if len(sys.argv) > 1 else 'test'
    webdav_provider.run(action)
