BuildGuard Cloud Keys
=====================

Die Datei buildguard-cloud-keys.txt ist eine ausfuellbare Vorlage fuer:

- Dropbox App Key und App Secret
- Google Drive Client-ID und Client-Schluessel

Nach dem Ausfuellen kannst du sie auf Smartphone, PC, USB-Stick oder
Android-Hardware kopieren und in BuildGuard importieren.

WICHTIG:
Die ausgefuellte Datei ist vertraulich. Nicht oeffentlich teilen und nach
Gebrauch sicher aufbewahren oder vom Zielgeraet loeschen.

BuildGuard exportiert und importiert keine OAuth Access- oder Refresh-Tokens.
Die eigentliche Kontoanmeldung muss auf jedem Geraet neu bestaetigt werden.
