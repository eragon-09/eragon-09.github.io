# SPDX-License-Identifier: GPL-3.0-or-later
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob, math, time
import shutil
import sqlite3
import urllib
import re
import os
from resources.lib.modules.backtothefuture import PY2

# Code to map the old translatePath
if PY2:
    translatePath = xbmc.translatePath
    loglevel = xbmc.LOGNOTICE
else:
    translatePath = xbmcvfs.translatePath
    loglevel = xbmc.LOGINFO

thumbnailPath = translatePath('special://thumbnails');
cachePath = os.path.join(translatePath('special://home'), 'cache')
tempPath = translatePath('special://temp')
addonPath = os.path.join(os.path.join(translatePath('special://home'), 'addons'),'script.ezmaintenance')

mediaPath = os.path.join(addonPath, 'media')
databasePath = translatePath('special://database')
THUMBS    =  translatePath(os.path.join('special://home/userdata/Thumbnails',''))

addon_id = 'script.buildguard'
fanart = translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
iconpath = translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi


def _format_size(num_bytes):
    num_bytes = float(num_bytes)
    for unit in ('B', 'KB', 'MB', 'GB'):
        if num_bytes < 1024.0:
            return '%.1f %s' % (num_bytes, unit)
        num_bytes /= 1024.0
    return '%.1f TB' % num_bytes


def _stat_and_unlink(path, stats):
    """Löscht eine Datei und zählt sie samt Größe in stats mit."""
    try:
        size = os.path.getsize(path)
    except Exception:
        size = 0
    os.unlink(path)
    stats['files'] += 1
    stats['bytes'] += size


def _dir_size(path):
    total = 0
    for r, d, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(r, f))
            except Exception:
                pass
    return total


def _stat_and_rmtree(path, stats):
    """Löscht einen Ordner rekursiv und zählt seinen Inhalt in stats mit."""
    stats['bytes'] += _dir_size(path)
    for r, d, files in os.walk(path):
        stats['files'] += len(files)
    shutil.rmtree(path)


def _notify_with_stats(heading_id, stats):
    addon = xbmcaddon.Addon(id=addon_id)
    text = addon.getLocalizedString(32089) % (
        stats['files'], _format_size(stats['bytes']))
    # Use Kodi's Python notification API so the add-on icon is applied
    # reliably instead of falling back to the default INFO icon.
    xbmcgui.Dialog().notification(
        addon.getLocalizedString(heading_id),
        text,
        iconpath,
        4000
    )

def clearCache(mode='verbose'):
    stats = {'files': 0, 'bytes': 0}
    if os.path.exists(cachePath)==True:
        for root, dirs, files in os.walk(cachePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                    for f in files:
                        try:
                            if (f == "xbmc.log" or f == "xbmc.old.log" or f == "kodi.log" or f == "kodi.old.log" or f == "archive_cache" or f == "commoncache.db" or f == "commoncache.socket" or f == "temp"): continue
                            _stat_and_unlink(os.path.join(root, f), stats)
                        except:
                            pass
                    for d in dirs:
                        try:
                            if (d == "archive_cache" or d == "temp"): continue
                            _stat_and_rmtree(os.path.join(root, d), stats)
                        except:
                            pass

            else:
                pass
    if os.path.exists(tempPath)==True:
        for root, dirs, files in os.walk(tempPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                for f in files:
                    try:
                        if (f == "xbmc.log" or f == "xbmc.old.log" or f == "kodi.log" or f == "kodi.old.log" or f == "archive_cache" or f == "commoncache.db" or f == "commoncache.socket" or f == "temp"): continue
                        _stat_and_unlink(os.path.join(root, f), stats)
                    except:
                        pass
                for d in dirs:
                    try:
                        if (d == "archive_cache" or d == "temp"): continue
                        _stat_and_rmtree(os.path.join(root, d), stats)
                    except:
                        pass

            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')

        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)

            if file_count > 0:
                for f in files:
                    _stat_and_unlink(os.path.join(root, f), stats)
                for d in dirs:
                    _stat_and_rmtree(os.path.join(root, d), stats)
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')

        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)

            if file_count > 0:
                for f in files:
                    _stat_and_unlink(os.path.join(root, f), stats)
                for d in dirs:
                    _stat_and_rmtree(os.path.join(root, d), stats)
            else:
                pass

    cacheEntries = []

    for entry in cacheEntries:
        clear_cache_path = translatePath(entry.path)
        if os.path.exists(clear_cache_path)==True:
            for root, dirs, files in os.walk(clear_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        _stat_and_unlink(os.path.join(root, f), stats)
                    for d in dirs:
                        _stat_and_rmtree(os.path.join(root, d), stats)
                else:
                    pass

    if mode == 'verbose': _notify_with_stats(32006, stats)
    return stats

def deleteThumbnails(mode='verbose'):
    stats = {'files': 0, 'bytes': 0}

    if os.path.exists(thumbnailPath)==True:
            # dialog = xbmcgui.Dialog()
            # if dialog.yesno("Delete Thumbnails", "This option deletes all thumbnails" + '\n' + "Are you sure you want to do this?"):
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:
                        for f in files:
                            try:
                                _stat_and_unlink(os.path.join(root, f), stats)
                            except:
                                pass


    if os.path.exists(THUMBS):
        try:
            for root, dirs, files in os.walk(THUMBS):
                file_count = 0
                file_count += len(files)
                # Count files and give option to delete
                if file_count > 0:
                    for f in files: _stat_and_unlink(os.path.join(root, f), stats)
                    for d in dirs: _stat_and_rmtree(os.path.join(root, d), stats)
        except:
            pass

    try:
        text13 = os.path.join(databasePath,"Textures13.db")
        _stat_and_unlink(text13, stats)
    except:
        pass
    if mode == 'verbose': _notify_with_stats(32008, stats)
    return stats

def purgePackages(mode='verbose'):
    stats = {'files': 0, 'bytes': 0}

    purgePath = translatePath('special://home/addons/packages')
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(purgePath):
        file_count = 0
        file_count += len(files)
    # if dialog.yesno("Delete Package Cache Files", "%d packages found."%file_count + '\n' + "Delete Them?"):
    for root, dirs, files in os.walk(purgePath):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            for f in files:
                _stat_and_unlink(os.path.join(root, f), stats)
            for d in dirs:
                _stat_and_rmtree(os.path.join(root, d), stats)
            # dialog = xbmcgui.Dialog()
            # dialog.ok("Maintenance", "Deleting Packages all done")
    if mode == 'verbose': _notify_with_stats(32007, stats)
    return stats


def clearPycache(mode='verbose'):
    """Löscht alle __pycache__-Ordner unter special://home/addons/ - mit
    Ausnahme des eigenen, gerade laufenden Addon-Ordners (Selbstschutz,
    analog zum Build-Backup-Restore). Gibt pro Addon eine Zeile
    (Addon-ID, Anzahl __pycache__-Ordner, Dateien, freigegebener Speicher)
    zurück, plus eine Gesamtsumme."""
    addons_root = translatePath('special://home/addons/')
    own_folder = addon_id  # 'script.buildguard' - laeuft gerade selbst
    rows = []
    total = {'folders': 0, 'files': 0, 'bytes': 0}

    if not os.path.isdir(addons_root):
        return rows, total

    for entry in sorted(os.listdir(addons_root)):
        if entry == own_folder:
            continue
        addon_dir = os.path.join(addons_root, entry)
        if not os.path.isdir(addon_dir):
            continue

        addon_stats = {'files': 0, 'bytes': 0}
        folder_count = 0
        for root, dirs, files in os.walk(addon_dir, topdown=True):
            hit_dirs = [d for d in dirs if d == '__pycache__']
            dirs[:] = [d for d in dirs if d != '__pycache__']
            for d in hit_dirs:
                pycache_path = os.path.join(root, d)
                try:
                    _stat_and_rmtree(pycache_path, addon_stats)
                    folder_count += 1
                except Exception:
                    pass

        if folder_count > 0:
            rows.append((entry, folder_count, addon_stats['files'], addon_stats['bytes']))
            total['folders'] += folder_count
            total['files'] += addon_stats['files']
            total['bytes'] += addon_stats['bytes']

    if mode == 'verbose':
        addon = xbmcaddon.Addon(id=addon_id)
        if rows:
            text = addon.getLocalizedString(32089) % (total['files'], _format_size(total['bytes']))
        else:
            text = addon.getLocalizedString(32091)
        xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % (
            addon.getLocalizedString(32090), text, '4000', iconpath))

    return rows, total



def determineNextMaintenance():
    getSetting = xbmcaddon.Addon().getSetting

    autoCleanDays = getSetting('autoCleanDays')
    if autoCleanDays is None:
        days = 0
    else:
        days = int(autoCleanDays)

    t1 = 0

    if days > 0:
        autoCleanHour = getSetting('autoCleanHour')
        if autoCleanHour is None:
            hour = 0
        else:
            hour = int(autoCleanHour)

        t0 = int(math.floor(time.time()))

        t1 = t0 + (days * 24 * 60 * 60)  # days * 24h * 60m * 60s

        x = time.localtime(t1)

        t1 += (hour - x.tm_hour) * 60 * 60 - x.tm_min * 60 - x.tm_sec
        while (t1 <= t0):
            t1 += 24 * 60 * 60 # add days until we are in the future

        #t1 = t0 + 1 * 60 # for testing - every minute

    win = xbmcgui.Window(10000)
    win.setProperty("ezmaintenance.nextMaintenanceTime", str(t1))

    logMaintenance("setNextMaintenance: %s" % str(t1))


def getNextMaintenance():
    win = xbmcgui.Window(10000)
    t1 = int(win.getProperty("ezmaintenance.nextMaintenanceTime"))

    logMaintenance("getNextMaintenance: %s" % str(t1))

    return t1

def logMaintenance(message):
#    xbmc.log("buildguard: %s" % message, level=loglevel)
    return


def _find_addons_db():
    """Findet die aktuelle Addons*.db dynamisch (Versionsnummer ändert
    sich je nach Kodi-Version, z.B. Addons33.db, Addons34.db - niemals
    hartkodieren). Nutzt dieselbe Logik wie buildbackup.get_latest_db()."""
    db_folder = translatePath('special://database')
    highest_number = -1
    highest_file = None
    try:
        entries = os.listdir(db_folder)
    except Exception:
        return None
    for f in entries:
        if f.startswith('Addons') and f.lower().endswith('.db'):
            try:
                number = int(f[len('Addons'):-3])
                if number > highest_number:
                    highest_number = number
                    highest_file = f
            except ValueError:
                pass
    if highest_file:
        return os.path.join(db_folder, highest_file)
    return None


def completeBuildCleanup():
    """Fuehrt die komplette Build-Bereinigung in fester Reihenfolge aus.

    Cache -> Packages -> Thumbnails -> __pycache__ -> Truncate Tables -> VACUUM
    -> Kodi beenden. Die Addon-Datenbank wird dabei nicht geloescht.
    """
    addon = xbmcaddon.Addon(id=addon_id)
    dlg = xbmcgui.Dialog()

    if not dlg.yesno(
            addon.getLocalizedString(32092),
            addon.getLocalizedString(32093)):
        return False

    steps = (
        ('cache', lambda: clearCache(mode='silent')),
        ('packages', lambda: purgePackages(mode='silent')),
        ('thumbnails', lambda: deleteThumbnails(mode='silent')),
        ('__pycache__', lambda: clearPycache(mode='silent')),
    )

    for name, operation in steps:
        try:
            operation()
        except Exception as exc:
            xbmc.log('{}: complete cleanup step {} failed: {}'.format(
                addon_id, name, exc), xbmc.LOGERROR)
            dlg.ok(addon.getLocalizedString(32092), addon.getLocalizedString(32094).format(name))
            return False

    # Letzter Schritt exakt nach dem integrierten Truncate-Tables-Verfahren.
    # Diese Funktion fuehrt DELETE/COMMIT/VACUUM aus und beendet Kodi.
    return truncateAddonTables(confirm=False, success_message_id=32095)


def truncateAddonTables(confirm=True, success_message_id=32100):
    """Leert die Kodi-Addon-Datenbank nach demselben Verfahren wie
    dem Truncate-Tables-Verfahren, mit einer wichtigen Schutzanpassung:
    Die Tabelle `version` bleibt erhalten, damit Kodi die Schema-Version der
    Addons-Datenbank weiterhin korrekt erkennen kann.

    DELETE FROM addonlinkrepo;
    DELETE FROM addons;
    DELETE FROM package;
    DELETE FROM repo;
    DELETE FROM update_rules;
    COMMIT;
    VACUUM;
    Kodi sofort beenden.

    Die Addons-Datenbank wird dynamisch ermittelt, damit dasselbe Verfahren
    auch dann funktioniert, wenn Kodi eine andere AddonsXX.db verwendet.
    """
    addon = xbmcaddon.Addon(id=addon_id)
    dlg = xbmcgui.Dialog()

    # Derselbe Sicherheitsablauf wie im Referenz-Addon: Hinweis, dann Ja/Nein.
    if confirm:
        dlg.ok(addon.getLocalizedString(32097), addon.getLocalizedString(32098))
        verify = dlg.yesno(addon.getLocalizedString(32097), addon.getLocalizedString(32099))
        if not verify:
            return False

    addons_db = _find_addons_db()
    if not addons_db or not os.path.exists(addons_db):
        dlg.ok(addon.getLocalizedString(32097), addon.getLocalizedString(32102))
        return False

    success = False
    con = None
    try:
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        cursor.execute('DELETE FROM addonlinkrepo;')
        cursor.execute('DELETE FROM addons;')
        cursor.execute('DELETE FROM package;')
        cursor.execute('DELETE FROM repo;')
        cursor.execute('DELETE FROM update_rules;')
        con.commit()
        success = True
    except sqlite3.Error as e:
        xbmc.log('{}: There was an error reading the database - {}'.format(addon_id, e), xbmc.LOGINFO)
        dlg.ok(addon.getLocalizedString(32097), addon.getLocalizedString(32101))
        return False
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass

    # Wie beim Truncate-Tables-Verfahren: zweiter DB-Zugriff fuer VACUUM.
    # Schutzanpassung: Die Tabelle `version` bleibt erhalten, damit Kodi
    # die Schema-Version der Addons-Datenbank weiterhin korrekt erkennt.
    con = None
    try:
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        cursor.execute('VACUUM;')
        con.commit()
    except sqlite3.Error as e:
        xbmc.log('{}: Failed to vacuum data from the sqlite table: {}'.format(addon_id, e), xbmc.LOGINFO)
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass

    if success:
        dlg.ok(addon.getLocalizedString(32097), addon.getLocalizedString(success_message_id))
        os._exit(1)

    return False
