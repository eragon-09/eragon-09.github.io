# SPDX-License-Identifier: GPL-3.0-or-later
"""Publication-provider dispatcher.

Keeps the menu and backup workflow independent from the configured cloud
provider. Dropbox remains the default and its proven implementation is used
unchanged.
"""
import xbmcaddon

ADDON = xbmcaddon.Addon('script.buildguard')


def provider_name():
    """Return the configured publication provider safely.

    Kodi stores enum settings as integers. Older test builds may have left a
    string value behind, so keep a compatibility fallback and default to the
    proven Dropbox provider on any invalid or missing setting.
    """
    try:
        value = ADDON.getSettingInt('publication_provider')
        if value == 1:
            return 'Google Drive'
        if value == 2:
            return 'WebDAV'
        return 'Dropbox'
    except (AttributeError, TypeError, ValueError):
        try:
            value = ADDON.getSetting('publication_provider').strip().lower()
        except Exception:
            value = ''
        if value in ('1', 'google drive', 'googledrive'):
            return 'Google Drive'
        if value in ('2', 'webdav'):
            return 'WebDAV'
        return 'Dropbox'


def _module():
    if provider_name() == 'Google Drive':
        from resources.lib.modules import google_drive_provider
        return google_drive_provider
    if provider_name() == 'WebDAV':
        from resources.lib.modules import webdav_provider
        return webdav_provider
    from resources.lib.modules import dropbox_auth
    return dropbox_auth


def publish_local_backup():
    return _module().publish_local_backup()


def manage_published_builds():
    return _module().manage_published_builds()


def show_public_link():
    return _module().show_public_link()


def test_connection():
    module = _module()
    test = getattr(module, 'test_connection', None)
    return test() if test else False
