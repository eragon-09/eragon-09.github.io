# SPDX-License-Identifier: GPL-3.0-or-later
"""Google Drive publication provider for BuildGuard.

Uses Google's OAuth device flow and the Drive v3 REST API only.  The
``drive.file`` scope limits BuildGuard to files it creates or that the user
explicitly opens with the app.
"""
import datetime
import json
import mimetypes
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.modules import dropbox_auth as common

ADDON = xbmcaddon.Addon('script.buildguard')
TITLE = ADDON.getAddonInfo('name')
TOKEN_FILENAME = 'google_drive_tokens.json'
DRIVE_API = 'https://www.googleapis.com/drive/v3'
DRIVE_UPLOAD = 'https://www.googleapis.com/upload/drive/v3'
TOKEN_URL = 'https://oauth2.googleapis.com/token'
DEVICE_URL = 'https://oauth2.googleapis.com/device/code'
SCOPE = 'https://www.googleapis.com/auth/drive.file'
FOLDER_MIME = 'application/vnd.google-apps.folder'


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def _profile_dir():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def token_path():
    return os.path.join(_profile_dir(), TOKEN_FILENAME)


def _credentials():
    return (ADDON.getSettingString('google_drive_client_id').strip(),
            ADDON.getSettingString('google_drive_client_secret').strip())


def _ensure_credentials():
    client_id, client_secret = _credentials()
    dialog = xbmcgui.Dialog()
    if not client_id:
        client_id = dialog.input(_(32374), type=xbmcgui.INPUT_ALPHANUM).strip()
        if not client_id:
            return '', ''
        ADDON.setSettingString('google_drive_client_id', client_id)
    if not client_secret:
        client_secret = dialog.input(_(32375), type=xbmcgui.INPUT_ALPHANUM).strip()
        if not client_secret:
            return '', ''
        ADDON.setSettingString('google_drive_client_secret', client_secret)
    return client_id, client_secret


def _save_token(data):
    payload = {
        'access_token': data.get('access_token', ''),
        'refresh_token': data.get('refresh_token', ''),
        'expires_at': time.time() + int(data.get('expires_in') or 3600) - 60,
        'scope': data.get('scope', SCOPE),
        'token_type': data.get('token_type', 'Bearer'),
    }
    with open(token_path(), 'w', encoding='utf-8') as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def _load_token():
    try:
        with open(token_path(), 'r', encoding='utf-8') as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _post_form(url, values, timeout=30, allow_error=False):
    body = urllib.parse.urlencode(values).encode('utf-8')
    request = urllib.request.Request(
        url, data=body,
        headers={'Content-Type': 'application/x-www-form-urlencoded',
                 'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version')},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.getcode(), json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as exc:
        raw = exc.read(65536)
        try:
            data = json.loads(raw.decode('utf-8'))
        except Exception:
            data = {'error': raw.decode('utf-8', 'replace')}
        if allow_error:
            return exc.code, data
        raise RuntimeError(data.get('error_description') or data.get('error') or str(exc))


def _access_token():
    client_id, client_secret = _credentials()
    token = _load_token()
    if not client_id or not token.get('refresh_token'):
        return ''
    if token.get('access_token') and float(token.get('expires_at') or 0) > time.time():
        return token['access_token']
    _status, refreshed = _post_form(TOKEN_URL, {
        'client_id': client_id,
        'client_secret': client_secret,
        'refresh_token': token['refresh_token'],
        'grant_type': 'refresh_token',
    })
    refreshed['refresh_token'] = token['refresh_token']
    _save_token(refreshed)
    return refreshed.get('access_token', '')


def _request(method, url, body=None, content_type='application/json', timeout=60):
    token = _access_token()
    if not token:
        raise RuntimeError(_(32381))
    headers = {
        'Authorization': 'Bearer ' + token,
        'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version'),
    }
    if body is not None and content_type:
        headers['Content-Type'] = content_type
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
            if not raw:
                return {}
            return json.loads(raw.decode('utf-8'))
    except urllib.error.HTTPError as exc:
        raw = exc.read(65536)
        try:
            detail = json.loads(raw.decode('utf-8'))
            message = detail.get('error', {}).get('message') or detail.get('error_description')
        except Exception:
            message = raw.decode('utf-8', 'replace')
        raise RuntimeError(message or str(exc))


class QRCodeDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.image = kwargs.get('image', '')
        self.text = kwargs.get('text', '')
        self.code = kwargs.get('code', '')

    def onInit(self):
        self.getControl(501).setImage(self.image)
        self.getControl(502).setText(self.text)
        self.getControl(504).setText('[COLOR gold][B]{}[/B][/COLOR]'.format(self.code))
        self.getControl(503).setLabel(_(32258))
        self.setFocus(self.getControl(503))

    def onClick(self, control_id):
        if control_id == 503:
            self.close()


def authorize():
    client_id, client_secret = _ensure_credentials()
    if not client_id or not client_secret:
        return False
    image_path = os.path.join(_profile_dir(), 'google_drive_oauth_qr.png')
    try:
        _status, device = _post_form(DEVICE_URL, {'client_id': client_id, 'scope': SCOPE})
        verification_url = device.get('verification_url') or device.get('verification_uri')
        if not verification_url or not device.get('device_code') or not device.get('user_code'):
            raise RuntimeError(_(32382))
        import pyqrcode
        pyqrcode.create(verification_url).png(image_path, scale=7)
        dialog = QRCodeDialog(
            'script-buildguard-google-qrcode.xml', ADDON.getAddonInfo('path'), 'Default',
            image=image_path, text=_(32376).format(verification_url), code=device['user_code'])
        dialog.doModal()
        del dialog

        interval = max(int(device.get('interval') or 5), 5)
        deadline = time.monotonic() + int(device.get('expires_in') or 1800)
        progress = xbmcgui.DialogProgress()
        progress.create(TITLE, _(32377))
        try:
            while time.monotonic() < deadline:
                if progress.iscanceled():
                    return False
                status, result = _post_form(TOKEN_URL, {
                    'client_id': client_id,
                    'client_secret': client_secret,
                    'device_code': device['device_code'],
                    'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
                }, allow_error=True)
                if status == 200 and result.get('access_token'):
                    _save_token(result)
                    from resources.lib.modules import cloud_status
                    cloud_status.refresh()
                    xbmcgui.Dialog().ok(TITLE, _(32378))
                    return True
                error = result.get('error', '')
                if error == 'slow_down':
                    interval += 5
                elif error not in ('authorization_pending', ''):
                    raise RuntimeError(result.get('error_description') or error)
                xbmc.sleep(interval * 1000)
        finally:
            progress.close()
        raise RuntimeError(_(32383))
    except Exception as exc:
        xbmc.log('[BuildGuard][Google Drive OAuth] ' + common._safe_text(exc, (client_id, client_secret)), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32379).format(common._safe_text(exc, (client_id, client_secret))))
        return False
    finally:
        if xbmcvfs.exists(image_path):
            xbmcvfs.delete(image_path)


def _folder_name():
    value = ADDON.getSettingString('google_drive_folder').strip().strip('/\\')
    return value or 'BuildGuard'


def _escape_query(value):
    return value.replace('\\', '\\\\').replace("'", "\\'")


def _list_files(query, fields='files(id,name,mimeType,trashed)'):
    url = DRIVE_API + '/files?' + urllib.parse.urlencode({
        'q': query,
        'spaces': 'drive',
        'fields': fields,
        'pageSize': 1000,
    })
    return _request('GET', url).get('files', [])


def _ensure_folder():
    name = _folder_name()
    query = "name='{}' and mimeType='{}' and trashed=false".format(_escape_query(name), FOLDER_MIME)
    files = _list_files(query)
    if files:
        folder_id = files[0]['id']
    else:
        metadata = json.dumps({'name': name, 'mimeType': FOLDER_MIME}).encode('utf-8')
        folder_id = _request('POST', DRIVE_API + '/files?fields=id,name', metadata)['id']
    ADDON.setSettingString('google_drive_folder_id', folder_id)
    return folder_id


def _find_file(name, folder_id):
    query = "name='{}' and '{}' in parents and trashed=false".format(_escape_query(name), folder_id)
    files = _list_files(query, 'files(id,name,mimeType,trashed,webContentLink)')
    return files[0] if files else None


def _multipart_upload(name, parent_id, data, mime_type, file_id=''):
    boundary = 'buildguard_' + uuid.uuid4().hex
    metadata = {'name': name}
    if parent_id and not file_id:
        metadata['parents'] = [parent_id]
    head = (
        '--{0}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n{1}\r\n'
        '--{0}\r\nContent-Type: {2}\r\n\r\n'
    ).format(boundary, json.dumps(metadata, ensure_ascii=False), mime_type).encode('utf-8')
    body = head + data + ('\r\n--{}--\r\n'.format(boundary)).encode('ascii')
    if file_id:
        url = DRIVE_UPLOAD + '/files/' + urllib.parse.quote(file_id) + '?uploadType=multipart&fields=id,name,webContentLink'
        return _request('PATCH', url, body, 'multipart/related; boundary=' + boundary, timeout=180)
    url = DRIVE_UPLOAD + '/files?uploadType=multipart&fields=id,name,webContentLink'
    return _request('POST', url, body, 'multipart/related; boundary=' + boundary, timeout=180)


def _resumable_upload(local_path, name, parent_id, file_id=''):
    total = xbmcvfs.Stat(local_path).st_size()
    metadata = {'name': name}
    if parent_id and not file_id:
        metadata['parents'] = [parent_id]
    token = _access_token()
    url = DRIVE_UPLOAD + ('/files/' + urllib.parse.quote(file_id) if file_id else '/files')
    url += '?uploadType=resumable&fields=id,name,webContentLink'
    request = urllib.request.Request(
        url, data=json.dumps(metadata).encode('utf-8'), method='PATCH' if file_id else 'POST',
        headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json; charset=UTF-8',
                 'X-Upload-Content-Type': 'application/zip', 'X-Upload-Content-Length': str(total),
                 'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version')})
    with urllib.request.urlopen(request, timeout=60) as response:
        session_url = response.headers.get('Location')
    if not session_url:
        raise RuntimeError('Google Drive did not return an upload session')

    progress = xbmcgui.DialogProgress()
    started = time.monotonic()
    progress.create(TITLE, common._upload_status(name, 0, total, started).replace('Dropbox', 'Google Drive'))
    source = xbmcvfs.File(local_path, 'rb')
    try:
        offset = 0
        chunk_size = 8 * 1024 * 1024
        result = {}
        while offset < total:
            if progress.iscanceled():
                raise RuntimeError(_(32029))
            chunk = bytes(source.readBytes(min(chunk_size, total - offset)))
            if not chunk:
                raise IOError('Unexpected end of backup file during Google Drive upload')
            end = offset + len(chunk) - 1
            req = urllib.request.Request(session_url, data=chunk, method='PUT', headers={
                'Content-Length': str(len(chunk)),
                'Content-Range': 'bytes {}-{}/{}'.format(offset, end, total),
                'Content-Type': 'application/zip',
            })
            try:
                with urllib.request.urlopen(req, timeout=180) as response:
                    raw = response.read()
                    result = json.loads(raw.decode('utf-8')) if raw else {}
            except urllib.error.HTTPError as exc:
                if exc.code != 308:
                    raise
            offset = end + 1
            progress.update(min(int(offset * 100 / max(total, 1)), 100),
                            common._upload_status(name, offset, total, started).replace('Dropbox', 'Google Drive'))
        return result
    finally:
        source.close()
        progress.close()


def _make_public(file_id):
    body = json.dumps({'type': 'anyone', 'role': 'reader'}).encode('utf-8')
    try:
        _request('POST', DRIVE_API + '/files/{}/permissions'.format(urllib.parse.quote(file_id)), body)
    except RuntimeError as exc:
        # Existing equivalent permission is harmless.
        if 'already' not in str(exc).lower():
            raise


def _direct_url(file_id):
    return 'https://drive.usercontent.google.com/download?' + urllib.parse.urlencode({
        'id': file_id, 'export': 'download', 'confirm': 't'})


def _download_catalog(folder_id):
    found = _find_file('buildguard.json', folder_id)
    if not found:
        return {'format': 2, 'builds': []}, ''
    token = _access_token()
    request = urllib.request.Request(
        DRIVE_API + '/files/' + urllib.parse.quote(found['id']) + '?alt=media',
        headers={'Authorization': 'Bearer ' + token, 'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version')})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = json.loads(response.read(262145).decode('utf-8-sig'))
    return common._catalog_from_data(data), found['id']


def _upload_catalog(folder_id, catalog, file_id=''):
    data = json.dumps(catalog, ensure_ascii=False, indent=2, sort_keys=True).encode('utf-8')
    result = _multipart_upload('buildguard.json', folder_id, data, 'application/json', file_id)
    _make_public(result['id'])
    return result['id']


def publish_local_backup():
    chosen = xbmcgui.Dialog().browse(1, _(32281), 'files', '.zip')
    if not chosen:
        return False
    try:
        folder_id = _ensure_folder()
        catalog, catalog_file_id = _download_catalog(folder_id)
        replace_index = common._creator_build_choice(catalog)
        if replace_index is None:
            return False
        local_filename = os.path.basename(chosen.replace('\\', '/'))
        if replace_index == -1:
            remote_filename = local_filename
            display_name = os.path.splitext(remote_filename)[0]
            if any(item['filename'].casefold() == remote_filename.casefold() for item in catalog['builds']):
                xbmcgui.Dialog().ok(TITLE, _(32308).format(display_name))
                return False
            question = _(32386).format(display_name, remote_filename)
        else:
            existing = catalog['builds'][replace_index]
            remote_filename = existing['filename']
            display_name = os.path.splitext(remote_filename)[0]
            question = _(32385).format(display_name, remote_filename, local_filename)
        if not xbmcgui.Dialog().yesno(TITLE, question):
            return False

        existing_file = _find_file(remote_filename, folder_id)
        uploaded = _resumable_upload(chosen, remote_filename, folder_id,
                                     existing_file['id'] if existing_file else '')
        file_id = uploaded.get('id') or (existing_file or {}).get('id')
        if not file_id:
            raise RuntimeError('Google Drive upload returned no file ID')
        _make_public(file_id)
        entry = {
            'name': display_name,
            'version': ADDON.getAddonInfo('version'),
            'filename': remote_filename,
            'path': '/' + _folder_name() + '/' + remote_filename,
            'download_url': _direct_url(file_id),
            'created': datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
            'file_id': file_id,
        }
        if replace_index == -1:
            catalog['builds'].append(entry)
        else:
            catalog['builds'][replace_index] = entry
        catalog_file_id = _upload_catalog(folder_id, catalog, catalog_file_id)
        public_url = _direct_url(catalog_file_id)
        ADDON.setSettingString('buildguard_public_url', public_url)
        ADDON.setSettingString('google_drive_public_url', public_url)
        short_url = common._stable_short_link(public_url)
        ADDON.setSettingString('google_drive_short_url', short_url or '')
        share_url = common._highlight_share_url(short_url or public_url)
        first = replace_index == -1 and len(catalog['builds']) == 1
        message = _(32368 if first else (32369 if replace_index == -1 else 32370)).format(display_name, share_url)
        xbmcgui.Dialog().ok(TITLE, message)
        return True
    except Exception as exc:
        safe = common._safe_text(exc, _credentials())
        xbmc.log('[BuildGuard][Google Drive publish] ' + safe, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32384).format(safe or type(exc).__name__))
        return False


def manage_published_builds():
    try:
        folder_id = _ensure_folder()
        catalog, catalog_file_id = _download_catalog(folder_id)
        builds = catalog['builds']
        if not builds:
            xbmcgui.Dialog().ok(TITLE, _(32312))
            return False
        selected = xbmcgui.Dialog().select(_(32387), [item['name'] for item in builds])
        if selected < 0:
            return False
        entry = builds[selected]
        if not xbmcgui.Dialog().yesno(TITLE, _(32388).format(entry['name'], entry['filename'])):
            return False
        file_id = entry.get('file_id')
        if not file_id:
            found = _find_file(entry['filename'], folder_id)
            file_id = found.get('id') if found else ''
        if file_id:
            try:
                _request('DELETE', DRIVE_API + '/files/' + urllib.parse.quote(file_id))
            except RuntimeError as exc:
                if 'not found' not in str(exc).lower():
                    raise
        del builds[selected]
        _upload_catalog(folder_id, catalog, catalog_file_id)
        xbmcgui.Dialog().ok(TITLE, _(32320).format(entry['name']))
        return True
    except Exception as exc:
        safe = common._safe_text(exc, _credentials())
        xbmc.log('[BuildGuard][Google Drive manage] ' + safe, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32384).format(safe or type(exc).__name__))
        return False


def show_public_link():
    original = ADDON.getSettingString('buildguard_public_url').strip()
    short = ADDON.getSettingString('buildguard_short_url').strip()
    if not original:
        xbmcgui.Dialog().ok(TITLE, _(32284))
        return False
    xbmcgui.Dialog().ok(TITLE, _(32389).format(common._highlight_share_url(short or original), original))
    return True


def test_connection():
    try:
        about = _request('GET', DRIVE_API + '/about?fields=user(displayName,emailAddress)')
        folder_id = _ensure_folder()
        user = about.get('user', {})
        identity = user.get('displayName') or user.get('emailAddress') or folder_id
        xbmcgui.Dialog().ok(TITLE, _(32380).format(identity, _folder_name()))
        return True
    except Exception as exc:
        xbmcgui.Dialog().ok(TITLE, _(32384).format(common._safe_text(exc, _credentials())))
        return False


def disconnect():
    token = _load_token()
    revoke = token.get('refresh_token') or token.get('access_token')
    if revoke:
        try:
            _post_form('https://oauth2.googleapis.com/revoke', {'token': revoke}, allow_error=True)
        except Exception:
            pass
    if xbmcvfs.exists(token_path()):
        xbmcvfs.delete(token_path())
    ADDON.setSettingString('google_drive_folder_id', '')
    from resources.lib.modules import cloud_status
    cloud_status.refresh()
    xbmcgui.Dialog().ok(TITLE, _(32390))
    return True


def run(action):
    if action == 'authorize':
        return authorize()
    if action == 'disconnect':
        return disconnect()
    if action == 'show_public_link':
        return show_public_link()
    if action == 'manage_published_builds':
        return manage_published_builds()
    if action == 'publish_backup':
        return publish_local_backup()
    return test_connection()
