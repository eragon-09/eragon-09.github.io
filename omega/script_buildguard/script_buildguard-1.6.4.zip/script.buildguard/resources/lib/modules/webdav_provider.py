# SPDX-License-Identifier: GPL-3.0-or-later
"""Prepared WebDAV publication provider for BuildGuard.

Kept in the release for future compatible hosting providers. It is not
exposed as a primary provider until configuration and Kodi 19-21 runtime
testing are complete. Existing provider interfaces must remain stable.


Supports HTTPS WebDAV servers using Basic authentication, variable-length
build catalogs, stable public URLs supplied by the creator, ZIP upload,
rename/delete catalog management and optional TinyURL creation.
"""
import base64
import datetime
import http.client
import json
import os
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.modules import dropbox_auth as common

ADDON = xbmcaddon.Addon('script.buildguard')
TITLE = ADDON.getAddonInfo('name')


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def _settings():
    server = ADDON.getSettingString('webdav_server_url').strip().rstrip('/')
    username = ADDON.getSettingString('webdav_username').strip()
    password = ADDON.getSettingString('webdav_password')
    folder = '/' + '/'.join(
        p for p in ADDON.getSettingString('webdav_folder').replace('\\', '/').split('/') if p
    )
    public = ADDON.getSettingString('webdav_public_url').strip().rstrip('/')
    return server, username, password, folder, public


def _validate_settings(require_public=False):
    server, username, password, folder, public = _settings()
    parsed = urllib.parse.urlsplit(server)
    if parsed.scheme.lower() != 'https' or not parsed.netloc:
        raise ValueError(_(32333))
    if not username or not password:
        raise ValueError(_(32334))
    if require_public:
        public_parsed = urllib.parse.urlsplit(public)
        if public_parsed.scheme.lower() != 'https' or not public_parsed.netloc:
            raise ValueError(_(32335))
    return server, username, password, folder, public


def _auth_header(username, password):
    token = base64.b64encode((username + ':' + password).encode('utf-8')).decode('ascii')
    return 'Basic ' + token


def _remote_url(filename=''):
    server, _user, _password, folder, _public = _validate_settings(False)
    quoted_folder = '/'.join(urllib.parse.quote(p) for p in folder.split('/') if p)
    base = server + ('/' + quoted_folder if quoted_folder else '')
    return base + ('/' + urllib.parse.quote(filename) if filename else '')


def _request(method, url, data=None, expected=(200, 201, 204, 207), timeout=30, extra_headers=None):
    _server, username, password, _folder, _public = _validate_settings(False)
    headers = {
        'Authorization': _auth_header(username, password),
        'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version'),
    }
    if data is not None:
        headers['Content-Type'] = 'application/octet-stream'
    if extra_headers:
        headers.update(extra_headers)
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read()
            status = getattr(response, 'status', response.getcode())
    except urllib.error.HTTPError as exc:
        if exc.code in expected:
            return exc.code, exc.read()
        raise
    if status not in expected:
        raise IOError('WebDAV HTTP {}'.format(status))
    return status, body


def _ensure_folder():
    server, username, password, folder, _public = _validate_settings(False)
    current = server
    for part in (p for p in folder.split('/') if p):
        current += '/' + urllib.parse.quote(part)
        headers = {
            'Authorization': _auth_header(username, password),
            'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version'),
        }
        request = urllib.request.Request(current, headers=headers, method='MKCOL')
        try:
            urllib.request.urlopen(request, timeout=20).close()
        except urllib.error.HTTPError as exc:
            if exc.code not in (405, 409):
                raise


def _public_url(filename):
    _server, _username, _password, _folder, public = _validate_settings(True)
    return public + '/' + urllib.parse.quote(filename)


def _upload_file(local_path, remote_filename):
    """Stream a ZIP through HTTPS and show progress without loading it in RAM."""
    progress = None
    connection = None
    source = None
    try:
        _ensure_folder()
        server, username, password, folder, _public = _validate_settings(False)
        parsed = urllib.parse.urlsplit(server)
        path_parts = [p for p in folder.split('/') if p] + [remote_filename]
        path = (parsed.path.rstrip('/') + '/' + '/'.join(urllib.parse.quote(p) for p in path_parts))
        if parsed.query:
            path += '?' + parsed.query
        total = os.path.getsize(xbmcvfs.translatePath(local_path))
        if total <= 0:
            raise IOError(_(32265))
        connection = http.client.HTTPSConnection(parsed.hostname, parsed.port or 443, timeout=60)
        connection.putrequest('PUT', path)
        connection.putheader('Authorization', _auth_header(username, password))
        connection.putheader('User-Agent', 'BuildGuard/' + ADDON.getAddonInfo('version'))
        connection.putheader('Content-Type', 'application/zip')
        connection.putheader('Content-Length', str(total))
        connection.endheaders()
        source = xbmcvfs.File(local_path, 'rb')
        sent = 0
        started = time.monotonic()
        progress = xbmcgui.DialogProgress()
        progress.create(TITLE, common._upload_status(remote_filename, 0, total, started).replace('Dropbox', 'WebDAV'))
        while sent < total:
            if progress.iscanceled():
                raise RuntimeError(_(32029))
            chunk = bytes(source.readBytes(min(1024 * 1024, total - sent)))
            if not chunk:
                raise IOError('Unexpected end of backup file during WebDAV upload')
            connection.send(chunk)
            sent += len(chunk)
            status = common._upload_status(remote_filename, sent, total, started).replace('Dropbox', 'WebDAV')
            progress.update(min(int(sent * 100 / total), 100), status)
        response = connection.getresponse()
        response.read()
        if response.status not in (200, 201, 204):
            raise IOError('WebDAV HTTP {}'.format(response.status))
        return '/' + '/'.join([p for p in folder.split('/') if p] + [remote_filename])
    finally:
        if source is not None:
            source.close()
        if connection is not None:
            connection.close()
        if progress is not None:
            progress.close()


def _download_catalog():
    try:
        _status, body = _request('GET', _remote_url('buildguard.json'), expected=(200,))
        return common._catalog_from_data(json.loads(body.decode('utf-8-sig')))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return {'format': 2, 'builds': []}
        raise


def _verify_public_catalog(expected_catalog):
    """Verify that the consumer URL is public and serves the new catalog."""
    public_url = _public_url('buildguard.json')
    request = urllib.request.Request(
        public_url,
        headers={'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version')},
        method='GET',
    )
    try:
        with urllib.request.urlopen(request, timeout=25) as response:
            body = response.read(2 * 1024 * 1024 + 1)
    except urllib.error.HTTPError as exc:
        raise IOError(_(32358).format(exc.code))
    if len(body) > 2 * 1024 * 1024:
        raise IOError(_(32359))
    try:
        actual = common._catalog_from_data(json.loads(body.decode('utf-8-sig')))
    except Exception:
        raise IOError(_(32360))
    expected_names = [item.get('name', '') for item in expected_catalog.get('builds', [])]
    actual_names = [item.get('name', '') for item in actual.get('builds', [])]
    if actual_names != expected_names:
        raise IOError(_(32361))
    return public_url


def _upload_catalog(catalog):
    """Upload the catalog atomically when MOVE is supported, then verify it publicly."""
    payload = json.dumps(catalog, ensure_ascii=False, indent=2, sort_keys=True).encode('utf-8')
    temp_name = '.buildguard-{}.json'.format(uuid.uuid4().hex)
    temp_url = _remote_url(temp_name)
    final_url = _remote_url('buildguard.json')
    _request('PUT', temp_url, data=payload, expected=(200, 201, 204))
    try:
        _request(
            'MOVE',
            temp_url,
            expected=(201, 204),
            extra_headers={'Destination': final_url, 'Overwrite': 'T'},
        )
    except Exception:
        # Some WebDAV implementations do not support MOVE or reject an
        # absolute Destination header. Preserve compatibility with a direct PUT.
        _request('PUT', final_url, data=payload, expected=(200, 201, 204))
        try:
            _request('DELETE', temp_url, expected=(200, 204, 404))
        except Exception:
            pass
    public_url = _verify_public_catalog(catalog)
    ADDON.setSettingString('buildguard_public_url', public_url)
    short_url = common._optional_short_link(public_url)
    return short_url or public_url


def publish_local_backup():
    chosen = xbmcgui.Dialog().browse(1, _(32281), 'files', '.zip')
    if not chosen:
        return False
    try:
        catalog = _download_catalog()
        display_name, replace_index = common._creator_build_choice(catalog)
        if not display_name:
            return False
        local_filename = os.path.basename(chosen.replace('\\', '/'))
        remote_filename = local_filename
        if replace_index is not None:
            existing = catalog['builds'][replace_index]
            remote_filename = existing['filename']
            question = _(32336).format(existing['name'], remote_filename, local_filename)
        else:
            question = _(32337).format(display_name, local_filename)
        if not xbmcgui.Dialog().yesno(TITLE, question):
            return False
        remote_path = _upload_file(chosen, remote_filename)
        entry = {
            'name': display_name,
            'version': ADDON.getAddonInfo('version'),
            'filename': remote_filename,
            'path': remote_path,
            'download_url': _public_url(remote_filename),
            'created': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        if replace_index is None:
            catalog['builds'].append(entry)
        else:
            catalog['builds'][replace_index] = entry
        public_link = _upload_catalog(catalog)
        xbmcgui.Dialog().ok(TITLE, _(32338).format(display_name, remote_filename, public_link))
        return True
    except Exception as exc:
        safe = common._safe_text(exc, (_settings()[2],))
        xbmc.log('[BuildGuard][WebDAV publish] ' + safe, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32339).format(safe or type(exc).__name__))
        return False


def manage_published_builds():
    try:
        catalog = _download_catalog()
        builds = catalog['builds']
        if not builds:
            xbmcgui.Dialog().ok(TITLE, _(32312))
            return False
        selected = xbmcgui.Dialog().select(_(32340), [_(32305).format(i['name'], i['filename']) for i in builds])
        if selected < 0:
            return False
        action = xbmcgui.Dialog().select(_(32314), [_(32316), _(32341)])
        if action < 0:
            return False
        entry = builds[selected]
        if action == 0:
            new_name = xbmcgui.Dialog().input(_(32307), defaultt=entry['name'], type=xbmcgui.INPUT_ALPHANUM).strip()
            if not new_name or new_name == entry['name']:
                return False
            if any(i != selected and item['name'].casefold() == new_name.casefold() for i, item in enumerate(builds)):
                xbmcgui.Dialog().ok(TITLE, _(32308).format(new_name))
                return False
            entry['name'] = new_name
            _upload_catalog(catalog)
            xbmcgui.Dialog().ok(TITLE, _(32318).format(new_name))
            return True
        if not xbmcgui.Dialog().yesno(TITLE, _(32342).format(entry['name'], entry['filename'])):
            return False
        try:
            _request('DELETE', _remote_url(entry['filename']), expected=(200, 204, 404))
        except urllib.error.HTTPError as exc:
            if exc.code != 404:
                raise
        del builds[selected]
        _upload_catalog(catalog)
        xbmcgui.Dialog().ok(TITLE, _(32320).format(entry['name']))
        return True
    except Exception as exc:
        safe = common._safe_text(exc, (_settings()[2],))
        xbmc.log('[BuildGuard][WebDAV manage] ' + safe, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32321).format(safe or type(exc).__name__))
        return False


def show_public_link():
    original = ADDON.getSettingString('buildguard_public_url').strip()
    short = ADDON.getSettingString('buildguard_short_url').strip()
    if not original:
        xbmcgui.Dialog().ok(TITLE, _(32284))
        return False
    text = _(32343).format(short, original) if short else _(32344).format(original)
    xbmcgui.Dialog().textviewer(_(32285), text)
    return True


def run(action):
    if action == 'show_public_link':
        return show_public_link()
    if action == 'manage_published_builds':
        return manage_published_builds()
    if action == 'publish_backup':
        return publish_local_backup()
    return test_connection()


def test_connection():
    """Perform a harmless write/read/delete round trip and validate the public URL."""
    test_name = '.buildguard-test-{}.txt'.format(uuid.uuid4().hex)
    payload = ('BuildGuard WebDAV test ' + test_name).encode('utf-8')
    remote = None
    try:
        remote = _remote_url(test_name)
        _ensure_folder()
        _request(
            'PROPFIND',
            _remote_url(),
            data=b'',
            expected=(200, 207),
            timeout=20,
            extra_headers={'Depth': '0', 'Content-Type': 'application/xml; charset=utf-8'},
        )
        _request('PUT', remote, data=payload, expected=(200, 201, 204), timeout=30)
        _status, downloaded = _request('GET', remote, expected=(200,), timeout=30)
        if downloaded != payload:
            raise IOError(_(32362))
        _request('DELETE', remote, expected=(200, 204), timeout=30)

        # The public base URL can only be fully verified after buildguard.json
        # exists. When it exists, ensure consumers can fetch it anonymously.
        try:
            catalog = _download_catalog()
            if catalog.get('builds'):
                _verify_public_catalog(catalog)
                message = _(32357)
            else:
                message = _(32345) + '\n\n' + _(32363)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                message = _(32345) + '\n\n' + _(32363)
            else:
                raise
        ADDON.setSettingBool('webdav_last_test_ok', True)
        from resources.lib.modules import cloud_status
        cloud_status.refresh()
        xbmcgui.Dialog().ok(TITLE, message)
        return True
    except Exception as exc:
        try:
            if remote:
                _request('DELETE', remote, expected=(200, 204, 404), timeout=10)
        except Exception:
            pass
        ADDON.setSettingBool('webdav_last_test_ok', False)
        from resources.lib.modules import cloud_status
        cloud_status.refresh()
        safe = common._safe_text(exc, (_settings()[2],))
        xbmc.log('[BuildGuard][WebDAV test] ' + safe, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32346).format(safe or type(exc).__name__))
        return False
