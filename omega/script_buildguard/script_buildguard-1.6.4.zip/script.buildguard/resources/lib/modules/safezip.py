# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""Sichere ZIP-Pruefung fuer BuildGuard.

Archive werden vollstaendig validiert, bevor eine Datei geschrieben wird.
Absolute Pfade, Pfad-Traversal, symbolische Links und untypisch grosse
Entpackverhaeltnisse werden abgelehnt.
"""
import os
import re
import stat
import zipfile

MAX_MEMBER_SIZE = 2 * 1024 * 1024 * 1024       # 2 GiB pro Datei
MAX_TOTAL_SIZE = 20 * 1024 * 1024 * 1024       # 20 GiB entpackt
MAX_MEMBERS = 250000
MAX_COMPRESSION_RATIO = 1000


class UnsafeArchiveError(ValueError):
    pass


def normalize_member_name(name):
    if not isinstance(name, str):
        name = name.decode('utf-8', errors='strict')
    name = name.replace('\\', '/')
    while name.startswith('./'):
        name = name[2:]
    return name


def is_symlink(info):
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)


def validate_member(info, allowed_roots=None):
    name = normalize_member_name(info.filename)
    if not name or name == '.':
        raise UnsafeArchiveError('Leerer oder ungueltiger ZIP-Pfad')
    if '\x00' in name:
        raise UnsafeArchiveError('NUL-Zeichen im ZIP-Pfad: {!r}'.format(name))
    if name.startswith('/') or name.startswith('//'):
        raise UnsafeArchiveError('Absoluter ZIP-Pfad: {}'.format(name))
    if re.match(r'^[A-Za-z]:', name):
        raise UnsafeArchiveError('Windows-Laufwerkspfad im Archiv: {}'.format(name))

    parts = [p for p in name.split('/') if p not in ('', '.')]
    if any(p == '..' for p in parts):
        raise UnsafeArchiveError('Pfad ausserhalb des Zielordners: {}'.format(name))
    if not parts:
        raise UnsafeArchiveError('Ungueltiger ZIP-Pfad: {}'.format(name))

    if allowed_roots and parts[0].lower() not in {r.lower() for r in allowed_roots}:
        raise UnsafeArchiveError(
            'Nicht erlaubter Hauptordner {} (erlaubt: {})'.format(
                parts[0], ', '.join(sorted(allowed_roots))))
    if is_symlink(info):
        raise UnsafeArchiveError('Symbolischer Link ist nicht erlaubt: {}'.format(name))
    if info.file_size < 0 or info.file_size > MAX_MEMBER_SIZE:
        raise UnsafeArchiveError('Datei ist unzulaessig gross: {}'.format(name))
    if info.compress_size > 0 and info.file_size / float(info.compress_size) > MAX_COMPRESSION_RATIO:
        raise UnsafeArchiveError('Verdaechtiges Kompressionsverhaeltnis: {}'.format(name))
    return '/'.join(parts) + ('/' if name.endswith('/') else '')


def validate_archive(zipf, allowed_roots=None):
    infos = zipf.infolist()
    if len(infos) > MAX_MEMBERS:
        raise UnsafeArchiveError('Archiv enthaelt zu viele Eintraege: {}'.format(len(infos)))
    total = 0
    normalized = []
    seen = set()
    for info in infos:
        name = validate_member(info, allowed_roots=allowed_roots)
        key = name.casefold()
        if key in seen:
            raise UnsafeArchiveError('Doppelter ZIP-Pfad: {}'.format(name))
        seen.add(key)
        total += info.file_size
        if total > MAX_TOTAL_SIZE:
            raise UnsafeArchiveError('Archiv ist entpackt groesser als erlaubt')
        normalized.append((info, name))
    damaged = zipf.testzip()
    if damaged:
        raise UnsafeArchiveError('Beschaedigter ZIP-Eintrag: {}'.format(damaged))
    return normalized


def safe_target(base_dir, member_name):
    base = os.path.realpath(os.path.abspath(base_dir))
    target = os.path.realpath(os.path.abspath(os.path.join(base, member_name)))
    try:
        common = os.path.commonpath([base, target])
    except AttributeError:
        common = os.path.commonprefix([base + os.sep, target + os.sep]).rstrip(os.sep)
    if common != base:
        raise UnsafeArchiveError('Ziel liegt ausserhalb des erlaubten Ordners: {}'.format(member_name))
    return target
