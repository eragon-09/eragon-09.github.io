# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""Vorbereitung nativer Kodi-Addons nach einer Build-Installation.

Dieser Schritt installiert keine Binärdateien selbst. Er markiert ausschließlich
native Addons aus dem installierten Build so, dass Kodi sie nach dem Neustart
über die eingerichteten Repositories plattformgerecht aktualisieren kann.
"""
import json
import os
import tempfile
from xml.etree import ElementTree as ET

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
LOG_PREFIX = '[BuildGuard Binary]'
ADDONS_DIR = xbmcvfs.translatePath('special://home/addons')
STATUS_DIR = xbmcvfs.translatePath('special://profile/addon_data/{}/'.format(ADDON_ID))
STATUS_FILE = os.path.join(STATUS_DIR, 'binary_repair_pending.json')


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('{} {}'.format(LOG_PREFIX, message), level)


def _is_binary_addon(root):
    """Erkennt echte native Addons anhand ihrer kodi.binary-Abhängigkeiten."""
    requires = root.find('requires')
    if requires is None:
        return False
    for dependency in requires.findall('import'):
        addon_id = dependency.attrib.get('addon', '').strip()
        if addon_id.startswith('kodi.binary.'):
            return True
    return False


def _write_atomic(path, content):
    parent = os.path.dirname(path)
    if not os.path.isdir(parent):
        os.makedirs(parent)
    handle, temp_path = tempfile.mkstemp(prefix='.buildguard-', dir=parent)
    try:
        with os.fdopen(handle, 'wb') as stream:
            if isinstance(content, str):
                content = content.encode('utf-8')
            stream.write(content)
            stream.flush()
            try:
                os.fsync(stream.fileno())
            except OSError:
                pass
        os.replace(temp_path, path)
    except Exception:
        try:
            os.remove(temp_path)
        except OSError:
            pass
        raise


def _prepare_addon(addon_dir):
    addon_xml = os.path.join(addon_dir, 'addon.xml')
    if not os.path.isfile(addon_xml):
        return False

    tree = ET.parse(addon_xml)
    root = tree.getroot()
    if not _is_binary_addon(root):
        return False

    changed = False
    if root.attrib.get('version') != '1.0.0':
        root.attrib['version'] = '1.0.0'
        changed = True

    # Nur ausführbare native Erweiterungspunkte umstellen. Metadaten- und
    # Python-Erweiterungen bleiben unverändert.
    native_extensions = []
    for extension in root.findall('extension'):
        point = extension.attrib.get('point', '').strip()
        if point.startswith('kodi.'):
            native_extensions.append(extension)

    if not native_extensions:
        _log(_(32196).format(os.path.basename(addon_dir)), xbmc.LOGWARNING)
        return False

    for extension in native_extensions:
        extension.attrib.clear()
        extension.attrib['point'] = 'xbmc.python.script'
        extension.attrib['library'] = 'default.py'
        for child in list(extension):
            extension.remove(child)
        changed = True

    metadata = root.find("./extension[@point='xbmc.addon.metadata']")
    if metadata is not None:
        platform = metadata.find('platform')
        if platform is not None and (platform.text or '').strip() != 'all':
            platform.text = 'all'
            changed = True

    dummy_path = os.path.join(addon_dir, 'default.py')
    if not os.path.isfile(dummy_path):
        _write_atomic(dummy_path, '# BuildGuard placeholder for platform-specific binary update\n')
        changed = True

    if not changed:
        return False

    xml_data = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    _write_atomic(addon_xml, xml_data)
    return True


def write_pending_status(addon_ids, phase='prepared', attempts=0):
    """Speichert den Installationsstatus für Service und Abschlusskontrolle."""
    if not os.path.isdir(STATUS_DIR):
        os.makedirs(STATUS_DIR)
    payload = {
        'schema': 2,
        'pending': bool(addon_ids),
        'phase': phase,
        'attempts': int(attempts),
        'addons': list(addon_ids),
    }
    _write_atomic(STATUS_FILE, json.dumps(payload, ensure_ascii=False, indent=2) + '\n')


def _find_addon_xml(addon_id):
    """Findet addon.xml anhand ID, auch wenn Ordnername und ID abweichen."""
    direct = os.path.join(ADDONS_DIR, addon_id, 'addon.xml')
    if os.path.isfile(direct):
        return direct
    try:
        entries = os.listdir(ADDONS_DIR)
    except OSError:
        return None
    for folder in entries:
        addon_xml = os.path.join(ADDONS_DIR, folder, 'addon.xml')
        if not os.path.isfile(addon_xml):
            continue
        try:
            root = ET.parse(addon_xml).getroot()
            if root.attrib.get('id') == addon_id:
                return addon_xml
        except (OSError, ET.ParseError):
            continue
    return None


def _is_buildguard_placeholder(addon_xml):
    """Erkennt den temporären Python-Platzhalter aus Schritt 4.2."""
    try:
        root = ET.parse(addon_xml).getroot()
    except (OSError, ET.ParseError):
        return True
    for extension in root.findall('extension'):
        if (extension.attrib.get('point') == 'xbmc.python.script'
                and extension.attrib.get('library') == 'default.py'):
            dummy = os.path.join(os.path.dirname(addon_xml), 'default.py')
            try:
                with open(dummy, 'rb') as stream:
                    marker = stream.read(512).decode('utf-8', 'ignore')
                if 'BuildGuard placeholder' in marker or 'Temporary BuildGuard placeholder' in marker:
                    return True
            except OSError:
                return True
    return False


def verify_prepared_addons(addon_ids):
    """Prüft, welche vorbereiteten Addons ersetzt, ausstehend oder fehlen."""
    installed = []
    pending = []
    missing = []
    for addon_id in addon_ids:
        addon_xml = _find_addon_xml(addon_id)
        if not addon_xml:
            missing.append(addon_id)
        elif _is_buildguard_placeholder(addon_xml):
            pending.append(addon_id)
        else:
            installed.append(addon_id)
    return installed, pending, missing

def read_pending_status():
    """Liest den persistenten Status; ungültige Dateien bleiben reparierbar."""
    if not os.path.isfile(STATUS_FILE):
        return {'schema': 2, 'pending': False, 'phase': 'none', 'attempts': 0, 'addons': []}
    try:
        with open(STATUS_FILE, 'rb') as stream:
            raw = stream.read().decode('utf-8')
        payload = json.loads(raw)
        addons = payload.get('addons') or []
        if not isinstance(addons, list):
            addons = []
        return {
            'schema': payload.get('schema', 1),
            'pending': bool(payload.get('pending')),
            'phase': str(payload.get('phase', 'prepared')),
            'attempts': int(payload.get('attempts', 0) or 0),
            'addons': [str(item) for item in addons if item],
        }
    except (OSError, ValueError, TypeError) as exc:
        _log(_(32224).format(exc), xbmc.LOGWARNING)
        return {'schema': 2, 'pending': False, 'phase': 'none', 'attempts': 0, 'addons': []}


def clear_pending_status():
    """Entfernt den Status erst nachdem Kodi die Addon-Aktualisierung annahm."""
    try:
        if os.path.isfile(STATUS_FILE):
            os.remove(STATUS_FILE)
    except OSError as exc:
        _log(_(32225).format(exc), xbmc.LOGWARNING)

def prepare_binary_addons():
    """Bereitet native Addons vor und speichert den Status für Schritt 4.3."""
    prepared = []
    failed = []

    try:
        entries = sorted(os.listdir(ADDONS_DIR))
    except OSError as exc:
        _log(_(32192).format(exc), xbmc.LOGERROR)
        raise RuntimeError(_(32192).format(exc))

    for folder_name in entries:
        if folder_name == ADDON_ID:
            continue
        addon_dir = os.path.join(ADDONS_DIR, folder_name)
        if not os.path.isdir(addon_dir):
            continue
        try:
            if _prepare_addon(addon_dir):
                prepared.append(folder_name)
                _log(_(32193).format(folder_name))
        except (OSError, ET.ParseError, ValueError) as exc:
            failed.append(folder_name)
            _log(_(32194).format(folder_name, exc), xbmc.LOGWARNING)

    write_pending_status(prepared)

    # Kompatibilität mit dem vorhandenen Service bis Schritt 4.3.
    ADDON.setSetting('binary_repair_pending', 'true' if prepared else 'false')
    ADDON.setSetting('binary_repair_addons', ','.join(prepared))

    if failed:
        _log(_(32195).format(len(failed), ', '.join(failed)), xbmc.LOGWARNING)
    return prepared
