# SPDX-License-Identifier: GPL-3.0-or-later
"""Berechnet einen einzigen, laienverstaendlichen Verbindungsstatus fuer den
aktuell in publication_provider ausgewaehlten Cloud-Anbieter.

Der Wert wird ausschliesslich lokal ermittelt (Einstellungen und Vorhandensein
der Token-Datei bzw. des letzten WebDAV-Testergebnisses) - es findet kein
Netzwerkaufruf statt. Aufgerufen wird refresh() nach jeder relevanten Aktion
(Verbinden, Trennen, Verbindung testen) sowie einmalig beim Kodi-Start.
"""
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('script.buildguard')

_PROVIDER_NAMES = {0: 'Dropbox', 1: 'Google Drive', 2: 'WebDAV'}


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def _provider_index():
    try:
        return ADDON.getSettingInt('publication_provider')
    except Exception:
        try:
            return int(ADDON.getSetting('publication_provider') or '0')
        except (TypeError, ValueError):
            return 0


def _dropbox_ready():
    from resources.lib.modules import dropbox_auth
    key = ADDON.getSettingString('dropbox_app_key').strip()
    secret = ADDON.getSettingString('dropbox_app_secret').strip()
    if not (key and secret):
        return False
    return xbmcvfs.exists(dropbox_auth.token_path())


def _google_ready():
    from resources.lib.modules import google_drive_provider
    client_id = ADDON.getSettingString('google_drive_client_id').strip()
    client_secret = ADDON.getSettingString('google_drive_client_secret').strip()
    if not (client_id and client_secret):
        return False
    return xbmcvfs.exists(google_drive_provider.token_path())


def _webdav_ready():
    server = ADDON.getSettingString('webdav_server_url').strip()
    username = ADDON.getSettingString('webdav_username').strip()
    password = ADDON.getSettingString('webdav_password')
    folder = ADDON.getSettingString('webdav_folder').strip()
    if not (server and server != 'https://' and username and password and folder):
        return False
    return ADDON.getSettingBool('webdav_last_test_ok')


def refresh():
    """Statuswert neu berechnen, in cloud_status speichern und zurueckgeben."""
    index = _provider_index()
    try:
        if index == 1:
            ready = _google_ready()
        elif index == 2:
            ready = _webdav_ready()
        else:
            ready = _dropbox_ready()
    except Exception:
        ready = False
    provider_name = _PROVIDER_NAMES.get(index, 'Dropbox')
    text = _(32986).format(provider_name) if ready else _(32987)
    try:
        # Nur schreiben, wenn sich der Wert tatsaechlich aendert. Das haelt
        # onSettingsChanged() im Hintergrunddienst frei von einer moeglichen
        # Rueckkopplungsschleife (Schreiben loest erneut onSettingsChanged aus).
        if ADDON.getSettingString('cloud_status') != text:
            ADDON.setSettingString('cloud_status', text)
    except Exception:
        pass
    return ready
