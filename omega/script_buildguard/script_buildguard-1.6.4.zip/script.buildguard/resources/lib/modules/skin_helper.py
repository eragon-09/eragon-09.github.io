# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""
Gemeinsame Skin-Hilfsfunktionen, genutzt von default.py (merkt nach einem
Restore einen Skin-Wechsel vor) und service.py (wendet ihn beim nächsten
Kodi-Start an).

Warum über einen Service statt live mitten im Restore?
Ein Live-Wechsel direkt im Restore-Ablauf (kurz vor dem erzwungenen Quit)
ist fragil: das eigene Fenster schließt gerade, Kodis "Diesen Skin
behalten?"-Sicherheitsdialog müsste exakt in diesem kurzen Zeitfenster
erscheinen UND bedient werden, und direkt danach folgt schon der
Neustart. Ein separater Service, der bei einem VOLLSTÄNDIG hochgefahrenen
Kodi (kein Restore mehr aktiv, keine eigenen Fenster offen) ansetzt, ist
ein deutlich saubererer, unaufgeregter Moment für einen Settings-Wechsel.
"""

import json
import os

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo('name')

# special://profile/ ist automatisch der richtige addon_data-Ordner
# dieses Addons - überlebt Neustarts, im Gegensatz zu special://temp/
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
if not PROFILE_DIR.endswith(('/', '\\')):
    PROFILE_DIR += '/'
PENDING_SKIN_FILE = PROFILE_DIR + 'pending_skin.txt'


def log(msg):
    xbmc.log('[{}] {}'.format(ADDON_NAME, msg), xbmc.LOGINFO)


def write_pending_skin(skin_id):
    """Merkt einen Skin-Wechsel für den nächsten Kodi-Start vor."""
    if not skin_id:
        return
    try:
        if not xbmcvfs.exists(PROFILE_DIR):
            xbmcvfs.mkdirs(PROFILE_DIR)
        f = xbmcvfs.File(PENDING_SKIN_FILE, 'w')
        try:
            f.write(skin_id.encode('utf-8'))
        finally:
            f.close()
        log('Skin-Wechsel für nächsten Kodi-Start vorgemerkt: {}'.format(skin_id))
    except Exception as e:
        log('Konnte Skin-Wechsel nicht vormerken: {}'.format(e))


def read_and_clear_pending_skin():
    """Liest einen vorgemerkten Skin-Wechsel aus und löscht den Marker
    sofort, damit er nur EINMAL angewendet wird (nicht bei jedem
    weiteren Kodi-Start erneut)."""
    try:
        if not xbmcvfs.exists(PENDING_SKIN_FILE):
            return None
        f = xbmcvfs.File(PENDING_SKIN_FILE)
        try:
            data = f.read()
        finally:
            f.close()
        if isinstance(data, bytes):
            data = data.decode('utf-8', errors='ignore')
        skin_id = data.strip()
        xbmcvfs.delete(PENDING_SKIN_FILE)
        return skin_id or None
    except Exception as e:
        log('Konnte vorgemerkten Skin-Wechsel nicht lesen: {}'.format(e))
        return None


def _set_skin_setting(skin_id):
    """Entspricht swapSkins()/setNew() in SimpleWizards skinSwitch.py:
    setzt lookandfeel.skin über Kodis Settings-JSON-RPC (nicht über
    LoadSkin()). Nur der Weg über die Settings-API aktualisiert
    zuverlässig auch den PERSISTIERTEN Einstellungswert."""
    try:
        payload = json.dumps({
            'jsonrpc': '2.0',
            'method': 'Settings.SetSettingValue',
            'params': {'setting': 'lookandfeel.skin', 'value': skin_id},
            'id': 1
        })
        xbmc.executeJSONRPC(payload)
    except Exception as e:
        log('Konnte lookandfeel.skin nicht setzen: {}'.format(e))


def activate_skin_live(skin_id):
    """1:1 derselbe Ablauf wie in SimpleWizards fresh_start() (maintenance.py):

        if not currSkin() in [skin]:
            swapSkins(skin)
            x = 0
            xbmc.sleep(100)
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
                x += 1
                xbmc.sleep(100)
                xbmc.executebuiltin('SendAction(Select)')
            if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin('SendClick(11)')
            else:
                log('Skin Swap Timed Out!')
            xbmc.sleep(100)
    """
    if not skin_id:
        return

    try:
        current_skin = xbmc.getSkinDir()
    except Exception:
        current_skin = None

    if current_skin == skin_id:
        log('Skin {} ist bereits aktiv, kein Wechsel nötig.'.format(skin_id))
        return

    log('Aktiviere Skin: {} (aktuell: {})'.format(skin_id, current_skin))
    _set_skin_setting(skin_id)

    x = 0
    xbmc.sleep(100)
    while not xbmc.getCondVisibility('Window.isVisible(yesnodialog)') and x < 150:
        x += 1
        xbmc.sleep(100)
        xbmc.executebuiltin('SendAction(Select)')

    if xbmc.getCondVisibility('Window.isVisible(yesnodialog)'):
        xbmc.executebuiltin('SendClick(11)')
        log('Skin-Bestätigungsdialog bestätigt.')
    else:
        log('Skin-Wechsel: Bestätigungsdialog nicht erschienen (Timeout nach {}s) '
            'oder kein Dialog nötig.'.format(x / 10.0))

    xbmc.sleep(100)

    try:
        final_skin = xbmc.getSkinDir()
        if final_skin != skin_id:
            log('Skin-Wechsel evtl. nicht übernommen (aktuell: {})'.format(final_skin))
        else:
            log('Skin-Wechsel erfolgreich: {}'.format(final_skin))
    except Exception:
        pass
