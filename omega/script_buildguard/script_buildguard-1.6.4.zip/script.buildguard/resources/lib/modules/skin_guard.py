# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""Skin-Schutz vor Fresh Start und Build-Installation.

BuildGuard wechselt auf einen mit Kodi gelieferten Standardskin, bevor Dateien
entfernt werden. Dadurch bleibt die Oberfläche bedienbar, falls der aktuell
aktive Drittanbieter-Skin gelöscht wird.
"""
import json

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
TITLE = ADDON.getAddonInfo('name')


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def _kodi_major():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except (TypeError, ValueError, IndexError):
        return 0


def _set_skin(skin_id):
    payload = json.dumps({
        'jsonrpc': '2.0',
        'method': 'Settings.SetSettingValue',
        'params': {'setting': 'lookandfeel.skin', 'value': skin_id},
        'id': 1,
    })
    response = xbmc.executeJSONRPC(payload)
    xbmc.log('[BuildGuard] Skin-Setting-Antwort: {}'.format(response), xbmc.LOGDEBUG)


def ensure_safe_skin():
    """Wechselt nach Zustimmung auf Estuary/Confluence.

    Gibt ``True`` zurück, wenn der Vorgang fortgesetzt werden darf. Lehnt der
    Nutzer den notwendigen Wechsel ab, wird ``False`` zurückgegeben.
    """
    current = xbmc.getSkinDir()
    safe_skins = ('skin.estuary', 'skin.confluence')
    if current in safe_skins:
        return True

    if not xbmcgui.Dialog().yesno(
            TITLE, _(32120), yeslabel=_(32121), nolabel=_(32122)):
        xbmcgui.Dialog().ok(TITLE, _(32123))
        return False

    target = 'skin.estuary' if _kodi_major() >= 17 else 'skin.confluence'
    try:
        _set_skin(target)
    except Exception as exc:
        xbmc.log('[BuildGuard] Skinwechsel fehlgeschlagen: {}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, 'Der Standardskin konnte nicht aktiviert werden.\n\n{}'.format(exc))
        return False

    monitor = xbmc.Monitor()
    for _unused in range(150):
        if monitor.waitForAbort(0.1):
            return False
        if xbmc.getCondVisibility('Window.isVisible(yesnodialog)'):
            xbmc.executebuiltin('SendClick(11)')
            break

    return xbmc.getSkinDir() in safe_skins or xbmc.getSkinDir() == target
