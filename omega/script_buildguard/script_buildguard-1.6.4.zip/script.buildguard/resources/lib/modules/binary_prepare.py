# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""Vorbereitung nativer Kodi-Addons nach einer Build-Installation.

Die eigentliche Plattformauswahl übernimmt Kodi nach dem Neustart. Dieses
Modul markiert ausschließlich eindeutig erkannte Binary-Addons als veraltet
und ersetzt ihren nativen Einstiegspunkt vorübergehend durch ein harmloses
Python-Skript. Dadurch kann Kodi starten und anschließend die zur aktuellen
Plattform passende Version aus den konfigurierten Repositories beziehen.
"""
import os
import tempfile
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon(id='script.buildguard')
ADDONS_DIR = xbmcvfs.translatePath('special://home/addons/')
OWN_ADDON_ID = 'script.buildguard'
LOG_PREFIX = '[BuildGuard Binary]'
DUMMY_SCRIPT = (
    '# -*- coding: utf-8 -*-\n'
    '# Temporary BuildGuard placeholder. Kodi replaces this add-on with the\n'
    '# platform-specific repository version after the next restart.\n'
)


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('{} {}'.format(LOG_PREFIX, message), level)


def _atomic_write(path, content):
    """Schreibt eine Textdatei möglichst atomar in dasselbe Verzeichnis."""
    directory = os.path.dirname(path)
    fd, temporary = tempfile.mkstemp(prefix='.buildguard-', dir=directory)
    try:
        with os.fdopen(fd, 'w') as handle:
            handle.write(content)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        try:
            os.replace(temporary, path)
        except AttributeError:  # Python-2-Fallback
            if os.path.exists(path):
                os.remove(path)
            os.rename(temporary, path)
    except Exception:
        try:
            os.remove(temporary)
        except OSError:
            pass
        raise


def _is_binary_addon(root):
    """Erkennt native Addons anhand kodi.binary-Abhängigkeit + kodi.*-Punkt."""
    has_binary_dependency = any(
        item.attrib.get('addon', '').startswith('kodi.binary')
        for item in root.findall('./requires/import')
    )
    has_native_extension = any(
        item.attrib.get('point', '').startswith('kodi.')
        for item in root.findall('extension')
    )
    return has_binary_dependency and has_native_extension


def _prepare_addon(addon_dir, addon_id):
    addon_xml = os.path.join(addon_dir, 'addon.xml')
    try:
        with open(addon_xml, 'rb') as handle:
            original = handle.read()
        root = ET.fromstring(original)
    except Exception as exc:
        raise RuntimeError(_(32202).format(addon_id, exc))

    if not _is_binary_addon(root):
        return False

    root.attrib['version'] = '1.0.0'
    changed_extensions = 0
    for extension in root.findall('extension'):
        point = extension.attrib.get('point', '')
        if not point.startswith('kodi.'):
            continue
        extension.attrib.clear()
        extension.attrib['point'] = 'xbmc.python.script'
        extension.attrib['library'] = 'default.py'
        changed_extensions += 1

    if not changed_extensions:
        return False

    metadata = root.find("./extension[@point='xbmc.addon.metadata']")
    if metadata is not None:
        platform = metadata.find('platform')
        if platform is None:
            platform = ET.SubElement(metadata, 'platform')
        platform.text = 'all'

    xml_body = ET.tostring(root, encoding='utf-8')
    if not isinstance(xml_body, str):
        xml_body = xml_body.decode('utf-8')
    xml_text = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' + xml_body

    _atomic_write(addon_xml, xml_text)
    _atomic_write(os.path.join(addon_dir, 'default.py'), DUMMY_SCRIPT)
    return True


def prepare_binary_addons():
    """Bereitet eindeutig erkannte Binary-Addons für den nächsten Start vor.

    Rückgabe: ``(prepared, failed)``. ``prepared`` enthält Addon-IDs,
    ``failed`` enthält Paare aus Addon-ID und Fehlermeldung. Ein einzelnes
    defektes addon.xml verhindert damit nicht die restliche Installation.
    """
    prepared = []
    failed = []
    _log(_(32200))

    try:
        entries = sorted(os.listdir(ADDONS_DIR))
    except OSError as exc:
        raise RuntimeError(_(32201).format(exc))

    for folder in entries:
        addon_dir = os.path.join(ADDONS_DIR, folder)
        addon_xml = os.path.join(addon_dir, 'addon.xml')
        if folder == OWN_ADDON_ID or not os.path.isdir(addon_dir) or not os.path.isfile(addon_xml):
            continue

        try:
            with open(addon_xml, 'rb') as handle:
                root = ET.fromstring(handle.read())
            addon_id = root.attrib.get('id') or folder
            if not _is_binary_addon(root):
                continue
            if _prepare_addon(addon_dir, addon_id):
                prepared.append(addon_id)
                _log(_(32203).format(addon_id))
        except Exception as exc:
            addon_id = folder
            failed.append((addon_id, str(exc)))
            _log(_(32204).format(addon_id, exc), xbmc.LOGERROR)

    _log(_(32205).format(len(prepared), len(failed)))
    return prepared, failed
