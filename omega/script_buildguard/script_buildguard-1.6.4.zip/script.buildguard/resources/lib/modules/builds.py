# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""Sicherer Build-Download und -Installer für BuildGuard.

Das Archiv wird heruntergeladen und vollständig validiert, bevor BuildGuard
einen Fresh Start anbietet oder Kodi-Dateien überschreibt.
"""
import os
import re
import sqlite3
import time
import zipfile
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

try:
    from urllib.parse import urlparse
    from urllib.request import Request, urlopen
except ImportError:  # Kodi/Python 2 Legacy-Fallback
    from urlparse import urlparse
    from urllib2 import Request, urlopen

from resources.lib.modules.safezip import UnsafeArchiveError, safe_target, validate_archive

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
TITLE = ADDON.getAddonInfo('name')
USER_AGENT = 'BuildGuard/{}'.format(ADDON.getAddonInfo('version'))
CHUNK_SIZE = 1024 * 1024
MAX_DOWNLOAD_SIZE = 8 * 1024 * 1024 * 1024
LOG_PREFIX = '[BuildGuard Installer]'


def _(string_id):
    return ADDON.getLocalizedString(string_id)



def _log(message, level=xbmc.LOGINFO):
    xbmc.log('{} {}'.format(LOG_PREFIX, message), level)


def _close_progress(progress):
    try:
        progress.close()
    except Exception:
        pass


def _remove_temp_file(path):
    try:
        if os.path.exists(path):
            os.remove(path)
            _log(_(32167).format(path))
    except OSError as exc:
        _log(_(32168).format(exc), xbmc.LOGWARNING)


def _validate_downloaded_archive(zip_path):
    if not os.path.isfile(zip_path):
        raise RuntimeError(_(32160))
    size = os.path.getsize(zip_path)
    if size <= 0:
        raise RuntimeError(_(32161))
    if size > MAX_DOWNLOAD_SIZE:
        raise RuntimeError(_(32144))
    with zipfile.ZipFile(zip_path, 'r') as archive:
        members = validate_archive(archive)
        damaged = archive.testzip()
        if damaged:
            raise zipfile.BadZipFile(_(32162).format(damaged))
        if not members:
            raise RuntimeError(_(32163))
    return size, len(members)


def _validate_source(source):
    source = (source or '').strip()
    parsed = urlparse(source)
    if parsed.scheme:
        if parsed.scheme.lower() != 'https':
            raise ValueError(_(32139))
        return source, True
    local = xbmcvfs.translatePath(source)
    if os.path.isfile(local):
        return local, False
    raise ValueError(_(32140))


def _copy_local(source, destination, progress):
    total = os.path.getsize(source)
    copied = 0
    with open(source, 'rb') as src, open(destination, 'wb') as dst:
        while True:
            chunk = src.read(CHUNK_SIZE)
            if not chunk:
                break
            dst.write(chunk)
            copied += len(chunk)
            percent = int(copied * 100.0 / total) if total else 0
            progress.update(percent, _(32141))
            if progress.iscanceled():
                raise RuntimeError(_(32142))


def _download_https(url, destination, progress):
    request = Request(url, headers={'User-Agent': USER_AGENT})
    response = urlopen(request, timeout=30)
    try:
        content_length = response.headers.get('Content-Length')
        total = int(content_length) if content_length else 0
        if total > MAX_DOWNLOAD_SIZE:
            raise RuntimeError(_(32143))
        downloaded = 0
        started = time.time()
        with open(destination, 'wb') as dst:
            while True:
                chunk = response.read(CHUNK_SIZE)
                if not chunk:
                    break
                downloaded += len(chunk)
                if downloaded > MAX_DOWNLOAD_SIZE:
                    raise RuntimeError(_(32144))
                dst.write(chunk)
                percent = int(downloaded * 100.0 / total) if total else 0
                elapsed = max(time.time() - started, 0.1)
                speed = downloaded / elapsed / 1048576.0
                progress.update(percent, _(32145).format(downloaded / 1048576.0, speed))
                if progress.iscanceled():
                    raise RuntimeError(_(32146))
    finally:
        response.close()


def _is_addons_database(name):
    """Simple-Wizard-Verhalten: Addons*.db darf trotz vorhandener Datei ersetzt werden."""
    base = os.path.basename(name.replace('\\', '/'))
    return bool(re.match(r'^Addons\d+\.db$', base, re.IGNORECASE))


def _extract(zip_path, destination, progress):
    """Entpackt wie der aktuelle Simple Wizard: vorhandene Dateien bleiben erhalten.

    Das ist besonders wichtig fuer BuildGuard selbst und bewusst erhaltene Dateien,
    die waehrend der laufenden Installation nicht ueberschrieben werden sollen.
    Die Addons-Datenbank ist die Ausnahme und wird aus dem Build uebernommen.
    """
    with zipfile.ZipFile(zip_path, 'r') as archive:
        members = validate_archive(archive)
        total = sum(info.file_size for info, _name in members) or 1
        processed = 0
        for info, name in members:
            target = safe_target(destination, name)
            if name.endswith('/'):
                if not os.path.isdir(target):
                    os.makedirs(target)
                continue

            # Portiert aus Simple Wizard: vorhandene Dateien werden nicht
            # blind ueberschrieben. Die Addons*.db ist bewusst ausgenommen.
            if os.path.exists(target) and not _is_addons_database(name):
                processed += info.file_size
                progress.update(min(int(processed * 100.0 / total), 100), name)
                if progress.iscanceled():
                    raise RuntimeError(_(32147))
                continue

            parent = os.path.dirname(target)
            if not os.path.isdir(parent):
                os.makedirs(parent)
            try:
                with archive.open(info, 'r') as src, open(target, 'wb') as dst:
                    while True:
                        chunk = src.read(CHUNK_SIZE)
                        if not chunk:
                            break
                        dst.write(chunk)
                        processed += len(chunk)
                        progress.update(min(int(processed * 100.0 / total), 100), name)
                        if progress.iscanceled():
                            raise RuntimeError(_(32147))
            except OSError as exc:
                if _is_addons_database(name):
                    # Unter Windows kann Kodis laufende Addons-Datenbank gesperrt sein.
                    # In diesem Fall bleibt die aktuelle DB erhalten und wird unten
                    # finalisiert, statt die bereits gestartete Installation abzubrechen.
                    processed += info.file_size
                    progress.update(min(int(processed * 100.0 / total), 100), name)
                    _log('Addons-Datenbank ist gesperrt und wurde nicht ersetzt: {}'.format(exc), xbmc.LOGWARNING)
                    continue
                raise


def _latest_addons_db():
    db_dir = xbmcvfs.translatePath('special://database/')
    newest = None
    newest_number = -1
    try:
        for filename in os.listdir(db_dir):
            match = re.match(r'^Addons(\d+)\.db$', filename, re.IGNORECASE)
            if match and int(match.group(1)) > newest_number:
                newest_number = int(match.group(1))
                newest = os.path.join(db_dir, filename)
    except OSError:
        return None
    return newest


def _finalize_addon_database():
    """Uebernimmt die zwei relevanten Finalisierungsschritte des Simple Wizard.

    BuildGuard wird nach dem Build-Import wieder als aktiviert markiert und
    die Metadaten des offiziellen Kodi-Repositories werden fuer eine frische
    Pruefung zurueckgesetzt.
    """
    db_path = _latest_addons_db()
    if not db_path or not os.path.isfile(db_path):
        _log('Keine Addons-Datenbank fuer die Finalisierung gefunden.', xbmc.LOGWARNING)
        return

    con = None
    try:
        con = sqlite3.connect(db_path)
        cur = con.cursor()
        timestamp = str(datetime.now())[:-7]
        cur.execute(
            'INSERT OR IGNORE INTO installed (addonID, enabled, installDate) VALUES (?, ?, ?)',
            (ADDON_ID, 1, timestamp)
        )
        cur.execute('UPDATE installed SET enabled = ? WHERE addonID = ?', (1, ADDON_ID))
        try:
            cur.execute(
                'UPDATE repo SET version = ?, checksum = ?, lastcheck = ? WHERE addonID = ?',
                ('', '', '', 'repository.xbmc.org')
            )
        except sqlite3.Error as exc:
            _log('Repository-Metadaten konnten nicht zurueckgesetzt werden: {}'.format(exc), xbmc.LOGWARNING)
        con.commit()
    except sqlite3.Error as exc:
        _log('Addons-Datenbank konnte nicht finalisiert werden: {}'.format(exc), xbmc.LOGWARNING)
    finally:
        if con is not None:
            try:
                con.close()
            except Exception:
                pass


def install_build(source, fresh_start_callback, skin_prepare_callback):
    """Validiert zuerst, verändert Kodi erst nach ausdrücklicher Zustimmung."""
    progress = xbmcgui.DialogProgress()
    temp_dir = xbmcvfs.translatePath('special://temp/buildguard')
    zip_path = os.path.join(temp_dir, 'validated_build.zip')
    destructive_started = False
    try:
        _log(_(32169))
        source, is_remote = _validate_source(source)
        _log(_(32170).format(_(32171) if is_remote else _(32172)))

        if not os.path.isdir(temp_dir):
            os.makedirs(temp_dir)
        _remove_temp_file(zip_path)

        progress.create(TITLE, _(32148))
        if is_remote:
            _log(_(32173))
            _download_https(source, zip_path, progress)
            _log(_(32174))
        else:
            _log(_(32175))
            _copy_local(source, zip_path, progress)
            _log(_(32176))

        progress.update(100, _(32149))
        archive_size, member_count = _validate_downloaded_archive(zip_path)
        _log(_(32177).format(member_count, archive_size))
        _close_progress(progress)

        warning = _(32150)
        if not xbmcgui.Dialog().yesno(TITLE, warning, yeslabel=_(32151), nolabel=_(32152)):
            _log(_(32178))
            return False

        _log(_(32179))
        if not skin_prepare_callback():
            _log(_(32180), xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(TITLE, _(32164))
            return False
        _log(_(32181))

        _log(_(32182))
        destructive_started = True
        if not fresh_start_callback(mode='silent'):
            _log(_(32183), xbmc.LOGERROR)
            xbmcgui.Dialog().ok(TITLE, _(32165))
            return False
        _log(_(32184))

        progress.create(TITLE, _(32153))
        _log(_(32185))
        _extract(zip_path, xbmcvfs.translatePath('special://home/'), progress)
        progress.update(100, _(32154))
        _log(_(32186).format(member_count))

        # Schritt 4.2: Native Addons werden in einem eigenen, kleinen Modul
        # eindeutig anhand ihrer kodi.binary-Abhängigkeit erkannt. Kodi selbst
        # wählt nach dem Neustart die passende Plattformversion aus.
        from resources.lib.modules.binary_prepare import prepare_binary_addons
        fixed_binaries, binary_failures = prepare_binary_addons()
        if fixed_binaries:
            from resources.lib.modules import binary_guard
            binary_guard.write_pending_status(fixed_binaries)
            ADDON.setSetting('binary_repair_pending', 'true')
            ADDON.setSetting('binary_repair_addons', ','.join(fixed_binaries))
            _log(_(32187).format(len(fixed_binaries), ', '.join(fixed_binaries)))
        else:
            ADDON.setSetting('binary_repair_pending', 'false')
            ADDON.setSetting('binary_repair_addons', '')
            _log(_(32188))
        if binary_failures:
            _log(_(32206).format(len(binary_failures)), xbmc.LOGWARNING)

        _close_progress(progress)

        # Finalisierung analog zum aktuellen Simple Wizard: laufendes Wizard-
        # Addon wieder aktivieren und Repository-Status fuer Kodi auffrischen.
        xbmcgui.Dialog().notification(
            TITLE, _(32534), ADDON.getAddonInfo('icon'), 5000
        )
        _finalize_addon_database()

        _log(_(32189))
        xbmcgui.Dialog().notification(
            TITLE, _(32535), ADDON.getAddonInfo('icon'), 3000
        )
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification(
            TITLE, _(32536), ADDON.getAddonInfo('icon'), 3000
        )
        xbmc.sleep(4000)
        os._exit(1)
    except (UnsafeArchiveError, zipfile.BadZipFile, ValueError, RuntimeError, OSError) as exc:
        _close_progress(progress)
        _log(_(32190).format(exc), xbmc.LOGERROR)
        message_id = 32166 if destructive_started else 32158
        xbmcgui.Dialog().ok(TITLE, _(message_id).format(exc))
        return False
    except Exception as exc:
        _close_progress(progress)
        _log(_(32191).format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32159).format(exc))
        return False
    finally:
        _close_progress(progress)
        _remove_temp_file(zip_path)

