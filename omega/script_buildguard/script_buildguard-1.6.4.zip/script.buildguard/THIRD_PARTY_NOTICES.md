# Third-party notices and provenance

BuildGuard is a derivative open-source project. This file records what is currently supported by the source tree and avoids claiming authorship that has not been verified.

## Known credits

- **EZ Maintenance+** — credited in `addon.xml` to **aenema** and **peno** as the base project.
- **Truncate Tables functionality** — credited in `addon.xml` to **The Cleaner**.
- Several source files contain GNU GPL version 3-or-later notices. Those notices are retained.

## Attribution status

The package supplied for this review did not include authoritative upstream repository URLs, commit IDs, release archives, or a complete historical copyright inventory. Therefore this notice does **not** certify complete provenance. Before publishing to a public repository or Kodi add-on repository, the maintainer should:

1. identify the exact upstream repositories and versions;
2. add their URLs and copyright notices here;
3. verify that all bundled images and skin assets may be redistributed under GPL-compatible terms;
4. retain every upstream license and attribution notice;
5. document substantial modifications in `changelog.txt`.

No permission claim beyond the included license notices is made here.
