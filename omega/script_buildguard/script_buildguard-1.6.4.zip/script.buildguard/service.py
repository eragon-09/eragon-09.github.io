# SPDX-License-Identifier: GPL-3.0-or-later
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.modules.backtothefuture import PY2
from resources.lib.modules import binary_guard
from resources.lib.modules import cloud_status
from resources.lib.modules import maintenance
from resources.lib.modules import skin_helper

if PY2:
    translatePath = xbmc.translatePath
    loglevel = xbmc.LOGNOTICE
else:
    translatePath = xbmcvfs.translatePath
    loglevel = xbmc.LOGINFO

AddonID = 'script.buildguard'
packagesdir = translatePath('special://home/addons/packages/')
thumbnails = translatePath('special://home/userdata/Thumbnails/')
dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon(id=AddonID)
setting = addon.getSetting
iconpath = translatePath('special://home/addons/{}/icon.png'.format(AddonID))
LOG_PREFIX = '[BuildGuard Service]'
BINARY_VERIFY_TIMEOUT = 300.0
BINARY_VERIFY_INTERVAL = 5.0
BINARY_UPDATE_RETRY_INTERVAL = 30.0


def _(string_id):
    return addon.getLocalizedString(string_id)


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('{} {}'.format(LOG_PREFIX, message), level)


def _setting_int(name, default):
    try:
        return int(setting(name))
    except (TypeError, ValueError):
        return default


def _folder_stats(path, monitor):
    total = 0
    count = 0
    if not os.path.isdir(path):
        return 0, 0
    for dirpath, _dirnames, filenames in os.walk(path):
        if monitor.abortRequested():
            break
        for filename in filenames:
            try:
                total += os.path.getsize(os.path.join(dirpath, filename))
                count += 1
            except OSError as exc:
                _log(_(32217).format(exc), xbmc.LOGWARNING)
    return total, count


def _wait_for_gui(monitor, timeout=60.0):
    waited = 0.0
    while not monitor.abortRequested() and waited < timeout:
        if (xbmc.getCondVisibility('System.HasLoggedIn')
                or xbmc.getCondVisibility('Window.IsActive(home)')):
            return True
        if monitor.waitForAbort(0.5):
            return False
        waited += 0.5
    return False


def _trigger_binary_updates():
    """Fordert Kodi erneut auf, Repositories und lokale Addons einzulesen."""
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.executebuiltin('UpdateLocalAddons')


def _verify_binary_repair(monitor, pending, timeout=BINARY_VERIFY_TIMEOUT):
    """Begleitet die Binary-Installation innerhalb derselben Kodi-Sitzung.

    Kodi arbeitet die Addon-Aktualisierung asynchron ab. BuildGuard wartet daher
    nach dem einzigen erforderlichen Neustart weiter und stößt die Aktualisierung
    in größeren Abständen erneut an, bis alle Platzhalter ersetzt wurden oder das
    Sicherheitszeitfenster abläuft.
    """
    waited = 0.0
    next_update_retry = BINARY_UPDATE_RETRY_INTERVAL
    installed = []
    unresolved = list(pending)
    missing = []
    while not monitor.abortRequested() and waited <= timeout:
        installed, unresolved, missing = binary_guard.verify_prepared_addons(pending)
        _log(_(32226).format(len(pending), len(installed), len(unresolved), len(missing)))
        if not unresolved and not missing:
            break

        if waited >= next_update_retry:
            try:
                _trigger_binary_updates()
                _log(_(32231).format(int(waited)))
            except Exception as exc:
                _log(_(32232).format(exc), xbmc.LOGWARNING)
            next_update_retry += BINARY_UPDATE_RETRY_INTERVAL

        if monitor.waitForAbort(BINARY_VERIFY_INTERVAL):
            break
        waited += BINARY_VERIFY_INTERVAL
    return installed, unresolved, missing


def _apply_pending_binary_repair(monitor):
    """Startet Updates und führt anschließend die Abschlusskontrolle aus."""
    state = binary_guard.read_pending_status()
    legacy_pending = setting('binary_repair_pending') == 'true'
    if not state.get('pending') and not legacy_pending:
        return False

    pending = state.get('addons') or [
        item for item in setting('binary_repair_addons').split(',') if item
    ]
    if not pending:
        binary_guard.clear_pending_status()
        addon.setSetting('binary_repair_pending', 'false')
        addon.setSetting('binary_repair_addons', '')
        return False

    attempts = int(state.get('attempts', 0) or 0) + 1
    binary_guard.write_pending_status(pending, phase='checking', attempts=attempts)
    _log(_(32210).format(len(pending)))

    if not _wait_for_gui(monitor):
        _log(_(32211), xbmc.LOGWARNING)
        return True

    try:
        from resources.lib.modules.buildbackup import enable_all_addons
        if not enable_all_addons():
            binary_guard.write_pending_status(pending, phase='retry', attempts=attempts)
            _log(_(32212), xbmc.LOGWARNING)
            return True

        _log(_(32213).format(len(pending)))
        installed, unresolved, missing = _verify_binary_repair(monitor, pending)

        if not unresolved and not missing:
            binary_guard.clear_pending_status()
            addon.setSetting('binary_repair_pending', 'false')
            addon.setSetting('binary_repair_addons', '')
            _log(_(32227).format(len(installed)))
            xbmc.executebuiltin('Notification({}, {}, 8000, {})'.format(
                addon.getAddonInfo('name'), _(32228).format(len(installed)), iconpath))
        else:
            remaining = unresolved + missing
            binary_guard.write_pending_status(remaining, phase='retry', attempts=attempts)
            addon.setSetting('binary_repair_pending', 'true')
            addon.setSetting('binary_repair_addons', ','.join(remaining))
            _log(_(32229).format(len(installed), len(unresolved), len(missing), ', '.join(remaining)), xbmc.LOGWARNING)
            xbmc.executebuiltin('Notification({}, {}, 10000, {})'.format(
                addon.getAddonInfo('name'), _(32233).format(len(remaining)), iconpath))
        return True
    except Exception as exc:
        binary_guard.write_pending_status(pending, phase='retry', attempts=attempts)
        _log(_(32215).format(exc), xbmc.LOGERROR)
        return True

def _apply_pending_skin_from_backup_restore(monitor):
    skin_id = skin_helper.read_and_clear_pending_skin()
    if not skin_id:
        return

    skin_helper.log('Ausstehender Skin-Wechsel nach Restore gefunden: {}'.format(skin_id))
    if _wait_for_gui(monitor):
        if not monitor.waitForAbort(3):
            skin_helper.activate_skin_live(skin_id)
    else:
        skin_helper.log('GUI nicht rechtzeitig bereit, Skin-Wechsel übersprungen.')


def _run_startup_maintenance(monitor):
    """Normale Startwartung; erst nach abgeschlossener Installationsphase."""
    notify_mode = setting('notify_mode') == 'true'
    auto_clean = setting('startup.cache') == 'true'
    filesize = _setting_int('filesize_alert', 500)
    filesize_thumb = _setting_int('filesizethumb_alert', 500)
    maxpackage_zips = _setting_int('packagenumbers_alert', 50)

    total_size, count = _folder_stats(packagesdir, monitor)
    total_mb = int(round(total_size / 1048576.0))
    if total_mb > filesize or count > maxpackage_zips:
        msg = _(32218).format(count, total_mb)
        if dialog.yesno(_(32219), msg, yeslabel=_(32220), nolabel=_(32221)):
            maintenance.purgePackages()

    total_size2, _thumb_count = _folder_stats(thumbnails, monitor)
    total_mb2 = int(round(total_size2 / 1048576.0))
    if total_mb2 > filesize_thumb:
        msg = _(32222).format(total_mb2)
        if dialog.yesno(_(32219), msg, yeslabel=_(32220), nolabel=_(32221)):
            maintenance.deleteThumbnails()

    if notify_mode:
        xbmc.executebuiltin('Notification({}, {}, 5000, {})'.format(
            addon.getAddonInfo('name'), _(32223).format(total_mb, total_mb2), iconpath))
    if not monitor.waitForAbort(3) and auto_clean:
        maintenance.clearCache()


class Monitor(xbmc.Monitor):

    def __init__(self):
        xbmc.Monitor.__init__(self)
        maintenance.logMaintenance('Monitor init')
        maintenance.determineNextMaintenance()
        cloud_status.refresh()

    def onSettingsChanged(self):
        maintenance.logMaintenance('onSettingsChanged')
        maintenance.determineNextMaintenance()
        cloud_status.refresh()


if __name__ == '__main__':
    monitor = Monitor()

    # Die Nachinstallation hat Vorrang. In derselben Sitzung werden bewusst
    # keine Paket-/Thumbnail-Dialoge geöffnet, damit Kodi die Repositories und
    # plattformspezifischen Binary-Pakete ungestört aktualisieren kann.
    installation_session = _apply_pending_binary_repair(monitor)
    _apply_pending_skin_from_backup_restore(monitor)
    if installation_session:
        _log(_(32216))
    else:
        _run_startup_maintenance(monitor)

    maintenance.logMaintenance('Service started')

    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
        maintenance.logMaintenance('monitor loop')
        if not xbmc.Player().isPlayingVideo():
            nextMaintenance = maintenance.getNextMaintenance()
            maintenance.logMaintenance('time.time() = %s, nextMaintenance = %s' % (
                str(time.time()), str(nextMaintenance)))
            if nextMaintenance > 0 and time.time() >= nextMaintenance:
                xbmc.log('buildguard: AutoClean started', level=loglevel)
                maintenance.clearCache()
                xbmc.log('buildguard: AutoClean done', level=loglevel)
                maintenance.determineNextMaintenance()

    del monitor
