# BuildGuard security and trust model

BuildGuard performs powerful operations: it can delete caches, overwrite Kodi files,
restore backups and install third-party builds. It is open-source, but open source does
not make an arbitrary build ZIP trustworthy.

## What BuildGuard checks

- ZIP integrity before extraction
- absolute paths and `..` path traversal
- symbolic links and duplicate archive paths
- suspicious file counts, extracted sizes and compression ratios
- HTTPS for network build downloads

## What BuildGuard cannot guarantee

- that third-party code is benign
- that a build is compatible with the current Kodi version or platform
- that an interrupted storage device or operating-system failure cannot damage data

Create a current backup before restore or build installation. Use only sources you
personally trust. Review logs after failures. BuildGuard is provided without warranty.

## Reporting a vulnerability

Do not publish secrets, tokens, personal paths or private build URLs in a public report.
Provide a minimal reproducible archive and the relevant Kodi log to the project maintainer.
