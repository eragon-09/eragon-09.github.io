# SPDX-License-Identifier: GPL-3.0-or-later
import sys
from resources.lib.modules import dropbox_auth

if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "test"
    dropbox_auth.run(action)
