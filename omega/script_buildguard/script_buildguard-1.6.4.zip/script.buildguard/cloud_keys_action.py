# SPDX-License-Identifier: GPL-3.0-or-later
"""Import/export BuildGuard cloud application credentials.

Only application credentials are handled here. OAuth access/refresh tokens and
account information are deliberately never exported.
"""
import os
import re
import sys

import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('script.buildguard')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
TEMPLATE_PATH = os.path.join(ADDON_PATH, 'resources', 'templates', 'buildguard-cloud-keys.txt')
EXPORT_NAME = 'buildguard-cloud-keys-PRIVATE.txt'
TEMPLATE_NAME = 'buildguard-cloud-keys-template.txt'
MAX_IMPORT_SIZE = 64 * 1024


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def _join_vfs(folder, filename):
    return folder.rstrip('/\\') + '/' + filename


def _read_text(path):
    handle = xbmcvfs.File(path, 'r')
    try:
        data = handle.read(MAX_IMPORT_SIZE + 1)
    finally:
        handle.close()
    if isinstance(data, bytes):
        data = data.decode('utf-8-sig', 'replace')
    if len(data) > MAX_IMPORT_SIZE:
        raise ValueError(_(32411))
    return data.lstrip('\ufeff')


def _write_text(path, text):
    handle = xbmcvfs.File(path, 'w')
    try:
        written = handle.write(text)
    finally:
        handle.close()
    if written is False:
        raise IOError('write failed')


def _safe_value(value):
    # Keep the format line based and prevent accidental section/key injection.
    return (value or '').replace('\r', '').replace('\n', '').strip()


def _build_export_text():
    return """############################################################
# BuildGuard Cloud Keys - PRIVATE
#
# WARNING / ACHTUNG:
# This file contains confidential application credentials.
# Diese Datei enthaelt vertrauliche App-Zugangsdaten.
# Never share it publicly. Niemals oeffentlich weitergeben.
#
# OAuth access tokens, refresh tokens, account names and
# BuildGuard share links are NEVER exported.
############################################################

[DROPBOX]
APP_KEY={dropbox_key}
APP_SECRET={dropbox_secret}

[GOOGLE_DRIVE]
CLIENT_ID={google_id}
CLIENT_SECRET={google_secret}
""".format(
        dropbox_key=_safe_value(ADDON.getSetting('dropbox_app_key')),
        dropbox_secret=_safe_value(ADDON.getSetting('dropbox_app_secret')),
        google_id=_safe_value(ADDON.getSetting('google_drive_client_id')),
        google_secret=_safe_value(ADDON.getSetting('google_drive_client_secret')),
    )


def _choose_folder(title):
    return xbmcgui.Dialog().browse(3, title, 'files')


def export_keys():
    warning = _(32399)
    if not xbmcgui.Dialog().yesno(_(32398), warning, yeslabel=_(32400), nolabel=_(32401)):
        return
    folder = _choose_folder(_(32402))
    if not folder:
        return
    path = _join_vfs(folder, EXPORT_NAME)
    if xbmcvfs.exists(path) and not xbmcgui.Dialog().yesno(_(32398), _(32403).format(EXPORT_NAME)):
        return
    try:
        _write_text(path, _build_export_text())
    except Exception:
        xbmcgui.Dialog().ok(_(32398), _(32404))
        return
    xbmcgui.Dialog().ok(_(32398), _(32405).format(path))


def save_template():
    folder = _choose_folder(_(32406))
    if not folder:
        return
    path = _join_vfs(folder, TEMPLATE_NAME)
    if xbmcvfs.exists(path) and not xbmcgui.Dialog().yesno(_(32407), _(32403).format(TEMPLATE_NAME)):
        return
    try:
        text = _read_text(TEMPLATE_PATH)
        _write_text(path, text)
    except Exception:
        xbmcgui.Dialog().ok(_(32407), _(32408))
        return
    xbmcgui.Dialog().ok(_(32407), _(32409).format(path))


def _parse(text):
    section = None
    values = {'DROPBOX': {}, 'GOOGLE_DRIVE': {}}
    valid_keys = {
        'DROPBOX': {'APP_KEY', 'APP_SECRET'},
        'GOOGLE_DRIVE': {'CLIENT_ID', 'CLIENT_SECRET'},
    }
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith(('#', ';')):
            continue
        match = re.match(r'^\[([A-Za-z0-9_]+)\]$', line)
        if match:
            section = match.group(1).upper()
            continue
        if '=' not in line or section not in valid_keys:
            continue
        key, value = line.split('=', 1)
        key = key.strip().upper()
        value = value.strip()
        if key in valid_keys[section] and value:
            values[section][key] = value
    return values


def import_keys():
    chosen = xbmcgui.Dialog().browse(1, _(32410), 'files', '.txt')
    if not chosen:
        return
    try:
        values = _parse(_read_text(chosen))
    except Exception as exc:
        message = str(exc) or _(32412)
        xbmcgui.Dialog().ok(_(32397), message)
        return

    found = []
    if values['DROPBOX']:
        found.append('Dropbox')
    if values['GOOGLE_DRIVE']:
        found.append('Google Drive')
    if not found:
        xbmcgui.Dialog().ok(_(32397), _(32413))
        return

    summary = '\n'.join('[B]✓ {}[/B]'.format(name) for name in found)
    if not xbmcgui.Dialog().yesno(_(32397), _(32414).format(summary), yeslabel=_(32415), nolabel=_(32401)):
        return

    # Apply only after the complete file has been read and parsed successfully.
    mapping = (
        ('DROPBOX', 'APP_KEY', 'dropbox_app_key'),
        ('DROPBOX', 'APP_SECRET', 'dropbox_app_secret'),
        ('GOOGLE_DRIVE', 'CLIENT_ID', 'google_drive_client_id'),
        ('GOOGLE_DRIVE', 'CLIENT_SECRET', 'google_drive_client_secret'),
    )
    changed = 0
    for section_name, key_name, setting_id in mapping:
        if key_name in values[section_name]:
            ADDON.setSetting(setting_id, values[section_name][key_name])
            changed += 1

    xbmcgui.Dialog().ok(_(32397), _(32416).format(changed))


def main():
    action = sys.argv[1] if len(sys.argv) > 1 else ''
    if action == 'export':
        export_keys()
    elif action == 'import':
        import_keys()
    elif action == 'template':
        save_template()


if __name__ == '__main__':
    main()
