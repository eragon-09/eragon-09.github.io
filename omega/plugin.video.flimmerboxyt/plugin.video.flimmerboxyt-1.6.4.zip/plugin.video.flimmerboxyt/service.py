"""Loopback-only DASH manifest server for FlimmerBoxYT."""
import os
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
import xbmc
import xbmcvfs

DATA = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.flimmerboxyt/')
MPD = os.path.join(DATA, 'mpd')
PORT_FILE = os.path.join(DATA, 'httpd_port.txt')

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/health':
            data = b'FlimmerBoxYT-2.0.0'
            content_type = 'text/plain'
        elif re.fullmatch(r'/mpd/flimmerboxyt_[a-f0-9]{10}\.mpd', path):
            name = path.rsplit('/', 1)[-1]
            filename = os.path.join(MPD, name)
            try:
                with open(filename, 'rb') as stream:
                    data = stream.read()
            except OSError:
                self.send_error(404)
                return
            content_type = 'application/dash+xml'
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format, *args):
        pass


def main():
    os.makedirs(MPD, exist_ok=True)
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    server.daemon_threads = True
    port = server.server_address[1]
    temp = PORT_FILE + '.tmp'
    with open(temp, 'w', encoding='utf-8') as stream:
        stream.write(str(port))
    os.replace(temp, PORT_FILE)
    thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.2}, daemon=True)
    thread.start()
    xbmc.log('FlimmerBoxYT 2.0.0: MPD HTTP server auf 127.0.0.1:%d' % port, xbmc.LOGINFO)
    try:
        xbmc.Monitor().waitForAbort()
    finally:
        server.shutdown()
        server.server_close()
        try:
            with open(PORT_FILE, encoding='utf-8') as stream:
                if stream.read().strip() == str(port):
                    os.unlink(PORT_FILE)
        except OSError:
            pass

if __name__ == '__main__':
    main()
