"""Kodi-Ansichtsdaten fuer YouTube-Listen; keine Netzwerkanfragen."""
import re

_BAD = re.compile(r'[\U0001F000-\U0010FFFF\u200d\ufe0e\ufe0f\u2600-\u27bf]')
_YEAR = re.compile(r'(?<!\d)(?:19[2-9]\d|20[0-3]\d)(?!\d)')
_SEPARATOR = re.compile(r'\s*(?:\||\u2502)\s*')


def _clean(text):
    text = _BAD.sub('', str(text or ''))
    return ' '.join(text.split()).strip(' -|:')


def display_metadata(video, genre_id):
    """Kurze Anzeige, waehrend die vollstaendige YouTube-Beschreibung erhalten bleibt."""
    raw = _clean(video.get('title', '')) or 'Ohne Titel'
    desc = _clean(video.get('description', ''))
    channel = _clean(video.get('channel', ''))
    film = genre_id == 'filme'
    year = None
    if film:
        match = _YEAR.search(raw)
        if match:
            year = int(match.group())
        # Nur eindeutig abgetrennte Werbezusaetze entfernen, nie Filmtitel erraten.
        parts = _SEPARATOR.split(raw)
        candidate = parts[0].strip()
        if len(parts) > 1 and len(candidate) >= 3:
            raw = candidate
        raw = re.sub(r'\s*\((?:Deutsch|German|HD|4K)\)\s*$', '', raw, flags=re.I).strip()
    label = raw
    if film and year and not _YEAR.search(raw):
        label += ' (%d)' % year
    if not film and len(label) > 105:
        label = label[:102].rstrip() + '...'
    info = []
    if channel:
        info.append('Kanal: ' + channel)
    if film and year:
        info.append('Filmjahr laut Videotitel: %d' % year)
    if video.get('published'):
        info.append('Veroeffentlicht: ' + str(video['published'])[:10])
    if desc:
        info.append(desc)
    elif not info:
        info.append('Keine weiteren Informationen vorhanden.')
    return label, '\n'.join(info), year
