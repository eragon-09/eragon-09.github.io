"""Standalone YouTube playback for Kodi 21 Omega (Windows / Android).

Uses the existing bundled yt-dlp for extraction, with a DASH SegmentBase
manifest for compatible ranged formats. No external binaries or YouTube addon.
"""
import os
import re
import time
from xml.sax.saxutils import escape, quoteattr

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HEIGHTS = {0: 2160, 1: 2160, 2: 1440, 3: 1080, 4: 720, 5: 480, 6: 360}


def _setting(name, default=0):
    try:
        return int(ADDON.getSetting(name))
    except (TypeError, ValueError):
        return default


def _enabled(name, default=True):
    value = ADDON.getSetting(name)
    return default if not value else value.lower() == 'true'


def _fmt_url(f):
    url = f.get('url', '')
    return url if url.startswith('https://') else ''


def _range(f, name):
    value = f.get(name)
    if isinstance(value, dict):
        try:
            a, b = int(value['start']), int(value['end'])
            return (a, b) if 0 <= a <= b else None
        except (ValueError, TypeError, KeyError):
            return None
    return None


def _dash_capable(f):
    return bool(_fmt_url(f) and _range(f, 'initRange') and _range(f, 'indexRange')
                and f.get('protocol') in ('https', 'http', None))


def _codec(f, audio=False):
    c = str(f.get('acodec' if audio else 'vcodec') or '')
    return c if c not in ('none', '') else None


def _representation(f, audio=False):
    codec = _codec(f, audio)
    if not codec:
        return ''
    init = _range(f, 'initRange')
    index = _range(f, 'indexRange')
    attrs = {'id': str(f.get('format_id') or 'stream'),
             'bandwidth': str(max(1000, int(float(f.get('tbr') or f.get('abr') or 100) * 1000))),
             'codecs': codec}
    if audio:
        attrs['audioSamplingRate'] = str(int(f.get('asr') or 44100))
    else:
        attrs.update(width=str(int(f.get('width') or 1280)),
                     height=str(int(f.get('height') or 720)))
        if f.get('fps'):
            attrs['frameRate'] = str(int(f['fps']))
    attrtext = ' '.join('%s=%s' % (k, quoteattr(v)) for k, v in attrs.items())
    lines = ['<Representation %s>' % attrtext]
    if audio:
        lines.append('<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="%s"/>' % int(f.get('audio_channels') or 2))
    lines.extend(['<BaseURL>%s</BaseURL>' % escape(_fmt_url(f)),
                  '<SegmentBase indexRange="%d-%d"><Initialization range="%d-%d"/></SegmentBase>' % (index[0], index[1], init[0], init[1]),
                  '</Representation>'])
    return '\n'.join(lines)


def _mpd(video, audio, duration):
    duration = max(1, float(duration or 1))
    def adaptation(f, is_audio):
        ext = f.get('ext')
        mime = ('audio/' if is_audio else 'video/') + ('webm' if ext == 'webm' else 'mp4')
        return '<AdaptationSet mimeType=%s contentType=%s segmentAlignment="true" startWithSAP="1">%s</AdaptationSet>' % (
            quoteattr(mime), quoteattr('audio' if is_audio else 'video'), _representation(f, is_audio))
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" '
            'mediaPresentationDuration="PT%.3fS" minBufferTime="PT2S" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011">'
            '<Period>%s%s</Period></MPD>' % (duration, adaptation(video, False), adaptation(audio, True)))


def _select(formats, limit, mode, safe):
    formats = [f for f in formats if isinstance(f, dict) and _fmt_url(f)]
    video = [f for f in formats if f.get('vcodec') not in ('none', None) and
             f.get('acodec') == 'none' and int(f.get('height') or 0) <= limit and _dash_capable(f)]
    audio = [f for f in formats if f.get('acodec') not in ('none', None) and
             f.get('vcodec') == 'none' and _dash_capable(f)]
    if safe or mode == 3:
        video = [f for f in video if str(f.get('vcodec', '')).startswith(('avc1', 'h264'))]
        audio = [f for f in audio if str(f.get('acodec', '')).startswith(('mp4a', 'aac'))]
    if mode == 1:
        audio.sort(key=lambda f: (str(f.get('acodec', '')).startswith(('mp4a', 'aac')), float(f.get('abr') or f.get('tbr') or 0)), reverse=True)
    elif mode == 2:
        audio.sort(key=lambda f: ('opus' in str(f.get('acodec', '')), float(f.get('abr') or f.get('tbr') or 0)), reverse=True)
    else:
        audio.sort(key=lambda f: float(f.get('abr') or f.get('tbr') or 0), reverse=True)
    video.sort(key=lambda f: (int(f.get('height') or 0), float(f.get('fps') or 0), float(f.get('tbr') or 0)), reverse=True)
    # Only pair same container family: Kodi/ISA may not accept mixed adaptation sets.
    for v in video:
        a = next((a for a in audio if a.get('ext') == v.get('ext')), None)
        if a:
            return v, a
    return None, None


def _progressive(formats, limit, safe):
    choices = [f for f in formats if isinstance(f, dict) and _fmt_url(f) and
               f.get('vcodec') not in (None, 'none') and f.get('acodec') not in (None, 'none')
               and int(f.get('height') or 0) <= limit and f.get('protocol') in ('https', 'http', None)]
    if safe:
        choices = [f for f in choices if f.get('ext') == 'mp4']
    return max(choices, key=lambda f: (int(f.get('height') or 0), float(f.get('tbr') or 0)), default=None)


def _manifest_file(content):
    directory = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.flimmerboxyt/manifests/')
    os.makedirs(directory, exist_ok=True)
    # Old manifests contain expiring URLs: never reuse them.
    for filename in os.listdir(directory):
        path = os.path.join(directory, filename)
        try:
            if filename.endswith('.mpd') and time.time() - os.path.getmtime(path) > 86400:
                os.unlink(path)
        except OSError:
            pass
    path = os.path.join(directory, 'stream_%d.mpd' % int(time.time() * 1000000))
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(content)
    return path


def _isa_available():
    """Check actual installation rather than a possibly false skin condition."""
    try:
        addon = xbmcaddon.Addon('inputstream.adaptive')
        xbmc.log('FlimmerBoxYT: InputStream Adaptive erkannt: %s' % addon.getAddonInfo('version'), xbmc.LOGINFO)
        return True
    except Exception as exc:
        xbmc.log('FlimmerBoxYT: InputStream Adaptive fehlt: %s' % exc, xbmc.LOGWARNING)
        return False


def _native_play(handle, youtube_id, title, limit, mode, safe):
    """Resolve through the bundled, standalone FlimmerBoxYT native YouTube client."""
    from resources.lib.mt_resolver import youtube as yt, dash
    response = yt.get_player_response(youtube_id, desired_height=limit)
    if not response:
        raise RuntimeError('Alle nativen YouTube-Clients ohne verwertbare Antwort')
    sd = response.get('streamingData') or {}
    adaptive = list(sd.get('adaptiveFormats') or [])
    progressive = list(sd.get('formats') or [])
    status = (response.get('playabilityStatus') or {}).get('status', 'unbekannt')
    xbmc.log('FlimmerBoxYT: Native Antwort status=%s, adaptive=%d, progressive=%d, hls=%s' %
             (status, len(adaptive), len(progressive), bool(sd.get('hlsManifestUrl'))), xbmc.LOGINFO)
    # Keep VP9 available when YouTube only supplies H.264 up to 360p.
    # Native DASH builder can include AV1 when the device supports decoding.
    if safe:
        adaptive = [f for f in adaptive if
                    ('video/' not in f.get('mimeType', '') or
                     'avc1' in f.get('mimeType', '') or 'vp9' in f.get('mimeType', '')) and
                    ('audio/' not in f.get('mimeType', '') or
                     'mp4a' in f.get('mimeType', '') or 'opus' in f.get('mimeType', ''))]
    video_summary = sorted({(f.get('itag'), f.get('height'),
                            (f.get('mimeType') or '').split(';')[0])
                           for f in adaptive if 'video/' in f.get('mimeType', '')},
                           key=lambda v: (int(v[1] or 0), str(v[0])))
    xbmc.log('FlimmerBoxYT: Verfuegbare Videospuren %s' % (video_summary,), xbmc.LOGINFO)
    if mode in (1, 2):
        preference = 'mp4a' if mode == 1 else 'opus'
        preferred = [f for f in adaptive if 'audio/' in f.get('mimeType', '') and preference in f.get('mimeType', '')]
        if preferred:
            adaptive = [f for f in adaptive if 'audio/' not in f.get('mimeType', '')] + preferred
    # If native clients only expose lower resolutions, try bundled yt-dlp
    # BEFORE committing a 1080p resolved URL. A failed quality upgrade must
    # leave native playback intact.
    native_height = max((int(f.get('height') or 0) for f in adaptive
                         if f.get('url') and f.get('initRange') and f.get('indexRange')
                         and (f.get('mimeType') or '').startswith('video/')),
                        default=0)
    if limit > native_height and _enabled('stream_fallback'):
        xbmc.log('FlimmerBoxYT: Native DASH max=%dp, Ziel=%dp; yt-dlp Qualitaetsupgrade' %
                 (native_height, limit), xbmc.LOGINFO)
        try:
            _ytdlp_play(handle, youtube_id, title, limit, mode, safe,
                        min_height=native_height)
            return True
        except Exception as upgrade_exc:
            xbmc.log('FlimmerBoxYT: yt-dlp Qualitaetsupgrade nicht verfuegbar: %s' %
                     upgrade_exc, xbmc.LOGWARNING)
    details = response.get('videoDetails') or {}
    try:
        duration = float(details.get('lengthSeconds') or 0)
    except (TypeError, ValueError):
        duration = 0
    li = xbmcgui.ListItem(label=title or details.get('title') or youtube_id)
    li.setProperty('IsPlayable', 'true')
    isa = _isa_available()
    xbmc.log('FlimmerBoxYT: DASH-Voraussetzungen adaptive=%d duration=%.1f isa=%s' % (len(adaptive), duration, isa), xbmc.LOGINFO)
    if adaptive and isa:
        if duration <= 0:
            duration = float(sd.get('approxDurationMs') or 0) / 1000.0
            xbmc.log('FlimmerBoxYT: DASH Dauer-Fallback %.1fs' % duration, xbmc.LOGINFO)
        if duration <= 0:
            xbmc.log('FlimmerBoxYT: DASH ohne Videodauer nicht moeglich', xbmc.LOGWARNING)
    if adaptive and isa and duration > 0:
        xbmc.log('FlimmerBoxYT: DASH-Generierung gestartet', xbmc.LOGINFO)
        path = dash.write_mpd(adaptive, duration, max_height=limit)
        if path:
            li.setPath(path)
            li.setMimeType('application/dash+xml')
            li.setContentLookup(False)
            li.setProperty('inputstream', 'inputstream.adaptive')
            xbmc.log('FlimmerBoxYT: Native DASH: %s' % path.split('?')[0], xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(handle, True, li)
            return True
        xbmc.log('FlimmerBoxYT: Native DASH: kein gueltiges MPD (Ranges, Audio oder Server pruefen)', xbmc.LOGWARNING)
    elif not isa:
        xbmcgui.Dialog().notification('FlimmerBoxYT', 'InputStream Adaptive installieren/aktivieren fuer HD', xbmcgui.NOTIFICATION_WARNING, 6000)
    if _enabled('stream_fallback'):
        choices = [f for f in progressive if f.get('url') and
                   (not f.get('height') or int(f['height']) <= limit) and
                   (not safe or 'mp4' in f.get('mimeType', ''))]
        if choices:
            choices.sort(key=lambda f: (int(f.get('height') or 0), int(f.get('bitrate') or 0)), reverse=True)
            li.setPath(choices[0]['url'])
            xbmc.log('FlimmerBoxYT: Native Progressive itag=%s' % choices[0].get('itag'), xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(handle, True, li)
            return True
        hls = sd.get('hlsManifestUrl')
        if hls:
            li.setPath(hls)
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setContentLookup(False)
            xbmc.log('FlimmerBoxYT: Native HLS', xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(handle, True, li)
            return True
    raise RuntimeError('Keine abspielbaren nativen Streams (adaptive=%d, progressive=%d)' %
                       (len(adaptive), len(progressive)))



def _ytdlp_play(handle, youtube_id, title, limit, mode, safe, min_height=0):
    """Independent last-resort extraction from the already bundled yt-dlp.

    Prefer progressive formats, then a ranged DASH manifest when ISA is available.
    No dependency on plugin.video.youtube or external executables.
    """
    from resources.lib import api
    ydl_class = getattr(api, 'YoutubeDL', None)
    if ydl_class is None:
        raise RuntimeError('Integriertes yt-dlp nicht verfuegbar')
    options = {'quiet': True, 'no_warnings': True, 'skip_download': True,
               'noplaylist': True, 'extract_flat': False, 'socket_timeout': 15,
               'retries': 1, 'format': 'bestvideo*+bestaudio/best'}
    with ydl_class(options) as ydl:
        info = ydl.extract_info('https://www.youtube.com/watch?v=' + youtube_id, download=False)
    if not isinstance(info, dict):
        raise RuntimeError('yt-dlp hat keine Video-Metadaten geliefert')
    formats = [f for f in (info.get('formats') or []) if
               int(f.get('height') or 0) > min_height or
               f.get('vcodec') == 'none']
    xbmc.log('FlimmerBoxYT: yt-dlp Kandidaten oberhalb %dp: %s' %
             (min_height, sorted({int(f.get('height') or 0) for f in formats
                                  if int(f.get('height') or 0) > min_height})), xbmc.LOGINFO)
    li = xbmcgui.ListItem(label=title or info.get('title') or youtube_id)
    li.setProperty('IsPlayable', 'true')
    # Ranged DASH is preferred for 4K, if the extractor supplies SegmentBase metadata.
    if _isa_available():
        video, audio = _select(formats, limit, mode, safe)
        if video and audio and float(info.get('duration') or 0) > 0:
            path = _manifest_file(_mpd(video, audio, info['duration']))
            # The native service exposes only its own mpd directory; use a local
            # file URL for this fallback manifest instead of a broken HTTP URL.
            from resources.lib.mt_resolver.dash import _path_to_file_url
            li.setPath(_path_to_file_url(path))
            li.setMimeType('application/dash+xml')
            li.setContentLookup(False)
            li.setProperty('inputstream', 'inputstream.adaptive')
            xbmcplugin.setResolvedUrl(handle, True, li)
            return True
    if _enabled('stream_fallback'):
        choice = _progressive(formats, limit, safe)
        if choice:
            li.setPath(_fmt_url(choice))
            xbmc.log('FlimmerBoxYT: yt-dlp Progressive %sp' % choice.get('height'), xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(handle, True, li)
            return True
    raise RuntimeError('yt-dlp hat keinen kompatiblen Stream geliefert')

def play(handle, youtube_id, title=''):
    if not re.fullmatch(r'[A-Za-z0-9_-]{11}', str(youtube_id or '')):
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    try:
        limit = HEIGHTS.get(_setting('video_quality'), 1080)
        mode = _setting('audio_mode', 1)
        safe = _enabled('safe_playback', False) or mode == 3
        # Compatibility changes codec preference, not the user's resolution ceiling.
        xbmc.log('FlimmerBoxYT 1.6.4: Nativer Resolver, ID=%s, max=%dp, safe=%s' %
                 (youtube_id, limit, safe), xbmc.LOGINFO)
        _native_play(handle, youtube_id, title, limit, mode, safe)
    except Exception as exc:
        xbmc.log('FlimmerBoxYT: Native Streamaufloesung fehlgeschlagen: %s' % exc, xbmc.LOGWARNING)
        if _enabled('stream_fallback'):
            try:
                _ytdlp_play(handle, youtube_id, title, limit, mode, safe)
                return
            except Exception as fallback_exc:
                xbmc.log('FlimmerBoxYT: yt-dlp Fallback fehlgeschlagen: %s' % fallback_exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('FlimmerBoxYT', 'Kein YouTube-Stream. Kodi-Log pruefen.', xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
