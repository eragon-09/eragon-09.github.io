import os
import tempfile
import time
import uuid
import re
from urllib.parse import quote as _url_quote
from urllib.request import pathname2url as _pathname2url, urlopen
try:
    import xbmc
    import xbmcvfs
    _HAS_KODI = True
except ImportError:
    _HAS_KODI = False
    xbmc = None
    xbmcvfs = None
_HTTPD_DATA_SUBDIR = "special://profile/addon_data/plugin.video.flimmerboxyt/"
_HTTPD_PORT_FILE = _HTTPD_DATA_SUBDIR + "httpd_port.txt"
_HTTPD_MPD_SUBDIR = _HTTPD_DATA_SUBDIR + "mpd/"

def _read_httpd_port():
    if not _HAS_KODI:
        return None
    try:
        path = xbmcvfs.translatePath(_HTTPD_PORT_FILE)
        if not os.path.isfile(path):
            return None
        with open(path, "r", encoding="utf-8") as fh:
            raw = fh.read().strip()
        port = int(raw)
        if 1024 <= port <= 65535:
            return port
    except (OSError, ValueError):
        pass
    return None
_ADAPTIVE_ITAGS = {
    133: (240,  "240p",   "mp4",  "avc1",  30, False),
    134: (360,  "360p",   "mp4",  "avc1",  30, False),
    135: (480,  "480p",   "mp4",  "avc1",  30, False),
    136: (720,  "720p",   "mp4",  "avc1",  30, False),
    137: (1080, "1080p",  "mp4",  "avc1",  30, False),
    264: (1440, "1440p",  "mp4",  "avc1",  30, False),
    266: (2160, "4K",     "mp4",  "avc1",  30, False),
    298: (720,  "720p60", "mp4",  "avc1",  60, False),
    299: (1080, "1080p60","mp4",  "avc1",  60, False),
    304: (1440, "1440p60","mp4",  "avc1",  60, False),
    305: (2160, "4K60",   "mp4",  "avc1",  60, False),
    242: (240,  "240p",   "webm", "vp9",   30, False),
    243: (360,  "360p",   "webm", "vp9",   30, False),
    244: (480,  "480p",   "webm", "vp9",   30, False),
    247: (720,  "720p",   "webm", "vp9",   30, False),
    248: (1080, "1080p",  "webm", "vp9",   30, False),
    271: (1440, "1440p",  "webm", "vp9",   30, False),
    313: (2160, "4K",     "webm", "vp9",   30, False),
    302: (720,  "720p60", "webm", "vp9",   60, False),
    303: (1080, "1080p60","webm", "vp9",   60, False),
    308: (1440, "1440p60","webm", "vp9",   60, False),
    315: (2160, "4K60",   "webm", "vp9",   60, False),
    394: (144,  "144p",   "mp4",  "av01",  30, False),
    395: (240,  "240p",   "mp4",  "av01",  30, False),
    396: (360,  "360p",   "mp4",  "av01",  30, False),
    397: (480,  "480p",   "mp4",  "av01",  30, False),
    398: (720,  "720p",   "mp4",  "av01",  30, False),
    399: (1080, "1080p",  "mp4",  "av01",  30, False),
    400: (1440, "1440p",  "mp4",  "av01",  30, False),
    401: (2160, "4K",     "mp4",  "av01",  30, False),
    139: (None, "48kbps",  "mp4",  "mp4a",  0, True),
    140: (None, "128kbps", "mp4",  "mp4a",  0, True),
    141: (None, "256kbps", "mp4",  "mp4a",  0, True),
    249: (None, "50kbps",  "webm", "opus",  0, True),
    250: (None, "70kbps",  "webm", "opus",  0, True),
    251: (None, "160kbps", "webm", "opus",  0, True),
    256: (None, "aac-5.1", "mp4",  "mp4a",  0, True),
    258: (None, "aac-5.1", "mp4",  "mp4a",  0, True),
}
_VIDEO_MIME = {"mp4": "video/mp4", "webm": "video/webm"}
_AUDIO_MIME = {"mp4": "audio/mp4", "webm": "audio/webm"}

def _codecs_from_mime(mime_type):
    if not mime_type:
        return None
    m = re.search(r'codecs="([^"]+)"', mime_type)
    return m.group(1) if m else None

def _iso_duration(seconds):
    try:
        s = float(seconds)
    except (TypeError, ValueError):
        return "PT0S"
    if s <= 0:
        return "PT0S"
    h = int(s // 3600)
    m = int((s % 3600) // 60)
    sec = s - (h * 3600) - (m * 60)
    parts = ["PT"]
    if h:
        parts.append("{}H".format(h))
    if m:
        parts.append("{}M".format(m))
    parts.append("{:.3f}S".format(sec))
    return "".join(parts)

def _xml_escape(v):
    if v is None:
        return ""
    return str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def _represent_stream(fmt, is_audio=False):
    itag = fmt.get("itag")
    url = fmt.get("url")
    if not url:
        return None
    meta = _ADAPTIVE_ITAGS.get(itag)
    mime = fmt.get("mimeType", "") or ""
    codecs = _codecs_from_mime(mime) or (meta[3] if meta else None)
    bitrate = fmt.get("bitrate") or fmt.get("averageBitrate") or 0
    init_range = fmt.get("initRange") or {}
    index_range = fmt.get("indexRange") or {}
    init_start = init_range.get("start")
    init_end = init_range.get("end")
    idx_start = index_range.get("start")
    idx_end = index_range.get("end")
    if None in (init_start, init_end, idx_start, idx_end):
        return None
    lines = []
    attrs = [
        'id="{}"'.format(itag),
        'bandwidth="{}"'.format(int(bitrate) or 100000),
    ]
    if codecs:
        attrs.append('codecs="{}"'.format(_xml_escape(codecs)))
    if is_audio:
        sr = fmt.get("audioSampleRate") or 44100
        attrs.append('audioSamplingRate="{}"'.format(sr))
    else:
        if fmt.get("width"):
            attrs.append('width="{}"'.format(fmt["width"]))
        if fmt.get("height"):
            attrs.append('height="{}"'.format(fmt["height"]))
        if fmt.get("fps"):
            attrs.append('frameRate="{}"'.format(fmt["fps"]))
    lines.append("      <Representation {}>".format(" ".join(attrs)))
    if is_audio:
        ch = fmt.get("audioChannels") or 2
        lines.append(
            '        <AudioChannelConfiguration '
            'schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" '
            'value="{}"/>'.format(ch)
        )
    lines.append("        <BaseURL>{}</BaseURL>".format(_xml_escape(url)))
    lines.append(
        '        <SegmentBase indexRange="{}-{}" indexRangeExact="true">'.format(
            idx_start, idx_end)
    )
    lines.append(
        '          <Initialization range="{}-{}"/>'.format(init_start, init_end)
    )
    lines.append("        </SegmentBase>")
    lines.append("      </Representation>")
    return "\n".join(lines)

def _group_by_container(formats, is_audio):
    out = {"mp4": [], "webm": []}
    for f in formats:
        meta = _ADAPTIVE_ITAGS.get(f.get("itag"))
        if not meta:
            continue
        if meta[5] != is_audio:
            continue
        container = meta[2]
        out.setdefault(container, []).append(f)
    return out

def _audio_language(fmt):
    """Read YouTube's track language, falling back to the track ID."""
    track = fmt.get("audioTrack") or {}
    track_id = str(track.get("id") or "")
    raw = str(track.get("languageCode") or fmt.get("languageCode") or "").strip()
    if not raw and track_id:
        raw = track_id.split(".", 1)[0]
    raw = raw.replace("_", "-").lower()
    if re.match(r"^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$", raw):
        return raw
    return "und"


def _is_original_audio(fmt):
    track = fmt.get("audioTrack") or {}
    track_id = str(track.get("id") or "").lower()
    name = track.get("displayName") or ""
    if isinstance(name, dict):
        name = " ".join(r.get("text", "") for r in name.get("runs", []) if isinstance(r, dict))
    name = str(name).lower()
    # YouTube uses ".original" in track IDs for the source recording.
    return (".original" in track_id or track_id.endswith("original") or
            "original" in name or "originalton" in name or
            bool(track.get("isOriginal")))


def _choose_audio(formats):
    """Prefer a marked original; otherwise German, then default/first track.

    Restrict to one language/track to avoid Kodi choosing a dubbed version.
    When metadata is absent, preserve the old audio selection behavior.
    """
    audios = [f for f in formats if (f.get("mimeType") or "").startswith("audio/")]
    if not audios:
        return formats
    with_tracks = [f for f in audios if f.get("audioTrack")]
    if not with_tracks:
        return formats
    original = [f for f in audios if _is_original_audio(f)]
    german = [f for f in audios if _audio_language(f).split("-")[0] == "de"]
    default = [f for f in audios if (f.get("audioTrack") or {}).get("audioIsDefault")]
    pool = original or german or default or audios
    # Different codecs/bitrates may represent the same language track.
    preferred = pool[0]
    preferred_track = (preferred.get("audioTrack") or {}).get("id")
    preferred_lang = _audio_language(preferred)
    if preferred_track:
        selected = [f for f in pool if (f.get("audioTrack") or {}).get("id") == preferred_track]
    elif preferred_lang != "und":
        selected = [f for f in pool if _audio_language(f) == preferred_lang]
    else:
        selected = pool
    if _HAS_KODI:
        xbmc.log('FlimmerBoxYT Audio: original=%d deutsch=%d ausgewaehlt=%s track=%s formate=%d' % (
            len(original), len(german), preferred_lang, preferred_track or '-', len(selected)), xbmc.LOGINFO)
    return [f for f in formats if not (f.get("mimeType") or "").startswith("audio/")] + selected


def build_mpd(adaptive_formats, duration_seconds, max_height=None):
    """Expose every supported video rendition as a codec-specific adaptation set."""
    if not adaptive_formats:
        return None
    adaptive_formats = _choose_audio(adaptive_formats)
    video_groups = {"mp4": [], "webm": []}
    audio_groups = {"mp4": [], "webm": []}
    for f in adaptive_formats:
        meta = _ADAPTIVE_ITAGS.get(f.get("itag"))
        if not meta or not f.get("url"):
            continue
        height, _, container, codec, _, is_audio = meta
        if not is_audio and max_height and height and height > max_height:
            continue
        # AV1 is included in automatic selection; Kodi/ISA decides which
        # representations the actual device can decode.
        if not is_audio and codec not in ("avc1", "vp9", "av01"):
            continue
        rep = _represent_stream(f, is_audio=is_audio)
        if rep:
            (audio_groups if is_audio else video_groups)[container].append((f, rep))
    if not any(video_groups.values()) or not any(audio_groups.values()):
        return None
    duration = _iso_duration(duration_seconds)
    xml = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011"',
        '     profiles="urn:mpeg:dash:profile:isoff-on-demand:2011"',
        '     type="static"',
        '     mediaPresentationDuration="{}"'.format(duration),
        '     minBufferTime="PT2S">',
        '  <Period duration="{}">'.format(duration),
    ]
    for container in ("mp4", "webm"):
        reps = video_groups[container]
        if not reps:
            continue
        xml.append('    <AdaptationSet contentType="video" mimeType="{}" segmentAlignment="true" startWithSAP="1">'.format(_VIDEO_MIME[container]))
        for f, rep in sorted(reps, key=lambda pair: (pair[0].get("height") or 0, pair[0].get("bitrate") or 0)):
            xml.append(rep)
        xml.append('    </AdaptationSet>')
    for container in ("mp4", "webm"):
        reps = audio_groups[container]
        if not reps:
            continue
        lang = _audio_language(reps[0][0])
        xml.append('    <AdaptationSet contentType="audio" mimeType="{}" segmentAlignment="true" startWithSAP="1" lang="{}">'.format(_AUDIO_MIME[container], lang))
        for f, rep in sorted(reps, key=lambda pair: pair[0].get("bitrate") or 0):
            xml.append(rep)
        xml.append('    </AdaptationSet>')
    xml.extend(['  </Period>', '</MPD>'])
    if _HAS_KODI:
        heights = sorted({int(f.get("height") or 0) for group in video_groups.values() for f, _ in group})
        xbmc.log('FlimmerBoxYT DASH: H264=%d VP9=%d AAC=%d Opus=%d Hoehen=%s' % (
            len(video_groups["mp4"]), len(video_groups["webm"]),
            len(audio_groups["mp4"]), len(audio_groups["webm"]), heights), xbmc.LOGINFO)
    return "\n".join(xml)

def _temp_dir():
    if _HAS_KODI:
        try:
            p = xbmcvfs.translatePath(_HTTPD_MPD_SUBDIR)
            if p:
                if not os.path.exists(p):
                    os.makedirs(p)
                return p
        except OSError:
            pass
        try:
            p = xbmcvfs.translatePath("special://temp/")
            if p:
                wt = os.path.join(p, "flimmerboxyt")
                if not os.path.exists(wt):
                    os.makedirs(wt)
                return wt
        except OSError:
            pass
    return tempfile.gettempdir()

def _cleanup_old(folder, max_age_sec=3600):
    try:
        now = time.time()
        for name in os.listdir(folder):
            if not name.startswith("flimmerboxyt_") or not name.endswith(".mpd"):
                continue
            full = os.path.join(folder, name)
            try:
                if now - os.path.getmtime(full) > max_age_sec:
                    os.remove(full)
            except OSError:
                pass
    except OSError:
        pass

def _path_to_file_url(path):
    # Windows Kodi: pathname2url may yield ///C:/..., producing invalid
    # file://///C:/... when blindly prefixed with file://.
    # Canonical Windows file URI has exactly three slashes: file:///C:/...
    normalized = os.path.abspath(path).replace("\\", "/")
    if len(normalized) >= 2 and normalized[1] == ":":
        return "file:///" + _url_quote(normalized, safe="/:")
    if normalized.startswith("//"):
        return "file:" + _url_quote(normalized, safe="/:")
    return "file://" + _url_quote(normalized, safe="/:")

def write_mpd(adaptive_formats, duration_seconds, max_height=None):
    xml = build_mpd(adaptive_formats, duration_seconds, max_height=max_height)
    if not xml:
        return None
    folder = _temp_dir()
    _cleanup_old(folder)
    name = "flimmerboxyt_{}.mpd".format(uuid.uuid4().hex[:10])
    full = os.path.join(folder, name)
    try:
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(xml)
    except OSError:
        return None
    port = _read_httpd_port()
    if port is not None:
        try:
            with urlopen('http://127.0.0.1:{}/health'.format(port), timeout=2) as response:
                if response.read(64) == b'FlimmerBoxYT-2.0.0':
                    return 'http://127.0.0.1:{}/mpd/{}'.format(port, name)
        except (OSError, ValueError) as exc:
            if _HAS_KODI:
                xbmc.log('FlimmerBoxYT: MPD-Server nicht erreichbar: {}'.format(exc), xbmc.LOGWARNING)
    if _HAS_KODI:
        xbmc.log('FlimmerBoxYT: MPD-HTTP-Dienst nicht gestartet; Kodi neu starten', xbmc.LOGERROR)
    return None
