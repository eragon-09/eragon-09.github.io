import os
import sys
from urllib.parse import parse_qsl, urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.router import Router

HANDLE   = int(sys.argv[1])
BASE_URL = sys.argv[0]
PARAMS   = dict(parse_qsl(urlparse(sys.argv[2]).query))


def _first_run_setup():
    """Fragt beim allerersten Start einmalig, ob Icons + Beschreibungen
    der eingebauten Kanaele gleich mitgeladen werden sollen."""
    addon_id = xbmcaddon.Addon().getAddonInfo('id')
    marker = xbmcvfs.translatePath(
        f'special://profile/addon_data/{addon_id}/first_run_done')
    if xbmcvfs.exists(marker):
        return

    try:
        os.makedirs(os.path.dirname(marker), exist_ok=True)
    except Exception:
        pass

    yes = xbmcgui.Dialog().yesno(
        'FlimmerBoxYT - Einrichtung',
        'Moechtest du jetzt Icons und Beschreibungen fuer alle 145 '
        'eingebauten Kanaele herunterladen?\n\n'
        'Das kann je nach Geraet einige Minuten dauern und kann '
        'jederzeit spaeter unter Einstellungen -> "Kanal-Icons '
        'herunterladen" nachgeholt werden.',
        yeslabel='Ja, jetzt laden', nolabel='Spaeter')

    # Marker in jedem Fall anlegen, damit der Dialog nur einmal erscheint
    try:
        with open(marker, 'w', encoding='utf-8') as f:
            f.write('1')
    except Exception:
        pass

    if yes:
        from resources.lib.icon_downloader import download_all_icons
        download_all_icons()


_first_run_setup()
Router(BASE_URL, HANDLE).route(PARAMS)
