"""Genre-Struktur fuer FlimmerBox DE - TiTanX Lab 4.0. Keine Emojis."""

GENRES = [
    {
        'id': 'filme', 'label': 'Filme', 'icon': 'genre_filme_top.png',
        'top_label': 'Top 30 Filme', 'top_query': 'Top Filme ganzer Film deutsch kostenlos legal',
        'channels_label': 'Movie Channels',
        'subcats': [
            {'id': 'filme_action', 'label': 'Action', 'query': 'Actionfilm ganzer Film deutsch'},
            {'id': 'filme_abenteuer', 'label': 'Abenteuer', 'query': 'Abenteuerfilm ganzer Film deutsch'},
            {'id': 'filme_thriller', 'label': 'Thriller', 'query': 'Thriller ganzer Film deutsch'},
            {'id': 'filme_scifi', 'label': 'Sci-Fi', 'query': 'Science Fiction Film ganzer Film deutsch'},
            {'id': 'filme_fantasy', 'label': 'Fantasy', 'query': 'Fantasyfilm ganzer Film deutsch'},
            {'id': 'filme_krimi', 'label': 'Krimi', 'query': 'Krimi ganzer Film deutsch'},
            {'id': 'filme_familie', 'label': 'Familienfilme', 'query': 'Familienfilm ganzer Film deutsch'},
            {'id': 'filme_maerchen', 'label': 'Maerchenfilme', 'query': 'Maerchenfilm ganzer Film deutsch'},
            {'id': 'filme_weihnachten', 'label': 'Weihnachtsfilme', 'query': 'Weihnachtsfilm ganzer Film deutsch'},
        ],
    },
    {
        'id': 'doku', 'label': 'Dokumentationen', 'icon': 'genre_doku.png',
        'top_label': 'Top 30 Dokumentationen', 'top_query': 'Dokumentation deutsch Doku komplett',
        'channels_label': 'Doku Channels',
        'subcats': [
            {'id': 'doku_natur', 'label': 'Natur und Tiere', 'query': 'Naturdokumentation Tierdokumentation deutsch'},
            {'id': 'doku_history', 'label': 'Geschichte', 'query': 'Geschichtsdokumentation deutsch'},
            {'id': 'doku_wissen', 'label': 'Wissenschaft', 'query': 'Wissenschaftsdokumentation deutsch'},
            {'id': 'doku_weltraum', 'label': 'Weltraum', 'query': 'Weltraum Universum Dokumentation deutsch'},
            {'id': 'doku_krieg', 'label': 'Militaer und Kriege', 'query': 'Kriegsdokumentation Militär Doku deutsch'},
            {'id': 'doku_technik', 'label': 'Technik', 'query': 'Technik Dokumentation deutsch'},
            {'id': 'doku_mystery', 'label': 'Mystery', 'query': 'Mystery Geheimnisse Dokumentation deutsch'},
            {'id': 'doku_reportagen', 'label': 'Reportagen', 'query': 'Reportage deutsch Dokumentation'},
        ],
    },
    {
        'id': 'kinder', 'label': 'Kinder', 'icon': 'genre_kinder.png',
        'top_label': 'Top 30 Kinder', 'top_query': 'Kinderfilm Lernvideo Kinder deutsch',
        'channels_label': 'Kinder Channels',
        'subcats': [
            {'id': 'kind_lernen', 'label': 'Lernvideos', 'query': 'Lernvideo Kinder Schule deutsch'},
            {'id': 'kind_maerchen', 'label': 'Maerchen', 'query': 'Märchen Kinder deutsch'},
            {'id': 'kind_filme', 'label': 'Kinderfilme', 'query': 'Kinderfilm ganzer Film deutsch'},
            {'id': 'kind_tiere', 'label': 'Tiere', 'query': 'Tiere Kinder Doku deutsch'},
        ],
    },
    {
        'id': 'autos', 'label': 'Autos', 'icon': 'genre_autos_technik.png',
        'top_label': 'Top 30 Autovideos', 'top_query': 'Autotest Fahrbericht Auto deutsch',
        'channels_label': 'Auto Channels',
        'subcats': [
            {'id': 'auto_tests', 'label': 'Tests und Reviews', 'query': 'Autotest Fahrbericht deutsch'},
            {'id': 'auto_tuning', 'label': 'Tuning', 'query': 'Tuning Performance Auto deutsch'},
            {'id': 'auto_oldtimer', 'label': 'Oldtimer', 'query': 'Oldtimer Auto deutsch'},
            {'id': 'auto_elektro', 'label': 'Elektroautos', 'query': 'Elektroauto Test deutsch'},
            {'id': 'auto_werkstatt', 'label': 'Werkstatt', 'query': 'Werkstatt Restaurierung Auto deutsch'},
        ],
    },
    {
        'id': 'technik', 'label': 'Technik', 'icon': 'genre_technik.png',
        'top_label': 'Top 30 Technikvideos', 'top_query': 'Technik Gadget Test deutsch',
        'channels_label': 'Technik Channels',
        'subcats': [
            {'id': 'technik_smartphones', 'label': 'Smartphones', 'query': 'Smartphone Technik Test deutsch'},
            {'id': 'technik_pc', 'label': 'Computer', 'query': 'Computer PC Hardware Technik deutsch'},
            {'id': 'technik_gadgets', 'label': 'KI und Gadgets', 'query': 'Gadget KI Technik deutsch'},
            {'id': 'technik_diy', 'label': 'Heimwerken und DIY', 'query': 'Heimwerken DIY deutsch'},
            {'id': 'technik_smarthome', 'label': 'Smart Home', 'query': 'Smart Home Technik deutsch'},
        ],
    },
    {
        'id': 'heimwerken', 'label': 'Heimwerken und DIY', 'icon': 'genre_heimwerken.png',
        'top_label': 'Top 30 Heimwerken', 'top_query': 'Heimwerken DIY selber machen deutsch',
        'channels_label': 'Heimwerken Channels',
        'subcats': [
            {'id': 'hw_holz',      'label': 'Holzarbeiten',           'query': 'Holzarbeiten DIY selber bauen deutsch'},
            {'id': 'hw_renovieren','label': 'Renovieren und Bauen',   'query': 'Renovieren Bauen Heimwerken deutsch'},
            {'id': 'hw_werkzeug',  'label': 'Werkzeug und Technik',   'query': 'Werkzeug Test Heimwerker deutsch'},
            {'id': 'hw_upcycling', 'label': 'Upcycling und Basteln',  'query': 'Upcycling Basteln DIY deutsch'},
            {'id': 'hw_garten',    'label': 'Garten und Outdoor',     'query': 'Garten DIY selber machen deutsch'},
        ],
    },
    {
        'id': 'reisen_outdoor', 'label': 'Reisen und Outdoor', 'icon': 'genre_reisen_outdoor.png',
        'top_label': 'Top 30 Reisevideos', 'top_query': 'Reise Doku Outdoor deutsch',
        'channels_label': 'Reise Channels',
        'subcats': [
            {'id': 'reise_deutschland', 'label': 'Deutschland', 'query': 'Deutschland Reise Doku'},
            {'id': 'reise_europa', 'label': 'Europa', 'query': 'Europa Reise Doku deutsch'},
            {'id': 'reise_welt', 'label': 'Weltreisen', 'query': 'Weltreise Reisedoku deutsch'},
            {'id': 'reise_vanlife', 'label': 'Vanlife', 'query': 'Vanlife Camping deutsch'},
            {'id': 'outdoor_camping', 'label': 'Camping', 'query': 'Camping Outdoor deutsch'},
            {'id': 'outdoor_bushcraft', 'label': 'Bushcraft', 'query': 'Survival Bushcraft deutsch'},
        ],
    },
    {
        'id': 'kochen_food', 'label': 'Kochen und Food', 'icon': 'genre_kochen_food.png',
        'top_label': 'Top 30 Rezepte', 'top_query': 'Rezept kochen deutsch beliebt',
        'channels_label': 'Food Channels',
        'subcats': [
            {'id': 'food_kochen', 'label': 'Kochen', 'query': 'kochen Rezept deutsch'},
            {'id': 'food_backen', 'label': 'Backen', 'query': 'Backen Kuchen Brot deutsch'},
            {'id': 'food_schnell', 'label': 'Schnell und einfach', 'query': 'schnelle einfache Rezepte deutsch'},
            {'id': 'food_bbq', 'label': 'Grillen und BBQ', 'query': 'Grillen BBQ deutsch'},
            {'id': 'food_dessert', 'label': 'Desserts', 'query': 'Dessert Rezept deutsch'},
        ],
    },
    {
        'id': 'finanzen', 'label': 'Finanzen', 'icon': 'genre_finanzen.png',
        'top_label': 'Top 30 Finanzvideos', 'top_query': 'Finanzen ETF Aktien Geldanlage deutsch',
        'channels_label': 'Finanz Channels',
        'subcats': [
            {'id': 'fin_etf', 'label': 'ETFs', 'query': 'ETF Geldanlage deutsch'},
            {'id': 'fin_aktien', 'label': 'Aktien', 'query': 'Aktien investieren deutsch'},
            {'id': 'fin_vorsorge', 'label': 'Altersvorsorge', 'query': 'Altersvorsorge Finanzen deutsch'},
            {'id': 'fin_krypto', 'label': 'Krypto', 'query': 'Krypto Bitcoin deutsch'},
        ],
    },
    {
        'id': 'it_ki', 'label': 'IT und KI', 'icon': 'genre_it_ki.png',
        'top_label': 'Top 30 KI Videos', 'top_query': 'Künstliche Intelligenz Programmieren IT deutsch',
        'channels_label': 'IT Channels',
        'subcats': [
            {'id': 'it_prog', 'label': 'Programmierung', 'query': 'Programmieren lernen deutsch'},
            {'id': 'it_ki_sub', 'label': 'KI', 'query': 'Künstliche Intelligenz deutsch'},
            {'id': 'it_linux', 'label': 'Linux', 'query': 'Linux Tutorial deutsch'},
            {'id': 'it_windows', 'label': 'Windows', 'query': 'Windows Tutorial deutsch'},
            {'id': 'it_netze', 'label': 'Netzwerke', 'query': 'Netzwerk IT deutsch'},
        ],
    },
    {
        'id': 'gaming', 'label': 'Gaming', 'icon': 'genre_gaming.png',
        'top_label': 'Top 30 Gaming Videos', 'top_query': 'Gaming deutsch Let\'s Play',
        'channels_label': 'Gaming Channels',
        'subcats': [
            {'id': 'gaming_letsplay', 'label': 'Lets Plays', 'query': 'Let\'s Play deutsch'},
            {'id': 'gaming_survival', 'label': 'Survival', 'query': 'Survival Game deutsch'},
            {'id': 'gaming_openworld', 'label': 'Open World', 'query': 'Open World Game deutsch'},
            {'id': 'gaming_strategie', 'label': 'Strategie', 'query': 'Strategiespiel deutsch'},
        ],
    },
    {
        'id': 'angeln', 'label': 'Angeln', 'icon': 'genre_angeln.png',
        'top_label': 'Top 30 Angeln', 'top_query': 'Angeln Karpfen Forelle deutsch',
        'channels_label': 'Angel Channels',
        'subcats': [
            {'id': 'angel_karpfen', 'label': 'Karpfenangeln',    'query': 'Karpfenangeln deutsch'},
            {'id': 'angel_raubfisch','label': 'Raubfischangeln', 'query': 'Raubfischangeln Hecht Zander deutsch'},
            {'id': 'angel_forelle', 'label': 'Forellenangeln',   'query': 'Forellenangeln Fliegenfischen deutsch'},
            {'id': 'angel_meer',    'label': 'Meeresangeln',     'query': 'Meeresangeln Nordsee Ostsee deutsch'},
            {'id': 'angel_tipps',   'label': 'Tipps und Ausruestung', 'query': 'Angelausrüstung Tipps deutsch'},
        ],
    },
    {
        'id': 'musik', 'label': 'Musik', 'icon': 'genre_musik.png',
        'top_label': 'Musik Top Videos', 'top_query': 'Musik Hits Deutschland aktuell',
        'channels_label': 'Musik Channels',
        'subcats': [
            {'id': 'musik_schlager',   'label': 'Schlager',        'query': 'Schlager Hits Deutschland aktuell'},
            {'id': 'musik_dance',      'label': 'Dance & Charts',  'query': 'Dance Charts Deutschland EDM Hits'},
            {'id': 'musik_klassik',    'label': 'Klassik & Oper',  'query': 'Klassik Konzert Oper deutsch'},
            {'id': 'musik_konzert',    'label': 'Konzerte & Live', 'query': 'Konzert Live Musik deutsch'},
        ],
    },
    {
        'id': 'sport', 'label': 'Sport', 'icon': 'genre_sport.png',
        'top_label': 'Top 30 Sportvideos', 'top_query': 'Sport Doku Highlights deutsch',
        'channels_label': 'Sport Channels',
        'subcats': [
            {'id': 'sport_fussball', 'label': 'Fussball', 'query': 'Fußball Doku Highlights deutsch'},
            {'id': 'sport_motorsport', 'label': 'Motorsport', 'query': 'Motorsport Doku deutsch'},
            {'id': 'sport_fitness', 'label': 'Fitness', 'query': 'Fitness Training deutsch'},
            {'id': 'sport_outdoor', 'label': 'Outdoor Sport', 'query': 'Wandern Klettern Radfahren deutsch'},
        ],
    },
    {
        'id': 'tv_mediatheken', 'label': 'TV Mediatheken', 'icon': 'genre_tv_mediatheken.png',
        'top_label': 'Top 30 Mediathek Videos', 'top_query': 'ARD ZDF Arte Doku deutsch',
        'channels_label': 'TV Channels',
        'subcats': [
            {'id': 'tv_arte', 'label': 'ARTE', 'query': 'ARTE Doku deutsch'},
            {'id': 'tv_zdf', 'label': 'ZDF', 'query': 'ZDF Doku deutsch'},
            {'id': 'tv_ard', 'label': 'ARD', 'query': 'ARD Doku deutsch'},
            {'id': 'tv_wdr', 'label': 'WDR', 'query': 'WDR Doku deutsch'},
            {'id': 'tv_swr', 'label': 'SWR', 'query': 'SWR Doku deutsch'},
        ],
    },
]

def get_genre(genre_id):
    for g in GENRES:
        if g['id'] == genre_id:
            return g
    return None

def get_subcat(subcat_id):
    for g in GENRES:
        for s in g['subcats']:
            if s['id'] == subcat_id:
                return s
    return None

def genre_labels():
    return [(g['label'], g['id']) for g in GENRES]
