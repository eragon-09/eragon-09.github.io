"""
Icon-Downloader fuer FlimmerBoxYT - TiTanX Lab
Laedt Kanal-Profilbilder UND -Beschreibungen ueber yt-dlp
(kein YouTube-API-Key noetig).

Hinweis: Anders als frueher (ein API-Call fuer 50 Kanaele) wird hier
pro Kanal eine eigene Anfrage gestellt, da yt-dlp keine Batch-Abfrage
kennt. Die Ergebnisse werden aber in resources/lib/api.py bereits
7 Tage lang gecacht, wiederholte Laeufe sind daher schnell.

Die dabei ohnehin abgerufenen Kanal-Beschreibungen werden zusaetzlich
in channel_meta.json gespeichert, damit auch fest eingebaute Kanaele
(nicht nur selbst hinzugefuegte) eine echte Beschreibung in der
Kanalverwaltung anzeigen koennen (siehe resources/lib/channels.py).
"""
import json
import os, re
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
from urllib.request import urlopen, Request

ADDON    = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
# Gespeichert in userdata/addon_data/ - bleibt bei Updates erhalten
ICON_DIR      = xbmcvfs.translatePath(
    f'special://userdata/addon_data/{ADDON_ID}/channels/')
META_CACHE_PATH = os.path.join(ICON_DIR, 'channel_meta.json')


def _load_meta():
    try:
        with open(META_CACHE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_meta(meta):
    try:
        os.makedirs(os.path.dirname(META_CACHE_PATH), exist_ok=True)
        with open(META_CACHE_PATH, 'w', encoding='utf-8') as f:
            json.dump(meta, f, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f'FlimmerBoxYT meta save error: {e}', xbmc.LOGWARNING)


def _slugify(name):
    text = (name or '').lower()
    repl = {'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss',
            'á': 'a',  'à': 'a',  'é': 'e',  'è': 'e'}
    for a, b in repl.items():
        text = text.replace(a, b)
    return re.sub(r'[^a-z0-9]+', '_', text).strip('_') or 'channel'


def _download_image(url, path):
    """Laedt Bild herunter, speichert als JPG 256x256 max 80KB."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        r    = urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=15)
        data = r.read()
        try:
            from PIL import Image
            import io
            img = Image.open(io.BytesIO(data)).convert('RGB')
            img = img.resize((256, 256), Image.LANCZOS)
            for quality in (85, 75, 65, 55):
                buf = io.BytesIO()
                img.save(buf, 'JPEG', quality=quality, optimize=True)
                if buf.tell() <= 81920:  # 80KB
                    break
            with open(path, 'wb') as f:
                f.write(buf.getvalue())
        except Exception:
            # Fallback ohne PIL - direkt speichern
            with open(path, 'wb') as f:
                f.write(data)
        return os.path.getsize(path) > 0
    except Exception as e:
        xbmc.log(f'FlimmerBoxYT icon save error: {e}', xbmc.LOGWARNING)
        return False


def download_all_icons():
    """Laedt Kanal-Icons UND -Beschreibungen ueber yt-dlp (kein API-Key noetig)."""
    from resources.lib.channels import BUILTIN_CHANNELS
    from resources.lib.api import get_channel_metadata

    channels = [c for c in BUILTIN_CHANNELS
                if c.get('id', '').startswith('UC')]

    meta_cache = _load_meta()

    # Ueberspringen, wenn sowohl Icon als auch Beschreibung schon vorhanden sind
    to_fetch = []
    skipped  = 0
    for ch in channels:
        slug = _slugify(ch.get('name', ''))
        icon_path = os.path.join(ICON_DIR, f'{slug}.jpg')
        has_icon = os.path.exists(icon_path) and os.path.getsize(icon_path) > 0
        has_desc = bool(meta_cache.get(ch.get('id', '')))
        if has_icon and has_desc:
            skipped += 1
        else:
            to_fetch.append((ch, has_icon, has_desc))

    if not to_fetch:
        xbmcgui.Dialog().ok('FlimmerBoxYT Icons',
                            f'Alle {skipped} Kanaele bereits vollstaendig (Icon + Beschreibung).')
        return

    total   = len(to_fetch)
    success = 0
    failed  = 0

    dialog = xbmcgui.DialogProgress()
    dialog.create('FlimmerBoxYT', f'Lade {total} Kanal-Icons & -Infos...')

    for i, (ch, has_icon, has_desc) in enumerate(to_fetch):
        if dialog.iscanceled():
            break

        pct = int(i / total * 100)
        dialog.update(pct, f'{ch.get("name", "Kanal")} ({i + 1} / {total})')

        meta = get_channel_metadata(ch.get('id', '')) or {}
        ok = False

        if not has_icon:
            icon_url = meta.get('icon_url', '')
            slug = _slugify(ch.get('name', ''))
            path = os.path.join(ICON_DIR, f'{slug}.jpg')
            if icon_url and _download_image(icon_url, path):
                ok = True
        else:
            ok = True

        if not has_desc:
            desc = (meta.get('description') or '').strip()
            if desc:
                meta_cache[ch.get('id', '')] = desc[:400]
                ok = True

        if ok:
            success += 1
        else:
            failed += 1

    _save_meta(meta_cache)
    dialog.close()

    msg = (f'{success} aktualisiert\n'
           f'{skipped} bereits vollstaendig\n'
           f'{failed} Fehler')
    xbmcgui.Dialog().ok('FlimmerBoxYT Icons', msg)
    xbmc.log(f'FlimmerBoxYT Icons: {msg.replace(chr(10), " | ")}',
             xbmc.LOGINFO)
