"""Router fuer FlimmerBox DE - TiTanX Lab 4.0."""

import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import urlencode

from resources.lib.genres import GENRES, get_genre, get_subcat, genre_labels
from resources.lib.api import (
    search, get_playlist_videos, has_api_key, get_uploads_playlist_id,
    resolve_handle_to_id, get_channel_metadata, get_channel_playlists,
    get_popular_videos,
)
from resources.lib.favorites import get as fav_get, add as fav_add, remove as fav_remove, is_favorite, count as fav_count, total_count
from resources.lib.channels import get_playlists_for_subcat, get_channels_for_genre, get_all_channels
from resources.lib.player import play
from resources.lib.channel_manager import (
    DATA_DIR, ICON_DIR, BANNER_DIR, add_channel_from_url, delete_user_channel,
    move_user_channel, export_backup, import_backup, slugify,
    search_youtube_channels, add_channel_from_search_result,
)
from concurrent.futures import ThreadPoolExecutor, as_completed

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
IMG_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources/art/genre/')
MEDIA_CHANNELS = xbmcvfs.translatePath(f'special://userdata/addon_data/{ADDON_ID}/channels/')


MEDIA_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources/media/')

def _img(filename):
    if not filename:
        return ''
    # 1. Direkt im img/ Ordner (Genre-Icons)
    p = os.path.join(IMG_PATH, filename)
    if os.path.exists(p):
        return p
    # 2. In media/playlists/ (Playlist-Thumbnails)
    if filename.startswith('playlists/'):
        p2 = os.path.join(MEDIA_PATH, filename)
        if os.path.exists(p2):
            return p2
    # 3. Fallback: Dateiname direkt zurückgeben
    return filename


def _channel_icon(ch):
    for rel in (ch.get('icon', ''), ''):
        if rel:
            p = os.path.join(DATA_DIR, rel)
            if os.path.exists(p):
                return p
    fn = slugify(ch.get('name', '')) + '.jpg'
    p = os.path.join(MEDIA_CHANNELS, fn)
    if os.path.exists(p):
        return p
    return 'DefaultVideo.png'


def _channel_banner(ch):
    rel = ch.get('banner', '')
    if rel:
        p = os.path.join(DATA_DIR, rel)
        if os.path.exists(p):
            return p
    fn = slugify(ch.get('name', '')) + '.jpg'
    p = os.path.join(BANNER_DIR, fn)
    if os.path.exists(p):
        return p
    return ''


class Router:
    def __init__(self, base_url, handle):
        self.base_url = base_url
        self.handle = handle

    def url(self, **kw):
        return f'{self.base_url}?{urlencode(kw)}'

    def route(self, p):
        mode = p.get('mode', 'main')
        if mode == 'main': self._main()
        elif mode == 'genre': self._genre(p.get('genre_id', ''))
        elif mode == 'top30': self._top30(p.get('genre_id', ''), p.get('page_token', ''))
        elif mode == 'latest': self._latest(p.get('genre_id', ''), p.get('page_token', ''))
        elif mode == 'subcat': self._subcat(p.get('genre_id', ''), p.get('subcat_id', ''), p.get('page_token', ''))
        elif mode == 'channels_menu': self._channels_menu(p.get('genre_id', ''))
        elif mode == 'channels_group': self._channels_group(p.get('genre_id', ''), p.get('group', 'ALL'))
        elif mode == 'channel_home': self._channel_home(p.get('genre_id', ''), p.get('channel_id', ''), p.get('channel_name', ''))
        elif mode == 'channel': self._channel(p.get('genre_id', ''), p.get('channel_id', ''), p.get('channel_name', ''), p.get('page_token', ''))
        elif mode == 'channel_popular': self._channel_popular(p.get('genre_id', ''), p.get('channel_id', ''), p.get('channel_name', ''), p.get('page_token', ''))
        elif mode == 'channel_playlists': self._channel_playlists(p.get('genre_id', ''), p.get('channel_id', ''), p.get('channel_name', ''), p.get('page_token', ''))
        elif mode == 'channel_info': self._channel_info(p.get('channel_id', ''), p.get('channel_name', ''))
        elif mode == 'playlist': self._playlist(p.get('genre_id', ''), p.get('playlist_id', ''), p.get('playlist_name', ''), p.get('page_token', ''))
        elif mode == 'search': self._search(p.get('genre_id', ''), p.get('subcat_id', ''))
        elif mode == 'results': self._results(p.get('genre_id', ''), p.get('subcat_id', ''), p.get('query', ''), p.get('page_token', ''))
        elif mode == 'favorites': self._favorites(p.get('genre_id', '_all'))
        elif mode == 'fav_add': self._fav_add(p)
        elif mode == 'fav_remove': self._fav_remove(p.get('genre_id', ''), p.get('youtube_id', ''))
        elif mode == 'manager': self._manager()
        elif mode == 'channel_search': self._channel_search(p.get('genre_id', ''))
        elif mode == 'channel_add': self._channel_add(p.get('genre_id', ''))
        elif mode == 'channel_delete_menu': self._channel_delete_menu()
        elif mode == 'channel_delete': self._channel_delete(p.get('channel_id', ''))
        elif mode == 'channel_move_menu': self._channel_move_menu()
        elif mode == 'channel_move': self._channel_move(p.get('channel_id', ''))
        elif mode == 'backup_export': self._backup_export()
        elif mode == 'backup_import': self._backup_import()
        elif mode == 'download_icons':
            from resources.lib.icon_downloader import download_all_icons
            download_all_icons()
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        elif mode == 'play': play(self.handle, p.get('youtube_id', ''), p.get('title', ''))
        else: self._main()

    def _add_dir(self, label, mode, art='DefaultFolder.png', plot='', **params):
        li = xbmcgui.ListItem(label=label)
        li.getVideoInfoTag().setTitle(label)
        if plot:
            li.getVideoInfoTag().setPlot(plot)
        li.setArt({'icon': art, 'thumb': art, 'poster': art})
        params['mode'] = mode
        xbmcplugin.addDirectoryItem(self.handle, self.url(**params), li, isFolder=True)

    def _main(self):
        xbmcplugin.setPluginCategory(self.handle, 'FlimmerBox DE - TiTanX Lab')
        xbmcplugin.setContent(self.handle, 'files')
        for g in GENRES:
            n_ch = len(get_channels_for_genre(g['id']))
            favs = fav_count(g['id'])
            label = g['label']
            plot = f"{len(g['subcats'])} Kategorien · {n_ch} Kanaele" + (f" · {favs} Favoriten" if favs else '')
            self._add_dir(label, 'genre', _img(g.get('icon', '')) or 'DefaultFolder.png', plot, genre_id=g['id'])
        self._add_dir(f'[B][COLOR gold]★ Alle Favoriten ({total_count()})[/COLOR][/B]', 'favorites', 'DefaultFavourites.png', f'{total_count()} gespeicherte Favoriten', genre_id='_all')
        self._add_dir('[B][COLOR dodgerblue]⚙ Kanalverwaltung[/COLOR][/B]', 'manager', 'DefaultAddonProgram.png', 'Kanaele hinzufuegen, loeschen, verschieben und sichern')
        xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(self.handle)

    def _genre(self, genre_id):
        g = get_genre(genre_id)
        if not g:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return
        xbmcplugin.setPluginCategory(self.handle, g['label'])
        xbmcplugin.setContent(self.handle, 'files')
        self._add_dir(g.get('top_label', 'Top 30'), 'top30', 'DefaultVideoPlaylists.png', 'Kuratierte Top-Suche', genre_id=genre_id)
        self._add_dir('Neueste Uploads', 'latest', 'DefaultRecentlyAddedEpisodes.png', 'Neueste Videos aller Kanaele in diesem Bereich', genre_id=genre_id)
        for sc in g['subcats']:
            self._add_dir(sc['label'], 'subcat', 'DefaultFolder.png', sc.get('query', ''), genre_id=genre_id, subcat_id=sc['id'])
        self._add_dir('[B][COLOR cyan]' + g.get('channels_label', 'Channels') + '[/COLOR][/B]', 'channels_menu', _img(g.get('icon','')) or 'DefaultVideoPlaylists.png', 'Kanaele alphabetisch A bis Z', genre_id=genre_id)
        self._add_dir('[B][COLOR lime]+ Kanal hinzufuegen[/COLOR][/B]', 'channel_add', 'DefaultAddonsSearch.png', 'YouTube URL einfuegen und direkt diesem Genre zuordnen', genre_id=genre_id)
        self._add_dir(f'[B][COLOR gold]★ Favoriten ({fav_count(genre_id)})[/COLOR][/B]', 'favorites', 'DefaultFavourites.png', '', genre_id=genre_id)
        xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(self.handle)

    def _top30(self, genre_id, page_token=''):
        g = get_genre(genre_id)
        if not g:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return
        xbmcplugin.setPluginCategory(self.handle, g.get('top_label', 'Top 30'))
        xbmcplugin.setContent(self.handle, 'movies')
        if not has_api_key(): return self._no_api_key()
        videos, next_token = search(g.get('top_query', g['label']), max_results=30, page_token=page_token or None)
        for v in videos[:30]:
            self._add_video(v, genre_id)
        if next_token:
            self._add_dir('Weitere Top-Ergebnisse ...', 'top30', 'DefaultFolder.png', '', genre_id=genre_id, page_token=next_token)
        xbmcplugin.endOfDirectory(self.handle)

    def _latest(self, genre_id, page_token=''):
        g = get_genre(genre_id)
        xbmcplugin.setPluginCategory(self.handle, 'Neueste Uploads' if not g else f'Neueste Uploads - {g["label"]}')
        xbmcplugin.setContent(self.handle, 'movies')
        if not has_api_key(): return self._no_api_key()

        CHANNELS_PER_PAGE = 15
        try:
            offset = int(page_token) if page_token else 0
        except Exception:
            offset = 0

        channels = get_channels_for_genre(genre_id)
        batch = [ch for ch in channels[offset:offset + CHANNELS_PER_PAGE] if ch.get('id')]

        def _fetch(ch):
            pl_id = get_uploads_playlist_id(ch.get('id', ''))
            if not pl_id:
                return ch, []
            videos, _ = get_playlist_videos(pl_id, max_results=5)
            return ch, (videos or [])

        all_videos = []
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(_fetch, ch) for ch in batch]
            for future in as_completed(futures):
                ch, videos = future.result()
                for v in videos:
                    v['_channel_name'] = ch.get('name', '')
                    all_videos.append(v)
        all_videos.sort(key=lambda x: x.get('published', ''), reverse=True)
        for v in all_videos:
            self._add_video(v, genre_id)
        if not all_videos:
            li = xbmcgui.ListItem(label='Keine Uploads in dieser Kanal-Auswahl gefunden')
            xbmcplugin.addDirectoryItem(self.handle, '', li, isFolder=False)
        if offset + CHANNELS_PER_PAGE < len(channels):
            self._add_dir(
                f'▶ Weitere Kanaele ({offset + CHANNELS_PER_PAGE}/{len(channels)}) ...',
                'latest', 'DefaultFolder.png', '',
                genre_id=genre_id, page_token=str(offset + CHANNELS_PER_PAGE))
        xbmcplugin.endOfDirectory(self.handle)

    def _subcat(self, genre_id, subcat_id, page_token=''):
        sc = get_subcat(subcat_id)
        if not sc:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return
        xbmcplugin.setPluginCategory(self.handle, sc['label'])
        xbmcplugin.setContent(self.handle, 'movies')
        if not has_api_key(): return self._no_api_key()
        li_s = xbmcgui.ListItem(label='[B][COLOR cyan]🔍  Suche: Titel eingeben …[/COLOR][/B]')
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode='search', genre_id=genre_id, subcat_id=subcat_id), li_s, isFolder=True)
        for pl in get_playlists_for_subcat(subcat_id):
            art = _img(pl.get('img', '')) or 'DefaultVideoPlaylists.png'
            self._add_dir('📋 ' + pl['name'], 'playlist', art, '', genre_id=genre_id, playlist_id=pl['id'], playlist_name=pl['name'])
        videos, next_token = search(sc['query'], page_token=page_token or None)
        for v in videos:
            self._add_video(v, genre_id)
        if next_token:
            self._add_dir('▶  Weitere Ergebnisse …', 'subcat', 'DefaultFolder.png', '', genre_id=genre_id, subcat_id=subcat_id, page_token=next_token)
        xbmcplugin.endOfDirectory(self.handle)

    def _channels_menu(self, genre_id):
        g = get_genre(genre_id)
        xbmcplugin.setPluginCategory(self.handle, g.get('channels_label', 'Channels') if g else 'Channels')
        xbmcplugin.setContent(self.handle, 'files')
        channels = sorted(get_channels_for_genre(genre_id), key=lambda c: c.get('name', '').lower())
        if len(channels) > 30:
            self._add_dir('[B][COLOR cyan]► Alle Kanaele[/COLOR][/B]', 'channels_group', 'DefaultVideoPlaylists.png', 'Alle Kanaele ungefiltert anzeigen', genre_id=genre_id, group='ALL')
            for group in ('A-F', 'G-L', 'M-R', 'S-Z'):
                self._add_dir(group, 'channels_group', 'DefaultFolder.png', '', genre_id=genre_id, group=group)
        else:
            for ch in channels:
                self._add_channel_item(ch, genre_id)
        self._add_dir('[B][COLOR lime]+ Kanal hinzufuegen[/COLOR][/B]', 'channel_add', 'DefaultAddonsSearch.png', '', genre_id=genre_id)
        xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(self.handle)

    def _channels_group(self, genre_id, group):
        xbmcplugin.setPluginCategory(self.handle, f'Channels {group}')
        xbmcplugin.setContent(self.handle, 'files')
        if group == 'ALL':
            for ch in sorted(get_channels_for_genre(genre_id), key=lambda c: c.get('name', '').lower()):
                self._add_channel_item(ch, genre_id)
        else:
            ranges = {'A-F': ('A', 'F'), 'G-L': ('G', 'L'), 'M-R': ('M', 'R'), 'S-Z': ('S', 'Z')}
            lo, hi = ranges.get(group, ('A', 'Z'))
            for ch in sorted(get_channels_for_genre(genre_id), key=lambda c: c.get('name', '').lower()):
                first = (ch.get('name', '#')[:1] or '#').upper()
                if lo <= first <= hi:
                    self._add_channel_item(ch, genre_id)
        xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(self.handle)

    def _add_channel_item(self, ch, genre_id):
        li = xbmcgui.ListItem(label=ch.get('name', 'Kanal'))
        li.getVideoInfoTag().setTitle(ch.get('name', 'Kanal'))
        li.getVideoInfoTag().setPlot(ch.get('description', '') or ch.get('handle', ''))
        icon = _channel_icon(ch)
        art = {'icon': icon, 'thumb': icon}
        banner = _channel_banner(ch)
        if banner:
            art['fanart'] = banner
        li.setArt(art)
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode='channel_home', genre_id=genre_id, channel_id=ch.get('id', ''), channel_name=ch.get('name', '')), li, isFolder=True)

    def _channel_home(self, genre_id, channel_id, channel_name):
        xbmcplugin.setPluginCategory(self.handle, channel_name or 'Kanal')
        xbmcplugin.setContent(self.handle, 'files')
        self._add_dir('Neueste Videos', 'channel', 'DefaultRecentlyAddedEpisodes.png', '', genre_id=genre_id, channel_id=channel_id, channel_name=channel_name)
        self._add_dir('Beliebteste Videos', 'channel_popular', 'DefaultVideo.png', '', genre_id=genre_id, channel_id=channel_id, channel_name=channel_name)
        self._add_dir('Playlists', 'channel_playlists', 'DefaultVideoPlaylists.png', '', genre_id=genre_id, channel_id=channel_id, channel_name=channel_name)
        self._add_dir('Kanalinformationen', 'channel_info', 'DefaultAddonInfo.png', '', channel_id=channel_id, channel_name=channel_name)
        xbmcplugin.endOfDirectory(self.handle)

    def _resolve_channel_id(self, channel_id, channel_name):
        if channel_id:
            return channel_id
        q = channel_name
        for ch in get_all_channels():
            if ch.get('name') == channel_name and ch.get('handle'):
                q = ch.get('handle')
                break
        return resolve_handle_to_id(q)

    def _channel(self, genre_id, channel_id, channel_name, page_token=''):
        xbmcplugin.setPluginCategory(self.handle, channel_name or 'Neueste Videos')
        xbmcplugin.setContent(self.handle, 'movies')
        if not has_api_key(): return self._no_api_key()
        channel_id = self._resolve_channel_id(channel_id, channel_name)
        pl_id = get_uploads_playlist_id(channel_id) if channel_id else ''
        videos, next_token = get_playlist_videos(pl_id, page_token=page_token or None) if pl_id else ([], None)
        for v in videos:
            self._add_video(v, genre_id)
        if next_token:
            self._add_dir('Weitere Videos ...', 'channel', 'DefaultFolder.png', '', genre_id=genre_id, channel_id=channel_id, channel_name=channel_name, page_token=next_token)
        xbmcplugin.endOfDirectory(self.handle, succeeded=bool(videos))

    def _channel_popular(self, genre_id, channel_id, channel_name, page_token=''):
        xbmcplugin.setPluginCategory(self.handle, 'Beliebteste Videos - ' + channel_name)
        xbmcplugin.setContent(self.handle, 'movies')
        if not has_api_key(): return self._no_api_key()
        videos, next_token = get_popular_videos(channel_id, page_token=page_token or None)
        for v in videos:
            self._add_video(v, genre_id)
        if next_token:
            self._add_dir('Weitere Videos ...', 'channel_popular', 'DefaultFolder.png', '', genre_id=genre_id, channel_id=channel_id, channel_name=channel_name, page_token=next_token)
        xbmcplugin.endOfDirectory(self.handle, succeeded=bool(videos))

    def _channel_playlists(self, genre_id, channel_id, channel_name, page_token=''):
        xbmcplugin.setPluginCategory(self.handle, 'Playlists - ' + channel_name)
        xbmcplugin.setContent(self.handle, 'files')
        if not has_api_key(): return self._no_api_key()
        playlists, next_token = get_channel_playlists(channel_id, page_token=page_token or None)
        for pl in playlists:
            art = pl.get('thumb', '') or 'DefaultVideoPlaylists.png'
            self._add_dir(pl.get('name', 'Playlist'), 'playlist', art, pl.get('description', ''), genre_id=genre_id, playlist_id=pl.get('id', ''), playlist_name=pl.get('name', 'Playlist'))
        if next_token:
            self._add_dir('Weitere Playlists ...', 'channel_playlists', 'DefaultFolder.png', '', genre_id=genre_id, channel_id=channel_id, channel_name=channel_name, page_token=next_token)
        xbmcplugin.endOfDirectory(self.handle)

    def _channel_info(self, channel_id, channel_name):
        meta = get_channel_metadata(channel_id) if channel_id and has_api_key() else {}
        title = meta.get('title') or channel_name
        desc = meta.get('description', 'Keine Beschreibung vorhanden')
        videos = meta.get('videoCount', '')
        subs = meta.get('subscriberCount', '')
        msg = desc[:800]
        if videos or subs:
            msg += f'\n\nVideos: {videos}\nAbonnenten: {subs}'
        xbmcgui.Dialog().textviewer(title, msg)
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _playlist(self, genre_id, playlist_id, playlist_name, page_token=''):
        xbmcplugin.setPluginCategory(self.handle, playlist_name or 'Playlist')
        xbmcplugin.setContent(self.handle, 'movies')
        if not has_api_key(): return self._no_api_key()
        videos, next_token = get_playlist_videos(playlist_id, page_token=page_token or None)
        for v in videos:
            self._add_video(v, genre_id)
        if next_token:
            self._add_dir('Weitere Videos ...', 'playlist', 'DefaultFolder.png', '', genre_id=genre_id, playlist_id=playlist_id, playlist_name=playlist_name, page_token=next_token)
        xbmcplugin.endOfDirectory(self.handle, succeeded=bool(videos))

    def _search(self, genre_id, subcat_id):
        sc = get_subcat(subcat_id)
        query = xbmcgui.Dialog().input(f'Suche - {sc["label"] if sc else "Suche"}', type=xbmcgui.INPUT_ALPHANUM)
        if not query or not query.strip():
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return
        self._results(genre_id, subcat_id, query.strip())

    def _results(self, genre_id, subcat_id, query, page_token=''):
        sc = get_subcat(subcat_id)
        full_query = f'{query} {sc["query"]}' if sc else query
        xbmcplugin.setPluginCategory(self.handle, 'Suche: ' + query)
        xbmcplugin.setContent(self.handle, 'movies')
        if not has_api_key(): return self._no_api_key()
        videos, next_token = search(full_query, page_token=page_token or None)
        for v in videos:
            self._add_video(v, genre_id)
        if next_token:
            self._add_dir('Weitere Ergebnisse ...', 'results', 'DefaultFolder.png', '', genre_id=genre_id, subcat_id=subcat_id, query=query, page_token=next_token)
        xbmcplugin.endOfDirectory(self.handle, succeeded=bool(videos))

    def _favorites(self, genre_id):
        xbmcplugin.setPluginCategory(self.handle, 'Favoriten')
        xbmcplugin.setContent(self.handle, 'movies')
        if genre_id == '_all':
            films = []
            for g in GENRES:
                for f in fav_get(g['id']):
                    f['_genre_id'] = g['id']; films.append(f)
        else:
            films = fav_get(genre_id)
            for f in films: f['_genre_id'] = genre_id
        for f in films:
            self._add_video(f, f.get('_genre_id', genre_id), show_add=False, show_remove=True)
        if not films:
            xbmcplugin.addDirectoryItem(self.handle, '', xbmcgui.ListItem(label='Noch keine Favoriten gespeichert'), isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)

    def _fav_add(self, p):
        film = {k: p.get(k, '') for k in ('youtube_id', 'title', 'description', 'thumb', 'channel')}
        try: film['year'] = int(p.get('year', 0))
        except Exception: film['year'] = 0
        fav_add(p.get('genre_id', ''), film)
        xbmcgui.Dialog().notification('Favorit gespeichert', film.get('title', ''), xbmcgui.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _fav_remove(self, genre_id, youtube_id):
        fav_remove(genre_id, youtube_id)
        xbmcgui.Dialog().notification('Favorit entfernt', '', xbmcgui.NOTIFICATION_INFO, 1500)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _manager(self):
        xbmcplugin.setPluginCategory(self.handle, 'Kanalverwaltung')
        xbmcplugin.setContent(self.handle, 'files')
        self._add_dir('Kanal suchen', 'channel_search', 'DefaultAddonsSearch.png', 'Schlagwort eingeben, Treffer auswaehlen und Genre festlegen')
        self._add_dir('Kanal per URL hinzufuegen', 'channel_add', 'DefaultAddonsSearch.png', 'YouTube URL, Handle oder UC-ID einfuegen')
        self._add_dir('Kanal loeschen', 'channel_delete_menu', 'DefaultFolder.png', 'Nur selbst hinzugefuegte Kanaele')
        self._add_dir('Kanal verschieben', 'channel_move_menu', 'DefaultFolder.png', 'Genre eines selbst hinzugefuegten Kanals aendern')
        self._add_dir('Backup exportieren', 'backup_export', 'DefaultFolder.png', '')
        self._add_dir('Backup importieren', 'backup_import', 'DefaultFolder.png', '')
        xbmcplugin.endOfDirectory(self.handle)

    def _select_genre(self, preselect=''):
        labels = [g['label'] for g in GENRES]
        ids = [g['id'] for g in GENRES]
        idx = 0
        if preselect in ids:
            idx = ids.index(preselect)
        choice = xbmcgui.Dialog().select('Genre auswaehlen', labels, preselect=idx)
        return ids[choice] if choice >= 0 else ''


    def _channel_search(self, genre_id=''):
        query = xbmcgui.Dialog().input('YouTube Kanal suchen - Schlagwort', type=xbmcgui.INPUT_ALPHANUM)
        if not query or not query.strip():
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return

        results = search_youtube_channels(query.strip(), max_results=10)
        if not results:
            xbmcgui.Dialog().notification('Kanal suchen', 'Keine Treffer oder YouTube-Limit aktiv', xbmcgui.NOTIFICATION_INFO, 3500)
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return

        labels = []
        for r in results:
            desc = (r.get('description') or '').replace('\n', ' ')
            labels.append(r.get('name', 'Kanal') + (f' - {desc[:70]}' if desc else ''))

        idx = xbmcgui.Dialog().select('Passenden Kanal auswaehlen', labels)
        if idx < 0:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return

        target_genre = genre_id or self._select_genre('')
        if not target_genre:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return

        ok, msg = add_channel_from_search_result(results[idx], target_genre)
        xbmcgui.Dialog().notification('Kanalverwaltung', msg, xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _channel_add(self, genre_id=''):
        url = xbmcgui.Dialog().input('YouTube Kanal URL, Handle oder UC-ID', type=xbmcgui.INPUT_ALPHANUM)
        if not url:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return
        target_genre = genre_id or self._select_genre('')
        if not target_genre:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False); return
        ok, msg = add_channel_from_url(url, target_genre)
        xbmcgui.Dialog().notification('Kanalverwaltung', msg, xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _user_channels(self):
        return [c for c in get_all_channels() if c.get('user_added')]

    def _channel_delete_menu(self):
        xbmcplugin.setPluginCategory(self.handle, 'Kanal loeschen')
        for ch in self._user_channels():
            self._add_dir(ch.get('name', 'Kanal'), 'channel_delete', _channel_icon(ch), ch.get('genre', ''), channel_id=ch.get('id', ''))
        xbmcplugin.endOfDirectory(self.handle)

    def _channel_delete(self, channel_id):
        if xbmcgui.Dialog().yesno('Kanal loeschen', 'Diesen selbst hinzugefuegten Kanal wirklich loeschen?'):
            delete_user_channel(channel_id)
            xbmcgui.Dialog().notification('Kanalverwaltung', 'Kanal geloescht', xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _channel_move_menu(self):
        xbmcplugin.setPluginCategory(self.handle, 'Kanal verschieben')
        for ch in self._user_channels():
            self._add_dir(ch.get('name', 'Kanal'), 'channel_move', _channel_icon(ch), ch.get('genre', ''), channel_id=ch.get('id', ''))
        xbmcplugin.endOfDirectory(self.handle)

    def _channel_move(self, channel_id):
        genre_id = self._select_genre('')
        if genre_id:
            move_user_channel(channel_id, genre_id)
            xbmcgui.Dialog().notification('Kanalverwaltung', 'Kanal verschoben', xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _backup_export(self):
        path = export_backup()
        xbmcgui.Dialog().notification('Backup', 'Backup erstellt' if path else 'Backup fehlgeschlagen', xbmcgui.NOTIFICATION_INFO if path else xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _backup_import(self):
        ok = import_backup()
        xbmcgui.Dialog().notification('Backup', 'Backup importiert' if ok else 'Kein Backup gefunden', xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def _add_video(self, v, genre_id, show_add=True, show_remove=False):
        vid = v.get('youtube_id', '')
        title = v.get('title', '')
        thumb = v.get('thumb', '') or f'https://i.ytimg.com/vi/{vid}/sddefault.jpg'
        year = v.get('year', 0)
        desc = v.get('description', '')
        ch = v.get('channel', '')
        label = title + (f'  [COLOR gray][{ch}][/COLOR]' if ch else '')
        li = xbmcgui.ListItem(label=label)
        tag = li.getVideoInfoTag()
        tag.setTitle(title); tag.setPlot(desc); tag.setMediaType('movie')
        if year: tag.setYear(year)
        if ch: tag.setStudios([ch])
        li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': f'https://i.ytimg.com/vi/{vid}/hqdefault.jpg', 'icon': thumb})
        li.setProperty('IsPlayable', 'true')
        ctx = []
        already = is_favorite(genre_id, vid)
        if show_add and not already:
            ctx.append(('Als Favorit speichern', f'RunPlugin({self.url(mode="fav_add", genre_id=genre_id, youtube_id=vid, title=title, description=desc[:150], thumb=thumb, year=year, channel=ch)})'))
        if show_remove or already:
            ctx.append(('Aus Favoriten entfernen', f'RunPlugin({self.url(mode="fav_remove", genre_id=genre_id, youtube_id=vid)})'))
        if ctx: li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode='play', youtube_id=vid, title=title), li, isFolder=False)

    def _no_api_key(self):
        xbmcgui.Dialog().ok('YouTube API-Key fehlt', 'Bitte YouTube Data API v3 Key in den Addon-Einstellungen eintragen.')
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
