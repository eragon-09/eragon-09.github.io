"""
Favoritenverwaltung – eine JSON-Datei pro Genre.
Gespeichert im Kodi-Addon-Profil.
"""

import json, os
import xbmcaddon, xbmcvfs

_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _path(genre_id):
    return os.path.join(_PROFILE, f'favs_{genre_id}.json')


def _load(genre_id):
    p = _path(genre_id)
    if not os.path.exists(p):
        return []
    try:
        with open(p, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []


def _save(genre_id, films):
    os.makedirs(_PROFILE, exist_ok=True)
    with open(_path(genre_id), 'w', encoding='utf-8') as f:
        json.dump(films, f, ensure_ascii=False, indent=2)


def get(genre_id):
    return _load(genre_id)


def count(genre_id):
    return len(_load(genre_id))


def add(genre_id, film):
    """Gibt True zurück wenn hinzugefügt, False wenn bereits vorhanden."""
    films = _load(genre_id)
    if any(f['youtube_id'] == film['youtube_id'] for f in films):
        return False
    films.append(film)
    films.sort(key=lambda x: x.get('title', ''))
    _save(genre_id, films)
    return True


def remove(genre_id, youtube_id):
    films = _load(genre_id)
    new   = [f for f in films if f['youtube_id'] != youtube_id]
    _save(genre_id, new)
    return len(new) < len(films)


def is_favorite(genre_id, youtube_id):
    return any(f['youtube_id'] == youtube_id for f in _load(genre_id))


def total_count():
    """Gesamtanzahl aller gespeicherten Favoriten."""
    total = 0
    if os.path.exists(_PROFILE):
        for fn in os.listdir(_PROFILE):
            if fn.startswith('favs_') and fn.endswith('.json'):
                try:
                    with open(os.path.join(_PROFILE, fn), 'r', encoding='utf-8') as f:
                        total += len(json.load(f))
                except Exception:
                    pass
    return total
