"""Player fuer FlimmerBox DE - TiTanX Lab.

Optimierte Wiedergabe:
- Videoqualitaet: Auto, 2160p, 1440p, 1080p, 720p, 480p, 360p
- Audio-Modus: Auto, AAC, Opus, Kompatibilitaet, Nur Streams mit Audio
- Kompatibilitaetsmodus begrenzt problematische Streams auf robuste Werte
- Übergibt saubere Parameter an plugin.video.youtube und InputStream Adaptive

Wichtig:
Das offizielle YouTube-Addon entscheidet final ueber Manifest und Stream.
Dieses Modul setzt Vorgaben, reduziert riskante Kombinationen und loggt die Wahl.
"""

from urllib.parse import urlencode
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()

QUALITY_LABELS = [
    "Automatisch",
    "2160p (4K)",
    "1440p (2K)",
    "1080p",
    "720p",
    "480p",
    "360p",
]

QUALITY_HEIGHTS = {
    0: "",       # Auto
    1: "2160",
    2: "1440",
    3: "1080",
    4: "720",
    5: "480",
    6: "360",
}

AUDIO_LABELS = [
    "Automatisch",
    "AAC bevorzugen",
    "Opus bevorzugen",
    "Kompatibilitätsmodus",
    "Nur Streams mit Audio",
]


def _get_int_setting(setting_id, default=0):
    try:
        return int(ADDON.getSetting(setting_id) or str(default))
    except Exception:
        return default


def _get_bool_setting(setting_id, default=False):
    try:
        val = ADDON.getSetting(setting_id)
        if val == "":
            return default
        return val.lower() == "true"
    except Exception:
        return default


def get_stream_preferences():
    qidx = _get_int_setting("video_quality", 0)
    aidx = _get_int_setting("audio_mode", 3)
    fallback = _get_bool_setting("stream_fallback", True)
    safe = _get_bool_setting("safe_playback", True)

    if qidx < 0 or qidx >= len(QUALITY_LABELS):
        qidx = 0
    if aidx < 0 or aidx >= len(AUDIO_LABELS):
        aidx = 3

    height = QUALITY_HEIGHTS.get(qidx, "")
    label = QUALITY_LABELS[qidx]
    audio_label = AUDIO_LABELS[aidx]

    # Kompatibilitätsmodus: vermeidet häufiger problematische sehr hohe DASH-Kombinationen.
    # Auto bleibt Auto, aber feste 2160/1440 werden auf 1080 begrenzt, wenn Safe aktiv ist.
    if safe and aidx in (3, 4) and height in ("2160", "1440"):
        height = "1080"
        label = label + " -> 1080p kompatibel"

    return {
        "quality_label": label,
        "height": height,
        "audio_label": audio_label,
        "audio_mode": aidx,
        "fallback": fallback,
        "safe": safe,
    }


def build_youtube_url(youtube_id):
    prefs = get_stream_preferences()

    # Nur video_id uebergeben – YouTube-Addon entscheidet selbst
    # ueber Stream-Typ (DASH/HLS). Zusaetzliche Parameter wie
    # quality/max_height koennen HLS-Fehler ausloesen.
    params = {"video_id": youtube_id}

    return "plugin://plugin.video.youtube/play/?{}".format(urlencode(params)), prefs


def play(handle, youtube_id, title=""):
    if not youtube_id:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    url, prefs = build_youtube_url(youtube_id)

    xbmc.log(
        "TiTanX Lab Player: quality={} max_height={} audio={} fallback={} safe={}".format(
            prefs["quality_label"],
            prefs["height"] or "auto",
            prefs["audio_label"],
            prefs["fallback"],
            prefs["safe"],
        ),
        xbmc.LOGINFO
    )

    li = xbmcgui.ListItem(label=title or youtube_id, path=url)
    li.setProperty("IsPlayable", "true")

    xbmcplugin.setResolvedUrl(handle, True, li)
