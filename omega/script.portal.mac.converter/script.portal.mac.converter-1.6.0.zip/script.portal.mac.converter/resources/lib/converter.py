# -*- coding: utf-8 -*-
import json
import re
import os
import datetime
from urllib.parse import urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON      = xbmcaddon.Addon()
ADDON_ID   = ADDON.getAddonInfo("id")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))

# ── Pfade ────────────────────────────────────────────────────────────────────
BASE_DATA_DIR = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/")
IN_DIR        = xbmcvfs.translatePath(BASE_DATA_DIR + "1_TXT_Import/")
OUT_DIR       = xbmcvfs.translatePath(BASE_DATA_DIR + "2_JSON_Export/")
BACKUP_DIR    = xbmcvfs.translatePath(BASE_DATA_DIR + "2_JSON_Export/_Backup/")

# ── Regex ────────────────────────────────────────────────────────────────────
PORTAL_HTTP_RE = re.compile(r"(https?://[^\s\]\)\}\>\"']+)", re.IGNORECASE)
MAC_ANY_RE     = re.compile(r"([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})")

# Erkennt Ablaufdatum nach Exp / Expires / ᴇxᴘ / 𝐄𝐱𝐩 + Pfeil/Doppelpunkt
EXP_LINE_RE = re.compile(
    r"""
    (?:
        [Ee][Xx][Pp](?:ires?|iry)?
        |[\u0045\U0001D404\u1D07][^\s]{0,6}
    )
    \s*
    (?:[\u27a9\u27a4\u27a8:\-=]|\u2192)*
    \s*
    (?P<datestr>
        \d{1,2}[./]\d{1,2}[./]\d{4}
        |
        (?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|
           Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|
           Dec(?:ember)?)
        \s+\d{1,2},\s+\d{4}
        (?:,\s*\d{1,2}:\d{2}\s*[aApP][mM])?
    )
    """,
    re.VERBOSE | re.IGNORECASE
)

MONTH_MAP = {
    "january":1,"february":2,"march":3,"april":4,"may":5,"june":6,
    "july":7,"august":8,"september":9,"october":10,"november":11,"december":12,
    "jan":1,"feb":2,"mar":3,"apr":4,"jun":6,"jul":7,"aug":8,
    "sep":9,"oct":10,"nov":11,"dec":12,
}

# Interner Marker für den Start-Button (kein echter Dateiname)
_BTN_SENTINEL = "__START_BTN__"


# ── Hilfsfunktionen ──────────────────────────────────────────────────────────

def _dedupe_macs(mac_list):
    """Duplikate entfernen, Reihenfolge erhalten (kein set())."""
    seen   = set()
    result = []
    for mac in mac_list:
        key = mac.upper()
        if key not in seen:
            seen.add(key)
            result.append(key)
    return result


def _parse_exp_date(line):
    """
    Extrahiert das Ablaufdatum aus einer Textzeile.
    Unterstützt DD.MM.YYYY und 'Month DD, YYYY [Zeit]'.
    Gibt 'YYYY-MM-DD' zurück oder None wenn kein Datum gefunden.
    """
    m = EXP_LINE_RE.search(line)
    if not m:
        return None
    ds = m.group("datestr").strip()

    # Format 1: DD.MM.YYYY oder DD/MM/YYYY
    mf = re.match(r"(\d{1,2})[./](\d{1,2})[./](\d{4})", ds)
    if mf:
        try:
            return datetime.date(
                int(mf.group(3)), int(mf.group(2)), int(mf.group(1))
            ).strftime("%Y-%m-%d")
        except ValueError:
            return None

    # Format 2: Month DD, YYYY [optionale Uhrzeit]
    mf2 = re.match(
        r"(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?"
        r"|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?"
        r"|Dec(?:ember)?)\s+(\d{1,2}),\s+(\d{4})",
        ds, re.IGNORECASE
    )
    if mf2:
        try:
            mon = MONTH_MAP.get(mf2.group(1).lower()[:3])
            return datetime.date(
                int(mf2.group(3)), mon, int(mf2.group(2))
            ).strftime("%Y-%m-%d")
        except (ValueError, TypeError):
            return None
    return None


def _extract_exp_for_mac(mac, content):
    """
    Sucht in den Zeilen rund um eine MAC-Adresse nach einem Ablaufdatum.
    Schaut bis zu 5 Zeilen vor und nach der MAC-Zeile.
    """
    lines = content.splitlines()
    for i, line in enumerate(lines):
        if mac.upper() in line.upper():
            search_start = max(0, i - 5)
            search_end   = min(len(lines), i + 6)
            for nearby in lines[search_start:search_end]:
                exp = _parse_exp_date(nearby)
                if exp:
                    return exp
    return None


def _backup_file(path):
    """Erstellt Sicherungskopie mit Zeitstempel im _Backup-Ordner."""
    if not xbmcvfs.exists(path):
        return
    xbmcvfs.mkdirs(BACKUP_DIR)
    ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = os.path.basename(path)
    dst  = xbmcvfs.translatePath(BACKUP_DIR + f"{name}.{ts}.bak")
    xbmcvfs.copy(path, dst)


def _read_txt(path):
    """Liest TXT-Datei sicher als String."""
    try:
        f       = xbmcvfs.File(path, "r")
        content = f.read()
        f.close()
        if isinstance(content, bytes):
            content = content.decode("utf-8", "ignore")
        return content, None
    except Exception as e:
        return None, str(e)


# ── Konvertierlogik ──────────────────────────────────────────────────────────

def convert_one_txt(txt_path, ask_overwrite=True):
    """
    Liest eine TXT-Datei, extrahiert Portal-URL und MACs,
    schreibt JSON nach OUT_DIR.
    Rückgabe: (True, None) = Erfolg | (False, str) = Fehler | (False, None) = Abbruch
    """
    content, err = _read_txt(txt_path)
    if err:
        return False, f"Lesefehler: {err}"

    m = PORTAL_HTTP_RE.search(content)
    if not m:
        return False, ADDON.getLocalizedString(30030)

    portal_url = m.group(1).strip()

    raw_macs = MAC_ANY_RE.findall(content)
    if not raw_macs:
        return False, ADDON.getLocalizedString(30031)

    macs     = _dedupe_macs(raw_macs)
    host     = urlparse(portal_url).hostname or "portal"
    out_path = xbmcvfs.translatePath(OUT_DIR + f"{host}.json")

    if xbmcvfs.exists(out_path) and ask_overwrite:
        if not xbmcgui.Dialog().yesno(
            ADDON.getLocalizedString(30018),
            ADDON.getLocalizedString(30019).format(name=host)
        ):
            return False, None

    _backup_file(out_path)

    # Ablaufdatum pro MAC aus dem Umfeld der jeweiligen Zeile extrahieren
    mac_entries = []
    for mac in macs:
        exp = _extract_exp_for_mac(mac, content)
        mac_entries.append({"mac": mac, "exp": exp})

    data = {
        "portal": portal_url,
        "macs":   mac_entries
    }

    try:
        fw = xbmcvfs.File(out_path, "w")
        fw.write(json.dumps(data, indent=2, ensure_ascii=False))
        fw.close()
    except Exception as e:
        return False, f"Schreibfehler: {e}"

    xbmc.log(
        f"[{ADDON_ID}] Konvertiert: {os.path.basename(txt_path)}"
        f" -> {host}.json ({len(macs)} MACs)",
        xbmc.LOGINFO
    )
    return True, None


# ── UI ───────────────────────────────────────────────────────────────────────

class TitanConverterUI(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.addon            = ADDON
        self.current_mode     = "MAIN"
        self.options          = []        # echte Dateinamen (ohne Sentinel)
        self.selected_indices = []
        self.is_multi         = False
        self.is_delete        = False
        self.target_dir       = ""
        self.target_ext       = ""

    def onInit(self):
        self.container = self.getControl(100)
        self.open_main_menu()

    # ── UI-Helfer ────────────────────────────────────────────────────────────

    def _btn_label(self, focused=False):
        """
        Erzeugt das dynamische Start-Button-Label.
        focused=True  → helle, fette Darstellung (Fokus-Zustand)
        focused=False → gedämpfte Darstellung (nofocus-Zustand)
        Zeigt Anzahl markierter Dateien und passt Farbe an.
        """
        count = len(self.selected_indices)

        if self.is_delete:
            if count == 0:
                # Kein Fokus, nichts markiert → grau, kein Fettdruck
                return f"[COLOR grey]{self.addon.getLocalizedString(30032)}[/COLOR]"
            if focused:
                # Fokus + markiert → rot, fett = klar klickbar
                return (f"[B][COLOR red]"
                        f"{self.addon.getLocalizedString(30033).format(count=count)}"
                        f"[/COLOR][/B]")
            else:
                # Kein Fokus + markiert → gedämpftes rot
                return (f"[COLOR FF993333]"
                        f"{self.addon.getLocalizedString(30033).format(count=count)}"
                        f"[/COLOR]")
        else:
            if count == 0:
                # Kein Fokus, nichts markiert → grau, kein Fettdruck
                return f"[COLOR grey]{self.addon.getLocalizedString(30034)}[/COLOR]"
            if focused:
                # Fokus + markiert → lime, fett = klar klickbar
                return (f"[B][COLOR lime]"
                        f"{self.addon.getLocalizedString(30035).format(count=count)}"
                        f"[/COLOR][/B]")
            else:
                # Kein Fokus + markiert → gedämpftes grün
                return (f"[COLOR FF336633]"
                        f"{self.addon.getLocalizedString(30035).format(count=count)}"
                        f"[/COLOR]")

    def _separator_label(self):
        return "[COLOR grey]──────────────────────────────[/COLOR]"

    def set_ui(self, title_id, hint_id_or_text, options,
               is_multi=False, is_delete=False):
        title = (self.addon.getLocalizedString(title_id)
                 if isinstance(title_id, int) else title_id)
        hint  = (self.addon.getLocalizedString(hint_id_or_text)
                 if isinstance(hint_id_or_text, int) else hint_id_or_text)

        self.setProperty("dialog_title", title)
        self.setProperty("dialog_hint",  hint)

        self.options          = options
        self.is_multi         = is_multi
        self.is_delete        = is_delete
        self.selected_indices = []

        self.container.reset()

        if self.is_multi:
            # 1. Dateien zuerst
            for opt in self.options:
                display = "[COLOR grey][  ][/COLOR] " + opt
                self.container.addItem(xbmcgui.ListItem(display))
            # 2. Trennlinie
            self.container.addItem(xbmcgui.ListItem(self._separator_label()))
            # 3. Start-Button ganz unten
            self.container.addItem(xbmcgui.ListItem(self._btn_label(focused=False)))
        else:
            for opt in self.options:
                self.container.addItem(xbmcgui.ListItem(opt))

        self.container.selectItem(0)
        self.refresh_visuals()

    def _btn_index(self):
        """Index des Start-Buttons in der Kodi-Liste (letzter Eintrag)."""
        return len(self.options) + 1   # options + separator + button

    def _sep_index(self):
        """Index der Trennlinie."""
        return len(self.options)

    def refresh_visuals(self):
        if not self.container or not self.is_multi:
            return

        pos         = self.container.getSelectedPosition()
        btn_focused = (pos == self._btn_index())

        # Dateien aktualisieren
        for i, opt in enumerate(self.options):
            item   = self.container.getListItem(i)
            prefix = ("[COLOR gold][X][/COLOR] "
                      if i in self.selected_indices
                      else "[COLOR grey][  ][/COLOR] ")
            item.setLabel(prefix + opt)

        # Trennlinie bleibt konstant
        sep = self.container.getListItem(self._sep_index())
        sep.setLabel(self._separator_label())

        # Button-Label: fokus-abhängig hell (focus) oder gedämpft (nofocus)
        btn = self.container.getListItem(self._btn_index())
        btn.setLabel(self._btn_label(focused=btn_focused))

    # ── Menüs ────────────────────────────────────────────────────────────────

    def open_main_menu(self):
        self.current_mode = "MAIN"
        opts = [
            self.addon.getLocalizedString(30001),
            self.addon.getLocalizedString(30002),
            self.addon.getLocalizedString(30003),
            self.addon.getLocalizedString(30026),
            self.addon.getLocalizedString(30004),
        ]
        self.set_ui(30000, "Titan Converter Engine", opts)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN):
            xbmc.sleep(20)
            self.refresh_visuals()
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU,
                              xbmcgui.ACTION_NAV_BACK,
                              xbmcgui.ACTION_PARENT_DIR):
            if self.current_mode == "MAIN":
                self.close()
            else:
                self.open_main_menu()

    def onClick(self, controlId):
        pos = self.container.getSelectedPosition()

        if self.current_mode == "MAIN":
            if   pos == 0: self.mode_select_file(multi=False)
            elif pos == 1: self.mode_select_file(multi=True)
            elif pos == 2: self.mode_delete_type()
            elif pos == 3: self.show_manual()
            elif pos == 4: self.close()

        elif self.current_mode == "SELECT_SINGLE":
            self._convert_single(self.options[pos])

        elif self.current_mode in ("SELECT_MULTI", "DELETE_FILES"):
            sep_idx = self._sep_index()
            btn_idx = self._btn_index()

            if pos == sep_idx:
                # Trennlinie angeklickt → ignorieren
                return
            elif pos == btn_idx:
                # Start-Button angeklickt
                if not self.selected_indices:
                    xbmcgui.Dialog().ok(
                        self.addon.getLocalizedString(30000),
                        self.addon.getLocalizedString(30025)
                    )
                else:
                    self.execute_batch()
            else:
                # Datei-Eintrag → markieren/demarkieren
                idx = pos   # pos == Dateiindex (keine Vorzeile mehr)
                if idx in self.selected_indices:
                    self.selected_indices.remove(idx)
                else:
                    self.selected_indices.append(idx)
                self.refresh_visuals()

        elif self.current_mode == "DELETE_TYPE":
            if pos == 2:
                self.open_main_menu()
            else:
                self.mode_delete_files(pos)

    # ── Aktionen ─────────────────────────────────────────────────────────────

    def show_manual(self):
        header   = self.addon.getLocalizedString(30026)
        lang     = xbmc.getLanguage(xbmc.ISO_639_1)
        filename = "anleitung_de.txt" if lang == "de" else "anleitung_en.txt"
        path     = os.path.join(ADDON_PATH, "resources", "docs", filename)

        if xbmcvfs.exists(path):
            f       = xbmcvfs.File(path)
            content = f.read()
            f.close()
            if isinstance(content, bytes):
                content = content.decode("utf-8", "ignore")
        else:
            content = (f"Datei nicht gefunden / File not found:\n{filename}\n"
                       f"Pfad: resources/docs/")
        xbmcgui.Dialog().textviewer(header, content)

    def mode_select_file(self, multi=False):
        _, files = xbmcvfs.listdir(IN_DIR)
        files    = sorted(f for f in files if f.lower().endswith(".txt"))
        if not files:
            xbmcgui.Dialog().ok(
                self.addon.getLocalizedString(30000),
                self.addon.getLocalizedString(30024)
                + "\n\n[COLOR grey]Ordner: 1_TXT_Import[/COLOR]"
            )
            return
        self.current_mode = "SELECT_MULTI" if multi else "SELECT_SINGLE"
        self.set_ui(
            30007 if multi else 30005,
            30008 if multi else 30006,
            files,
            is_multi=multi
        )

    def mode_delete_type(self):
        self.current_mode = "DELETE_TYPE"
        opts = [
            self.addon.getLocalizedString(30011),
            self.addon.getLocalizedString(30012),
            self.addon.getLocalizedString(30013),
        ]
        self.set_ui(30009, 30010, opts)

    def mode_delete_files(self, type_idx):
        self.target_dir = IN_DIR  if type_idx == 0 else OUT_DIR
        self.target_ext = ".txt"  if type_idx == 0 else ".json"
        _, files = xbmcvfs.listdir(self.target_dir)
        files    = sorted(f for f in files if f.lower().endswith(self.target_ext))
        if not files:
            xbmcgui.Dialog().ok(
                self.addon.getLocalizedString(30000),
                self.addon.getLocalizedString(30024)
            )
            return
        self.current_mode = "DELETE_FILES"
        self.set_ui(30007, 30008, files, is_multi=True, is_delete=True)

    def _convert_single(self, filename):
        path    = xbmcvfs.translatePath(IN_DIR + filename)
        ok, err = convert_one_txt(path, ask_overwrite=True)
        if ok:
            xbmcgui.Dialog().ok(
                self.addon.getLocalizedString(30000),
                self.addon.getLocalizedString(30022)
            )
            self.open_main_menu()
        elif err:
            xbmcgui.Dialog().ok(
                self.addon.getLocalizedString(30000),
                f"[COLOR red]{err}[/COLOR]"
            )

    def execute_batch(self):
        if self.current_mode == "SELECT_MULTI":
            success = 0
            errors  = []
            for i in self.selected_indices:
                path    = xbmcvfs.translatePath(IN_DIR + self.options[i])
                ok, err = convert_one_txt(path, ask_overwrite=True)
                if ok:
                    success += 1
                elif err:
                    errors.append(f"- {self.options[i]}: {err}")

            msg = f"{success} {self.addon.getLocalizedString(30022)}"
            if errors:
                msg += "\n\n[COLOR red]Fehler:[/COLOR]\n" + "\n".join(errors)
            xbmcgui.Dialog().ok(self.addon.getLocalizedString(30000), msg)

        elif self.current_mode == "DELETE_FILES":
            count = len(self.selected_indices)
            if xbmcgui.Dialog().yesno(
                self.addon.getLocalizedString(30020),
                self.addon.getLocalizedString(30021).format(count=count)
            ):
                for i in self.selected_indices:
                    xbmcvfs.delete(
                        xbmcvfs.translatePath(self.target_dir + self.options[i])
                    )
                xbmcgui.Dialog().ok(
                    self.addon.getLocalizedString(30000),
                    self.addon.getLocalizedString(30023)
                )

        self.open_main_menu()


# ── Einstiegspunkt ───────────────────────────────────────────────────────────

def run_main_menu_loop():
    for d in (IN_DIR, OUT_DIR):
        if not xbmcvfs.exists(d):
            xbmcvfs.mkdirs(d)

    ui = TitanConverterUI(
        "script-portal-mac-converter.xml",
        ADDON_PATH,
        "Default"
    )
    ui.doModal()
    del ui
