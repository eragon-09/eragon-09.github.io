# -*- coding: utf-8 -*-
"""FullscreenVideo-Back: MultiEPG bei Vavoo-Wiedergabe, sonst normales Zurück."""
import xbmc
import xbmcgui


def _is_vavoo_playback(player, home):
    if not player.isPlayingVideo():
        return False
    if home.getProperty("VavooTVPlus.Playing") == "1":
        return True
    # Fallback: Abgleich über die Stream-URL
    session_url = home.getProperty("VavooTVPlus.PlayingURL")
    actual = player.getPlayingFile() or ""
    if not (session_url and actual):
        return False
    return (actual.split("|", 1)[0] == session_url.split("|", 1)[0]
            or (session_url.startswith("plugin://plugin.video.vavoo.tv.plus/")
                and actual.startswith("plugin://plugin.video.vavoo.tv.plus/")))


def main():
    try:
        if _is_vavoo_playback(xbmc.Player(), xbmcgui.Window(10000)):
            # Wiedergabe läuft im Hintergrund weiter, MultiEPG öffnet auf dem aktuellen Sender.
            xbmc.executebuiltin(
                "RunPlugin(plugin://plugin.video.vavoo.tv.plus/?action=favorites_epg&overlay=1)")
        else:
            xbmc.executebuiltin("Action(Back)")
    except Exception as exc:
        xbmc.log("[Vavoo TV Plus] EPG hotkey: %s" % exc, xbmc.LOGWARNING)
        xbmc.executebuiltin("Action(Back)")


if __name__ == "__main__":
    main()
