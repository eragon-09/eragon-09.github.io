# -*- coding: utf-8 -*-
"""Vavoo TV Guide: zeitproportionale, fernbedienbare Multi-EPG (1080p).

Das Fenster bringt alle Texturen selbst mit (resources/skins/Default/media) und
sieht deshalb unter jedem Kodi-Skin gleich aus. Raster, Fokusrahmen und
Jetzt-Linie werden hier dynamisch gezeichnet, die Kopf- und Infoleiste steht in
FavoritesEPG.xml.
"""
import datetime
import json
import math
import os
import re
import threading
from urllib.parse import quote

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.vavoo.tv.plus')
MEDIA = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'skins', 'Default', 'media')


def _tex(name):
    return os.path.join(MEDIA, name)


# ── Zuletzt gewählter Sender (dauerhaft im Add-on-Profil) ────────────────────
def _state_path():
    return os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
                        'multiepg_last_channel.json')


def load_last_channel():
    """Liefert {'url','name','group_file'} des zuletzt gewählten Senders oder {}."""
    try:
        with open(_state_path(), 'r', encoding='utf-8') as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def save_last_channel(url, name='', group_file=None):
    """Merkt sich den zuletzt gewählten/gespielten Sender.

    group_file=None behält die bekannte Gruppe, falls es derselbe Sender ist.
    """
    if not url:
        return
    try:
        old = load_last_channel()
        if group_file is None:
            same = (old.get('url', '').split('|', 1)[0] == url.split('|', 1)[0])
            group_file = old.get('group_file', '') if same else ''
        folder = os.path.dirname(_state_path())
        os.makedirs(folder, exist_ok=True)
        tmp = _state_path() + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as stream:
            json.dump({'url': url, 'name': name or '', 'group_file': group_file or ''},
                      stream, ensure_ascii=False)
        os.replace(tmp, _state_path())
    except Exception as exc:
        xbmc.log('VAVOO MultiEPG: Sender konnte nicht gemerkt werden: {}'.format(exc),
                 xbmc.LOGWARNING)


# ── Geometrie (1080p) ────────────────────────────────────────────────────────
ROWS = 10                       # gleichzeitig sichtbare Zeilen
PAGE_SIZE = 50                  # Sender je logischer Seite
LEFT = 12                       # linker Rand der Senderspalte
GRID_X, GRID_W = 350, 1560      # Raster: x-Start und Breite
TOP, ROW_H = 256, 56            # erste Zeile, Zeilenhöhe
PX_PER_MIN = 7.6                # 30 min = 228 px
VIEW_MIN = int(GRID_W / PX_PER_MIN)   # sichtbare Minuten (~205)
LEAD_MIN = 15                   # Vorlauf links vor dem ersten Zeitstempel
STEP_MIN = 30                   # Scroll-Schritt
RULER_Y = 176                   # Uhrzeiten in der Zeitleiste
LINE_TOP, LINE_BOTTOM = 218, 846

OFFSET_MIN, OFFSET_MAX = -48, 96    # Scrollgrenze in 30-min-Schritten

WEEKDAYS = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag']

# Kodi-Aktions-IDs
ACT_LEFT, ACT_RIGHT, ACT_UP, ACT_DOWN = 1, 2, 3, 4
ACT_PAGE_UP, ACT_PAGE_DOWN = 5, 6
ACT_CLOSE = (9, 10, 92, 216)    # PARENT_DIR, PREVIOUS_MENU, NAV_BACK, BACKSPACE

HEADER_IDS = (10, 11, 12, 13)


def _programmes(api, channel):
    """Findet die EPG-Einträge eines Senders (tvg_id, Name, normalisiert, EPG-Mapping)."""
    cache = api._epg_cache
    lookup = getattr(api, '_epg_lookup', {})

    def norm(value):
        return re.sub(r'[^a-z0-9]', '', (value or '').lower())

    # Bevorzugt die gepruefte XMLTV-ID; fremde/numerische tvg-IDs
    # aus alten Favoritenlisten duerfen die korrekte Zuordnung nicht verdecken.
    try:
        mapped = api.get_channel_epg_id(channel.get('name', ''))
        if mapped and cache.get(mapped):
            return cache[mapped]
    except Exception:
        pass

    for key in (channel.get('tvg_id'), channel.get('name')):
        if not key:
            continue
        if key in cache:
            return cache[key]
        found = lookup.get(norm(key))
        if found in cache:
            return cache[found]
    try:
        mapped = api.get_channel_epg_id(channel.get('name', ''))
        if mapped and mapped in cache:
            return cache[mapped]
    except Exception:
        pass
    return []


class FavoritesEPG(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.gf = kwargs['groups_module']
        self._repair_callback = kwargs['repair_callback']
        self._sender_dialog_active = False
        self.api = kwargs['api']
        from epg_group_data import visible_groups
        self.groups = visible_groups(self.gf.load_groups())
        self.group_index = -1          # -1 = Alle Favoriten, -2 = VAVOO Channels
        self.start_url = kwargs.get('start_url', '')
        self.jump_to_playing = kwargs.get('jump_to_playing', False)
        start_file = kwargs.get('start_file', '')
        self._last_group_file = ''
        # Ohne ausdrücklichen Sender/Gruppe: zuletzt gewählten Sender wieder markieren,
        # auch wenn er in einer anderen Gruppe liegt.
        if not self.start_url and not start_file:
            last = load_last_channel()
            if last.get('url'):
                self.start_url = last['url']
                self._last_group_file = last.get('group_file', '')
                self.jump_to_playing = True
        # Zuletzt gewählte Gruppe dauerhaft im Kodi-Add-on-Profil merken.
        # Der Dateiname ist stabil, auch wenn Gruppen umsortiert werden.
        try:
            saved_file = ADDON.getSetting('multiepg_last_group_file')
        except Exception:
            saved_file = ''
        requested_file = start_file or saved_file
        if requested_file == '__vavoo_channels__':
            self.group_index = -2
        for i, g in enumerate(self.groups):
            if requested_file and g.get('file') == requested_file:
                self.group_index = i
                break
        # Ein expliziter Start über das Kontextmenü gilt ebenfalls als Auswahl.
        if start_file and self.group_index >= 0:
            self._save_group_selection()

        self.offset = 0                # in 30-min-Schritten
        self.page = 0
        self.scroll_top = 0
        self.channels = []
        self.group_headers = []
        self.chosen = None
        self.dynamic = []              # alle dynamisch erzeugten Controls
        self.rows = []                 # pro sichtbarer Zeile: {'channel','progs','cells'}
        self.cellmap = {}              # controlId -> (row, col)
        self.selected_row = 0
        self.selected_col = 0
        self.sel_time = None           # Zeitanker für Auf/Ab-Navigation
        self.time_origin = None        # Zeitraster bleibt beim vertikalen Scrollen stabil
        self._focus_keeper = None      # fester Fokus beim Austausch der Zeilen
        self._programmatic_focus = None
        self.view_start = None
        self.view_end = None
        self.row_hl = self.now_line = self.now_marker = None
        self.frame = []
        self._progs = {}
        self._pending = []
        self._old_dynamic = []
        self._sel_key = None
        self._stop = threading.Event()
        self.utc_shift = datetime.datetime.utcnow() - datetime.datetime.now()


    def _save_group_selection(self):
        """Speichert die gewählte Liste; leerer Wert steht für Alle Favoriten."""
        group_file = (self.groups[self.group_index].get('file', '')
                      if self.group_index >= 0 else
                      ('__vavoo_channels__' if self.group_index == -2 else ''))
        try:
            ADDON.setSetting('multiepg_last_group_file', group_file)
        except Exception as exc:
            xbmc.log('VAVOO MultiEPG: Auswahl konnte nicht gespeichert werden: {}'.format(exc),
                     xbmc.LOGWARNING)
    # ── Lebenszyklus ────────────────────────────────────────────────────────
    def onInit(self):
        self._load_channels()
        if self.start_url:
            index = self._find_start_channel()
            if index is not None:
                self.page, within = divmod(index, PAGE_SIZE)
                page_len = min(PAGE_SIZE, len(self.channels) - self.page * PAGE_SIZE)
                self.scroll_top = max(0, min(within - ROWS // 2, page_len - ROWS))
                self.selected_row = within - self.scroll_top
            self.start_url = ''
        self.sel_time = datetime.datetime.now()
        self.time_origin = self.sel_time.replace(minute=(self.sel_time.minute // 30) * 30,
                                                 second=0, microsecond=0)
        # Bleibt beim Neuzeichnen bestehen: Kodi springt dadurch nicht kurz
        # auf den ersten EPG-Button der neu aufgebauten Liste.
        self._focus_keeper = xbmcgui.ControlButton(
            LEFT, TOP, 2, 2, '', focusTexture=_tex('white.png'),
            noFocusTexture=_tex('white.png'))
        self.addControl(self._focus_keeper)
        self._focus_keeper.setVisible(False)
        self._render()
        self._focus_cell()
        if not getattr(self, '_ticker', None):
            self._ticker = threading.Thread(target=self._tick, daemon=True)
            self._ticker.start()

    def close(self):
        self._stop.set()
        super().close()

    def _tick(self):
        """Uhr und Jetzt-Linie alle 15 s nachführen."""
        while not self._stop.wait(15):
            if self._sender_dialog_active:
                continue
            try:
                self._update_clock()
                self._place_now()
            except Exception:
                continue    # z. B. während eines Neuaufbaus; nächster Takt klappt wieder

    # ── Daten ───────────────────────────────────────────────────────────────
    def _load_channels(self):
        from epg_group_data import favorite_channels, vavoo_channels
        if self.group_index == -2:
            try:
                self.channels = vavoo_channels(ADDON)
            except Exception as exc:
                xbmc.log('VAVOO MultiEPG Channel Browser: {}'.format(exc), xbmc.LOGWARNING)
                self.channels = []
            self.group_headers = []
            self.page = self.scroll_top = self.selected_row = self.selected_col = 0
            return
        self.channels = favorite_channels(self.gf, self.groups, self.group_index)
        self.group_headers = [i for i, ch in enumerate(self.channels) if ch.get('_header')]
        if self.group_index == -1:
            try:
                self.gf.rebuild_all_favorites_m3u(self.groups)
            except Exception as exc:
                xbmc.log('VAVOO: Gesamt-M3U: {}'.format(exc), xbmc.LOGWARNING)
        self.page = 0
        self.scroll_top = 0
        self.selected_row = 0
        self.selected_col = 0

    def _find_start_channel(self):
        """Find the playing channel in the current group or across all bouquets."""
        def locate():
            wanted = self.start_url.split("|", 1)[0].strip()
            for i, channel in enumerate(self.channels):
                if channel.get('_header'):
                    continue
                if channel.get("url", "").split("|", 1)[0].strip() == wanted:
                    return i
            return None

        found = locate()
        if found is not None or not self.jump_to_playing:
            return found
        # Nur die aktuelle Ansicht wechseln, nie die gespeicherte Gruppenwahl ändern.
        if self._last_group_file:
            for i, g in enumerate(self.groups):
                if g.get('file') == self._last_group_file:
                    self.group_index = i
                    self._load_channels()
                    found = locate()
                    if found is not None:
                        return found
                    break
        self.group_index = -1
        self._load_channels()
        return locate()

    def _local_progs(self, channel):
        """EPG-Liste eines Senders in Ortszeit, sortiert (pro Sender gecacht)."""
        key = channel.get('url') or channel.get('name')
        if key not in self._progs:
            out = []
            for start, stop, title, desc in _programmes(self.api, channel):
                if start and stop:
                    out.append((start - self.utc_shift, stop - self.utc_shift, title or '', desc or ''))
            out.sort(key=lambda p: p[0])
            self._progs[key] = out
        return self._progs[key]

    # ── Zeichnen ────────────────────────────────────────────────────────────
    def _clear(self):
        # Double buffering: alte EPG-Zeilen sichtbar lassen, bis die neuen
        # Controls in einem einzigen Kodi-Aufruf bereitstehen.
        if self._old_dynamic:
            self.removeControls(self._old_dynamic)
        self._old_dynamic = self.dynamic
        self.dynamic = []
        self.rows = []
        self.cellmap = {}
        self.frame = []
        self._pending = []
        self._sel_key = None
        self.row_hl = self.now_line = self.now_marker = None

    def _add(self, control):
        # Controls sammeln und am Ende in EINEM Aufruf hinzufügen (viel schneller als einzeln)
        self._pending.append(control)
        return control

    def _flush(self):
        if self._pending:
            self.addControls(self._pending)
            self.dynamic.extend(self._pending)
            self._pending = []
        # Erst jetzt die alte Darstellung entfernen, um Schwarzblenden beim
        # zeilenweisen Scrollen zu vermeiden.
        if self._old_dynamic:
            self.removeControls(self._old_dynamic)
            self._old_dynamic = []

    def _label(self, x, y, w, h, text, color='FFE5EAF2', font='font13', align=4):
        return self._add(xbmcgui.ControlLabel(x, y, w, h, str(text), font=font,
                                              textColor=color, alignment=align))

    def _rect(self, x, y, w, h, color, texture='white.png'):
        return self._add(xbmcgui.ControlImage(x, y, w, h, _tex(texture), colorDiffuse=color))

    def _x(self, t):
        return GRID_X + int((t - self.view_start).total_seconds() / 60 * PX_PER_MIN)

    def _tick0(self, now):
        base = self.time_origin or now.replace(minute=(now.minute // 30) * 30,
                                                second=0, microsecond=0)
        return base - datetime.timedelta(minutes=30) + datetime.timedelta(minutes=STEP_MIN * self.offset)

    def _render(self):
        self._clear()
        now = datetime.datetime.now().replace(microsecond=0)
        tick0 = self._tick0(now)
        self.view_start = tick0 - datetime.timedelta(minutes=LEAD_MIN)
        self.view_end = self.view_start + datetime.timedelta(minutes=VIEW_MIN)

        name = ('VAVOO Channels' if self.group_index == -2 else
                ('Alle Favoriten' if self.group_index == -1 else
                 self.groups[self.group_index]['name']))
        self.getControl(10).setLabel(name)
        total_pages = max(1, (len(self.channels) + PAGE_SIZE - 1) // PAGE_SIZE)
        total_senders = sum(not ch.get('_header') for ch in self.channels)
        self.getControl(30).setLabel('Seite {}/{} · {} Sender'.format(
            self.page + 1, total_pages, total_senders))
        self._update_clock()

        # Zeitleiste mit Teilstrichen
        for i in range(7):
            t = tick0 + datetime.timedelta(minutes=30 * i)
            x = self._x(t)
            if GRID_X - 40 <= x <= GRID_X + GRID_W + 20:
                self._label(x - 70, RULER_Y, 140, 30, t.strftime('%H:%M'), 'FFFFFFFF', align=2)
                self._rect(x - 1, RULER_Y + 32, 2, 12, 'FF9AA8BD')

        # Zeilen-Highlight des gewählten Senders (liegt unter den Sendernamen)
        self.row_hl = self._rect(LEFT - 4, TOP, GRID_X - LEFT - 2, ROW_H - 2, 'FFD40F1F')

        page_channels = self.channels[self.page * PAGE_SIZE + self.scroll_top:self.page * PAGE_SIZE + self.scroll_top + ROWS]
        for row, channel in enumerate(page_channels):
            y = TOP + row * ROW_H
            if channel.get('_header'):
                self._rect(LEFT, y + 2, GRID_X + GRID_W - LEFT, ROW_H - 4,
                           'EE101B2B', 'white.png')
                if channel.get('logo'):
                    self._add(xbmcgui.ControlImage(LEFT + 12, y + 7, 48, 42,
                                                   channel['logo'], aspectRatio=2))
                self._label(LEFT + 76, y, 920, ROW_H - 2,
                            '── {} ──'.format(channel['name']), 'FFFFFFFF')
                self.rows.append({'channel': channel, 'progs': [], 'cells': []})
                continue
            self._rect(LEFT, y + ROW_H - 1, GRID_X - LEFT - 6, 1, 'FF28344A')
            if channel.get('logo'):
                self._add(xbmcgui.ControlImage(LEFT + 10, y + 7, 56, 42, channel['logo'], aspectRatio=2))
            self._label(LEFT + 78, y, GRID_X - LEFT - 96, ROW_H - 2, channel.get('name', ''),
                        'FFFFFFFF', align=4)

            progs = self._local_progs(channel)
            visible = [p for p in progs if p[1] > self.view_start and p[0] < self.view_end]
            if not visible:
                visible = [(self.view_start, self.view_end, 'Keine EPG-Daten', '')]
            cells = []
            for start, stop, title, desc in visible:
                a = max(self.view_start, start)
                b = min(self.view_end, stop)
                x = self._x(a)
                w = self._x(b) - x - 4
                if w < 14:
                    continue
                has_data = title != 'Keine EPG-Daten'
                if has_data and stop <= now:
                    skin, text_color = 'cell_gray', 'FFB4BDC9'      # abgelaufen: Schiefergrau
                elif has_data and start <= now:
                    skin, text_color = 'cell_green', 'FFFFFFFF'     # läuft gerade
                else:
                    skin, text_color = 'cell_blue', 'FFFFFFFF'      # kommt noch
                btn = xbmcgui.ControlButton(
                    x, y + 3, w, ROW_H - 6, title or 'Ohne Titel',
                    focusTexture=_tex(skin + '_focus.png'), noFocusTexture=_tex(skin + '.png'),
                    textOffsetX=14, alignment=4, font='font13',
                    textColor=text_color, focusedColor='FFFFFFFF')
                self._add(btn)
                cells.append({'btn': btn, 'prog': (start, stop, title, desc)})
            self.rows.append({'channel': channel, 'progs': progs, 'cells': cells})

        # Jetzt-Linie, Marke und Fokusrahmen (über allem) anlegen, dann alles auf einmal hinzufügen
        self.now_line = self._rect(0, LINE_TOP, 3, LINE_BOTTOM - LINE_TOP, 'FFFF263D')
        self.now_marker = self._add(xbmcgui.ControlImage(0, LINE_TOP - 14, 18, 14, _tex('now_marker.png')))
        self.frame = [self._rect(0, 0, 1, 1, 'FFFFFFFF') for _ in range(4)]
        # Markierung und Fokusrahmen VOR dem Einblenden an die Zielposition setzen,
        # sonst blitzt die rote Zeile kurz oben (Zeile 1) auf.
        preselected = self._preselect()
        self._flush()

        # Eigene Navigation: Kodi soll den Fokus nicht selbst verschieben
        for r, row in enumerate(self.rows):
            for c, cell in enumerate(row['cells']):
                b = cell['btn']
                b.setNavigation(b, b, b, b)
                self.cellmap[b.getId()] = (r, c)
        if not preselected:
            for f in self.frame:
                f.setVisible(False)
        self._place_now()

    def _preselect(self):
        """Zeilenmarkierung und Rahmen schon vor dem Einblenden positionieren."""
        try:
            if not self.rows:
                return False
            row = max(0, min(self.selected_row, len(self.rows) - 1))
            if not self.rows[row]['cells']:
                positions = [i for i, r in enumerate(self.rows) if r['cells']]
                if not positions:
                    return False
                row = min(positions, key=lambda i: abs(i - row))
            idx = self._cell_index_at(row, self.sel_time or datetime.datetime.now())
            if idx < 0:
                return False
            self.selected_row = row
            self.row_hl.setPosition(LEFT - 4, TOP + row * ROW_H)
            self._place_frame(self.rows[row]['cells'][idx]['btn'])
            return True
        except Exception:
            return False

    def _place_now(self):
        if not (self.now_line and self.now_marker and self.view_start):
            return
        now = datetime.datetime.now()
        visible = self.view_start <= now <= self.view_end
        if visible:
            x = self._x(now)
            self.now_line.setPosition(x - 1, LINE_TOP)
            self.now_marker.setPosition(x - 9, LINE_TOP - 14)
        self.now_line.setVisible(visible)
        self.now_marker.setVisible(visible)

    def _update_clock(self):
        now = datetime.datetime.now()
        self.getControl(31).setLabel('{} · {}'.format(WEEKDAYS[now.weekday()], now.strftime('%d.%m.%Y')))
        self.getControl(32).setLabel(now.strftime('%H:%M') + ' Uhr')

    def _place_frame(self, btn):
        x, y = btn.getX(), btn.getY()
        w, h = btn.getWidth(), btn.getHeight()
        t = 3
        parts = [(x, y, w, t), (x, y + h - t, w, t), (x, y, t, h), (x + w - t, y, t, h)]
        for ctl, (px, py, pw, ph) in zip(self.frame, parts):
            ctl.setPosition(px, py)
            ctl.setWidth(pw)
            ctl.setHeight(ph)
            ctl.setVisible(True)

    # ── Auswahl und Infoleiste ──────────────────────────────────────────────
    def _select(self, row, col):
        if not (0 <= row < len(self.rows)) or not self.rows[row]['cells']:
            return
        cells = self.rows[row]['cells']
        col = max(0, min(col, len(cells) - 1))
        key = cells[col]['btn'].getId()
        if key == self._sel_key:      # schon ausgewählt (onFocus nach setFocus): nichts doppelt tun
            return
        self._sel_key = key
        self.selected_row, self.selected_col = row, col
        if self.row_hl:
            self.row_hl.setPosition(LEFT - 4, TOP + row * ROW_H)
        if self.frame:
            self._place_frame(cells[col]['btn'])
        self._details()

    def _details(self):
        if not self.rows:
            self._set_info('Keine Sender', '', '', None, '', '')
            return
        row = self.rows[self.selected_row]
        cells = row['cells']
        if not cells:
            return
        start, stop, title, desc = cells[min(self.selected_col, len(cells) - 1)]['prog']
        channel = row['channel']
        now = datetime.datetime.now()
        times = '{} – {}'.format(start.strftime('%H:%M'), stop.strftime('%H:%M'))
        if title == 'Keine EPG-Daten':
            times = ''
        elif start <= now < stop:
            left = max(1, int((stop - now).total_seconds() // 60))
            times += '  ·  läuft, noch {} Min.'.format(left)
        nxt_time = nxt_title = ''
        for s, e, t, _d in row['progs']:
            if s >= stop:
                nxt_time = '{} – {}'.format(s.strftime('%H:%M'), e.strftime('%H:%M'))
                nxt_title = t
                break
        self._set_info(title or 'Ohne Titel', times,
                       (desc or 'Keine Beschreibung vorhanden')[:320] if title != 'Keine EPG-Daten' else '',
                       channel, nxt_time, nxt_title)

    def _set_info(self, title, times, desc, channel, nxt_time, nxt_title):
        self.getControl(40).setLabel(title)
        self.getControl(41).setLabel(times)
        self.getControl(42).setText(desc)
        self.getControl(43).setImage((channel or {}).get('logo') or '', False)
        self.getControl(44).setLabel((channel or {}).get('name', ''))
        self.getControl(51).setLabel(nxt_time)
        self.getControl(52).setLabel(nxt_title)

    def _cell_index_at(self, row, t):
        cells = self.rows[row]['cells']
        if not cells:
            return -1
        for i, cell in enumerate(cells):
            s, e = cell['prog'][0], cell['prog'][1]
            if s <= t < e:
                return i
        return min(range(len(cells)),
                   key=lambda i: abs((cells[i]['prog'][0] - t).total_seconds()))

    def _focus_cell(self):
        """Fokus auf die Sendung der gewählten Zeile zum Zeitanker setzen."""
        if not self.rows:
            self.setFocusId(10)
            return
        self.selected_row = max(0, min(self.selected_row, len(self.rows) - 1))
        if not self.rows[self.selected_row]['cells']:
            positions = [i for i, row in enumerate(self.rows) if row['cells']]
            if not positions:
                self.setFocusId(10)
                return
            self.selected_row = min(positions, key=lambda i: abs(i - self.selected_row))
        idx = self._cell_index_at(self.selected_row, self.sel_time or datetime.datetime.now())
        if idx < 0:
            self.setFocusId(10)
            return
        self._select(self.selected_row, idx)
        button = self.rows[self.selected_row]['cells'][idx]['btn']
        self._programmatic_focus = button.getId()
        self.setFocus(button)

    def _focus_live_cell(self):
        """Vertikal immer die jetzt laufende Sendung fokussieren.

        Links/Rechts dürfen die Zeitposition verändern; Hoch/Runter stellt
        den Jetzt-Bezug wieder her. Ohne EPG wird die Ersatzkachel gewählt.
        """
        now = datetime.datetime.now().replace(microsecond=0)
        self.sel_time = now
        if self.offset != 0 or not (self.view_start <= now < self.view_end):
            self.offset = 0
            self._rerender()
        else:
            self._focus_cell()

    def _anchor(self, prog):
        return max(prog[0], self.view_start) + datetime.timedelta(seconds=1)

    def _rerender(self, focus_cell=True):
        self.offset = max(OFFSET_MIN, min(OFFSET_MAX, self.offset))
        # Fokus vor dem Entfernen des aktiven Buttons auf einen dauerhaften,
        # unsichtbaren Button am selben Ort übertragen.
        if self._focus_keeper and self.getFocusId() in self.cellmap:
            active = self.getControl(self.getFocusId())
            self._focus_keeper.setPosition(active.getX(), active.getY())
            self._focus_keeper.setWidth(active.getWidth())
            self._focus_keeper.setHeight(active.getHeight())
            self._programmatic_focus = self._focus_keeper.getId()
            self.setFocus(self._focus_keeper)
        self._render()
        if focus_cell:
            self._focus_cell()

    # ── Eingaben ────────────────────────────────────────────────────────────
    def onFocus(self, controlId):
        # Maus oder direkter Fokuswechsel: Auswahl nachziehen
        if controlId == self._programmatic_focus:
            self._programmatic_focus = None
            return
        if controlId in self.cellmap:
            row, col = self.cellmap[controlId]
            self.sel_time = self._anchor(self.rows[row]['cells'][col]['prog'])
            self._select(row, col)

    def onClick(self, controlId):
        if self._sender_dialog_active:
            return
        if controlId == 10:
            options = ['Alle Favoriten'] + [g['name'] for g in self.groups] + ['VAVOO Channels']
            choice = xbmcgui.Dialog().select('Sendergruppe wählen', options,
                                             preselect=(len(options) - 1 if self.group_index == -2
                                                        else self.group_index + 1))
            if choice >= 0:
                self.group_index = -2 if choice == len(options)-1 else choice - 1
                self._save_group_selection()
                self._load_channels()
                self._rerender(focus_cell=False)
            self.setFocusId(10)
        elif controlId in (11, 13):
            self.offset += -2 if controlId == 11 else 2
            self.sel_time = None
            self._rerender(focus_cell=False)
            self.setFocusId(controlId)
        elif controlId == 12:
            self.offset = 0
            self.sel_time = datetime.datetime.now()
            self.time_origin = self.sel_time.replace(minute=(self.sel_time.minute // 30) * 30,
                                                     second=0, microsecond=0)
            self._rerender(focus_cell=False)
            self.setFocusId(12)
        elif controlId in self.cellmap:
            row, _col = self.cellmap[controlId]
            self.chosen = self.rows[row]['channel']
            save_last_channel(self.chosen.get('url', ''), self.chosen.get('name', ''),
                              self.chosen.get('_group_file', ''))
            self.close()

    def _context_actions(self):
        """Senderaktionen, ohne die EPG-Zeitachse oder Navigation zu verändern."""
        focus = self.getFocusId()
        if focus not in self.cellmap:
            return
        row, _ = self.cellmap[focus]
        channel = self.rows[row]['channel']
        from epg_sender_actions import context_actions
        self._sender_dialog_active = True
        try:
            operation = context_actions(self.gf, self.groups, channel, self._repair_callback)
        finally:
            self._sender_dialog_active = False
        if not operation:
            return
        # Auswahl möglichst auf dem bearbeiteten Sender halten.
        old_absolute = self.page * PAGE_SIZE + self.scroll_top + row
        old_url = channel.get('url')
        self._load_channels()
        if operation != 'remove':
            new_absolute = next((i for i, ch in enumerate(self.channels)
                                 if ch.get('url') == old_url and ch.get('_group_file', '') == channel.get('_group_file', '') and not ch.get('_header')),
                                min(old_absolute, len(self.channels) - 1))
        else:
            new_absolute = min(old_absolute, len(self.channels) - 1)
        if new_absolute >= 0:
            self.page, within = divmod(new_absolute, PAGE_SIZE)
            self.scroll_top = max(0, within - min(row, ROWS - 1))
            self.selected_row = within - self.scroll_top
        self._rerender()

    def onAction(self, action):
        if self._sender_dialog_active:
            return
        code = action.getId()
        if code in ACT_CLOSE:
            self.close()
            return
        if code in (117, 101):  # Kodi Kontextmenü / Fernbedienung-Menütaste
            self._context_actions()
            return
        if code not in (ACT_LEFT, ACT_RIGHT, ACT_UP, ACT_DOWN, ACT_PAGE_UP, ACT_PAGE_DOWN):
            return
        focus = self.getFocusId()
        if focus in HEADER_IDS:
            if code == ACT_DOWN:
                self._focus_live_cell()
            return
        if focus not in self.cellmap:
            return
        row, col = self.cellmap[focus]
        cells = self.rows[row]['cells']
        cur = cells[col]['prog']

        if code in (ACT_UP, ACT_DOWN):
            step = -1 if code == ACT_UP else 1
            absolute = self.page * PAGE_SIZE + self.scroll_top + row + step
            while 0 <= absolute < len(self.channels) and self.channels[absolute].get('_header'):
                absolute += step
            if 0 <= absolute < len(self.channels):
                old_page, old_top = self.page, self.scroll_top
                self.page, within = divmod(absolute, PAGE_SIZE)
                page_length = min(PAGE_SIZE, len(self.channels) - self.page * PAGE_SIZE)
                if self.page != old_page:
                    self.scroll_top = 0 if step > 0 else max(0, page_length - ROWS)
                elif within < self.scroll_top:
                    self.scroll_top = within
                elif within >= self.scroll_top + ROWS:
                    self.scroll_top = within - ROWS + 1
                self.selected_row = within - self.scroll_top
                # Beim vertikalen Scrollen bleibt der gewählte Zeitpunkt
                # und die horizontale Position der Zeitachse unverändert.
                # Nur der sichtbare Senderausschnitt wird bei Bedarf erneuert.
                if self.page != old_page or self.scroll_top != old_top:
                    self._rerender()
                else:
                    self._focus_cell()
            elif code == ACT_UP:
                self.setFocusId(10)
            return

        if code in (ACT_PAGE_DOWN, ACT_PAGE_UP):
            direction = 1 if code == ACT_PAGE_DOWN else -1
            next_page = self.page + direction
            if 0 <= next_page * PAGE_SIZE < len(self.channels):
                self.page = next_page
                self.scroll_top = 0
                self.selected_row = 0
                # Auch beim Seitenwechsel die gewählte Zeit beibehalten.
                self._rerender()
            return

        if code == ACT_RIGHT:
            if col + 1 < len(cells):
                nxt = cells[col + 1]['prog']
                self.sel_time = self._anchor(nxt)
                limit = self.view_end - datetime.timedelta(minutes=25)
                if nxt[0] >= limit:      # Block liegt kaum noch im Bild: weiterscrollen
                    need = (nxt[0] - limit).total_seconds() / 60
                    self.offset += max(1, int(math.ceil(need / STEP_MIN)))
                    self.sel_time = nxt[0] + datetime.timedelta(seconds=1)
                    self._rerender()
                else:
                    self._select(row, col + 1)
                    self.setFocus(cells[col + 1]['btn'])
            else:
                self.sel_time = self.view_end + datetime.timedelta(seconds=1)
                self.offset += 1
                self._rerender()
        elif code == ACT_LEFT:
            if col > 0 and cells[col - 1]['prog'][1] > self.view_start:
                prev = cells[col - 1]['prog']
                self.sel_time = self._anchor(prev)
                self._select(row, col - 1)
                self.setFocus(cells[col - 1]['btn'])
            else:
                self.sel_time = max(cur[0], self.view_start) - datetime.timedelta(minutes=1)
                self.offset -= 1
                self._rerender()
