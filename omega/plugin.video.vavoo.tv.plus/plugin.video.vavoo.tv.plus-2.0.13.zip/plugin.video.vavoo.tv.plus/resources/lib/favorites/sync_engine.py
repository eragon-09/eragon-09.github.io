# -*- coding: utf-8 -*-
"""Synchronisation vorhandener Favoritensender mit dem Vavoo-Katalog.

Das Modul aktualisiert ausschliesslich technische Senderdaten. Gruppen- und
Senderreihenfolge bleiben erhalten. Datei-, Metadaten- und M3U-Zugriffe werden
als Abhaengigkeiten uebergeben, damit keine zyklischen Imports mit
``group_favs`` entstehen.
"""

import os
import re
import shutil
import time

import xbmc


def sync_name_key(value):
    """Erzeugt einen toleranten Vergleichsschluessel fuer Sendernamen."""
    value = (value or "").lower().strip()
    value = re.sub(r"\s*\(\d+\)\s*$", "", value)
    value = re.sub(r"\(backup(?:\s+\d+)?\)", " ", value)
    value = re.sub(r"\b(?:hevc|raw)\b", " ", value)
    value = value.replace("ß", "ss").replace("&", "und")
    # HD+ ist eine Bildqualitaet, waehrend 1+ im Sendernamen erhalten bleibt.
    value = re.sub(r"\b(?:uhd|4k|fhd|full\s*hd|hd|sd)\s*\+", " ", value)
    value = value.replace("+", "plus")
    # Nur eindeutig benannte Regionalvarianten vereinheitlichen.
    value = re.sub(r"\bwdr\s+(?:fernsehen\s+)?(?:hd\s+)?(?=aachen|bielefeld|bonn|dortmund|duisburg|duesseldorf|düsseldorf|essen|siegen|wuppertal|koeln|köln)", "wdr fernsehen ", value)
    value = value.replace("düsseldorf", "duesseldorf").replace("köln", "koeln")
    value = re.sub(r'\b(?:deutschland|germany|de|at|ch)\b', '', value)
    value = re.sub(r'\b(?:uhd|4k|fhd|full\s*hd|hd|sd|backup|quelle\s*\d+|stream\s*\d+|match\s*time)\b', '', value)
    value = re.sub(r'[^a-z0-9]+', '', value)

    aliases = {
        "sportdigital1plus": "sportdigital1plus",
        "sportdigital1": "sportdigital1plus",
        "sportdigitalfussball": "sportdigitalfussball",
        "sportdigitalfusball": "sportdigitalfussball",
        "sportdigitallfussball": "sportdigitalfussball",
        "sat1": "sat1",
        "satone": "sat1",
        "rtltelevision": "rtl",
        "rtl2": "rtlzwei",
        "rtlii": "rtlzwei",
        "prosieben": "prosieben",
        "pro7": "prosieben",
        "kabeleins": "kabeleins",
        "kabel1": "kabeleins",
    }
    # Varianten wie FUN, MAXX, DOKU und CLASSICS bleiben eigene Sender.
    # Ausschliesslich das Namenspraefix wird vereinheitlicht.
    for prefix, canonical in (
        ("prosieben", "prosieben"), ("pro7", "prosieben"),
        ("kabeleins", "kabeleins"), ("kabel1", "kabeleins"),
        ("rtlzwei", "rtlzwei"), ("rtl2", "rtlzwei"),
        ("rtlii", "rtlzwei"),
    ):
        if value.startswith(prefix):
            tail = value[len(prefix):]
            if not tail or tail in ("fun", "maxx", "doku", "classics"):
                return canonical + tail
    return aliases.get(value, value)


def candidate_score(name, preferred_name=""):
    """Bewertet Katalogtreffer. Hoehere Werte werden bevorzugt."""
    n = (name or "").lower()
    score = 0
    if "uhd" in n or "4k" in n:
        score += 60
    elif "fhd" in n or "full hd" in n:
        score += 50
    elif " hd" in " " + n or n.endswith("hd"):
        score += 35
    if any(x in n for x in ("backup", "match time", "test", "event")):
        score -= 30
    if preferred_name and sync_name_key(name) == sync_name_key(preferred_name):
        score += 15
    return score


def quality_from_name(value):
    """Ermittelt eine verständliche Qualitätsstufe aus einem Katalognamen."""
    text = (value or "").lower()
    if "uhd" in text or "4k" in text:
        return "Ultra HD (4K)"
    if "fhd" in text or "full hd" in text or "1080" in text:
        return "Full HD"
    if " hd" in " " + text or text.endswith("hd") or "720" in text:
        return "HD"
    return "SD"


def sync_group_channels(filename, live_channels, api_module=None,
                        max_candidates=0, validation_timeout=7,
                        validate_streams=True, defective_only=False,
                        progress_callback=None, group_index=1, group_total=1,
                        global_offset=0, global_total=0, only_index=None, *,
                        load_group_channels, load_source_meta, source_meta_key,
                        save_source_meta, profile_dir, group_m3u_path,
                        save_group_channels):
    """Aktualisiert technische Daten vorhandener Favoriten.

    Gruppen- und Senderreihenfolge bleiben exakt erhalten. Erreichbare
    HD/FHD-Kandidaten werden bevorzugt. Nicht gefundene oder nicht erreichbare
    Sender bleiben unveraendert. Vor Aenderungen wird eine Sicherung angelegt.
    """
    channels = load_group_channels(filename)
    source_meta = load_source_meta()
    selected_total = (
        1 if only_index is not None and 0 <= int(only_index) < len(channels)
        else len(channels)
    )
    result = {
        "total": selected_total,
        "updated": 0,
        "unchanged": 0,
        "missing": 0,
        "fallbacks": 0,
        "unreachable": 0,
        "backup": "",
    }
    if not channels or not live_channels:
        result["missing"] = selected_total
        return result

    by_name = {}
    by_epg = {}
    for live_name, raw_sources in live_channels.items():
        if isinstance(raw_sources, (str, dict)):
            raw_sources = [raw_sources]
        normalized_sources = []
        for source in (raw_sources or []):
            if isinstance(source, dict):
                url = (source.get("url") or "").strip()
                country = (source.get("country") or "").strip()
                quality = (source.get("quality") or "").strip()
            else:
                url = (source or "").strip()
                country = ""
                quality = ""
            if not url:
                continue
            normalized_sources.append({
                "url": url,
                "country": country,
                "quality": quality or quality_from_name(live_name),
            })
        urls = [item["url"] for item in normalized_sources]
        if not live_name or not urls:
            continue
        epg_id = ""
        if api_module is not None:
            try:
                epg_id = api_module.get_channel_epg_id(live_name) or ""
            except Exception:
                pass
        entry = {
            "name": live_name,
            "urls": urls,
            "tvg_id": epg_id,
            "source_details": {item["url"]: item for item in normalized_sources},
        }
        key = sync_name_key(live_name)
        if key:
            by_name.setdefault(key, []).append(entry)
        if epg_id:
            by_epg.setdefault(epg_id.lower(), []).append(entry)

    original_order = [ch.get("name", "") for ch in channels]
    checked_urls = {}
    current_channel_name = ""
    current_channel_index = 0

    def continue_progress(phase="sender", candidate_index=0, candidate_total=0):
        if progress_callback is None:
            return True
        try:
            return progress_callback({
                "phase": phase,
                "group_file": filename,
                "group_index": group_index,
                "group_total": group_total,
                "channel_name": current_channel_name,
                "channel_index": current_channel_index,
                "channel_total": selected_total,
                "global_index": global_offset + current_channel_index,
                "global_total": global_total,
                "candidate_index": candidate_index,
                "candidate_total": candidate_total,
            }) is not False
        except Exception as exc:
            xbmc.log(
                "[VavooTV] progress callback error: {}".format(exc),
                xbmc.LOGWARNING,
            )
            return True

    def is_working(url, candidate_index=0, candidate_total=0):
        """Resolve und strenger HLS-Check; jede Katalog-URL nur einmal."""
        if not continue_progress("candidate", candidate_index, candidate_total):
            return None
        normalized_url = (url or "").strip()
        if not normalized_url:
            return False
        if normalized_url in checked_urls:
            return checked_urls[normalized_url]
        ok = False
        if api_module is not None:
            try:
                stream_url, headers = api_module.resolve_stream(normalized_url)
                if stream_url:
                    validator = getattr(api_module, "validate_hls_stream", None)
                    if validator:
                        ok = bool(validator(
                            stream_url, headers, timeout=validation_timeout
                        ))
                    else:
                        try:
                            ok = bool(api_module.check_stream(
                                stream_url, headers, timeout=validation_timeout
                            ))
                        except TypeError:
                            ok = bool(api_module.check_stream(stream_url, headers))
                xbmc.log(
                    "[VavooTV] Sync-Kandidat {}: {}".format(
                        "OK" if ok else "DEFEKT", normalized_url
                    ),
                    xbmc.LOGINFO if ok else xbmc.LOGWARNING,
                )
            except Exception as exc:
                xbmc.log(
                    "[VavooTV] Kandidaten-Check fehlgeschlagen: {}".format(exc),
                    xbmc.LOGWARNING,
                )
        else:
            ok = True
        checked_urls[normalized_url] = ok
        return ok

    changed = False
    canceled = False
    for channel_pos, channel in enumerate(channels, 1):
        if only_index is not None and (channel_pos - 1) != int(only_index):
            continue
        current_channel_name = channel.get("name", "")
        current_channel_index = channel_pos
        if not continue_progress("sender"):
            canceled = True
            break

        # Senderidentitaet ist eine zwingende Bedingung. EPG-IDs allein
        # duerfen keine fremden Sender (z.B. Sky Sport statt RTL) zuordnen.
        identity = sync_name_key(channel.get("name", ""))
        candidates = list(by_name.get(identity, [])) if identity else []
        old_epg = (channel.get("tvg_id") or "").strip().lower()
        rejected = len(by_epg.get(old_epg, [])) - sum(
            1 for item in by_epg.get(old_epg, [])
            if sync_name_key(item.get("name", "")) == identity
        ) if old_epg else 0
        if rejected:
            xbmc.log("[VavooTV] Unsichere EPG-Treffer fuer {} verworfen: {}".format(
                channel.get("name", ""), rejected), xbmc.LOGWARNING)
        if not candidates:
            xbmc.log("[VavooTV] Keine eindeutige Senderidentitaet fuer {}".format(
                channel.get("name", "")), xbmc.LOGWARNING)

        unique = []
        seen = set()
        for entry in candidates:
            marker = (entry.get("name", ""), tuple(entry.get("urls", [])))
            if marker not in seen:
                seen.add(marker)
                unique.append(entry)

        preference = source_meta.get(source_meta_key(filename, channel), {})
        preferred_name = (preference.get("preferred_catalog_name") or "").strip()
        preferred_url = (preference.get("preferred_url") or "").strip()
        if preferred_name and sync_name_key(preferred_name) != identity:
            xbmc.log("[VavooTV] Widerspruechliche manuelle Quelle fuer {}: {}".format(
                channel.get("name", ""), preferred_name), xbmc.LOGWARNING)
            result["unchanged"] += 1
            result["unsafe"] = result.get("unsafe", 0) + 1
            continue
        if preferred_url and not any(preferred_url in item.get("urls", []) for item in candidates):
            # Gesperrte manuelle Quellen niemals durch automatische Wahl ersetzen.
            xbmc.log("[VavooTV] Manuelle Quelle nicht im passenden Katalog fuer {}".format(
                channel.get("name", "")), xbmc.LOGWARNING)
            result["unchanged"] += 1
            result["unsafe"] = result.get("unsafe", 0) + 1
            continue

        def entry_rank(entry):
            score = candidate_score(
                entry.get("name", ""), channel.get("name", "")
            )
            if (
                preferred_name
                and entry.get("name", "").strip().lower()
                == preferred_name.lower()
            ):
                score += 1000
            if preferred_url and preferred_url in (entry.get("urls") or []):
                score += 2000
            return score

        candidates = sorted(unique, key=entry_rank, reverse=True)
        if not candidates:
            result["missing"] += 1
            continue

        old_url = channel.get("url", "")
        url_candidates = []
        seen_urls = set()
        for entry in candidates:
            for url in entry.get("urls", []):
                clean_url = (url or "").strip()
                if clean_url and clean_url not in seen_urls:
                    seen_urls.add(clean_url)
                    url_candidates.append((clean_url, entry))

        if preferred_url:
            url_candidates = [pair for pair in url_candidates if pair[0] == preferred_url]

        chosen_url = ""
        chosen_entry = None
        failed_count = 0

        if not validate_streams:
            if url_candidates:
                chosen_url, chosen_entry = url_candidates[0]
        else:
            if defective_only and old_url:
                current_ok = is_working(old_url, 1, 1)
                if current_ok is None:
                    canceled = True
                elif current_ok:
                    result["unchanged"] += 1
                    continue

            candidates_to_test = (
                url_candidates[:max_candidates]
                if max_candidates and max_candidates > 0
                else url_candidates
            )
            for candidate_pos, (url, entry) in enumerate(candidates_to_test, 1):
                if defective_only and url == old_url:
                    continue
                working = is_working(
                    url, candidate_pos, len(candidates_to_test)
                )
                if working is None:
                    canceled = True
                    break
                if working:
                    chosen_url = url
                    chosen_entry = entry
                    if failed_count > 0 or (
                        defective_only and old_url and url != old_url
                    ):
                        result["fallbacks"] += 1
                        xbmc.log(
                            "[VavooTV] Fallback gewaehlt fuer {}: {}".format(
                                channel.get("name", ""), url
                            ),
                            xbmc.LOGINFO,
                        )
                    break
                failed_count += 1

        if canceled:
            break
        if not chosen_url:
            result["unreachable"] += 1
            result["unchanged"] += 1
            continue

        new_logo = channel.get("logo", "")
        new_epg = channel.get("tvg_id", "")
        if api_module is not None and chosen_entry is not None:
            try:
                new_logo = (
                    api_module.get_channel_logo(chosen_entry["name"])
                    or new_logo
                )
            except Exception:
                pass
            try:
                new_epg = (
                    chosen_entry.get("tvg_id")
                    or api_module.get_channel_epg_id(chosen_entry["name"])
                    or new_epg
                )
            except Exception:
                pass

        try:
            meta_key = source_meta_key(filename, channel)
            meta_entry = source_meta.get(meta_key, {})
            if not isinstance(meta_entry, dict):
                meta_entry = {}
            details = (
                chosen_entry.get("source_details", {}).get(chosen_url, {})
                if chosen_entry else {}
            )
            meta_entry.update({
                "last_catalog_name": (
                    chosen_entry.get("name", "") if chosen_entry else ""
                ),
                "last_url": chosen_url,
                "last_country": details.get("country", ""),
                "last_quality": (
                    details.get("quality", "")
                    or quality_from_name(chosen_entry.get("name", "") if chosen_entry else "")
                ),
                "last_status": "ok" if chosen_url else "unknown",
                "last_update": time.strftime("%Y-%m-%d %H:%M:%S"),
            })
            source_meta[meta_key] = meta_entry
        except Exception:
            pass

        if (
            chosen_url != old_url
            or new_logo != channel.get("logo", "")
            or new_epg != channel.get("tvg_id", "")
        ):
            channel["url"] = chosen_url
            channel["logo"] = new_logo
            channel["tvg_id"] = new_epg
            result["updated"] += 1
            changed = True
        else:
            result["unchanged"] += 1

    if canceled:
        result["canceled"] = True
        result["updated"] = 0
        return result

    if changed:
        try:
            backup_dir = os.path.join(profile_dir(), "sync_backups")
            os.makedirs(backup_dir, exist_ok=True)
            src = group_m3u_path(filename)
            stem, ext = os.path.splitext(os.path.basename(filename))
            backup = os.path.join(
                backup_dir,
                "{}_{}{}".format(
                    stem, time.strftime("%Y%m%d-%H%M%S"), ext or ".m3u"
                ),
            )
            shutil.copy2(src, backup)
            result["backup"] = backup
        except Exception as exc:
            xbmc.log("[VavooTV] Sicherung fehlgeschlagen, keine Aenderung: {}".format(
                exc), xbmc.LOGERROR)
            result["error"] = "backup_failed"
            result["updated"] = 0
            return result

        if not save_group_channels(filename, channels):
            result["error"] = "write_failed"
            try:
                if result["backup"]:
                    shutil.copy2(result["backup"], group_m3u_path(filename))
            except Exception:
                pass
            return result

        saved_order = [
            item.get("name", "") for item in load_group_channels(filename)
        ]
        if saved_order != original_order:
            result["error"] = "order_changed"
            xbmc.log(
                "[VavooTV] Sync abgebrochen: Favoriten-Reihenfolge wurde veraendert.",
                xbmc.LOGERROR,
            )
            try:
                if result["backup"]:
                    shutil.copy2(result["backup"], group_m3u_path(filename))
            except Exception as exc:
                xbmc.log(
                    "[VavooTV] restore backup error: {}".format(exc),
                    xbmc.LOGERROR,
                )
            result["updated"] = 0

    if not result.get("error"):
        save_source_meta(source_meta)

    return result
