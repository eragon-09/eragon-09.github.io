# -*- coding: utf-8 -*-
"""Reine M3U-Helfer fuer Favoriten.

Dieses Modul kennt weder Kodi noch Addon-Einstellungen. Es zerlegt nur
M3U-Inhalte in die bereits im Addon verwendete Dictionary-Struktur.
"""
import re
from urllib.parse import parse_qs, unquote_plus, urlparse


def extract_epg_url(header_line):
    match = re.search(r'url-tvg="([^"]*)"', header_line or "")
    return match.group(1).strip() if match else ""


def parse_extinf(extinf_line):
    """Liest Name, Logo und tvg-id aus einer EXTINF-Zeile."""
    line = extinf_line or ""
    name_match = re.search(r',(.+)$', line)
    logo_match = re.search(r'tvg-logo="([^"]*)"', line)
    id_match = re.search(r'tvg-id="([^"]*)"', line)
    return {
        "name": name_match.group(1).strip() if name_match else "",
        "logo": logo_match.group(1).strip() if logo_match else "",
        "tvg_id": id_match.group(1).strip() if id_match else "",
    }


def unwrap_plugin_url(raw_url):
    """Extrahiert die urspruengliche URL aus alten plugin://-Eintraegen."""
    if not (raw_url or "").startswith("plugin://"):
        return raw_url
    try:
        query = parse_qs(urlparse(raw_url).query)
        return unquote_plus(query["url"][0]) if "url" in query else raw_url
    except Exception:
        return raw_url


def parse_favorites_m3u(content, epg_url_callback=None):
    """Parst eine Favoriten-M3U in die bestehende Listenstruktur."""
    lines = (content or "").splitlines()
    favorites = []
    current_ext = None
    pending_vavoo = None

    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue

        if line.startswith("#EXTM3U"):
            epg_url = extract_epg_url(line)
            if epg_url and epg_url_callback:
                epg_url_callback(epg_url)
            continue

        if line.startswith("#EXTINF:"):
            current_ext = line
            pending_vavoo = None
            continue

        if line.startswith("#EXTVLCOPT") or line.startswith("#KODIPROP"):
            continue

        if line.startswith("##MARKER:"):
            favorites.append({"type": "marker", "name": line[9:].strip()})
            current_ext = None
            pending_vavoo = None
            continue

        if line.startswith("##VAVOO-URL:"):
            pending_vavoo = line[12:].strip()
            continue

        if current_ext is None:
            continue

        metadata = parse_extinf(current_ext)
        raw_url = line
        if pending_vavoo:
            url = pending_vavoo
        else:
            url = unwrap_plugin_url(raw_url)

        if metadata["name"] and url:
            entry = {
                "type": "channel",
                "name": metadata["name"],
                "url": url,
            }
            if metadata["logo"]:
                entry["logo"] = metadata["logo"]
            if metadata["tvg_id"]:
                entry["tvg_id"] = metadata["tvg_id"]
            favorites.append(entry)

        current_ext = None
        pending_vavoo = None

    return favorites
