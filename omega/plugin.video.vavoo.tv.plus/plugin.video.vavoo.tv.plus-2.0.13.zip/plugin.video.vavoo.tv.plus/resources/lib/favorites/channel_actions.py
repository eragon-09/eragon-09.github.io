# -*- coding: utf-8 -*-
"""Senderbezogene UI-Aktionen fuer Favoritengruppen.

Das Modul enthaelt das Hinzufuegen, Umbenennen, Entfernen und Verschieben
von Sendern. Datei-, Gruppen- und EPG-Zugriffe werden als Abhaengigkeiten
uebergeben, damit keine zyklischen Imports mit ``group_favs`` entstehen.
"""

import xbmc
import xbmcgui


def add_single(addon_name, group_file, channel_name, channel_url,
               channel_logo="", epg_cache=None, *, load_group_channels,
               save_group_channels, match_epg_id, addon):
    """Einen einzelnen Sender zu einer Favoritengruppe hinzufuegen."""
    channels = load_group_channels(group_file)

    if any(c["name"] == channel_name for c in channels):
        xbmcgui.Dialog().notification(
            addon_name,
            "Bereits in dieser Gruppe: {}".format(channel_name),
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )
        return False

    tvg_id = match_epg_id(channel_name, epg_cache or {})
    channels.append({
        "name": channel_name,
        "url": channel_url,
        "logo": channel_logo,
        "tvg_id": tvg_id,
    })
    save_group_channels(group_file, channels, addon.getSetting("epg_url").strip())
    return True


def add_to_group_dialog(addon_name, channel_name, channel_url,
                        channel_logo="", epg_cache=None, *, load_groups,
                        load_group_channels, save_group_channels,
                        match_epg_id, addon):
    """Eine Zielgruppe auswaehlen und den Sender dort hinzufuegen."""
    groups = load_groups()
    if not groups:
        xbmcgui.Dialog().ok(
            addon_name,
            "Keine Gruppen vorhanden.\nBitte zuerst eine Gruppe erstellen.",
        )
        return False

    names = [g["name"] for g in groups]
    idx = xbmcgui.Dialog().select(
        "'{}' hinzufügen zu:".format(channel_name), names
    )
    if idx < 0:
        return False

    result = add_single(
        addon_name,
        groups[idx]["file"],
        channel_name,
        channel_url,
        channel_logo,
        epg_cache,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        match_epg_id=match_epg_id,
        addon=addon,
    )
    if result:
        xbmcgui.Dialog().notification(
            addon_name,
            "Hinzugefügt zu '{}'".format(groups[idx]["name"]),
            xbmcgui.NOTIFICATION_INFO,
            2000,
        )
    return result


def add_multi(addon_name, group_file, group_name, epg_cache=None, *,
              load_group_channels, save_group_channels, match_epg_id,
              addon, api_module=None):
    """Mehrere Sender einer Laendergruppe auswaehlen und speichern."""
    if api_module is None:
        import vavoo_api as api_module

    all_countries = api_module.get_available_countries()
    if not all_countries:
        xbmcgui.Dialog().ok(addon_name, "Keine Ländergruppen verfügbar.")
        return False

    country_idx = xbmcgui.Dialog().select("Ländergruppe wählen", all_countries)
    if country_idx < 0:
        return False
    country = all_countries[country_idx]

    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, "Lade Sender für {} …".format(country))
    try:
        channels_data = api_module.fetch_channels_for_group(country)
    finally:
        progress.close()

    if not channels_data:
        xbmcgui.Dialog().ok(
            addon_name, "Keine Sender für '{}' gefunden.".format(country)
        )
        return False

    existing = load_group_channels(group_file)
    exist_names = {c["name"] for c in existing}
    sorted_names = sorted(channels_data.keys())

    labels = []
    preselect = []
    for i, name in enumerate(sorted_names):
        if name in exist_names:
            labels.append("[COLOR gold]{}[/COLOR]".format(name))
            preselect.append(i)
        else:
            labels.append(name)

    chosen = xbmcgui.Dialog().multiselect(
        "Sender auswählen – {}".format(country), labels, preselect=preselect
    )
    if chosen is None:
        return False

    chosen_names = {sorted_names[i] for i in chosen}
    sorted_name_set = set(sorted_names)
    existing = [
        c for c in existing
        if c["name"] not in sorted_name_set or c["name"] in chosen_names
    ]

    exist_now = {c["name"] for c in existing}
    added = 0
    for name in sorted_names:
        if name in chosen_names and name not in exist_now:
            existing.append({
                "name": name,
                "url": channels_data[name][0],
                "logo": "",
                "tvg_id": match_epg_id(name, epg_cache or {}),
            })
            added += 1

    save_group_channels(
        group_file, existing, addon.getSetting("epg_url").strip()
    )

    removed = len((exist_names & sorted_name_set) - chosen_names)
    parts = []
    if added:
        parts.append("{} Sender hinzugefügt".format(added))
    if removed:
        parts.append("{} Sender entfernt".format(removed))
    if not parts:
        parts.append("Keine Änderungen")

    xbmcgui.Dialog().notification(
        addon_name, ", ".join(parts), xbmcgui.NOTIFICATION_INFO, 3000
    )
    return True


def rename(addon_name, group_file, channel_idx, *, load_group_channels,
           save_group_channels, addon):
    """Einen Sender innerhalb einer Gruppe umbenennen."""
    channels = load_group_channels(group_file)
    try:
        idx = int(channel_idx)
        if not 0 <= idx < len(channels):
            return False
    except (ValueError, TypeError):
        return False

    old_name = channels[idx].get("name", "")
    kb = xbmc.Keyboard(old_name, "Sender umbenennen")
    kb.doModal()
    if not kb.isConfirmed():
        return False
    new_name = kb.getText().strip()
    if not new_name or new_name == old_name:
        return False

    channels[idx]["name"] = new_name
    save_group_channels(
        group_file, channels, addon.getSetting("epg_url").strip()
    )
    xbmcgui.Dialog().notification(
        addon_name,
        "Umbenannt: {} → {}".format(old_name, new_name),
        xbmcgui.NOTIFICATION_INFO,
        2500,
    )
    return True


def remove(addon_name, group_file, channel_idx, *, load_group_channels,
           save_group_channels, addon):
    """Einen Sender per Index aus einer Gruppe entfernen."""
    channels = load_group_channels(group_file)
    try:
        idx = int(channel_idx)
        if 0 <= idx < len(channels):
            name = channels[idx]["name"]
            channels.pop(idx)
            save_group_channels(
                group_file, channels, addon.getSetting("epg_url").strip()
            )
            xbmcgui.Dialog().notification(
                addon_name,
                "Entfernt: {}".format(name),
                xbmcgui.NOTIFICATION_INFO,
                2000,
            )
            return True
    except (ValueError, TypeError):
        pass
    return False


def move(group_file, channel_idx, direction, *, load_group_channels,
         save_group_channels, addon):
    """Einen Sender innerhalb einer Gruppe verschieben."""
    channels = load_group_channels(group_file)
    try:
        idx = int(channel_idx)
        if direction == "up" and idx > 0:
            channels[idx], channels[idx - 1] = channels[idx - 1], channels[idx]
        elif direction == "down" and idx < len(channels) - 1:
            channels[idx], channels[idx + 1] = channels[idx + 1], channels[idx]
        elif direction == "top":
            channels.insert(0, channels.pop(idx))
        elif direction == "bottom":
            channels.append(channels.pop(idx))
        else:
            return False
        save_group_channels(
            group_file, channels, addon.getSetting("epg_url").strip()
        )
        return True
    except (ValueError, TypeError, IndexError):
        return False


def move_to_group(addon_name, src_file, channel_idx, epg_cache=None, *,
                  load_group_channels, save_group_channels, load_groups,
                  match_epg_id, addon):
    """Einen Sender in eine andere Favoritengruppe verschieben."""
    channels = load_group_channels(src_file)
    try:
        idx = int(channel_idx)
        if not 0 <= idx < len(channels):
            return False
    except (ValueError, TypeError):
        return False

    channel = channels[idx]
    groups = load_groups()
    names = [g["name"] for g in groups if g["file"] != src_file]
    files = [g["file"] for g in groups if g["file"] != src_file]

    if not names:
        xbmcgui.Dialog().ok(addon_name, "Keine anderen Gruppen vorhanden.")
        return False

    dst_idx = xbmcgui.Dialog().select(
        "'{}' verschieben nach:".format(channel["name"]), names
    )
    if dst_idx < 0:
        return False
    dst_file = files[dst_idx]

    channels.pop(idx)
    epg_url = addon.getSetting("epg_url").strip()
    save_group_channels(src_file, channels, epg_url)

    dst_channels = load_group_channels(dst_file)
    if not any(c["name"] == channel["name"] for c in dst_channels):
        if not channel.get("tvg_id"):
            channel["tvg_id"] = match_epg_id(channel["name"], epg_cache or {})
        dst_channels.append(channel)
        save_group_channels(dst_file, dst_channels, epg_url)

    xbmcgui.Dialog().notification(
        addon_name,
        "'{}' → '{}'".format(channel["name"], names[dst_idx]),
        xbmcgui.NOTIFICATION_INFO,
        2500,
    )
    return True
