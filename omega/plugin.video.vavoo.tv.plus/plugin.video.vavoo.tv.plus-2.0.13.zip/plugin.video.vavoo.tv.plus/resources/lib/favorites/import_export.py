# -*- coding: utf-8 -*-
"""Import, Export und Registrierung externer Favoriten-M3U-Dateien.

Datei-, Gruppen- und EPG-Zugriffe werden als Abhängigkeiten übergeben,
damit keine zyklischen Imports mit ``group_favs`` entstehen.
"""

import os
import re
import shutil
import zipfile

import xbmc
import xbmcgui
import xbmcvfs


def backup_all_groups(addon_name, *, load_groups, groups_json_path,
                      group_m3u_path, backup_zip_path):
    """Exportiert alle Gruppen-M3U-Dateien als ZIP."""
    groups = load_groups()
    if not groups:
        xbmcgui.Dialog().ok(addon_name, "Keine Gruppen vorhanden.")
        return False

    start_dir = "/storage/emulated/0/Download"
    if not os.path.exists(start_dir):
        start_dir = "/"

    save_dir = xbmcgui.Dialog().browse(
        3, "Speicherort für Sicherung wählen", "files", "", False, False, start_dir
    )
    if not save_dir:
        return False

    zip_path = backup_zip_path()
    try:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            groups_path = groups_json_path()
            if os.path.exists(groups_path):
                zf.write(groups_path, "groups.json")
            for group in groups:
                m3u_path = group_m3u_path(group["file"])
                if os.path.exists(m3u_path):
                    zf.write(m3u_path, group["file"])

        dest = os.path.join(save_dir, os.path.basename(zip_path))
        shutil.copy2(zip_path, dest)
        xbmcgui.Dialog().notification(
            addon_name, "Sicherung wurde erstellt", xbmcgui.NOTIFICATION_INFO, 3500
        )
        return True
    except Exception as exc:
        xbmcgui.Dialog().ok(addon_name, "Fehler bei der Sicherung:\n{}".format(exc))
        return False


def parse_m3u_channels(text):
    """Parst M3U-Text in Sender-Dictionaries."""
    channels = []
    current_ext = None
    pending_vavoo = None

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF:"):
            current_ext = line
            pending_vavoo = None
            continue
        if line.startswith("##VAVOO-URL:"):
            pending_vavoo = line[12:].strip()
            continue
        if line.startswith("#"):
            continue

        if current_ext is not None:
            match_name = re.search(r",(.+)$", current_ext)
            name = match_name.group(1).strip() if match_name else ""
            match_tvg_name = re.search(r'tvg-name="([^"]*)"', current_ext)
            if match_tvg_name and match_tvg_name.group(1).strip():
                name = match_tvg_name.group(1).strip()
            match_logo = re.search(r'tvg-logo="([^"]*)"', current_ext)
            logo = match_logo.group(1).strip() if match_logo else ""
            match_id = re.search(r'tvg-id="([^"]*)"', current_ext)
            tvg_id = match_id.group(1).strip() if match_id else ""

            if pending_vavoo:
                url = pending_vavoo
            elif line.startswith("plugin://"):
                try:
                    from urllib.parse import parse_qs, unquote_plus, urlparse
                    query = parse_qs(urlparse(line).query)
                    url = unquote_plus(query["url"][0]) if "url" in query else line
                except Exception:
                    url = line
            else:
                url = line

            if name and url:
                channels.append({
                    "name": name,
                    "url": url,
                    "logo": logo,
                    "tvg_id": tvg_id,
                })
            current_ext = None
            pending_vavoo = None

    return channels


def _is_m3u_filename(filename):
    return bool(filename) and filename.lower().endswith((".m3u", ".m3u8"))


def sync_bundled_m3u(*, favgroups_dir, addon_favgroups_dir, return_stats=False):
    """Übernimmt neue mitgelieferte M3Us in den Benutzerordner.

    Eine bereits befüllte Benutzerliste wird niemals überschrieben. Existiert
    dort jedoch nur ein leerer, vom Addon angelegter Platzhalter, darf dieser
    durch die gleichnamige, gültige mitgelieferte Liste ersetzt werden.

    Mit ``return_stats=True`` wird ein Bericht mit den Schlüsseln ``checked``,
    ``added``, ``replaced``, ``current``, ``invalid`` und ``errors`` geliefert.
    Ohne diese Option bleibt der bisherige Rückgabewert (Anzahl Änderungen)
    vollständig kompatibel.
    """
    target_dir = favgroups_dir()
    source_dir = addon_favgroups_dir() if addon_favgroups_dir else ""
    stats = {
        "checked": 0,
        "added": 0,
        "replaced": 0,
        "current": 0,
        "invalid": 0,
        "errors": 0,
    }
    if not source_dir or not os.path.isdir(source_dir):
        return stats if return_stats else 0

    changed = 0
    try:
        import shutil
        os.makedirs(target_dir, exist_ok=True)

        for filename in sorted(os.listdir(source_dir), key=str.lower):
            filename = filename.strip()
            if not _is_m3u_filename(filename):
                continue

            source = os.path.join(source_dir, filename)
            target = os.path.join(target_dir, filename)
            if not os.path.isfile(source):
                continue
            stats["checked"] += 1

            # Nur gültige und tatsächlich befüllte mitgelieferte Listen
            # übernehmen. Defekte Paketdateien dürfen keinen Benutzerbestand
            # ersetzen oder neue leere Gruppen erzeugen.
            source_text = vfs_read_text(source)
            if not source_text or not source_text.lstrip("\ufeff \t\r\n").startswith("#EXTM3U"):
                stats["invalid"] += 1
                xbmc.log("[VavooTV] Ungültige Paket-M3U übersprungen: {}".format(source), xbmc.LOGWARNING)
                continue
            if len(parse_m3u_channels(source_text)) < 1:
                stats["invalid"] += 1
                xbmc.log("[VavooTV] Leere Paket-M3U übersprungen: {}".format(source), xbmc.LOGWARNING)
                continue

            replace_placeholder = False
            if os.path.isfile(target):
                target_text = vfs_read_text(target)
                target_channels = parse_m3u_channels(target_text) if target_text else []
                if target_channels:
                    # Echte Benutzerlisten haben immer Vorrang.
                    stats["current"] += 1
                    continue
                replace_placeholder = True

            try:
                shutil.copy2(source, target)
                changed += 1
                if replace_placeholder:
                    stats["replaced"] += 1
                else:
                    stats["added"] += 1
                xbmc.log(
                    "[VavooTV] {} M3U übernommen: {}".format(
                        "Leeren Platzhalter ersetzt;" if replace_placeholder else "Neue",
                        filename,
                    ),
                    xbmc.LOGINFO,
                )
            except Exception as exc:
                stats["errors"] += 1
                xbmc.log("[VavooTV] bundled M3U copy error ({}): {}".format(filename, exc), xbmc.LOGERROR)
    except Exception as exc:
        stats["errors"] += 1
        xbmc.log("[VavooTV] sync_bundled_m3u error: {}".format(exc), xbmc.LOGERROR)
    return stats if return_stats else changed


def update_standard_groups(addon_name, *, favgroups_dir, addon_favgroups_dir):
    """Prüft und ergänzt die mitgelieferten Standard-Favoritengruppen manuell."""
    stats = sync_bundled_m3u(
        favgroups_dir=favgroups_dir,
        addon_favgroups_dir=addon_favgroups_dir,
        return_stats=True,
    )
    lines = [
        "{} Standardgruppen geprüft".format(stats.get("checked", 0)),
        "",
        "{} Gruppen ergänzt".format(stats.get("added", 0)),
        "{} Platzhalter ersetzt".format(stats.get("replaced", 0)),
        "{} bereits vorhanden".format(stats.get("current", 0)),
    ]
    if stats.get("invalid", 0):
        lines.append("{} ungültige Listen übersprungen".format(stats["invalid"]))
    if stats.get("errors", 0):
        lines.append("{} Fehler – Details im Kodi-Log".format(stats["errors"]))
    xbmcgui.Dialog().ok(addon_name, "\n".join(lines))
    return bool(stats.get("added") or stats.get("replaced"))


def m3u_scan_signature(*, favgroups_dir, addon_favgroups_dir):
    """Liefert eine stabile Signatur aller M3U-Dateien beider Ordner."""
    rows = []
    for label, folder in (("user", favgroups_dir()), ("addon", addon_favgroups_dir() if addon_favgroups_dir else "")):
        if not folder or not os.path.isdir(folder):
            continue
        try:
            for filename in sorted(os.listdir(folder), key=str.lower):
                if not _is_m3u_filename(filename):
                    continue
                path = os.path.join(folder, filename)
                if not os.path.isfile(path):
                    continue
                stat = os.stat(path)
                rows.append("{}|{}|{}|{}".format(
                    label, filename.lower(), int(stat.st_size), int(stat.st_mtime)
                ))
        except Exception as exc:
            xbmc.log("[VavooTV] m3u_scan_signature error: {}".format(exc), xbmc.LOGERROR)
    return "\n".join(rows)


def scan_unregistered_m3u(*, favgroups_dir, load_groups, addon_favgroups_dir=None):
    """Findet noch nicht registrierte M3U/M3U8-Dateien im Favoritenordner."""
    sync_bundled_m3u(
        favgroups_dir=favgroups_dir,
        addon_favgroups_dir=addon_favgroups_dir,
    )
    fav_dir = favgroups_dir()
    registered_files = {group["file"].lower() for group in load_groups()}
    unregistered = []
    try:
        for filename in sorted(os.listdir(fav_dir), key=str.lower):
            filename = filename.strip()
            if not _is_m3u_filename(filename):
                continue
            if filename.lower() in registered_files:
                continue
            full_path = os.path.join(fav_dir, filename)
            if not os.path.isfile(full_path):
                continue

            # Nur tatsächlich nutzbare Favoritenlisten anbieten. Dadurch werden
            # leere, beschädigte oder fremd benannte Dateien nicht registriert.
            text = vfs_read_text(full_path)
            if not text or not text.lstrip("\ufeff \t\r\n").startswith("#EXTM3U"):
                xbmc.log(
                    "[VavooTV] Ungültige M3U übersprungen: {}".format(full_path),
                    xbmc.LOGWARNING,
                )
                continue
            channel_count = len(parse_m3u_channels(text))
            if channel_count < 1:
                xbmc.log(
                    "[VavooTV] Leere M3U übersprungen: {}".format(full_path),
                    xbmc.LOGWARNING,
                )
                continue

            suggestion = os.path.splitext(filename)[0].replace("_", " ").title()
            unregistered.append({
                "name": suggestion,
                "file": filename,
                "path": full_path,
                "channel_count": channel_count,
            })
    except Exception as exc:
        xbmc.log("[VavooTV] scan_unregistered_m3u error: {}".format(exc), xbmc.LOGERROR)
    return unregistered


def register_unregistered_m3u(addon_name, *, favgroups_dir, load_groups,
                              save_groups, init_group_icon,
                              addon_favgroups_dir=None):
    """Registriert ausgewählte, noch unbekannte M3U-Dateien als Gruppen."""
    unregistered = scan_unregistered_m3u(
        favgroups_dir=favgroups_dir,
        load_groups=load_groups,
        addon_favgroups_dir=addon_favgroups_dir,
    )
    if not unregistered:
        xbmcgui.Dialog().notification(
            addon_name, "Keine neuen M3U-Dateien gefunden.",
            xbmcgui.NOTIFICATION_INFO, 2500
        )
        return False

    labels = [
        "{}  ({} Sender, {})".format(
            item["name"], item.get("channel_count", 0), item["file"]
        )
        for item in unregistered
    ]
    chosen = xbmcgui.Dialog().multiselect(
        "Neue M3U-Dateien gefunden – registrieren?", labels
    )
    if chosen is None:
        return False

    groups = load_groups()
    registered_files = {group["file"] for group in groups}
    added = 0
    for index in chosen:
        entry = unregistered[index]
        keyboard = xbmc.Keyboard(entry["name"], "Name für '{}'".format(entry["file"]))
        keyboard.doModal()
        if not keyboard.isConfirmed():
            continue
        name = keyboard.getText().strip() or entry["name"]

        if any(group["name"].lower() == name.lower() for group in groups):
            suffix = 2
            base = name
            while any(
                group["name"].lower() == "{} {}".format(base, suffix).lower()
                for group in groups
            ):
                suffix += 1
            name = "{} {}".format(base, suffix)

        if entry["file"] not in registered_files:
            init_group_icon(entry["file"])
            groups.append({"name": name, "file": entry["file"]})
            registered_files.add(entry["file"])
            added += 1

    if added:
        save_groups(groups)
        xbmcgui.Dialog().notification(
            addon_name, "{} Liste(n) registriert".format(added),
            xbmcgui.NOTIFICATION_INFO, 2500
        )
    return added > 0


def vfs_read_text(file_path):
    """Liest eine Datei über Kodis VFS und liefert Text oder ``None``."""
    try:
        handle = xbmcvfs.File(file_path)
        try:
            raw = handle.readBytes()
            if raw:
                handle.close()
                if isinstance(raw, (bytes, bytearray)):
                    return raw.decode("utf-8", errors="ignore")
                return str(raw)
        except Exception:
            pass
        try:
            text = handle.read()
            handle.close()
            if text:
                return text
        except Exception:
            pass
        handle.close()
    except Exception:
        pass
    return None


def normalize_folder(folder):
    """Ergänzt bei Bedarf den plattformspezifischen abschließenden Trenner."""
    if folder and not folder.endswith("/") and not folder.endswith("\\"):
        separator = "\\" if ("\\" in folder or (len(folder) > 1 and folder[1] == ":")) else "/"
        folder += separator
    return folder


def import_m3u_multi(addon_name, epg_cache=None, *, addon, load_groups,
                     save_groups, make_filename, save_group_channels,
                     init_group_icon):
    """Importiert mehrere M3U-Dateien nacheinander."""
    selected_files = []
    last_dir = ""
    while True:
        file_path = xbmcgui.Dialog().browse(
            1,
            "M3U auswählen ({} gewählt) – Abbrechen zum Beenden".format(len(selected_files)),
            "files", ".m3u|.m3u8", False, False, last_dir
        )
        if not file_path or file_path == last_dir:
            break
        if os.path.splitext(file_path)[1].lower() not in (".m3u", ".m3u8"):
            xbmcgui.Dialog().notification(
                addon_name, "Nur .m3u- und .m3u8-Dateien erlaubt",
                xbmcgui.NOTIFICATION_WARNING, 2000
            )
            continue
        if file_path in selected_files:
            xbmcgui.Dialog().notification(
                addon_name, "Bereits ausgewählt", xbmcgui.NOTIFICATION_INFO, 1500
            )
            continue
        selected_files.append(file_path)
        last_dir = os.path.dirname(file_path)
        if not xbmcgui.Dialog().yesno(
            addon_name,
            "{} Datei(en) ausgewählt. Weitere hinzufügen?".format(len(selected_files)),
            nolabel="Fertig", yeslabel="Weitere wählen"
        ):
            break

    if not selected_files:
        return False

    groups = load_groups()
    existing_files = {group["file"] for group in groups}
    epg_url = addon.getSetting("epg_url").strip()
    imported = 0
    skipped = []

    for file_path in selected_files:
        is_network = any(file_path.startswith(prefix) for prefix in (
            "smb://", "nfs://", "ftp://", "sftp://", "special://"
        ))
        text = vfs_read_text(file_path) if is_network else None
        if text is None:
            try:
                with open(file_path, encoding="utf-8", errors="ignore") as handle:
                    text = handle.read()
            except Exception:
                text = vfs_read_text(file_path)

        if not text or not text.strip().startswith("#EXTM3U"):
            skipped.append(os.path.basename(file_path))
            continue
        channels = parse_m3u_channels(text)
        if not channels:
            skipped.append(os.path.basename(file_path))
            continue

        basename = os.path.splitext(os.path.basename(file_path))[0]
        filename = make_filename(basename)
        base, extension = os.path.splitext(filename)
        counter = 1
        while filename in existing_files:
            filename = "{}_{}{}".format(base, counter, extension)
            counter += 1

        try:
            save_group_channels(filename, channels, epg_url)
        except Exception:
            skipped.append(os.path.basename(file_path))
            continue

        init_group_icon(filename)
        groups.append({"name": basename, "file": filename})
        existing_files.add(filename)
        imported += 1

    if imported:
        save_groups(groups)
    message = "{} Liste(n) importiert".format(imported)
    if skipped:
        message += ", {} übersprungen".format(len(skipped))
    xbmcgui.Dialog().notification(
        addon_name, message, xbmcgui.NOTIFICATION_INFO, 3000
    )
    return imported > 0


def import_m3u_from_file(addon_name, epg_cache=None, *, addon, load_groups,
                         save_groups, make_filename, save_group_channels,
                         load_group_channels, init_group_icon, group_m3u_path,
                         match_epg_id, target_group_file=""):
    """Importiert eine externe M3U in eine bestehende oder neue Gruppe."""
    start_dir = "/storage/emulated/0/Download"
    if not os.path.exists(start_dir):
        start_dir = "/"
    file_path = xbmcgui.Dialog().browse(
        1, "M3U-Datei auswählen", "files", ".m3u|.m3u8|.txt",
        False, False, start_dir
    )
    if not file_path or not os.path.exists(file_path):
        return False

    try:
        with open(file_path, encoding="utf-8", errors="ignore") as handle:
            text = handle.read()
    except Exception as exc:
        xbmcgui.Dialog().ok(addon_name, "Datei konnte nicht gelesen werden:\n{}".format(exc))
        return False

    if not text.strip().startswith("#EXTM3U"):
        xbmcgui.Dialog().ok(
            addon_name,
            "Keine gültige M3U-Datei.\nDie Datei muss mit #EXTM3U beginnen."
        )
        return False
    channels = parse_m3u_channels(text)
    if not channels:
        xbmcgui.Dialog().ok(addon_name, "Keine Sender in der M3U-Datei gefunden.")
        return False

    file_basename = os.path.splitext(os.path.basename(file_path))[0]
    groups = load_groups()

    # Wird der Import aus dem Kontextmenü einer bereits ausgewählten Gruppe
    # gestartet, ist das Ziel eindeutig. In diesem Fall entfallen sowohl die
    # Modus- als auch die Zielgruppenabfrage.
    if target_group_file:
        target = next((group for group in groups if group.get("file") == target_group_file), None)
        if not target:
            xbmcgui.Dialog().ok(addon_name, "Die ausgewählte Zielgruppe wurde nicht gefunden.")
            return False
        return merge_channels_into_group(
            addon_name, target_group_file, channels, epg_cache,
            addon=addon, load_group_channels=load_group_channels,
            save_group_channels=save_group_channels, match_epg_id=match_epg_id
        )

    modes = [
        "In bestehende Gruppe importieren",
        "Neue Gruppe anlegen und importieren",
        "Als eigenständige Gruppe '{}' kopieren".format(file_basename),
    ]
    mode = xbmcgui.Dialog().select(
        "{} Sender gefunden – Ziel wählen:".format(len(channels)), modes
    )
    if mode < 0:
        return False

    if mode == 0:
        if not groups:
            xbmcgui.Dialog().ok(
                addon_name, "Noch keine Gruppen vorhanden.\nBitte zuerst eine Gruppe erstellen."
            )
            return False
        group_index = xbmcgui.Dialog().select(
            "Zielgruppe auswählen:", [group["name"] for group in groups]
        )
        if group_index < 0:
            return False
        return merge_channels_into_group(
            addon_name, groups[group_index]["file"], channels, epg_cache,
            addon=addon, load_group_channels=load_group_channels,
            save_group_channels=save_group_channels, match_epg_id=match_epg_id
        )

    if mode == 1:
        keyboard = xbmc.Keyboard(file_basename, "Name der neuen Gruppe")
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return False
        group_name = keyboard.getText().strip() or file_basename
        filename = make_filename(group_name)
        existing_files = {group["file"] for group in groups}
        base, extension = os.path.splitext(filename)
        counter = 1
        while filename in existing_files:
            filename = "{}_{}{}".format(base, counter, extension)
            counter += 1
        groups.append({"name": group_name, "file": filename})
        save_groups(groups)
        save_group_channels(filename, [], addon.getSetting("epg_url").strip())
        init_group_icon(filename)
        return merge_channels_into_group(
            addon_name, filename, channels, epg_cache,
            addon=addon, load_group_channels=load_group_channels,
            save_group_channels=save_group_channels, match_epg_id=match_epg_id
        )

    if mode == 2:
        filename = make_filename(file_basename)
        existing_files = {group["file"] for group in groups}
        base, extension = os.path.splitext(filename)
        counter = 1
        while filename in existing_files:
            filename = "{}_{}{}".format(base, counter, extension)
            counter += 1
        destination = group_m3u_path(filename)
        try:
            shutil.copy2(file_path, destination)
        except Exception as exc:
            xbmcgui.Dialog().ok(addon_name, "Kopieren fehlgeschlagen:\n{}".format(exc))
            return False

        parsed = parse_m3u_channels(text)
        save_group_channels(filename, parsed, addon.getSetting("epg_url").strip())
        keyboard = xbmc.Keyboard(file_basename, "Name für diese Liste")
        keyboard.doModal()
        group_name = keyboard.getText().strip() if keyboard.isConfirmed() else file_basename
        init_group_icon(filename)
        groups.append({"name": group_name, "file": filename})
        save_groups(groups)
        xbmcgui.Dialog().notification(
            addon_name,
            "'{}' mit {} Sendern importiert".format(group_name, len(parsed)),
            xbmcgui.NOTIFICATION_INFO, 3000
        )
        return True
    return False


def merge_channels_into_group(addon_name, group_file, new_channels,
                              epg_cache=None, *, addon, load_group_channels,
                              save_group_channels, match_epg_id):
    """Fügt neue Sender ohne Namensduplikate in eine Gruppe ein."""
    existing = load_group_channels(group_file)
    existing_names = {channel["name"] for channel in existing}
    added = 0
    skipped = 0
    for channel in new_channels:
        name = channel.get("name", "")
        if not name or not channel.get("url"):
            continue
        if name in existing_names:
            skipped += 1
            continue
        if not channel.get("tvg_id") and epg_cache:
            channel["tvg_id"] = match_epg_id(name, epg_cache)
        existing.append(channel)
        existing_names.add(name)
        added += 1

    save_group_channels(group_file, existing, addon.getSetting("epg_url").strip())
    parts = []
    if added:
        parts.append("{} Sender hinzugefügt".format(added))
    if skipped:
        parts.append("{} bereits vorhanden".format(skipped))
    xbmcgui.Dialog().notification(
        addon_name, ", ".join(parts) or "Keine Änderungen",
        xbmcgui.NOTIFICATION_INFO, 3000
    )
    return True


def scan_and_notify(addon_name, *, favgroups_dir, load_groups,
                    addon_favgroups_dir=None):
    """Informiert unaufdringlich über noch nicht registrierte M3U-Dateien."""
    count = len(scan_unregistered_m3u(
        favgroups_dir=favgroups_dir,
        load_groups=load_groups,
        addon_favgroups_dir=addon_favgroups_dir,
    ))
    if count > 0:
        xbmcgui.Dialog().notification(
            addon_name,
            "{} neue M3U-Datei(en) im Favoritenordner gefunden".format(count),
            xbmcgui.NOTIFICATION_INFO, 4000
        )
    return count
