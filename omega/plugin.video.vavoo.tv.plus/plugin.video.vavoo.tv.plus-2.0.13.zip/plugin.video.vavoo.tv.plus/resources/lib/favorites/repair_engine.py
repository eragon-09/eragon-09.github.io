# -*- coding: utf-8 -*-
"""Reparatur- und Aktualisierungsabläufe für Favoritensender.

Dieses Modul enthält die Kodi-Dialog- und Kataloglogik für komplette
Favoritengruppen, einzelne Sender und die manuelle Quellenauswahl. Die
M3U-Synchronisation selbst bleibt in :mod:`favorites.sync_engine`.
"""

import os
import shutil
import time
import difflib
import re

import xbmc
import xbmcgui


def sync_favorite_groups(group_file="", force_reload=True, mode="quick", *,
                         addon_name, api_module, group_favs,
                         get_active_countries, append_internal_log):
    """Synchronisiert oder repariert Favoriten-M3Us.

    ``mode="quick"`` aktualisiert technische Daten ohne Streamtests.
    ``mode="repair"`` prüft alle Favoriten mit Streamtest und Fallback.
    ``mode="defects"`` prüft und repariert nur defekte bestehende Streams.
    """
    all_countries = api_module.get_available_countries()
    countries = get_active_countries(all_countries)

    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, "Aktueller Senderkatalog wird geladen ...")

    live_channels = {}
    try:
        for country_pos, country in enumerate(countries, 1):
            if progress.iscanceled():
                progress.close()
                return False
            pct = int(((country_pos - 1) / max(len(countries), 1)) * 10)
            progress.update(pct, f"Senderliste {country_pos} von {len(countries)}\n{country}")
            current = _repair_catalog(api_module, country, force_reload)
            for name, urls in current.items():
                live_channels.setdefault(name, [])
                for url in (urls if isinstance(urls, list) else [urls]):
                    if not url:
                        continue
                    item = {
                        "url": url,
                        "country": str(country),
                        "quality": "",
                    }
                    if not any(existing.get("url") == url for existing in live_channels[name] if isinstance(existing, dict)):
                        live_channels[name].append(item)

        if not live_channels:
            progress.close()
            xbmcgui.Dialog().ok(
                addon_name,
                "Aktualisierung nicht möglich: Kein aktueller Senderkatalog geladen.",
            )
            return False

        groups = group_favs.load_groups()
        if group_file:
            groups = [g for g in groups if g.get("file") == group_file]
        if not groups:
            progress.close()
            return False

        group_counts = []
        for group in groups:
            try:
                group_counts.append(len(group_favs.load_group_channels(group["file"])))
            except Exception:
                group_counts.append(0)
        total_senders = sum(group_counts)
        completed_before = 0
        canceled = False

        totals = {
            "total": 0,
            "updated": 0,
            "unchanged": 0,
            "missing": 0,
            "fallbacks": 0,
            "unreachable": 0,
            "errors": 0,
        }

        def update_progress(info):
            if progress.iscanceled():
                return False
            global_index = max(1, int(info.get("global_index", 1)))
            global_total = max(1, int(info.get("global_total", total_senders or 1)))
            pct = 10 + int(((global_index - 1) / global_total) * 89)
            group_idx = info.get("group_index", 1)
            group_total = info.get("group_total", len(groups))
            channel_idx = info.get("channel_index", 1)
            channel_total = info.get("channel_total", 1)
            name = info.get("channel_name", "") or "Unbekannter Sender"
            line1 = f"Favoritenliste {group_idx} von {group_total}"
            line2 = f"Sender {channel_idx} von {channel_total}: {name}"
            if info.get("phase") == "candidate" and info.get("candidate_total", 0):
                line2 += (
                    f"  |  Quelle {info.get('candidate_index', 1)} von "
                    f"{info.get('candidate_total', 1)}"
                )
            progress.update(min(pct, 99), f"{line1}\n{line2}")
            return not progress.iscanceled()

        for group_pos, group in enumerate(groups, 1):
            if progress.iscanceled():
                canceled = True
                break
            stats = group_favs.sync_group_channels(
                group["file"], live_channels, api_module,
                max_candidates=0 if mode == "quick" else 3,
                validation_timeout=4 if mode == "defects" else 7,
                validate_streams=(mode != "quick"),
                defective_only=(mode == "defects"),
                progress_callback=update_progress,
                group_index=group_pos,
                group_total=len(groups),
                global_offset=completed_before,
                global_total=total_senders,
            )
            if stats.get("canceled"):
                canceled = True
                break
            completed_before += group_counts[group_pos - 1]
            for key in (
                "total", "updated", "unchanged", "missing", "fallbacks", "unreachable"
            ):
                totals[key] += stats.get(key, 0)
            if stats.get("error"):
                totals["errors"] += 1

        if canceled:
            progress.close()
            xbmcgui.Dialog().notification(
                addon_name,
                "Aktualisierung abgebrochen – aktuelle Gruppe nicht gespeichert",
                xbmcgui.NOTIFICATION_WARNING,
                3500,
            )
            return False

        progress.update(
            100,
            f"Favoritenaktualisierung abgeschlossen\n{total_senders} Sender verarbeitet",
        )
    finally:
        try:
            progress.close()
        except Exception:
            pass

    summary_title = (
        "Schnelle Aktualisierung abgeschlossen.\n\n" if mode == "quick" else
        "Defekte Sender geprüft und repariert.\n\n" if mode == "defects" else
        "Favoriten geprüft und repariert.\n\n"
    )
    append_internal_log(
        f"Favoriten-Sync ({mode}) abgeschlossen: {totals['total']} Sender, "
        f"{totals['updated']} geändert, {totals['fallbacks']} Fallbacks"
    )
    xbmcgui.Dialog().ok(
        addon_name,
        summary_title
        + f"Sender insgesamt: {totals['total']}\n"
        + f"Geändert: {totals['updated']}\n"
        + f"Bereits aktuell: {totals['unchanged']}\n"
        + f"Nicht gefunden (beibehalten): {totals['missing']}\n"
        + f"Fallback verwendet: {totals['fallbacks']}\n"
        + f"Kein erreichbarer Stream (beibehalten): {totals['unreachable']}\n"
        + f"Fehler/Zurückgesetzt: {totals['errors']}\n\n"
        + "Gruppen- und Senderreihenfolge bleiben unverändert.",
    )
    return True


def sync_single_favorite(group_file, channel_index, mode="quick", *,
                         addon_name, api_module, group_favs,
                         get_active_countries):
    """Aktualisiert genau einen Favoritensender ohne Positionsänderung."""
    try:
        channel_index = int(channel_index)
    except (TypeError, ValueError):
        return False

    channels = group_favs.load_group_channels(group_file)
    if channel_index < 0 or channel_index >= len(channels):
        xbmcgui.Dialog().ok(addon_name, "Sender konnte nicht gefunden werden.")
        return False
    channel_name = channels[channel_index].get("name", "Unbekannter Sender")

    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, f"Sender wird vorbereitet ...\n{channel_name}")
    live_channels = {}
    stats = {}
    try:
        countries = get_active_countries(api_module.get_available_countries())
        for pos, country in enumerate(countries, 1):
            if progress.iscanceled():
                return False
            pct = int(((pos - 1) / max(len(countries), 1)) * 30)
            progress.update(pct, f"Senderliste {pos} von {len(countries)}\n{country}")
            current = _repair_catalog(api_module, country, True)
            for name, urls in current.items():
                live_channels.setdefault(name, [])
                for url in (urls if isinstance(urls, list) else [urls]):
                    if not url:
                        continue
                    item = {
                        "url": url,
                        "country": str(country),
                        "quality": "",
                    }
                    if not any(existing.get("url") == url for existing in live_channels[name] if isinstance(existing, dict)):
                        live_channels[name].append(item)

        def one_progress(info):
            if progress.iscanceled():
                return False
            msg = f"Sender: {channel_name}"
            if info.get("phase") == "candidate" and info.get("candidate_total", 0):
                msg += (
                    f"\nQuelle {info.get('candidate_index', 1)} von "
                    f"{info.get('candidate_total', 1)} wird geprüft"
                )
            else:
                msg += "\nAktuelle Daten werden gesucht"
            progress.update(60 if mode == "quick" else 70, msg)
            return not progress.iscanceled()

        stats = group_favs.sync_group_channels(
            group_file, live_channels, api_module,
            max_candidates=0 if mode == "quick" else 3,
            validation_timeout=7,
            validate_streams=(mode != "quick"),
            defective_only=False,
            progress_callback=one_progress,
            global_total=1,
            only_index=channel_index,
        )
        if stats.get("canceled") or progress.iscanceled():
            return False
        progress.update(100, f"Sender abgeschlossen\n{channel_name}")
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if stats.get("updated"):
        message = "Sender wurde aktualisiert."
        if stats.get("fallbacks"):
            message += "\nEine alternative Quelle wurde verwendet."
    elif stats.get("missing"):
        message = (
            "Kein passender Sender im aktuellen Katalog gefunden.\n"
            "Der bisherige Eintrag bleibt erhalten."
        )
    elif stats.get("unreachable"):
        message = (
            "Keine funktionierende Ersatzquelle gefunden.\n"
            "Der bisherige Eintrag bleibt erhalten."
        )
    else:
        message = "Der Sender ist bereits aktuell."
    xbmcgui.Dialog().ok(addon_name, f"{channel_name}\n\n{message}")
    return True


def manual_select_single_favorite(group_file, channel_index, *, addon_name,
                                  api_module, group_favs,
                                  get_active_countries, append_internal_log):
    """Lässt den Benutzer einen Katalogtreffer für einen Favoriten wählen."""
    try:
        channel_index = int(channel_index)
    except (TypeError, ValueError):
        return False

    channels = group_favs.load_group_channels(group_file)
    if channel_index < 0 or channel_index >= len(channels):
        xbmcgui.Dialog().ok(addon_name, "Sender konnte nicht gefunden werden.")
        return False

    current = channels[channel_index]
    channel_name = current.get("name", "Unbekannter Sender")
    # User may search beyond the exact channel name (e.g. WDR HD -> WDR Fernsehen).
    default_search = channel_name
    search_term = xbmcgui.Dialog().input(
        "Sender suchen (Name oder Teilname)", defaultt=default_search,
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if not search_term or not search_term.strip():
        return False

    def search_key(value):
        value = (value or "").casefold()
        value = re.sub(r"\([^)]*\)$", "", value).strip()
        value = re.sub(r"\b(?:hd|fhd|uhd|sd|hevc|4k)\b", " ", value)
        return " ".join(re.findall(r"[\w]+", value))

    query = search_key(search_term)
    if not query:
        return False
    query_tokens = set(query.split())
    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, f"Passende Sender werden gesucht ...\n{search_term}")
    candidates = []
    seen = set()
    try:
        countries = get_active_countries(api_module.get_available_countries())
        for pos, country in enumerate(countries, 1):
            if progress.iscanceled():
                return False
            pct = int((pos / max(len(countries), 1)) * 100)
            progress.update(pct, f"Senderliste {pos} von {len(countries)}\n{country}")
            catalog = _repair_catalog(api_module, country, True)
            for live_name, urls in catalog.items():
                live_key = search_key(live_name)
                live_tokens = set(live_key.split())
                # Exact, partial and closely related channel names are offered.
                similarity = difflib.SequenceMatcher(None, query, live_key).ratio()
                if not (query == live_key or query in live_key or
                        (len(query) >= 4 and live_key in query) or
                        (query_tokens and query_tokens.issubset(live_tokens)) or
                        (len(query) >= 5 and similarity >= 0.74)):
                    continue
                try:
                    live_epg = api_module.get_channel_epg_id(live_name) or ""
                except Exception:
                    live_epg = ""
                try:
                    logo = api_module.get_channel_logo(live_name) or ""
                except Exception:
                    logo = ""
                for url in (urls if isinstance(urls, list) else [urls]):
                    url = (url or "").strip()
                    marker = (live_name, url)
                    if not url or marker in seen:
                        continue
                    seen.add(marker)
                    lower = live_name.lower()
                    quality = (
                        "UHD/4K" if ("uhd" in lower or "4k" in lower) else
                        "FHD" if ("fhd" in lower or "full hd" in lower) else
                        "HD" if (" hd" in " " + lower or lower.endswith("hd")) else
                        "SD"
                    )
                    candidates.append({
                        "name": live_name,
                        "url": url,
                        "country": str(country),
                        "tvg_id": live_epg,
                        "logo": logo,
                        "quality": quality,
                        "search_score": (3 if query == live_key else
                                         2 if query in live_key else
                                         1 if query_tokens.issubset(live_tokens) else
                                         similarity),
                    })
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if not candidates:
        xbmcgui.Dialog().ok(
            addon_name,
            f"{search_term}\n\nKeine passenden Sender im aktuellen Katalog gefunden.\n"
            "Versuche einen kürzeren Suchbegriff, z. B. WDR.",
        )
        return False

    candidates.sort(
        key=lambda entry: (
            entry.get("search_score", 0),
            group_favs._candidate_score(entry.get("name", ""), channel_name),
            entry.get("country", ""),
            entry.get("name", ""),
        ),
        reverse=True,
    )
    candidates = candidates[:150]
    labels = ["Bisherigen Eintrag unverändert lassen"]
    for entry in candidates:
        epg = entry.get("tvg_id") or "keine EPG-ID"
        labels.append(
            f"{entry.get('name', '')}  |  {entry.get('country', '')}  |  "
            f"{entry.get('quality', 'SD')}  |  {epg}"
        )

    choice = xbmcgui.Dialog().select(
        f"Sender auswählen: {channel_name}", labels, preselect=0
    )
    if choice <= 0:
        return False

    selected = candidates[choice - 1]
    confirm = xbmcgui.Dialog().yesno(
        addon_name,
        f"Diesen Sender setzen?\n\n"
        f"Favorit: {channel_name}\n"
        f"Auswahl: {selected.get('name', '')}\n"
        f"Land: {selected.get('country', '')}\n"
        f"Qualität: {selected.get('quality', '')}\n"
        f"EPG-ID: {selected.get('tvg_id') or '-'}",
    )
    if not confirm:
        return False

    # Validate only the explicitly selected source, before touching favorites.
    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, "Ausgewählter Sender wird geprüft ...")
    try:
        stream, headers = api_module.resolve_stream(selected["url"])
        valid = bool(stream and api_module.validate_hls_stream(stream, headers, timeout=7))
        if progress.iscanceled():
            return False
    except Exception:
        valid = False
    finally:
        progress.close()
    if not valid:
        xbmcgui.Dialog().ok(addon_name, "Der Ersatzstream konnte nicht bestätigt werden. Der Favorit bleibt unverändert.")
        return False

    if not _replace_confirmed_favorite(group_favs, group_file, channel_index, current, selected):
        xbmcgui.Dialog().ok(addon_name, "Der Sender konnte nicht sicher gespeichert werden.")
        return False

    append_internal_log(
        f"Quelle manuell gesetzt: {channel_name} -> {selected.get('name', '')} "
        f"({selected.get('country', '')}, {selected.get('quality', '')})"
    )
    xbmcgui.Dialog().ok(
        addon_name,
        f"{channel_name}\n\nGesetzt wurde:\n{selected.get('name', '')}\n"
        f"{selected.get('country', '')} | {selected.get('quality', '')}",
    )
    return True


def _replace_confirmed_favorite(gf, group_file, index, original, selected):
    """Replace exact copies across groups, preserving their positions."""
    import tempfile
    groups = gf.load_groups()
    files = list(dict.fromkeys([group_file] + [g.get("file", "") for g in groups]))
    identity = (original.get("name"), original.get("url"))
    replacement = {k: selected.get(k, "") for k in ("name", "url", "logo", "tvg_id")}
    if not replacement["name"] or not replacement["url"]:
        return False
    plans = []
    backups = []
    try:
        for filename in files:
            if not filename or filename.lower() == "alle_favoriten.m3u":
                continue
            rows = gf.load_group_channels(filename)
            if filename == group_file and (not 0 <= index < len(rows) or
                    (rows[index].get("name"), rows[index].get("url")) != identity):
                return False
            positions = [i for i, row in enumerate(rows)
                         if (row.get("name"), row.get("url")) == identity]
            if positions:
                plans.append((filename, rows, positions))
        if not plans:
            return False
        backup_dir = os.path.join(gf._profile_dir(), "sync_backups")
        os.makedirs(backup_dir, exist_ok=True)
        for filename, rows, positions in plans:
            src = gf._group_m3u_path(filename)
            fd, backup = tempfile.mkstemp(prefix=os.path.basename(filename) + "_", suffix=".m3u", dir=backup_dir)
            os.close(fd)
            shutil.copy2(src, backup)
            backups.append((src, backup))
        meta = dict(gf.load_source_meta())
        for filename, rows, positions in plans:
            old_key = gf._source_meta_key(filename, original)
            new_key = gf._source_meta_key(filename, replacement)
            for i in positions:
                rows[i] = dict(rows[i], **replacement)
            if not gf.save_group_channels(filename, rows):
                raise IOError("favorite write failed")
            if gf.load_group_channels(filename) != rows:
                raise IOError("favorite verification failed")
            meta.pop(old_key, None)
            meta[new_key] = {"preferred_catalog_name": replacement["name"],
                             "preferred_url": replacement["url"],
                             "preferred_country": selected.get("country", ""),
                             "preferred_quality": selected.get("quality", ""),
                             "last_catalog_name": replacement["name"],
                             "last_url": replacement["url"], "last_status": "manuell gewählt"}
        if not gf.save_source_meta(meta):
            raise IOError("source metadata write failed")
    except Exception as exc:
        for src, backup in backups:
            try:
                shutil.copy2(backup, src)
            except Exception:
                xbmc.log("[VavooTV] Wiederherstellung fehlgeschlagen: " + src, xbmc.LOGERROR)
        xbmc.log("[VavooTV] Senderersatz fehlgeschlagen: " + str(exc), xbmc.LOGERROR)
        return False
    try:
        gf.rebuild_all_favorites_m3u(groups)
    except Exception as exc:
        xbmc.log("[VavooTV] Sammel-M3U: " + str(exc), xbmc.LOGWARNING)
    return True


def _repair_catalog(api_module, country, force):
    catalog = api_module.fetch_channels_for_group(country, force=force) or {}
    if country != "Germany":
        return catalog
    import json
    from pathlib import Path
    from favorites.sync_engine import sync_name_key
    try:
        rows = json.loads((Path(__file__).resolve().parents[2] / "favgroups" / "geil_sources.json").read_text(encoding="utf-8"))
        result = dict(catalog)
        identities = {sync_name_key(n) for n in catalog}
        for name, url in rows:
            if sync_name_key(name) not in identities:
                result.setdefault(name, []).append(url)
        return result
    except (OSError, ValueError):
        return catalog
