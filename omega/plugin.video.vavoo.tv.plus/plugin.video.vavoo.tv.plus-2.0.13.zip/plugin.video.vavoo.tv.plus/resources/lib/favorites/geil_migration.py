import os, re, json, shutil
from urllib.parse import urlsplit, parse_qs, urlencode

from favorites.sync_engine import sync_name_key as key

def migrate(path, mapping_path):
    try:
        with open(mapping_path, encoding="utf-8") as f:
            mapping = json.load(f)
        with open(path, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
        name = ""
        changed = False
        for i, line in enumerate(lines):
            if line.startswith("#EXTINF:"):
                name = line.split(",", 1)[-1].strip()
            elif line.startswith("plugin://"):
                url = parse_qs(urlsplit(line).query).get("url", [""])[0]
                if urlsplit(url).hostname in ("vavoo.to", "geil.to", "www2.vavoo.to", "voltop.net") and "/vavoo-iptv/play/" in url:
                    replacement = mapping.get(key(name))
                    if replacement:
                        new_url = parse_qs(urlsplit(replacement).query)["url"][0]
                        params = parse_qs(urlsplit(line).query, keep_blank_values=True)
                        params["url"] = [new_url]
                        lines[i] = line.split("?", 1)[0] + "?" + urlencode(params, doseq=True)
                        changed = True
        if changed:
            backup = path + ".pre-geil.bak"
            if not os.path.exists(backup):
                shutil.copy2(path, backup)
            tmp = path + ".geil.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
            os.replace(tmp, path)
    except (OSError, ValueError):
        return


def migrate_cinema(path, mapping_path):
    if os.path.basename(path).lower() != "cinema_tv.m3u":
        return
    try:
        with open(mapping_path, encoding="utf-8") as f:
            mapping = json.load(f)
        with open(path, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
        changed = False
        for i, line in enumerate(lines[:-1]):
            if not line.startswith("#EXTINF:"):
                continue
            name = line.split(",", 1)[-1].strip()
            target = mapping.get(name)
            if not target or not lines[i+1].startswith("plugin://"):
                continue
            label, url = target
            current = parse_qs(urlsplit(lines[i+1]).query).get("url", [""])[0]
            if "/vavoo-iptv/play/" not in current:
                continue
            lines[i] = line.replace(name, label) if label != name else line
            lines[i+1] = url
            changed = True
        if changed:
            backup = path + ".pre-cinema-2014.bak"
            if not os.path.exists(backup):
                shutil.copy2(path, backup)
            tmp = path + ".cinema.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
            os.replace(tmp, path)
    except (OSError, ValueError):
        return
