# -*- coding: utf-8 -*-
"""Favoritengruppen-Bilder verwalten.

Die Funktionen in diesem Modul behandeln nur die Zuordnung, Anlage,
Umbenennung und Loeschung von Gruppenbildern. Fehlende optionale
Favoritengruppen oder Gruppenbilder sind kein Fehler.
"""

import os
import shutil

import xbmcaddon
import xbmcvfs

from utils import paths as path_utils


ADDON = xbmcaddon.Addon()


def _profile_dir():
    return path_utils.addon_profile(ADDON)


def addon_icons_dir():
    """Mitgelieferten ``resources/art/favo_icons``-Ordner liefern."""
    try:
        return path_utils.bundled_favo_icons_dir(ADDON)
    except Exception:
        return ""


def user_icons_dir():
    """Beschreibbaren ``favo_icons``-Ordner im Addon-Profil zurueckgeben."""
    path = path_utils.user_favo_icons_dir(ADDON)
    os.makedirs(path, exist_ok=True)
    return path


def group_stem(group_file):
    return os.path.splitext(group_file)[0]


def addon_default_icon():
    """Pfad zum generischen mitgelieferten Favoritenbild liefern."""
    try:
        return os.path.join(addon_icons_dir(), "default.png")
    except Exception:
        return ""


def find_icon_in_dir(directory, stem):
    """Case-insensitiv nach ``<stem>.png`` in *directory* suchen."""
    if not directory:
        return None
    try:
        directory = xbmcvfs.translatePath(directory)
    except Exception:
        pass
    if not os.path.isdir(directory):
        return None

    expected = str(stem).lower()
    try:
        for filename in os.listdir(directory):
            filename = filename.strip()
            if not filename:
                continue
            name, extension = os.path.splitext(filename)
            if extension.lower() == ".png" and name.lower() == expected:
                return os.path.join(directory, filename)
    except Exception:
        return None
    return None


def get_group_icon(group_file):
    """Gruppenspezifisches Bild oder das mitgelieferte Standardbild liefern."""
    stem = group_stem(group_file)
    return (
        find_icon_in_dir(user_icons_dir(), stem)
        or find_icon_in_dir(addon_icons_dir(), stem)
        or addon_default_icon()
    )


def get_group_icon_optional(group_file):
    """Nur ein gruppenspezifisches Bild liefern, andernfalls ``None``."""
    stem = group_stem(group_file)
    return (
        find_icon_in_dir(user_icons_dir(), stem)
        or find_icon_in_dir(addon_icons_dir(), stem)
    )


def init_group_icon(group_file):
    """Bei Bedarf ein beschreibbares Standardbild fuer eine Gruppe anlegen."""
    stem = group_stem(group_file)
    user_path = os.path.join(user_icons_dir(), stem + ".png")
    if os.path.exists(user_path):
        return user_path

    bundled = find_icon_in_dir(addon_icons_dir(), stem)
    if bundled:
        return bundled

    default = addon_default_icon()
    if default and os.path.exists(default):
        try:
            shutil.copy2(default, user_path)
        except Exception:
            pass
    return user_path


def rename_group_icon(old_file, new_file):
    """Vorhandenes Gruppenbild gemeinsam mit der Gruppe umbenennen."""
    for icon_dir in (user_icons_dir(), addon_icons_dir()):
        old_path = os.path.join(icon_dir, group_stem(old_file) + ".png")
        new_path = os.path.join(icon_dir, group_stem(new_file) + ".png")
        if os.path.exists(old_path) and not os.path.exists(new_path):
            try:
                os.rename(old_path, new_path)
            except Exception:
                pass


def delete_group_icon(group_file):
    """Gruppenspezifisches Bild aus Benutzer- und Addon-Ordner entfernen."""
    stem = group_stem(group_file)
    for icon_dir in (user_icons_dir(), addon_icons_dir()):
        path = os.path.join(icon_dir, stem + ".png")
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass
