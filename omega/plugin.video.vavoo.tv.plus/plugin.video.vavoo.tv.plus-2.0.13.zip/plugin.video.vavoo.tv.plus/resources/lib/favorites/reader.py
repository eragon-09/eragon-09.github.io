# -*- coding: utf-8 -*-
"""Dateizugriff fuer Favoritenlisten mit leichtem Dateicache."""
import copy
import json
import os

from .parser import parse_favorites_m3u
from utils.performance import measure

_FAVORITES_CACHE = {}


def _file_signature(path):
    try:
        stat = os.stat(path)
        return stat.st_mtime_ns, stat.st_size
    except Exception:
        return None


def invalidate_favorites_cache(path=None):
    """Verwirft einen oder alle geparsten Favoriteneinträge."""
    if path is None:
        _FAVORITES_CACHE.clear()
    else:
        _FAVORITES_CACHE.pop(os.path.abspath(path), None)


def load_favorites(path, save_callback=None, epg_url_callback=None):
    """Laedt M3U-Favoriten und migriert bei Bedarf die alte JSON-Datei."""
    old_json = path.replace(".m3u", ".json")
    if os.path.exists(old_json) and not os.path.exists(path):
        try:
            with open(old_json, encoding="utf-8") as handle:
                data = json.load(handle)
            migrated = []
            for entry in data:
                if "type" not in entry:
                    entry["type"] = "channel"
                migrated.append(entry)
            if save_callback:
                save_callback(migrated)
            os.remove(old_json)
            invalidate_favorites_cache(path)
            return migrated
        except Exception:
            pass

    if not os.path.exists(path):
        invalidate_favorites_cache(path)
        return []

    cache_key = os.path.abspath(path)
    signature = _file_signature(path)
    cached = _FAVORITES_CACHE.get(cache_key)
    if cached and cached.get("signature") == signature:
        return copy.deepcopy(cached.get("favorites", []))

    try:
        with measure("favorites.read", os.path.basename(path)):
            with open(path, encoding="utf-8") as handle:
                content = handle.read()
    except Exception:
        return []

    with measure("favorites.parse", os.path.basename(path)):
        favorites = parse_favorites_m3u(content, epg_url_callback=epg_url_callback)
    _FAVORITES_CACHE[cache_key] = {
        "signature": signature,
        "favorites": copy.deepcopy(favorites),
    }
    return favorites
