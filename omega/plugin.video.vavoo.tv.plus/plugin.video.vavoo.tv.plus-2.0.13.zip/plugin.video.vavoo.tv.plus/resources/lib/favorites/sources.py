# -*- coding: utf-8 -*-
"""Anzeige und Verwaltung gespeicherter Quelleninformationen."""

from utils import dialogs


_COUNTRY_LABELS = {
    "germany": "Deutschland",
    "de": "Deutschland",
    "austria": "Österreich",
    "at": "Österreich",
    "switzerland": "Schweiz",
    "ch": "Schweiz",
    "united kingdom": "Vereinigtes Königreich",
    "uk": "Vereinigtes Königreich",
    "france": "Frankreich",
    "italy": "Italien",
    "spain": "Spanien",
    "netherlands": "Niederlande",
    "poland": "Polen",
    "romania": "Rumänien",
    "turkey": "Türkei",
    "croatia": "Kroatien",
    "bulgaria": "Bulgarien",
    "albania": "Albanien",
}


def _country_label(value):
    text = str(value or "").strip()
    return _COUNTRY_LABELS.get(text.lower(), text or "nicht bekannt")


def _quality_label(value):
    text = str(value or "").strip()
    lower = text.lower()
    if not text:
        return "wird beim nächsten Abgleich ermittelt."
    if "uhd" in lower or "4k" in lower:
        return "Ultra HD (4K)"
    if "fhd" in lower or "full hd" in lower or "1080" in lower:
        return "Full HD"
    if lower == "hd" or "720" in lower:
        return "HD"
    if lower == "sd":
        return "SD"
    return text


def _time_label(value):
    """Formatiert ISO-Zeitstempel ohne datetime/strptime-Abhängigkeit."""
    text = str(value or "").strip()
    if not text:
        return "noch nicht geprüft"

    # Erwartete Formen: YYYY-MM-DD HH:MM:SS oder YYYY-MM-DDTHH:MM:SS.
    # Die direkte Prüfung ist absichtlich unabhängig von Kodis datetime-Bindings.
    compact = text[:19].replace("T", " ")
    if (
        len(compact) == 19
        and compact[4] == "-"
        and compact[7] == "-"
        and compact[10] == " "
        and compact[13] == ":"
        and compact[16] == ":"
        and compact[0:4].isdigit()
        and compact[5:7].isdigit()
        and compact[8:10].isdigit()
        and compact[11:13].isdigit()
        and compact[14:16].isdigit()
        and compact[17:19].isdigit()
    ):
        return "{}.{}.{} {}:{}".format(
            compact[8:10], compact[5:7], compact[0:4],
            compact[11:13], compact[14:16]
        )
    return text


def source_information_text(channel, meta, include_epg=True):
    """Erzeugt die zentrale, benutzerfreundliche Quellenanzeige."""
    meta = meta if isinstance(meta, dict) else {}
    preferred = bool(meta.get("preferred_catalog_name") or meta.get("preferred_url"))
    country = meta.get("preferred_country") if preferred else meta.get("last_country")
    quality = meta.get("preferred_quality") if preferred else meta.get("last_quality")
    checked = meta.get("last_update") or meta.get("updated_at")

    if preferred:
        lines = ["Bevorzugte Quelle:", "Vavoo", ""]
        catalog_name = str(meta.get("preferred_catalog_name") or "").strip()
        if catalog_name:
            lines.extend(["Ausgewählter Katalogeintrag:", catalog_name, ""])
    else:
        lines = ["Quelle", "", "Automatische Quellenauswahl aktiv.", ""]

    lines.extend([
        "Land:",
        _country_label(country),
        "",
        "Qualität:",
        _quality_label(quality),
        "",
        "Zuletzt geprüft:",
        _time_label(checked),
    ])
    if include_epg:
        lines.extend(["", "EPG-ID:", channel.get("tvg_id") or "-"])
    return "\n".join(lines)


def show_source_information(addon_name, gf, filename, channel):
    dialogs.info(
        addon_name,
        source_information_text(
            channel, gf.get_source_meta(filename, channel), include_epg=True
        ),
    )
    return True


def _select_channel(addon_name, gf):
    groups = gf.load_groups()
    valid = []
    for group in groups:
        filename = group.get("file", "")
        channels = gf.load_group_channels(filename) if filename else []
        if channels:
            valid.append((group, channels))
    if not valid:
        dialogs.info(addon_name, "Keine Favoritensender vorhanden.")
        return None
    gp = dialogs.select(
        "Favoritengruppe wählen",
        [g.get("name", g.get("file", "Favoritengruppe")) for g, _ in valid],
    )
    if gp < 0:
        return None
    group, channels = valid[gp]
    cp = dialogs.select(
        "Sender wählen",
        [ch.get("name", "Unbekannter Sender") for ch in channels],
    )
    if cp < 0:
        return None
    return group, channels, cp


def source_manager(addon_name, gf):
    selected = _select_channel(addon_name, gf)
    if not selected:
        return
    group, channels, pos = selected
    channel = channels[pos]
    filename = group.get("file", "")
    meta = gf.get_source_meta(filename, channel)
    options = ["Quelleninformationen anzeigen"]
    if meta.get("preferred_catalog_name") or meta.get("preferred_url"):
        options.append("Bevorzugte Quelle zurücksetzen")
    choice = dialogs.select(channel.get("name", "Sender"), options)
    if choice < 0:
        return
    if choice == 0:
        show_source_information(addon_name, gf, filename, channel)
        return
    if choice == 1:
        if not dialogs.confirm(
            addon_name,
            "Bevorzugte Quelle für diesen Sender wirklich zurücksetzen?\n\n"
            "Die M3U und die EPG-ID bleiben unverändert.",
        ):
            return
        if gf.clear_preferred_source(filename, channel):
            dialogs.notify(addon_name, "Bevorzugte Quelle zurückgesetzt", 2500)
        else:
            dialogs.info(addon_name, "Die Quelle konnte nicht zurückgesetzt werden.")


def channel_info(addon_name, gf, manual_select, quick_sync, repair_sync):
    selected = _select_channel(addon_name, gf)
    if not selected:
        return
    group, channels, pos = selected
    filename = group.get("file", "")
    channel = channels[pos]
    while True:
        meta = gf.get_source_meta(filename, channel)
        name = channel.get("name") or "Unbekannter Sender"
        source_info = source_information_text(channel, meta, include_epg=False)
        info = (
            f"Sender: {name}\n"
            f"Favoritengruppe: {group.get('name') or filename or '-'}\n"
            f"Position: {pos + 1} von {len(channels)}\n\n"
            f"EPG-ID: {channel.get('tvg_id') or '-'}\n"
            f"Logo: {channel.get('logo') or '-'}\n"
            f"Stream-Adresse: {channel.get('url') or '-'}\n\n"
            f"{source_info}\n\n"
            "Hinweis: Quelleninformationen werden separat gespeichert. "
            "Sendername und EPG-ID werden durch diese Ansicht nicht verändert."
        )
        actions = [
            "Informationen anzeigen",
            "Sender manuell auswählen",
            "Sender schnell aktualisieren",
            "Sender prüfen und reparieren",
        ]
        has_preferred = bool(
            meta.get("preferred_catalog_name") or meta.get("preferred_url")
        )
        if has_preferred:
            actions.append("Bevorzugte Quelle zurücksetzen")
        choice = dialogs.select(name, actions)
        if choice < 0:
            return
        if choice == 0:
            dialogs.text("Senderinformationen", info)
            continue
        if choice == 1:
            manual_select(filename, pos)
        elif choice == 2:
            quick_sync(filename, pos)
        elif choice == 3:
            repair_sync(filename, pos)
        elif choice == 4 and has_preferred:
            if dialogs.confirm(
                addon_name,
                "Bevorzugte Quelle für diesen Sender zurücksetzen?\n\n"
                "M3U, Sendername und EPG-ID bleiben unverändert.",
            ):
                gf.clear_preferred_source(filename, channel)
                dialogs.notify(addon_name, "Bevorzugte Quelle zurückgesetzt", 2500)
        channels = gf.load_group_channels(filename)
        if pos >= len(channels):
            return
        channel = channels[pos]
