# -*- coding: utf-8 -*-
"""Schreiblogik fuer Favoriten-M3U-Dateien."""
import os
import re

from .reader import invalidate_favorites_cache
from utils.io import atomic_write_text


def build_favorites_m3u(favorites, epg_id_lookup):
    lines = ["#EXTM3U", ""]
    current_group = "Favoriten"

    for favorite in favorites:
        favorite_type = favorite.get("type", "channel")

        if favorite_type == "marker":
            name = favorite.get("name", "")
            lines.append(f"##MARKER:{name}")
            clean = re.sub(r'^[-\s*]+|[-\s*]+$', '', name).strip()
            current_group = clean if clean else name
            lines.append("")
            continue

        name = favorite.get("name", "")
        url = favorite.get("url", "")
        if not name or not url:
            continue

        logo = ""
        epg_id = epg_id_lookup(name)
        safe_name = name.replace('"', "'")
        extinf = (
            f'#EXTINF:-1'
            f' tvg-name="{safe_name}"'
            f' tvg-id="{epg_id}"'
            f' tvg-logo="{logo}"'
            f' group-title="{current_group}"'
            f',{safe_name}'
        )
        lines.append(extinf)
        lines.append(f"##VAVOO-URL:{url}")
        lines.append(url)
        lines.append("")

    return "\n".join(lines)


def save_favorites(path, favorites, epg_id_lookup):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    content = build_favorites_m3u(favorites, epg_id_lookup)
    atomic_write_text(path, content)
    invalidate_favorites_cache(path)
