# -*- coding: utf-8 -*-
"""Gruppenbezogene UI-Aktionen fuer Favoritenlisten.

Das Modul enthaelt nur das Erstellen, Umbenennen, Entfernen und Verschieben
von Gruppen. Datei- und M3U-Zugriffe werden als Abhaengigkeiten uebergeben,
damit keine zyklischen Imports mit ``group_favs`` entstehen.
"""

import os

import xbmc
import xbmcgui


def create_group(addon_name, *, load_groups, save_groups, make_filename,
                 save_group_channels, init_group_icon):
    """Neue Favoritengruppe erstellen."""
    kb = xbmc.Keyboard("", "Name der neuen Gruppe")
    kb.doModal()
    if not kb.isConfirmed():
        return False

    name = kb.getText().strip()
    if not name:
        return False

    groups = load_groups()
    if any(g["name"].lower() == name.lower() for g in groups):
        xbmcgui.Dialog().ok(addon_name, "Gruppe '{}' existiert bereits.".format(name))
        return False

    filename = make_filename(name)
    existing_files = {g["file"] for g in groups}
    base, ext = os.path.splitext(filename)
    counter = 1
    while filename in existing_files:
        filename = "{}_{}{}".format(base, counter, ext)
        counter += 1

    groups.append({"name": name, "file": filename, "icon": ""})
    save_groups(groups)
    save_group_channels(filename, [])
    init_group_icon(filename)

    xbmcgui.Dialog().notification(
        addon_name,
        "Gruppe '{}' erstellt".format(name),
        xbmcgui.NOTIFICATION_INFO,
        2000,
    )
    return True


def rename_group(addon_name, group_file="", group_name="", *,
                 load_groups, save_groups):
    """Eine Favoritengruppe umbenennen."""
    groups = load_groups()
    if not groups:
        return False

    if group_file:
        idx = next((i for i, g in enumerate(groups) if g["file"] == group_file), -1)
        if idx < 0:
            return False
    else:
        names = [g["name"] for g in groups]
        idx = xbmcgui.Dialog().select("Gruppe umbenennen", names)
        if idx < 0:
            return False

    old_name = groups[idx]["name"]
    kb = xbmc.Keyboard(old_name, "Neuer Name für '{}'".format(old_name))
    kb.doModal()
    if not kb.isConfirmed():
        return False

    new_name = kb.getText().strip()
    if not new_name or new_name == old_name:
        return False

    if any(
        i != idx and g["name"].lower() == new_name.lower()
        for i, g in enumerate(groups)
    ):
        xbmcgui.Dialog().ok(addon_name, "Name '{}' bereits vergeben.".format(new_name))
        return False

    groups[idx]["name"] = new_name
    save_groups(groups)
    xbmcgui.Dialog().notification(
        addon_name,
        "Umbenannt in '{}'".format(new_name),
        xbmcgui.NOTIFICATION_INFO,
        2000,
    )
    return True


def remove_group(addon_name, group_file="", group_name="", *,
                 load_groups, save_groups, group_m3u_path,
                 delete_group_icon):
    """Eine Favoritengruppe nach Bestaetigung entfernen."""
    groups = load_groups()
    if not groups:
        return False

    if group_file:
        idx = next((i for i, g in enumerate(groups) if g["file"] == group_file), -1)
        if idx < 0:
            return False
    else:
        names = [g["name"] for g in groups]
        idx = xbmcgui.Dialog().select("Gruppe entfernen", names)
        if idx < 0:
            return False

    group = groups[idx]
    if not xbmcgui.Dialog().yesno(
        addon_name,
        "Gruppe '{}' wirklich entfernen?\nDie enthaltenen Sender werden gelöscht.".format(
            group["name"]
        ),
    ):
        return False

    path = group_m3u_path(group["file"])
    if os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            pass

    delete_group_icon(group["file"])
    groups.pop(idx)
    save_groups(groups)
    xbmcgui.Dialog().notification(
        addon_name,
        "Gruppe '{}' entfernt".format(group["name"]),
        xbmcgui.NOTIFICATION_INFO,
        2000,
    )
    return True


def move_group(group_file, direction, *, load_groups, save_groups):
    """Eine Favoritengruppe um eine Position verschieben."""
    groups = load_groups()
    idx = next((i for i, g in enumerate(groups) if g["file"] == group_file), -1)
    if idx < 0:
        return False

    if direction == "up" and idx > 0:
        groups[idx], groups[idx - 1] = groups[idx - 1], groups[idx]
    elif direction == "down" and idx < len(groups) - 1:
        groups[idx], groups[idx + 1] = groups[idx + 1], groups[idx]
    else:
        return False

    save_groups(groups)
    return True
