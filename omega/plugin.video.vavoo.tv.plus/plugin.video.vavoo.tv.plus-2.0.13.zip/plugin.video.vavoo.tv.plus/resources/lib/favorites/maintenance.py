# -*- coding: utf-8 -*-
import os
import re
from datetime import datetime

import xbmcvfs

from utils import dialogs, logger, paths, strings
from utils.io import atomic_write_text


def write_text_file(path, text):
    try:
        atomic_write_text(path, text)
        return True
    except Exception as exc:
        logger.warning(f"Datei konnte nicht geschrieben werden: {exc}")
        return False


def read_text_file(path):
    try:
        if not os.path.exists(path):
            return ""
        with open(path, "r", encoding="utf-8") as handle:
            return handle.read()
    except Exception as exc:
        logger.warning(f"Datei konnte nicht gelesen werden: {exc}")
        return ""


def append_internal_log(profile_path, log_file, message):
    try:
        os.makedirs(profile_path, exist_ok=True)
        existing = read_text_file(log_file).splitlines()
        entry = f"{datetime.now().strftime('%d.%m.%Y %H:%M:%S')}  {message}"
        lines = (existing + [entry])[-500:]
        write_text_file(log_file, "\n".join(lines) + "\n")
    except Exception as exc:
        logger.debug(f"Aktivitaetsprotokoll: {exc}")


def show_last_report(addon_name, report_file):
    report = read_text_file(report_file)
    if not report:
        dialogs.info(addon_name, strings.MAINTENANCE_NO_REPORT)
        return
    dialogs.text(strings.MAINTENANCE_REPORT_TITLE, report)


def show_activity_log(addon_name, log_file):
    content = read_text_file(log_file)
    if not content:
        dialogs.info(addon_name, strings.ACTIVITY_LOG_EMPTY)
        return
    dialogs.text(strings.ACTIVITY_LOG_TITLE, content)


def clear_activity_log(addon_name, log_file):
    if not os.path.exists(log_file):
        dialogs.notify(addon_name, strings.ACTIVITY_LOG_ALREADY_EMPTY, 2000)
        return
    if not dialogs.confirm(addon_name, strings.ACTIVITY_LOG_CLEAR_CONFIRM):
        return
    try:
        os.remove(log_file)
        dialogs.notify(addon_name, strings.ACTIVITY_LOG_CLEARED, 2000)
    except Exception as exc:
        dialogs.info(addon_name, f"{strings.ACTIVITY_LOG_DELETE_FAILED}\n\n{exc}")


def _channel_key(channel):
    tvg_id = (channel.get("tvg_id") or "").strip().lower()
    name = re.sub(r"[^a-z0-9]+", "", (channel.get("name") or "").strip().lower())
    return tvg_id or name


def scan(addon, addon_name, gf, report_file, log_callback):
    progress = dialogs.progress(addon_name, strings.MAINTENANCE_CHECKING)
    groups = gf.load_groups()
    total_channels = 0
    empty_urls, missing_logos, duplicates = [], [], []
    valid_meta_keys = set()
    group_count = max(1, len(groups))
    for group_pos, group in enumerate(groups, 1):
        if progress.iscanceled():
            progress.close()
            dialogs.notify(addon_name, strings.MAINTENANCE_CANCELLED, 2500)
            return
        filename = group.get("file", "")
        group_name = group.get("name") or filename or "Favoritengruppe"
        channels = gf.load_group_channels(filename) if filename else []
        seen = {}
        for channel in channels:
            total_channels += 1
            name = channel.get("name") or "Unbekannter Sender"
            if not (channel.get("url") or "").strip():
                empty_urls.append(f"{group_name}: {name}")
            logo = (channel.get("logo") or "").strip()
            if not logo:
                missing_logos.append(f"{group_name}: {name}")
            elif not logo.lower().startswith(("http://", "https://", "special://")):
                try:
                    if not os.path.exists(xbmcvfs.translatePath(logo)):
                        missing_logos.append(f"{group_name}: {name}")
                except Exception:
                    pass
            key = _channel_key(channel)
            if key:
                if key in seen:
                    duplicates.append(f"{group_name}: {seen[key]} / {name}")
                else:
                    seen[key] = name
            try:
                valid_meta_keys.add(gf._source_meta_key(filename, channel))
            except Exception:
                pass
        progress.update(int((group_pos / group_count) * 80), f"Gruppe {group_pos} von {len(groups)}: {group_name}")
    meta = gf.load_source_meta()
    orphan_meta = [key for key in meta.keys() if key not in valid_meta_keys]
    preferred_sources = sum(1 for entry in meta.values() if isinstance(entry, dict) and (entry.get("preferred_catalog_name") or entry.get("preferred_url")))
    profile_dir = paths.addon_profile(addon)
    backup_files = []
    try:
        for name in os.listdir(profile_dir):
            if name.lower().startswith("vavootv-gruppen-backup-") and name.lower().endswith(".zip"):
                backup_files.append(name)
        sync_dir = os.path.join(profile_dir, "sync_backups")
        if os.path.isdir(sync_dir):
            backup_files.extend(os.path.join("sync_backups", name) for name in os.listdir(sync_dir) if os.path.isfile(os.path.join(sync_dir, name)))
    except Exception:
        pass
    progress.update(100, strings.MAINTENANCE_BUILDING_REPORT)
    progress.close()
    def sample(values, limit=5):
        if not values:
            return "keine"
        text = "\n".join(f"- {value}" for value in values[:limit])
        if len(values) > limit:
            text += f"\n- weitere Eintraege: {len(values) - limit}"
        return text
    report = (
        "Lokale Systempruefung abgeschlossen\n\n"
        f"Favoritengruppen: {len(groups)}\nSender insgesamt: {total_channels}\n"
        f"Sender ohne Stream-Adresse: {len(empty_urls)}\nDoppelte Sender: {len(duplicates)}\n"
        f"Fehlende lokale Logos: {len(missing_logos)}\nBevorzugte Quellen: {preferred_sources}\n"
        f"Verwaiste Quellen-Metadaten: {len(orphan_meta)}\nBackups: {len(backup_files)}\n\n"
        f"Sender ohne Stream-Adresse\n{sample(empty_urls)}\n\n"
        f"Doppelte Sender\n{sample(duplicates)}\n\n"
        f"Fehlende lokale Logos\n{sample(missing_logos)}\n\n"
        "Hinweis: Diese Pruefung verwendet keine Netzwerk-Streamtests und veraendert weder M3U-Dateien noch EPG-IDs. Fuer eine Streampruefung verwenden Sie 'Defekte Sender suchen'."
    )
    stored = f"Erstellt: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}\nAddon-Version: {addon.getAddonInfo('version')}\n\n{report}"
    write_text_file(report_file, stored)
    log_callback(f"Systempruefung abgeschlossen: {len(groups)} Gruppen, {total_channels} Sender, {len(duplicates)} doppelte, {len(empty_urls)} ohne Stream-Adresse")
    dialogs.text(strings.MAINTENANCE_REPORT, stored)
