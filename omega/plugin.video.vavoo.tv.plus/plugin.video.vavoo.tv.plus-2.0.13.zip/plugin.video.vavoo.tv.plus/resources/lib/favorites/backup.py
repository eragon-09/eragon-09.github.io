# -*- coding: utf-8 -*-
"""Complete user-data backup and restore for Vavoo TV Plus.

The archive contains user-owned configuration and favorite data. Runtime caches
are deliberately excluded so a restore always starts from a clean state.
"""

import datetime
import json
import os
import shutil
import tempfile
import zipfile

import xbmc
import xbmcgui
import xbmcvfs


_BACKUP_FORMAT = 1
_PROFILE_FILES = (
    "groups.json",
    "settings.xml",
    "favorite_source_meta.json",
    "maintenance_report.txt",
    "activity_log.txt",
)
_PROFILE_DIRS = ("favgroups", "favo_icons")
_HISTORY_FILE = "backup_history.json"
_README_NAME = "README.txt"
_MANIFEST_NAME = "manifest.json"
_MAX_HISTORY = 20


def _safe_name(name):
    name = (name or "").replace("\\", "/")
    normalized = os.path.normpath(name).replace("\\", "/")
    if normalized.startswith("../") or normalized == ".." or normalized.startswith("/"):
        return False
    return not any(part in ("", ".", "..") for part in normalized.split("/"))


def _profile_path(addon):
    return xbmcvfs.translatePath(addon.getAddonInfo("profile"))


def _default_start_dir():
    candidates = (
        "/storage/emulated/0/Download",
        xbmcvfs.translatePath("special://home/"),
        "/",
    )
    for path in candidates:
        if path and os.path.exists(path):
            return path
    return "/"


def _atomic_json_write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, temp_path = tempfile.mkstemp(prefix=".backup-history-", suffix=".tmp", dir=os.path.dirname(path))
    os.close(fd)
    try:
        with open(temp_path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
        os.replace(temp_path, path)
    except Exception:
        try:
            os.remove(temp_path)
        except OSError:
            pass
        raise


def _history_path(addon):
    return os.path.join(_profile_path(addon), _HISTORY_FILE)


def _load_history(addon):
    path = _history_path(addon)
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        entries = data if isinstance(data, list) else []
    except Exception:
        entries = []
    valid = []
    for item in entries:
        if not isinstance(item, dict):
            continue
        backup_path = xbmcvfs.translatePath(item.get("path", ""))
        if backup_path and os.path.isfile(backup_path):
            item["path"] = backup_path
            valid.append(item)
    if valid != entries:
        try:
            _atomic_json_write(path, valid[:_MAX_HISTORY])
        except Exception:
            pass
    return valid[:_MAX_HISTORY]


def _remember_backup(addon, manifest, path):
    history = _load_history(addon)
    real_path = xbmcvfs.translatePath(path)
    history = [item for item in history if item.get("path") != real_path]
    history.insert(0, {
        "path": real_path,
        "created_at": manifest.get("created_at", ""),
        "addon_version": manifest.get("addon_version", ""),
        "groups": manifest.get("favorite_groups", 0),
        "channels": manifest.get("favorite_channels", 0),
        "icons": manifest.get("favorite_icons", 0),
    })
    _atomic_json_write(_history_path(addon), history[:_MAX_HISTORY])


def _iter_backup_files(profile_dir):
    for filename in _PROFILE_FILES:
        path = os.path.join(profile_dir, filename)
        if os.path.isfile(path):
            yield path, filename

    for dirname in _PROFILE_DIRS:
        base = os.path.join(profile_dir, dirname)
        if not os.path.isdir(base):
            continue
        for root, _, files in os.walk(base):
            for filename in files:
                source = os.path.join(root, filename)
                relative = os.path.relpath(source, profile_dir).replace("\\", "/")
                yield source, relative


def _count_profile_data(profile_dir):
    groups_dir = os.path.join(profile_dir, "favgroups")
    icons_dir = os.path.join(profile_dir, "favo_icons")
    groups = 0
    channels = 0
    icons = 0
    if os.path.isdir(groups_dir):
        for filename in os.listdir(groups_dir):
            if not filename.lower().endswith(".m3u"):
                continue
            groups += 1
            path = os.path.join(groups_dir, filename)
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as handle:
                    channels += sum(1 for line in handle if line.lstrip().startswith("#EXTINF"))
            except Exception:
                pass
    if os.path.isdir(icons_dir):
        for _, _, files in os.walk(icons_dir):
            icons += sum(1 for filename in files if filename.lower().endswith((".png", ".jpg", ".jpeg", ".webp")))
    return groups, channels, icons


def _kodi_version():
    value = xbmc.getInfoLabel("System.BuildVersion") or "unbekannt"
    return value.strip()


def _format_created(value):
    try:
        dt = datetime.datetime.fromisoformat(value)
        return dt.strftime("%d.%m.%Y, %H:%M Uhr")
    except Exception:
        return value or "unbekannt"


def _build_readme(manifest):
    return (
        "Vavoo TV Plus Sicherung\n"
        "=========================\n\n"
        "Erstellt: {created}\n"
        "Addon-Version: {version}\n"
        "Kodi-Version: {kodi}\n\n"
        "Inhalt:\n"
        "- Favoritengruppen: {groups}\n"
        "- Favoritensender: {channels}\n"
        "- Eigene Favoritenbilder: {icons}\n"
        "- Addon-Einstellungen und EPG-Konfiguration\n"
        "- Bevorzugte Quellen und Wartungsdaten\n\n"
        "Cache-Dateien sind bewusst nicht enthalten und werden nach einer\n"
        "Wiederherstellung automatisch neu aufgebaut.\n"
    ).format(
        created=_format_created(manifest.get("created_at")),
        version=manifest.get("addon_version") or "unbekannt",
        kodi=manifest.get("kodi_version") or "unbekannt",
        groups=manifest.get("favorite_groups", 0),
        channels=manifest.get("favorite_channels", 0),
        icons=manifest.get("favorite_icons", 0),
    )


def _write_archive(addon, destination):
    profile_dir = _profile_path(addon)
    os.makedirs(profile_dir, exist_ok=True)
    entries = list(_iter_backup_files(profile_dir))
    groups, channels, icons = _count_profile_data(profile_dir)
    manifest = {
        "backup_format": _BACKUP_FORMAT,
        "addon_id": addon.getAddonInfo("id"),
        "addon_name": addon.getAddonInfo("name"),
        "addon_version": addon.getAddonInfo("version"),
        "kodi_version": _kodi_version(),
        "created_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "favorite_groups": groups,
        "favorite_channels": channels,
        "favorite_icons": icons,
        "cache_included": False,
        "files": [arcname for _, arcname in entries],
    }

    destination_dir = os.path.dirname(destination)
    if destination_dir:
        os.makedirs(destination_dir, exist_ok=True)
    fd, temp_path = tempfile.mkstemp(prefix=".vavootv-backup-", suffix=".zip", dir=destination_dir or None)
    os.close(fd)
    try:
        with zipfile.ZipFile(temp_path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(_MANIFEST_NAME, json.dumps(manifest, ensure_ascii=False, indent=2))
            archive.writestr(_README_NAME, _build_readme(manifest))
            for source, arcname in entries:
                archive.write(source, arcname)
        os.replace(temp_path, destination)
    except Exception:
        try:
            os.remove(temp_path)
        except OSError:
            pass
        raise
    return manifest


def _backup_preview(addon_name, profile_dir):
    groups, channels, icons = _count_profile_data(profile_dir)
    message = (
        "Folgende Daten werden gesichert:\n\n"
        "- Favoriten und Favoritengruppen\n"
        "- Eigene Favoritenbilder\n"
        "- Einstellungen und EPG-Konfiguration\n"
        "- Bevorzugte Quellen und Wartungsdaten\n\n"
        "Gruppen: %d\nSender: %d\nEigene Bilder: %d\n\n"
        "Cache-Dateien werden nicht gesichert."
    ) % (groups, channels, icons)
    return xbmcgui.Dialog().yesno(addon_name, message, nolabel="Abbrechen", yeslabel="Sicherung erstellen")


def create_complete(addon, addon_name):
    """Create one ZIP containing favorites, user icons, settings and metadata."""
    profile_dir = _profile_path(addon)
    if not _backup_preview(addon_name, profile_dir):
        return False

    save_dir = xbmcgui.Dialog().browse(
        3,
        "Speicherort fuer Sicherung waehlen",
        "files",
        "",
        False,
        False,
        _default_start_dir(),
    )
    if not save_dir:
        return False

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = "VavooTVPlus-Komplettsicherung-%s.zip" % timestamp
    destination = os.path.join(xbmcvfs.translatePath(save_dir), filename)
    try:
        manifest = _write_archive(addon, destination)
        _remember_backup(addon, manifest, destination)
        xbmcgui.Dialog().notification(
            addon_name,
            "Sicherung wurde erstellt",
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        return True
    except Exception as exc:
        xbmc.log("[VavooTV] complete backup failed: %s" % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(addon_name, "Sicherung konnte nicht erstellt werden.\n\n%s" % exc)
        return False


def _read_manifest(archive):
    try:
        raw = archive.read(_MANIFEST_NAME).decode("utf-8")
        manifest = json.loads(raw)
    except Exception as exc:
        raise ValueError("Keine gueltige Vavoo-TV-Plus-Sicherung: %s" % exc)
    if manifest.get("backup_format") != _BACKUP_FORMAT:
        raise ValueError("Nicht unterstuetztes Sicherungsformat.")
    return manifest


def _validate_archive(archive, addon_id):
    manifest = _read_manifest(archive)
    if manifest.get("addon_id") not in (None, "", addon_id):
        raise ValueError("Die Sicherung gehoert zu einem anderen Addon.")

    bad_file = archive.testzip()
    if bad_file:
        raise ValueError("Die Sicherung ist beschaedigt: %s" % bad_file)

    allowed_roots = set(_PROFILE_FILES) | set(_PROFILE_DIRS) | {_MANIFEST_NAME, _README_NAME}
    for info in archive.infolist():
        name = info.filename.replace("\\", "/").rstrip("/")
        if not name:
            continue
        if not _safe_name(name):
            raise ValueError("Unsicherer Dateipfad in der Sicherung: %s" % name)
        root = name.split("/", 1)[0]
        if root not in allowed_roots:
            raise ValueError("Unbekannter Inhalt in der Sicherung: %s" % name)
    return manifest


def _create_recovery_backup(addon):
    profile_dir = _profile_path(addon)
    recovery_dir = os.path.join(profile_dir, "restore_backups")
    os.makedirs(recovery_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    destination = os.path.join(recovery_dir, "Vor-Wiederherstellung-%s.zip" % timestamp)
    _write_archive(addon, destination)
    return destination


def _browse_backup():
    selected = xbmcgui.Dialog().browse(
        1,
        "Sicherung auswaehlen",
        "files",
        ".zip",
        False,
        False,
        _default_start_dir(),
    )
    return xbmcvfs.translatePath(selected) if selected else ""


def _select_backup(addon):
    history = _load_history(addon)
    if not history:
        return _browse_backup()
    labels = []
    for item in history:
        labels.append("%s - Version %s" % (
            _format_created(item.get("created_at")),
            item.get("addon_version") or "unbekannt",
        ))
    labels.append("Andere Sicherung auswaehlen")
    choice = xbmcgui.Dialog().select("Sicherungen", labels)
    if choice < 0:
        return ""
    if choice == len(history):
        return _browse_backup()
    return history[choice].get("path", "")


def _check_free_space(profile_dir, archive):
    required = sum(info.file_size for info in archive.infolist()) * 2 + (10 * 1024 * 1024)
    try:
        free = shutil.disk_usage(profile_dir).free
    except Exception:
        return
    if free < required:
        raise ValueError("Nicht genuegend freier Speicher fuer die Wiederherstellung.")


def _clear_runtime_cache(profile_dir):
    cache_dir = os.path.join(profile_dir, "cache")
    if os.path.isdir(cache_dir):
        shutil.rmtree(cache_dir, ignore_errors=True)
    os.makedirs(cache_dir, exist_ok=True)


def restore_complete(addon, addon_name):
    """Restore a validated complete backup after creating a recovery archive."""
    selected = _select_backup(addon)
    if not selected:
        return False

    try:
        with zipfile.ZipFile(selected, "r") as archive:
            manifest = _validate_archive(archive, addon.getAddonInfo("id"))
            profile_dir = _profile_path(addon)
            os.makedirs(profile_dir, exist_ok=True)
            _check_free_space(profile_dir, archive)

            details = (
                "Sicherung wiederherstellen?\n\n"
                "Erstellt: %s\n"
                "Addon-Version: %s\n"
                "Kodi-Version: %s\n"
                "Gruppen: %s\n"
                "Sender: %s\n"
                "Eigene Bilder: %s\n\n"
                "Vorher wird automatisch eine Rueckfallsicherung erstellt.\n"
                "Vorhandene Favoriten und Einstellungen werden ersetzt."
            ) % (
                _format_created(manifest.get("created_at")),
                manifest.get("addon_version") or "unbekannt",
                manifest.get("kodi_version") or "unbekannt",
                manifest.get("favorite_groups", "unbekannt"),
                manifest.get("favorite_channels", "unbekannt"),
                manifest.get("favorite_icons", "unbekannt"),
            )
            if not xbmcgui.Dialog().yesno(addon_name, details, nolabel="Abbrechen", yeslabel="Wiederherstellen"):
                return False

            recovery_path = _create_recovery_backup(addon)
            temp_dir = tempfile.mkdtemp(prefix="vavootv-restore-", dir=profile_dir)
            try:
                archive.extractall(temp_dir)

                for dirname in _PROFILE_DIRS:
                    source_dir = os.path.join(temp_dir, dirname)
                    if not os.path.isdir(source_dir):
                        continue
                    destination_dir = os.path.join(profile_dir, dirname)
                    if os.path.isdir(destination_dir):
                        shutil.rmtree(destination_dir)
                    shutil.copytree(source_dir, destination_dir)

                for filename in _PROFILE_FILES:
                    source = os.path.join(temp_dir, filename)
                    if not os.path.isfile(source):
                        continue
                    destination = os.path.join(profile_dir, filename)
                    temp_destination = destination + ".restore.tmp"
                    shutil.copy2(source, temp_destination)
                    os.replace(temp_destination, destination)
            finally:
                shutil.rmtree(temp_dir, ignore_errors=True)

            _clear_runtime_cache(profile_dir)

        restart_now = xbmcgui.Dialog().yesno(
            addon_name,
            "Sicherung wurde erfolgreich wiederhergestellt.\n\n"
            "Der Cache wurde bereinigt und wird neu aufgebaut.\n"
            "Rueckfallsicherung:\n%s\n\n"
            "Kodi sollte jetzt neu gestartet werden.\nKodi jetzt beenden?" % recovery_path,
            nolabel="Spaeter",
            yeslabel="Kodi beenden",
        )
        if restart_now:
            xbmc.executebuiltin("Quit")
        return True
    except Exception as exc:
        xbmc.log("[VavooTV] complete restore failed: %s" % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(addon_name, "Wiederherstellung fehlgeschlagen.\n\n%s" % exc)
        return False


def get_last_backup(addon):
    history = _load_history(addon)
    return history[0] if history else None


def last_backup_label(addon):
    item = get_last_backup(addon)
    if not item:
        return "Letzte Sicherung: noch keine Sicherung vorhanden"
    return "Letzte Sicherung: %s" % _format_created(item.get("created_at"))


def show_last_backup(addon, addon_name):
    item = get_last_backup(addon)
    if not item:
        xbmcgui.Dialog().ok(addon_name, "Es wurde noch keine Sicherung erstellt.")
        return False
    xbmcgui.Dialog().textviewer(
        "Letzte Sicherung",
        "Erstellt: %s\nVersion: %s\nGruppen: %s\nSender: %s\nEigene Bilder: %s\n\nDatei:\n%s" % (
            _format_created(item.get("created_at")),
            item.get("addon_version") or "unbekannt",
            item.get("groups", 0),
            item.get("channels", 0),
            item.get("icons", 0),
            item.get("path", ""),
        ),
    )
    return True
