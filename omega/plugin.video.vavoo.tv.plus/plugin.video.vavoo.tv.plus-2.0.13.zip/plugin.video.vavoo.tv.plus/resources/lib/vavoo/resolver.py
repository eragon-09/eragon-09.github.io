from vavoo.catalog import GEIL_HEADERS
from urllib.parse import urlsplit

def resolve_stream(url, *, session, decode, resolve_url, log, xbmc, addon, check_stream_func, **kwargs):
    try:
        parsed = urlsplit(url)
        if parsed.hostname != 'geil.to' or not parsed.path.startswith('/live/play/'):
            return None, {}
        r = session.get(resolve_url, params={'region':'US','language':'de','url':url}, headers=GEIL_HEADERS, timeout=(3,8))
        log(f'GEIL Resolve HTTP {r.status_code}', xbmc.LOGINFO)
        r.raise_for_status()
        result = decode(r)
        stream = result.get('url','') if isinstance(result,dict) else ''
        if urlsplit(stream).scheme not in ('http','https'):
            return None, {}
        headers = dict(result.get('headers') or {})
        headers.setdefault('User-Agent', GEIL_HEADERS['User-Agent'])
        if addon.getSettingBool('stream_check') and not check_stream_func(stream, headers):
            return None, {}
        return stream, headers
    except Exception as exc:
        log('GEIL Resolve FAILED: ' + str(exc), xbmc.LOGERROR)
        return None, {}
