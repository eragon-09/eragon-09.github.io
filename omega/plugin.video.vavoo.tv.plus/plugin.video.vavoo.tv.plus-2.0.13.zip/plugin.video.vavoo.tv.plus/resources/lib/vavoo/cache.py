# -*- coding: utf-8 -*-
"""Persistenter JSON-Cache mit schneller In-Memory-Schicht.

Der Disk-Cache bleibt vollständig kompatibel. Häufig gelesene Einträge werden
zusätzlich im Prozessspeicher gehalten, damit wiederholte Dateizugriffe während
eines Addon-Aufrufs entfallen. Zur Sicherheit werden Werte als Kopie ausgegeben.
"""

import copy
import hashlib
import json
import os
import time

import xbmcaddon
import xbmcvfs

from utils.io import atomic_write_json
from utils.performance import measure, record


def _build_cache_dir():
    try:
        addon = xbmcaddon.Addon()
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        cache_dir = os.path.join(profile, "cache")
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir
    except Exception:
        return ""


_CACHE_DIR = _build_cache_dir()
_MEMORY_CACHE = {}


def _cache_path(key):
    """Erzeugt einen sicheren Dateipfad für einen beliebigen Cache-Key."""
    safe = hashlib.md5(str(key).encode("utf-8")).hexdigest()
    return os.path.join(_CACHE_DIR, safe + ".json") if _CACHE_DIR else ""


def _is_expired(expires):
    return bool(expires and expires < int(time.time()))


def cache_set(key, value, ttl_seconds=0):
    """Speichert einen Wert im RAM und auf Disk; TTL 0 läuft nicht ab."""
    expires = int(time.time()) + ttl_seconds if ttl_seconds else 0
    _MEMORY_CACHE[str(key)] = {
        "expires": expires,
        "value": copy.deepcopy(value),
    }

    path = _cache_path(key)
    if not path:
        return
    try:
        with measure("cache.set", "disk"):
            atomic_write_json(path, {"expires": expires, "value": value})
    except Exception:
        pass


def cache_get(key):
    """Liest zuerst aus dem RAM, danach von Disk; Rückgabe ``(gefunden, wert)``."""
    memory_key = str(key)
    memory = _MEMORY_CACHE.get(memory_key)
    if memory:
        if _is_expired(memory.get("expires", 0)):
            _MEMORY_CACHE.pop(memory_key, None)
        else:
            record("cache.get", 0.0, "ram")
            return True, copy.deepcopy(memory.get("value"))

    path = _cache_path(key)
    if not path or not os.path.exists(path):
        return False, None
    try:
        with measure("cache.get", "disk"):
            with open(path, encoding="utf-8") as handle:
                data = json.load(handle)
        expires = data.get("expires", 0)
        if _is_expired(expires):
            os.remove(path)
            return False, None
        value = data["value"]
        _MEMORY_CACHE[memory_key] = {
            "expires": expires,
            "value": copy.deepcopy(value),
        }
        return True, copy.deepcopy(value)
    except Exception:
        try:
            os.remove(path)
        except OSError:
            pass
        _MEMORY_CACHE.pop(memory_key, None)
        return False, None


def cache_del(key):
    """Löscht einen Cache-Eintrag aus RAM und Disk."""
    _MEMORY_CACHE.pop(str(key), None)
    path = _cache_path(key)
    if path and os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            pass
