# -*- coding: utf-8 -*-
"""Live-TV-Katalog für Vavoo TV Plus.

Dieses Modul enthält ausschließlich das Laden der Länder und Senderlisten.
Netzwerk, Authentifizierung und Disk-Cache werden von ``vavoo_api`` übergeben,
damit das Modul unabhängig bleibt und keine zyklischen Importe entstehen.
"""

import re
import time
import xbmc

from utils.performance import measure

COUNTRY_CACHE_TTL = 18000
CHANNEL_CACHE_TTL = 10800

_countries_cache = {"data": None, "ts": 0}
_group_cache = {}


def get_available_countries(force, session, decode, log, index_url, fallback_countries=None):
    now = time.time()
    if not force and _countries_cache['data'] and now - _countries_cache['ts'] < COUNTRY_CACHE_TTL:
        return _countries_cache['data']
    try:
        r = session.get(index_url, params={'region':'US','language':'de','sort':'trending','filter[group]':'Germany'}, headers=GEIL_HEADERS, timeout=(3,8))
        r.raise_for_status()
        groups = next(f['values'] for f in decode(r)['features']['filter'] if f['id']=='group')
        countries = sorted({g['id'] for g in groups})
        if countries:
            _countries_cache.update(data=countries, ts=now)
            return countries
    except Exception as exc:
        log('GEIL Laender: %s' % exc, xbmc.LOGWARNING)
    return _countries_cache['data'] or sorted(fallback_countries or ['Germany'])


GEIL_HEADERS = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0','Accept':'application/json','Referer':'https://geil.to/'}


def fetch_channels_page(sig, group, cursor, session, decode, log, api_headers, catalog_url, catalog_id, client_version):
    params = {'region':'US','language':'de','sort':'trending','filter[group]':group}
    if cursor:
        params['cursor'] = str(cursor)
    try:
        with measure('catalog.page', f'{group}:{cursor}'):
            response = session.get(catalog_url, params=params, headers=GEIL_HEADERS, timeout=(3,8))
        log(f'GEIL Catalog HTTP {response.status_code} group={group} cursor={cursor}', xbmc.LOGINFO)
        response.raise_for_status()
        result = decode(response)
        if not isinstance(result, dict) or not isinstance(result.get('items'), list):
            raise ValueError('Ungueltige Katalogantwort')
        return result
    except Exception as exc:
        log(f'GEIL Catalog FAILED: {exc}', xbmc.LOGERROR)
        return None


def normalize_name(name):
    return re.sub(r"\s+\.[a-zA-Z]$", "", name.strip())


def fetch_channels_for_group(
    group, force, fetch_page, get_signature, cache_get, cache_set, log, strict_refresh=False,
):
    now = time.time()
    cached = _group_cache.get(group)
    if not force and cached and (now - cached["ts"]) < CHANNEL_CACHE_TTL:
        log(f"Cache '{group}' ({len(cached['data'])} Kanäle)")
        return cached["data"]

    if not force:
        ok, disk_data = cache_get(f"geil_channels_{group}")
        if ok and disk_data:
            log(f"Disk-Cache '{group}' ({len(disk_data)} Kanäle)", xbmc.LOGINFO)
            _group_cache[group] = {"data": disk_data, "ts": now}
            return disk_data

    sig = get_signature()
    if not sig:
        if strict_refresh:
            raise RuntimeError("Keine Authentifizierungssignatur erhalten")
        return cached["data"] if cached else {}

    channels = {}
    cursor = 0
    page = 0
    seen_cursors = set()
    while page < 100:
        page += 1
        result = fetch_page(sig, group, cursor)
        if not isinstance(result, dict):
            if strict_refresh:
                raise RuntimeError("Ungültige Antwort vom Senderkatalog")
            _, old_data = cache_get(f"geil_channels_{group}")
            return (cached or {}).get("data") or old_data or cache_get(f"geil_last_good_channels_{group}")[1] or {}
        items = result.get("items", [])
        if not items:
            break

        for item in items:
            raw = item.get("name", "").strip()
            url = item.get("url", "")
            if not raw or not url:
                continue
            norm = normalize_name(raw)
            channels.setdefault(norm, []).append(url)

        next_cursor = result.get("nextCursor")
        if (
            next_cursor is None
            or next_cursor in (0, "0", "")
            or str(next_cursor) in seen_cursors
        ):
            break
        seen_cursors.add(str(next_cursor))
        cursor = next_cursor

    log(
        f"Gruppe '{group}': {len(channels)} Kanäle in {page} Seite(n)",
        xbmc.LOGINFO,
    )
    if not channels:
        if strict_refresh:
            raise RuntimeError("Keine frischen Senderdaten für %s empfangen" % group)
        if cached and cached.get("data"):
            return cached["data"]
        _, old_data = cache_get(f"geil_channels_{group}")
        return old_data or cache_get(f"geil_last_good_channels_{group}")[1] or {}
    _group_cache[group] = {"data": channels, "ts": now}
    cache_set(f"geil_channels_{group}", channels, CHANNEL_CACHE_TTL)
    cache_set(f"geil_last_good_channels_{group}", channels, 0)
    return channels
