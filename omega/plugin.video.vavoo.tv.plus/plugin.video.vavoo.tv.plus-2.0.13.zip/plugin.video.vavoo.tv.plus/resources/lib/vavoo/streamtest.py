# -*- coding: utf-8 -*-
"""Stream reachability and strict HLS validation for Vavoo TV Plus."""

def check_stream(url, headers=None, timeout=8, *, session, user_agent, log, xbmc):
    """Prüft auf Videodaten und verwirft HTML-/VYPN-Zwischenseiten."""
    if not url:
        return None

    try:
        check_url = url.split("|", 1)[0]
        request_headers = dict(headers or {})
        request_headers.setdefault("User-Agent", user_agent)
        request_headers.setdefault("Accept", "*/*")

        response = session.get(
            check_url,
            headers=request_headers,
            stream=True,
            timeout=timeout,
            allow_redirects=True,
        )
        response.raise_for_status()

        content_type = (response.headers.get("Content-Type") or "").lower()
        final_url = (response.url or "").lower()
        first_chunk = next(response.iter_content(chunk_size=4096), b"")
        sample = first_chunk.decode("utf-8", errors="ignore").lower()

        blocked_markers = (
            "<!doctype html", "<html", "www.vypn.net",
            "willst du kostenlos weiterschauen", "gib in vypn",
        )
        if "vypn.net" in final_url or any(marker in sample for marker in blocked_markers):
            log(f"VYPN-/HTML-Zwischenseite erkannt: {response.url}", xbmc.LOGWARNING)
            return None

        if "text/html" in content_type or "text/plain" in content_type:
            log(f"Stream-Check fehlgeschlagen: Content-Type={content_type}", xbmc.LOGWARNING)
            return None

        log(f"Stream-Check OK: {url[:80]}", xbmc.LOGINFO)
        return url
    except Exception as exc:
        log(f"Stream-Check Fehler: {exc}", xbmc.LOGWARNING)
        return None


def validate_hls_stream(url, headers=None, timeout=8, *, session, user_agent, log, xbmc):
    """Prüft eine URL streng auf eine echte HLS-Playlist."""
    if not url:
        return False
    try:
        from urllib.parse import urljoin

        check_url = url.split("|", 1)[0]
        request_headers = dict(headers or {})
        request_headers.setdefault("User-Agent", user_agent)
        request_headers.setdefault(
            "Accept", "application/vnd.apple.mpegurl, application/x-mpegURL, */*"
        )

        def load_playlist(target):
            response = session.get(
                target,
                headers=request_headers,
                timeout=timeout,
                allow_redirects=True,
                stream=False,
            )
            response.raise_for_status()
            content_type = (response.headers.get("Content-Type") or "").lower()
            text = (response.text or "").lstrip("\ufeff").strip()
            lower = text[:2048].lower()
            if any(x in lower for x in ("<!doctype html", "<html", "vypn.net", "access denied")):
                return None, None
            if not text.startswith("#EXTM3U"):
                log(f"HLS-Check: keine M3U8-Playlist ({content_type})", xbmc.LOGWARNING)
                return None, None
            return text, response.url

        text, final_url = load_playlist(check_url)
        if not text:
            return False

        lines = [line.strip() for line in text.splitlines() if line.strip()]
        has_media = any(line.startswith(("#EXTINF", "#EXT-X-PART", "#EXT-X-MAP")) for line in lines)
        media_uris = [line for line in lines if not line.startswith("#")]
        if has_media and media_uris:
            log(f"HLS-Check OK (Media): {final_url[:100]}", xbmc.LOGINFO)
            return True

        variant = None
        for index, line in enumerate(lines):
            if line.startswith("#EXT-X-STREAM-INF"):
                for following in lines[index + 1:]:
                    if not following.startswith("#"):
                        variant = urljoin(final_url, following)
                        break
                if variant:
                    break
        if not variant:
            log("HLS-Check: Playlist ohne Medien oder Varianten", xbmc.LOGWARNING)
            return False

        variant_text, variant_final = load_playlist(variant)
        if not variant_text:
            return False
        variant_lines = [line.strip() for line in variant_text.splitlines() if line.strip()]
        has_variant_media = any(
            line.startswith(("#EXTINF", "#EXT-X-PART", "#EXT-X-MAP"))
            for line in variant_lines
        )
        variant_uris = [line for line in variant_lines if not line.startswith("#")]
        ok = bool(has_variant_media and variant_uris)
        log(
            f"HLS-Check {'OK' if ok else 'fehlgeschlagen'} (Variante): {str(variant_final)[:100]}",
            xbmc.LOGINFO if ok else xbmc.LOGWARNING,
        )
        return ok
    except Exception as exc:
        log(f"HLS-Check Fehler: {exc}", xbmc.LOGWARNING)
        return False
