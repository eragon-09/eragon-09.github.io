# -*- coding: utf-8 -*-
"""Gemeinsame Senderaktionen beider EPG-Fenster."""
import xbmc
import xbmcgui

def context_actions(gf, groups, channel, repair_callback):
    if channel.get('_header'):
        return None
    group_file = channel.get('_group_file', '')
    is_catalog = bool(channel.get('_vavoo_catalog'))
    options = ([('Sender hinzufügen', 'add')] if is_catalog else [
        ('Sender prüfen und reparieren', 'repair'),
        ('Sender hinzufügen', 'add'),
        ('Sender nach oben verschieben', 'up'),
        ('Sender nach unten verschieben', 'down'),
        ('Sender umbenennen', 'rename'),
        ('Aus Favoriten entfernen', 'remove')])
    choice = xbmcgui.Dialog().select('MultiEPG – Senderaktionen', [x[0] for x in options])
    if choice < 0:
        return None
    operation = options[choice][1]
    entries = gf.load_group_channels(group_file) if group_file else []
    index = next((i for i, ch in enumerate(entries)
                  if ch.get('url') == channel.get('url')
                  and ch.get('name') == channel.get('name')), None)
    if operation == 'add':
        targets = [g for g in groups if g.get('file') != group_file]
        if not targets:
            xbmcgui.Dialog().notification('VAVOO TV Plus', 'Keine Zielgruppe vorhanden')
            return None
        target_index = xbmcgui.Dialog().select('Zu Favoriten hinzufügen',
                                               [g['name'] for g in targets])
        if target_index < 0:
            return None
        target = targets[target_index]['file']
        saved = gf.load_group_channels(target)
        if any(ch.get('url') == channel.get('url') for ch in saved):
            xbmcgui.Dialog().notification('VAVOO TV Plus', 'Sender bereits vorhanden')
            return None
        saved.append({key: channel.get(key, '') for key in
                      ('name', 'url', 'logo', 'tvg_id')})
        if not gf.save_group_channels(target, saved):
            xbmcgui.Dialog().notification('VAVOO TV Plus', 'Speichern fehlgeschlagen')
            return None
        gf.rebuild_all_favorites_m3u(groups)
        xbmcgui.Dialog().notification('VAVOO TV Plus', 'Sender hinzugefügt')
        return operation
    if index is None:
        xbmcgui.Dialog().notification('VAVOO TV Plus', 'Sender nicht gefunden')
        return None
    if operation == 'repair':
        # Direkt im selben Python-Kontext, ohne RunPlugin / Container.Refresh.
        if not repair_callback(group_file, index):
            return None
        gf.rebuild_all_favorites_m3u(groups)
        updated = gf.load_group_channels(group_file)
        if index < len(updated):
            channel.update({key: updated[index].get(key, '') for key in ('name', 'url', 'logo', 'tvg_id')})
        return operation
    if operation in ('up', 'down'):
        other = index + (-1 if operation == 'up' else 1)
        if not 0 <= other < len(entries):
            return None
        entries[index], entries[other] = entries[other], entries[index]
        if not gf.save_group_channels(group_file, entries):
            return None
    elif operation == 'rename':
        name = xbmcgui.Dialog().input('Sender umbenennen',
                                      defaultt=channel.get('name', ''),
                                      type=xbmcgui.INPUT_ALPHANUM).strip()
        if not name or name == channel.get('name'):
            return None
        entries[index]['name'] = name
        if not gf.save_group_channels(group_file, entries):
            return None
    elif operation == 'remove':
        if not xbmcgui.Dialog().yesno('Sender wirklich entfernen?',
                                      '„{}“ aus dieser Favoritengruppe entfernen?'.format(
                                          channel.get('name', ''))):
            return None
        del entries[index]
        if not gf.save_group_channels(group_file, entries):
            return None
    try:
        gf.rebuild_all_favorites_m3u(groups)
    except Exception as exc:
        xbmc.log('MultiEPG: Sammel-M3U: %s' % exc, xbmc.LOGWARNING)
    return operation
