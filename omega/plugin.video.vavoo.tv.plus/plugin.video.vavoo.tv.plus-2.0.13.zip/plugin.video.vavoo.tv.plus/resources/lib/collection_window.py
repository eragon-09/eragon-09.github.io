"""Full-screen collection preview; playback remains in vod_comfort."""
import time
from concurrent.futures import ThreadPoolExecutor
import xbmcgui
import xbmcaddon

def entry_key(x):
    return str(x['id']) + (':%s:%s' % (x['s'], x['e']) if x.get('e') else '')

def progress(r):
    return max(0,min(100,int(100*r.get('pos',0)/r['total']))) if r.get('total') and not r.get('seen') else 0

class CollectionWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.entries=kwargs['entries']; self.name=kwargs['name']; self.state=kwargs['state']
        self.series=bool(self.entries[0].get('e')); self.collection=kwargs.get('collection',False); self.index=kwargs['index']; self.seconds=kwargs['seconds']; self.ready=False
        self.done=False; self.result=None; self.paused=not bool(self.seconds); self.user_navigation=False
    def onInit(self):
        self.getControl(10).setLabel(self.name)
        if self.collection or self.series:
            released=[x for x in self.entries if not x.get('releaseDate') or x['releaseDate']<=time.strftime('%Y-%m-%d')]
            count=sum(bool(self.state.get(entry_key(x),{}).get('seen')) for x in released)
            self.getControl(18).setLabel('%d von %d %s gesehen'%(count,len(released),'Folgen' if self.series else 'Filmen'))
            self.getControl(22).setVisible(True); self.getControl(23).setVisible(count>0)
            self.getControl(23).setWidth(max(1,int(520*count/max(1,len(released)))))
        self.list=self.getControl(100)
        # Filmreihen erhalten eine eigene Anordnung. Serien (einschliesslich
        # Next-Episode-Countdown und Ladebalken) behalten das bisherige Layout.
        if not self.series:
            # Eigene, dezent groessere tuerkise Ueberschrift nur fuer Filmreihen.
            # Das Serien-Countdown-Label (15) bleibt unveraendert.
            self.getControl(15).setVisible(False)
            self.getControl(29).setVisible(True)
            self.list.setPosition(630, 236)
            self.list.setHeight(664)
            self.getControl(101).setPosition(654, 925)
            self.getControl(102).setPosition(1016, 925)
            # Fuer die getrennte TMDB-Zeile die Beschreibung tiefer beginnen.
            self.getControl(13).setPosition(60, 392)
            self.getControl(13).setHeight(493)
        else:
            # Eigenes Serienlayout: Countdown und Balken zentriert unter der
            # Episodenliste; Filmreihen-Layout bleibt davon unberuehrt.
            self.getControl(29).setVisible(False)
            self.getControl(15).setVisible(True)
            self.getControl(15).setPosition(654, 917)
            self.getControl(15).setWidth(690)
            self.getControl(16).setPosition(654, 978)
            self.getControl(16).setWidth(672)
            self.getControl(17).setPosition(654, 978)
            self.getControl(101).setPosition(654, 995)
            self.getControl(102).setPosition(1016, 995)
        for x in self.entries:
            r=self.state.get(entry_key(x),{}); seen=r.get('seen')
            future=x.get('releaseDate','')>time.strftime('%Y-%m-%d')
            status='Noch nicht veröffentlicht' if future else ('Gesehen' if seen else 'Ungesehen')
            pct=progress(r)
            if pct and not future: status='Angefangen · %d %%'%pct
            color='FF8FE6A0' if seen and not future else 'FF8ADCEB'
            status='[COLOR '+color+']'+status+'[/COLOR]'
            li=xbmcgui.ListItem(x['n'],status)
            if self.series: li.setLabel('Folge %02d · %s'%(int(x['e']),x.get('ep_name') or 'Episode'))
            year=x.get('releaseDate','')[:4]
            if year and not self.series: li.setLabel(x['n']+' - ('+year+')')
            self.list.addItem(li)
        self.setFocusId(100); self.list.selectItem(self.index)
        self.update_details(); self.ready=True
    def update_details(self):
        x=self.entries[self.index]
        self.getControl(11).setLabel(('Folge %02d · %s'%(int(x['e']),x.get('ep_name') or 'Episode')) if self.series else x['n'])
        r=self.state.get(entry_key(x),{}); pct=progress(r)
        self.getControl(19).setVisible(bool(pct)); self.getControl(20).setVisible(bool(pct)); self.getControl(20).setWidth(max(1,int(520*pct/100)))
        self.getControl(21).setLabel(x.get('details',''))
        self.getControl(12).setLabel(self.list.getListItem(self.index).getLabel2())
        self.getControl(13).setText(x.get('plot') or 'Keine Beschreibung verfügbar.')
        self.getControl(14).setImage(x.get('still') or x.get('poster') or '')
        self.getControl(14).setPosition(1390, 165 if self.series else 155)
        self.getControl(14).setHeight(300 if self.series else 750)
        for cid in (24,25,26,27,28): self.getControl(cid).setVisible(self.series)
        if self.series:
            self.getControl(25).setLabel(x.get('ep_name') or 'Episode')
            self.getControl(26).setLabel('Staffel %s · Folge %s'%(x['s'],x['e']))
            date=x.get('releaseDate') or ''
            self.getControl(27).setLabel('Erstausstrahlung: '+(date[8:10]+'.'+date[5:7]+'.'+date[:4] if len(date)>=10 else 'Nicht verfügbar'))
            self.getControl(28).setLabel(x.get('details','')+' · '+self.list.getListItem(self.index).getLabel2())
        self.getControl(2).setImage(x.get('fanart') or x.get('poster') or '')
    def choose(self):
        if not self.ready: return
        i=self.list.getSelectedPosition()
        if 0<=i<len(self.entries):
            x=self.entries[i]
            if x.get('releaseDate','')>time.strftime('%Y-%m-%d'): return
            self.result=x; self.done=True
    def onClick(self, controlId):
        if controlId in (100,101): self.choose()
        elif controlId==102: self.done=True
    def onAction(self, action):
        if action.getId() in (9,10,92): self.done=True
        elif action.getId() in (1,2,3,4,5,6,7,104,105,106,107,108,109):
            if self.ready: self.user_navigation=True

def show(name, entries, nxt, state, seconds, player, monitor, collection=False):
    index=next(i for i,x in enumerate(entries) if entry_key(x)==entry_key(nxt))
    dialog=CollectionWindow('CollectionAutoplay.xml',xbmcaddon.Addon().getAddonInfo('path'),'Default','1080i',entries=entries,name=name,state=state,index=index,seconds=seconds,collection=collection)
    pool=None; pending={}
    if not nxt.get('e'):
        from tmdb_collections import get
        pool=ThreadPoolExecutor(max_workers=2)
        def details(x):
            m=get('/movie/'+str(x['tmdb']))
            return ' · '.join(v for v in (('%d Min.'%m['runtime']) if m.get('runtime') else '', ', '.join(g['name'] for g in m.get('genres',[])[:2] if g.get('name'))) if v) + (('\nTMDB %.1f/10' % m['vote_average']) if m.get('vote_count') and m.get('vote_average') else '')
    try:
        dialog.show(); deadline=None; last_remaining=None
        while not monitor.abortRequested() and not player.isPlaying() and not dialog.done:
            if dialog.ready:
                if deadline is None: deadline=time.monotonic()+seconds
                i=dialog.list.getSelectedPosition()
                if 0<=i<len(entries) and i!=dialog.index:
                    if dialog.user_navigation:
                        dialog.index=i; dialog.paused=True; dialog.update_details()
                    else:
                        dialog.list.selectItem(dialog.index)
                if pool:
                    x=entries[dialog.index]; k=entry_key(x)
                    if k not in pending: pending[k]=pool.submit(details,x)
                    if pending[k].done():
                        try: x['details']=pending[k].result()
                        except Exception: x['details']=''
                        dialog.getControl(21).setLabel(x['details'])
                remaining=max(0,int(deadline-time.monotonic()+0.999))
                if remaining!=last_remaining or dialog.paused:
                    # Filmreihen nutzen die eigene Akzent-Ueberschrift (29),
                    # Serien weiterhin das originale Countdown-Label (15).
                    dialog.getControl(15 if dialog.series else 29).setLabel((('Wähle deine nächste Folge' if dialog.series else '[B]Wähle deinen nächsten Film[/B]') if not seconds else ('Autoplay pausiert – Folge auswählen' if dialog.series else 'Autoplay pausiert – Film auswählen')) if dialog.paused else ('[B]Nächste Folge startet in %d Sekunden[/B]' if dialog.series else 'Nächster Film startet in %d Sekunden')%remaining)
                    dialog.getControl(16).setVisible(not dialog.paused)
                    dialog.getControl(17).setVisible(not dialog.paused)
                    dialog.getControl(17).setWidth(max(1,int((672 if dialog.series else 1100)*remaining/max(1,seconds))))
                    last_remaining=remaining
                if not dialog.paused and time.monotonic()>=deadline: return nxt
            if monitor.waitForAbort(0.1): break
        return dialog.result if not monitor.abortRequested() and not player.isPlaying() else None
    finally:
        dialog.close()
        if pool:
            for future in pending.values(): future.cancel()
            pool.shutdown(wait=False)
