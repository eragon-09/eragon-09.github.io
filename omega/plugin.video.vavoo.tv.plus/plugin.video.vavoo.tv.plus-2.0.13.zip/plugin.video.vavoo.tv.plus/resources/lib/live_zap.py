# -*- coding: utf-8 -*-
"""Native Kodi video playlist; resolve only the selected live channel."""
from urllib.parse import urlencode
import xbmc
import xbmcgui


def channel_entries(channels, chosen):
    valid = [c for c in channels if not c.get('_header') and c.get('url') and c.get('name')]
    index = next((i for i, c in enumerate(valid) if c is chosen), None)
    if index is None:
        index = next((i for i, c in enumerate(valid) if c == chosen), None)
    if index is None:
        valid = [chosen]
        index = 0
    return valid, index


def start_channel_playlist(channels, chosen):
    valid, index = channel_entries(channels, chosen)
    paths = []
    for channel in valid:
        params = dict(action='play_live_zap', url=channel['url'], name=channel['name'],
                      tvg_id=channel.get('tvg_id') or '', logo=channel.get('logo') or '',
                      file=channel.get('_group_file') or '')
        paths.append('plugin://plugin.video.vavoo.tv.plus/?' + urlencode(params))
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    player = xbmc.Player()
    home = xbmcgui.Window(10000)
    # Reopening the guide and selecting the same channel must not restart it.
    if (player.isPlayingVideo() and home.getProperty('VavooTVPlus.Playing') == '1'
            and home.getProperty('VavooTVPlus.FavoriteURL') == chosen['url']
            and playlist.getposition() == index and playlist.size() == len(paths)
            and all(playlist[i].getPath() == path for i, path in enumerate(paths))):
        return
    playlist.clear()
    playlist.unshuffle()
    for channel, path in zip(valid, paths):
        item = xbmcgui.ListItem(label=channel['name'], path=path)
        item.setProperty('IsPlayable', 'true')
        logo = channel.get('logo') or ''
        if logo:
            item.setArt({'thumb': logo, 'icon': logo})
        item.getVideoInfoTag().setTitle(channel['name'])
        playlist.add(path, item)
    player.play(playlist, startpos=index)
