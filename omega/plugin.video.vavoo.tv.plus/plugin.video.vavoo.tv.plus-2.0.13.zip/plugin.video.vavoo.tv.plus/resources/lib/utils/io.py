# -*- coding: utf-8 -*-
"""Robuste, atomare Dateischreibvorgaenge fuer Addon-Daten."""

import json
import os
import tempfile


def _atomic_replace(path, write_callback):
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    fd, temporary_path = tempfile.mkstemp(prefix=".vavoo-", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            write_callback(handle)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        os.replace(temporary_path, path)
        return True
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            if os.path.exists(temporary_path):
                os.remove(temporary_path)
        except OSError:
            pass
        raise


def atomic_write_text(path, text):
    """Schreibt UTF-8-Text ohne Zwischenzustand in die Zieldatei."""
    return _atomic_replace(path, lambda handle: handle.write(text))


def atomic_write_json(path, value, indent=None, sort_keys=False):
    """Schreibt JSON atomar; optionale Formatierung bleibt aufruferspezifisch."""
    return _atomic_replace(
        path,
        lambda handle: json.dump(
            value,
            handle,
            ensure_ascii=False,
            indent=indent,
            sort_keys=sort_keys,
        ),
    )
