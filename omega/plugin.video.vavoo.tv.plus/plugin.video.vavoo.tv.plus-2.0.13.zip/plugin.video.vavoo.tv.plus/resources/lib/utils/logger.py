# -*- coding: utf-8 -*-
"""Einheitliches Kodi-Logging fuer Vavoo TV Plus."""
import xbmc

PREFIX = "[VavooTV]"


def _write(message, level):
    xbmc.log(f"{PREFIX} {message}", level)


def debug(message):
    _write(message, xbmc.LOGDEBUG)


def info(message):
    _write(message, xbmc.LOGINFO)


def warning(message):
    _write(message, xbmc.LOGWARNING)


def error(message):
    _write(message, xbmc.LOGERROR)
