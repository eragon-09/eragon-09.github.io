# -*- coding: utf-8 -*-
"""Leichter interner Performance-Monitor fuer Vavoo TV Plus.

Die Messung veraendert keine Ablaufe und schreibt nur in das Kodi-Log.
Normale Messwerte erscheinen im Debuglog; deutlich langsame Vorgänge werden
als Info protokolliert, damit echte Hotspots leichter auffallen.
"""

import time
from contextlib import contextmanager

import xbmc

_PREFIX = "[VavooTV][PERF]"
_SLOW_MS = 1000.0
_SAMPLES = {}


def record(name, elapsed_ms, detail=""):
    """Speichert eine Messung im Prozessspeicher und protokolliert sie."""
    key = str(name)
    stats = _SAMPLES.setdefault(key, {"count": 0, "total_ms": 0.0, "max_ms": 0.0})
    stats["count"] += 1
    stats["total_ms"] += float(elapsed_ms)
    stats["max_ms"] = max(stats["max_ms"], float(elapsed_ms))

    suffix = f" | {detail}" if detail else ""
    message = f"{_PREFIX} {key}: {elapsed_ms:.1f} ms{suffix}"
    level = xbmc.LOGINFO if elapsed_ms >= _SLOW_MS else xbmc.LOGDEBUG
    xbmc.log(message, level)


@contextmanager
def measure(name, detail=""):
    """Context-Manager fuer risikoarme Zeitmessungen."""
    started = time.perf_counter()
    try:
        yield
    finally:
        record(name, (time.perf_counter() - started) * 1000.0, detail)


def snapshot():
    """Liefert eine Kopie der aktuellen Prozessmesswerte."""
    result = {}
    for name, stats in _SAMPLES.items():
        count = stats["count"] or 1
        result[name] = {
            "count": stats["count"],
            "total_ms": round(stats["total_ms"], 1),
            "average_ms": round(stats["total_ms"] / count, 1),
            "max_ms": round(stats["max_ms"], 1),
        }
    return result
