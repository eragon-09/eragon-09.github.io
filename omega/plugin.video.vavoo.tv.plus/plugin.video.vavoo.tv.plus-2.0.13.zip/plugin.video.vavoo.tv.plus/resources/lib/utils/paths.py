# -*- coding: utf-8 -*-
"""Gemeinsame Pfadhelfer für das Addon."""
import os
import xbmcvfs


def translated(path):
    return xbmcvfs.translatePath(path)


def addon_profile(addon):
    return translated(addon.getAddonInfo("profile"))


def ensure_dir(path):
    if path and not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)
    return path


def profile_file(addon, filename):
    return os.path.join(addon_profile(addon), filename)


def sync_backup_dir(addon):
    return os.path.join(addon_profile(addon), "sync_backups")


def addon_root(addon):
    """Installationsverzeichnis des Addons liefern."""
    return translated(addon.getAddonInfo("path"))


def resources_dir(addon):
    return os.path.join(addon_root(addon), "resources")


def media_dir(addon):
    """Feste Grafiken der Benutzeroberflaeche."""
    return os.path.join(resources_dir(addon), "media")


def art_dir(addon):
    """Austauschbare Inhaltsgrafiken des Addons."""
    return os.path.join(resources_dir(addon), "art")


def bundled_favo_icons_dir(addon):
    return os.path.join(art_dir(addon), "favo_icons")


def user_favo_icons_dir(addon):
    return os.path.join(addon_profile(addon), "favo_icons")


def media_icon_path(addon, filename):
    """Pfad zu einem festen UI-Bild unter resources/media/icons."""
    return os.path.join(media_dir(addon), "icons", filename)


def country_flag_path(addon, country_code):
    """Pfad zu einer mitgelieferten Länderflagge."""
    return os.path.join(resources_dir(addon), "country_flags", f"{country_code}.png")


def default_channel_path(addon):
    """Pfad zum Standardbild für Sender ohne eigenes Logo."""
    return os.path.join(resources_dir(addon), "default_channel.png")
