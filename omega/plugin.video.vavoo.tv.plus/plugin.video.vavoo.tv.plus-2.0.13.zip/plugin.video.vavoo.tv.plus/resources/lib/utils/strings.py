# -*- coding: utf-8 -*-
"""Zentrale, wiederverwendbare Texte für Vavoo TV Plus.

Die Konstanten verändern keine Kodi-Actions oder Datenformate. Sie dienen nur
zur konsistenten Beschriftung von Menüs und Dialogen.
"""

# Hauptmenü
MENU_MOVIES = "Filme"
MENU_SERIES = "Serien"
MENU_SETTINGS = "Einstellungen"

PLOT_LIVE_TV = "{status}. Favoriten, Länder, Genres und A bis Z."
PLOT_MOVIES = "VOD-Filme mit Kategorien, Genres und Suche."
PLOT_SERIES = "VOD-Serien mit Kategorien, Staffeln und Episoden."
PLOT_SETTINGS = "Länder, EPG, Wiedergabe und Ansicht einstellen."

# Live TV
LIVE_FAVORITES = "Meine Favoriten"
LIVE_AZ = "Live A bis Z"
LIVE_GENRES = "Live Genres"
LIVE_COUNTRIES = "Länder"
LIVE_MANAGE_FAVORITES = "Favoriten verwalten"
LIVE_MANAGE_SOURCES = "Quellen verwalten"
LIVE_HELP = "Hilfe"

PLOT_LIVE_AZ = "Alle Live-Sender alphabetisch anzeigen."
PLOT_LIVE_GENRES = "Live-Sender nach Genre anzeigen."
PLOT_LIVE_COUNTRIES = "Live-Sender der ausgewählten Länder anzeigen."
PLOT_LIVE_MANAGE = "Sender aktualisieren, reparieren, sichern sowie M3U importieren oder exportieren."
PLOT_LIVE_SOURCES = "Bevorzugte Quelle eines Favoritensenders anzeigen, wechseln oder zurücksetzen."
PLOT_LIVE_HELP = "Kurze Hilfe zu Favoriten, Aktualisierung, Reparatur und Sicherungen anzeigen."
PLOT_LIVE_ATTENTION = "Auffällige Favoritensender jetzt suchen und reparieren."

# Einstellungen
SETTINGS_COUNTRY_GROUPS = "Ländergruppen auswählen"
SETTINGS_CONFIGURATION = "Einstellungen"

# Wartung und Protokolle
MAINTENANCE_NO_REPORT = "Noch kein gespeicherter Wartungsbericht vorhanden."
MAINTENANCE_REPORT_TITLE = "Letzter Wartungsbericht"
ACTIVITY_LOG_EMPTY = "Das interne Änderungsprotokoll ist noch leer."
ACTIVITY_LOG_TITLE = "Änderungsprotokoll"
ACTIVITY_LOG_ALREADY_EMPTY = "Protokoll ist bereits leer"
ACTIVITY_LOG_CLEAR_CONFIRM = "Internes Änderungsprotokoll wirklich leeren?"
ACTIVITY_LOG_CLEARED = "Protokoll geleert"
ACTIVITY_LOG_DELETE_FAILED = "Protokoll konnte nicht gelöscht werden."
MAINTENANCE_CHECKING = "Favoriten werden lokal geprüft"
MAINTENANCE_CANCELLED = "Prüfung abgebrochen"
MAINTENANCE_BUILDING_REPORT = "Wartungsbericht wird erstellt"
MAINTENANCE_REPORT = "Wartungsbericht"
