# -*- coding: utf-8 -*-
"""Kleine, konsistente Wrapper um Kodi-Standarddialoge."""
import xbmcgui


def info(title, message):
    xbmcgui.Dialog().ok(title, message)


def confirm(title, message):
    return xbmcgui.Dialog().yesno(title, message)


def notify(title, message, duration=2500, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(title, message, icon, duration)


def select(title, items):
    return xbmcgui.Dialog().select(title, items)


def multiselect(title, items, preselect=None):
    kwargs = {}
    if preselect is not None:
        kwargs["preselect"] = preselect
    return xbmcgui.Dialog().multiselect(title, items, **kwargs)


def text(title, content):
    xbmcgui.Dialog().textviewer(title, content)


def progress(title, message=""):
    dialog = xbmcgui.DialogProgress()
    dialog.create(title, message)
    return dialog
