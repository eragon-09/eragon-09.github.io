# -*- coding: utf-8 -*-
"""Schlankes Live-TV-Menue: MultiEPG, Laender und Verwaltung."""
from .runtime import get


def show():
    xbmcplugin = get("xbmcplugin")
    handle = get("HANDLE")
    gf = get("gf")
    make_item = get("_make_menu_item")
    build_url = get("build_url")
    xbmcplugin.setContent(handle, "files")

    # Die Sendergruppen werden nur im MultiEPG und in der Verwaltung angezeigt.
    # Die M3U-Favoritendateien bleiben dabei unveraendert.
    entries = [
        ("MultiEPG", "favorites_epg", False, "multiepg.png",
         "Programmuebersicht deiner Favoriten"),
        ("Sender & Favoriten", "live_sender_favorites", True, "favoriten_verwalten.png",
         "Favoritenlisten und VAVOO Channel Browser"),
        ("Sender aktualisieren & reparieren", "live_sync_menu", True, "favoriten_verwalten.png",
         "Senderlisten aktualisieren und Favoriten reparieren"),
        ("EPG verwalten", "live_epg_menu", True, "multiepg.png",
         "Programmdaten aktualisieren und EPG-Cache verwalten"),
    ]
    for label, action, folder, icon, plot in entries:
        li = make_item(label, icon, plot)
        xbmcplugin.addDirectoryItem(handle, build_url(action=action), li, folder)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def manage():
    """Administrative actions kept one level below Live-TV."""
    xbmcplugin = get("xbmcplugin")
    handle = get("HANDLE")
    make_item = get("_make_menu_item")
    build_url = get("build_url")
    xbmcplugin.setContent(handle, "files")
    entries = [
        ("Meine Favoriten bearbeiten", "live_favorites", True, "favoriten_verwalten.png", "Favoritengruppen und Sender verwalten"),
        ("Laenderlisten aktualisieren", "do_refresh_channels", False, "laender.png", "Senderlisten manuell aktualisieren"),
        ("Eigene Favoritenlisten synchronisieren", "favorites_sync_select", True, "favoriten_verwalten.png", "Eine Favoritenliste mit OK synchronisieren"),
        ("EPG schnell aktualisieren", "do_load_epg", False, "multiepg.png", "EPG neu laden"),
        ("Weitere Laender hinzufuegen", "country_select", False, "laender.png", "Laenderauswahl oeffnen"),
    ]
    for label, action, folder, icon, plot in entries:
        xbmcplugin.addDirectoryItem(handle, build_url(action=action), make_item(label, icon, plot), folder)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _submenu(entries):
    xbmcplugin = get("xbmcplugin")
    handle = get("HANDLE")
    make_item = get("_make_menu_item")
    build_url = get("build_url")
    xbmcplugin.setContent(handle, "files")
    for label, action, folder, icon, plot in entries:
        xbmcplugin.addDirectoryItem(
            handle, build_url(action=action), make_item(label, icon, plot), folder)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def sender_favorites():
    _submenu([
        ("Meine Favoriten", "live_favorites", True, "meine_favoriten.png",
         "Vorhandene Favoritengruppen oeffnen"),
        ("VAVOO Channel Browser", "vavoo_browser", True, "laender.png",
         "Aktuelle Sender durchsuchen und zu Favoriten hinzufuegen"),
        ("Favoritengruppen verwalten", "favorites_manager", True,
         "favoriten_verwalten.png", "Favoriten verwalten, importieren und sichern"),
    ])


def sync_menu():
    _submenu([
        ("VAVOO-Senderliste neu laden", "do_refresh_channels", False,
         "laender.png", "Ausgewaehlte Senderlisten aktualisieren"),
        ("Favoriten schnell aktualisieren", "grp_sync_all_quick", False,
         "favoriten_verwalten.png", "Favoritenabgleich starten"),
        ("Sender pruefen & reparieren", "grp_sync_all_defects", False,
         "favoriten_verwalten.png", "Defekte Streams untersuchen"),
        ("Einzelne Favoritengruppe synchronisieren", "favorites_sync_select", True,
         "meine_favoriten.png", "Favoritengruppe auswaehlen"),
    ])


def epg_menu():
    _submenu([
        (get("ADDON").getLocalizedString(31106), "do_load_epg", False,
         "multiepg.png", get("ADDON").getLocalizedString(31107)),
        (get("ADDON").getLocalizedString(31108), "epg_cache_reload", False,
         "multiepg.png", get("ADDON").getLocalizedString(31109)),
        (get("ADDON").getLocalizedString(31104), "settings", False,
         "settings.png", get("ADDON").getLocalizedString(31105)),
        (get("ADDON").getLocalizedString(31110), "diagnose_favorites_epg", False,
         "multiepg.png", get("ADDON").getLocalizedString(31111)),
    ])
