# -*- coding: utf-8 -*-
"""Menu package facade used by addon.py."""
from .runtime import configure
from .main import show as main_menu
from .live_tv import show as live_tv_menu

__all__ = ["configure", "main_menu", "live_tv_menu"]


def live_tv_manage():
    from .live_tv import manage
    return manage()
