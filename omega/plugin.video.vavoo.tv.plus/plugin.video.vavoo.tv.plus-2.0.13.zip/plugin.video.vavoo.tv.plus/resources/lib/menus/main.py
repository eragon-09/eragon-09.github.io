# -*- coding: utf-8 -*-
"""Main menu view."""
from .runtime import get
from utils import strings


def show():
    is_first_run = get("is_first_run")
    api = get("api")
    run_wizard = get("run_wizard")
    refresh = get("_refresh_selected_countries_and_offer_favorites")
    scan_done = get("_scan_done_this_session")
    check_update = get("_check_for_update_async")
    xbmcplugin = get("xbmcplugin")
    handle = get("HANDLE")
    live_status = get("_live_tv_status")
    make_item = get("_make_menu_item")
    build_url = get("build_url")
    get_active_countries = get("get_active_countries")

    if is_first_run():
        all_countries = api.get_available_countries(force=True)
        if all_countries:
            selected = run_wizard(all_countries)
            if selected is not None:
                refresh(selected)

    if not scan_done():
        check_update()

    xbmcplugin.setContent(handle, "files")
    live_label, live_status_text, _ = live_status()
    items = [
        (live_label, "live_tv", True, "live_tv.png", strings.PLOT_LIVE_TV.format(status=live_status_text)),
        (strings.MENU_MOVIES, "movies_index", True, "filme_premium.png", strings.PLOT_MOVIES),
        (strings.MENU_SERIES, "series_index", True, "serien_premium.png", strings.PLOT_SERIES),
        ("Weiterschauen", "comfort_menu", True, "weiterschauen.png", "Filme und Serien fortsetzen"),
        ("Meine Filme", "comfort_menu", True, "meine_filme.png", "Filmfavoriten"),
        ("Meine Serien", "comfort_menu", True, "meine_serien.png", "Serienfavoriten"),
    ]

    all_countries = api.get_available_countries()
    selected = get_active_countries(all_countries) if all_countries else []
    countries_str = ",".join(selected)
    for label, action, is_folder, icon_name, plot in items:
        li = make_item(label, icon_name, plot)
        kwargs = {"action": action}
        if action == "comfort_menu":
            kwargs["mode"] = {"Weiterschauen":"continue","Meine Filme":"fav_movie","Meine Serien":"fav_series"}[label]
        if action == "live_tv" and countries_str:
            kwargs["countries"] = countries_str
        xbmcplugin.addDirectoryItem(handle, build_url(**kwargs), li, is_folder)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
