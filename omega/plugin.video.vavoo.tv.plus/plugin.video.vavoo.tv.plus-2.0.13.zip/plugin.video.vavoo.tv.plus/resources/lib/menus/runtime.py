# -*- coding: utf-8 -*-
"""Shared runtime namespace for incrementally extracted menu modules."""

_runtime = {}


def configure(namespace):
    """Store references from addon.py without importing it recursively."""
    _runtime.clear()
    _runtime.update({k: v for k, v in namespace.items() if not k.startswith("__")})


def get(name):
    return _runtime[name]
