# -*- coding: utf-8 -*-
"""Gemeinsame Gruppenauswahl und Senderdaten für beide EPG-Ansichten."""

def visible_groups(groups):
    result, files, names = [], set(), set()
    for group in groups:
        filename = (group.get('file') or '').strip().casefold()
        name = (group.get('name') or '').strip().casefold()
        if (not filename or filename in files or name in names
                or filename in ('alle_favoriten.m3u', 'all_favorites.m3u')
                or name in ('alle favoriten', 'meine favoriten')):
            continue
        files.add(filename)
        names.add(name)
        result.append(group)
    return result


def favorite_channels(gf, groups, group_index):
    selected = groups if group_index == -1 else [groups[group_index]]
    channels = []
    for group in selected:
        valid = [dict(ch, _group_file=group['file'])
                 for ch in gf.load_group_channels(group['file'])
                 if ch.get('name') and ch.get('url')]
        if group_index == -1 and valid:
            channels.append({'_header': True, 'name': group['name'],
                             '_group_file': group['file'],
                             'logo': gf.get_group_icon(group['file'])})
        channels.extend(valid)
    return channels


def vavoo_channels(addon):
    from vavoo_api import (get_available_countries, fetch_channels_for_group,
                           get_channel_logo, get_channel_epg_id, parse_country_codes)
    countries = get_available_countries()
    selected = addon.getSetting('selected_countries').strip()
    if selected:
        wanted = parse_country_codes(selected)
        countries = [country for country in countries if country in wanted] or countries
    channels = []
    for country in countries:
        for name, urls in (fetch_channels_for_group(country) or {}).items():
            for url in (urls if isinstance(urls, (list, tuple)) else [urls]):
                if url:
                    channels.append({'name': name, 'url': url,
                                     'logo': get_channel_logo(name) or '',
                                     'tvg_id': get_channel_epg_id(name) or '',
                                     '_vavoo_catalog': True})
    return channels
