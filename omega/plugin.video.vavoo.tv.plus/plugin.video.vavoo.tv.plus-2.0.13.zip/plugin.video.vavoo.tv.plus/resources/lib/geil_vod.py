"""VOD adapter for the observed MHUB JSON API."""
import requests
import xbmcgui
import xbmcaddon
import xbmc
from urllib.parse import quote, unquote, urlencode, urlsplit, parse_qsl

META = 'https://www.mhub.mx/tmdb'
VOD = 'https://geil.to/vod'

def get(base, path, **params):
    try:
        r = requests.get(base + path, params=dict({'region':'US','language':'de'}, **params), timeout=(3, 12), headers={'Accept':'application/json'})
        r.raise_for_status()
        d = r.json()
        return d if isinstance(d, dict) else {}
    except (requests.RequestException, ValueError) as e:
        status = getattr(getattr(e, 'response', None), 'status_code', None)
        xbmc.log('GEIL VOD request failed: %s HTTP %s %s' % (type(e).__name__, status, path), xbmc.LOGWARNING)
        return {}

def listing(vod_type, cursor=None):
    movie = vod_type.startswith('movie')
    kind = 'movie' if movie else 'series'
    params = {'sort':'trendingDay' if '.trending' in vod_type else 'popularity'}
    if '.search=' in vod_type:
        params = {'search': unquote(vod_type.split('.search=',1)[1])}
        xbmc.log('GEIL VOD search: kind=%s query=%s' % (kind, params['search']), xbmc.LOGINFO)
    if '.search=' not in vod_type and '.genre=' in vod_type:
        name = vod_type.split('.genre=',1)[1]
        manifest = get(META, '/mhub-addon.json')
        for cat in manifest.get('catalogs',[]):
            if cat.get('id') == kind:
                for filt in cat.get('features',{}).get('filter',[]):
                    if filt.get('id') == 'genre':
                        for v in filt.get('values',[]):
                            if v.get('name') == name: params['filter[genre]'] = v['id']
        if 'filter[genre]' not in params: return {}
    if cursor: params['cursor'] = cursor
    d = get(META, '/catalog/'+('video' if movie else 'series')+'/'+kind+'.json', **params)
    if '.search=' in vod_type:
        xbmc.log('GEIL VOD search results: kind=%s count=%s' % (kind, len(d.get('items', []))), xbmc.LOGINFO)
    return {'data':[dict(x, id=kind+'.'+str(x['id']), poster=x.get('images',{}).get('poster','')) for x in d.get('items',[]) if x.get('id')], 'next':d.get('nextCursor')}

def seasons(tmdb):
    d = get(META, '/item/series/'+quote(str(tmdb),safe='')+'.json')
    return [{'season_number':int(x['season']), 'episode_count':x.get('count',0), 'name':x.get('name',''), 'poster':x.get('images',{}).get('poster','')} for x in d.get('catalogs',[]) if 'season' in x]

def episodes(tmdb, season):
    d = get(META, '/catalog/video/season_'+quote(str(tmdb),safe='')+'_'+str(int(season))+'.json')
    return [{'episode_number':int(x['episode']), 'name':x.get('name',''), 'overview':x.get('description',''), 'still':x.get('images',{}).get('thumbnail',''), 'air_date':x.get('releaseDate',''), 'runtime':int(x.get('runtime') or 0)//60} for x in d.get('items',[]) if 'episode' in x]

def resolve(item_id, media_type='movie', tmdb_id=None, season=None, episode=None, name='', auto_start=False):
    ident = 'tmdb:'+str(tmdb_id)
    params = {}
    if season is not None and episode is not None:
        ident += ':'+str(season)+':'+str(episode)
    else:
        d = get(META, '/item/video/'+quote(str(tmdb_id),safe='')+'.json')
        imdb = d.get('ids',{}).get('imdb')
        if imdb:
            params['ids'] = ident
            ident = 'imdb:'+imdb
    sources = get(VOD, '/source/video/'+quote(ident,safe=':')+'.json', **params).get('sources',[])
    addon = xbmcaddon.Addon()
    preferred = ('de', 'en', '')[addon.getSettingInt('vod_language')]
    auto = addon.getSettingBool('vod_auto')
    fallback = addon.getSettingBool('vod_fallback')
    https = addon.getSettingBool('vod_https')
    sources = [s for s in sources if isinstance(s, dict) and s.get('url')]
    def languages(s):
        return [str(x).lower().replace('_','-').split('-')[0] for x in (s.get('languages') or [])]
    def rank(s):
        path = urlsplit(s['url']).path.lower()
        direct = path.endswith(('.mp4','.m3u8'))
        return (bool(preferred and preferred not in languages(s)), not direct,
                bool(https and not s['url'].startswith('https://')))
    sources.sort(key=rank)
    if preferred and not fallback:
        sources = [s for s in sources if preferred in languages(s)]
    dialog = xbmcgui.Dialog()
    if not sources:
        dialog.ok('Vavoo TV Plus', 'Keine Quellen in der bevorzugten Sprache verfügbar.')
        return None
    labels = ['%s | %s | %s' % (s.get('name','Server'), ', '.join(s.get('languages') or []).upper(), s.get('quality') or 'Qualität unbekannt') for s in sources]
    if auto_start:
        for source in sources:
            result=try_source(source['url'])
            if result: return result
        return None
    while True:
        i = dialog.select(name or 'Quelle auswählen', ['Automatisch (bevorzugte Sprache)'] + labels) if auto else dialog.select(name or 'Quelle auswählen', labels)
        if i < 0: return None
        if auto and i == 0:
            progress = xbmcgui.DialogProgress()
            progress.create('Vavoo TV Plus', 'Quelle wird geprüft …')
            try:
                for j, source in enumerate(sources):
                    if progress.iscanceled(): return None
                    progress.update(int(100*j/len(sources)), labels[j])
                    result = try_source(source['url'])
                    if progress.iscanceled(): return None
                    if result: return result
            finally:
                progress.close()
            dialog.ok('Vavoo TV Plus', 'Keine abspielbare Quelle gefunden.')
        else:
            result = try_source(sources[i-1 if auto else i]['url'])
            if result: return result
            dialog.ok('Vavoo TV Plus', 'Quelle nicht abspielbar. Bitte einen anderen Server wählen.')


def try_source(source):
    d = get(VOD, '/resolve', url=source)
    result = validate_stream(d)
    if result: return result
    # Optional resolver for supported hosters; no automatic installation.
    if d.get('clientFetch') or not d.get('url'):
        try:
            import resolveurl
            media = resolveurl.HostedMediaFile(url=source)
            if media.valid_url():
                resolved = media.resolve()
                if isinstance(resolved, str) and resolved.startswith(('https://','http://')):
                    url, _, suffix = resolved.partition('|')
                    headers = dict(parse_qsl(suffix))
                    path = urlsplit(url).path.lower()
                    fmt = 'hls' if path.endswith('.m3u8') else 'mp4' if path.endswith('.mp4') else 'auto'
                    result = validate_stream({'url':url,'format':fmt,'headers':headers})
                    if result: return result
            xbmc.log('GEIL VOD ResolveURL: no usable result', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('GEIL VOD ResolveURL: '+type(e).__name__, xbmc.LOGWARNING)
    return None


def validate_stream(d):
    u = d.get('url','')
    fmt = d.get('format')
    if not isinstance(u,str) or not u.startswith(('https://','http://')) or fmt not in ('hls','mp4','auto'):
        return None
    headers = d.get('headers') or {}
    if not isinstance(headers, dict): headers = {}
    headers = {str(k):v for k,v in headers.items() if isinstance(v,str)}
    try:
        with requests.get(u, headers=headers, stream=True, timeout=(3,8)) as r:
            ct = r.headers.get('Content-Type','').split(';')[0].lower()
            first = next(r.iter_content(chunk_size=1024), b'')
            clean = first.lstrip(b'\xef\xbb\xbf \r\n\t')
            kind = 'hls' if clean.startswith(b'#EXTM3U') else 'html' if clean.lower().startswith((b'<!doctype html',b'<html',b'<head')) or ct == 'text/html' else 'mp4' if first[4:8] == b'ftyp' or ct == 'video/mp4' else 'other'
            xbmc.log('GEIL VOD probe: host=%s final_host=%s HTTP %s redirects=%s format=%s content-type=%s body=%s' % (urlsplit(u).hostname, urlsplit(r.url).hostname, r.status_code, len(r.history), fmt, ct, kind), xbmc.LOGINFO)
            r.raise_for_status()
            if kind == 'hls': fmt = 'hls'
            elif kind == 'mp4': fmt = 'mp4'
            else: return None
            # Preserve the effective request headers, excluding credentials.
            effective = {k:v for k,v in r.request.headers.items() if k.lower() in ('user-agent','referer','origin','accept')}
            effective.update(headers)
            return {'url':u + ('|' + urlencode(effective) if effective else ''), 'format':fmt}
    except (requests.RequestException, ValueError) as e:
        xbmc.log('GEIL VOD probe failed: '+type(e).__name__, xbmc.LOGWARNING)
        return None
