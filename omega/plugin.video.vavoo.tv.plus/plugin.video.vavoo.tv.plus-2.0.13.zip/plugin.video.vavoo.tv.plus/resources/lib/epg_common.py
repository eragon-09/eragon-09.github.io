# -*- coding: utf-8 -*-
"""Gemeinsame EPG-Hilfen für Kanalliste, Raster und Banner (Kodi 21)."""
import datetime
import re

WEEKDAYS = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag']
WD_SHORT = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So']
MONTHS = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August',
          'September', 'Oktober', 'November', 'Dezember']


def _norm(value):
    return re.sub(r'[^a-z0-9]', '', (value or '').lower())


def programmes(api, channel):
    """Rohliste der EPG-Einträge eines Senders (Start/Ende als naive UTC, wie im Cache)."""
    cache = api._epg_cache
    lookup = getattr(api, '_epg_lookup', {})
    for key in (channel.get('tvg_id'), channel.get('name')):
        if not key:
            continue
        if key in cache:
            return cache[key]
        found = lookup.get(_norm(key))
        if found in cache:
            return cache[found]
    try:
        mapped = api.get_channel_epg_id(channel.get('name', ''))
        if mapped and mapped in cache:
            return cache[mapped]
    except Exception:
        pass
    return []


_sorted_cache = {}


def sorted_programmes(api, channel):
    """Wie programmes(), aber nach Startzeit sortiert (pro Liste einmal berechnet)."""
    raw = programmes(api, channel)
    if not raw:
        return []
    hit = _sorted_cache.get(id(raw))
    if hit is None or hit[0] != len(raw):
        hit = (len(raw), sorted((p for p in raw if p[0] and p[1]), key=lambda p: p[0]))
        _sorted_cache[id(raw)] = hit
    return hit[1]


def current_index(progs, now_utc):
    """Index der laufenden Sendung (binäre Suche) oder -1."""
    lo, hi = 0, len(progs)
    while lo < hi:
        mid = (lo + hi) // 2
        if progs[mid][0] <= now_utc:
            lo = mid + 1
        else:
            hi = mid
    i = lo - 1
    return i if i >= 0 and progs[i][1] > now_utc else -1


def utc_shift():
    """Differenz UTC minus Ortszeit; lokal = utc - shift."""
    return datetime.datetime.utcnow() - datetime.datetime.now()


def hhmm(dt):
    return dt.strftime('%H:%M')


def span(start, stop):
    return '{} – {}'.format(hhmm(start), hhmm(stop))


def minutes(start, stop):
    return max(1, int((stop - start).total_seconds() // 60))


def date_long(now=None):
    now = now or datetime.datetime.now()
    return '{}, {}. {} {}'.format(WEEKDAYS[now.weekday()], now.day, MONTHS[now.month - 1], now.year)


def _epoch(dt):
    """Naive UTC-Zeit (wie im EPG-Cache) in Unix-Sekunden."""
    import calendar
    return calendar.timegm(dt.timetuple())


def banner_payload(api, channel, num='', logo=''):
    """Daten für das Wiedergabe-Banner.

    Enthält Zeitstempel statt fertiger Texte: Der Service rechnet Fortschritt und
    Restzeit bei jedem Einblenden frisch und springt nach Sendungsende auf "Danach".
    """
    import time
    payload = {'ts': time.time(), 'num': str(num or ''), 'name': channel.get('name', ''),
               'logo': logo or channel.get('logo', ''), 'date': date_long(),
               'title': '', 'start_ts': 0, 'stop_ts': 0,
               'nxt_title': '', 'nxt_start_ts': 0, 'nxt_stop_ts': 0}
    try:
        if not getattr(api, '_epg_cache', None):
            return payload
        progs = sorted_programmes(api, channel)
        now = datetime.datetime.utcnow()
        i = current_index(progs, now)
        if i >= 0:
            start, stop, title, _desc = progs[i]
            payload.update(title=title or '', start_ts=_epoch(start), stop_ts=_epoch(stop))
            if i + 1 < len(progs):
                ns, ne, nt, _nd = progs[i + 1]
                payload.update(nxt_title=nt or '', nxt_start_ts=_epoch(ns), nxt_stop_ts=_epoch(ne))
    except Exception:
        pass
    return payload
