"""Local VOD state and playback monitoring; no TV state is modified."""
import os, json, sqlite3, time
from urllib.parse import urlencode, urlsplit, parse_qsl
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import geil_vod as api

ID='plugin.video.vavoo.tv.plus'
BASE='plugin://'+ID+'/'
ADDON=xbmcaddon.Addon(ID)
WINDOW=xbmcgui.Window(10000)
PENDING=ID+'.vod.pending'

def db():
    path=xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    os.makedirs(path,exist_ok=True)
    c=sqlite3.connect(os.path.join(path,'vod_comfort.sqlite'),timeout=5)
    c.execute('CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, data TEXT, pos REAL DEFAULT 0, total REAL DEFAULT 0, seen INTEGER DEFAULT 0, fav INTEGER DEFAULT 0, updated REAL DEFAULT 0, hidden INTEGER DEFAULT 0)')
    return c

def key(d):
    return str(d['id'])+(':'+str(d['s'])+':'+str(d['e']) if d.get('e') else '')

def rows():
    with db() as c:
        return {k:dict(json.loads(d),pos=p,total=t,seen=s,fav=f,updated=u,hidden=h) for k,d,p,t,s,f,u,h in c.execute('SELECT * FROM state')}

def save(d, **fields):
    k=key(d)
    data={x:d[x] for x in ('id','n','tmdb','s','e','poster','plot','ep_name') if d.get(x) is not None}
    with db() as c:
        c.execute('INSERT OR IGNORE INTO state(key,data) VALUES (?,?)',(k,json.dumps(data,ensure_ascii=False)))
        c.execute('UPDATE state SET data=?, '+','.join(x+'=?' for x in fields)+' WHERE key=?',(json.dumps(data,ensure_ascii=False),*fields.values(),k))

def url(d,action='play_vod',**extra):
    p={x:d[x] for x in ('id','n','tmdb','s','e','poster','plot','ep_name') if d.get(x) is not None}
    return BASE+'?'+urlencode(dict(p,action=action,**extra))

def release_year(value):
    y=str(value or '')[:4]
    return int(y) if len(y)==4 and y.isascii() and y.isdigit() and 1800<=int(y)<=9999 else 0

def remember_years(items):
    values=[(str(x['id']), release_year(x.get('releaseDate') or x.get('year'))) for x in items if x.get('id')]
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS vod_years (id TEXT PRIMARY KEY, year INTEGER)')
        c.executemany('INSERT OR REPLACE INTO vod_years VALUES (?,?)', [(i,y) for i,y in values if y])

def year_for(d, fetch=False):
    y=release_year(d.get('year') or d.get('releaseDate'))
    if y: return y
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS vod_years (id TEXT PRIMARY KEY, year INTEGER)')
        r=c.execute('SELECT year FROM vod_years WHERE id=?',(d['id'],)).fetchone()
    if r: return r[0]
    if not fetch or not d.get('tmdb'): return 0
    kind='video' if d['id'].startswith('movie') else 'series'
    meta=api.get(api.META,'/item/'+kind+'/'+str(d['tmdb'])+'.json')
    y=release_year(meta.get('releaseDate'))
    if y: remember_years([dict(id=d['id'],year=y)])
    return y

def year_label(name, year):
    return '%s - (%d)'%(name,year) if year else name

def title(d):
    return year_label(d.get('n',''),year_for(d))+(' · S%02dE%02d %s'%(int(d['s']),int(d['e']),d.get('ep_name','')) if d.get('e') else '')

def stamp(p):
    p=int(p); return '%d:%02d:%02d'%(p//3600,p//60%60,p%60)

def decorate(li,d, state=None):
    r=(state if state is not None else rows()).get(key(d),{})
    label=li.getLabel()
    if r.get('fav'): label='[COLOR gold]*[/COLOR] '+label
    if r.get('seen'): label=label+' [COLOR lime][Gesehen][/COLOR]'
    li.setLabel(label)
    tag=li.getVideoInfoTag(); tag.setPlaycount(int(r.get('seen',0)))
    if r.get('pos') and r.get('total'):
        # Kein Kodi-Resume-Metadatum setzen: Die eigene VOD-Abfrage und
        # Player.onAVStarted verwalten den Startpunkt bereits.
        # Fortschritt, Gesehen und Serien-Episoden bleiben in der Datenbank.
        if not r.get('seen'):
            pct=max(0,min(100,int(100*r['pos']/r['total'])))
            if pct >= 1: li.setLabel(label+' [COLOR cyan][Fortsetzen: %d %%][/COLOR]'%pct)
    menu=[]
    if not d.get('e'):
        menu.append(('Aus Favoriten entfernen' if r.get('fav') else 'Zu meinen Favoriten hinzufügen','fav'))
    if d.get('e') or d['id'].startswith('movie'):
        menu.append(('Als ungesehen markieren' if r.get('seen') else 'Als gesehen markieren','seen'))
        if r.get('pos'): menu.extend([('Von Anfang an abspielen','restart'),('Aus Weiterschauen entfernen','hide')])
    if d['id'].startswith('movie') and not d.get('e'):
        li.addContextMenuItems([('Filmreihe anzeigen', 'Container.Update('+url(d,'vod_collection')+')')])
    li.addContextMenuItems([(label, 'PlayMedia('+url(d,restart='1')+')' if op=='restart' else 'RunPlugin('+url(d,'comfort_change',op=op)+')') for label,op in menu])

def change(d):
    r=rows().get(key(d),{}); op=d.get('op')
    if op=='fav': save(d,fav=1-int(r.get('fav',0)))
    elif op=='seen': save(d,seen=1-int(r.get('seen',0)),pos=0,updated=time.time(),hidden=0)
    elif op=='hide': save(d,hidden=1,pos=0)
    xbmc.executebuiltin('Container.Refresh')

def next_episode(d, cross=True):
    s,e=int(d['s']),int(d['e']); tm=d['tmdb']
    eps=api.episodes(tm,s)
    if not eps: return None
    candidates=[x for x in eps if x['episode_number']>e]
    if not candidates and cross:
        ss=sorted(x['season_number'] for x in api.seasons(tm) if x['season_number']>s)
        if ss: s=ss[0]; candidates=api.episodes(tm,s)
    if not candidates: return None
    x=min(candidates,key=lambda x:x['episode_number'])
    if x.get('air_date','')>time.strftime('%Y-%m-%d'): return None
    return dict(d,s=s,e=x['episode_number'],ep_name=x.get('name',''),plot=x.get('overview',''),poster=d.get('poster') or x.get('still',''))

def collection(d, meta=None):
    if not d.get('tmdb'): return '', []
    meta=meta if meta is not None else api.get(api.META,'/item/video/'+str(d['tmdb'])+'.json')
    for cat in meta.get('catalogs',[]):
        cid=str(cat.get('id',''))
        if not cid.startswith('collection_'): continue
        items=cat.get('items') or api.get(api.META,'/catalog/video/'+cid+'.json').get('items',[])
        if not any(movie_id(x.get('id'))==str(d['tmdb']) for x in items): continue
        remember_years([dict(x,id='movie.'+movie_id(x['id'])) for x in items if x.get('id')])
        entries=[dict(id='movie.'+movie_id(x['id']),tmdb=movie_id(x['id']),n=x.get('name',''),poster=x.get('images',{}).get('poster',''),fanart=x.get('images',{}).get('backdrop','') or x.get('images',{}).get('fanart',''),plot=x.get('description',''),releaseDate=x.get('releaseDate','')) for x in items if x.get('id') and x.get('name')]
        entries.sort(key=lambda x:(x['releaseDate'] or '9999',x['id']))
        return cat.get('name') or 'Filmreihe',entries
    import tmdb_collections
    name, entries=tmdb_collections.find(d['tmdb'])
    remember_years(entries)
    return name, entries

def collection_next(d, entries):
    # Follow release order even when the viewer is rewatching a series.
    current=movie_id(d.get('tmdb') or d.get('id'))
    today=time.strftime('%Y-%m-%d')
    for i,x in enumerate(entries):
        if movie_id(x.get('tmdb') or x.get('id'))==current:
            for y in entries[i+1:]:
                if y.get('releaseDate') and y['releaseDate']<=today:
                    return y
            break
    return None

def first_unseen(d, entries):
    state=rows(); today=time.strftime('%Y-%m-%d')
    return next((x for x in entries if x['id']!=d['id'] and not state.get(key(x),{}).get('seen') and (not x.get('releaseDate') or x['releaseDate']<=today)),None)

def prepare(d,stream,resume):
    WINDOW.setProperty(PENDING,json.dumps(dict(data=d,stream=stream.split('|')[0],resume=resume,created=time.time())))

class Player(xbmc.Player):
    def __init__(self):
        super().__init__(); self.current=None; self.pos=0; self.total=0; self.finished=None; self.last=0
    def onAVStarted(self):
        try:
            p=json.loads(WINDOW.getProperty(PENDING) or '{}'); f=self.getPlayingFile().split('|')[0]
            if not p or time.time()-p['created']>180: return
            d=p['data']; q=dict(parse_qsl(urlsplit(f).query))
            match=f==p['stream'] or (f.startswith(BASE) and q.get('action')=='play_vod' and q.get('id')==d['id'] and str(q.get('e',''))==str(d.get('e') or '') and str(q.get('s',''))==str(d.get('s') or ''))
            if not match: return
            WINDOW.clearProperty(PENDING); self.finished=None; self.current=d; self.pos=p['resume']; self.total=0; self.last=0
            if self.pos>0: self.seekTime(self.pos)
            xbmc.log('VOD comfort tracking: '+key(d),xbmc.LOGINFO)
        except Exception as exc: xbmc.log('VOD comfort start: '+str(exc),xbmc.LOGWARNING)
    def tick(self):
        if self.current and self.isPlayingVideo():
            try:
                self.pos=self.getTime(); self.total=self.getTotalTime()
                if time.time()-self.last>=5 and self.total>0:
                    self.persist(False); self.last=time.time()
            except RuntimeError: pass
    def persist(self,ended):
        if self.current and self.total>0:
            save(self.current,pos=0 if ended else self.pos,total=self.total,seen=1 if ended else rows().get(key(self.current),{}).get('seen',0),updated=time.time(),hidden=0)
    def finish(self,ended):
        if self.current:
            d=self.current; self.persist(ended); self.current=None
            if ended:
                self.finished=d
                autoplay_log('ended '+key(d))
    def onPlayBackEnded(self): self.finish(True)
    def onPlayBackStopped(self): self.finish(False)
    def onPlayBackError(self): self.finish(False)

def autoplay_log(message, level=xbmc.LOGINFO):
    xbmc.log('VOD autoplay: '+str(message), level)

def start_next(player, d, monitor, automatic=True):
    if monitor.abortRequested() or player.isPlaying():
        autoplay_log('start cancelled: another playback or shutdown')
        return
    if not automatic:
        target=url(d, auto='0')
        autoplay_log('dispatch PlayMedia '+key(d)+' automatic=False')
        xbmc.executebuiltin('PlayMedia('+target+')')
        return
    autoplay_log('automatic resolve '+key(d))
    result=api.resolve(item_id=d['id'], media_type='series' if d.get('e') else 'movie',
                       tmdb_id=d['tmdb'], season=d.get('s'), episode=d.get('e'),
                       name=d['n'], auto_start=True)
    if monitor.abortRequested() or player.isPlaying():
        autoplay_log('automatic start cancelled after resolve')
        return
    if not result or not result.get('url'):
        autoplay_log('automatic resolve failed '+key(d), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Vavoo TV Plus','Keine automatische Quelle gefunden. Bitte Quelle manuell wählen.',xbmcgui.NOTIFICATION_WARNING,5000)
        start_next(player,d,monitor,automatic=False)
        return
    stream=result['url']; fmt=result.get('format')
    li=xbmcgui.ListItem(d['n'],path=stream)
    li.setProperty('IsPlayable','true'); li.setContentLookup(False)
    li.setMimeType('application/vnd.apple.mpegurl' if fmt=='hls' else 'video/mp4')
    tag=li.getVideoInfoTag(); tag.setTitle(d['n']); tag.setPlot(d.get('plot',''))
    tag.setMediaType('episode' if d.get('e') else 'movie')
    if d.get('e'):
        tag.setSeason(int(d['s'])); tag.setEpisode(int(d['e']))
    if d.get('poster'): li.setArt({'poster':d['poster'],'thumb':d['poster'],'fanart':d['poster']})
    prepare(d,stream,0)
    autoplay_log('direct Player.play '+key(d)+' format='+str(fmt))
    player.play(stream,li)
    # AVStarted can take time for remote streams; do not issue a duplicate play.
    for _ in range(90):
        if monitor.waitForAbort(1): return
        if player.current and key(player.current)==key(d):
            autoplay_log('automatic playback confirmed '+key(d)); return
    autoplay_log('automatic playback not confirmed '+key(d),xbmc.LOGWARNING)
    if not player.isPlaying():
        xbmcgui.Dialog().notification('Vavoo TV Plus','Automatischer Start nicht bestätigt. Bitte Film manuell starten.',xbmcgui.NOTIFICATION_WARNING,5000)


def run(monitor):
    player=Player()
    while not monitor.waitForAbort(1):
        try:
            player.tick()
            d=player.finished
            if not d: continue
            if player.isPlaying(): continue
            player.finished=None
            autoplay_log('processing end '+key(d))
            if d.get('e'):
                if not ADDON.getSettingBool('comfort_episode'): continue
                nxt=next_episode(d,ADDON.getSettingBool('comfort_season'))
                if nxt and not player.isPlaying() and not monitor.abortRequested():
                    try:
                        import collection_window
                        entries=[]
                        for ep in api.episodes(nxt['tmdb'],nxt['s']):
                            entries.append(dict(nxt,e=ep['episode_number'],ep_name=ep.get('name',''),plot=ep.get('overview',''),still=ep.get('still',''),releaseDate=ep.get('air_date') or '',details=('%d Min.'%ep['runtime']) if ep.get('runtime') else ''))
                        entries.sort(key=lambda x:int(x['e']))
                        if not any(key(x)==key(nxt) for x in entries): entries.append(nxt)
                        chosen=collection_window.show(d['n']+' · Staffel '+str(nxt['s']),entries,nxt,rows(),max(5,ADDON.getSettingInt('comfort_delay')),player,monitor)
                    except Exception as exc:
                        autoplay_log('series window fallback: '+str(exc),xbmc.LOGWARNING)
                    else:
                        if chosen: start_next(player,chosen,monitor)
                        continue
            else:
                auto=ADDON.getSettingBool('comfort_movie')
                recommend_auto=ADDON.getSettingBool('comfort_recommend_auto')
                show=ADDON.getSettingBool('comfort_collection')
                if not (auto or recommend_auto or show): continue
                meta=api.get(api.META,'/item/video/'+str(d['tmdb'])+'.json')
                cname, entries=collection(d,meta)
                is_collection=bool(entries)
                if not entries:
                    for cat in meta.get('catalogs',[]):
                        cid=str(cat.get('id',''))
                        if not cid.startswith(('recommendations_movie_','similar_movie_')): continue
                        items=cat.get('items') or api.get(api.META,'/catalog/video/'+cid+'.json').get('items',[])
                        for x in items:
                            i=movie_id(x.get('id',''))
                            if not i or i==str(d['tmdb']) or not x.get('name'): continue
                            if x.get('releaseDate') and x['releaseDate']>time.strftime('%Y-%m-%d'): continue
                            entries.append(dict(id='movie.'+i,tmdb=i,n=x['name'],poster=x.get('images',{}).get('poster',''),fanart=x.get('images',{}).get('backdrop','') or x.get('images',{}).get('fanart',''),plot=x.get('description',''),releaseDate=x.get('releaseDate','')))
                        if entries: break
                    cname='Filmempfehlungen'
                    remember_years(entries)
                suggested=collection_next(d,entries) if is_collection else None
                unseen=first_unseen(d,entries)
                nxt=(suggested if auto else None) if is_collection else (unseen if recommend_auto else None)
                if is_collection and not suggested and auto and ADDON.getSettingInt('comfort_collection_end')==0:
                    # Legacy value 0 now means preselect only, never auto-restart.
                    nxt=None
                selected=suggested or (unseen if not is_collection or ADDON.getSettingInt('comfort_collection_end')==0 else None) or (entries[0] if entries else None)
                autoplay_log('premium movie window collection=%s count=%d auto=%s' % (is_collection,len(entries),bool(nxt)))
                if not entries:
                    if show: xbmcgui.Dialog().notification('Vavoo TV Plus','Keine Filmreihe oder Empfehlungen verfügbar.',xbmcgui.NOTIFICATION_INFO,4000)
                    continue
                if (show or nxt) and not player.isPlaying() and not monitor.abortRequested():
                    seconds=max(5,ADDON.getSettingInt('comfort_movie_delay')) if nxt else 0
                    try:
                        import collection_window
                        chosen=collection_window.show(cname,entries,nxt or selected,rows(),seconds,player,monitor,collection=is_collection)
                    except Exception:
                        import traceback
                        autoplay_log('collection window fallback: '+traceback.format_exc(),xbmc.LOGWARNING)
                        if nxt: pass  # Existing countdown fallback below.
                        else:
                            labels=[title(x) for x in entries]
                            i=xbmcgui.Dialog().select(cname,labels,preselect=entries.index(selected))
                            if i>=0 and not player.isPlaying() and not monitor.abortRequested():
                                start_next(player,entries[i],monitor,automatic=False)
                            continue
                    else:
                        if chosen and not player.isPlaying() and not monitor.abortRequested():
                            start_next(player,chosen,monitor,automatic=bool(nxt))
                        continue
                else: continue
            if not nxt or player.isPlaying() or monitor.abortRequested():
                autoplay_log('no next item or playback active')
                continue
            autoplay_log('next '+key(nxt))
            seconds=max(5,ADDON.getSettingInt('comfort_delay' if d.get('e') else 'comfort_movie_delay'))
            # Kodi yes/no autoclose returns false on timeout; use progress dialog with explicit cancellation.
            dialog=xbmcgui.DialogProgress(); dialog.create('Als Nächstes',title(nxt))
            cancelled=False
            try:
                for remaining in range(seconds,0,-1):
                    dialog.update(int(100*(seconds-remaining)/seconds),title(nxt)+'\nStart in %d Sekunden'%remaining)
                    if dialog.iscanceled() or player.isPlaying() or monitor.waitForAbort(1): cancelled=True; break
                if dialog.iscanceled(): cancelled=True
            finally: dialog.close()
            if cancelled:
                autoplay_log('countdown cancelled '+key(nxt))
            elif not player.isPlaying() and not monitor.abortRequested():
                autoplay_log('countdown completed '+key(nxt))
                start_next(player,nxt,monitor)
        except Exception as exc:
            import traceback
            xbmc.log('VOD comfort: '+traceback.format_exc(),xbmc.LOGWARNING)


def movie_id(value):
    value = str(value)
    return value[6:] if value.startswith("movie.") else value
