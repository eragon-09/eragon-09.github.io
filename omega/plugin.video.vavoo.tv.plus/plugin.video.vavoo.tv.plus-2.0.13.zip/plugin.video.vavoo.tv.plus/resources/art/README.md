# Artwork

Dieser Ordner enthält austauschbare Inhaltsgrafiken des Addons.

## favo_icons

`favo_icons/` enthält die mitgelieferten Standardbilder für Favoritengruppen.
Eigene Gruppenbilder werden weiterhin im Addon-Profil unter
`addon_data/plugin.video.vavoo.tv.plus/favo_icons/` gespeichert und haben Vorrang.

Die festen Grafiken der Benutzeroberfläche bleiben unter `resources/media/`.
