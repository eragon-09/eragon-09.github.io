# -*- coding: utf-8 -*-
"""Aktualisiert die ausdrücklich ausgewählten Länder beim Kodi-Start."""
import os
import json
import hashlib
import xbmcgui
import sys
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon(id="plugin.video.vavoo.tv.plus")
PREFIX = "[Vavoo TV Plus Startup] "
MAX_ATTEMPTS = 3
RETRY_SECONDS = (15, 30)


def log(message, level=xbmc.LOGINFO):
    xbmc.log(PREFIX + str(message), level)


def list_fingerprint(channels):
    """Stable digest of channel names and their source URLs, independent of dict ordering."""
    canonical = []
    for name, urls in channels.items():
        canonical.append((str(name), sorted(str(url) for url in urls)))
    payload = json.dumps(sorted(canonical), ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def read_snapshots(path):
    try:
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def save_snapshots(path, data):
    temp = path + ".tmp"
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, sort_keys=True)
    os.replace(temp, path)


def refresh(monitor):
    selected = ADDON.getSetting("selected_countries").strip()
    if not selected:
        log("Keine Länder explizit ausgewählt; Aktualisierung übersprungen.")
        return
    lib = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))
    if lib not in sys.path:
        sys.path.insert(0, lib)
    import vavoo_api as api

    codes = api.parse_country_codes(selected)
    if not codes:
        log("Keine gültige Länderauswahl gefunden.", xbmc.LOGWARNING)
        return
    # Die verfügbare Länderliste kann bei Netzwerkausfall auf Fallback-Daten zurückgreifen.
    try:
        countries = api.get_available_countries()
    except Exception as exc:
        log("Länderkatalog nicht erreichbar: %s" % exc, xbmc.LOGWARNING)
        countries = []
    known = {api.country_to_code(country).upper(): country for country in countries}
    names = []
    for code in codes:
        name = known.get(str(code).upper(), code)
        if name not in names:
            names.append(name)

    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    os.makedirs(profile, exist_ok=True)
    snapshot_path = os.path.join(profile, "startup_country_snapshots.json")
    snapshots = read_snapshots(snapshot_path)
    changed_countries = []
    fresh_catalog = {}
    failed_countries = []
    for country in names:
        if monitor.abortRequested():
            return
        for attempt in range(1, MAX_ATTEMPTS + 1):
            if monitor.abortRequested():
                return
            try:
                # strict_refresh verhindert, dass alte Cache-Daten als neuer Download gelten.
                channels = api.fetch_channels_for_group(country, force=True, strict_refresh=True)
                log("%s: %d Sender frisch geladen (Versuch %d)." % (country, len(channels), attempt))
                fresh_catalog.update(channels)
                fingerprint = list_fingerprint(channels)
                previous = snapshots.get(str(country))
                if previous is not None and previous != fingerprint:
                    changed_countries.append(str(country))
                    log("%s: Senderliste hat sich geändert." % country)
                elif previous is None:
                    log("%s: Erste Vergleichsbasis gespeichert; kein Änderungsalarm." % country)
                snapshots[str(country)] = fingerprint
                try:
                    save_snapshots(snapshot_path, snapshots)
                except OSError as exc:
                    log("Vergleichsbasis konnte nicht gespeichert werden: %s" % exc, xbmc.LOGWARNING)
                break
            except Exception as exc:
                log("%s: Versuch %d/%d fehlgeschlagen: %s; vorhandener Cache bleibt erhalten." %
                    (country, attempt, MAX_ATTEMPTS, exc), xbmc.LOGWARNING)
                if attempt == MAX_ATTEMPTS:
                    log("%s: Kein frisches Update; bisherige Liste bleibt erhalten." % country, xbmc.LOGWARNING)
                    failed_countries.append(country)
                elif monitor.waitForAbort(RETRY_SECONDS[attempt - 1]):
                    return
    if failed_countries or not fresh_catalog or monitor.abortRequested():
        log("Favoriten-Abgleich übersprungen: Katalog nicht vollständig frisch.")
        return
    try:
        import group_favs as gf
        from favorites.sync_engine import sync_name_key
        groups = gf.load_groups()
        # Alias-Erkennung aus der vorhandenen Sync-Engine verwenden.
        # Jede Katalogvariante bleibt separat: HD, HD+, RAW, BACKUP usw.
        indexed = {}
        for name, urls in fresh_catalog.items():
            key = sync_name_key(name)
            if not key:
                continue
            if isinstance(urls, (str, dict)):
                urls = [urls]
            for item in urls or []:
                url = item.get("url", "") if isinstance(item, dict) else item
                if url:
                    indexed.setdefault(key, []).append((name, str(url).strip()))

        import re
        def variant(name):
            text = (name or "").lower()
            if re.search(r"\b(?:uhd|4k)\b", text):
                return "uhd"
            if re.search(r"\b(?:fhd|full\s*hd)\b", text):
                return "fhd"
            if re.search(r"\bhd\+?\b|\bhd\+", text):
                return "hd"
            return "sd"

        def candidate_rank(name, wanted):
            """Qualitaet beibehalten; Backup nur als schlechtere Alternative."""
            text = (name or "").lower()
            score = 100 if variant(name) == variant(wanted) else 0
            if variant(wanted) == "hd" and variant(name) == "fhd":
                score += 10
            if "backup" in text or "test" in text or "match time" in text:
                score -= 50
            if "raw" in text or "hevc" in text:
                score -= 10
            # Exakter Anzeigename hat Vorrang vor einem Alias.
            if name.casefold().strip() == wanted.casefold().strip():
                score += 20
            return score

        def unique_replacement(wanted, old_url):
            key = sync_name_key(wanted)
            matches = indexed.get(key, [])
            # Bereits vorhandene URLs bleiben auch bei anderen Schreibweisen.
            if any(url == old_url for _, url in matches):
                return None, False
            ranks = {}
            for name, url in matches:
                if url and url != old_url:
                    ranks[url] = max(ranks.get(url, -10000), candidate_rank(name, wanted))
            if not ranks:
                return None, True
            best = max(ranks.values())
            winners = [url for url, rank in ranks.items() if rank == best]
            # Bei gleichwertigen Quellen niemals zufaellig ersetzen.
            return (winners[0], False) if len(winners) == 1 else (None, True)
        updated = 0
        unresolved = 0
        for group in groups:
            if monitor.abortRequested():
                return
            filename = group.get("file", "")
            if not filename or filename.lower() == "alle_favoriten.m3u":
                continue
            channels = gf.load_group_channels(filename)
            eligible = {}
            for channel in channels:
                old = (channel.get("url") or "").strip()
                if not old:
                    continue
                candidate, uncertain = unique_replacement(channel.get("name", ""), old)
                if candidate:
                    # Originalname verwenden; die vorhandene Sync-Engine
                    # prueft den Stream vor dem Schreiben und legt Backups an.
                    eligible[channel["name"]] = [candidate]
                elif uncertain:
                    unresolved += 1
            if not eligible:
                continue
            # Vor jedem Schreiben sichert die vorhandene Sync-Engine die M3U.
            result = gf.sync_group_channels(
                filename, eligible, api_module=api,
                max_candidates=1, validation_timeout=5,
                validate_streams=True)
            updated += result.get("updated", 0)
            unresolved += result.get("unreachable", 0)
            if result.get("error"):
                log("Abgleich %s: %s" % (filename, result["error"]), xbmc.LOGWARNING)
        if updated:
            gf.rebuild_all_favorites_m3u(groups)
            log("Favoriten automatisch aktualisiert: %d Sender." % updated)
        if unresolved:
            xbmcgui.Dialog().notification(
                "Vavoo TV Plus", "%d Sender bitte manuell prüfen" % unresolved,
                xbmcgui.NOTIFICATION_INFO, 7000, False)
    except Exception as exc:
        log("Automatischer Favoriten-Abgleich fehlgeschlagen: %s" % exc, xbmc.LOGERROR)



def monitor_epg_playback_failures():
    """Wiedergabestatus verfolgen und nach einem Fehler zurück ins MultiEPG springen.

    Fehler-Rücksprung: Nach einem Wiedergabefehler wird der Kodi-Fehlerdialog
    ("Wiedergabe nicht möglich") nach FAIL_AUTO_SECONDS automatisch geschlossen
    oder sofort, sobald der Nutzer OK drückt. Danach öffnet das MultiEPG wieder
    auf dem zuletzt gewählten Sender.
    """
    import time
    from urllib.parse import quote
    FAIL_AUTO_SECONDS = 4.0     # automatischer Rücksprung (3-5 s)
    NO_DIALOG_SECONDS = 1.5     # Fehler ohne Dialog: fast sofort zurück
    STUCK_SECONDS = 35          # Stream startet gar nicht
    home = xbmcgui.Window(10000)
    monitor = xbmc.Monitor()

    def is_vavoo_file(actual):
        session_url = home.getProperty("VavooTVPlus.PlayingURL")
        if not (session_url and actual):
            return False
        return (actual.split("|", 1)[0] == session_url.split("|", 1)[0]
                or (session_url.startswith("plugin://plugin.video.vavoo.tv.plus/")
                    and actual.startswith("plugin://plugin.video.vavoo.tv.plus/")))

    class Playback(xbmc.Player):
        def __init__(self):
            super().__init__()
            self.av_time = 0.0
            self.err_time = 0.0

        def onPlayBackError(self):
            self.err_time = time.time()
            home.clearProperty("VavooTVPlus.Playing")

        def onAVStarted(self):
            self.av_time = time.time()
            try:
                ok = is_vavoo_file(self.getPlayingFile())
            except Exception:
                ok = False
            if ok:
                home.setProperty("VavooTVPlus.Playing", "1")
            else:
                home.clearProperty("VavooTVPlus.Playing")

        def onPlayBackStopped(self):
            home.clearProperty("VavooTVPlus.Playing")

        def onPlayBackEnded(self):
            home.clearProperty("VavooTVPlus.Playing")

    player = Playback()
    last_key = ""
    fail_since = 0.0
    dialog_seen = False

    def clear_pending():
        home.clearProperty("VavooTVPlus.PendingEPGURL")
        home.clearProperty("VavooTVPlus.PendingEPGTime")

    while not monitor.abortRequested():
        url = home.getProperty("VavooTVPlus.PendingEPGURL")
        raw_time = home.getProperty("VavooTVPlus.PendingEPGTime")
        try:
            started = float(raw_time)
        except (ValueError, TypeError):
            started = 0
        if not url or not started:
            fail_since = 0.0
            dialog_seen = False
            monitor.waitForAbort(0.5)
            continue
        key = raw_time + url
        if key != last_key:
            last_key = key
            fail_since = 0.0
            dialog_seen = False

        # Erfolg zählt erst, wenn der NEUE Stream gestartet ist (der alte kann
        # beim Senderwechsel noch laufen).
        if player.av_time >= started:
            clear_pending()
            monitor.waitForAbort(0.5)
            continue

        failed = player.err_time >= started
        elapsed = time.time() - started
        if failed or elapsed > STUCK_SECONDS:
            now = time.time()
            if not fail_since:
                fail_since = now
            dialog_open = xbmc.getCondVisibility("Window.IsActive(okdialog)")
            if dialog_open:
                dialog_seen = True
            waited = now - fail_since
            go = ((dialog_seen and not dialog_open)              # OK gedrückt
                  or waited >= FAIL_AUTO_SECONDS                 # 3-5 s Auto-Rücksprung
                  or (not dialog_seen and waited >= NO_DIALOG_SECONDS))
            if go:
                clear_pending()
                fail_since = 0.0
                dialog_seen = False
                if not failed and player.isPlaying():
                    player.stop()
                if dialog_open:
                    xbmc.executebuiltin("Dialog.Close(okdialog,true)")
                    monitor.waitForAbort(0.3)
                log("Wiedergabefehler: Rückkehr zum ausgewählten MultiEPG-Sender.")
                xbmc.executebuiltin(
                    "RunPlugin(plugin://plugin.video.vavoo.tv.plus/"
                    "?action=favorites_epg&url=%s)" % quote(url, safe="")
                )
        monitor.waitForAbort(0.25)


def install_epg_keymap():
    """Keymap mit dem tatsächlichen Addon-Pfad im Profil ablegen und neu laden."""
    try:
        from xml.sax.saxutils import quoteattr
        script = xbmcvfs.translatePath(
            os.path.join(ADDON.getAddonInfo("path"), "epg_hotkey.py")).replace("\\", "/")
        cmd = 'RunScript("%s")' % script
        content = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<keymap>\n  <FullscreenVideo>\n    <keyboard>\n'
            '      <backspace>%(c)s</backspace>\n'
            '      <escape>%(c)s</escape>\n'
            '    </keyboard>\n    <remote>\n'
            '      <back>%(c)s</back>\n'
            '    </remote>\n  </FullscreenVideo>\n</keymap>\n'
        ) % {"c": quoteattr(cmd)[1:-1]}
        content = content.encode("utf-8")
        destdir = xbmcvfs.translatePath("special://profile/keymaps")
        os.makedirs(destdir, exist_ok=True)
        dest = os.path.join(destdir, "vavoo_multiepg.xml")
        previous = None
        if os.path.isfile(dest):
            with open(dest, "rb") as stream:
                previous = stream.read()
        if previous != content:
            with open(dest, "wb") as stream:
                stream.write(content)
            xbmc.executebuiltin("Action(reloadkeymaps)")
            log("FullscreenVideo-Zurück-Taste für MultiEPG eingerichtet.")
    except Exception as exc:
        log("EPG-Tastenbelegung konnte nicht eingerichtet werden: %s" % exc, xbmc.LOGWARNING)


def main():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(10):
        return
    try:
        if ADDON.getSetting("refresh_selected_on_startup").lower() not in ("true", "1", "yes"):
            log("Automatische Aktualisierung deaktiviert.")
            return
        refresh(monitor)
    except Exception as exc:
        log("Startaktualisierung fehlgeschlagen: %s" % exc, xbmc.LOGERROR)


if __name__ == "__main__":
    import threading
    install_epg_keymap()
    lib = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))
    sys.path.insert(0, lib)
    import vod_comfort
    threading.Thread(target=main, daemon=True).start()
    threading.Thread(target=monitor_epg_playback_failures, daemon=True).start()
    vod_comfort.run(xbmc.Monitor())
