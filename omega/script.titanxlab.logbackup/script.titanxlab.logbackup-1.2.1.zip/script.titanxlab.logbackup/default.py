import datetime
import ipaddress
import json
import os
import re
import zipfile
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name') or 'TitanX Lab - Log Backup'
ADDON_VERSION = ADDON.getAddonInfo('version') or '1.2.1'
PASTE_RS_URL = 'https://paste.rs'
MAX_SAVED_LINKS = 20


def L(string_id, *args):
    text = ADDON.getLocalizedString(string_id)
    return text.format(*args) if args else text


def read_text(path):
    handle = xbmcvfs.File(path, 'rb')
    try:
        data = handle.read()
    finally:
        handle.close()
    return data.decode('utf-8', errors='replace') if isinstance(data, bytes) else data


def write_text(path, text):
    handle = xbmcvfs.File(path, 'w')
    try:
        handle.write(text)
    finally:
        handle.close()


def history_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'uploads.json')


def load_saved_links():
    path = history_path()
    if not xbmcvfs.exists(path):
        return []
    try:
        data = json.loads(read_text(path))
        if not isinstance(data, list):
            return []
        entries = []
        for entry in data:
            if not isinstance(entry, dict) or not entry.get('url'):
                continue
            # Migration from older versions.
            if 'privacy_mode' not in entry:
                entry['privacy_mode'] = entry.get('kind') == 'sanitized'
            entry.pop('kind', None)
            entries.append(entry)
        return entries
    except Exception:
        return []


def save_share_link(url, privacy_mode):
    entries = load_saved_links()
    entries.insert(0, {
        'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'privacy_mode': bool(privacy_mode),
        'url': url,
    })
    write_text(history_path(), json.dumps(entries[:MAX_SAVED_LINKS], ensure_ascii=False, indent=2))


def clear_saved_links():
    path = history_path()
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)


def format_saved_date(value):
    try:
        parsed = datetime.datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
        return parsed.strftime('%d.%m.%Y %H:%M')
    except Exception:
        return value or '-'


def privacy_label(entry):
    return L(32041) if entry.get('privacy_mode', False) else L(32042)


def show_saved_links(dialog):
    entries = load_saved_links()
    if not entries:
        dialog.ok(ADDON_NAME, L(32040))
        return

    options = []
    for index, entry in enumerate(entries):
        prefix = L(32047) if index == 0 else L(32048)
        options.append('{} - {} - {} - {}'.format(
            prefix,
            format_saved_date(entry.get('created', '')),
            privacy_label(entry),
            entry.get('url', ''),
        ))
    options.extend([L(32043), L(32003)])

    choice = dialog.select(L(32039), options)
    if choice < 0 or choice == len(options) - 1:
        return
    if choice == len(entries):
        if dialog.yesno(ADDON_NAME, L(32044), nolabel=L(32004), yeslabel=L(32045)):
            clear_saved_links()
            dialog.ok(ADDON_NAME, L(32046))
        return

    entry = entries[choice]
    body = L(
        32049,
        L(32047) if choice == 0 else L(32048),
        format_saved_date(entry.get('created', '')),
        privacy_label(entry),
        entry.get('url', ''),
    )
    dialog.textviewer(L(32039), body, usemono=False)


def redact_url_credentials(match):
    return re.sub(
        r'(?i)(://)([^/@\s:]+):([^/@\s]+)@',
        r'\1[USER]:[PASSWORD]@',
        match.group(0),
    )


def redact_ip(match):
    value = match.group(0).strip('[]')
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        return match.group(0)
    return match.group(0) if address.is_loopback else '[IP]'


def sanitize_log(text):
    text = re.sub(r'(?i)\b(?:https?|ftp|ftps|smb|nfs)://[^\s<>"\']+', redact_url_credentials, text)
    text = re.sub(
        r'(?i)\b(password|passwd|pwd|token|access[_-]?token|refresh[_-]?token|api[_-]?key|apikey|secret|authorization|cookie|session(?:id)?)\b'
        r'(\s*[:=]\s*)([^\s,;\]\}\)]+)',
        lambda m: '{}{}[REDACTED]'.format(m.group(1), m.group(2)),
        text,
    )
    text = re.sub(r'(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+', r'\1 [REDACTED]', text)
    text = re.sub(r'(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b', '[EMAIL]', text)
    text = re.sub(r'(?i)\b(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}\b', '[MAC]', text)
    text = re.sub(r'(?<![\w:])(?:\d{1,3}\.){3}\d{1,3}(?![\w:])', redact_ip, text)
    text = re.sub(r'(?<![\w:])(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}(?![\w:])', redact_ip, text)
    text = re.sub(r'(?i)([A-Z]:\\Users\\)[^\\\r\n]+', r'\1[USER]', text)
    text = re.sub(r'(?i)(/home/)[^/\s]+', r'\1[USER]', text)
    text = re.sub(r'(?i)(/Users/)[^/\s]+', r'\1[USER]', text)
    text = re.sub(r'(?im)(Local hostname:\s*).*$', r'\1[HOSTNAME]', text)
    return text


def network_error(error):
    if isinstance(error, HTTPError):
        try:
            body = error.read().decode('utf-8', errors='replace').strip()
        except Exception:
            body = ''
        return 'HTTP {}: {}'.format(error.code, body or error.reason)
    if isinstance(error, URLError):
        return str(error.reason)
    return str(error)


def upload_to_paste_rs(text):
    request = Request(
        PASTE_RS_URL,
        data=text.encode('utf-8'),
        headers={
            'Content-Type': 'text/plain; charset=utf-8',
            'User-Agent': 'TitanX-Lab-Kodi-Log-Backup/{}'.format(ADDON_VERSION),
        },
        method='POST',
    )
    with urlopen(request, timeout=45) as response:
        result = response.read().decode('utf-8', errors='replace').strip()
    if not result.startswith('http'):
        raise RuntimeError(result or L(32020))
    return result


def create_local_zip(dialog, log_path, timestamp):
    folder = dialog.browse(3, L(32010), 'files')
    if not folder:
        return
    folder = xbmcvfs.translatePath(folder)
    zip_path = os.path.join(folder, 'kodi_log_{}.zip'.format(timestamp))
    temp_log = xbmcvfs.translatePath('special://temp/titanxlab_kodi_log.tmp')
    try:
        if not xbmcvfs.copy(log_path, temp_log):
            raise RuntimeError(L(32021))
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.write(temp_log, arcname='kodi.log')
        dialog.ok(ADDON_NAME, L(32011, zip_path))
    finally:
        if xbmcvfs.exists(temp_log):
            xbmcvfs.delete(temp_log)


def upload_log(dialog, log_text, privacy_mode):
    upload_text = sanitize_log(log_text) if privacy_mode else log_text
    message = L(32012) if privacy_mode else L(32013)
    if not dialog.yesno(ADDON_NAME, message, nolabel=L(32004), yeslabel=L(32005)):
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, L(32014))
    try:
        url = upload_to_paste_rs(upload_text)
        save_share_link(url, privacy_mode)
        progress.close()
        dialog.textviewer(L(32015), L(32016, url), usemono=False)
    except Exception as error:
        progress.close()
        dialog.ok(ADDON_NAME, L(32017, network_error(error)))



def show_upload_menu():
    dialog = xbmcgui.Dialog()
    options = [L(32012), L(32013), L(32003)]
    choice = dialog.select(L(32011), options)

    if choice == 0:
        show_paste_rs_menu()
    elif choice == 1:
        show_saved_links()


def show_paste_rs_menu():
    dialog = xbmcgui.Dialog()
    options = [L(32001), L(32002), L(32003)]
    choice = dialog.select(L(32012), options)

    if choice == 0:
        upload_log(True)
    elif choice == 1:
        upload_log(False)


def main():
    dialog = xbmcgui.Dialog()
    log_path = xbmcvfs.translatePath('special://logpath/kodi.log')
    if not xbmcvfs.exists(log_path):
        dialog.ok(ADDON_NAME, L(32018))
        return
    options = [L(32000), L(32010), L(32011), L(32003)]
    choice = dialog.select(ADDON_NAME, options)

    if choice == 0:
        create_local_backup()
    elif choice == 1:
        show_upload_menu()
    elif choice == 2:
        show_saved_links()


if __name__ == '__main__':
    main()
