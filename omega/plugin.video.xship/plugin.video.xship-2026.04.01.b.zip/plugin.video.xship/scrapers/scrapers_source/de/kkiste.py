# kkiste
# 2023-01-28
# edit 2026-03-29 (portiert von xStream kkiste.py)

from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from resources.lib.control import getSetting, quote_plus

SITE_IDENTIFIER = 'kkiste'
SITE_DOMAIN = 'kkiste-io.skin'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/index.php?do=search&subaction=search&story=%s'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            t = set([cleantitle.get(i) for i in set(titles) if i])
            years = (year, year+1, year-1, 0)
            links = []

            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.search_link % quote_plus(sSearchText))
                    oRequest.cacheTime = 60 * 60 * 6
                    sHtmlContent = oRequest.request()
                    if not sHtmlContent: continue
                    # Pattern aus xStream-Version (funktioniert)
                    pattern = r'class="short">.*?href="([^"]+)">([^<]+).*?Jahr:.*?([\d]+)<'
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    if not isMatch: continue

                    for sUrl, sName, sYear in aResult:
                        if season == 0:
                            if cleantitle.get(sName) in t and int(sYear) in years:
                                if sUrl not in links: links.append(sUrl)
                        else:
                            parts = sName.split('-')
                            if len(parts) > 1:
                                if cleantitle.get(parts[0].strip()) in t and str(season) in parts[1]:
                                    if sUrl not in links: links.append(sUrl)
                    if links: break
                except Exception:
                    continue

            if not links: return self.sources

            for link in set(links):
                try:
                    sHtmlContent = cRequestHandler(link).request()
                    if not sHtmlContent: continue

                    if season > 0:
                        # Episode-Container aus xStream: >{episode}< ... </ul></li>
                        pattern = r'>{0}<.*?</ul></li>'.format(episode)
                        isMatch, sHtmlContent = cParser.parseSingleResult(sHtmlContent, pattern)
                        if not isMatch: continue

                    isMatch, aResult = cParser.parse(sHtmlContent, r'link="([^"]+)"')
                    if not isMatch: continue

                    for sUrl in aResult:
                        if 'youtube' in sUrl: continue
                        if sUrl.startswith('//'): sUrl = 'https:' + sUrl
                        elif sUrl.startswith('/'): sUrl = self.base_link + sUrl
                        isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
                        if isBlocked: continue
                        if url: self.sources.append({'source': hoster, 'quality': 'HD', 'language': 'de',
                                                      'url': url, 'direct': True, 'prioHoster': prioHoster})
                except Exception:
                    continue

        except Exception:
            pass
        return self.sources

    def resolve(self, url):
        return url
