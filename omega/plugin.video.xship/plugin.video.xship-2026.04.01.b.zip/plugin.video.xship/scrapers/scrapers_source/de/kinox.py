# kinox
# edit 2026-03-29 (portiert von xStream kinox.py)

import json, re, time
from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser, source_utils
from resources.lib.control import getSetting, quote_plus, urljoin, parse_qs

SITE_IDENTIFIER = 'kinox'
SITE_DOMAIN = 'kinoz.to'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link    = self.base_link + '/Search.html?q=%s'
        self.mirror_link    = self.base_link + '/aGET/Mirror/%s&Hoster=%s&Mirror=%s'
        self.episode_link   = self.base_link + '/aGET/MirrorByEpisode/?Addr=%s&SeriesID=%s&Season=%s&Episode=%s'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            url = ''

            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.search_link % quote_plus(sSearchText))
                    oRequest.cacheTime = 60 * 60 * 6
                    # Sprachcookie setzen - wichtig für deutsche Ergebnisse
                    oRequest.addHeaderEntry('Cookie', 'ListDisplayLang=2; ListDisplayYears=Always;')
                    sHtmlContent = oRequest.request()
                    if not sHtmlContent: continue

                    # Suchtreffer parsen (aus xStream __displayItems)
                    r = dom_parser.parse_dom(sHtmlContent, 'table', attrs={'id': 'RsltTableStatic'})
                    if not r: continue
                    r = dom_parser.parse_dom(r, 'tr')
                    rows = [(dom_parser.parse_dom(i, 'a', req='href'),
                             dom_parser.parse_dom(i, 'span')) for i in r]
                    rows = [(i[0][0].attrs['href'], i[0][0].content, i[1][0].content)
                            for i in rows if i[0] and i[1]]

                    for sUrl, sName, sYearStr in rows:
                        if season == 0:
                            if int(sYearStr) not in (year, year+1, year-1): continue
                            if cleantitle.get(sName) not in t: continue
                        else:
                            if cleantitle.get(sName) not in t: continue
                        url = urljoin(self.base_link, sUrl)
                        break

                    if url: break
                except Exception:
                    continue

            if not url: return self.sources

            oRequest = cRequestHandler(url)
            oRequest.addHeaderEntry('Cookie', 'ListDisplayLang=2; ListDisplayYears=Always;')
            sHtmlContent = oRequest.request()
            if not sHtmlContent: return self.sources

            if season and episode:
                # Serien: MirrorByEpisode API (aus xStream showHosters)
                r = dom_parser.parse_dom(sHtmlContent, 'select', attrs={'id': 'SeasonSelection'}, req='rel')
                if not r: return self.sources
                r = source_utils.replaceHTMLCodes(r[0].attrs['rel'])[1:]
                r = parse_qs(r)
                r = {i: r[i][0] if r[i] else '' for i in r}
                ep_url = urljoin(self.base_link,
                                 '/aGET/MirrorByEpisode/?Addr=%s&SeriesID=%s&Season=%s&Episode=%s'
                                 % (r.get('Addr',''), r.get('SeriesID',''), season, episode))
                oReq2 = cRequestHandler(ep_url)
                oReq2.addHeaderEntry('Cookie', 'ListDisplayLang=2;')
                sHtmlContent = oReq2.request()

            # Hoster-Liste parsen (aus xStream showHosters)
            r = dom_parser.parse_dom(sHtmlContent, 'ul', attrs={'id': 'HosterList'})
            if not r: return self.sources
            r = dom_parser.parse_dom(r, 'li', attrs={'id': re.compile(r'Hoster_\d+')}, req='rel')
            r = [(source_utils.replaceHTMLCodes(i.attrs['rel']), i.content) for i in r if i]
            r = [(i[0], re.findall(r'class="Named"[^>]*>([^<]+).*?(\d+)/(\d+)', i[1])) for i in r]
            r = [(i[0], i[1][0][0].lower().rsplit('.', 1)[0], i[1][0][2]) for i in r if i[1]]

            for link, hoster, mirrors in r:
                try:
                    if isBlockedHoster(hoster)[0]: continue
                    u = parse_qs('&id=%s' % link)
                    u = {x: u[x][0] if u[x] else '' for x in u}
                    for x in range(1, min(int(mirrors), 2) + 1):  # max 2 Mirrors
                        mirror_url = self.mirror_link % (u.get('id',''), u.get('Hoster',''), x)
                        if season and episode:
                            mirror_url += '&Season=%s&Episode=%s' % (season, episode)
                        oReq = cRequestHandler(mirror_url)
                        oReq.addHeaderEntry('Referer', self.base_link)
                        raw = oReq.request()
                        if not raw or len(raw) < 20:
                            pass  # sleep entfernt
                            raw = cRequestHandler(mirror_url).request()
                        if not raw: continue

                        # Stream-URL aus JSON extrahieren (aus xStream getHosterUrl)
                        try:
                            data = json.loads(raw)
                            stream_html = data.get('Stream', '')
                        except Exception:
                            stream_html = raw

                        r2 = dom_parser.parse_dom(stream_html, 'a', req='href')
                        r3 = dom_parser.parse_dom(stream_html, 'iframe', req='src')
                        sStreamUrl = r2[0].attrs['href'] if r2 else (r3[0].attrs['src'] if r3 else None)
                        if not sStreamUrl: continue
                        if not sStreamUrl.startswith('http'):
                            sStreamUrl = urljoin('https:', sStreamUrl)
                        if 'streamcrypt.net' in sStreamUrl:
                            oReq2 = cRequestHandler(sStreamUrl, caching=False)
                            oReq2.request()
                            sStreamUrl = oReq2.getRealUrl()
                        isBlocked, hosterName, resolved, prioHoster = isBlockedHoster(sStreamUrl)
                        if isBlocked: continue
                        if resolved:
                            self.sources.append({'source': hosterName, 'quality': 'SD', 'language': 'de',
                                                  'url': resolved, 'direct': True, 'prioHoster': prioHoster,
                                                  'info': 'Mirror %s' % x})
                except Exception:
                    continue

        except Exception:
            pass
        return self.sources

    def resolve(self, url):
        return url
