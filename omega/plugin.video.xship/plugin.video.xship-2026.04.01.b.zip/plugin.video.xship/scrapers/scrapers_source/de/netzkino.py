# netzkino
# edit 2024-11-14
# edit 2026-03-29

from resources.lib.utils import isBlockedHoster
import json
from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting
from resources.lib.utils import getExtIDS

SITE_IDENTIFIER = 'netzkino'
SITE_DOMAIN = 'www.netzkino.de'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_api = 'https://api.netzkino.de.simplecache.net/capi-2.0a/movies/%s.json?d=www'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        if season > 0: return self.sources
        try:
            aIDS = getExtIDS(imdb, 'movies')
            if not aIDS or 'slug' not in aIDS: return self.sources
            slug = aIDS['slug'].rsplit('-', 1)[0]
            oRequest = cRequestHandler(self.search_api % slug)
            oRequest.cacheTime = 60 * 60 * 24
            item = json.loads(oRequest.request())
            if 'No such slug found' in str(item): return self.sources
            fields = item.get('custom_fields', {})
            if not fields: return self.sources
            if int(fields.get('Jahr', [0])[0]) != year: return self.sources
            streaming = fields.get('Streaming', [''])[0]
            if streaming:
                stream = 'https://pmd.netzkino-seite.netzkino.de/%s.mp4' % streaming
                quality = fields.get('Adaptives_Streaming', ['720p'])[0] or '720p'
                self.sources.append({'source': 'Netzkino', 'quality': quality, 'language': 'de', 'url': stream, 'direct': True, 'prioHoster': 1})
        except Exception:
            pass
        return self.sources

    def resolve(self, url):
        return url
