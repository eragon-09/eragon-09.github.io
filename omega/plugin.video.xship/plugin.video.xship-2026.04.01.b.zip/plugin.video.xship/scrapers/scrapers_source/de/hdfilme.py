# hdfilme (hdfilme-to.my - DLE CMS)
# edit 2026-03-29 (portiert von xStream hdfilme.py)

from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from resources.lib.control import getSetting, quote_plus

SITE_IDENTIFIER = 'hdfilme'
SITE_DOMAIN = 'hdfilme-to.my'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/index.php?do=search&subaction=search&story=%s'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            t = set([cleantitle.get(i) for i in set(titles) if i])
            years = (year, year+1, year-1, 0)
            links = []

            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.search_link % quote_plus(sSearchText))
                    oRequest.cacheTime = 60 * 60 * 6
                    sHtmlContent = oRequest.request()
                    if not sHtmlContent: continue

                    # Pattern aus xStream hdfilme.py showEntries
                    pattern = r'<div class="box-product(.*?)<h3.*?href="([^"]+).*?">([^<]+).*?(.*?)</li>'
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    if not isMatch: continue

                    for sDummy, sUrl, sName, sYearBlock in aResult:
                        isYear, sYear = cParser.parseSingleResult(sYearBlock, r'([\d]+)\s</p>')
                        if season == 0:
                            if not isYear or int(sYear) not in years: continue
                            if cleantitle.get(sName) in t:
                                links.append(sUrl)
                        else:
                            if 'taffel' not in sName.lower(): continue
                            parts = sName.split('-')
                            if len(parts) > 1 and cleantitle.get(parts[0].strip()) in t and str(season) in parts[1]:
                                links.append(sUrl)
                    if links: break
                except Exception:
                    continue

            if not links: return self.sources

            for link in set(links):
                try:
                    sHtmlContent = cRequestHandler(link).request()
                    if not sHtmlContent: continue

                    if season > 0:
                        # Episoden aus xStream showEpisodes + showHosters
                        pattern = r'"><a href="#">([^<]+)'
                        isMatch, aEpisodes = cParser.parse(sHtmlContent, pattern)
                        if not isMatch: continue
                        # Episode finden
                        ep_name = None
                        for ep in aEpisodes:
                            if str(episode) in ep:
                                ep_name = ep
                                break
                        if not ep_name: continue
                        pattern = r'>{0}<.*?</ul>'.format(ep_name)
                        isMatch, sBlock = cParser.parseSingleResult(sHtmlContent, pattern)
                        if not isMatch: continue
                        isMatch, aResult = cParser.parse(sBlock, r'link="([^"]+)"')
                        if not isMatch: continue
                        urls = aResult
                    else:
                        # Filme: link= Pattern aus xStream showHosters
                        isMatch, aResult = cParser.parse(sHtmlContent, r'link="([^"]+)"')
                        if not isMatch: continue
                        urls = aResult

                    for sUrl in urls:
                        if 'youtube' in sUrl or 'dropload' in sUrl: continue
                        if sUrl.startswith('//'): sUrl = 'https:' + sUrl
                        elif sUrl.startswith('/'): sUrl = self.base_link + sUrl
                        isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
                        if isBlocked: continue
                        if url: self.sources.append({'source': hoster, 'quality': 'HD', 'language': 'de',
                                                      'url': url, 'direct': True, 'prioHoster': prioHoster})
                except Exception:
                    continue

        except Exception:
            pass
        return self.sources

    def resolve(self, url):
        return url
