# hdfilme_1 (hdfilme.my - eigenes Template)
# edit 2026-03-29 (portiert von xStream hdfilme_1.py)

from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from resources.lib.control import getSetting, quote_plus

SITE_IDENTIFIER = 'hdfilme_1'
SITE_DOMAIN = 'hdfilme.bid'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/?story=%s&do=search&subaction=search'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            t = set([cleantitle.get(i) for i in set(titles) if i])
            years = (year, year+1, year-1)
            links = []

            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.search_link % quote_plus(sSearchText))
                    oRequest.cacheTime = 60 * 60 * 6
                    sHtmlContent = oRequest.request()
                    if not sHtmlContent: continue

                    # Pattern aus xStream hdfilme_1.py showEntries
                    pattern = r'class="item relative mt-3">.*?href="([^"]+).*?title="([^"]+).*?data-src="([^"]+)(.*?)</div></div>'
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    if not isMatch: continue

                    for sUrl, sName, sThumbnail, sDummy in aResult:
                        isYear, sYear = cParser.parseSingleResult(sDummy, r'mt-1">[^<]*<span>([\d]+)</span>')
                        if season == 0:
                            if cleantitle.get(sName) not in t: continue
                            if isYear and int(sYear) not in years: continue
                            links.append(sUrl)
                        else:
                            # Serien erkennen: kurze Laufzeit oder kein TMDB-Film-Treffer
                            if cleantitle.get(sName.split('-')[0].strip() if '-' in sName else sName) not in t: continue
                            links.append(sUrl)
                    if links: break
                except Exception:
                    continue

            if not links: return self.sources

            for link in set(links):
                try:
                    sHtmlContent = cRequestHandler(link).request()
                    if not sHtmlContent: continue

                    if season > 0:
                        # Staffel-Block aus xStream showEpisodes: #se-ac-{season}
                        pattern = r'#se-ac-%s(.*?)</div></div>' % season
                        isMatch, sSeasonBlock = cParser.parseSingleResult(sHtmlContent, pattern)
                        if not isMatch: continue
                        # Episode-Block: x{episode} Episode
                        pattern = r'x%s\sEpisode(.*?)<br' % episode
                        isMatch, sEpBlock = cParser.parseSingleResult(sSeasonBlock, pattern)
                        if not isMatch: continue
                        isMatch, aResult = cParser.parse(sEpBlock, r'href="([^"]+)"')
                        if not isMatch: continue
                        urls = aResult
                    else:
                        # Filme: iframe -> zweiter Request -> data-link (aus xStream showHosters)
                        pattern = r'<iframe\sw.*?src="([^"]+)"'
                        isMatch, hUrl = cParser.parseSingleResult(sHtmlContent, pattern)
                        if not isMatch: continue
                        sHtmlContent2 = cRequestHandler(hUrl).request()
                        if not sHtmlContent2: continue
                        isMatch, aResult = cParser.parse(sHtmlContent2, r'data-link="([^"]+)"')
                        if not isMatch: continue
                        urls = aResult

                    for sUrl in urls:
                        if 'youtube' in sUrl: continue
                        if sUrl.startswith('//'): sUrl = 'https:' + sUrl
                        elif sUrl.startswith('/'): sUrl = self.base_link + sUrl
                        isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
                        if isBlocked: continue
                        if url: self.sources.append({'source': hoster, 'quality': 'HD', 'language': 'de',
                                                      'url': url, 'direct': True, 'prioHoster': prioHoster})
                except Exception:
                    continue

        except Exception:
            pass
        return self.sources

    def resolve(self, url):
        return url
