# vavoo
# 2022-08-08
# edit 2026-04-02 (Hoster-Mapping + Redirect-Fallback aus vod_vavoo.py portiert)

from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
import requests
import json

SITE_IDENTIFIER = 'vavoo'
SITE_DOMAIN = 'vavoo.to'
SITE_NAME = SITE_IDENTIFIER.upper()

_PING_HEADERS = {
    "user-agent": "okhttp/4.11.0",
    "accept": "application/json",
    "content-type": "application/json; charset=utf-8",
    "accept-encoding": "gzip"
}
_PING_DATA = {
    "token": "tosFwQCJMS8qrW_AjLoHPQ41646J5dRNha6ZWHnijoYQQQoADQoXYSo7ki7O5-CsgN4CH0uRk6EEoJ0728ar9scCRQW3ZkbfrPfeCXW2VgopSW2FWDqPOoVYIuVPAOnXCZ5g",
    "reason": "app-blur", "locale": "de", "theme": "dark",
    "metadata": {
        "device": {"type": "Handset", "brand": "google", "model": "Nexus", "name": "21081111RG", "uniqueId": "d10e5d99ab665233"},
        "os": {"name": "android", "version": "7.1.2", "abis": ["arm64-v8a", "armeabi-v7a", "armeabi"], "host": "android"},
        "app": {"platform": "android", "version": "3.1.20", "buildId": "289515000", "engine": "hbc85",
                "signatures": ["6e8a975e3cbf07d5de823a760d4c2547f86c1403105020adee5de67ac510999e"],
                "installer": "app.revanced.manager.flutter"},
        "version": {"package": "tv.vavoo.app", "binary": "3.1.20", "js": "3.1.20"}
    },
    "appFocusTime": 0, "playerActive": False, "playDuration": 0, "devMode": False,
    "hasAddon": True, "castConnected": False, "package": "tv.vavoo.app",
    "version": "3.1.20", "process": "app",
    "firstAppStart": 1743962904623, "lastAppStart": 1743962904623,
    "ipLocation": "", "adblockEnabled": True,
    "proxy": {"supported": ["ss", "openvpn"], "engine": "ss", "ssVersion": 1,
              "enabled": True, "autoServer": True, "id": "pl-waw"},
    "iap": {"supported": False}
}

# Hoster-Name-Mapping aus vod_vavoo.py (xStream)
# Vavoo gibt interne Servernamen zurück — diese Tabelle übersetzt sie
# in die echten Hoster-Namen die resolveurl kennt
_SERVER_NAME_MAP = {
    'Server P2': 'Streamtape',
    'Server W2': 'Doodstream',
    'Server O':  'Vidoza',
    'Server E':  'Mixdrop',
    'Server M2': 'Supervideo',
    'Server G2': 'Luluvideo',
}

def _map_server_name(raw_name):
    """Übersetzt interne Vavoo-Servernamen in echte Hoster-Namen."""
    for key, mapped in _SERVER_NAME_MAP.items():
        if key in raw_name:
            return mapped
    return raw_name  # Fallback: Originalname behalten

# FIX: Signature einmal pro Session cachen - nicht bei jedem Mirror neu holen
_cached_sig = None

def getAuthSignature():
    global _cached_sig
    if _cached_sig:
        return _cached_sig
    try:
        req = requests.post('https://www.vavoo.tv/api/app/ping',
                            json=_PING_DATA, headers=_PING_HEADERS, timeout=10).json()
        _cached_sig = req.get('addonSig')
        return _cached_sig
    except Exception:
        return None

def _resolve_via_redirect(url):
    """
    Fallback-Auflösung aus vod_vavoo.py:
    Folgt HTTP-Redirects um die echte Stream-URL zu ermitteln,
    wenn mediahubmx-resolve keine URL liefert.
    """
    try:
        resp = requests.get(url, allow_redirects=True, timeout=10,
                            headers={"user-agent": "okhttp/4.11.0"})
        return resp.url if resp.url != url else None
    except Exception:
        return None

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            # TMDB-ID per IMDb-ID ermitteln
            tmdb_url = 'https://api.themoviedb.org/3/find/%s?api_key=be7e192d9ff45609c57344a5c561be1d&external_source=imdb_id' % imdb
            tmdb = requests.get(tmdb_url, timeout=10).json()

            if season == 0:
                results = tmdb.get('movie_results', [])
                if not results: return self.sources
                result = results[0]
                _data = {"language": "de", "region": "AT", "type": "movie",
                         "ids": {"tmdb_id": result['id']}, "name": result['title'],
                         "episode": {}, "clientVersion": "3.0.2"}
            else:
                results = tmdb.get('tv_results', [])
                if not results: return self.sources
                result = results[0]
                _data = {"language": "de", "region": "AT", "type": "series",
                         "ids": {"tmdb_id": result['id']}, "name": result['name'],
                         "episode": {"season": season, "episode": episode},
                         "clientVersion": "3.0.2"}

            sig = getAuthSignature()
            if not sig: return self.sources

            _headers = {"user-agent": "MediaHubMX/2",
                        "content-type": "application/json; charset=utf-8",
                        "accept-encoding": "gzip",
                        "mediahubmx-signature": sig}

            mirrors = requests.post("https://vavoo.to/mediahubmx-source.json",
                                    json=_data, headers=_headers, timeout=15).json()
            if not mirrors: return self.sources

            for mirror in mirrors:
                try:
                    # Nur deutsche Sprachspuren (aus vod_vavoo.py übernommene Logik)
                    langs = mirror.get('languages', [])
                    if langs and 'de' not in langs:
                        continue

                    # Hoster-Namen lesbar machen (aus vod_vavoo.py)
                    raw_name = mirror.get('name', '')
                    hoster_display = _map_server_name(raw_name)

                    # Primär: mediahubmx-resolve
                    _resolve_data = {"language": "de", "region": "AT",
                                     "url": mirror['url'], "clientVersion": "3.0.2"}
                    resolved = requests.post("https://vavoo.to/mediahubmx-resolve.json",
                                             json=_resolve_data, headers=_headers,
                                             timeout=10).json()
                    url = resolved.get('data', {}).get('url')

                    # Fallback: HTTP-Redirect (aus vod_vavoo.py)
                    if not url:
                        url = _resolve_via_redirect(mirror['url'])
                    if not url:
                        continue

                    isBlocked, hoster, sUrl, prioHoster = isBlockedHoster(url)
                    if isBlocked: continue

                    # Hoster-Namen: gemappten Namen bevorzugen, sonst resolveurl-Name
                    source_name = hoster_display if hoster_display != raw_name else hoster

                    if sUrl:
                        self.sources.append({
                            'source': source_name,
                            'quality': mirror.get('tag', 'SD'),
                            'language': 'de',
                            'url': sUrl,
                            'direct': True,
                            'prioHoster': prioHoster
                        })
                except Exception:
                    continue
        except Exception:
            pass
        return self.sources

    def resolve(self, url):
        return url
