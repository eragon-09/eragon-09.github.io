"""MeineCloud / DEVIDEOSRC API resolver for the xShip streamcloud scraper."""
import base64
import json
import re
import time
from html import unescape
from urllib.parse import urlparse
from resources.lib.requestHandler import cRequestHandler

HOSTS = ('meinecloud.click', 'devideosrc.co')
TOKEN = re.compile(r'token\s*:\s*["\']([^"\']{16,})["\']')
IMDB = re.compile(r'tt\d+', re.I)


def _log(message):
    try:
        import xbmc
        xbmc.log('[xShip meinecloud] ' + str(message), xbmc.LOGINFO)
    except Exception:
        pass


def is_platform(url):
    host = urlparse(('https:' + url) if (url or '').startswith('//') else (url or '')).hostname or ''
    return any(host == name or host.endswith('.' + name) for name in HOSTS)


def _request(url, referer='', payload=None):
    try:
        req = cRequestHandler(url, caching=False, ignoreErrors=True, jspost=payload is not None)
        if payload is not None:
            for key, value in payload.items():
                req.addParameters(key, value)
            req.addHeaderEntry('Origin', url.split('/api/', 1)[0])
        if referer:
            req.addHeaderEntry('Referer', referer)
        result = req.request() or ''
        if any(result.startswith(error) for error in ('DDOS GUARD SCHUTZ', 'CLOUDFLARE-SCHUTZ AKTIV', 'SEITE NICHT ERREICHBAR', 'URL FEHLER', 'TIMEOUT')):
            return ''
        return result
    except Exception as exc:
        _log('Request fehlgeschlagen: %s (%s)' % (url, exc))
        return ''


def _hosts(preferred=''):
    host = urlparse(preferred).hostname or ''
    return [host] + [name for name in HOSTS if name != host] if host in HOSTS else list(HOSTS)


def _decode(url):
    url = str(url or '').strip()
    if not url.startswith(('http://', 'https://', '//')):
        try:
            decoded = base64.b64decode(url + '=' * (-len(url) % 4)).decode('utf-8').strip()
            if decoded.startswith(('http://', 'https://', '//')):
                url = decoded
        except Exception:
            pass
    return 'https:' + url if url.startswith('//') else url


def _urls(sources):
    urls = []
    for item in sources or []:
        if not isinstance(item, dict):
            continue
        url = _decode(item.get('url'))
        if url.startswith(('http://', 'https://')) and not is_platform(url) and url not in urls:
            urls.append(url)
    return urls


def _fetch(imdb, kind, preferred='', referer=''):
    for host in _hosts(preferred):
        base = 'https://' + host
        page = '%s/%s/%s' % (base, kind, imdb)
        html = _request(page, referer)
        match = TOKEN.search(html)
        if not match:
            continue
        token = match.group(1)
        try:
            parts = base64.b64decode(token.split('.')[0] + '===').decode('utf-8', 'replace').split('|')
            if int(parts[4]) <= int(time.time()) + 30:
                continue
        except (ValueError, IndexError, TypeError):
            pass
        response = _request(base + '/api/embed-links', page, {'type': 'movie' if kind == 'movie' else 'tv', 'id': imdb, 'token': token})
        try:
            data = json.loads(response)
            if isinstance(data, dict) and data.get('ok'):
                return data
        except (TypeError, ValueError):
            pass
    _log('Keine API-Quellen fuer %s/%s' % (kind, imdb))
    return {}


def movie(imdb, preferred='', referer=''):
    match = IMDB.search(str(imdb or ''))
    if not match:
        return []
    return _urls(_fetch(match.group(0), 'movie', preferred, referer).get('sources'))


def series(imdb, season, episode, preferred='', referer=''):
    match = IMDB.search(str(imdb or ''))
    if not match:
        return []
    data = _fetch(match.group(0), 'serial', preferred, referer)
    for item in (data.get('tv') or {}).get('seasons') or []:
        if not isinstance(item, dict) or str(item.get('season_number')) != str(int(season)):
            continue
        for ep in item.get('episodes') or []:
            if isinstance(ep, dict) and str(ep.get('episode_number')) == str(int(episode)):
                return _urls(ep.get('sources'))
    return []
