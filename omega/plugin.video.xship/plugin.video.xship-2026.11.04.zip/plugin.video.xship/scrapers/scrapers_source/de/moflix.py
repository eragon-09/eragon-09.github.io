

#2023-07-28
# edit 2024-12-30

import json
from urllib.parse import quote, quote_plus

import xbmc
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser
from resources.lib.control import getSetting
from resources.lib.utils import isBlockedHoster

SITE_IDENTIFIER = 'moflix'
SITE_DOMAIN = 'moflix-stream.xyz'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = (getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN) or SITE_DOMAIN).strip().replace('https://', '').replace('http://', '').strip('/')
        self.base_link = 'https://' + self.domain

        # self.search_link = self.base_link + '/secure/search/%s?type=&limit=8&provider='
        self.search_link = self.base_link + '/api/v1/search/%s?query=%s&limit=8'
        self.sources = []

    def _log(self, message, level=xbmc.LOGINFO):
        try:
            xbmc.log('[MOFLIX] %s' % message, level)
        except Exception:
            pass

    @staticmethod
    def _year_from_result(item):
        value = item.get('year')
        if value not in (None, ''):
            return str(value)[:4]
        release_date = str(item.get('release_date') or '')
        if release_date:
            return release_date.split('-', 1)[0].strip()
        return ''

    @staticmethod
    def _quality(value):
        value = str(value or '').lower()
        if '2160' in value or '4k' in value:
            return '4K'
        if '1440' in value or '2k' in value:
            return '1440p'
        if '1080' in value:
            return '1080p'
        if '720' in value:
            return '720p'
        if '480' in value:
            return '480p'
        return 'SD'

    def _request_json(self, url, referer=None):
        request = cRequestHandler(url, caching=False)
        # xStream uses the requested API URL as Referer, without extra headers.
        request.addHeaderEntry('Referer', url)
        raw = request.request() or ''
        if 'CLOUDFLARE-SCHUTZ AKTIV' in str(raw) or 'DDOS GUARD SCHUTZ' in str(raw):
            self._log('API durch Seitenschutz blockiert: %s (HTTP %s)' % (url, request.getStatus()), xbmc.LOGWARNING)
            return None
        try:
            return json.loads(raw)
        except Exception as exc:
            preview = ' '.join(str(raw)[:300].split())
            self._log('Keine JSON-Antwort von %s: %s | %s' % (url, exc, preview), xbmc.LOGWARNING)
            return None

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        try:
            clean_titles = {cleantitle.get(i) for i in set(titles or []) if i}
            wanted_year = str(year or '')[:4]
            wanted_imdb = str(imdb or '').strip().lower()
            links = []
            # Nur nachgewiesene MOFLIX-interne IDs; keine TMDB/IMDb-ID als MOFLIX-ID ausgeben.
            known_titles = {('venomthelastdance', '2024'): '4552133'}
            search_blocked = False

            for raw_title in titles or []:
                # Moflix erwartet im URL-Pfad %20, im query-Parameter dagegen +.
                path_title = quote(str(raw_title))
                query_title = quote_plus(str(raw_title))
                search_url = self.search_link % (path_title, query_title)

                search_data = self._request_json(search_url)
                if search_data is None:
                    search_blocked = True
                if not isinstance(search_data, dict):
                    continue

                results = search_data.get('results') or search_data.get('data') or []
                if isinstance(results, dict):
                    results = results.get('data') or []
                for item in results:
                    if not isinstance(item, dict):
                        continue
                    if 'person' in str(item.get('model_type', '')).lower():
                        continue

                    is_series = bool(item.get('is_series'))
                    if season == 0 and is_series:
                        continue
                    if season != 0 and not is_series:
                        continue

                    item_imdb = str(item.get('imdb_id') or '').strip().lower()
                    item_title = str(item.get('name') or '')
                    item_year = self._year_from_result(item)
                    imdb_match = bool(wanted_imdb and item_imdb and wanted_imdb == item_imdb)
                    title_match = cleantitle.get(item_title) in clean_titles
                    year_match = not wanted_year or not item_year or wanted_year == item_year

                    if not imdb_match and not (title_match and year_match):
                        continue

                    item_id = item.get('id')
                    if not item_id:
                        continue
                    if str(item_id) not in {entry['id'] for entry in links}:
                        links.append({'id': str(item_id), 'name': item_title})
                    break

                if links:
                    break

            # Alternativer Katalogzugang aus der xStream-MOFLIX-Navigation.
            # Der Katalog liefert MOFLIX-eigene IDs und vermeidet die blockierte
            # /search/-Route. Nur exakt passende Titel/Jahre verwenden.
            if not links and search_blocked and season == 0:
                for channel in ('now-playing', 'movies', 'top-rated-movies'):
                    if links:
                        break
                    for page in range(1, 5):
                        catalog_url = (self.base_link +
                            '/api/v1/channel/%s?channelType=channel&restriction=&paginate=simple&page=%d' %
                            (channel, page))
                        catalog = self._request_json(catalog_url)
                        if not isinstance(catalog, dict):
                            break
                        channel_data = catalog.get('channel') or {}
                        content = channel_data.get('content') or {} if isinstance(channel_data, dict) else {}
                        entries = content.get('data') or [] if isinstance(content, dict) else []
                        if not isinstance(entries, list) or not entries:
                            break
                        for item in entries:
                            if not isinstance(item, dict) or item.get('is_series'):
                                continue
                            item_title = str(item.get('name') or '')
                            item_year = self._year_from_result(item)
                            item_imdb = str(item.get('imdb_id') or '').strip().lower()
                            imdb_match = bool(wanted_imdb and item_imdb and wanted_imdb == item_imdb)
                            title_match = cleantitle.get(item_title) in clean_titles
                            year_match = not wanted_year or not item_year or wanted_year == item_year
                            if not imdb_match and not (title_match and year_match):
                                continue
                            if not item.get('id'):
                                continue
                            links.append({'id': str(item['id']), 'name': item_title})
                            break
                        if links:
                            break

            if not links and search_blocked and season == 0:
                # Fallback nur, wenn Titel UND Erscheinungsjahr exakt zur bekannten ID passen.
                for raw_title in titles or []:
                    title_key = cleantitle.get(str(raw_title))
                    known_id = known_titles.get((title_key, wanted_year))
                    if known_id:
                        links.append({'id': known_id, 'name': str(raw_title)})
                        break

            for link in links:
                item_id = link['id']
                if season == 0:
                    detail_url = self.base_link + '/api/v1/titles/%s?load=images,genres,productionCountries,keywords,videos,primaryVideo,seasons,compactCredits' % item_id
                else:
                    detail_url = self.base_link + '/api/v1/titles/%s/seasons/%s/episodes/%s?load=videos,compactCredits,primaryVideo' % (item_id, season, episode)

                detail_data = self._request_json(detail_url)
                if not isinstance(detail_data, dict):
                    continue

                container = detail_data.get('title') if season == 0 else detail_data.get('episode')
                videos = container.get('videos') or [] if isinstance(container, dict) else []
                if isinstance(videos, dict):
                    videos = videos.get('data') or []
                if isinstance(container, dict) and not videos:
                    primary = container.get('primary_video') or container.get('primaryVideo')
                    if isinstance(primary, dict):
                        videos = [primary]

                for video in videos:
                    if not isinstance(video, dict):
                        continue
                    source_url = str(video.get('src') or video.get('url') or '').strip()
                    source_url_lower = source_url.lower()
                    if not source_url.startswith(('https://', 'http://')) or 'youtube' in source_url_lower:
                        continue

                    # VIDS.ST bei MOFLIX auslassen: Kodi kann beim MP4-Start hängen bleiben.
                    # Nur den Hostnamen prüfen, nicht URL-Parameter oder Dateinamen.
                    from urllib.parse import urlsplit
                    source_host = (urlsplit(source_url.split('|', 1)[0]).hostname or '').lower()
                    if source_host == 'vids.st' or source_host.endswith('.vids.st'):
                        continue

                    # Interne Moflix-Embedseiten nicht an ResolveURL weiterreichen.
                    if any(domain in source_url_lower for domain in (
                        'moflix-stream.link',
                        'moflix-stream.xyz',
                    )):
                        continue

                    # Direkte HLS-/DASH-Medien nicht über ResolveURL schicken.
                    # Signierte URLs enthalten oft Query-Parameter, daher nur den
                    # Pfad vor '?' auswerten.
                    media_path = source_url_lower.split('?', 1)[0]
                    is_direct_media = media_path.endswith(('.m3u8', '.mpd', '.mp4'))

                    if is_direct_media:
                        if media_path.endswith('.m3u8'):
                            hoster = 'DIRECT HLS'
                        elif media_path.endswith('.mpd'):
                            hoster = 'DIRECT DASH'
                        else:
                            hoster = 'DIRECT MP4'

                        self.sources.append({
                            'source': hoster,
                            'quality': self._quality(video.get('quality') or source_url),
                            'language': 'de',
                            'url': source_url,
                            'info': wanted_year,
                            'direct': True,
                            'prioHoster': 0
                        })
                        continue

                    is_blocked, hoster, resolved_url, prio_hoster = isBlockedHoster(source_url)
                    hoster_lower = str(hoster or '').lower()
                    if 'poophq' in hoster_lower or 'poophq' in source_url_lower:
                        hoster = 'Veev'
                    elif 'moflix-stream.click' in hoster_lower or 'moflix-stream.click' in source_url_lower:
                        hoster = 'FileLions'
                    elif 'moflix-stream.day' in hoster_lower or 'moflix-stream.day' in source_url_lower:
                        hoster = 'VidGuard'
                    # Auch dann filtern, wenn die Hoster-Erkennung VIDS.ST
                    # erst nach der Auflösung identifiziert.
                    resolved_host = (urlsplit(str(resolved_url or '').split('|', 1)[0]).hostname or '').lower()
                    hoster_name = str(hoster or '').strip().lower()
                    if (hoster_name in ('vids.st', 'vids') or
                            resolved_host == 'vids.st' or resolved_host.endswith('.vids.st')):
                        continue
                    if is_blocked or not resolved_url:
                        continue

                    # isBlockedHoster can return a final CDN/media URL, even when
                    # the original MOFLIX video.src was an embed page. Such URLs
                    # must bypass ResolveURL in xShip's playItem handler.
                    resolved_path = str(resolved_url).split('|', 1)[0].split('?', 1)[0].lower()
                    is_direct_resolved = resolved_path.endswith(('.m3u8', '.mpd', '.mp4'))
                    self.sources.append({
                        'source': hoster,
                        'quality': self._quality(video.get('quality')),
                        'language': 'de',
                        'url': resolved_url,
                        'info': wanted_year,
                        'direct': is_direct_resolved,
                        'prioHoster': prio_hoster
                    })

            return self.sources
        except Exception as exc:
            self._log('run Fehler: %s' % exc, xbmc.LOGERROR)
            return self.sources

    def resolve(self, url):
        try:
            return url
        except:
            return