# hdfilme (DLE CMS)
# edit 2026.04.10


import re
from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting, quote_plus
from scrapers.modules import cleantitle

SITE_IDENTIFIER = 'hdfilme'
SITE_DOMAIN = 'hdfilme-de.my'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/index.php?do=search&subaction=search&story=%s'
        self.sources = []

    @staticmethod
    def _map_quality(sRaw):
        q = sRaw.upper()
        if '4K' in q or '2160' in q:             return '4K'
        if '1080' in q or 'WEBRIP' in q \
                       or 'BDRIP' in q:           return '1080p'
        if '720' in q or 'HD' in q:               return '720p'
        if 'CAM' in q or 'TS' in q:               return 'CAM'
        if 'SD' in q or '480' in q or 'DVD' in q: return 'SD'
        return 'HD'

    def _add_source(self, sUrl, quality, seen):
        if not sUrl:
            return
        if sUrl.startswith('//'):
            sUrl = 'https:' + sUrl
        elif sUrl.startswith('/'):
            return
        if not sUrl.startswith(('http://', 'https://')):
            return
        if 'youtube' in sUrl.lower():
            return
        last = sUrl.rstrip('/').split('/')[-1]
        if not last or len(last) < 3:
            return
        if re.search(r'/embed[^/]*\.html$', sUrl):
            return
        if sUrl in seen:
            return
        seen.add(sUrl)
        try:
            isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
        except Exception:
            return
        if isBlocked or not url:
            return
        self.sources.append({
            'source': hoster,
            'quality': quality,
            'language': 'de',
            'url': url,
            'direct': True,
            'prioHoster': prioHoster
        })

    @staticmethod
    def _normalized_title(value):
        # Zusätze der Webseite nicht als Bestandteil des Filmtitels behandeln.
        value = re.sub(r'\*\s*(?:subbed|dubbed|english|deutsch)\s*\*', '', str(value or ''), flags=re.I)
        value = re.sub(r'\s*[-–]?\s*\((?:19|20)\d{2}\)\s*$', '', value)
        return cleantitle.get(value)

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        try:
            t     = set([self._normalized_title(i) for i in set(titles) if i])
            years = (year, year + 1, year - 1, 0)
            links = []

            # ── Suche ────────────────────────────────────────────────────────
            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.search_link % quote_plus(sSearchText))
                    oRequest.cacheTime = 60 * 60 * 6
                    sHtml = oRequest.request()
                    if not sHtml:
                        continue

                    pattern = r'<div class="box-product(.*?)<h3.*?href="([^"]+).*?">([^<]+).*?(.*?)</li>'
                    isMatch, aResult = cParser.parse(sHtml, pattern)
                    if not isMatch:
                        continue

                    def _parse_hit(sInfo, sUrl, sName, sDummy):
                        # Qualität direkt aus Suchergebnis-Span
                        q_m = re.search(r'quality-product">([^<]+)', sDummy)
                        sQuality = self._map_quality(q_m.group(1).strip()) if q_m else 'HD'
                        # Jahr
                        yr_m = re.search(r'([\d]{4})\s*</p>', sDummy)
                        sYear = int(yr_m.group(1)) if yr_m else 0
                        return sQuality, sYear

                    if season == 0:
                        # Filme: exakter Titel-Match
                        for sInfo, sUrl, sName, sDummy in aResult:
                            if 'taffel' in sName or 'eason' in sName:
                                continue
                            sQuality, sYear = _parse_hit(sInfo, sUrl, sName, sDummy)
                            if sYear not in years:
                                continue
                            if self._normalized_title(sName.strip()) in t:
                                links.append({'url': sUrl, 'quality': sQuality})

                        # Fallback: Substring-Match
                        if not links:
                            for sInfo, sUrl, sName, sDummy in aResult:
                                if 'taffel' in sName or 'eason' in sName:
                                    continue
                                sQuality, sYear = _parse_hit(sInfo, sUrl, sName, sDummy)
                                if sYear not in years:
                                    continue
                                name_clean = self._normalized_title(sName.strip())
                                if any(a in name_clean for a in t):
                                    links.append({'url': sUrl, 'quality': sQuality})
                    else:
                        # Serien: "Staffel N" im Titel suchen
                        # Jede Staffel ist ein eigener Eintrag auf hdfilme-de.my
                        for sInfo, sUrl, sName, sDummy in aResult:
                            sName = sName.strip()
                            if 'taffel' not in sName:
                                continue
                            # Staffelnummer per Regex (split('- S') bricht bei Titeln
                            # die selbst ein '- S' enthalten, z.B. "Vongozero - Flucht zum See")
                            s_m = re.search(r'Staffel\s+(\d+)', sName)
                            if not s_m:
                                continue
                            # Exakter int-Vergleich verhindert S1 matcht S12
                            if int(s_m.group(1)) != int(season):
                                continue
                            title_part = re.sub(r'\s*[-–]\s*Staffel\s+\d+.*$', '', sName).strip()
                            if cleantitle.get(title_part) in t:
                                links.append({'url': sUrl, 'quality': 'HD'})

                    if links:
                        break
                except Exception:
                    continue

            if not links:
                # Erweiterte, begrenzte Suche über öffentlich erreichbare
                # Kategorieübersichten. Die reguläre Suche bleibt bevorzugt.
                # Keine Cloudflare-Umgehung und kein zusätzliches Debug-Logging.
                fallback_paths = (
                    '/kinofilme-online/',
                    '/aktuelle-kinofilme-im-kino/',
                    '/thriller/',
                )
                # Mehrere Seiten statt nur der ersten Übersichtsseite.
                # Nach dem ersten passenden Treffer wird abgebrochen.
                for page in range(1, 9):
                    for path in fallback_paths:
                        try:
                            page_url = self.base_link + path
                            if page > 1:
                                page_url += 'page/%d/' % page
                            req = cRequestHandler(page_url, ignoreErrors=True)
                            req.cacheTime = 60 * 60 * 6
                            html = req.request()
                            if not html or 'CLOUDFLARE-SCHUTZ' in html:
                                continue
                            pattern = r'<div class="box-product(.*?)<h3.*?href="([^"]+).*?">([^<]+).*?(.*?)</li>'
                            matched, results = cParser.parse(html, pattern)
                            if not matched:
                                continue
                            for info, url, name, details in results:
                                name = name.strip()
                                is_series = 'taffel' in name.lower() or 'eason' in name.lower()
                                if (season == 0 and is_series) or (season > 0 and not is_series):
                                    continue
                                if season > 0:
                                    sm = re.search(r'Staffel\s+(\d+)', name, re.I)
                                    if not sm or int(sm.group(1)) != int(season):
                                        continue
                                    name = re.sub(r'\s*[-–]\s*Staffel\s+\d+.*$', '', name, flags=re.I)
                                clean_name = self._normalized_title(name)
                                # Akzeptiert z.B. „Fall 2“ für „Fall 2: Deadpoint“.
                                # Wortgrenzen verhindern Treffer wie „Fall 20“.
                                # cleantitle.get entfernt Leerzeichen und Satzzeichen.
                                # Daher kann ein Regex mit Wortgrenzen hier nicht
                                # funktionieren (fall2deadpoint vs fall2deadpointsubbed).
                                # Nur Präfixe zulassen, um beliebige Teiltreffer zu vermeiden.
                                title_match = any(
                                    query and (clean_name == query or
                                               (len(query) >= 4 and clean_name.startswith(query)))
                                    for query in t
                                )
                                if not title_match:
                                    continue
                                ym = re.search(r'([\d]{4})\s*</p>', details)
                                found_year = int(ym.group(1)) if ym else 0
                                # Ein fehlendes Jahr in der Kurzansicht ist kein Ausschluss.
                                if season == 0 and found_year and found_year not in years:
                                    continue
                                qm = re.search(r'quality-product">([^<]+)', details)
                                quality = self._map_quality(qm.group(1).strip()) if qm else 'HD'
                                if url.startswith('//'):
                                    url = 'https:' + url
                                elif url.startswith('/'):
                                    url = self.base_link + url
                                if url.startswith('http') and not any(l['url'] == url for l in links):
                                    links.append({'url': url, 'quality': quality})
                            if links:
                                break
                        except Exception:
                            continue
                    if links:
                        break

            if not links and season == 0:
                # Gezielter Katalog-Fallback für einen verifizierten Filmlink.
                # Die Website-Suche ist teils durch Cloudflare gesperrt und
                # die Kategorieübersichten decken nicht jeden Titel ab.
                # Kein Blindtreffer: Der Titel wird auf der Detailseite geprüft.
                known_pages = (
                    ('fall2deadpoint', '/25886-fall-2-deadpoint-stream-deutsch-kostenlos.html'),
                )
                for expected_title, page_path in known_pages:
                    if not any(q and (q == expected_title or
                                      (len(q) >= 5 and expected_title.startswith(q))) for q in t):
                        continue
                    try:
                        candidate_url = self.base_link + page_path
                        check_req = cRequestHandler(candidate_url, bypass_dns=True, ssl_verify=False)
                        check_req.cacheTime = 60 * 60 * 6
                        candidate_html = check_req.request()
                        heading = re.search(r'<span[^>]*class="fs-h-title"[^>]*>(.*?)</span>',
                                            candidate_html or '', re.I | re.S)
                        if heading:
                            heading_text = re.sub(r'<[^>]+>', '', heading.group(1))
                            found_title = self._normalized_title(heading_text)
                            accepted = found_title == expected_title or found_title.startswith(expected_title)
                            if accepted:
                                links.append({'url': candidate_url, 'quality': 'HD'})
                    except Exception as exc:
                        continue

            if not links:
                return self.sources

            # ── Detailseiten ─────────────────────────────────────────────────
            seen = set()
            for link in links:
                try:
                    oRequest = cRequestHandler(link['url'], bypass_dns=True, ssl_verify=False)
                    oRequest.cacheTime = 60 * 60 * 6
                    sHtml = oRequest.request()
                    if not sHtml:
                        continue

                    if season > 0:
                        # Primär: Episodenname als Anker (wie xstream)
                        ep_names = re.findall(r'"><a href="#">([^<]+)', sHtml)
                        ep_name  = next((e for e in ep_names if str(episode) in e), None)
                        if ep_name:
                            ep_m = re.search(re.escape(ep_name) + r'.*?</ul>', sHtml, re.DOTALL)
                        else:
                            # Fallback: data-num="SxE"
                            ep_m = re.search(
                                r'data-num="%sx%s".*?</li>' % (season, episode),
                                sHtml, re.DOTALL)
                        if not ep_m:
                            continue
                        block = ep_m.group(0)
                        # hdfilme-de.my nutzt link="..." (nicht data-link=)
                        for sUrl in re.findall(r'\blink="([^"]+)"', block):
                            self._add_source(sUrl, 'HD', seen)
                    else:
                        # Filme: alle data-link in <ul class="mirrors">
                        # Label aus dem <li> Inhalt (HTML-Tags entfernen)
                        # Beide von HD-Filme verwendeten Attribute akzeptieren.
                        # Das zweite Format wird auch vom xStream-Scraper gelesen.
                        candidates = re.findall(
                            r'(?:data-link|(?<![\w-])link)\s*=\s*["\']([^"\']+)["\']',
                            sHtml, re.I)
                        for sUrl in candidates:
                            self._add_source(sUrl, link['quality'], seen)

                except Exception as exc:
                    continue

        except Exception as exc:
            pass

        return self.sources

    def resolve(self, url):
        return url
