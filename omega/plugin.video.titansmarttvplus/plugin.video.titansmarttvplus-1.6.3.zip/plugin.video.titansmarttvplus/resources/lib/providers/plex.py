# -*- coding: utf-8 -*-
"""Ausgelagerte Provider-Implementierung."""

def _plex_is_german_channel(ch):
    """
    Erkennt den deutsch lokalisierten Plex-Feed anhand der von Plex gelieferten
    deutschen Senderbeschreibung. Die /de/live-tv-Liste selbst enthaelt auch
    internationale FAST-Sender, daher reicht die Region allein nicht aus.
    """
    text = f"{ch.get('title', '')} {ch.get('plot', '')}".lower()
    # Sehr eindeutige deutsche Woerter; bewusst ohne kurze/mehrdeutige Tokens
    # wie "in", "ist" oder "die" (engl. Verb), um Fehlklassifikationen zu
    # vermeiden.
    german_words = {
        "der", "das", "den", "dem", "des", "und", "oder", "für", "fuer",
        "mit", "von", "eine", "einer", "einem", "einen", "eines", "auf",
        "aus", "zur", "zum", "über", "ueber", "deutsch", "deutsche",
        "deutschen", "filme", "serien", "sendungen", "zeigt", "erlebt",
        "gegen", "nach", "seine", "seiner", "ihre", "ihrer", "wird",
        "werden", "sich", "nicht", "auch", "beim", "durch", "zwischen",
        "menschen", "welt", "jagd", "geschichten", "folgen"
    }
    words = re.findall(r"[a-zäöüß]+", text)
    hits = sum(1 for word in words if word in german_words)
    has_german_chars = any(c in text for c in "äöüß")
    title = (ch.get("title") or "").lower()
    explicit = any(x in title for x in (
        "deutsch", "euronews deutsch", "spiegel tv", "netzkino",
        "myspass", "stromberg", "pastewka", "täterjagd", "taeterjagd"
    ))
    return explicit or hits >= 2 or (has_german_chars and hits >= 1)


def load_plex_de_static():
    """Laedt die gebuendelte deutsche Plex-Live-TV-Liste samt Jetzt/Danach-EPG."""
    try:
        raw = read_text(PLEX_DE_CHANNELS_FILE)
        data = json.loads(raw) if raw else []
    except Exception as e:
        log(f"Plex DE Kanalliste konnte nicht geladen werden: {e}", xbmc.LOGERROR)
        return []

    german_only = ADDON.getSetting("plex_german_only") != "false"
    if german_only:
        before = len(data)
        data = [ch for ch in data if _plex_is_german_channel(ch)]
        log(f"[Plex DE] Sprachfilter aktiv: {len(data)} von {before} Sendern")

    # Erst nach dem Sprachfilter laden: dadurch werden nur die tatsaechlich
    # angezeigten Plex-DE-Sender beim Cloud-Guide abgefragt.
    wanted_ids = [str(ch.get("id") or "").strip() for ch in data if ch.get("id")]
    use_epg = epg_enabled("plex")
    epg_map = plex_fetch_epg_grid(channel_ids=wanted_ids) if (use_epg and plex_is_logged_in()) else {}
    if use_epg and plex_is_logged_in():
        matched_ids = [cid for cid in wanted_ids if cid in epg_map]
        log(f"[Plex EPG] DE-Sender={len(wanted_ids)} EPG-Treffer={len(matched_ids)}")

    channels = []
    for ch in data:
        cid = ch.get("id", "")
        epg_item = epg_map.get(cid) if epg_map else None
        channels.append({
            "name": ch.get("title", "Kanal"), "url": ch.get("url", ""),
            "logo": ch.get("logo", ""), "group": ch.get("group", "Sonstige"),
            "tvgid": cid, "tvgname": ch.get("title", ""), "channel_id": cid,
            "plot_static": ch.get("plot", ""),
            "epg_now": (epg_item or {}).get("now"),
            "epg_next": (epg_item or {}).get("next"),
        })
    return channels




def _plex_parse_grid(data, forced_channel_id=None):
    """Parst eine Plex-/grid-Antwort in das gemeinsame {now,next}-Format.

    Der Plex-Cloud-Endpunkt ``/grid`` wird pro Sender mit ``channelGridKey``
    und ``date`` abgefragt. In dieser Antwort liegen ``beginsAt``/``endsAt``
    in ``Metadata[].Media[]``. Manche Cloud-Antworten enthalten dabei keine
    ``channelIdentifier``-Angabe; deshalb kann der bereits bekannte statische
    Sender-Schluessel als ``forced_channel_id`` mitgegeben werden.
    """
    epg_entries = {}
    now_ts = int(time.time())

    container = data.get("MediaContainer", data) if isinstance(data, dict) else {}
    items = container.get("Metadata") or container.get("metadata") or []
    if isinstance(items, dict):
        items = [items]

    for item in items:
        if not isinstance(item, dict):
            continue
        title = (item.get("title") or item.get("grandparentTitle") or item.get("parentTitle") or "").strip()
        summary = (item.get("summary") or "").strip()
        media_list = item.get("Media") or item.get("media") or []
        if isinstance(media_list, dict):
            media_list = [media_list]
        if not media_list:
            media_list = [item]

        for media in media_list:
            if not isinstance(media, dict):
                continue
            cid = (forced_channel_id or media.get("channelIdentifier") or media.get("channelGuid") or
                   media.get("channelID") or media.get("channelId") or
                   item.get("channelIdentifier") or item.get("channelGuid") or
                   item.get("channelID") or item.get("channelId") or "")
            if isinstance(cid, str) and "/" in cid:
                cid = cid.rsplit("/", 1)[-1]
            cid = str(cid or "").strip()

            starts = (media.get("beginsAt") or media.get("start") or
                      item.get("beginsAt") or item.get("start"))
            ends = (media.get("endsAt") or media.get("stop") or
                    item.get("endsAt") or item.get("stop"))
            if not (cid and starts and title):
                continue
            try:
                starts = int(starts)
                if ends:
                    ends = int(ends)
                else:
                    duration_ms = media.get("duration") or item.get("duration") or 3600000
                    ends = starts + max(60, int(duration_ms) // 1000)
            except (TypeError, ValueError):
                continue
            epg_entries.setdefault(cid, []).append({
                "start": starts,
                "stop": ends,
                "title": title,
                "desc": summary,
            })

    epg_map = {}
    for cid, entries in epg_entries.items():
        # Doppelte Airings vermeiden und chronologisch sortieren.
        uniq = {}
        for e in entries:
            uniq[(e.get("start"), e.get("stop"), e.get("title"))] = e
        entries = sorted(uniq.values(), key=lambda x: x.get("start") or 0)
        now_item = None
        next_item = None
        for entry in entries:
            if entry["start"] <= now_ts < entry["stop"]:
                now_item = entry
            elif entry["start"] > now_ts:
                next_item = entry
                break
        if now_item or next_item:
            epg_map[cid] = {"now": now_item, "next": next_item}
    return epg_map


def _plex_cloud_channels(client_id, token):
    """Liefert Plex-Free-Live-TV Channel-ID -> gridKey."""
    headers = _plex_headers(client_id, token)
    headers.update({
        "X-Plex-Provider-Version": "7.0.0",
        "X-Plex-Language": "de",
        "Accept-Language": "de-DE,de;q=0.9",
        "Accept": "application/json",
    })
    try:
        r = requests.get("https://epg.provider.plex.tv/lineups/plex/channels", headers=headers, timeout=20)
        log(f"[Plex EPG] GET /lineups/plex/channels -> HTTP {r.status_code}")
        if r.status_code != 200:
            log(f"[Plex EPG] Channel-Liste Fehler: {r.text[:300]}", xbmc.LOGWARNING)
            return {}
        data = r.json()
    except Exception as e:
        log(f"[Plex EPG] Channel-Liste fehlgeschlagen: {e}", xbmc.LOGWARNING)
        return {}

    container = data.get("MediaContainer", data) if isinstance(data, dict) else {}
    items = container.get("Channel") or container.get("Metadata") or [] if isinstance(container, dict) else []
    if isinstance(items, dict):
        items = [items]
    result = {}
    for ch in items if isinstance(items, list) else []:
        if not isinstance(ch, dict):
            continue
        cid = str(ch.get("id") or "").strip()
        grid = str(ch.get("gridKey") or "").strip()
        if cid and grid:
            result[cid] = grid
    log(f"[Plex EPG] Cloud-Kanalliste: {len(result)} Sender mit gridKey")
    return result


def _plex_fetch_grid_channel(cid, grid_key, headers, day):
    """Lädt den Tages-Guide eines Plex-Senders und liefert (cid, epg_item)."""
    try:
        r = requests.get(
            "https://epg.provider.plex.tv/grid",
            headers=headers,
            params={"channelGridKey": grid_key, "date": day},
            timeout=15,
        )
        if r.status_code != 200:
            return cid, None, r.status_code
        parsed = _plex_parse_grid(r.json(), forced_channel_id=cid)
        return cid, parsed.get(cid), 200
    except Exception:
        return cid, None, 0


def plex_fetch_epg_grid(force=False, channel_ids=None):
    """Lädt Jetzt/Danach für die angezeigten deutschen Plex-Live-TV-Sender.

    v1.19.6: Der bestätigte Cloud-Aufruf ``/grid?channelGridKey=...&date=...``
    wird pro Sender verwendet. Die Requests laufen begrenzt parallel und das
    Ergebnis wird wie bisher über den Plex-EPG-Cache wiederverwendet.
    """
    cache_sec = get_plex_epg_cache_seconds()
    cpath = cache_path("plexepg", "de")
    stale = {}
    if xbmcvfs.exists(cpath):
        cached = read_json(cpath, {})
        stale = cached.get("epg_map") or {}
        if not force and cached.get("ts") and (time.time() - cached["ts"]) <= cache_sec:
            # Die statische Plex-DE-Senderliste ist Bestandteil des Addons. Ein
            # einzelner Sender ohne Cloud-gridKey darf deshalb einen frischen
            # EPG-Cache nicht ungueltig machen. Sonst wuerde bei jedem Oeffnen
            # bzw. nach der Wiedergabe die komplette Plex-Cloud erneut geladen.
            log(f"[Plex EPG] Cache: {len(stale)} Sender (sofort verwendet)")
            return stale

    token = get_plex_token()
    client_id = get_plex_client_id()
    if not token:
        return stale

    wanted = [str(x).strip() for x in (channel_ids or []) if str(x).strip()]
    cloud = _plex_cloud_channels(client_id, token)
    if not cloud:
        return stale
    targets = [(cid, cloud.get(cid)) for cid in wanted if cloud.get(cid)]
    log(f"[Plex EPG] Grid-Zuordnung: {len(targets)} von {len(wanted)} Plex-DE-Sendern")
    if not targets:
        return stale

    headers = _plex_headers(client_id, token)
    headers.update({
        "X-Plex-Provider-Version": "7.0.0",
        "X-Plex-Language": "de",
        "Accept-Language": "de-DE,de;q=0.9",
        "Accept": "application/json",
    })
    day = datetime.now().strftime("%Y-%m-%d")
    fresh = {}
    failed = 0

    # Begrenzte Parallelität: deutlich schneller als 47 serielle Requests,
    # ohne den Plex-Cloudservice unnötig aggressiv abzufragen.
    workers = min(8, max(1, len(targets)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_plex_fetch_grid_channel, cid, grid, headers, day) for cid, grid in targets]
        for fut in as_completed(futures):
            cid, item, status = fut.result()
            if item:
                fresh[cid] = item
            else:
                failed += 1
                if status not in (200,):
                    log(f"[Plex EPG] Grid {cid.rsplit('-', 1)[-1]} -> HTTP {status}", xbmc.LOGWARNING)

    # Falls heute kurz vor Mitternacht nur 'now', aber kein 'next' vorhanden ist,
    # wird nur für diese wenigen Sender zusätzlich morgen geladen.
    need_tomorrow = [(cid, cloud.get(cid)) for cid, item in fresh.items() if item.get("now") and not item.get("next") and cloud.get(cid)]
    if need_tomorrow:
        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        with ThreadPoolExecutor(max_workers=min(4, len(need_tomorrow))) as pool:
            futures = [pool.submit(_plex_fetch_grid_channel, cid, grid, headers, tomorrow) for cid, grid in need_tomorrow]
            for fut in as_completed(futures):
                cid, item2, status = fut.result()
                if item2 and item2.get("next"):
                    fresh[cid]["next"] = item2.get("next")

    # Bei einzelnen Providerfehlern vorhandenen alten Sender-EPG behalten.
    merged = dict(stale)
    merged.update(fresh)
    write_json(cpath, {"ts": time.time(), "epg_map": merged})
    log(f"[Plex EPG] Jetzt/Danach geladen: {len(fresh)}/{len(targets)}" + (f" Fehler={failed}" if failed else ""))
    return merged


# ----------------------------------------------------------
# Plex-Login (offizieller PIN-Link-Flow ueber plex.tv/link)
# Kein Passwort läuft je durchs Addon - nur ein 4-stelliger Code.
# Wird fuer die Wiedergabe der Plex-DE-Sender benoetigt, da jede
# Stream-URL sessiongebunden signiert wird (kein anonymer Zugriff moeglich).
# ----------------------------------------------------------
PLEX_CLIENT_PRODUCT  = "Titan Smart TV Plus"
PLEX_CLIENT_DEVICE   = "Kodi"
PLEX_CLIENT_PLATFORM = "Kodi"


def _plex_auth_load():
    return read_json(PLEX_AUTH_FILE, {})


def _plex_auth_save(data):
    write_json(PLEX_AUTH_FILE, data)


def get_plex_client_id():
    """Persistente, zufaellige Geraete-ID fuer die Plex-API (einmalig erzeugt)."""
    data = _plex_auth_load()
    cid = data.get("client_id")
    if not cid:
        cid = str(uuid.uuid4())
        data["client_id"] = cid
        _plex_auth_save(data)
    return cid


def get_plex_token():
    return (_plex_auth_load().get("token") or "").strip()


def plex_is_logged_in():
    return bool(get_plex_token())


def plex_logout():
    data = _plex_auth_load()
    data.pop("token", None)
    _plex_auth_save(data)
    notify("Plex-Verknüpfung getrennt")


def _plex_headers(client_id, token=None):
    h = {
        "Accept": "application/json",
        "X-Plex-Product": PLEX_CLIENT_PRODUCT,
        "X-Plex-Device": PLEX_CLIENT_DEVICE,
        "X-Plex-Platform": PLEX_CLIENT_PLATFORM,
        "X-Plex-Client-Identifier": client_id,
    }
    if token:
        h["X-Plex-Token"] = token
    return h


def _plex_request_pin(client_id):
    """Fordert bei Plex einen 4-stelligen Link-Code an (offizieller PIN-Login)."""
    try:
        r = requests.post(
            "https://plex.tv/api/v2/pins",
            headers=_plex_headers(client_id),
            data={"strong": "false"},
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
        return data.get("id"), data.get("code")
    except Exception as e:
        log(f"[Plex Login] PIN-Anfrage fehlgeschlagen: {e}", xbmc.LOGERROR)
        return None, None


def _plex_poll_pin(pin_id, client_id):
    """Prueft, ob der Code auf plex.tv/link bestaetigt wurde."""
    try:
        r = requests.get(
            f"https://plex.tv/api/v2/pins/{pin_id}",
            headers=_plex_headers(client_id),
            timeout=15,
        )
        r.raise_for_status()
        return (r.json().get("authToken") or "").strip() or None
    except Exception as e:
        log(f"[Plex Login] PIN-Abfrage fehlgeschlagen: {e}", xbmc.LOGWARNING)
        return None


def plex_login_flow():
    """
    Startet den offiziellen Plex-Link-Flow und wartet (mit Abbrechen-Option),
    bis der Nutzer den Code auf plex.tv/link bestaetigt hat.
    Gibt True bei Erfolg zurueck.
    """
    client_id = get_plex_client_id()
    pin_id, code = _plex_request_pin(client_id)
    if not pin_id or not code:
        notify("Plex-Login konnte nicht gestartet werden (siehe Log)", True, 6000)
        return False

    dlg = xbmcgui.DialogProgress()
    dlg.create(
        "Plex-Konto verknüpfen",
        f"Öffne [B]plex.tv/link[/B] und gib diesen Code ein:\n"
        f"[COLOR gold][B]{code}[/B][/COLOR]\n"
        f"Warte auf Bestätigung (Abbrechen mit Zurück)",
    )
    token = None
    try:
        for i in range(60):  # ca. 5 Minuten (60 x 5s)
            if dlg.iscanceled():
                break
            dlg.update(int(i / 60 * 100))
            token = _plex_poll_pin(pin_id, client_id)
            if token:
                break
            xbmc.sleep(5000)
    finally:
        dlg.close()

    if token:
        data = _plex_auth_load()
        data["token"] = token
        data["client_id"] = client_id
        _plex_auth_save(data)
        notify("Plex erfolgreich verknüpft")
        return True

    notify("Plex-Login abgebrochen oder abgelaufen", True, 5000)
    return False


def plex_resolve_stream_url(part_url, channel_id=""):
    """Baut eine aktuelle Plex-Live-URL mit den normalen Plex-Clientparametern.

    Plex erwartet beim Live-Provider neben dem Konto-Token inzwischen auch
    Client-/Session-Metadaten. Diese Werte beschreiben nur diesen Kodi-Client;
    IP, Standort und die Regionspruefung von Plex werden nicht veraendert.
    """
    token = get_plex_token()
    if not token or not part_url:
        return None

    client_id = get_plex_client_id()
    session_id = str(uuid.uuid4())
    params = {
        "includeAllStreams": "1",
        "X-Plex-Product": PLEX_CLIENT_PRODUCT,
        "X-Plex-Client-Identifier": client_id,
        "X-Plex-Client-Platform": PLEX_CLIENT_PLATFORM,
        "X-Plex-Platform": PLEX_CLIENT_PLATFORM,
        "X-Plex-Device": PLEX_CLIENT_DEVICE,
        "X-Plex-Session-Id": session_id,
        "X-Plex-Token": token,
    }
    sep = "&" if "?" in part_url else "?"
    resolved = part_url + sep + urlencode(params)

    # Vor dem Uebergang an Kodi kurz pruefen, ob Plex das Manifest fuer den
    # angemeldeten Client akzeptiert. Token/volle URL werden nie geloggt.
    try:
        r = requests.get(
            resolved,
            headers={
                "User-Agent": UA,
                "Referer": "https://watch.plex.tv/",
                "Origin": "https://watch.plex.tv",
            },
            timeout=15,
            allow_redirects=True,
            stream=True,
        )
        status = r.status_code
        final_url = r.url or resolved
        r.close()
        log(f"[Plex Stream] Manifest-Test fuer {channel_id}: HTTP {status}")
        if status != 200:
            return None
        # Falls Plex auf eine aktuelle Provider-URL umleitet, genau diese an
        # Kodi weitergeben. Ansonsten bleibt die Part-URL erhalten.
        resolved = final_url
    except Exception as e:
        log(f"[Plex Stream] Manifest-Test fehlgeschlagen: {e}", xbmc.LOGWARNING)
        # Netzwerk-Probe darf Playback nicht grundlos verhindern; Kodi bekommt
        # die vollstaendige Provider-URL und versucht sie selbst.

    return resolved


def plex_now_playing_lookup(part_url, channel_name=""):
    """
    Ermittelt das aktuell laufende Programm eines Plex-DE-Senders OHNE
    Grid-Endpunkt: Die Live-HLS-Segmente selbst tragen eine eingebettete
    Episoden-ID im #EXTINF-Kommentar, z.B.
    "epid=68295854:epdur=2969739:ct=M:tag=content:...". Dazu wird kurz das
    Manifest abgerufen, die aktuelle epid (letztes "tag=content"-Segment,
    keine Werbung) extrahiert, und darueber die Titel-Metadaten via
    vod.provider.plex.tv/library/metadata/{epid} abgefragt - demselben
    Endpunkt, der fuer Plex VoD bereits bestaetigt funktioniert (inkl.
    X-Plex-Provider-Version 3.3.0).
    Gibt {"title":..., "plot":..., "epid":...} zurueck oder None.
    """
    stream_url = plex_resolve_stream_url(part_url, channel_name)
    if not stream_url:
        return None

    try:
        r = requests.get(stream_url, headers={"User-Agent": UA}, timeout=15)
        log(f"[Plex EPG2] GET Manifest für '{channel_name}' -> HTTP {r.status_code}")
        if r.status_code != 200:
            return None
        manifest = r.text
    except Exception as e:
        log(f"[Plex EPG2] Manifest-Abruf fehlgeschlagen: {e}", xbmc.LOGERROR)
        return None

    epid = None
    for line in reversed(manifest.splitlines()):
        if not line.startswith("#EXTINF"):
            continue
        if "tag=ad" in line or "tag=slate" in line:
            continue  # Werbe-/Standbild-Segment ueberspringen
        m = re.search(r"epid=(\d+)", line)
        if m:
            epid = m.group(1)
            break

    if not epid:
        log(f"[Plex EPG2] Keine epid im Manifest von '{channel_name}' gefunden", xbmc.LOGWARNING)
        return None

    data = _plex_vod_get(f"/library/metadata/{epid}")
    items = (data.get("MediaContainer") or {}).get("Metadata") or []
    if not items:
        log(f"[Plex EPG2] Keine Metadaten für epid={epid} gefunden", xbmc.LOGWARNING)
        return {"title": None, "plot": None, "epid": epid}

    item = items[0]
    title = item.get("title", "")
    show_title = item.get("grandparentTitle", "")
    full_title = f"{show_title}: {title}" if show_title and show_title != title else title
    return {"title": full_title, "plot": item.get("summary", ""), "epid": epid}


def view_plex_now_playing(part_url, name):
    """Kontextmenü-Aktion: zeigt 'Jetzt läuft' für einen Plex-Sender in einem Dialog."""
    part_url = unquote_plus(part_url)
    name = unquote_plus(name)

    busy = ProgressDialog(enabled=True)
    busy.open(f"Ermittle Programm für '{name}' …")
    result = plex_now_playing_lookup(part_url, name)
    busy.close()

    if not result or not result.get("title"):
        xbmcgui.Dialog().ok(name, "Konnte aktuelles Programm nicht ermitteln (siehe Kodi-Log, Tag \"[Plex EPG2]\").")
        return

    xbmcgui.Dialog().ok(name, result["title"], result.get("plot") or "")


def plex_vod_public_metadata(public_url):
    """
    Holt Genre, Regie, lokalisierte FSK und Gesamtbewertung von der
    OEFFENTLICHEN watch.plex.tv-Seite (Schema.org JSON-LD im HTML) - die
    interne API (vod.provider.plex.tv) liefert diese Felder in den
    Listen-Daten laut Kodi-Log nicht mit. Kein Token/Login noetig, da es
    sich um eine oeffentliche, fuer Suchmaschinen gedachte Seite handelt.
    Nur auf Abruf (Kontextmenü), nicht fuer ganze Listen.
    """
    if not public_url:
        return None
    if "/de/" not in public_url:
        public_url = public_url.replace("watch.plex.tv/", "watch.plex.tv/de/", 1)

    try:
        r = requests.get(public_url, headers={"User-Agent": UA, "Accept-Language": "de-DE"}, timeout=15)
        log(f"[Plex VoD] GET {public_url} (öffentliche Seite) -> HTTP {r.status_code}")
        if r.status_code != 200:
            return None
        html = r.text
    except Exception as e:
        log(f"[Plex VoD] Öffentliche-Seite-Abruf fehlgeschlagen: {e}", xbmc.LOGERROR)
        return None

    for m in re.finditer(r'<script type="application/ld\+json">(.*?)</script>', html, re.DOTALL):
        try:
            data = json.loads(m.group(1))
        except Exception:
            continue
        candidates = data if isinstance(data, list) else [data]
        for obj in candidates:
            if isinstance(obj, dict) and obj.get("@type") in ("Movie", "TVSeries", "TVSeason", "TVEpisode"):
                genres = obj.get("genre") or []
                if isinstance(genres, str):
                    genres = [genres]
                director_obj = obj.get("director")
                if isinstance(director_obj, list):
                    directors = [d.get("name", "") for d in director_obj if isinstance(d, dict) and d.get("name")]
                elif isinstance(director_obj, dict):
                    directors = [director_obj.get("name", "")] if director_obj.get("name") else []
                else:
                    directors = []
                agg = obj.get("aggregateRating") or {}
                return {
                    "genres": genres,
                    "directors": directors,
                    "rating": agg.get("ratingValue"),
                    "content_rating": obj.get("contentRating"),
                }
    log(f"[Plex VoD] Kein Movie/TVSeries-JSON-LD-Block in {public_url} gefunden", xbmc.LOGWARNING)
    return None


def view_plex_vod_more_info(public_url, name):
    """Kontextmenü-Aktion: zeigt Genre/Regie/FSK/Bewertung für einen VoD-Titel."""
    public_url = unquote_plus(public_url)
    name = unquote_plus(name)

    busy = ProgressDialog(enabled=True)
    busy.open(f"Lade Zusatzinfos für '{name}' …")
    meta = plex_vod_public_metadata(public_url)
    busy.close()

    if not meta:
        xbmcgui.Dialog().ok(name, "Konnte keine Zusatzinfos laden (siehe Kodi-Log, Tag \"[Plex VoD]\").")
        return

    lines = []
    if meta.get("genres"):
        lines.append("Genre: " + ", ".join(meta["genres"]))
    if meta.get("directors"):
        lines.append("Regie: " + ", ".join(meta["directors"]))
    if meta.get("content_rating"):
        lines.append("FSK: " + str(meta["content_rating"]))
    if meta.get("rating"):
        lines.append("Bewertung: " + str(meta["rating"]))

    xbmcgui.Dialog().ok(name, "\n".join(lines) if lines else "Keine Zusatzinfos verfügbar.")


def play_plex_channel(channel_id, name, plot="", part_url=""):
    """Wiedergabe eines Plex-DE-Senders: Login sicherstellen, URL zusammenbauen."""
    channel_id = unquote_plus(channel_id)
    part_url = unquote_plus(part_url)
    name = unquote_plus(name)
    plot = unquote_plus(plot) if plot else ""

    if not plex_is_logged_in():
        go = xbmcgui.Dialog().yesno(
            "Plex-Login erforderlich",
            "Für Plex Live TV wird ein kostenloses Plex-Konto benötigt.\n"
            "Noch kein Konto? Erstelle eines auf watch.plex.tv/de/\n"
            "Bereits registriert? Jetzt mit Plex verknüpfen?",
        )
        if not go or not plex_login_flow():
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

    stream_url = plex_resolve_stream_url(part_url, channel_id)
    if not stream_url:
        notify("Plex-Stream konnte nicht aufgelöst werden (siehe Kodi-Log)", True, 6000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    WIN.setProperty(RETURN_FROM_PLAY_FLAG, "1")
    extra = (
        f"&Referer={quote_plus('https://watch.plex.tv/')}"
        f"&Origin={quote_plus('https://watch.plex.tv')}"
    )
    playback_url = stream_url + f"|User-Agent={quote_plus(UA)}{extra}"

    li = xbmcgui.ListItem(name, path=playback_url)
    li.setProperty("IsPlayable", "true")
    # Den bereits in der Senderansicht erzeugten Jetzt/Naechste-EPG-Plot auch
    # an das Playback-ListItem uebergeben. Sonst ersetzt Kodi beim Start die
    # EPG-Information durch einen leeren/statischen Player-Plot.
    set_video_info(li, name, plot)

    li.setMimeType("application/vnd.apple.mpegurl")
    if kodi_has_addon("inputstream.ffmpegdirect"):
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
        li.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        li.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
        li.setProperty("inputstream.ffmpegdirect.playback_as_live", "true")
        li.setProperty("inputstream.ffmpegdirect.mime_type", "application/vnd.apple.mpegurl")
        li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
        li.setProperty("inputstream.ffmpegdirect.user_agent", UA)
    else:
        log("[Plex Live] FFmpeg Direct fehlt - native HLS-Wiedergabe")

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ----------------------------------------------------------
# Plex VoD (Plex's eigene kostenlose Filme & Serien - "Plex Movies & Shows",
# getrennt vom persönlichen Server, ebenfalls werbefinanziert/gratis).
# Nutzt denselben Konto-Login (PIN-Flow) wie Plex Live TV.
# Endpunkt-Host "vod.provider.plex.tv" folgt denselben Konventionen wie ein
# normaler Plex Media Server (Hubs, /library/metadata/, /children) - das ist
# durch eine tatsaechlich beobachtete Anfrage von web.plex.tv belegt, daher
# vergleichsweise sicher. ACHTUNG: anders als beim Live-TV-Fix ist das nicht
# an mehreren unabhaengigen Quellen gegengeprueft - falls etwas nicht auf
# Anhieb klappt, bitte Kodi-Debug-Log mit Tag "[Plex VoD]" schicken.
# ----------------------------------------------------------
PLEX_VOD_HOST = "https://vod.provider.plex.tv"


def _plex_vod_params(extra=None):
    token = get_plex_token()
    client_id = get_plex_client_id()
    p = {
        "X-Plex-Product": PLEX_CLIENT_PRODUCT,
        "X-Plex-Version": "4.43.4",
        "X-Plex-Client-Identifier": client_id,
        "X-Plex-Platform": PLEX_CLIENT_PLATFORM,
        "X-Plex-Device": PLEX_CLIENT_DEVICE,
        "X-Plex-Features": "external-media,indirect-media",
        "X-Plex-Provider-Version": "6.0.0",
        "X-Plex-Text-Format": "plain",
        "X-Plex-Language": "de",
        "X-Plex-Token": token,
    }
    if extra:
        p.update(extra)
    return p


def _plex_vod_get(path, extra_params=None):
    """GET gegen vod.provider.plex.tv, gibt geparstes JSON oder {} zurueck."""
    url = path if path.startswith("http") else f"{PLEX_VOD_HOST}{path}"
    try:
        r = requests.get(
            url,
            headers={"Accept": "application/json"},
            params=_plex_vod_params(extra_params),
            timeout=20,
        )
        log(f"[Plex VoD] GET {url} -> HTTP {r.status_code}")
        if r.status_code != 200:
            log(f"[Plex VoD] Fehlerantwort (gekürzt): {r.text[:800]}", xbmc.LOGWARNING)
            return {}
        return r.json()
    except Exception as e:
        log(f"[Plex VoD] Request fehlgeschlagen: {e}", xbmc.LOGERROR)
        return {}


def _plex_vod_get_paginated(path, base_params, page_size=100, max_items=500):
    """
    Wie _plex_vod_get, aber holt bei Bedarf mehrere Seiten nach (die API
    liefert pro Anfrage nur 'page_size' Elemente plus 'totalSize' in der
    Antwort). Ohne das wurden bei grossen Genres/Kollektionen (z.B. "Action")
    nur die ersten 100 Titel angezeigt, obwohl die Plex-Webseite deutlich
    mehr listet - das war der Grund, warum einzelne Filme im Addon fehlten.
    Bricht bei max_items ab, um die Ladezeit nicht ausufern zu lassen.
    """
    all_items = []
    start = 0
    total = None
    while True:
        params = dict(base_params, **{"X-Plex-Container-Start": start, "X-Plex-Container-Size": page_size})
        data = _plex_vod_get(path, params)
        container = data.get("MediaContainer") or {}
        items = container.get("Metadata") or []
        if total is None:
            total = container.get("totalSize") or container.get("size") or len(items)
        all_items.extend(items)
        start += page_size
        if not items or len(all_items) >= total or len(all_items) >= max_items:
            break
    return all_items


def plex_vod_fetch_hub(section, hub="popular", force=False):
    """
    Laedt eine Hub-Liste (z.B. 'trending') fuer eine Sektion und cached sie
    (Intervall 12 Stunden; unabhaengig vom Live-EPG, da diese
    Listen sich aehnlich haeufig aendern wie EPG-Daten).

    Manche 'hub'-Werte sind in Wirklichkeit Genre-Tags (z.B. aus dem
    Genres-Menü), die als Hub-Name nicht existieren (siehe Kodi-Log: nur
    7 von 14 Kategorie-Slugs trafen direkt einen echten Hub). Liefert der
    direkte Hub-Aufruf nichts, wird deshalb automatisch die gefilterte
    Bibliotheksliste (Standard-Plex-Muster /all?genre=) als Fallback
    versucht. Beide Zweige paginieren jetzt bis zu 500 Titel nach, statt
    starr bei den ersten 100 abzuschneiden.
    """
    cpath = cache_path("plexvod", f"{section}_{hub}")
    cache_sec = 12 * 60 * 60
    if not force and xbmcvfs.exists(cpath):
        cached = read_json(cpath, {})
        if cached.get("ts") and (time.time() - cached["ts"]) <= cache_sec:
            return cached.get("items") or []

    items = _plex_vod_get_paginated(
        f"/hubs/sections/{section}/{hub}",
        {"contentDirectoryID": section},
    )

    if not items:
        log(f"[Plex VoD] Hub '{hub}' lieferte nichts - versuche Genre-Fallback "
            f"/library/sections/{section}/all?genre={hub}")
        items = _plex_vod_get_paginated(
            f"/library/sections/{section}/all",
            {"genre": hub, "contentDirectoryID": section},
        )
        if not items:
            log(f"[Plex VoD] Genre-Fallback für '{hub}' ebenfalls leer", xbmc.LOGWARNING)

    if items:
        write_json_compact(cpath, {"ts": time.time(), "items": items})
    return items


def _plex_vod_has_german_audio_in_item(item):
    """True, wenn Plex in den Media/Part/Stream-Daten eine deutsche Tonspur meldet."""
    german_codes = {"de", "deu", "ger", "de-de", "de_at", "de-at", "de_ch", "de-ch"}
    german_names = {"deutsch", "german", "deutschland"}
    for media in item.get("Media") or []:
        for part in media.get("Part") or []:
            for stream in part.get("Stream") or []:
                # Plex: streamType 2 = Audio. Fehlt streamType, pruefen wir nur
                # explizite Sprachfelder und vermeiden Titel-/Plot-Heuristiken.
                st = stream.get("streamType")
                if st not in (None, 2, "2"):
                    continue
                vals = [stream.get("languageCode"), stream.get("language"),
                        stream.get("extendedDisplayTitle"), stream.get("displayTitle")]
                for val in vals:
                    v = str(val or "").strip().lower()
                    if v in german_codes or v in german_names or "deutsch" in v or "german" in v:
                        return True
    return False


def _plex_vod_is_german(item):
    """
    Prueft die tatsaechlich von Plex gemeldeten Audio-Spuren. Bei Serien wird
    notfalls eine Episode als Stichprobe geprueft. Ergebnis wird gecached,
    damit Hub-/Genre-Listen nach dem ersten Aufruf deutlich schneller sind.
    """
    if _plex_vod_has_german_audio_in_item(item):
        return True
    key = str(item.get("ratingKey") or "")
    if not key:
        return False
    cpath = cache_path("plexvodlang", key)
    cached = read_json(cpath, {}) if xbmcvfs.exists(cpath) else {}
    if "de" in cached:
        return bool(cached.get("de"))

    data = _plex_vod_get(f"/library/metadata/{key}", {"includeAllStreams": 1})
    details = (data.get("MediaContainer") or {}).get("Metadata") or []
    is_de = any(_plex_vod_has_german_audio_in_item(x) for x in details)

    # Shows tragen auf Serienebene oft keine Streams. Dann erste verfuegbare
    # Episode pruefen (Serie -> Staffel -> Episode).
    item_type = item.get("type") or (details[0].get("type") if details else "")
    if not is_de and item_type == "show":
        seasons = plex_vod_fetch_children(key)
        for season in seasons[:3]:
            skey = season.get("ratingKey")
            if not skey:
                continue
            episodes = plex_vod_fetch_children(skey)
            if episodes:
                ep = episodes[0]
                edata = _plex_vod_get(f"/library/metadata/{ep.get('ratingKey')}", {"includeAllStreams": 1})
                eitems = (edata.get("MediaContainer") or {}).get("Metadata") or []
                is_de = any(_plex_vod_has_german_audio_in_item(x) for x in eitems)
                break

    write_json_compact(cpath, {"de": bool(is_de), "ts": time.time()})
    return bool(is_de)


def _plex_vod_filter_german(items, progress=None):
    if ADDON.getSetting("plex_vod_german_only") == "false":
        return items
    out = []
    total = len(items) or 1
    for i, item in enumerate(items):
        if progress and i % 5 == 0:
            progress.update(min(75, 40 + int(35 * i / total)), "Prüfe deutsche Tonspur …")
        if _plex_vod_is_german(item):
            out.append(item)
    log(f"[Plex VoD] Deutschfilter aktiv: {len(out)} von {len(items)} Titeln")
    return out


def plex_vod_fetch_children(rating_key):
    """Laedt Kind-Elemente eines Metadaten-Eintrags (Serie->Staffeln, Staffel->Episoden)."""
    data = _plex_vod_get(f"/library/metadata/{rating_key}/children")
    return (data.get("MediaContainer") or {}).get("Metadata") or []


def plex_vod_resolve_playable(rating_key):
    """
    Loest die abspielbare Datei-URL fuer ein Film-/Episoden-Item auf
    (Media[0].Part[0].key + Konto-Token).
    """
    data = _plex_vod_get(f"/library/metadata/{rating_key}")
    items = (data.get("MediaContainer") or {}).get("Metadata") or []
    if not items:
        return None
    media = items[0].get("Media") or []
    if not media:
        return None
    parts = media[0].get("Part") or []
    if not parts:
        return None
    part_key = parts[0].get("key", "")
    if not part_key:
        return None
    token = get_plex_token()
    sep = "&" if "?" in part_key else "?"
    return f"{PLEX_VOD_HOST}{part_key}{sep}X-Plex-Token={quote_plus(token)}"


def _plex_vod_ensure_login():
    if plex_is_logged_in():
        return True
    go = xbmcgui.Dialog().yesno(
        "Plex-Login erforderlich",
        "Für Plex VoD (Filme & Serien) wird ein kostenloses Plex-Konto benötigt.\n\n"
        "Jetzt verknüpfen?",
    )
    if not go:
        return False
    return plex_login_flow()


def _plex_vod_thumb(item, field="thumb"):
    url = item.get(field, "")
    if not url:
        return ""
    if url.startswith("http"):
        return url
    token = get_plex_token()
    sep = "&" if "?" in url else "?"
    return f"{PLEX_VOD_HOST}{url}{sep}X-Plex-Token={quote_plus(token)}"


def _plex_vod_art(item):
    """
    Baut ein vollstaendiges Kodi-Art-Dict aus dem typisierten "Image"-Array,
    das Plex VoD-Items mitliefern (coverPoster/background/clearLogo/banner/
    snapshot - siehe Kodi-Log). Deutlich hochwertiger als die einfachen
    thumb/art-Felder. Faellt pro Feld auf thumb/art zurueck, falls das
    Image-Array etwas nicht enthaelt.
    """
    by_type = {}
    for img in (item.get("Image") or []):
        t = img.get("type", "")
        u = img.get("url", "")
        if t and u:
            by_type[t] = u

    poster = by_type.get("coverPoster") or _plex_vod_thumb(item, "thumb")
    fanart = by_type.get("background") or _plex_vod_thumb(item, "art") or poster
    clearlogo = by_type.get("clearLogo") or by_type.get("clearLogoWide") or ""
    banner = by_type.get("banner") or ""
    landscape = by_type.get("snapshot") or by_type.get("backgroundSquare") or fanart

    art = {
        "thumb": poster,
        "poster": poster,
        "icon": poster,
        "fanart": fanart,
        "landscape": landscape,
    }
    if clearlogo:
        art["clearlogo"] = clearlogo
    if banner:
        art["banner"] = banner
    return art


PLEX_VOD_CATEGORIES = [
    ("Action", "action"),
    ("Animation", "animation"),
    ("Comedy", "comedy"),
    ("Krimi", "crime"),
    ("Dokumentation", "documentary"),
    ("Drama", "drama"),
    ("En Español", "en-espanol"),
    ("Horror", "horror"),
    ("Musik", "musical"),
    ("Liebesfilm", "romance"),
    ("Sci-Fi", "sci-fi"),
    ("Thriller", "thriller"),
    ("Western", "western"),
    ("Audio-Deskription", "descriptive-audio"),
]


PLEX_VOD_COLLECTIONS = [
    ("Plex Picks", "plex-picks-gas"),
    ("Summer Lovin'", "summer-lovin-excerpt"),
    ("Binge-Worthy Shows", "binge-worthy-shows"),
    ("Moviedome Hits", "moviedome"),
    ("Quests, Sagas & Dragons", "quests-sagas-and-dragons"),
    ("Indie-Festival-Favoriten", "indies-festival-favorites"),
    ("Anime", "anime"),
    ("Best of the West", "best-of-the-west-excerpt"),
    ("Shark Reek", "shark-reek"),
    ("True Crime Time", "true-crime"),
    ("Comedy Gold", "comedy-gold"),
    ("Christmas In July", "christmas-in-july-excerpt"),
    ("That's So Nineties", "thats-so-nineties"),
    ("Charles Bronson", "charles-bronson"),
    ("Based on a True Story", "based-on-a-true-story"),
    ("Crime Time", "crime-time"),
    ("Kriegsfilme", "war-films"),
    ("Til Death Do Us", "til-death-do-us"),
    ("Totally Eighties", "totally-eighties"),
    ("Beliebte Telenovelas", "popular-telenovelas"),
    ("Creator TV", "creator-tv"),
    ("Reality TV", "reality-tv"),
    ("Masters of Food", "masters-of-food"),
    ("Take Me To Your Leader", "take-me-to-your-leader"),
    ("Mitternachtsfilme", "midnight-movies"),
    ("Fuel Your Wanderlust", "fuel-your-wanderlust"),
    ("Zombies", "zombies"),
    ("Slasher Horror", "slasher-horror"),
    ("Screen Legends", "screen-legends"),
    ("We Are Proud", "we-are-proud"),
    ("Most Woof-Listed", "most-woof-listed"),
    ("Hitchcock", "hitchcock"),
    ("Action Sheroes", "action-sheroes"),
    ("Reel Mockbusters", "reel-mockbusters"),
    ("Blood Drive", "blood-drive"),
    ("Sci-Fi (Serien)", "sci-fi_tv"),
    ("Krimi (Serien)", "crime_tv"),
    ("Hot Docs", "hot-docs"),
    ("Family Fun Night", "family-fun-night"),
    ("Fight Club", "fight-club"),
    ("Sportartikel", "sporting-goods"),
    ("Once Upon A Time In Hong Kong", "once-upon-a-time-in-hong-kong"),
    ("Backstage Pass", "backstage-pass"),
    ("Buchclub", "book-club"),
]


def view_plex_vod_main():
    """
    Plex-VoD-Hauptmenü. Laut Kodi-Log gibt es KEINE getrennte 'movies'/'tv'-
    Sektion - Filme UND Serien liegen gemeinsam unter der Sektion 'movies'
    (z.B. liegt der Hub "Binge-Worthy Shows" unter
    /hubs/sections/movies/binge-worthy-shows). Einzelne Items unterscheiden
    sich nur ueber ihr "type"-Feld (movie/show), das view_plex_vod_hub()
    bereits auswertet. "popular" war kein gueltiger Hub-Name - die echten
    Hub-IDs sind trending/recommended/recentlyAdded/expiring etc.
    """
    if not _plex_vod_ensure_login():
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
        return

    plex_icon = get_menu_icon("plex")
    items = [
        ("  Populär in Deutschland", "plex_vod_hub",       {"section": "movies", "hub": "trending"}),
        ("  Empfohlen für dich",     "plex_vod_hub",       {"section": "movies", "hub": "recommended"}),
        ("  Kürzlich hinzugefügt",   "plex_vod_hub",       {"section": "movies", "hub": "recentlyAdded"}),
        ("  Nur noch kurze Zeit",    "plex_vod_hub",       {"section": "movies", "hub": "expiring"}),
        ("  Genres",                 "plex_vod_genres",      {}),
        ("  Kollektionen",           "plex_vod_collections", {}),
    ]
    for label, action, kwargs in items:
        url = build_url({"action": action, **kwargs})
        li = xbmcgui.ListItem(colorize(label, COLOR_GROUP))
        li.setArt({"icon": plex_icon, "thumb": plex_icon, "fanart": plex_icon})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)


def view_plex_vod_collections():
    """Kuratierte Themen-Kollektionen (bestätigte Hub-Slugs von watch.plex.tv)."""
    if not _plex_vod_ensure_login():
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
        return

    plex_icon = get_menu_icon("plex")
    for label, slug in PLEX_VOD_COLLECTIONS:
        url = build_url({"action": "plex_vod_hub", "section": "movies", "hub": slug})
        li = xbmcgui.ListItem(colorize(label, COLOR_GROUP))
        li.setArt({"icon": plex_icon, "thumb": plex_icon, "fanart": plex_icon})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)


def view_plex_vod_genres():
    """
    Genre-Liste (Kategorien von watch.plex.tv/de/on-demand/category/{slug}).
    EXPERIMENTELL: geht davon aus, dass Kategorie-Slugs wie "action" genauso
    als Hub-ID unter /hubs/sections/movies/{slug} funktionieren wie die
    bereits bestaetigten Hubs (trending, recommended, ...). Falls ein Genre
    beim Oeffnen leer bleibt oder einen Fehler wirft, steht das im Log unter
    "[Plex VoD]" - dann braucht dieses Genre vermutlich einen anderen
    Endpunkt (z.B. /library/sections/movies/all?genre=... statt /hubs/...).
    """
    if not _plex_vod_ensure_login():
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
        return

    plex_icon = get_menu_icon("plex")
    for label, slug in PLEX_VOD_CATEGORIES:
        url = build_url({"action": "plex_vod_hub", "section": "movies", "hub": slug})
        li = xbmcgui.ListItem(colorize(label, COLOR_GROUP))
        li.setArt({"icon": plex_icon, "thumb": plex_icon, "fanart": plex_icon})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)


def _plex_pick_rating(item):
    """
    Plex liefert oft mehrere Bewertungsquellen (IMDb, Rotten Tomatoes,
    TMDB) als "Rating"-Array mit "value"/"type"-Feldern statt eines
    einzelnen Skalars (siehe watch.plex.tv-Detailseite: mehrere Badges
    gleichzeitig). Bevorzugt "audience"-Typ, sonst den ersten Treffer.
    Faellt auf die einfachen "rating"/"audienceRating"-Felder zurueck,
    falls kein Array vorhanden ist.
    """
    ratings = item.get("Rating") or []
    if ratings:
        for r in ratings:
            if (r.get("type") or "").lower() == "audience" and r.get("value"):
                return r.get("value")
        for r in ratings:
            if r.get("value"):
                return r.get("value")
    return item.get("audienceRating") or item.get("rating")


def view_plex_vod_hub(section, hub):
    """Zeigt eine Hub-Liste (Filme oder Serien) an."""
    if not _plex_vod_ensure_login():
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
        return

    p = ProgressDialog(enabled=True)
    p.open("Lade Plex VoD …")
    try:
        p.update(40, "Lade Titel …")
        items = plex_vod_fetch_hub(section, hub)
        items = _plex_vod_filter_german(items, p)
        if not items:
            notify("Keine Plex VoD-Titel gefunden (siehe Log)", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(80, "Baue Menü …")
        for idx, item in enumerate(items):
            if idx == 0:
                log(f"[Plex VoD] Beispiel-Item-Rohdaten (gekürzt): {json.dumps(item, ensure_ascii=False)[:4000]}")
            rating_key = item.get("ratingKey", "")
            title = item.get("title", "")
            if not rating_key or not title:
                continue
            plot = item.get("summary", "")
            tagline = item.get("tagline", "")
            year = item.get("year", "")
            art = _plex_vod_art(item)
            item_type = item.get("type", "")  # "movie" oder "show"

            duration_ms = item.get("duration") or 0
            content_rating = item.get("contentRating", "")
            audience_rating = _plex_pick_rating(item)
            studio = item.get("studio", "")

            li = xbmcgui.ListItem(f"{title} ({year})" if year else title)

            # Klassische Info-API zuerst (extrem breit kompatibel über alle
            # Kodi-Versionen/Skins hinweg) - falls die neuere InfoTag-API
            # darunter aus irgendeinem Grund nichts anzeigt, greift das hier
            # trotzdem.
            info = {"title": title, "mediatype": "movie" if item_type == "movie" else "tvshow"}
            if plot:
                info["plot"] = plot
                info["plotoutline"] = plot
            if tagline:
                info["tagline"] = tagline
            if year:
                info["year"] = int(year)
            if duration_ms:
                info["duration"] = int(duration_ms) // 60000  # setInfo erwartet Minuten
            if content_rating:
                info["mpaa"] = content_rating
            if studio:
                info["studio"] = studio
            if audience_rating:
                info["rating"] = float(audience_rating)
            li.setInfo("video", info)

            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(title)
                if plot:
                    tag.setPlot(plot)
                if tagline:
                    tag.setTagLine(tagline)
                if year:
                    tag.setYear(int(year))
                if duration_ms:
                    tag.setDuration(int(duration_ms) // 1000)
                if content_rating:
                    tag.setMpaa(content_rating)
                if audience_rating:
                    tag.setRating(float(audience_rating))
                if studio:
                    tag.setStudios([studio])
            except Exception as e:
                log(f"[Plex VoD] InfoTag-Fehler bei '{title}': {e}", xbmc.LOGWARNING)
            li.setArt(art)

            public_url = item.get("publicPagesURL", "")
            if public_url:
                info_cm_url = build_url({"action": "plex_vod_more_info",
                                         "public_url": quote_plus(public_url),
                                         "name": quote_plus(title)})
                li.addContextMenuItems([("ℹ Genre/Regie/FSK anzeigen", "RunPlugin(%s)" % info_cm_url)])

            if item_type == "movie":
                li.setProperty("IsPlayable", "true")
                play_url = build_url({
                    "action": "plex_vod_play",
                    "rating_key": quote_plus(rating_key),
                    "name": quote_plus(title),
                    "plot": quote_plus(plot),
                })
                dl_url = build_url({"action":"plex_vod_download","rating_key":quote_plus(rating_key),"name":quote_plus(title),"plot":quote_plus(plot),"poster":quote_plus(art.get("poster", "")),"fanart":quote_plus(art.get("fanart", "")),"media_type":"movie"})
                li.addContextMenuItems([("Download", "RunPlugin(%s)" % dl_url)])
                xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)
            else:
                children_url = build_url({
                    "action": "plex_vod_children",
                    "rating_key": quote_plus(rating_key),
                    "name": quote_plus(title),
                    "level": "season",
                    "show_title": quote_plus(title),
                })
                xbmcplugin.addDirectoryItem(HANDLE, children_url, li, isFolder=True)

        xbmcplugin.setContent(HANDLE, "movies" if section == "movies" else "tvshows")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_plex_vod_children(rating_key, name, level, show_title="", season=""):
    """
    Zeigt Staffeln (level='season') oder Episoden (level='episode') einer Serie.
    """
    show_title = unquote_plus(show_title) if show_title else ""
    season = unquote_plus(str(season)) if season else ""
    p = ProgressDialog(enabled=True)
    p.open(f"Lade '{name}' …")
    try:
        p.update(40, "Lade Inhalte …")
        items = plex_vod_fetch_children(rating_key)
        if not items:
            notify("Keine Inhalte gefunden", True, 5000)
            xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
            return

        p.update(80, "Baue Menü …")
        for item in items:
            child_key = item.get("ratingKey", "")
            title = item.get("title", "")
            if not child_key or not title:
                continue
            plot = item.get("summary", "")
            art = _plex_vod_art(item)

            li = xbmcgui.ListItem(title)

            info = {"title": title, "mediatype": "season" if level == "season" else "episode"}
            if plot:
                info["plot"] = plot
            idx = item.get("index")
            if idx is not None:
                if level == "season":
                    info["season"] = int(idx)
                else:
                    info["episode"] = int(idx)
            li.setInfo("video", info)

            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(title)
                if plot:
                    tag.setPlot(plot)
                if idx is not None:
                    if level == "season":
                        tag.setSeason(int(idx))
                    else:
                        tag.setEpisode(int(idx))
            except Exception as e:
                log(f"[Plex VoD] InfoTag-Fehler bei '{title}': {e}", xbmc.LOGWARNING)
            li.setArt(art)

            if level == "season":
                next_url = build_url({
                    "action": "plex_vod_children",
                    "rating_key": quote_plus(child_key),
                    "name": quote_plus(title),
                    "level": "episode",
                    "show_title": quote_plus(show_title or name),
                    "season": str(idx if idx is not None else season or ""),
                })
                xbmcplugin.addDirectoryItem(HANDLE, next_url, li, isFolder=True)
            else:
                li.setProperty("IsPlayable", "true")
                play_url = build_url({
                    "action": "plex_vod_play",
                    "rating_key": quote_plus(child_key),
                    "name": quote_plus(title),
                    "plot": quote_plus(plot),
                })
                dl_url = build_url({"action":"plex_vod_download","rating_key":quote_plus(child_key),"name":quote_plus(title),"plot":quote_plus(plot),"poster":quote_plus(art.get("poster", "")),"fanart":quote_plus(art.get("fanart", "")),"show_title":quote_plus(show_title),"season":str(season or ""),"episode":str(idx if idx is not None else ""),"media_type":"episode"})
                li.addContextMenuItems([("Download", "RunPlugin(%s)" % dl_url)])
                xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)

        xbmcplugin.setContent(HANDLE, "episodes" if level == "episode" else "seasons")
        xbmcplugin.endOfDirectory(HANDLE, True, cacheToDisc=False)
    finally:
        p.close()


def view_plex_vod_download(rating_key, name, plot="", poster="", fanart="", show_title="", season="", episode="", media_type="movie"):
    """Laedt die von Plex fuer das VoD-Item gelieferte Mediendatei direkt herunter."""
    rating_key=unquote_plus(rating_key); name=unquote_plus(name)
    plot=unquote_plus(plot) if plot else ""; poster=unquote_plus(poster) if poster else ""; fanart=unquote_plus(fanart) if fanart else ""; show_title=unquote_plus(show_title) if show_title else ""
    if not _plex_vod_ensure_login(): return
    # Metadaten beim Download nochmals direkt von Plex laden. So bleibt die lokale
    # Bibliothek vollstaendig, auch wenn die aufrufende Liste nur Basisdaten hatte.
    extra={}
    try:
        data=_plex_vod_get(f"/library/metadata/{rating_key}")
        details=(data.get("MediaContainer") or {}).get("Metadata") or []
        if details:
            d=details[0]
            plot=d.get("summary") or plot
            art=_plex_vod_art(d)
            poster=art.get("poster") or poster; fanart=art.get("fanart") or fanart
            genres=[g.get("tag") for g in (d.get("Genre") or []) if isinstance(g,dict) and g.get("tag")]
            extra={
                "year": d.get("year") or "", "genre": genres, "studio": d.get("studio") or "",
                "mpaa": d.get("contentRating") or "", "tagline": d.get("tagline") or "",
                "rating": _plex_pick_rating(d) or "", "duration": int((d.get("duration") or 0)/1000) if d.get("duration") else 0
            }
            if media_type=="episode":
                show_title=d.get("grandparentTitle") or show_title
                season=d.get("parentIndex") if d.get("parentIndex") is not None else season
                episode=d.get("index") if d.get("index") is not None else episode
    except Exception as exc:
        log("[Plex Download] Metadaten-Nachladen fehlgeschlagen: %s" % exc, xbmc.LOGWARNING)
    base=_rktv_download_path()
    if not base: return
    root=_vod_download_root(base)+"Plex VoD/"; xbmcvfs.mkdirs(root)
    if media_type == "episode" and show_title:
        folder=root+"Serien/"+_rktv_safe_filename(show_title)+"/Staffel %02d/" % int(season or 0)+("S%02dE%02d - %s/" % (int(season or 0),int(episode or 0),_rktv_safe_filename(name)))
    elif media_type == "movie": folder=root+"Filme/"+_rktv_safe_filename(name)+"/"
    else: folder=root+_rktv_safe_filename(name)+"/"
    xbmcvfs.mkdirs(folder)
    xbmcgui.Dialog().notification("Plex Download", "Download %s gestartet" % name, xbmcgui.NOTIFICATION_INFO, 4000)
    started_at=time.time(); downloaded=0; total=0
    _download_status_write("Plex", name, 0, 0, "running", False, started_at)
    try:
        stream=plex_vod_resolve_playable(rating_key)
        if not stream: raise Exception("Stream konnte nicht aufgeloest werden")
        r=requests.get(stream,stream=True,timeout=30); r.raise_for_status()
        ctype=(r.headers.get("content-type") or "").lower()
        try: total=int(r.headers.get("content-length") or 0)
        except Exception: total=0
        _download_status_write("Plex", name, downloaded, total, "running", False, started_at)
        ext=".mp4" if "mp4" in ctype else ".mkv" if "matroska" in ctype else ".mp4"
        out=folder+"video"+ext
        f=xbmcvfs.File(out,"wb")
        try:
            for chunk in r.iter_content(1024*1024):
                if xbmc.Monitor().abortRequested(): raise Exception("Download abgebrochen")
                if chunk:
                    f.write(chunk); downloaded += len(chunk)
                    _download_status_write("Plex", name, downloaded, total, "running", False, started_at)
        finally: f.close()
        meta={"provider":"Plex","title":name,"plot":plot,"poster":poster,"fanart":fanart,"show_title":show_title,"season":season,"episode":episode,"media_type":media_type,"media_file":"video"+ext,"rating_key":rating_key,"completed_at":time.time()}
        meta.update(extra)
        write_json(folder+"download.json", meta)
        _download_status_write("Plex", name, downloaded, downloaded, "done", False, started_at)
        log("[Plex Download] Fertig: %s" % out)
        xbmcgui.Dialog().notification("Plex Download", "Download %s erledigt" % name, xbmcgui.NOTIFICATION_INFO, 7000)
    except Exception as exc:
        _download_status_write("Plex", name, downloaded, total, "error", False, started_at, str(exc))
        log("[Plex Download] Fehler: %s" % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Plex Download", "Download %s fehlgeschlagen" % name, xbmcgui.NOTIFICATION_ERROR, 7000)


def view_plex_vod_play(rating_key, name, plot=""):
    rating_key = unquote_plus(rating_key)
    name = unquote_plus(name)
    plot = unquote_plus(plot) if plot else ""

    if not _plex_vod_ensure_login():
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    stream_url = plex_vod_resolve_playable(rating_key)
    if not stream_url:
        notify("Plex-VoD-Stream konnte nicht aufgelöst werden (siehe Kodi-Log)", True, 6000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    WIN.setProperty(RETURN_FROM_PLAY_FLAG, "1")
    li = xbmcgui.ListItem(name, path=stream_url)
    li.setProperty("IsPlayable", "true")
    set_video_info(li, name, plot)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


