# SPDX-License-Identifier: GPL-3.0-or-later
"""Einheitliche Formatierung fuer alle Datei-Fortschrittsdialoge im
gesamten Addon (lokales Kopieren/Herunterladen eines Builds, Extraktion,
Backup-Erstellung, Cloud-Up-/Download zu Dropbox/Google Drive/WebDAV) -
ein gemeinsamer Aufbau statt der zuvor vier unabhaengig gewachsenen
Varianten in builds.py, buildbackup.py und dropbox_auth.py (von
google_drive_provider.py/webdav_provider.py per Provider-Namens-Ersetzung
mitgenutzt).

Einheitlicher Aufbau (3 Zeilen):
    <Label>
    <gekuerzter Datei-/Pfadname>
    <Groesse> [ - ETA: <Restzeit>]
"""
import time

ETA_SEPARATOR = '   \u2022   '  # '   •   '


def format_size(num_bytes):
    """z.B. 512 -> '512.0 B', 1536000 -> '1.5 MB'."""
    num_bytes = float(num_bytes)
    for unit in ('B', 'KB', 'MB', 'GB'):
        if num_bytes < 1024.0:
            return '%.1f %s' % (num_bytes, unit)
        num_bytes /= 1024.0
    return '%.1f TB' % num_bytes


def format_eta(seconds):
    """z.B. 16 -> '0:16', 4000 -> '1:06:40'."""
    if seconds is None or seconds < 0:
        return ''
    seconds = int(seconds)
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h > 0:
        return '{}:{:02d}:{:02d}'.format(h, m, s)
    return '{}:{:02d}'.format(m, s)


def truncate_path(path, max_len=48):
    """Kuerzt einen Dateipfad/-namen auf eine feste Maximallaenge, damit
    Kodis natives DialogProgress-Fenster die Zeile NIE umbricht - egal wie
    tief der Pfad verschachtelt ist. Verhindert, dass der gesamte
    Dialoginhalt (Prozentzahl, ETA, Abbrechen-Button) je nach Dateiname
    sichtbar hoch/runter springt."""
    if len(path) <= max_len:
        return path
    return '\u2026/' + path[-(max_len - 2):]


def status_text(label, filename, done, total, started_at, eta_text_format):
    """Baut den einheitlichen 3-zeiligen Fortschrittstext.

    started_at: time.monotonic()-Zeitstempel vom Start des Vorgangs.
    eta_text_format: lokalisierter Format-String mit einem '{}' fuer die
    Restzeit (z.B. strings.po #32109, deutsch 'ETA: {}'). Ohne genuegend
    Datenpunkte (noch nichts uebertragen, Gesamtgroesse unbekannt, unter
    1s vergangen) wird die ETA schlicht weggelassen statt eines
    Platzhaltertexts - konsistent mit dem bisherigen buildbackup.py-Stil.
    """
    total = max(int(total or 0), 0)
    done = max(int(done or 0), 0)
    if total:
        done = min(done, total)
    elapsed = max(time.monotonic() - started_at, 0.001)

    eta_str = ''
    if total and 0 < done < total and elapsed > 1.0:
        rate = done / elapsed
        if rate > 0:
            eta_str = format_eta((total - done) / rate)

    size_line = '{} / {}'.format(format_size(done), format_size(total)) if total else format_size(done)
    if eta_str:
        size_line += ETA_SEPARATOR + eta_text_format.format(eta_str)

    return '{}\n{}\n{}'.format(label, truncate_path(filename), size_line)
