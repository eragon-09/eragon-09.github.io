# SPDX-License-Identifier: GPL-3.0-or-later
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.modules import control, maintenance, navigation, whitelist
from resources.lib.modules.backtothefuture import PY2

if PY2:
    translatePath = xbmc.translatePath
    from urlparse import parse_qsl
else:
    translatePath = xbmcvfs.translatePath
    from urllib.parse import parse_qsl

AddonID = 'script.buildguard'
selfAddon = xbmcaddon.Addon(id=AddonID)
AddonTitle = 'BuildGuard'


def _(string_id):
    return selfAddon.getLocalizedString(string_id)


ADDON_FANART = control.addonFanart()
ADDON_ICON = control.addonIcon()
HOME = translatePath('special://home/')
EXCLUDES = [
    AddonID,
    'backupdir',
    'backup.zip',
    'packages',
    'script.module.requests',
    'script.module.urllib3',
    'script.module.chardet',
    'script.module.idna',
    'script.module.certifi',
    'script.module.dropbox',
    'script.module.pyqrcode',
]

dialog = xbmcgui.Dialog()
progressDialog = xbmcgui.DialogProgress()


def FRESHSTART(mode='verbose'):
    if mode != 'silent': select = xbmcgui.Dialog().yesno(AddonTitle, _(32017) + '\n' + _(32018), yeslabel=_(32124), nolabel=_(32125))
    else: select = 1
    if select == 0: return False
    elif select == 1:

        # Waehrend eines Build-Installs (mode='silent', aufgerufen aus
        # builds.install_build()) zusaetzlich die vom Nutzer gepflegte
        # Whitelist beruecksichtigen - beim rein manuellen "Fresh Start"
        # aus dem Menue (mode='verbose') bewusst nicht, da dort ohnehin
        # ausdruecklich "alles zuruecksetzen" gewuenscht ist.
        active_excludes = whitelist.apply_whitelist(EXCLUDES) if mode == 'silent' else EXCLUDES

        progressDialog.create(AddonTitle, _(32132) + '\n' + _(32129))
        try:
            for root, dirs, files in os.walk(HOME,topdown=True):
                dirs[:] = [d for d in dirs if d not in active_excludes]
                for name in files:
                    try:
                        os.remove(os.path.join(root,name))
                        os.rmdir(os.path.join(root,name))
                    except: pass

                for name in dirs:
                    try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                    except: pass
        except: pass
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    if mode != 'silent': dialog.ok(AddonTitle, _(32016))


    if mode != 'silent': xbmc.executebuiltin('LoadProfile(Master user)')
    return True

def REMOVE_EMPTY_FOLDERS():
#initialize the counters
    print('########### Start Removing Empty Folders #########')
    empty_count = 0
    used_count = 0
    for curdir, subdirs, files in os.walk(HOME):
        try:
            if len(subdirs) == 0 and len(files) == 0: #check for empty directories. len(files) == 0 may be overkill
                empty_count += 1 #increment empty_count
                os.rmdir(curdir) #delete the directory
                print('successfully removed: ' + curdir)
            elif len(subdirs) > 0 and len(files) > 0: #check for used directories
                used_count += 1 #increment used_count
        except:pass






def _show_settings():
    control.openSettings()


def _show_log_tools():
    from resources.lib.modules import logviewer
    logviewer.logView()


def _show_backup_restore():
    navigation.show_backup_restore(_)


def _show_help_setup():
    navigation.show_help_setup(_)


def _show_help_topic(topic):
    navigation.show_help_topic(_, topic)


def _backup_local():
    from resources.lib.modules import buildbackup
    buildbackup.run_backup_flow()


def _restore_local():
    from resources.lib.modules import buildbackup
    buildbackup.run_restore_flow(FRESHSTART)


def _publish_backup():
    from resources.lib.modules import publication
    publication.publish_local_backup()


def _show_public_link():
    from resources.lib.modules import publication
    publication.show_public_link()


def _manage_published_builds():
    from resources.lib.modules import publication
    publication.manage_published_builds()


def _install_public_build():
    from resources.lib.modules import dropbox_auth
    dropbox_auth.install_public_build(FRESHSTART)


def _fresh_start():
    dialog.ok(AddonTitle, _(32015))
    FRESHSTART()


def _install_build(url):
    from resources.lib.modules import builds
    builds.install_build(url, FRESHSTART)


def _dispatch(action, params):
    routes = {
        None: lambda: navigation.show_categories(_),
        'settings': _show_settings,
        'builds': lambda: navigation.show_builds(selfAddon),
        'maintenance': lambda: navigation.show_maintenance(_),
        'clear_cache': maintenance.clearCache,
        'clear_packages': maintenance.purgePackages,
        'clear_thumbs': maintenance.deleteThumbnails,
        'clear_pycache': maintenance.clearPycache,
        'manage_whitelist': whitelist.manage_whitelist,
        'complete_build_cleanup': maintenance.completeBuildCleanup,
        'truncate_tables': maintenance.truncateAddonTables,
        'log_tools': _show_log_tools,
        'backup_restore': _show_backup_restore,
        'help_setup': _show_help_setup,
        'help_topic': lambda: _show_help_topic(params.get('topic')),
        'backup_local': _backup_local,
        'restore_local': _restore_local,
        'publish_backup': _publish_backup,
        'show_public_link': _show_public_link,
        'manage_published_builds': _manage_published_builds,
        'install_public_build': _install_public_build,
        'fresh_start': _fresh_start,
        'install_build': lambda: _install_build(params.get('url')),
    }
    handler = routes.get(action)
    if handler is not None:
        handler()


def run():
    from resources.lib.modules import cloud_status
    cloud_status.refresh()
    params = dict(parse_qsl(sys.argv[2].replace('?', '')))
    _dispatch(params.get('action'), params)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


if __name__ == '__main__':
    run()
