# SPDX-License-Identifier: GPL-3.0-or-later
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.modules.backtothefuture import PY2
from resources.lib.modules import cloud_status
from resources.lib.modules import maintenance

if PY2:
    translatePath = xbmc.translatePath
    loglevel = xbmc.LOGNOTICE
else:
    translatePath = xbmcvfs.translatePath
    loglevel = xbmc.LOGINFO

AddonID = 'script.buildguard'
packagesdir = translatePath('special://home/addons/packages/')
thumbnails = translatePath('special://home/userdata/Thumbnails/')
dialog = xbmcgui.Dialog()


def _diag(message):
    try:
        xbmc.log('[BuildGuard DIAG] {}'.format(message), xbmc.LOGINFO)
    except Exception:
        pass

addon = xbmcaddon.Addon(id=AddonID)
setting = addon.getSetting
iconpath = translatePath('special://home/addons/{}/icon.png'.format(AddonID))
LOG_PREFIX = '[BuildGuard Service]'


def _(string_id):
    return addon.getLocalizedString(string_id)


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('{} {}'.format(LOG_PREFIX, message), level)


def _setting_int(name, default):
    try:
        return int(setting(name))
    except (TypeError, ValueError):
        return default


def _folder_stats(path, monitor):
    total = 0
    count = 0
    if not os.path.isdir(path):
        return 0, 0
    for dirpath, _dirnames, filenames in os.walk(path):
        if monitor.abortRequested():
            break
        for filename in filenames:
            try:
                total += os.path.getsize(os.path.join(dirpath, filename))
                count += 1
            except OSError as exc:
                _log(_(32217).format(exc), xbmc.LOGWARNING)
    return total, count



def _package_zip_stats(path, monitor=None):
    """Return total bytes and count for ZIP files in Kodi's packages folder."""
    total_size = 0
    count = 0
    try:
        for root, _dirs, files in os.walk(path):
            if monitor and monitor.abortRequested():
                break
            for filename in files:
                if not filename.lower().endswith('.zip'):
                    continue
                fullpath = os.path.join(root, filename)
                try:
                    total_size += os.path.getsize(fullpath)
                    count += 1
                except OSError:
                    pass
    except OSError:
        pass
    return total_size, count


def _wait_for_gui(monitor, timeout=60.0):
    waited = 0.0
    while not monitor.abortRequested() and waited < timeout:
        if (xbmc.getCondVisibility('System.HasLoggedIn')
                or xbmc.getCondVisibility('Window.IsActive(home)')):
            return True
        if monitor.waitForAbort(0.5):
            return False
        waited += 0.5
    return False


def _wait_for_home_stable(monitor, timeout=90.0, stable_for=3.0):
    """Wartet, bis Kodis Home-Fenster wirklich stabil aktiv ist.

    Modale Wartungsdialoge waehrend der GUI-Initialisierung koennen verhindern,
    dass Kodi das Home-Fenster (10000) aktiviert. Die normale BuildGuard-
    Startwartung darf deshalb erst beginnen, wenn Home fuer mehrere Sekunden
    durchgehend aktiv war. Bei Timeout wird die Wartung fuer diese Sitzung
    bewusst uebersprungen.
    """
    _diag('Warte auf stabiles Home-Fenster (timeout={}s, stabil={}s)'.format(timeout, stable_for))
    waited = 0.0
    stable = 0.0
    interval = 0.5
    while not monitor.abortRequested() and waited < timeout:
        if xbmc.getCondVisibility('Window.IsActive(home)'):
            stable += interval
            if stable >= stable_for:
                _diag('Home stabil erkannt nach {:.1f}s'.format(waited))
                return True
        else:
            stable = 0.0
        if monitor.waitForAbort(interval):
            return False
        waited += interval
    _diag('Home nicht stabil erkannt; Timeout/Abbruch nach {:.1f}s'.format(waited))
    return False


def _run_startup_maintenance(monitor):
    """Normale Startwartung; erst nach abgeschlossener Installationsphase."""
    _diag('Startup-Wartung gestartet')

    # Keine modalen Dialoge oeffnen, solange Kodi noch Startup.xml/Home
    # initialisiert. Sonst kann der Home-Wechsel wegen DialogConfirm
    # abgewiesen werden und der Skin schwarz stehen bleiben.
    if not _wait_for_home_stable(monitor, timeout=90.0, stable_for=3.0):
        _diag('Home-Fenster nicht stabil aktiv; Startwartung fuer diese Sitzung uebersprungen.')
        return

    notify_mode = setting('notify_mode') == 'true'
    auto_clean = setting('startup.cache') == 'true'
    filesize_thumb = _setting_int('filesizethumb_alert', 500)

    # Nach dem sicheren GUI-Start genügt schon eine vorhandene Paket-ZIP
    # für die Bereinigungsabfrage. Andere Dateien werden nicht mitgezählt.
    total_size, count = _package_zip_stats(packagesdir, monitor)
    total_mb = int(round(total_size / 1048576.0))
    _diag('Paketordner geprueft: {} ZIP(s), {} MB'.format(count, total_mb))
    if count > 0:
        msg = _(32218).format(count, total_mb)
        _diag('Oeffne Paket-Bereinigungsdialog')
        decision = dialog.yesno(_(32219), msg, yeslabel=_(32220), nolabel=_(32221))
        _diag('Paket-Bereinigungsdialog geschlossen: {}'.format('Bereinigen' if decision else 'Behalten'))
        if decision:
            _diag('Starte purgePackages()')
            maintenance.purgePackages()
            _diag('purgePackages() beendet')

        # Defensive Rueckkehr zum Home-Fenster nach dem modalen Dialog.
        # Bei Skins mit eigener Startup.xml verhindert dies einen schwarzen
        # GUI-Zustand, falls Kodi den vorherigen Home-Wechsel verworfen hat.
        if not monitor.abortRequested():
            xbmc.executebuiltin('ActivateWindow(Home)')
            monitor.waitForAbort(0.15)
    else:
        _diag('Keine Paket-ZIPs vorhanden; kein Dialog')

    total_size2, _thumb_count = _folder_stats(thumbnails, monitor)
    total_mb2 = int(round(total_size2 / 1048576.0))
    if total_mb2 > filesize_thumb:
        msg = _(32222).format(total_mb2)
        if dialog.yesno(_(32219), msg, yeslabel=_(32220), nolabel=_(32221)):
            maintenance.deleteThumbnails()

    if notify_mode:
        xbmc.executebuiltin('Notification({}, {}, 5000, {})'.format(
            addon.getAddonInfo('name'), _(32223).format(total_mb, total_mb2), iconpath))
    if not monitor.waitForAbort(3) and auto_clean:
        maintenance.clearCache()


class Monitor(xbmc.Monitor):

    def __init__(self):
        xbmc.Monitor.__init__(self)
        maintenance.logMaintenance('Monitor init')
        maintenance.determineNextMaintenance()
        cloud_status.refresh()

    def onSettingsChanged(self):
        maintenance.logMaintenance('onSettingsChanged')
        maintenance.determineNextMaintenance()
        cloud_status.refresh()


if __name__ == '__main__':
    monitor = Monitor()

    # Simple-Wizard-Prinzip: Nach Build/Restore nur FirstRun behandeln.
    # Keine Skin-Recovery, keine Binary-Nachkontrolle, kein Pending/Retry.
    marker = translatePath('special://profile/addon_data/{}/firstrun.pending'.format(AddonID))
    first_run = setting('firstrun') == 'true' or os.path.isfile(marker)
    # Prozessweite Sperre: Wenn der BuildGuard-Service nach dem FirstRun in
    # derselben Kodi-Sitzung neu gestartet wird (z.B. durch Addon-Updates),
    # darf keine BuildGuard-Startup-Wartung mehr in den Simple-Wizard-Ablauf
    # eingreifen. Window-Properties verschwinden automatisch beim nächsten
    # echten Kodi-Neustart.
    home_window = xbmcgui.Window(10000)
    install_session = home_window.getProperty('BuildGuard.SimpleWizardInstallSession') == 'true'
    if first_run:
        home_window.setProperty('BuildGuard.SimpleWizardInstallSession', 'true')
        try:
            from resources.lib.modules.addons_enable import enable_addons
            enable_addons()
        finally:
            try:
                addon.setSetting('firstrun', 'false')
            except Exception:
                pass
            try:
                if os.path.isfile(marker):
                    os.remove(marker)
            except OSError:
                pass
    elif install_session:
        # In derselben Kodi-Sitzung nach Build/Restore: exakt keine eigene
        # Startup-Wartung, Dialoge, Prüfungen oder Bereinigung. Kodi übernimmt.
        pass
    else:
        # Erst bei einem späteren echten Kodi-Start ist die normale, vom
        # Installationsablauf unabhängige BuildGuard-Wartung wieder erlaubt.
        _run_startup_maintenance(monitor)

    maintenance.logMaintenance('Service started')
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
        maintenance.logMaintenance('monitor loop')
        if not xbmc.Player().isPlayingVideo():
            nextMaintenance = maintenance.getNextMaintenance()
            if nextMaintenance > 0 and time.time() >= nextMaintenance:
                maintenance.clearCache()
                maintenance.determineNextMaintenance()
    del monitor
