# SPDX-License-Identifier: GPL-3.0-or-later
"""Aktive Sicherung/Wiederherstellung von BuildGuards eigenen Cloud-
Zugangsdaten rund um einen Fresh Start waehrend der Build-Installation.

Hintergrund: FRESHSTART() in default.py schliesst script.buildguard zwar
ueber EXCLUDES von der Loeschung aus, die anschliessend siebenmal
aufgerufene REMOVE_EMPTY_FOLDERS() prueft dagegen keinerlei Ausschluss-
liste. Statt sich rein auf Ausschluss-/"nicht ueberschreiben"-Logik zu
verlassen, werden die sicherheitsrelevanten Dateien hier aktiv in einen
temporaeren Ordner innerhalb des eigenen, geschuetzten addon_data-Ordners
kopiert und nach dem Entpacken des neuen Builds wieder zurueckgeschrieben -
unabhaengig davon, was das Build-ZIP an eigenen BuildGuard-Dateien
mitbringt oder ueberschreibt.
"""
import os
import shutil

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(ADDON_ID)
LOG_PREFIX = '[BuildGuard CredentialGuard]'

# Dateien im Addon-Profilordner (special://profile/addon_data/script.buildguard/),
# die Zugangsdaten enthalten koennen und einen Fresh Start unbeschadet
# ueberstehen muessen:
#   - settings.xml deckt die WebDAV-Zugangsdaten (webdav_username/
#     webdav_password) sowie die Google-Drive-Client-ID/-Secret ab, die
#     alle ueber ADDON.setSetting()/getSettingString() dort landen.
#   - die beiden JSON-Dateien enthalten die jeweiligen OAuth-Tokens.
CREDENTIAL_FILES = [
    'settings.xml',
    'dropbox_tokens.json',
    'google_drive_tokens.json',
]


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('{} {}'.format(LOG_PREFIX, message), level)


def _profile_dir():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def _backup_dir():
    # Bewusst NICHT special://temp/: auf portablen Kodi-Installationen liegt
    # special://temp/ (z.B. .../portable_data/cache) INNERHALB von
    # special://home/ und ist damit selbst dem Loesch-Loop von FRESHSTART()
    # ausgesetzt, da 'cache'/'temp' nicht in dessen EXCLUDES steht. Ein
    # Unterordner innerhalb von _profile_dir() ist dagegen automatisch
    # geschuetzt: FRESHSTART() schliesst den kompletten Ordner
    # 'script.buildguard' (per Namensvergleich auf jeder Ebene, also auch
    # unter userdata/addon_data/) von der Loeschung aus, siehe EXCLUDES in
    # default.py.
    path = os.path.join(_profile_dir(), 'credential_backup_tmp')
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def backup():
    """Kopiert vorhandene Zugangsdaten-Dateien in einen temporaeren Ordner.

    Gibt die Liste der tatsaechlich gesicherten Dateinamen zurueck.
    """
    profile_dir = _profile_dir()
    backup_dir = _backup_dir()
    saved = []
    for filename in CREDENTIAL_FILES:
        source = os.path.join(profile_dir, filename)
        if not os.path.isfile(source):
            continue
        target = os.path.join(backup_dir, filename)
        try:
            shutil.copy2(source, target)
            saved.append(filename)
        except OSError as exc:
            _log('Sicherung fehlgeschlagen fuer {}: {}'.format(filename, exc), xbmc.LOGWARNING)
    _log('Zugangsdaten vor Fresh Start gesichert: {}'.format(', '.join(saved) if saved else '(keine vorhanden)'))
    return saved


def restore():
    """Schreibt zuvor gesicherte Zugangsdaten-Dateien zurueck und raeumt
    danach den temporaeren Sicherungsordner auf.

    Ohne vorherigen backup()-Aufruf (bzw. wenn nichts zu sichern war) ist
    dies ein No-op - die Funktion kann daher gefahrlos mehrfach
    aufgerufen werden, etwa zusaetzlich in einem Fehlerpfad.
    """
    profile_dir = _profile_dir()
    backup_dir = _backup_dir()
    restored = []
    for filename in CREDENTIAL_FILES:
        source = os.path.join(backup_dir, filename)
        if not os.path.isfile(source):
            continue
        target = os.path.join(profile_dir, filename)
        try:
            shutil.copy2(source, target)
            restored.append(filename)
        except OSError as exc:
            _log('Wiederherstellung fehlgeschlagen fuer {}: {}'.format(filename, exc), xbmc.LOGERROR)
    if restored:
        _log('Zugangsdaten nach Build-Installation wiederhergestellt: {}'.format(', '.join(restored)))
    try:
        shutil.rmtree(backup_dir, ignore_errors=True)
    except OSError:
        pass
    return restored
