# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later

'''
 CONTROL ROUTINES
'''


import os,sys

import xbmc,xbmcaddon,xbmcplugin,xbmcgui,xbmcvfs
from resources.lib.modules.backtothefuture import PY2


integer = 1000

lang = xbmcaddon.Addon().getLocalizedString

lang2 = xbmc.getLocalizedString

setting = xbmcaddon.Addon().getSetting

setSetting = xbmcaddon.Addon().setSetting

addon = xbmcaddon.Addon

addItem = xbmcplugin.addDirectoryItem

item = xbmcgui.ListItem

directory = xbmcplugin.endOfDirectory

content = xbmcplugin.setContent

property = xbmcplugin.setProperty

addonInfo = xbmcaddon.Addon().getAddonInfo

infoLabel = xbmc.getInfoLabel

condVisibility = xbmc.getCondVisibility

jsonrpc = xbmc.executeJSONRPC

window = xbmcgui.Window(10000)

dialog = xbmcgui.Dialog()

progressDialog = xbmcgui.DialogProgress()

progressDialogBG = xbmcgui.DialogProgressBG()

windowDialog = xbmcgui.WindowDialog()

button = xbmcgui.ControlButton

image = xbmcgui.ControlImage

keyboard = xbmc.Keyboard

sleep = xbmc.sleep

execute = xbmc.executebuiltin

skin = xbmc.getSkinDir()

player = xbmc.Player()

playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

resolve = xbmcplugin.setResolvedUrl

openFile = xbmcvfs.File

makeFile = xbmcvfs.mkdir

deleteFile = xbmcvfs.delete

deleteDir = xbmcvfs.rmdir

listDir = xbmcvfs.listdir

if PY2:
    translatePath = xbmc.translatePath
else:
    translatePath = xbmcvfs.translatePath

skinPath = translatePath('special://skin/')

addonPath = translatePath(addonInfo('path'))

AddonID = 'script.buildguard'
artPath = translatePath(os.path.join('special://home/addons/' + AddonID, 'art'))
# DIRECTORIES
backupdir        =  translatePath(os.path.join('special://home/backupdir',''))
packagesdir      =  translatePath(os.path.join('special://home/addons/packages',''))
USERDATA         =  translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA       =  translatePath(os.path.join(USERDATA, 'addon_data'))
HOME             =  translatePath('special://home/')
HOME_ADDONS      =  translatePath('special://home/addons')


def addonIcon():
    path = translatePath(os.path.join('special://home/addons/' + AddonID , 'icon.png'))
    return path

def addonFanart():
    return translatePath(os.path.join('special://home/addons/' + AddonID , 'fanart.jpg'))

def selectDialog(list, heading=addonInfo('name')):
    return dialog.select(heading, list)


def openSettings(query=None, id=addonInfo('id')):
    try:
        idle()
        execute('Addon.OpenSettings(%s)' % id)
        if query == None: raise Exception()
        c, f = query.split('.')
        execute('SetFocus(%i)' % (int(c) + 100))
        execute('SetFocus(%i)' % (int(f) + 200))
    except:
        return

def refresh():
    return execute('Container.Refresh')

def idle():
    return execute('Dialog.Close(busydialog)')
