# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""Whitelist fuer den Fresh-Start-Schritt bei der Build-Installation.

Erlaubt es, bestimmte installierte Addons dauerhaft von der Loeschung
waehrend eines Build-Installs (FRESHSTART) auszunehmen. Die Auswahl wird
als JSON in den eigenen Addon-Daten gespeichert, unabhaengig vom
Build-Verzeichnis selbst - bleibt also auch nach einem Fresh Start erhalten.
"""
import json
import re

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
LOG_PREFIX = '[BuildGuard Whitelist]'

ADDONS_DIR = xbmcvfs.translatePath('special://home/addons/')
DATA_DIR = xbmcvfs.translatePath('special://profile/addon_data/{}/'.format(ADDON_ID))
WHITELIST_FILE = DATA_DIR + 'whitelist.json'

# Ordner, die nie zur Auswahl angeboten werden - keine echten Addons bzw.
# ohnehin schon ueber die feste EXCLUDES-Liste geschuetzt.
HIDDEN_FROM_SELECTION = ('packages', 'temp', ADDON_ID)


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('{} {}'.format(LOG_PREFIX, message), level)


def _(string_id):
    return ADDON.getLocalizedString(string_id)


def read_whitelist():
    """Liest die gespeicherte Whitelist. Liefert eine leere Liste, falls
    noch keine existiert oder die Datei beschaedigt ist."""
    if not xbmcvfs.exists(WHITELIST_FILE):
        return []
    try:
        with xbmcvfs.File(WHITELIST_FILE) as handle:
            raw = handle.read()
        data = json.loads(raw)
        whitelist = data.get('whitelist', [])
        if not isinstance(whitelist, list):
            return []
        return [str(item) for item in whitelist if item]
    except (OSError, ValueError, TypeError) as exc:
        _log('Whitelist konnte nicht gelesen werden: {}'.format(exc), xbmc.LOGWARNING)
        return []


def write_whitelist(items):
    """Speichert die Whitelist als JSON in den eigenen Addon-Daten."""
    if not xbmcvfs.exists(DATA_DIR):
        xbmcvfs.mkdirs(DATA_DIR)
    try:
        with xbmcvfs.File(WHITELIST_FILE, 'w') as handle:
            handle.write(json.dumps({'whitelist': items}, ensure_ascii=False, indent=2))
        return True
    except OSError as exc:
        _log('Whitelist konnte nicht gespeichert werden: {}'.format(exc), xbmc.LOGERROR)
        return False


def _display_name(folder_name):
    try:
        addon_name = xbmcaddon.Addon(folder_name).getAddonInfo('name')
        return re.sub(r'\[[^\]]+\]', '', addon_name).strip() or folder_name
    except Exception:
        return folder_name


def manage_whitelist():
    """Zeigt eine Mehrfachauswahl aller installierten Addons und speichert
    die getroffene Auswahl als neue Whitelist."""
    dirs, _files = xbmcvfs.listdir(ADDONS_DIR)
    dirs = sorted(d for d in dirs if d not in HIDDEN_FROM_SELECTION)

    current = set(read_whitelist())
    preselect = [i for i, folder in enumerate(dirs) if folder in current]
    labels = [_display_name(folder) for folder in dirs]

    choice = xbmcgui.Dialog().multiselect(_(32988), labels, preselect=preselect)
    if choice is None:
        return False

    selected = [dirs[i] for i in choice]
    if write_whitelist(selected):
        _log('Whitelist gespeichert: {} Eintraege -> {}'.format(len(selected), ', '.join(selected)))
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo('name'), _(32990), ADDON.getAddonInfo('icon'), 3000
        )
        return True
    return False


def apply_whitelist(excludes_list):
    """Haengt die gespeicherte Whitelist an eine bestehende Exclude-Liste
    an - fuer den Einsatz in FRESHSTART() waehrend eines Build-Installs."""
    whitelist = read_whitelist()
    merged = list(excludes_list)
    for item in whitelist:
        if item not in merged:
            merged.append(item)
    return merged
