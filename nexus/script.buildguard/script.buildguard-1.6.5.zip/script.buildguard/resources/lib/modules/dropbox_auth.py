# SPDX-License-Identifier: GPL-3.0-or-later
"""Creator-only Dropbox OAuth helper.

This module establishes, tests and removes a Dropbox OAuth session.
It provides creator-only test and backup ZIP uploads, publishes a minimal
buildguard.json, creates stable Dropbox shared links and supports a
credential-free consumer download of the published backup ZIP.
"""
import datetime
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request


class DropboxOAuthHTTPError(RuntimeError):
    """Dropbox OAuth HTTP error without sensitive request data."""

    def __init__(self, status, body, headers=None):
        self.status = int(status or 0)
        self.body = str(body or "")
        self.headers = headers or {}
        RuntimeError.__init__(
            self,
            "Dropbox OAuth HTTP {}: {}".format(self.status, self.body),
        )


def _dropbox_authorize_url(app_key):
    """Build the Dropbox browser authorization URL."""
    query = urllib.parse.urlencode({
        "client_id": app_key,
        "response_type": "code",
        "token_access_type": "offline",
    })
    return "https://www.dropbox.com/oauth2/authorize?" + query


def _exchange_authorization_code(app_key, app_secret, code):
    """Exchange the one-time code directly through Dropbox HTTPS."""
    payload = urllib.parse.urlencode({
        "code": code,
        "grant_type": "authorization_code",
        "client_id": app_key,
        "client_secret": app_secret,
    }).encode("utf-8")

    request = urllib.request.Request(
        "https://api.dropboxapi.com/oauth2/token",
        data=payload,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "BuildGuard/{}".format(ADDON.getAddonInfo("version")),
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            body = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as error:
        try:
            body = error.read().decode("utf-8", errors="replace")
        except Exception:
            body = str(error)
        raise DropboxOAuthHTTPError(
            getattr(error, "code", 0),
            body,
            dict(getattr(error, "headers", {}) or {}),
        )
    except urllib.error.URLError as error:
        raise RuntimeError(
            "Dropbox OAuth network error: {}".format(
                getattr(error, "reason", error)
            )
        )

    try:
        result = json.loads(body)
    except (TypeError, ValueError):
        raise RuntimeError("Dropbox returned an invalid OAuth response.")

    if not isinstance(result, dict):
        raise RuntimeError("Dropbox returned an unsupported OAuth response.")
    if not result.get("access_token") and not result.get("refresh_token"):
        raise RuntimeError("Dropbox returned no usable OAuth token.")
    return result


def _oauth_error_text(error):
    """Return a lower-case OAuth error description without exposing secrets."""
    parts = [str(error or ''), str(getattr(error, "body", "") or "")]
    response = getattr(error, 'response', None)
    if response is not None:
        parts.append(str(getattr(response, 'text', '') or ''))
        try:
            payload = response.json()
        except Exception:
            payload = None
        if payload is not None:
            try:
                parts.append(json.dumps(payload, ensure_ascii=False, sort_keys=True))
            except Exception:
                parts.append(str(payload))
    return ' '.join(parts).lower()


def _is_invalid_grant_error(error):
    """Return True for expired, reused or session-mismatched access codes."""
    message = _oauth_error_text(error)
    return (
        'invalid_grant' in message
        or 'code has expired' in message
        or 'code was already used' in message
        or ('authorization code' in message and 'invalid' in message)
    )


def _is_invalid_client_error(error):
    """Return True when the configured app key or secret was rejected."""
    message = _oauth_error_text(error)
    return (
        'invalid_client' in message
        or 'client authentication failed' in message
        or 'invalid app key' in message
        or 'invalid app secret' in message
    )


import xbmc

import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.modules import progress_format

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(ADDON_ID)
TITLE = ADDON.getAddonInfo('name')
TOKEN_FILENAME = 'dropbox_tokens.json'


def _(string_id):
    return ADDON.getLocalizedString(string_id)




def _safe_text(value, secrets=()):
    text = str(value or '')
    for secret in secrets:
        if secret:
            text = text.replace(secret, '<redacted>')
    text = re.sub(r'(?i)(access_token|refresh_token|code|client_secret)=[^&\s]+', r'\1=<redacted>', text)
    return text[:1800]


def _diagnostic_exception(exc, app_key, app_secret, code):
    """Log a privacy-safe OAuth failure, including the HTTP response body.

    requests.HTTPError stores Dropbox's useful OAuth error in ``response``.
    Never log the request body or authorization headers because those can
    contain the app secret or the one-time authorization code.
    """
    diag_id = time.strftime('%Y%m%d-%H%M%S')
    secrets = (app_key, app_secret, code)
    details = {
        'diagnostic_id': diag_id,
        'exception_type': type(exc).__name__,
        'message': _safe_text(exc, secrets),
        'request_id': _safe_text(getattr(exc, 'request_id', ''), secrets),
        'error': _safe_text(getattr(exc, 'error', ''), secrets),
        'user_message': _safe_text(getattr(exc, 'user_message_text', ''), secrets),
        'app_key_length': len(app_key),
        'app_secret_length': len(app_secret),
        'authorization_code_length': len(code),
        'app_key_has_outer_whitespace': app_key != app_key.strip(),
        'app_secret_has_outer_whitespace': app_secret != app_secret.strip(),
        'authorization_code_has_whitespace': any(ch.isspace() for ch in code),
        'oauth_flow_mode': 'direct_https_app_secret_offline',
    }

    direct_body = getattr(exc, "body", "")
    if direct_body:
        details["http_status"] = getattr(exc, "status", None)
        details["response_text"] = _safe_text(direct_body, secrets)
        try:
            details["response_json"] = json.loads(direct_body)
        except (TypeError, ValueError):
            pass
        safe_headers = {}
        for name, value in (getattr(exc, "headers", {}) or {}).items():
            if str(name).lower() in (
                "content-type",
                "date",
                "server",
                "x-dropbox-request-id",
                "x-request-id",
            ):
                safe_headers[str(name).lower()] = _safe_text(value, secrets)
        details["response_headers"] = safe_headers

    response = getattr(exc, 'response', None)
    if response is not None:
        details['http_status'] = getattr(response, 'status_code', None)
        details['http_reason'] = _safe_text(getattr(response, 'reason', ''), secrets)
        details['response_url'] = _safe_text(getattr(response, 'url', ''), secrets)
        details['response_text'] = _safe_text(getattr(response, 'text', ''), secrets)

        headers = getattr(response, 'headers', {}) or {}
        safe_headers = {}
        for name in ('content-type', 'date', 'server', 'x-dropbox-request-id', 'x-request-id'):
            value = headers.get(name) or headers.get(name.title())
            if value:
                safe_headers[name] = _safe_text(value, secrets)
        details['response_headers'] = safe_headers

        try:
            response_json = response.json()
        except Exception:
            response_json = None
        if response_json is not None:
            details['response_json'] = json.loads(_safe_text(
                json.dumps(response_json, ensure_ascii=False, sort_keys=True),
                secrets,
            )) if isinstance(response_json, dict) else _safe_text(response_json, secrets)

    try:
        import dropbox
        details['dropbox_sdk_version'] = getattr(dropbox, '__version__', 'unknown')
    except Exception:
        details['dropbox_sdk_version'] = 'unknown'

    xbmc.log(
        '[BuildGuard][Dropbox OAuth diagnostic] '
        + json.dumps(details, ensure_ascii=False, sort_keys=True),
        xbmc.LOGERROR,
    )
    return diag_id, details

def _profile_dir():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def token_path():
    return os.path.join(_profile_dir(), TOKEN_FILENAME)


def _load_sdk():
    try:
        from dropbox import dropbox as dropbox_client
        from dropbox import oauth
        import pyqrcode
        return dropbox_client, oauth, pyqrcode
    except ImportError as exc:
        raise RuntimeError(str(exc))


def _credentials():
    return (ADDON.getSettingString('dropbox_app_key').strip(),
            ADDON.getSettingString('dropbox_app_secret').strip())


def _ensure_credentials():
    """Return credentials, prompting only when Kodi has not committed them yet.

    Action settings can run while the settings window is still open. On some
    Kodi versions the edited values are not written until that window closes,
    so a newly started script sees empty strings. Asking once here and saving
    the values makes the OAuth action reliable without changing normal use.
    """
    app_key, app_secret = _credentials()
    dialog = xbmcgui.Dialog()

    if not app_key:
        app_key = dialog.input(_(32237), type=xbmcgui.INPUT_ALPHANUM).strip()
        if not app_key:
            return '', ''
        ADDON.setSettingString('dropbox_app_key', app_key)

    if not app_secret:
        app_secret = dialog.input(
            _(32238),
            type=xbmcgui.INPUT_ALPHANUM,
        ).strip()
        if not app_secret:
            return '', ''
        ADDON.setSettingString('dropbox_app_secret', app_secret)

    return app_key, app_secret



def _oauth_result_data(result):
    """Normalize Dropbox OAuth results across SDK versions.

    Modern SDKs return an OAuth2FlowNoRedirectResult object. Older SDKs and
    some Kodi-packaged variants can return a mapping or a tuple containing at
    least the access token and account/user identifier.
    """
    data = {
        'access_token': '',
        'refresh_token': '',
        'expiration': None,
        'account_id': '',
    }

    if result is None:
        return data

    if isinstance(result, dict):
        data['access_token'] = (
            result.get('access_token')
            or result.get('oauth2_access_token')
            or result.get('token')
            or ''
        )
        data['refresh_token'] = (
            result.get('refresh_token')
            or result.get('oauth2_refresh_token')
            or ''
        )
        data['expiration'] = (
            result.get('expiration')
            or result.get('expires_at')
            or result.get('expires_in')
        )
        data['account_id'] = (
            result.get('account_id')
            or result.get('user_id')
            or result.get('uid')
            or ''
        )
        return data

    # Official Dropbox result objects use ``expiration``. Some wrappers expose
    # ``expires_at`` instead, so support both.
    data['access_token'] = (
        getattr(result, 'access_token', None)
        or getattr(result, 'oauth2_access_token', None)
        or getattr(result, 'token', None)
        or ''
    )
    data['refresh_token'] = (
        getattr(result, 'refresh_token', None)
        or getattr(result, 'oauth2_refresh_token', None)
        or ''
    )
    data['expiration'] = (
        getattr(result, 'expiration', None)
        or getattr(result, 'expires_at', None)
        or getattr(result, 'expires_in', None)
    )
    data['account_id'] = (
        getattr(result, 'account_id', None)
        or getattr(result, 'user_id', None)
        or getattr(result, 'uid', None)
        or ''
    )

    # Legacy Dropbox SDKs returned a tuple such as (access_token, user_id).
    if not data['access_token'] and isinstance(result, (tuple, list)):
        if len(result) >= 1:
            data['access_token'] = result[0] or ''
        if len(result) >= 2:
            data['account_id'] = result[1] or ''
        if len(result) >= 3:
            data['refresh_token'] = result[2] or ''
        if len(result) >= 4:
            data['expiration'] = result[3]

    return data


def _expiration_to_iso(value):
    """Convert SDK expiration formats to an ISO timestamp when possible."""
    if not value:
        return ''
    if isinstance(value, datetime.datetime):
        return value.isoformat()
    if isinstance(value, (int, float)):
        # ``expires_in`` values are relative seconds; large values are assumed
        # to be Unix timestamps.
        if value < 100000000:
            value = time.time() + value
        try:
            return datetime.datetime.fromtimestamp(value).isoformat()
        except (OverflowError, OSError, ValueError):
            return ''
    try:
        return str(value)
    except Exception:
        return ''

def _save_token(result):
    """Persist a new token atomically, preserving the existing token on failure."""
    token_data = _oauth_result_data(result)
    payload = {
        'access_token': token_data['access_token'],
        'refresh_token': token_data['refresh_token'],
        'expires_at': _expiration_to_iso(token_data['expiration']),
        'account_id': token_data['account_id'],
    }
    final_path = token_path()
    temp_path = final_path + '.new'
    try:
        with open(temp_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except (AttributeError, OSError):
                pass
        os.replace(temp_path, final_path)
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                pass


def _load_token():
    path = token_path()
    if not xbmcvfs.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _expiration(value):
    if not value:
        return None
    try:
        return datetime.datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def _create_client(access_token='', refresh_token='', expires_at=None):
    """Create a Dropbox client from either a refresh or access token.

    Dropbox can return an access token without a new refresh token when an
    existing authorization is reused. Such a response is still valid and must
    not be treated as a failed authorization.
    """
    dropbox_client, _oauth, _pyqrcode = _load_sdk()
    app_key, app_secret = _credentials()
    access_token = access_token or ''
    refresh_token = refresh_token or ''

    if refresh_token:
        if not app_key:
            return None
        kwargs = {
            'oauth2_access_token': access_token or None,
            'oauth2_refresh_token': refresh_token,
            'oauth2_access_token_expiration': expires_at,
            'app_key': app_key,
        }
        if app_secret:
            kwargs['app_secret'] = app_secret
        return dropbox_client.Dropbox(**kwargs)

    if access_token:
        return dropbox_client.Dropbox(oauth2_access_token=access_token)

    return None


def _client():
    token = _load_token()
    if not token:
        return None
    return _create_client(
        access_token=token.get('access_token') or '',
        refresh_token=token.get('refresh_token') or '',
        expires_at=_expiration(token.get('expires_at')),
    )


class QRCodeDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.image = kwargs.get('image', '')
        self.text = kwargs.get('text', '')

    def onInit(self):
        self.getControl(501).setImage(self.image)
        self.getControl(502).setText(self.text)
        self.getControl(503).setLabel(_(32258))
        self.setFocus(self.getControl(503))

    def onClick(self, control_id):
        if control_id == 503:
            self.close()


def authorize():
    app_key, app_secret = _ensure_credentials()
    if not app_key or not app_secret:
        xbmcgui.Dialog().ok(TITLE, _(32248))
        return False
    image_path = os.path.join(_profile_dir(), 'dropbox_oauth_qr.png')
    try:
        existing_token = token_path()
        _dropbox_client, _oauth, pyqrcode = _load_sdk()
        authorize_url = _dropbox_authorize_url(app_key)
        pyqrcode.create(authorize_url).png(image_path, scale=7)
        dialog = QRCodeDialog(
            'script-buildguard-dropbox-qrcode.xml',
            ADDON.getAddonInfo('path'),
            'Default',
            image=image_path,
            text=_(32244),
        )
        dialog.doModal()
        del dialog
        xbmcgui.Dialog().ok(TITLE, _(32259))
        code = ''.join(xbmcgui.Dialog().input(_(32245)).split())
        if not code:
            return False
        try:
            result = _exchange_authorization_code(app_key, app_secret, code)
        except Exception as error:
            if _is_invalid_grant_error(error):
                retry = xbmcgui.Dialog().yesno(
                    TITLE,
                    ADDON.getLocalizedString(32980),
                    yeslabel=ADDON.getLocalizedString(32981),
                    nolabel=ADDON.getLocalizedString(32982)
                )
                if retry:
                    return authorize()
                return False
            if _is_invalid_client_error(error):
                xbmc.log(
                    "[BuildGuard] Dropbox rejected the configured app credentials.",
                    xbmc.LOGERROR,
                )
                xbmcgui.Dialog().ok(TITLE, ADDON.getLocalizedString(32985))
                return False
            diag_id, details = _diagnostic_exception(error, app_key, app_secret, code)
            reason = (
                details.get('response_text')
                or details.get('error')
                or details.get('message')
                or type(error).__name__
            )
            xbmcgui.Dialog().ok(
                TITLE,
                ADDON.getLocalizedString(32983).format(
                    str(reason) + '\nDiagnostic ID: ' + diag_id
                )
            )
            return False
        token_data = _oauth_result_data(result)
        if not token_data['access_token'] and not token_data['refresh_token']:
            xbmc.log(
                '[BuildGuard][Dropbox OAuth] Unsupported result type: {}'.format(
                    type(result).__name__
                ),
                xbmc.LOGERROR,
            )
            raise RuntimeError(_(32984))

        fresh_client = _create_client(
            access_token=token_data['access_token'],
            refresh_token=token_data['refresh_token'],
            expires_at=(
                token_data['expiration']
                if isinstance(token_data['expiration'], datetime.datetime)
                else _expiration(_expiration_to_iso(token_data['expiration']))
            ),
        )
        if fresh_client is None:
            raise RuntimeError(_(32984))

        # Verify the freshly returned credentials before replacing a previously
        # working token file.
        account = fresh_client.users_get_current_account()
        _save_token(result)
        from resources.lib.modules import cloud_status
        cloud_status.refresh()
        name = getattr(getattr(account, 'name', None), 'display_name', '') or getattr(account, 'email', '')
        xbmcgui.Dialog().ok(TITLE, _(32246) + ('\n' + name if name else ''))
        return True
    except Exception as exc:
        diag_id, details = _diagnostic_exception(exc, app_key, app_secret, locals().get('code', ''))
        response_json = details.get('response_json') or {}
        if isinstance(response_json, dict) and response_json.get('error') == 'invalid_grant':
            reason = _(32257)
        else:
            reason = (details.get('response_text') or details.get('error')
                      or details.get('message') or details.get('exception_type'))
        xbmcgui.Dialog().ok(TITLE, _(32247).format(reason + '\nDiagnostic ID: ' + diag_id))
        return False
    finally:
        if xbmcvfs.exists(image_path):
            xbmcvfs.delete(image_path)



def _dropbox_folder():
    """Return a normalized absolute Dropbox folder path."""
    folder = ADDON.getSettingString('dropbox_folder').strip().replace('\\', '/')
    if not folder or folder == '/':
        return ''
    return '/' + '/'.join(part for part in folder.split('/') if part)


def _is_existing_folder_error(exc):
    """Return True only for Dropbox's folder-already-exists conflict."""
    error = getattr(exc, 'error', None)
    try:
        if not error or not error.is_path():
            return False
        path_error = error.get_path()
        if not path_error.is_conflict():
            return False
        conflict = path_error.get_conflict()
        return bool(conflict.is_folder())
    except (AttributeError, TypeError):
        return False


def _ensure_dropbox_folder(client, folder):
    """Create each target-folder level without requesting metadata."""
    if not folder:
        return
    current = ''
    for part in folder.strip('/').split('/'):
        current += '/' + part
        try:
            client.files_create_folder_v2(current)
        except Exception as exc:
            if not _is_existing_folder_error(exc):
                raise



def _upload_status(filename, uploaded, total, started_at):
    """Return a compact upload status with progress and ETA - einheitliches
    Format ueber das gesamte Addon hinweg (siehe progress_format.py).
    Der Provider-Name 'Dropbox' bleibt bewusst als austauschbarer Literal
    im Label stehen: google_drive_provider.py/webdav_provider.py rufen
    diese Funktion mit .replace('Dropbox', '<Provider>') weiter und
    erben so automatisch dasselbe Layout."""
    label = _(32992).format('Dropbox')
    return progress_format.status_text(label, filename, uploaded, total, started_at, _(32109))

def upload_backup_file(local_path, remote_filename=None):
    """Upload an existing backup ZIP to the configured creator folder.

    Uses Dropbox upload sessions so normal Kodi build ZIPs are not limited by
    the small single-request upload size. The local backup is never deleted.
    """
    progress = None
    try:
        client = _client()
        if client is None:
            return False, _(32250)
        if not local_path or not xbmcvfs.exists(local_path):
            return False, _(32264)

        from dropbox.files import CommitInfo, UploadSessionCursor, WriteMode

        folder = _dropbox_folder()
        _ensure_dropbox_folder(client, folder)
        local_filename = os.path.basename(local_path.replace('\\', '/'))
        filename = os.path.basename((remote_filename or local_filename).replace('\\', '/'))
        if not filename.lower().endswith('.zip'):
            return False, _(32315)
        remote_path = (folder + '/' + filename) if folder else '/' + filename
        chunk_size = 8 * 1024 * 1024
        source = xbmcvfs.File(local_path, 'rb')
        try:
            total_size = source.size()
            if total_size <= 0:
                return False, _(32265)

            started_at = time.monotonic()
            progress = xbmcgui.DialogProgress()
            progress.create(TITLE, _upload_status(filename, 0, total_size, started_at))

            first_chunk = bytes(source.readBytes(min(chunk_size, total_size)))
            if not first_chunk:
                return False, _(32265)
            if progress.iscanceled():
                raise RuntimeError(_(32029))

            start = client.files_upload_session_start(first_chunk)
            offset = len(first_chunk)
            cursor = UploadSessionCursor(session_id=start.session_id, offset=offset)
            commit = CommitInfo(path=remote_path, mode=WriteMode.overwrite, mute=True)
            progress.update(
                min(int(cursor.offset * 100 / total_size), 99),
                _upload_status(filename, cursor.offset, total_size, started_at),
            )

            while cursor.offset < total_size:
                if progress.iscanceled():
                    raise RuntimeError(_(32029))
                chunk = bytes(source.readBytes(min(chunk_size, total_size - cursor.offset)))
                if not chunk:
                    raise IOError('Unexpected end of backup file during Dropbox upload')
                if cursor.offset + len(chunk) < total_size:
                    client.files_upload_session_append_v2(chunk, cursor)
                    cursor.offset += len(chunk)
                else:
                    client.files_upload_session_finish(chunk, cursor, commit)
                    cursor.offset += len(chunk)
                progress.update(
                    min(int(cursor.offset * 100 / total_size), 100),
                    _upload_status(filename, cursor.offset, total_size, started_at),
                )
            if cursor.offset == len(first_chunk):
                client.files_upload_session_finish(b'', cursor, commit)
                progress.update(100, _upload_status(filename, total_size, total_size, started_at))
        finally:
            source.close()
        return True, remote_path
    except Exception as exc:
        safe_error = _safe_text(exc, _credentials())
        xbmc.log('[BuildGuard][Dropbox backup upload] ' + safe_error, xbmc.LOGERROR)
        return False, safe_error or type(exc).__name__
    finally:
        if progress is not None:
            progress.close()


def _existing_shared_link(client, path):
    """Return an existing direct shared link for *path*, if Dropbox has one."""
    result = client.sharing_list_shared_links(path=path, direct_only=True)
    links = getattr(result, 'links', None) or []
    return links[0].url if links else ''


def _shared_link(client, path):
    """Create or reuse a stable Dropbox shared link for one file."""
    existing = _existing_shared_link(client, path)
    if existing:
        return existing
    try:
        return client.sharing_create_shared_link_with_settings(path).url
    except Exception:
        # A link may already exist even when creation reports a conflict.
        existing = _existing_shared_link(client, path)
        if existing:
            return existing
        raise


def _direct_download_url(url):
    """Turn a Dropbox preview link into a direct HTTPS download link."""
    parsed = urllib.parse.urlsplit(url.strip())
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query = [(key, value) for key, value in query if key.lower() not in ('dl', 'raw')]
    query.append(('dl', '1'))
    return urllib.parse.urlunsplit(parsed._replace(query=urllib.parse.urlencode(query)))


def _create_tinyurl(long_url):
    """Create a TinyURL for the stable public catalog URL."""
    endpoint = 'https://tinyurl.com/api-create.php?' + urllib.parse.urlencode({'url': long_url})
    request = urllib.request.Request(
        endpoint,
        headers={'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version')},
    )
    with urllib.request.urlopen(request, timeout=15) as response:
        short_url = response.read(4096).decode('utf-8', 'replace').strip()
    parsed = urllib.parse.urlsplit(short_url)
    if parsed.scheme.lower() != 'https' or parsed.netloc.lower() not in ('tinyurl.com', 'www.tinyurl.com'):
        raise ValueError('TinyURL returned an invalid URL')
    return short_url


def _stable_short_link(long_url):
    """Return one persistent TinyURL for an unchanged buildguard.json URL.

    A shortener outage must never make a successful Dropbox publication fail.
    A new TinyURL is requested only when no cached link exists or when the
    original public catalog URL has changed.
    """
    cached_url = ADDON.getSettingString('buildguard_short_url').strip()
    cached_source = ADDON.getSettingString('buildguard_short_source_url').strip()
    if cached_url and cached_source == long_url:
        return cached_url
    try:
        short_url = _create_tinyurl(long_url)
        ADDON.setSettingString('buildguard_short_url', short_url)
        ADDON.setSettingString('buildguard_short_source_url', long_url)
        xbmc.log('[BuildGuard][TinyURL] Stable short link created', xbmc.LOGINFO)
        return short_url
    except Exception as exc:
        safe_error = _safe_text(exc)
        xbmc.log('[BuildGuard][TinyURL] ' + safe_error, xbmc.LOGWARNING)
        return ''

def _index_path():
    folder = _dropbox_folder()
    return (folder + '/buildguard.json') if folder else '/buildguard.json'


def _entry_from_legacy(data):
    """Convert the Phase-1 single-build document into one catalog entry."""
    if not isinstance(data, dict) or 'builds' in data:
        return None
    required = ('version', 'filename', 'path', 'download_url', 'created')
    if not all(isinstance(data.get(key), str) and data.get(key).strip() for key in required):
        return None
    entry = {key: data[key].strip() for key in required}
    entry['name'] = str(data.get('name') or os.path.splitext(os.path.basename(entry['filename']))[0]).strip()
    return entry


def _catalog_from_data(data):
    """Return a normalized variable-length catalog, accepting legacy JSON."""
    legacy = _entry_from_legacy(data)
    if legacy:
        return {'format': 2, 'builds': [legacy]}
    if not isinstance(data, dict):
        return {'format': 2, 'builds': []}
    builds = data.get('builds')
    if not isinstance(builds, list):
        return {'format': 2, 'builds': []}
    clean = []
    for item in builds:
        if not isinstance(item, dict):
            continue
        try:
            clean.append(_validated_build_entry(item))
        except ValueError:
            continue
    return {'format': 2, 'builds': clean}


def _download_creator_catalog(client):
    """Read the creator's current catalog; a missing file means an empty list."""
    try:
        _metadata, response = client.files_download(_index_path())
        raw = response.content
        return _catalog_from_data(json.loads(raw.decode('utf-8-sig')))
    except Exception as exc:
        error = getattr(exc, 'error', None)
        try:
            if error and error.is_path() and error.get_path().is_not_found():
                return {'format': 2, 'builds': []}
        except (AttributeError, TypeError):
            pass
        # Old SDK/HTTP variants can expose only text for not_found.
        if 'not_found' in str(exc).lower():
            return {'format': 2, 'builds': []}
        raise


def _upload_catalog(client, catalog):
    from dropbox.files import WriteMode
    content = json.dumps(catalog, ensure_ascii=False, indent=2, sort_keys=True).encode('utf-8')
    client.files_upload(content, _index_path(), mode=WriteMode.overwrite, mute=True)


def _creator_build_choice(catalog):
    """Choose a new catalog entry or an existing slot without name prompts."""
    builds = catalog.get('builds') or []
    labels = [_(32304)] + [item['name'] for item in builds]
    selected = xbmcgui.Dialog().select(_(32306), labels)
    if selected < 0:
        return None
    return -1 if selected == 0 else selected - 1

def publish_backup_index(remote_path, display_name, replace_index=None):
    """Add or update one build while keeping a stable shared catalog link."""
    try:
        client = _client()
        if client is None:
            return False, _(32250)
        catalog = _download_creator_catalog(client)
        builds = catalog['builds']
        zip_url = _direct_download_url(_shared_link(client, remote_path))
        entry = {
            'name': display_name,
            'version': ADDON.getAddonInfo('version'),
            'filename': os.path.basename(remote_path),
            'path': remote_path,
            'download_url': zip_url,
            'created': datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
        }
        if replace_index is not None and 0 <= replace_index < len(builds):
            builds[replace_index] = entry
        else:
            builds.append(entry)
        _upload_catalog(client, catalog)
        index_url = _direct_download_url(_shared_link(client, _index_path()))
        ADDON.setSettingString('buildguard_public_url', index_url)
        ADDON.setSettingString('dropbox_public_url', index_url)
        short_url = _stable_short_link(index_url)
        ADDON.setSettingString('dropbox_short_url', short_url or '')
        xbmc.log('[BuildGuard][Dropbox publish] buildguard.json: ' + _index_path(), xbmc.LOGINFO)
        return True, (short_url or index_url)
    except Exception as exc:
        safe_error = _safe_text(exc, _credentials())
        xbmc.log('[BuildGuard][Dropbox buildguard.json publish] ' + safe_error, xbmc.LOGERROR)
        return False, safe_error or type(exc).__name__



def _highlight_share_url(url):
    """Highlight TinyURL links in Kodi dialogs without changing the stored URL."""
    host = urllib.parse.urlsplit(url).netloc.lower()
    if host in ('tinyurl.com', 'www.tinyurl.com'):
        return '[COLOR gold][B]{}[/B][/COLOR]'.format(url)
    return url


def publish_local_backup():
    """Publish a ZIP using its filename automatically as the build name."""
    chosen = xbmcgui.Dialog().browse(1, _(32281), 'files', '.zip')
    if not chosen:
        return False
    try:
        client = _client()
        if client is None:
            xbmcgui.Dialog().ok(TITLE, _(32250))
            return False
        catalog = _download_creator_catalog(client)
    except Exception as exc:
        xbmcgui.Dialog().ok(TITLE, _(32268).format(chosen, '', _safe_text(exc), ''))
        return False

    replace_index = _creator_build_choice(catalog)
    if replace_index is None:
        return False
    local_filename = os.path.basename(chosen.replace('\\', '/'))
    if replace_index == -1:
        remote_filename = local_filename
        display_name = os.path.splitext(remote_filename)[0]
        if any(item['filename'].casefold() == remote_filename.casefold()
               for item in catalog['builds']):
            xbmcgui.Dialog().ok(TITLE, _(32308).format(display_name))
            return False
        question = _(32310).format(display_name, remote_filename)
    else:
        existing = catalog['builds'][replace_index]
        remote_filename = existing['filename']
        display_name = os.path.splitext(remote_filename)[0]
        question = _(32309).format(display_name, remote_filename, local_filename)
    if not xbmcgui.Dialog().yesno(TITLE, question):
        return False

    upload_ok, upload_result = upload_backup_file(chosen, remote_filename=remote_filename)
    if not upload_ok:
        xbmcgui.Dialog().ok(TITLE, _(32266).format(chosen, upload_result, ''))
        return False
    catalog_index = None if replace_index == -1 else replace_index
    index_ok, index_result = publish_backup_index(upload_result, display_name, catalog_index)
    if not index_ok:
        xbmcgui.Dialog().ok(TITLE, _(32268).format(chosen, upload_result, index_result, ''))
        return False
    highlighted_url = _highlight_share_url(index_result)
    is_first_publication = replace_index == -1 and not catalog.get('builds')
    # catalog was read before upload; an empty list means this is the first
    # published BuildGuard catalog. Existing slots are updates, all other
    # entries are additional published builds.
    if is_first_publication:
        message = _(32368).format(display_name, highlighted_url)
    elif replace_index == -1:
        message = _(32369).format(display_name, highlighted_url)
    else:
        message = _(32370).format(display_name, highlighted_url)
    xbmcgui.Dialog().ok(TITLE, message)
    return True

def manage_published_builds():
    """Rename display names or delete published catalog entries and ZIPs."""
    try:
        client = _client()
        if client is None:
            xbmcgui.Dialog().ok(TITLE, _(32250))
            return False
        catalog = _download_creator_catalog(client)
        builds = catalog['builds']
        if not builds:
            xbmcgui.Dialog().ok(TITLE, _(32312))
            return False
        selected = xbmcgui.Dialog().select(
            _(32313), [item['name'] for item in builds])
        if selected < 0:
            return False
        action = xbmcgui.Dialog().select(_(32314), [_(32316), _(32317)])
        if action < 0:
            return False
        entry = builds[selected]
        if action == 0:
            new_name = xbmcgui.Dialog().input(
                _(32307), defaultt=entry['name'], type=xbmcgui.INPUT_ALPHANUM).strip()
            if not new_name or new_name == entry['name']:
                return False
            if any(i != selected and item['name'].casefold() == new_name.casefold()
                   for i, item in enumerate(builds)):
                xbmcgui.Dialog().ok(TITLE, _(32308).format(new_name))
                return False
            entry['name'] = new_name
            _upload_catalog(client, catalog)
            xbmcgui.Dialog().ok(TITLE, _(32318).format(new_name))
            return True
        if not xbmcgui.Dialog().yesno(TITLE, _(32319).format(entry['name'], entry['filename'])):
            return False
        try:
            client.files_delete_v2(entry['path'])
        except Exception as exc:
            if 'not_found' not in str(exc).lower():
                raise
        del builds[selected]
        _upload_catalog(client, catalog)
        xbmcgui.Dialog().ok(TITLE, _(32320).format(entry['name']))
        return True
    except Exception as exc:
        safe_error = _safe_text(exc, _credentials())
        xbmc.log('[BuildGuard][Dropbox catalog management] ' + safe_error, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32321).format(safe_error or type(exc).__name__))
        return False


def show_public_link():
    """Show the preferred share URL and retain the original Dropbox URL."""
    original_url = ADDON.getSettingString('buildguard_public_url').strip()
    short_url = ADDON.getSettingString('buildguard_short_url').strip()
    if not original_url:
        xbmcgui.Dialog().ok(TITLE, _(32284))
        return False
    if short_url:
        text = _(32302).format(short_url, original_url)
    else:
        text = _(32303).format(original_url)
    xbmcgui.Dialog().textviewer(_(32285), text)
    return True


def _provider_index():
    try:
        return ADDON.getSettingInt('publication_provider')
    except Exception:
        try:
            return int(ADDON.getSetting('publication_provider') or '0')
        except (TypeError, ValueError):
            return 0


def _provider_published_url():
    """Return the preferred saved link for the currently selected provider."""
    if _provider_index() == 1:
        short_id, public_id = 'google_drive_short_url', 'google_drive_public_url'
    else:
        short_id, public_id = 'dropbox_short_url', 'dropbox_public_url'
    return (ADDON.getSettingString(short_id).strip()
            or ADDON.getSettingString(public_id).strip())


def _prompt_consumer_url(default=''):
    url = xbmcgui.Dialog().input(
        _(32270),
        defaultt=default,
        type=xbmcgui.INPUT_ALPHANUM,
    ).strip()
    if url:
        ADDON.setSettingString('buildguard_index_url', url)
    return url


def _consumer_url():
    """Prefer the active provider's saved TinyURL/direct catalog link."""
    url = _provider_published_url()
    if not url:
        url = ADDON.getSettingString('buildguard_short_url').strip()
    if not url:
        url = ADDON.getSettingString('buildguard_public_url').strip()
    if not url:
        url = ADDON.getSettingString('buildguard_index_url').strip()
        if url == 'https://':
            url = ''
    if url:
        ADDON.setSettingString('buildguard_index_url', url)
        return url
    return _prompt_consumer_url()


def _direct_metadata_url(url):
    """Normalize a public URL without introducing Dropbox credentials."""
    parsed = urllib.parse.urlsplit(url.strip())
    if parsed.scheme.lower() != 'https' or not parsed.netloc:
        raise ValueError(_(32275))

    # Public Dropbox share links otherwise often return an HTML preview page.
    if parsed.netloc.lower() in ('dropbox.com', 'www.dropbox.com'):
        query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
        query = [(key, value) for key, value in query if key.lower() != 'dl']
        query.append(('dl', '1'))
        parsed = parsed._replace(query=urllib.parse.urlencode(query))
    return urllib.parse.urlunsplit(parsed)


def _read_public_json(url):
    request = urllib.request.Request(
        _direct_metadata_url(url),
        headers={'User-Agent': 'BuildGuard/' + ADDON.getAddonInfo('version')},
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        content_type = (response.headers.get('Content-Type') or '').lower()
        length = response.headers.get('Content-Length')
        try:
            too_large = bool(length) and int(length) > 262144
        except (TypeError, ValueError):
            too_large = False
        if too_large:
            raise ValueError(_(32276))
        data = response.read(262145)
    if len(data) > 262144:
        raise ValueError(_(32276))
    if 'text/html' in content_type:
        raise ValueError(_(32277))
    return json.loads(data.decode('utf-8-sig'))


def _validated_build_entry(data):
    if not isinstance(data, dict):
        raise ValueError(_(32274).format('build'))
    values = {}
    for field in ('name', 'version', 'filename', 'path', 'download_url', 'created'):
        value = data.get(field)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(_(32274).format(field))
        values[field] = value.strip()
    if not values['filename'].lower().endswith('.zip'):
        raise ValueError(_(32274).format('filename'))
    if os.path.basename(values['path'].replace('\\', '/')) != values['filename']:
        raise ValueError(_(32274).format('path'))
    parsed = urllib.parse.urlsplit(values['download_url'])
    if parsed.scheme.lower() != 'https' or not parsed.netloc:
        raise ValueError(_(32274).format('download_url'))
    return values


def _validated_builds(data):
    """Validate Phase-3 catalogs and remain compatible with Phase-1 JSON."""
    legacy = _entry_from_legacy(data)
    if legacy:
        return [_validated_build_entry(legacy)]
    if not isinstance(data, dict) or not isinstance(data.get('builds'), list):
        raise ValueError(_(32274).format('builds'))
    builds = [_validated_build_entry(item) for item in data['builds']]
    if not builds:
        raise ValueError(_(32322))
    return builds


def _select_public_build(builds):
    if len(builds) == 1:
        return builds[0]
    labels = [_(32323).format(item['name'], _display_created_date(item['created']))
              for item in builds]
    selected = xbmcgui.Dialog().select(_(32324), labels)
    return builds[selected] if selected >= 0 else None


def _display_created(value):
    try:
        parsed = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
        return parsed.astimezone().strftime('%d.%m.%Y %H:%M:%S')
    except (TypeError, ValueError, OSError):
        return value


def _display_created_date(value):
    """Nur das Datum (TT.MM.JJJJ), ohne Uhrzeit - fuer die kompakte
    Build-Auswahlliste. Zeigt bewusst NICHT BuildGuards eigene
    Addon-Version (die vorher hier stand und faelschlich wie eine
    Build-Versionsnummer aussah, obwohl sie nur die BuildGuard-Version
    des jeweiligen Veroeffentlichers war)."""
    try:
        parsed = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
        return parsed.astimezone().strftime('%d.%m.%Y')
    except (TypeError, ValueError, OSError):
        return value


def _load_public_builds():
    """Load the catalog and offer manual entry only if the saved link fails."""
    url = _consumer_url()
    if not url:
        return None
    try:
        return _validated_builds(_read_public_json(url))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError,
            ValueError, json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
        safe_error = _safe_text(exc)
        if not xbmcgui.Dialog().yesno(TITLE, _(32430).format(safe_error or type(exc).__name__)):
            raise
        replacement = _prompt_consumer_url(url)
        if not replacement:
            return None
        return _validated_builds(_read_public_json(replacement))


def check_public_build_info():
    """Download and validate buildguard.json, but never download its ZIP."""
    url = _consumer_url()
    if not url:
        return False
    try:
        builds = _load_public_builds()
        if builds is None:
            return False
        info = _select_public_build(builds)
        if info is None:
            return False
        xbmcgui.Dialog().ok(
            TITLE,
            _(32325).format(
                info['name'], info['filename'],
                _display_created(info['created']),
            ),
        )
        return True
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError,
            ValueError, json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
        safe_error = _safe_text(exc)
        xbmc.log('[BuildGuard][Consumer buildguard.json] ' + safe_error, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32272).format(safe_error or type(exc).__name__))
        return False


def install_public_build(fresh_start_callback):
    """Read buildguard.json, let the user pick a build, then install it via
    denselben Fresh-Start-basierten Weg wie jede andere Build-Quelle
    (builds.install_build()) - identisch zum lokalen Weg (run_restore_flow)
    und den fest konfigurierten Wizard-Slot-Builds. Kein separater, sanfter
    Restore-Pfad mehr fuer online veroeffentlichte Builds."""
    url = _consumer_url()
    if not url:
        return False
    try:
        public_builds = _load_public_builds()
        if public_builds is None:
            return False
        info = _select_public_build(public_builds)
        if info is None:
            return False
        download_url = _direct_metadata_url(info['download_url'])
        # Ab hier exakt derselbe zentrale Installationspfad wie bei
        # "Build Local": Bestaetigungsdialog -> Quelle beziehen -> Archiv
        # pruefen -> Fresh Start -> Entpacken -> Binary-Dummies/FirstRun ->
        # Neustart. Kodi uebernimmt danach die Binary-Aktualisierung.
        xbmc.log('[BuildGuard][Meine Builds] Build ausgewaehlt; uebergebe an gemeinsamen Installer', xbmc.LOGINFO)
        from resources.lib.modules import builds
        return builds.install_build(download_url, fresh_start_callback)
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError,
            ValueError, json.JSONDecodeError, UnicodeDecodeError, OSError, RuntimeError) as exc:
        safe_error = _safe_text(exc)
        xbmc.log('[BuildGuard][Consumer install] ' + safe_error, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32290).format(safe_error or type(exc).__name__))
        return False


def upload_test_file():
    """Upload one tiny text file without touching normal backup behavior."""
    try:
        client = _client()
        if client is None:
            xbmcgui.Dialog().ok(TITLE, _(32250))
            return False

        from dropbox.files import WriteMode

        folder = _dropbox_folder()
        _ensure_dropbox_folder(client, folder)
        remote_path = (folder + '/buildguard-test.txt') if folder else '/buildguard-test.txt'
        timestamp = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
        addon_version = ADDON.getAddonInfo('version')
        kodi_version = xbmc.getInfoLabel('System.BuildVersion') or 'unknown'
        content = (
            'BuildGuard Dropbox Test\n\n'
            'Date: {}\n'
            'BuildGuard: {}\n'
            'Kodi: {}\n'
        ).format(timestamp, addon_version, kodi_version).encode('utf-8')

        client.files_upload(content, remote_path, mode=WriteMode.overwrite, mute=True)
        xbmcgui.Dialog().ok(TITLE, _(32261).format(remote_path))
        return True
    except Exception as exc:
        safe_error = _safe_text(exc, _credentials())
        xbmc.log('[BuildGuard][Dropbox test upload] ' + safe_error, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITLE, _(32262).format(safe_error or type(exc).__name__))
        return False

def test_connection():
    try:
        client = _client()
        if client is None:
            xbmcgui.Dialog().ok(TITLE, _(32250))
            return False
        account = client.users_get_current_account()
        display_name = getattr(getattr(account, 'name', None), 'display_name', '')
        identity = display_name or getattr(account, 'email', '') or getattr(account, 'account_id', '')
        xbmcgui.Dialog().ok(TITLE, _(32249).format(identity))
        return True
    except Exception:
        xbmcgui.Dialog().ok(TITLE, _(32250))
        return False


def disconnect():
    path = token_path()
    if not xbmcvfs.exists(path):
        xbmcgui.Dialog().ok(TITLE, _(32252))
        return False
    xbmcvfs.delete(path)
    from resources.lib.modules import cloud_status
    cloud_status.refresh()
    xbmcgui.Dialog().ok(TITLE, _(32251))
    return True


def run(action):
    if action == 'authorize':
        return authorize()
    if action == 'disconnect':
        return disconnect()
    if action == 'upload_test':
        return upload_test_file()
    if action == 'check_public_build':
        return check_public_build_info()
    if action == 'publish_backup':
        return publish_local_backup()
    if action == 'show_public_link':
        return show_public_link()
    if action == 'manage_published_builds':
        return manage_published_builds()
    if action == 'install_public_build':
        return install_public_build()
    return test_connection()
