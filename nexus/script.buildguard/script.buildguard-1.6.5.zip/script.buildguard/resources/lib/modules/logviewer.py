# SPDX-License-Identifier: GPL-3.0-or-later
"""BuildGuard log viewer, local backup and anonymous paste.rs uploader."""
import datetime
import ipaddress
import json
import os
import re
import zipfile
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.modules import control

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_TITLE = ADDON.getAddonInfo('name') or 'BuildGuard'
ADDON_VERSION = ADDON.getAddonInfo('version') or '1.6.5'
PASTE_RS_URL = 'https://paste.rs'
MAX_SAVED_LINKS = 20
MAX_LOG_SIZE = 10 * 1024 * 1024


def _(string_id, *args):
    text = ADDON.getLocalizedString(string_id)
    return text.format(*args) if args else text


def _translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except AttributeError:
        return xbmc.translatePath(path)


def _read_text(path):
    handle = xbmcvfs.File(path, 'rb')
    try:
        data = handle.read()
    finally:
        handle.close()
    return data.decode('utf-8', errors='replace') if isinstance(data, bytes) else data


def _write_text(path, text):
    handle = xbmcvfs.File(path, 'w')
    try:
        handle.write(text)
    finally:
        handle.close()


def _history_path():
    profile = _translate(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'log_uploads.json')


def _load_saved_links():
    path = _history_path()
    if not xbmcvfs.exists(path):
        return []
    try:
        data = json.loads(_read_text(path))
        if not isinstance(data, list):
            return []
        return [entry for entry in data if isinstance(entry, dict) and entry.get('url')][:MAX_SAVED_LINKS]
    except Exception as error:
        xbmc.log('{}: could not read link history: {}'.format(ADDON_ID, error), xbmc.LOGWARNING)
        return []


def _save_share_link(url, privacy_mode):
    entries = _load_saved_links()
    entries.insert(0, {
        'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'privacy_mode': bool(privacy_mode),
        'url': url,
    })
    path = _history_path()
    temp_path = path + '.tmp'
    payload = json.dumps(entries[:MAX_SAVED_LINKS], ensure_ascii=False, indent=2)
    try:
        _write_text(temp_path, payload)
        if xbmcvfs.exists(path) and not xbmcvfs.delete(path):
            raise IOError('Could not replace existing link history')
        if not xbmcvfs.rename(temp_path, path):
            raise IOError('Could not activate new link history')
    finally:
        if xbmcvfs.exists(temp_path):
            xbmcvfs.delete(temp_path)


def _clear_saved_links():
    path = _history_path()
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)


def _format_date(value):
    try:
        return datetime.datetime.strptime(value, '%Y-%m-%d %H:%M:%S').strftime('%d.%m.%Y %H:%M')
    except Exception:
        return value or '-'


def _privacy_label(entry):
    return _(32517) if entry.get('privacy_mode', False) else _(32518)


def _show_saved_links(dialog):
    entries = _load_saved_links()
    if not entries:
        dialog.ok(ADDON_TITLE, _(32516))
        return

    options = []
    for index, entry in enumerate(entries):
        age = _(32522) if index == 0 else _(32523)
        options.append('{} - {} - {} - {}'.format(
            age, _format_date(entry.get('created', '')), _privacy_label(entry), entry.get('url', '')
        ))
    options.extend([_(32519), _(32504)])

    choice = dialog.select(_(32515), options)
    if choice < 0 or choice == len(options) - 1:
        return
    if choice == len(entries):
        if dialog.yesno(ADDON_TITLE, _(32520), nolabel=_(32505), yeslabel=_(32521)):
            _clear_saved_links()
            dialog.ok(ADDON_TITLE, _(32524))
        return

    entry = entries[choice]
    body = _(32525,
             _(32522) if choice == 0 else _(32523),
             _format_date(entry.get('created', '')),
             _privacy_label(entry),
             entry.get('url', ''))
    dialog.textviewer(_(32515), body, usemono=False)


def _redact_url_credentials(match):
    return re.sub(r'(?i)(://)([^/@\s:]+):([^/@\s]+)@', r'\1[USER]:[PASSWORD]@', match.group(0))


def _redact_ip(match):
    original = match.group(0)
    value = original.strip('[]')
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        return original
    return original if address.is_loopback else '[IP]'


def _sanitize_log(text):
    text = re.sub(r'(?i)\b(?:https?|ftp|ftps|smb|nfs)://[^\s<>"\']+', _redact_url_credentials, text)
    text = re.sub(
        r'(?i)\b(password|passwd|pwd|token|access[_-]?token|refresh[_-]?token|api[_-]?key|apikey|secret|authorization|cookie|session(?:id)?)\b'
        r'(\s*[:=]\s*)([^\s,;\]\}\)]+)',
        lambda m: '{}{}[REDACTED]'.format(m.group(1), m.group(2)), text)
    text = re.sub(r'(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+', r'\1 [REDACTED]', text)
    text = re.sub(r'(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b', '[EMAIL]', text)
    text = re.sub(r'(?i)\b(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}\b', '[MAC]', text)
    text = re.sub(r'(?<![\w:])(?:\d{1,3}\.){3}\d{1,3}(?![\w:])', _redact_ip, text)
    text = re.sub(r'(?<![\w:])(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}(?![\w:])', _redact_ip, text)
    text = re.sub(r'(?i)([A-Z]:\\Users\\)[^\\\r\n]+', r'\1[USER]', text)
    text = re.sub(r'(?i)(/home/)[^/\s]+', r'\1[USER]', text)
    text = re.sub(r'(?i)(/Users/)[^/\s]+', r'\1[USER]', text)
    text = re.sub(r'(?im)(Local hostname:\s*).*$', r'\1[HOSTNAME]', text)
    return text


def _network_error(error):
    if isinstance(error, HTTPError):
        try:
            body = error.read().decode('utf-8', errors='replace').strip()
        except Exception:
            body = ''
        return 'HTTP {}: {}'.format(error.code, body or error.reason)
    if isinstance(error, URLError):
        return str(error.reason)
    return str(error)


def _upload_to_paste_rs(text):
    request = Request(
        PASTE_RS_URL,
        data=text.encode('utf-8'),
        headers={
            'Content-Type': 'text/plain; charset=utf-8',
            'User-Agent': 'BuildGuard-Kodi-Log/{}'.format(ADDON_VERSION),
        },
        method='POST',
    )
    with urlopen(request, timeout=45) as response:
        result = response.read().decode('utf-8', errors='replace').strip()
    if not re.match(r'^https?://paste\.rs/[A-Za-z0-9][^\s]*$', result):
        raise RuntimeError(result or _(32513))
    return result


def _create_local_zip(dialog, selected_log):
    destination = dialog.browse(3, _(32506), 'files')
    if not destination:
        return
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    base_name = os.path.splitext(os.path.basename(selected_log))[0]
    zip_name = '{}_{}.zip'.format(base_name, timestamp)
    temp_zip = os.path.join(_translate('special://temp/'), zip_name)
    try:
        with zipfile.ZipFile(temp_zip, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.write(selected_log, os.path.basename(selected_log))
        separator = '' if destination.endswith(('/', '\\')) else '/'
        final_path = destination + separator + zip_name
        if not xbmcvfs.copy(temp_zip, final_path):
            raise RuntimeError(_(32514))
        dialog.ok(ADDON_TITLE, _(32507, final_path))
    except Exception as error:
        xbmc.log('{}: local log ZIP failed: {}'.format(ADDON_ID, error), xbmc.LOGERROR)
        dialog.ok(ADDON_TITLE, _(32508, error))
    finally:
        if xbmcvfs.exists(temp_zip):
            xbmcvfs.delete(temp_zip)


def _upload_log(dialog, selected_log, privacy_mode):
    message = _(32509) if privacy_mode else _(32510)
    if not dialog.yesno(ADDON_TITLE, message, nolabel=_(32505), yeslabel=_(32511)):
        return

    try:
        size = os.path.getsize(selected_log)
    except OSError:
        size = 0
    if size > MAX_LOG_SIZE:
        dialog.ok(ADDON_TITLE, _(32530, MAX_LOG_SIZE // (1024 * 1024)))
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_TITLE, _(32512))
    try:
        text = _read_text(selected_log)
        if not text.strip():
            dialog.ok(ADDON_TITLE, _(32531))
            return
        if privacy_mode:
            text = _sanitize_log(text)
        url = _upload_to_paste_rs(text)
        _save_share_link(url, privacy_mode)
        xbmc.log('{}: log uploaded successfully ({})'.format(ADDON_ID, 'privacy' if privacy_mode else 'complete'), xbmc.LOGINFO)
        dialog.textviewer(_(32526), _(32527, url), usemono=False)
    except Exception as error:
        xbmc.log('{}: log upload failed: {}'.format(ADDON_ID, error), xbmc.LOGERROR)
        dialog.ok(ADDON_TITLE, _(32528, _network_error(error)))
    finally:
        progress.close()


def _available_logs():
    log_path = _translate('special://logpath')
    names = ('kodi.log', 'kodi.old.log', 'spmc.log', 'spmc.old.log', 'tvmc.log',
             'freetelly.log', 'ftmc.log', 'firemc.log', 'nodi.log')
    result = []
    for name in names:
        path = os.path.join(log_path, name)
        if xbmcvfs.exists(path):
            result.append((name, path))
    return result


def _select_log(dialog):
    """Let the user choose one of the available Kodi log files."""
    logs = _available_logs()
    if not logs:
        dialog.ok(ADDON_TITLE, _(32529))
        return None

    selected = control.selectDialog([item[0] for item in logs])
    if selected < 0:
        return None
    return logs[selected][1]


def _paste_rs_menu(dialog):
    """Open the paste.rs privacy selection and upload the chosen log."""
    actions = [_(32502), _(32503), _(32504)]
    action = control.selectDialog(actions)
    if action < 0 or action == 2:
        return

    selected_log = _select_log(dialog)
    if not selected_log:
        return

    _upload_log(dialog, selected_log, privacy_mode=(action == 0))


def _upload_menu(dialog):
    """Group upload-related actions in one submenu."""
    actions = [_(32533), _(32515), _(32504)]
    action = control.selectDialog(actions)
    if action < 0 or action == 2:
        return
    if action == 0:
        _paste_rs_menu(dialog)
    elif action == 1:
        _show_saved_links(dialog)


def logView():
    dialog = xbmcgui.Dialog()
    actions = [_(32500), _(32501), _(32532), _(32504)]
    action = control.selectDialog(actions)
    if action < 0 or action == 3:
        return

    if action == 2:
        _upload_menu(dialog)
        return

    selected_log = _select_log(dialog)
    if not selected_log:
        return

    if action == 0:
        from resources.lib.modules import TextViewer
        TextViewer.moduleName = _(32500)
        TextViewer.text_view(selected_log)
    elif action == 1:
        _create_local_zip(dialog, selected_log)
