# SPDX-License-Identifier: GPL-3.0-or-later
"""Kodi directory/menu construction for BuildGuard.

This module only builds directory entries. It intentionally contains no
maintenance, backup, restore, download or destructive file operations.
"""

import os
import sys
import time

import xbmc
import xbmcgui
import xbmcplugin

try:
    from urllib.parse import quote_plus
except ImportError:  # pragma: no cover - legacy Python fallback
    from urllib import quote_plus

from resources.lib.modules import control, maintenance
from resources.lib.modules.backtothefuture import PY2, unicode


BUILD_COLORS = ('lime', 'skyblue', 'cyan', 'yellow', 'purple')



def add_directory_item(name, url, action, icon, fanart, description,
                       is_folder=False, icon_image='DefaultFolder.png',
                       extra_params=None):
    """Add one item to the active Kodi plugin directory."""
    addon_icon = control.addonIcon()
    if icon is None or icon == '':
        icon = addon_icon

    plugin_url = (
        sys.argv[0]
        + '?url=' + quote_plus(url)
        + '&action=' + str(action)
        + '&name=' + quote_plus(name)
        + '&icon=' + quote_plus(icon)
        + '&fanart=' + quote_plus(fanart)
        + '&description=' + quote_plus(description)
    )
    for key, value in (extra_params or {}).items():
        plugin_url += '&' + quote_plus(str(key)) + '=' + quote_plus(str(value))

    if PY2:
        item = xbmcgui.ListItem(
            name,
            iconImage=icon_image,
            thumbnailImage=icon,
        )
    else:
        item = xbmcgui.ListItem(name)
        item.setArt({'icon': icon_image, 'thumbnailImage': icon})

    item.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
    item.setProperty('Fanart_Image', fanart)
    return xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=plugin_url,
        listitem=item,
        isFolder=is_folder,
    )


def show_categories(localize):
    """Render the BuildGuard root menu."""
    icon = control.addonIcon()
    fanart = control.addonFanart()
    entries = (
        ('[COLOR red][B]' + localize(32000) + '[/B][/COLOR]', 'url', 'fresh_start', False),
        ('[COLOR lime][B]' + localize(32001) + '[/B][/COLOR]', 'ur', 'builds', True),
        ('[COLOR white][B]' + localize(32002) + '[/B][/COLOR]', 'ur', 'backup_restore', True),
        ('[COLOR white][B]' + localize(32003) + '[/B][/COLOR]', 'ur', 'maintenance', True),
        ('[COLOR white][B]' + localize(32004) + '[/B][/COLOR]', 'ur', 'log_tools', False),
        ('[COLOR white][B]' + localize(32005) + '[/B][/COLOR]', 'ur', 'settings', False),
        ('[COLOR white][B]' + localize(32431) + '[/B][/COLOR]', 'ur', 'help_setup', True),
    )
    for label, url, action, is_folder in entries:
        add_directory_item(label, url, action, icon, fanart, '', is_folder=is_folder)



def show_help_setup(localize):
    """Render concise built-in setup guidance."""
    icon = control.addonIcon()
    fanart = control.addonFanart()
    topics = (
        (32432, 'dropbox'),
        (32433, 'google_drive'),
        (32434, 'cloud_keys'),
        (32435, 'first_publish'),
        (32436, 'install_build'),
    )
    for label_id, topic in topics:
        add_directory_item(
            localize(label_id), 'url', 'help_topic', icon, fanart, '',
            extra_params={'topic': topic},
        )


def show_help_topic(localize, topic):
    """Show one localized help page without changing any settings."""
    pages = {
        'dropbox': (32432, 32437),
        'google_drive': (32433, 32438),
        'cloud_keys': (32434, 32439),
        'first_publish': (32435, 32440),
        'install_build': (32436, 32441),
    }
    title_id, text_id = pages.get(topic, (32431, 32442))

    if topic in ('dropbox', 'google_drive'):
        language = xbmc.getLanguage(xbmc.ISO_639_1).lower()
        suffix = 'de' if language.startswith('de') else 'en'
        help_path = os.path.join(
            control.addonPath,
            'resources',
            'docs',
            topic + '_' + suffix + '.txt',
        )
        try:
            with open(help_path, 'r', encoding='utf-8') as help_file:
                help_text = help_file.read()
            if help_text.strip():
                xbmcgui.Dialog().textviewer(localize(title_id), help_text)
                return
        except (IOError, OSError, UnicodeError):
            pass

    xbmcgui.Dialog().textviewer(localize(title_id), localize(text_id))


def show_backup_restore(localize):
    """Render local backup, provider publishing and consumer install actions."""
    from resources.lib.modules import publication
    provider = publication.provider_name()
    icon = control.addonIcon()
    fanart = control.addonFanart()
    entries = (
        (localize(32291), 'backup_local'),
        (localize(32292), 'restore_local'),
        (localize(32347), 'publish_backup'),
        (localize(32348), 'show_public_link'),
        (localize(32349), 'manage_published_builds'),
    )
    for label, action in entries:
        add_directory_item(label, 'url', action, icon, fanart, '')

def show_maintenance(localize):
    """Render maintenance actions without executing them."""
    icon = control.addonIcon()
    fanart = control.addonFanart()
    next_cleanup = maintenance.getNextMaintenance()
    if next_cleanup > 0:
        formatted = time.strftime(
            '%a, %d %b %Y %I:%M:%S %p %Z',
            time.localtime(next_cleanup),
        )
        add_directory_item(
            localize(32009) % formatted,
            'xxx',
            'xxx',
            None,
            fanart,
            '',
            is_folder=False,
            icon_image='DefaultIconInfo.png',
        )

    entries = (
        (localize(32006), 'clear_cache'),
        (localize(32007), 'clear_packages'),
        (localize(32008), 'clear_thumbs'),
        (localize(32090), 'clear_pycache'),
        ('[COLOR red][B]' + localize(32097) + '[/B][/COLOR]', 'truncate_tables'),
        ('[COLOR orange][B]' + localize(32092) + '[/B][/COLOR]', 'complete_build_cleanup'),
    )
    for label, action in entries:
        add_directory_item(label, 'url', action, icon, fanart, '')


def show_builds(addon):
    """Render configured build sources plus install-from-link and whitelist actions."""
    fanart_default = control.addonFanart()
    icon = control.addonIcon()
    for index, color in enumerate(BUILD_COLORS, start=1):
        if control.setting('enable_wiz{0}'.format(index)) == 'false':
            continue

        try:
            name = unicode(addon.getSetting('name{0}'.format(index)))
            url = unicode(addon.getSetting('url{0}'.format(index)))
            image = unicode(addon.getSetting('img{0}'.format(index)))
            fanart = image or fanart_default
            add_directory_item(
                '[COLOR {0}][B][Build][/B][/COLOR] {1}'.format(color, name),
                url,
                'install_build',
                image,
                fanart,
                'My custom Build',
                is_folder=False,
            )
        except Exception:
            # Preserve the legacy behavior: one incomplete build slot must not
            # prevent the remaining configured slots from being shown.
            continue

    add_directory_item(
        addon.getLocalizedString(32295), 'url', 'install_public_build',
        icon, fanart_default, '',
    )
    add_directory_item(
        addon.getLocalizedString(32989), 'url', 'manage_whitelist',
        icon, fanart_default, '',
    )
