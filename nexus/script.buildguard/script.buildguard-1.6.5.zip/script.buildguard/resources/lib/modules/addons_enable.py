# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""First-start addon activation modeled on Simple Wizard.

BuildGuard does not verify binary compatibility here. Kodi receives repository
and local-addon refresh commands and remains solely responsible for selecting
and installing the correct platform-specific binary versions.
"""
from datetime import datetime
import glob
import os
import re
import sqlite3
from xml.dom.minidom import parse

import xbmc
import xbmcaddon
import xbmcvfs

ADDONS_PATH = xbmcvfs.translatePath('special://home/addons')
DATABASE_PATH = xbmcvfs.translatePath('special://database')


def _latest_addons_db():
    newest = None
    number = -1
    try:
        for filename in os.listdir(DATABASE_PATH):
            match = re.match(r'^Addons(\d+)\.db$', filename, re.I)
            if match and int(match.group(1)) > number:
                number = int(match.group(1))
                newest = os.path.join(DATABASE_PATH, filename)
    except OSError:
        return None
    return newest


def enable_db(addon_id):
    db = _latest_addons_db()
    if not db:
        xbmc.log('[BuildGuard FirstRun] Keine Addons-Datenbank gefunden: {}'.format(addon_id), xbmc.LOGWARNING)
        return
    conn = sqlite3.connect(db)
    try:
        cur = conn.cursor()
        cur.execute('SELECT id, addonID, enabled FROM installed WHERE addonID = ?', (addon_id,))
        found = cur.fetchone()
        if found is None:
            stamp = str(datetime.now())[:-7]
            cur.execute('INSERT INTO installed (addonID, enabled, installDate) VALUES (?,?,?)',
                        (addon_id, '1', stamp))
        else:
            cur.execute('UPDATE installed SET enabled = ? WHERE addonID = ?', (1, addon_id))
        conn.commit()
    except Exception as exc:
        xbmc.log('[BuildGuard FirstRun] Addon {} konnte nicht aktiviert werden: {}'.format(addon_id, exc), xbmc.LOGINFO)
    finally:
        conn.close()


def force_update():
    xbmc.log('[BuildGuard FirstRun] Updating addon repositories', xbmc.LOGINFO)
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.log('[BuildGuard FirstRun] Updating local addons', xbmc.LOGINFO)
    xbmc.executebuiltin('UpdateLocalAddons')


def enable_addons():
    addon_xmls = glob.glob(os.path.join(ADDONS_PATH, '*/addon.xml'))
    addon_xmls.sort()
    addon_ids = []
    for xml in addon_xmls:
        try:
            root = parse(xml)
            addon_id = root.documentElement.getAttribute('id')
            if addon_id:
                addon_ids.append(addon_id)
        except Exception:
            pass

    disabled = []
    for addon_id in addon_ids:
        try:
            xbmcaddon.Addon(id=addon_id)
        except Exception:
            disabled.append(addon_id)

    for addon_id in disabled:
        try:
            enable_db(addon_id)
        except Exception:
            pass

    force_update()
    xbmc.log('[BuildGuard FirstRun] {} Addon(s) geprueft, {} in DB aktiviert; Kodi uebernimmt Binary-Auswahl.'.format(
        len(addon_ids), len(disabled)), xbmc.LOGINFO)
