# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
"""
resources/lib/modules/buildbackup.py - Backend-Logik fuer die in
BuildGuard integrierte Build-Backup/Restore-Funktion.
Erstellt eine ZIP-Datei des installierten Builds mit identischer
Original-Ordnerstruktur (addons / media / userdata als Pfade innerhalb
der ZIP) und kann diese auch wiederherstellen.

Plattformunabhängig (Windows, Linux, Raspberry Pi/LibreELEC, Android):
 - special:// Pfade werden über xbmcvfs.translatePath aufgelöst
 - Alle Datei-/Ordner-Operationen laufen über xbmcvfs (nicht über das
   Python os/shutil-Modul), damit auch Netzwerkziele (smb://, nfs://)
   und Android-Speicherpfade als Backup-Ziel funktionieren. Die ZIP
   selbst wird zunächst lokal in special://temp/ gebaut (Pythons
   zipfile-Modul braucht einen echten lokalen Pfad) und danach per
   xbmcvfs.copy an den eigentlichen (ggf. nicht-lokalen) Zielort kopiert.

Ablauf Backup:
 - Vor dem Start wird per virtueller Tastatur (xbmc.Keyboard) nach einem
   Backup-Namen gefragt (leer = Zeitstempel)
 - /addons wird gesichert, __pycache__- und .pyc-Dateien ausgeschlossen
 - Die aktuelle Addons*.db wird konsistent in eine temporäre Datei kopiert;
   nur diese Backup-Kopie wird wie Truncate Tables geleert und per VACUUM
   verkleinert. Die laufende Kodi-Datenbank bleibt unverändert.
 - /media wird 1:1 gesichert (falls vorhanden)
 - /userdata wird gesichert, dabei werden Cache, Packages und Thumbnails
   NICHT mitgesichert; für Thumbnails wird aber ein leerer
   Ordner-Eintrag in die ZIP geschrieben, damit die Struktur beim
   Restore stimmt
 - Textures13.db (Texture-Cache-Datenbank) wird ausgeschlossen
 - In /userdata/addon_data/* werden unnötige Unterordner (cache/temp/tmp/
   __pycache__) und Dateien (Logs, Temp-Dateien usw.) ausgeschlossen
 - Nach dem Backup werden Cache, Packages, Thumbnails sowie unnötige
   addon_data-Dateien auf dem laufenden System geleert/entfernt

Ablauf Restore:
 - addons/, userdata/ und media/ werden NICHT vorab gelöscht, sondern
   jede Datei aus der ZIP wird direkt an Ort und Stelle überschrieben
   (kein zweistufiges Löschen+Neuschreiben). Grund: Schlägt bei einer
   unter Windows gesperrten Datei (z.B. Kodis eigene guisettings.xml
   während der Restore läuft) das Neuschreiben fehl, nachdem das Löschen
   bereits gelungen war, wäre die Datei komplett WEG statt nur veraltet -
   bei Kern-Dateien verhindert das sogar den nächsten Programmstart.
   Overwrite-in-place garantiert: eine Datei ist entweder ersetzt oder
   behält ihren alten, funktionierenden Inhalt - nie "gar nichts".
 - Addon-Ordner, die auf der Platte liegen, aber nicht mehr im Backup
   enthalten sind, werden erst NACH erfolgreichem Entpacken aufgeräumt
 - Ausnahme: der eigene, gerade laufende Addon-Ordner (dieses Script)
   wird weder gelöscht noch überschrieben - unter Windows sperrt das
   Betriebssystem gerade ausgeführte Dateien, ein Löschen/Überschreiben
   des eigenen laufenden Codes würde den Restore mitten im Ablauf
   abstürzen lassen
 - Entpackt wird in fester Reihenfolge: zuerst addons/ (Dateien müssen
   auf der Platte liegen), dann media/, zuletzt userdata/ (enthält die
   Datenbank, die den Aktiviert/Deaktiviert-Status jedes Addons trackt)
 - Zusammengehörige SQLite-Dateien (.db/.db-wal/.db-shm/.db-journal)
   werden vorab nicht-destruktiv auf Sperrung geprüft und als Gruppe
   behandelt, damit nie nur ein Teil der Gruppe ersetzt wird (sonst
   drohen "disk I/O error" durch inkonsistente WAL-Zustände)
 - Nach dem Entpacken werden ALLE im addons-Ordner gefundenen Addons
   direkt in der Kodi-Datenbank (Addons*.db, Version wird dynamisch
   ermittelt) als aktiviert markiert - nicht nur dieses Addon selbst -
   damit garantiert der komplette Build wieder aktiv ist
 - Native Binär-Addons (inputstream/PVR/Game-Clients mit 'kodi.binary'
   Extension-Point) werden erkannt und für eine automatische
   Neuinstallation der zum AKTUELLEN System passenden Version vorbereitet
   (Version zurückgesetzt, Einstiegspunkt durch Platzhalter ersetzt) -
   verhindert Abstürze, wenn ein Backup von einem anderen System/einer
   anderen Architektur wiederhergestellt wird
 - Einzelne Dateien, die Kodi während des Restores selbst noch gesperrt
   hält (z.B. geladene Addon-DLLs), werden übersprungen statt die
   komplette Wiederherstellung abzubrechen; am Ende wird gemeldet, was
   übersprungen wurde
"""

import json
import os
import re
import sqlite3
import sys
import time
import zipfile
from xml.etree import ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.modules import credential_guard, maintenance, progress_format
from resources.lib.modules.safezip import UnsafeArchiveError, validate_archive

ADDON_ID = 'script.buildguard'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo('name')


def _(string_id):
    return ADDON.getLocalizedString(string_id)

USERDATA = xbmcvfs.translatePath('special://userdata/')
ADDONS_DIR = xbmcvfs.translatePath('special://home/addons/')
MEDIA_DIR = xbmcvfs.translatePath('special://home/media/')
HOME_DIR = xbmcvfs.translatePath('special://home/')
TEMP_DIR = xbmcvfs.translatePath('special://temp/')
DATABASE_DIR = xbmcvfs.translatePath('special://database/')

# Eigener Addon-Ordner (dieses Script läuft selbst aus addons/ heraus).
# Muss beim Restore unangetastet bleiben - vor allem unter Windows sperrt
# das Betriebssystem gerade ausgeführte Dateien, ein Löschen/Überschreiben
# des eigenen laufenden Codes lässt den Restore mitten im Ablauf abstürzen.
OWN_ADDON_FOLDER = os.path.basename(
    os.path.normpath(xbmcvfs.translatePath(ADDON.getAddonInfo('path'))))

# Dateien, die aus addon_data (und generell) als "nicht benötigt" gelten
JUNK_EXTENSIONS = ('.log', '.tmp', '.temp', '.bak', '.old', '.pyc',
                    '.part', '.crdownload')
JUNK_FILENAMES = ('thumbs.db', '.ds_store')
SENSITIVE_FILENAMES = (
    'dropbox_tokens.json', 'dropbox_oauth_qr.png',
    'google_drive_tokens.json', 'google_drive_oauth_qr.png',
    'buildguard-cloud-keys-private.txt',
)
JUNK_FOLDERS = ('__pycache__', 'cache', 'temp', 'tmp')

# Ordner in /userdata, die beim Backup NICHT mitkopiert (nur geleert) werden
SKIP_USERDATA_FOLDERS = ('cache', 'packages', 'thumbnails')

# Schlüsselwörter, die auf ein Zugangsdaten-Feld in Addon-settings.xml hindeuten
CREDENTIAL_KEYWORDS = ('user', 'pass', 'login', 'token', 'apikey',
                        'api_key', 'secret', 'pin', 'auth')

# Fest hinterlegte, Creator-eigene Dropbox-App-Zugangsdaten (kein
# individuelles Nutzer-Zugangsdatum) - werden in BuildGuards eigener
# settings.xml IMMER entfernt, unabhaengig vom include_credentials-Flag.
CREATOR_ONLY_SETTING_IDS = ('dropbox_app_key', 'dropbox_app_secret')

# Tabellen, die im Backup bewusst leer sein sollen. Die Liste entspricht
# dem bisherigen Truncate-Tables-Werkzeug. Die laufende Kodi-Datenbank
# wird dabei NICHT verändert; bereinigt wird ausschließlich eine temporäre
# SQLite-Kopie, die anschließend in die Backup-ZIP geschrieben wird.
ADDON_DB_TRUNCATE_TABLES = (
    'addonlinkrepo', 'addons', 'package', 'repo', 'update_rules'
)


# ---------------------------------------------------------------------------
# Kleine VFS-Hilfsfunktionen (funktionieren für lokale Pfade genauso wie für
# smb://, nfs:// und Android-Speicherpfade, im Gegensatz zu os.*/shutil.*)
# ---------------------------------------------------------------------------

def ensure_slash(path):
    if not path.endswith('/') and not path.endswith('\\'):
        return path + '/'
    return path


def vfs_isdir(path):
    return xbmcvfs.exists(ensure_slash(path))


def vfs_mkdirs(path):
    try:
        xbmcvfs.mkdirs(ensure_slash(path))
    except Exception as e:
        log('Konnte Ordner {} nicht anlegen: {}'.format(path, e))


def vfs_walk(top):
    """Rekursiver Verzeichnis-Walker über xbmcvfs, analog zu os.walk
    (topdown, 'dirs' kann vom Aufrufer in-place gefiltert werden)."""
    top = ensure_slash(top)
    try:
        dirs, files = xbmcvfs.listdir(top)
    except Exception as e:
        log('Konnte {} nicht lesen: {}'.format(top, e))
        dirs, files = [], []
    yield top, dirs, files
    for d in dirs:
        for x in vfs_walk(top + d):
            yield x

def vfs_rmtree(path, failures=None):
    """Löscht einen Ordner rekursiv (Datei für Datei), da rmdir(force=)
    nicht auf jeder Kodi-Version verfügbar ist. Fehlgeschlagene Löschungen
    (z.B. von Kodi selbst offen gehaltene Dateien wie Addons33.db, geladene
    Addon-DLLs, offene SQLite-Dateien) werden optional in 'failures'
    gesammelt statt nur geloggt zu werden."""
    path = ensure_slash(path)
    try:
        dirs, files = xbmcvfs.listdir(path)
    except Exception:
        dirs, files = [], []
    for f in files:
        try:
            xbmcvfs.delete(path + f)
        except Exception as e:
            log('Konnte Datei {} nicht entfernen: {}'.format(path + f, e))
            if failures is not None:
                failures.append(path + f)
    for d in dirs:
        vfs_rmtree(path + d, failures)
    try:
        xbmcvfs.rmdir(path)
    except Exception as e:
        log('Konnte Ordner {} nicht entfernen: {}'.format(path, e))


def vfs_read_text(path):
    f = xbmcvfs.File(path)
    try:
        data = f.read()
    finally:
        f.close()
    if isinstance(data, bytes):
        data = data.decode('utf-8', errors='ignore')
    return data

def is_credential_key(key):
    key = key.lower()
    return any(kw in key for kw in CREDENTIAL_KEYWORDS)


def sanitize_sources_xml(content):
    """Entfernt eingebettete Zugangsdaten aus sources.xml (Kodi 21)."""
    content = re.sub(r'(\w+://)[^/@\s]+:[^/@\s]+@', r'\1', content)
    content = re.sub(r'(<login>).*?(</login>)', r'\1\2', content,
                      flags=re.IGNORECASE | re.DOTALL)
    content = re.sub(r'(<password>).*?(</password>)', r'\1\2', content,
                      flags=re.IGNORECASE | re.DOTALL)
    return content


def sanitize_addon_settings_xml(content):
    """Leert vermutliche Zugangsdaten-Werte in einer Addon settings.xml."""
    def repl_element(match):
        opening, sid, closing = match.group(1), match.group(2), match.group(4)
        if is_credential_key(sid):
            return opening + closing
        return match.group(0)

    content = re.sub(
        r'(<setting[^>]*\bid="([^"]*)"[^>]*>)(.*?)(</setting>)',
        repl_element, content, flags=re.IGNORECASE | re.DOTALL
    )

    def repl_attr(match):
        sid = match.group(2)
        if is_credential_key(sid):
            full = match.group(0)
            full = re.sub(r'value="[^"]*"', 'value=""', full)
            return full
        return match.group(0)

    content = re.sub(
        r'(<setting[^>]*\bid="([^"]*)"[^>]*/>)',
        repl_attr, content, flags=re.IGNORECASE
    )
    return content


def strip_setting_ids(content, setting_ids):
    """Leert die Werte exakt benannter Settings-IDs in einer Addon
    settings.xml - unabhaengig von CREDENTIAL_KEYWORDS/is_credential_key().

    Im Unterschied zu sanitize_addon_settings_xml() (die auf Basis von
    Schluesselwoertern arbeitet und vom include_credentials-Flag des
    Nutzers gesteuert wird) betrifft dies eine feste, kleine Liste
    konkreter IDs, die UNABHAENGIG von diesem Flag immer entfernt werden
    sollen (siehe CREATOR_ONLY_SETTING_IDS)."""
    ids = set(setting_ids)

    def repl_element(match):
        opening, sid, closing = match.group(1), match.group(2), match.group(4)
        if sid in ids:
            return opening + closing
        return match.group(0)

    content = re.sub(
        r'(<setting[^>]*\bid="([^"]*)"[^>]*>)(.*?)(</setting>)',
        repl_element, content, flags=re.IGNORECASE | re.DOTALL
    )

    def repl_attr(match):
        sid = match.group(2)
        if sid in ids:
            full = match.group(0)
            full = re.sub(r'value="[^"]*"', 'value=""', full)
            return full
        return match.group(0)

    content = re.sub(
        r'(<setting[^>]*\bid="([^"]*)"[^>]*/>)',
        repl_attr, content, flags=re.IGNORECASE
    )
    return content


# ---------------------------------------------------------------------------
# Sonstige Hilfsfunktionen
# ---------------------------------------------------------------------------

def log(msg):
    xbmc.log('[{}] {}'.format(ADDON_NAME, msg), xbmc.LOGINFO)

def is_within(path, container):
    """True, wenn path == container oder ein Unterpfad von container ist.
    Vergleicht case-insensitiv (Windows: 'C:\\...' == 'c:\\...') und
    versucht Symlinks/Junctions aufzulösen, soweit lokal möglich."""
    if not container:
        return False

    def norm(p):
        try:
            p = os.path.realpath(p)
        except Exception:
            pass
        p = p.replace('\\', '/').rstrip('/')
        return os.path.normcase(p)

    path = norm(path)
    container = norm(container)
    return path == container or path.startswith(container + '/')


def _default_browse_start():
    """Startposition fuer den Backup-Zielordner-Dialog. Auf Android der
    oeffentliche Downloads-Ordner - der Nutzer kennt und findet ihn am
    ehesten wieder, gerade bei Fernbedienungsnavigation (Fire TV/Android
    TV). Wirkt NUR als Startpunkt des Browse-Dialogs (Kodis eigener
    'default'-Parameter dafuer) - der Nutzer kann im Dialog weiterhin frei
    zu jedem anderen Ordner navigieren, gespeichert wird ausschliesslich
    das, was er am Ende tatsaechlich auswaehlt."""
    if xbmc.getCondVisibility('System.Platform.Android'):
        android_downloads = '/storage/emulated/0/Download/'
        if os.path.isdir(android_downloads):
            return android_downloads
    return ''


def select_backup_path():
    """Manuell einen Backup-Zielordner waehlen und dauerhaft speichern."""
    dlg = xbmcgui.Dialog()
    current = ADDON.getSetting('backup_path')
    start = current if current and not is_within(current, HOME_DIR) else _default_browse_start()

    while True:
        chosen = dlg.browse(3, _(32020), 'files', '', False, False, start)
        if not chosen:
            return None
        if is_within(chosen, HOME_DIR):
            dlg.ok(ADDON_NAME, _(32021))
            start = _default_browse_start()
            continue
        ADDON.setSetting('backup_path', chosen)
        return chosen


def get_backup_path():
    """Bei jedem Backup den Zielordner abfragen.

    Der zuletzt verwendete, gültige Ordner wird als Startposition des
    Kodi-Browse-Dialogs verwendet und nach Auswahl wieder gespeichert.
    """
    path = ADDON.getSetting('backup_path')
    if path and is_within(path, HOME_DIR):
        ADDON.setSetting('backup_path', '')
    return select_backup_path()


def is_junk_file(filename):
    lower = filename.lower()
    return lower.endswith(JUNK_EXTENSIONS) or lower in JUNK_FILENAMES


def is_junk_folder(name):
    lower = name.lower()
    return lower in JUNK_FOLDERS or 'cache' in lower


def clean_addon_data_folder(folder_path):
    """Entfernt unnötige Dateien/Ordner in einem addon_data-Unterordner."""
    for root, dirs, files in vfs_walk(folder_path):
        keep_dirs = []
        for d in dirs:
            if is_junk_folder(d):
                vfs_rmtree(root + d)
            else:
                keep_dirs.append(d)
        dirs[:] = keep_dirs

        for f in files:
            if is_junk_file(f):
                try:
                    xbmcvfs.delete(root + f)
                except Exception as e:
                    log('Konnte {} nicht entfernen: {}'.format(f, e))


# ---------------------------------------------------------------------------
# ZIP-Backup: einheitlicher Enumerator (für Zählen UND Schreiben identisch,
# damit Fortschrittsanzeige und tatsächlich geschriebene Dateien nie
# auseinanderlaufen)
# ---------------------------------------------------------------------------

def _new_progress_state(bytes_total):
    return {
        'bytes_done': 0,
        'bytes_total': bytes_total,
        'start_time': time.monotonic(),
        'last_update': 0.0,
    }


def _update_progress(progress, state, status_label, filename, force=False):
    """Aktualisiert den Fortschrittsbalken GRÖSSENBASIERT (nicht nach
    Dateianzahl) inkl. 'X von Y' und geschätzter Restzeit. Gedrosselt auf
    max. 5x/Sekunde, damit es bei vielen kleinen Dateien nicht ruckelt."""
    now = time.time()
    if not force and (now - state['last_update']) < 0.2:
        return
    state['last_update'] = now

    total = state['bytes_total']
    done = min(state['bytes_done'], total) if total else state['bytes_done']
    pct = int(done * 100 / total) if total else 0

    text = progress_format.status_text(status_label, filename, done, total,
                                        state['start_time'], _(32109))
    progress.update(min(pct, 100), text)


def is_textures_db(filename):
    """Textures13.db/Textures14.db usw. - der Texture-Cache, wird von Kodi
    ohnehin neu aufgebaut und muss nicht gesichert werden."""
    lower = filename.lower()
    return lower.startswith('textures') and lower.endswith('.db')


def iter_backup_entries(src, arc_prefix, skip_pycache=False,
                         skip_toplevel_names=None, is_userdata=False):
    """Läuft src rekursiv ab und liefert (voller_pfad, arcname, rel, in_addon_data)
    für jede Datei, die ins Backup soll - unter Anwendung aller Ausschluss-
    regeln (pycache, Cache/Packages/Thumbnails, addon_data-Cache-Unterordner,
    Junk-Dateien, Textures-DB)."""
    src = ensure_slash(src)
    for root, dirs, files in vfs_walk(src):
        if skip_pycache:
            dirs[:] = [d for d in dirs if d != '__pycache__']
        if skip_toplevel_names and root == src:
            dirs[:] = [d for d in dirs if d.lower() not in skip_toplevel_names]

        rel = root[len(src):].rstrip('/')
        rel_top = rel.split('/')[0] if rel else ''

        if is_userdata:
            if rel_top.lower() in SKIP_USERDATA_FOLDERS:
                dirs[:] = []
                continue
            dirs[:] = [d for d in dirs if d != '__pycache__']

        in_addon_data_tree = is_userdata and (
            rel == 'addon_data' or rel.startswith('addon_data/'))
        if in_addon_data_tree:
            dirs[:] = [d for d in dirs if not is_junk_folder(d)]

        for f in files:
            lower_file = f.lower()
            if skip_pycache and lower_file.endswith('.pyc'):
                continue
            if lower_file in SENSITIVE_FILENAMES:
                continue
            if in_addon_data_tree and is_junk_file(f):
                continue
            if is_userdata and is_textures_db(f):
                continue

            rel_prefixed = (rel + '/') if rel else ''
            arcname = arc_prefix + rel_prefixed + f
            yield root + f, arcname, rel, in_addon_data_tree

def count_entries_size(src, **kwargs):
    total = 0
    for full_path, _arcname, _rel, _flag in iter_backup_entries(src, '', **kwargs):
        try:
            total += os.path.getsize(full_path)
        except Exception:
            pass
    return total


def zip_write_folder(zipf, src, arc_prefix, progress, prog_state,
                      status_label='Erstelle ZIP...', is_userdata=False,
                      include_credentials=True, file_replacements=None, **kwargs):
    for src_file, arcname, rel, in_addon_data_tree in iter_backup_entries(
            src, arc_prefix, is_userdata=is_userdata, **kwargs):
        f = arcname.rsplit('/', 1)[-1]
        try:
            file_size = os.path.getsize(src_file)
        except Exception:
            file_size = 0

        try:
            # BuildGuard's creator-only Dropbox app credentials (dropbox_app_key/
            # -secret - feste Entwickler-Zugangsdaten, keine individuellen
            # Daten des Nutzers) werden IMMER entfernt, unabhaengig von
            # include_credentials. Alle anderen Zugangsdaten in dieser
            # Datei (WebDAV, Google Drive, die eigene Dropbox-Verbindung
            # des Nutzers) folgen wie bei jedem anderen Addon dem
            # include_credentials-Flag - vorher wurde hier die KOMPLETTE
            # settings.xml immer sanitisiert, wodurch auch die eigenen
            # Zugangsdaten des Nutzers verloren gingen, selbst wenn er
            # "Ja, Zugangsdaten mit sichern" gewaehlt hatte.
            if (is_userdata and in_addon_data_tree
                    and rel.lower() == 'addon_data/script.buildguard'
                    and f.lower() == 'settings.xml'):
                content = strip_setting_ids(vfs_read_text(src_file), CREATOR_ONLY_SETTING_IDS)
                if not include_credentials:
                    content = sanitize_addon_settings_xml(content)
                zipf.writestr(arcname, content.encode('utf-8'))
                prog_state['bytes_done'] += file_size
                _update_progress(progress, prog_state, status_label, f)
                if progress.iscanceled():
                    return False
                continue

            if is_userdata and not include_credentials:
                if rel == '' and f.lower() == 'passwords.xml':
                    prog_state['bytes_done'] += file_size
                    continue

                if rel == '' and f.lower() == 'sources.xml':
                    content = sanitize_sources_xml(vfs_read_text(src_file))
                    zipf.writestr(arcname, content.encode('utf-8'))
                    prog_state['bytes_done'] += file_size
                    _update_progress(progress, prog_state, status_label, f)
                    if progress.iscanceled():
                        return False
                    continue

                if in_addon_data_tree and f.lower() == 'settings.xml':
                    content = sanitize_addon_settings_xml(vfs_read_text(src_file))
                    zipf.writestr(arcname, content.encode('utf-8'))
                    prog_state['bytes_done'] += file_size
                    _update_progress(progress, prog_state, status_label, f)
                    if progress.iscanceled():
                        return False
                    continue

            replacement = (file_replacements or {}).get(os.path.normcase(os.path.normpath(src_file)))
            zipf.write(replacement or src_file, arcname)
        except Exception as e:
            log('Fehler beim Hinzufügen von {}: {}'.format(src_file, e))

        prog_state['bytes_done'] += file_size
        _update_progress(progress, prog_state, status_label, f)
        if progress.iscanceled():
            return False
    return True


def clear_live_folders():
    """Leert Cache, Packages und Thumbnails im laufenden System und räumt
    addon_data auf.

    Thumbnails wird bewusst NICHT selbst per Dateiliste geleert (siehe
    fruehere Version): Kodis Textures13.db verknuepft jeden Original-
    Bildpfad (z.B. ein Hintergrundbild) mit seiner gecachten Datei in
    diesem Ordner. Werden nur die Dateien geloescht, denkt Kodi im
    laufenden Betrieb weiterhin, ein gueltiger Cache-Eintrag existiere,
    zeigt dann aber ins Leere - sichtbar z.B. als verschwindendes
    Hintergrundbild, behoben erst durch einen Kodi-Neustart. Deshalb wird
    stattdessen maintenance.deleteThumbnails() verwendet, die Dateien UND
    Textures13.db gemeinsam loescht - Kodi erkennt dann sofort "kein
    Cache-Eintrag vorhanden" und cached bei Bedarf sauber neu, ohne dass
    die GUI eine kaputte Referenz behaelt."""
    userdata = ensure_slash(USERDATA)
    dirs, _unused = xbmcvfs.listdir(userdata)
    for d in dirs:
        if d.lower() in SKIP_USERDATA_FOLDERS and d.lower() != 'thumbnails':
            path = userdata + d + '/'
            sub_dirs, sub_files = xbmcvfs.listdir(path)
            for f in sub_files:
                try:
                    xbmcvfs.delete(path + f)
                except Exception as e:
                    log('Konnte {} nicht löschen: {}'.format(path + f, e))
            for sd in sub_dirs:
                vfs_rmtree(path + sd)

    try:
        maintenance.deleteThumbnails(mode='silent')
    except Exception as e:
        log('Konnte Thumbnails/Textures-DB nicht bereinigen: {}'.format(e))

    addon_data = userdata + 'addon_data/'
    if vfs_isdir(addon_data):
        sub_dirs, _unused = xbmcvfs.listdir(addon_data)
        for sub in sub_dirs:
            clean_addon_data_folder(addon_data + sub)


def make_default_zip_name():
    return 'Build_Backup_{}.zip'.format(time.strftime('%Y%m%d_%H%M%S'))



def get_latest_db(prefix):
    """Findet die aktuellste DB-Datei mit gegebenem Präfix (z.B. 'Addons').
    Die Versionsnummer im Dateinamen (Addons33.db, Addons34.db, ...) ändert
    sich je nach Kodi-Version, daher niemals hartkodieren - Technik wie bei
    bekannten Build-Installern (SimpleWizard) üblich."""
    highest_number = -1
    highest_file = None
    try:
        _unused, files = xbmcvfs.listdir(ensure_slash(DATABASE_DIR))
    except Exception as e:
        log('Konnte {} nicht lesen: {}'.format(DATABASE_DIR, e))
        return None
    for f in files:
        if f.startswith(prefix) and f.lower().endswith('.db'):
            try:
                number = int(f[len(prefix):-3])
                if number > highest_number:
                    highest_number = number
                    highest_file = f
            except ValueError:
                pass
    if highest_file:
        return ensure_slash(DATABASE_DIR) + highest_file
    return None




def prepare_backup_addon_db():
    """Erstellt eine konsistente, bereinigte Kopie der aktuellen Addons*.db.

    Die Originaldatenbank der laufenden Kodi-Instanz bleibt unangetastet.
    In der temporären Kopie werden exakt dieselben Tabellen geleert wie im
    Truncate-Tables-Programm; anschließend wird VACUUM ausgeführt.

    Rückgabe: (original_path, temp_path). Bei Fehlern wird (None, None)
    geliefert, damit kein Backup mit einer unbereinigten Addon-Datenbank
    erzeugt wird.
    """
    addons_db = get_latest_db('Addons')
    if not addons_db or not os.path.isfile(addons_db):
        log('Keine Addons*.db für das Backup gefunden.')
        return None, None

    temp_db = os.path.join(TEMP_DIR, 'buildguard_backup_addons.db')
    try:
        if os.path.exists(temp_db):
            os.remove(temp_db)
    except OSError as e:
        log('Temporäre Addon-Datenbank konnte nicht entfernt werden: {}'.format(e))
        return None, None

    source = None
    target = None
    try:
        source = sqlite3.connect('file:{}?mode=ro'.format(addons_db), uri=True)
        target = sqlite3.connect(temp_db)
        source.backup(target)
        target.close()
        target = None
        source.close()
        source = None

        con = sqlite3.connect(temp_db)
        try:
            cursor = con.cursor()
            existing = {
                row[0] for row in cursor.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            }
            missing = [table for table in ADDON_DB_TRUNCATE_TABLES if table not in existing]
            if missing:
                raise sqlite3.DatabaseError(
                    'Erwartete Tabellen fehlen: {}'.format(', '.join(missing)))

            for table in ADDON_DB_TRUNCATE_TABLES:
                cursor.execute('DELETE FROM "{}"'.format(table))
            con.commit()
            cursor.execute('VACUUM')
            con.commit()
        finally:
            con.close()

        log('Temporäre Addon-Datenbank für das Backup bereinigt: {}'.format(temp_db))
        return addons_db, temp_db
    except (OSError, sqlite3.Error) as e:
        log('Addon-Datenbank für das Backup konnte nicht bereinigt werden: {}'.format(e))
        try:
            if os.path.exists(temp_db):
                os.remove(temp_db)
        except OSError:
            pass
        return None, None
    finally:
        for con in (target, source):
            if con:
                try:
                    con.close()
                except Exception:
                    pass


def cleanup_backup_addon_db(temp_db):
    if not temp_db:
        return
    try:
        if os.path.exists(temp_db):
            os.remove(temp_db)
    except OSError as e:
        log('Temporäre Addon-Datenbank konnte nicht gelöscht werden: {}'.format(e))


def do_backup(backup_path, include_credentials, zip_name=None, status_cb=None):
    """Erstellt eine echte ZIP-Datei (addons/, userdata/, media/ als Pfade
    relativ zum Kodi-Ordner) und kopiert sie an den gewählten Zielort.
    Die ZIP wird zunächst lokal in special://temp/ gebaut (Python zipfile
    braucht einen echten lokalen Pfad) und danach per xbmcvfs.copy an den
    - ggf. nicht-lokalen - Zielort übertragen."""
    def status(text):
        log(text)
        if status_cb:
            status_cb(text)

    if not backup_path or not vfs_isdir(backup_path):
        return False, _(32022)

    zip_name = (zip_name or make_default_zip_name()).strip()
    if not zip_name.lower().endswith('.zip'):
        zip_name += '.zip'

    local_zip_path = TEMP_DIR + zip_name
    final_path = ensure_slash(backup_path) + zip_name

    original_addons_db, temp_addons_db = prepare_backup_addon_db()
    if not original_addons_db or not temp_addons_db:
        return False, _(32029)

    replacements = {
        os.path.normcase(os.path.normpath(original_addons_db)): temp_addons_db
    }

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, _(32023))

    status(_(32024))
    addons_bytes = count_entries_size(ADDONS_DIR, skip_pycache=True,
                                       skip_toplevel_names=('addons',))
    media_bytes = count_entries_size(MEDIA_DIR) if vfs_isdir(MEDIA_DIR) else 0
    userdata_bytes = count_entries_size(USERDATA, is_userdata=True)
    total_bytes = addons_bytes + media_bytes + userdata_bytes
    prog_state = _new_progress_state(total_bytes)

    ok = True
    try:
        with zipfile.ZipFile(local_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            status(_(32025))
            ok = zip_write_folder(zipf, ADDONS_DIR, 'addons/', progress, prog_state,
                                   status_label=_(32025),
                                   skip_pycache=True, skip_toplevel_names=('addons',))

            if ok and vfs_isdir(MEDIA_DIR):
                status(_(32026))
                ok = zip_write_folder(zipf, MEDIA_DIR, 'media/', progress, prog_state,
                                       status_label=_(32026))

            if ok:
                status(_(32027))
                ok = zip_write_folder(zipf, USERDATA, 'userdata/', progress, prog_state,
                                       status_label=_(32027),
                                       is_userdata=True,
                                       include_credentials=include_credentials,
                                       file_replacements=replacements)

            if ok:
                # Platzhalter-Ordnereintrag, damit die Struktur nach einem
                # Restore stimmt, obwohl Thumbnails selbst nicht gesichert wird
                zi = zipfile.ZipInfo('userdata/Thumbnails/')
                zi.external_attr = 0o40775 << 16 | 0x10
                zipf.writestr(zi, '')
    except Exception as e:
        log('Fehler beim Erstellen der ZIP-Datei: {}'.format(e))
        ok = False

    progress.close()
    cleanup_backup_addon_db(temp_addons_db)

    if not ok:
        try:
            if xbmcvfs.exists(local_zip_path):
                xbmcvfs.delete(local_zip_path)
        except Exception:
            pass
        return False, _(32029)

    status(_(32030))
    if not xbmcvfs.copy(local_zip_path, final_path):
        return False, _(32033)
    try:
        xbmcvfs.delete(local_zip_path)
    except Exception:
        pass

    status(_(32031))
    clear_live_folders()

    status(_(32032).format(final_path))
    return True, final_path


# ---------------------------------------------------------------------------
# Restore
# ---------------------------------------------------------------------------

# SQLite legt zusammengehörige Zusatzdateien an (Write-Ahead-Log/Shared-
# Memory-Index). Wird nur eine davon während des Restores übersprungen
# (weil gesperrt), während die andere(n) erfolgreich überschrieben werden,
# entsteht ein inkonsistenter WAL-Zustand -> "disk I/O error" beim
# betroffenen Addon. Daher werden solche Dateien als Gruppe behandelt.
SQLITE_AUX_SUFFIXES = ('-wal', '-shm', '-journal')


def _sqlite_group_base(path):
    for suf in SQLITE_AUX_SUFFIXES:
        if path.endswith(suf):
            return path[:-len(suf)]
    return path


def _restore_target_path(member):
    if member.startswith('addons/'):
        return ADDONS_DIR + member[len('addons/'):]
    if member.startswith('media/'):
        return MEDIA_DIR + member[len('media/'):]
    if member.startswith('userdata/'):
        return USERDATA + member[len('userdata/'):]
    return HOME_DIR + member


def read_skin_from_backup(zipf):
    """Liest NUR den in der Backup-guisettings.xml hinterlegten Skin aus,
    ohne irgendeinen Seiteneffekt. Das eigentliche Umschalten passiert
    Der Skin wird aus dem Backup nur noch für die Restore-Rückmeldung ermittelt.
    beim nächsten Kodi-Start (siehe service.py) - deutlich robuster."""
    try:
        content = zipf.read('userdata/guisettings.xml').decode('utf-8', errors='ignore')
    except KeyError:
        return None
    except Exception as e:
        log('Konnte guisettings.xml aus Backup nicht lesen: {}'.format(e))
        return None

    try:
        root = ET.fromstring(content)
        skin_el = root.find('./lookandfeel/skin')
        skin_id = skin_el.text.strip() if skin_el is not None and skin_el.text else None
    except Exception as e:
        log('Konnte Skin aus Backup-guisettings.xml nicht ermitteln: {}'.format(e))
        return None

    return skin_id or None


def restore_backup(zip_source_path, status_cb=None):
    """Entpackt die gewählte Backup-ZIP zurück nach addons/, userdata/ und
    media/ - durch direktes Überschreiben bestehender Dateien statt
    Vorab-Löschen (siehe Hinweis unten). Liegt die ZIP nicht lokal
    (Netzwerk/Android-Speicher), wird sie zuerst nach special://temp/
    kopiert, da Pythons zipfile-Modul nur mit echten lokalen Dateien
    arbeiten kann.

    WICHTIG: Es wird NICHTS vorab gelöscht. Stattdessen wird jede Datei
    direkt überschrieben (open(...,'wb') ersetzt den Inhalt atomar in
    einem Schritt). Grund: Ein zweistufiges "erst löschen, dann neu
    schreiben" kann bei einer unter Windows gesperrten Datei dazu führen,
    dass das Löschen noch gelingt, das Neuschreiben aber fehlschlägt -
    die Datei ist dann schlicht WEG. Bei Kodi-Kerndateien wie
    guisettings.xml verhindert das sogar den nächsten Programmstart
    komplett. Overwrite-in-place stellt sicher: Eine Datei ist entweder
    erfolgreich ersetzt, oder sie behält unverändert ihren alten
    (funktionierenden) Inhalt - nie beides gleichzeitig "nichts"."""
    def status(text):
        log(text)
        if status_cb:
            status_cb(text)

    local_zip = zip_source_path
    is_local = os.path.exists(zip_source_path)
    if not is_local:
        status(_(32034))
        local_zip = TEMP_DIR + 'restore_tmp.zip'
        if not xbmcvfs.copy(zip_source_path, local_zip):
            return False, _(32035), None

    credentials_backed_up = False
    try:
        skipped_locked = []
        vfs_mkdirs(ADDONS_DIR)
        vfs_mkdirs(USERDATA)
        vfs_mkdirs(MEDIA_DIR)

        # BuildGuards eigene Zugangsdaten (settings.xml, Dropbox-/Google-
        # Drive-Tokens) aktiv sichern, BEVOR die Backup-ZIP unten Datei
        # fuer Datei ueberschreibt. Notwendig, weil eine wiederhergestellte
        # ZIP (z.B. ein von jemand anderem mit include_credentials=False
        # erstelltes/verteiltes Build-Paket) zwangslaeufig eine
        # zugangsdaten-bereinigte settings.xml enthaelt und
        # userdata/addon_data/script.buildguard/ hier NICHT von der
        # Ueberschreibung ausgenommen ist (nur der addons/-Codeordner ist
        # es, siehe OWN_ADDON_FOLDER-Filter oben).
        credential_guard.backup()
        credentials_backed_up = True

        status(_(32036))
        with zipfile.ZipFile(local_zip, 'r') as zipf:
            validated = validate_archive(zipf, allowed_roots={'addons', 'media', 'userdata'})
            all_infos = []
            for zi, safe_name in validated:
                zi.filename = safe_name
                if not safe_name.startswith('addons/{}/'.format(OWN_ADDON_FOLDER)):
                    all_infos.append(zi)

            # Zusammengehörige SQLite-Dateien (.db/.db-wal/.db-shm/
            # .db-journal) vorab nicht-destruktiv auf Sperrung testen
            # (Öffnen im 'r+b'-Modus verändert nichts), damit beim
            # Entpacken nie nur ein Teil der Gruppe ersetzt wird.
            locked_sqlite_bases = set()
            for zi in all_infos:
                member = zi.filename
                if member.endswith('/'):
                    continue
                target = _restore_target_path(member)
                tl = target.lower()
                if not (tl.endswith('.db') or tl.endswith(
                        ('.db-wal', '.db-shm', '.db-journal'))):
                    continue
                if not os.path.exists(target):
                    continue
                try:
                    with open(target, 'r+b'):
                        pass
                except Exception:
                    locked_sqlite_bases.add(_sqlite_group_base(target))

            # Feste Reihenfolge: addons zuerst (Dateien müssen auf der
            # Platte liegen, bevor die userdata-Datenbank - die den
            # Aktiviert/Deaktiviert-Status jedes Addons trackt - greift),
            # dann media, zuletzt userdata.
            def sort_key(zi):
                if zi.filename.startswith('addons/'):
                    return 0
                if zi.filename.startswith('media/'):
                    return 1
                return 2
            infos = sorted(all_infos, key=sort_key)

            total_bytes = sum(zi.file_size for zi in infos)
            prog_state = _new_progress_state(total_bytes)
            progress = xbmcgui.DialogProgress()
            progress.create(ADDON_NAME, _(32037))
            status(_(32037))

            zip_addon_folders = set()

            for zi in infos:
                member = zi.filename
                if progress.iscanceled():
                    progress.close()
                    if credentials_backed_up:
                        credential_guard.restore()
                    return False, _(32039), None

                if member.startswith('addons/'):
                    rest = member[len('addons/'):]
                    if '/' in rest:
                        zip_addon_folders.add(rest.split('/', 1)[0])

                target = _restore_target_path(member)

                # Gehört diese Datei zu einer als gesperrt erkannten
                # SQLite-Gruppe -> die ganze Gruppe unangetastet lassen
                if not member.endswith('/'):
                    target_lower = target.lower()
                    if target_lower.endswith('.db') or target_lower.endswith(
                            ('.db-wal', '.db-shm', '.db-journal')):
                        if _sqlite_group_base(target) in locked_sqlite_bases:
                            log('Übersprungen (gesperrte SQLite-Geschwisterdatei): {}'.format(member))
                            skipped_locked.append(member)
                            prog_state['bytes_done'] += zi.file_size
                            _update_progress(progress, prog_state, _(32037), member)
                            continue

                try:
                    if member.endswith('/'):
                        vfs_mkdirs(target)
                    else:
                        vfs_mkdirs(target.rsplit('/', 1)[0] + '/')
                        # Direktes Überschreiben (kein vorheriges Löschen!)
                        # - schlägt der Schreibvorgang fehl, bleibt die
                        # alte Datei unverändert vorhanden.
                        with zipf.open(member) as s, open(target, 'wb') as d:
                            while True:
                                chunk = s.read(1024 * 1024)
                                if not chunk:
                                    break
                                d.write(chunk)
                except PermissionError as e:
                    # Datei ist gerade von Kodi selbst geöffnet/gesperrt
                    # (z.B. geladene Addon-DLL, offene Bild-Handles) -
                    # überspringen statt die gesamte Wiederherstellung
                    # abzubrechen. Die alte Datei bleibt dabei unversehrt
                    # bestehen. Ein zweiter Restore-Lauf nach einem
                    # Kodi-Neustart holt diese Dateien meist nach.
                    log('Datei gesperrt, übersprungen: {} ({})'.format(member, e))
                    skipped_locked.append(member)
                    locked_sqlite_bases.add(_sqlite_group_base(target))
                except Exception as e:
                    log('Fehler beim Entpacken von {}: {}'.format(member, e))
                    skipped_locked.append(member)
                    locked_sqlite_bases.add(_sqlite_group_base(target))

                prog_state['bytes_done'] += zi.file_size
                _update_progress(progress, prog_state, _(32037), member)

            progress.close()

            status(_(32040))
            applied_skin = read_skin_from_backup(zipf)

        # Direkt nach dem Entpacken zurueckschreiben - unabhaengig davon,
        # was die wiederhergestellte ZIP an eigenen BuildGuard-Dateien
        # mitgebracht/ueberschrieben hat.
        credential_guard.restore()

        status(_(32041))
        from resources.lib.modules.binary_prepare import prepare_binary_addons
        fixed_binaries, binary_failures = prepare_binary_addons()
        if binary_failures:
            for addon_id, error in binary_failures:
                log('Binary-Vorbereitung fehlgeschlagen: {} ({})'.format(addon_id, error))

        status(_(32042))
        enable_all_addons()

        # Erst JETZT, nachdem alles erfolgreich entpackt wurde: Addon-
        # Ordner entfernen, die auf der Platte liegen, aber nicht (mehr)
        # im Backup enthalten sind (z.B. seither deinstallierte Addons).
        # Bewusst als letzter, unkritischer Schritt - ein Fehler hier
        # gefährdet die bereits erfolgreich wiederhergestellten Daten
        # nicht mehr.
        status(_(32043))
        try:
            if vfs_isdir(ADDONS_DIR):
                current_dirs, _unused = xbmcvfs.listdir(ensure_slash(ADDONS_DIR))
                for d in current_dirs:
                    if d == OWN_ADDON_FOLDER or d in zip_addon_folders:
                        continue
                    vfs_rmtree(ensure_slash(ADDONS_DIR) + d, failures=skipped_locked)
        except Exception as e:
            log('Konnte veraltete Addon-Ordner nicht aufräumen: {}'.format(e))

        # Duplikate entfernen (eine Datei kann mehrfach als gesperrt
        # aufgefallen sein)
        seen = set()
        skipped_locked = [x for x in skipped_locked if not (x in seen or seen.add(x))]
    except Exception as e:
        if credentials_backed_up:
            credential_guard.restore()
        log('Fehler bei der Wiederherstellung: {}'.format(e))
        return False, _(32044).format(e), None
    finally:
        if not is_local:
            try:
                xbmcvfs.delete(local_zip)
            except Exception:
                pass

    return True, _build_restore_result_message(skipped_locked, fixed_binaries, applied_skin), applied_skin


def _build_restore_result_message(skipped_locked, fixed_binaries=None, applied_skin=None):
    fixed_binaries = fixed_binaries or []
    parts = [_(32045)]

    if applied_skin:
        parts.append(_(32046).format(applied_skin))

    if fixed_binaries:
        preview = ', '.join(fixed_binaries[:8])
        more = '' if len(fixed_binaries) <= 8 else _(32049).format(len(fixed_binaries) - 8)
        parts.append(_(32047).format(len(fixed_binaries), preview, more))

    if skipped_locked:
        preview = '\n'.join(skipped_locked[:5])
        more = '' if len(skipped_locked) <= 5 else _(32050).format(len(skipped_locked) - 5)
        parts.append(_(32048).format(len(skipped_locked), preview, more))

    return ''.join(parts)


# ---------------------------------------------------------------------------
# Einfache, dialogbasierte Abläufe für den direkten Menü-Aufruf aus
# default.py (Aktion 'backup_restore') - bewusst OHNE eigenes Custom-
# Fenster, damit nur eine einzige, lineare Dialogfolge zu sehen ist statt
# eines Panels plus zusätzlicher Dialoge obendrauf.
# ---------------------------------------------------------------------------

def run_backup_flow():
    """SICHERN: Zielordner bei jedem Backup wählen, dabei den zuletzt
    verwendeten Ordner als Startposition anbieten; danach optional
    Zugangsdaten-Frage, Name eingeben und Backup erstellen."""
    dlg = xbmcgui.Dialog()

    backup_path = get_backup_path()
    if not backup_path:
        return

    include_credentials = dlg.yesno(
        ADDON_NAME, _(32051),
        yeslabel=_(32052),
        nolabel=_(32053)
    )

    kb = xbmc.Keyboard('', _(32054))
    kb.doModal()
    if not kb.isConfirmed():
        return
    zip_name = kb.getText().strip()
    if not zip_name:
        zip_name = make_default_zip_name()
    if not zip_name.lower().endswith('.zip'):
        zip_name += '.zip'

    final_path = ensure_slash(backup_path) + zip_name
    if xbmcvfs.exists(final_path):
        if not dlg.yesno(ADDON_NAME, _(32066).format(zip_name)):
            return

    cred_txt = (_(32056) if include_credentials else _(32057))
    confirm = dlg.yesno(ADDON_NAME, _(32055).format(zip_name, cred_txt, backup_path))
    if not confirm:
        return

    ok, result = do_backup(backup_path, include_credentials, zip_name=zip_name)

    if not ok:
        dlg.ok(ADDON_NAME, result)
        return

    cred_hint = (_(32059) if include_credentials else _(32060))
    # Local backup creation and cloud publication are deliberately separated.
    dlg.ok(ADDON_NAME, _(32058).format(result, cred_hint))


def run_restore_from_path(chosen, skip_confirm=False):
    """Restore one already selected local ZIP using the normal safe flow.

    skip_confirm=True wird von install_public_build() genutzt, das dem
    Nutzer bereits vorher eine vollstaendige Bestaetigung (inklusive
    derselben Ueberschreib-Warnung) gezeigt hat - eine zweite, inhaltlich
    redundante Rueckfrage waere an dieser Stelle nur unnoetiger
    Zusatzklick."""
    dlg = xbmcgui.Dialog()
    if not chosen:
        return False

    if not skip_confirm:
        confirm = dlg.yesno(ADDON_NAME, _(32061).format(chosen))
        if not confirm:
            return False

    ok, msg, skin_id = restore_backup(chosen)
    if not ok:
        dlg.ok(ADDON_NAME, msg)
        return False

    # Kurze, sich selbst schliessende Benachrichtigungen statt einer
    # blockierenden OK-Box: der Prozess wird direkt danach per os._exit(1)
    # hart beendet, ein Klick wuerde daran nichts mehr aendern (dasselbe
    # Muster wie in builds.py/install_build()).
    xbmcgui.Dialog().notification(ADDON_NAME, _(32535), ADDON.getAddonInfo('icon'), 3000)
    xbmc.sleep(3000)
    xbmcgui.Dialog().notification(ADDON_NAME, _(32536), ADDON.getAddonInfo('icon'), 3000)
    xbmc.sleep(3000)

    # Harter Prozess-Kill statt geordnetem Quit - siehe restore_backup-
    # Docstring: ein geordnetes Quit würde guisettings.xml sofort wieder
    # mit dem alten Zustand überschreiben.
    os._exit(1)


def run_restore_flow(fresh_start_callback):
    """Auswahl einer lokalen Build-ZIP, installiert danach ueber denselben
    Fresh-Start-basierten Weg wie jede andere Build-Quelle
    (builds.install_build()) - identisch zum Online-Katalog-Weg
    (dropbox_auth.install_public_build()) und den fest konfigurierten
    Wizard-Slot-Builds. Ersetzt die vorherige sanfte "eigenes Backup
    wiederherstellen"-Logik (run_restore_from_path()/restore_backup()) fuer
    diesen Menuepunkt."""
    chosen = xbmcgui.Dialog().browse(1, _(32067), 'files', '.zip')
    if not chosen:
        return False
    from resources.lib.modules import builds
    return builds.install_build(chosen, fresh_start_callback)
