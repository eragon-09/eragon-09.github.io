# -*- coding: utf-8 -*-

import os
import json
import time
import xbmcvfs
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

CACHE_TTL_DEFAULT = 600  # 10 Minuten


class Cache:
    def __init__(self, name, ttl=CACHE_TTL_DEFAULT):
        self.name = name
        self.ttl = ttl

        self.cache_dir = xbmcvfs.translatePath(
            f"special://profile/addon_data/{ADDON_ID}/cache"
        )

        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)

        self.cache_file = os.path.join(self.cache_dir, f"{self.name}.json")

    def get(self):
        if not os.path.exists(self.cache_file):
            return None

        try:
            with open(self.cache_file, "r", encoding="utf-8") as f:
                payload = json.load(f)

            timestamp = payload.get("timestamp", 0)
            if time.time() - timestamp > self.ttl:
                return None

            return payload.get("data")

        except Exception:
            return None

    def set(self, data):
        try:
            payload = {
                "timestamp": time.time(),
                "data": data
            }

            with open(self.cache_file, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)

        except Exception:
            pass

    def clear(self):
        if os.path.exists(self.cache_file):
            try:
                os.remove(self.cache_file)
            except Exception:
                pass
