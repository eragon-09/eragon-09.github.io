import sys
import xbmcgui
import xbmcplugin

from resources.lib.json_loader import load_data
from resources.lib.image_utils import resolve_image
from resources.lib.utils import build_url


def list_categories():
    handle = int(sys.argv[1])
    data = load_data()

    categories = data.get("categories", {})

    for name, info in categories.items():
        url = build_url({
            "action": "category",
            "category": name
        })

        li = xbmcgui.ListItem(label=name)

        thumb = resolve_image(info.get("image"), "categories")
        if thumb:
            li.setArt({
                "thumb": thumb,
                "icon": thumb,
                "fanart": thumb
            })

        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=url,
            listitem=li,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(handle)
