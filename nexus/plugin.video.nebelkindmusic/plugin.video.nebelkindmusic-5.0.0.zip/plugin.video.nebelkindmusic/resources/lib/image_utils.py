import os
import xbmcvfs

MEDIA_PATH = xbmcvfs.translatePath(
    "special://home/addons/plugin.video.nebelkindmusic/resources/media/"
)


def resolve_image(image_name, subfolder):
    if not image_name:
        return ""

    path = os.path.join(MEDIA_PATH, subfolder, image_name)
    return path if xbmcvfs.exists(path) else ""
