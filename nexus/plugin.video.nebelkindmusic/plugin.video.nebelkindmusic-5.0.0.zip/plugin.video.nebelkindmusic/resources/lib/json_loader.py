import json
import xbmcvfs

JSON_PATH = "special://home/addons/plugin.video.nebelkindmusic/resources/data/playlists.json"


def load_data():
    if not xbmcvfs.exists(JSON_PATH):
        return {}

    with xbmcvfs.File(JSON_PATH) as f:
        return json.loads(f.read())
