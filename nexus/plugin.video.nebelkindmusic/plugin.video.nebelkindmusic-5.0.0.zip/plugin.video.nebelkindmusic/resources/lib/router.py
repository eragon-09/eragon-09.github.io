import sys
import xbmcplugin
import xbmcgui
from urllib.parse import parse_qsl

from resources.lib.categories import list_categories
from resources.lib.playlists import list_playlists


def router(paramstring):
    handle = int(sys.argv[1])
    params = dict(parse_qsl(paramstring[1:]))

    action = params.get("action")

    if action == "category":
        list_playlists(params.get("category"))

    elif action == "play":
        playlist_id = params.get("playlist_id")

        # YouTube-URL als auflösbares PlayItem setzen
        yt_url = (
            "plugin://plugin.video.youtube/play/"
            "?playlist_id={}".format(playlist_id)
        )

        li = xbmcgui.ListItem(path=yt_url)

        xbmcplugin.setResolvedUrl(
            handle=handle,
            succeeded=True,
            listitem=li
        )

    else:
        list_categories()
