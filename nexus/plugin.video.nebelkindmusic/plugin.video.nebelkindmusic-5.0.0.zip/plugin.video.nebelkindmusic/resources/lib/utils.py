import sys
import urllib.parse


def build_url(query):
    """
    Baut eine Kodi-plugin-URL mit Query-Parametern
    """
    return sys.argv[0] + "?" + urllib.parse.urlencode(query)
