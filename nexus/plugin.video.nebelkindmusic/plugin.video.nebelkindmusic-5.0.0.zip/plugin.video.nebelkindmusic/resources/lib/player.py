import xbmc


def play_playlist(playlist_id):
    if not playlist_id:
        return

    # Kodi Omega / aktuelles YouTube-Addon erwartet /play/
    yt_url = (
        "plugin://plugin.video.youtube/play/"
        "?playlist_id={}".format(playlist_id)
    )

    xbmc.executebuiltin("RunPlugin({})".format(yt_url))
