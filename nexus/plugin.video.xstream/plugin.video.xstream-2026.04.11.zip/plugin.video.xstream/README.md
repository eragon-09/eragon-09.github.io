
## Willkommen bei xStream für Kodi!!



xStream ist ein Video-Addon für Kodi. xStream dient als Suchmaschine für Filme und Serien auf verschiedenen Webseiten. xStream verfügt über eine intuitive und optisch ansprechende Benutzeroberfläche, wobei man direkt in den einzelnen Sitplugins der Webseiten nach Streams suchen kann, oder alle Webseiten gemeinsam durchsucht.

Sowohl der Funktionsumfang von xStream als auch das Angebot an Webseiten-Inhalten wird von den beteiligten Entwicklern stetig weiterentwickelt bzw. um neue Webseiten erweitert.

Diese werden auch als Site-Plugins bezeichnet, welche auf die eigentlichen Quellen verweisen die für das bereitgestellte Angebot verantworlich sind! Der bereitgestellte Inhalt der Webseiten steht in keinem Bezug zu xStream oder den Entwicklern! xStream läuft ausschließlich unter Python 3 und funktioniert somit ab Kodi Version 19 und höher!


