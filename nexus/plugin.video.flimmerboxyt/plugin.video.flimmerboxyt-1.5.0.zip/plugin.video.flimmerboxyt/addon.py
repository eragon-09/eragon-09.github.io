import sys
from urllib.parse import parse_qsl, urlparse
import xbmcplugin
from resources.lib.router import Router

HANDLE   = int(sys.argv[1])
BASE_URL = sys.argv[0]
PARAMS   = dict(parse_qsl(urlparse(sys.argv[2]).query))

Router(BASE_URL, HANDLE).route(PARAMS)
