"""
YouTube Data API v3 – Suche und Playlist-Abruf.
API-Key wird aus plugin.video.youtube oder den eigenen Einstellungen gelesen.

Stabilitäts-Patch:
- JSON-Datei-Cache in userdata/addon_data
- Retry/Backoff bei HTTP 429 und temporären Fehlern
- geringere API-Last, damit Untermenüs beim ersten Öffnen zuverlässiger gefüllt werden
"""

import json
import time
import hashlib
import os
import xbmc
import xbmcaddon
import xbmcvfs
from urllib.request import urlopen, Request
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError

YT_API = 'https://www.googleapis.com/youtube/v3'
ADDON  = xbmcaddon.Addon()

# Eingebetteter API-Key (aus Nutzer-settings.xml übernommen)
_BUILTIN_KEY = 'AIzaSyDnlJ0e_CZlLoZm7CMNnO41xInZgVFyObo'

CACHE_DIR = xbmcvfs.translatePath(
    'special://profile/addon_data/{}/cache'.format(ADDON.getAddonInfo('id'))
)

# Cache-Zeiten
TTL_SEARCH          = 15 * 60          # 15 Minuten
TTL_PLAYLIST_VIDEOS = 15 * 60         # 15 Minuten
TTL_UPLOADS        = 7 * 24 * 60 * 60 # 7 Tage
TTL_CHANNEL_ICON   = 30 * 24 * 60 * 60 # 30 Tage


def _ensure_cache_dir():
    try:
        if not xbmcvfs.exists(CACHE_DIR):
            xbmcvfs.mkdirs(CACHE_DIR)
    except Exception:
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
        except Exception:
            pass


def _cache_key(endpoint, params):
    safe = json.dumps({'endpoint': endpoint, 'params': params}, sort_keys=True)
    return hashlib.md5(safe.encode('utf-8')).hexdigest() + '.json'


def _cache_path(endpoint, params):
    _ensure_cache_dir()
    return os.path.join(CACHE_DIR, _cache_key(endpoint, params))


def _read_cache(endpoint, params, ttl):
    if not ttl:
        return None
    path = _cache_path(endpoint, params)
    try:
        if not os.path.exists(path):
            return None
        with open(path, 'r', encoding='utf-8') as f:
            payload = json.load(f)
        if time.time() - payload.get('time', 0) > ttl:
            return None
        return payload.get('data')
    except Exception:
        return None


def _write_cache(endpoint, params, data):
    if data is None:
        return
    path = _cache_path(endpoint, params)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'time': time.time(), 'data': data}, f)
    except Exception:
        pass


_BUILTIN_KEY = 'AIzaSyDnlJ0e_CZlLoZm7CMNnO41xInZgVFyObo'

def get_api_key():
    # 1. Eigene Addon-Einstellungen (manueller Override hat Vorrang)
    try:
        k = ADDON.getSetting('youtube_api_key').strip()
        if k and k != _BUILTIN_KEY:
            return k
    except Exception:
        pass

    # 2. API-Key aus plugin.video.youtube übernehmen
    try:
        yt = xbmcaddon.Addon('plugin.video.youtube')
        for s in ('api.key', 'youtube.api.key', 'api_key'):
            try:
                k = yt.getSetting(s).strip()
                if k:
                    return k
            except Exception:
                pass
    except Exception:
        pass

    # 3. Eingebetteter Key als Fallback
    return _BUILTIN_KEY


def has_api_key():
    return bool(get_api_key())


def _get(endpoint, params, ttl=0):
    """
    YouTube API GET mit Cache und Retry.
    Bei 429 wird zuerst ein alter Cache genutzt, falls vorhanden.
    """
    key = get_api_key()
    if not key:
        return None

    clean_params = dict(params)
    cached = _read_cache(endpoint, clean_params, ttl)
    if cached is not None:
        return cached

    req_params = dict(clean_params)
    req_params['key'] = key
    url = f'{YT_API}/{endpoint}?{urlencode(req_params)}'

    last_error = None
    for attempt, delay in enumerate((0, 1, 2, 4), start=1):
        if delay:
            xbmc.sleep(delay * 1000)
        try:
            r = urlopen(Request(url, headers={'Accept': 'application/json'}), timeout=15)
            data = json.loads(r.read().decode('utf-8'))
            _write_cache(endpoint, clean_params, data)
            return data
        except HTTPError as e:
            last_error = e
            if e.code == 429:
                # Bei Rate-Limit alten Cache auch nach TTL verwenden, wenn vorhanden.
                stale = _read_cache(endpoint, clean_params, 365 * 24 * 60 * 60)
                if stale is not None:
                    xbmc.log(f'FlimmerBoxYT API 429, nutze alten Cache: {endpoint}', xbmc.LOGWARNING)
                    return stale
                continue
            if e.code in (500, 502, 503, 504):
                continue
            xbmc.log(f'FlimmerBoxYT API Fehler: HTTP {e.code} {e.reason}', xbmc.LOGERROR)
            return None
        except (URLError, TimeoutError, Exception) as e:
            last_error = e
            continue

    xbmc.log(f'FlimmerBoxYT API Fehler nach Retry: {last_error}', xbmc.LOGERROR)
    return None


def _parse_video(item, id_field='id'):
    """Wandelt ein API-Item in ein einheitliches Film-Dict um."""
    if isinstance(item.get(id_field), dict):
        vid = item[id_field].get('videoId', '')
    else:
        vid = item.get(id_field, '')

    sn     = item.get('snippet', {})
    thumbs = sn.get('thumbnails', {})
    thumb  = (thumbs.get('high') or thumbs.get('medium') or
              thumbs.get('default') or {})
    year_str = sn.get('publishedAt', '')[:4]

    return {
        'youtube_id':  vid,
        'title':       sn.get('title', ''),
        'description': sn.get('description', '')[:300],
        'channel':     sn.get('channelTitle', ''),
        'thumb':       thumb.get('url', f'https://i.ytimg.com/vi/{vid}/sddefault.jpg'),
        'year':        int(year_str) if year_str.isdigit() else 0,
        'published':   sn.get('publishedAt', ''),
    }


def search(query, max_results=25, page_token=None):
    """
    Sucht Videos auf YouTube.
    Gibt (videos, next_page_token) zurück.
    """
    params = {
        'part':              'snippet',
        'q':                 query,
        'type':              'video',
        'maxResults':        max_results,
        'order':             'relevance',
        'relevanceLanguage': 'de',
        'videoDuration':     'long',
    }
    if page_token:
        params['pageToken'] = page_token

    data = _get('search', params, ttl=TTL_SEARCH)
    if not data:
        return [], None

    videos = [_parse_video(item) for item in data.get('items', [])
              if item.get('id', {}).get('videoId')]
    return videos, data.get('nextPageToken')


def get_playlist_videos(playlist_id, page_token=None, max_results=50):
    """
    Lädt Videos einer Playlist.
    Gibt (videos, next_page_token) zurück, oder (None, None) wenn kein API-Key.
    """
    if not has_api_key():
        return None, None

    params = {
        'part':       'snippet',
        'playlistId': playlist_id,
        'maxResults': max_results,
    }
    if page_token:
        params['pageToken'] = page_token

    data = _get('playlistItems', params, ttl=TTL_PLAYLIST_VIDEOS)
    if not data:
        return [], None

    videos = []
    for item in data.get('items', []):
        sn  = item.get('snippet', {})
        vid = sn.get('resourceId', {}).get('videoId', '')
        if not vid:
            continue
        thumbs = sn.get('thumbnails', {})
        thumb  = (thumbs.get('standard') or thumbs.get('high') or
                  thumbs.get('medium') or thumbs.get('default') or {})
        year_str = sn.get('publishedAt', '')[:4]
        videos.append({
            'youtube_id':  vid,
            'title':       sn.get('title', ''),
            'description': sn.get('description', '')[:300],
            'channel':     sn.get('channelTitle', ''),
            'thumb':       thumb.get('url', f'https://i.ytimg.com/vi/{vid}/sddefault.jpg'),
            'year':        int(year_str) if year_str.isdigit() else 0,
            'published':   sn.get('publishedAt', ''),
        })

    return videos, data.get('nextPageToken')


def get_uploads_playlist_id(channel_id):
    """Gibt die Uploads-Playlist-ID eines Kanals zurück (für Kanal-Feed)."""
    data = _get('channels', {
        'part':       'contentDetails',
        'id':         channel_id,
        'maxResults': 1,
    }, ttl=TTL_UPLOADS)
    if not data or not data.get('items'):
        return None
    return data['items'][0]['contentDetails']['relatedPlaylists']['uploads']


def resolve_handle_to_id(handle_or_name):
    """
    Versucht eine Kanal-ID über den Handle oder Kanalnamen zu ermitteln.
    Nur noch Fallback, da die meisten Kanäle feste UC-IDs haben.
    """
    data = _get('search', {
        'part':      'snippet',
        'q':         handle_or_name,
        'type':      'channel',
        'maxResults': 1,
    }, ttl=TTL_UPLOADS)
    if not data or not data.get('items'):
        return None
    return data['items'][0].get('id', {}).get('channelId', '')


def get_channel_icon(channel_id):
    """Lädt das Profilbild (Icon) eines YouTube-Kanals, 30 Tage gecached."""
    data = _get('channels', {
        'part':       'snippet',
        'id':         channel_id,
        'maxResults': 1,
    }, ttl=TTL_CHANNEL_ICON)
    if not data or not data.get('items'):
        return _BUILTIN_KEY
    thumbs = data['items'][0].get('snippet', {}).get('thumbnails', {})
    for size in ('high', 'medium', 'default'):
        url = thumbs.get(size, {}).get('url', '')
        if url:
            return url
    return ''


def get_channel_metadata(channel_id):
    """Lädt Name, Beschreibung, Icon-URL und ggf. Banner-URL eines Kanals."""
    data = _get('channels', {
        'part': 'snippet,brandingSettings,statistics',
        'id': channel_id,
        'maxResults': 1,
    }, ttl=TTL_CHANNEL_ICON)
    if not data or not data.get('items'):
        return {}
    item = data['items'][0]
    sn = item.get('snippet', {})
    thumbs = sn.get('thumbnails', {})
    icon = ''
    for size in ('high', 'medium', 'default'):
        icon = thumbs.get(size, {}).get('url', '')
        if icon:
            break
    branding = item.get('brandingSettings', {})
    image = branding.get('image', {})
    banner = image.get('bannerExternalUrl', '')
    stats = item.get('statistics', {})
    return {
        'id': channel_id,
        'title': sn.get('title', ''),
        'description': sn.get('description', ''),
        'icon_url': icon,
        'banner_url': banner,
        'subscriberCount': stats.get('subscriberCount', ''),
        'videoCount': stats.get('videoCount', ''),
    }


def get_channel_playlists(channel_id, page_token=None, max_results=25):
    params = {
        'part': 'snippet',
        'channelId': channel_id,
        'maxResults': max_results,
    }
    if page_token:
        params['pageToken'] = page_token
    data = _get('playlists', params, ttl=TTL_PLAYLIST_VIDEOS)
    if not data:
        return [], None
    playlists = []
    for item in data.get('items', []):
        sn = item.get('snippet', {})
        thumbs = sn.get('thumbnails', {})
        thumb = (thumbs.get('high') or thumbs.get('medium') or thumbs.get('default') or {})
        playlists.append({
            'id': item.get('id', ''),
            'name': sn.get('title', ''),
            'description': sn.get('description', ''),
            'thumb': thumb.get('url', ''),
        })
    return playlists, data.get('nextPageToken')


def get_popular_videos(channel_id, page_token=None, max_results=25):
    params = {
        'part': 'snippet',
        'channelId': channel_id,
        'type': 'video',
        'order': 'viewCount',
        'maxResults': max_results,
    }
    if page_token:
        params['pageToken'] = page_token
    data = _get('search', params, ttl=TTL_SEARCH)
    if not data:
        return [], None
    videos = [_parse_video(item) for item in data.get('items', [])
              if item.get('id', {}).get('videoId')]
    return videos, data.get('nextPageToken')
