"""Kanalverwaltung fuer FlimmerBox DE - TiTanX Lab 4.0."""

import json
import os
import re
import shutil
from urllib.parse import urlparse
from urllib.request import urlopen, Request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
DATA_DIR = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
CHANNELS_JSON = os.path.join(DATA_DIR, 'channels.json')
ICON_DIR = os.path.join(DATA_DIR, 'icons')
BANNER_DIR = os.path.join(DATA_DIR, 'banners')
BACKUP_JSON = os.path.join(DATA_DIR, 'channels_backup.json')


def _ensure_dirs():
    for d in (DATA_DIR, ICON_DIR, BANNER_DIR):
        try:
            if not xbmcvfs.exists(d):
                xbmcvfs.mkdirs(d)
        except Exception:
            os.makedirs(d, exist_ok=True)


def slugify(text):
    text = (text or '').lower()
    repl = {
        'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss',
        'á': 'a', 'à': 'a', 'é': 'e', 'è': 'e'
    }
    for a, b in repl.items():
        text = text.replace(a, b)
    text = re.sub(r'[^a-z0-9]+', '_', text).strip('_')
    return text or 'channel'


def load_user_channels():
    _ensure_dirs()
    if not os.path.exists(CHANNELS_JSON):
        return []
    try:
        with open(CHANNELS_JSON, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data.get('channels', [])
        if isinstance(data, list):
            return data
    except Exception as e:
        xbmc.log(f'TiTanX Kanalverwaltung: channels.json konnte nicht gelesen werden: {e}', xbmc.LOGERROR)
    return []


def save_user_channels(channels):
    _ensure_dirs()
    with open(CHANNELS_JSON, 'w', encoding='utf-8') as f:
        json.dump({'channels': channels}, f, indent=2, ensure_ascii=False)


def get_user_channels():
    return load_user_channels()


def extract_handle_or_id(value):
    value = (value or '').strip()
    if not value:
        return '', ''
    if value.startswith('UC') and len(value) >= 20:
        return '', value
    if value.startswith('@'):
        return value, ''
    try:
        path = urlparse(value).path.strip('/')
    except Exception:
        path = value.strip('/')
    parts = [p for p in path.split('/') if p]
    if not parts:
        return value if value.startswith('@') else '@' + value, ''
    if parts[0] == 'channel' and len(parts) > 1:
        return '', parts[1]
    if parts[0].startswith('@'):
        return parts[0], ''
    if parts[0] in ('c', 'user') and len(parts) > 1:
        return parts[1] if parts[1].startswith('@') else '@' + parts[1], ''
    return parts[-1] if parts[-1].startswith('@') else '@' + parts[-1], ''


def _download_file(url, target):
    if not url:
        return ''
    try:
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        data = urlopen(req, timeout=20).read()
        with open(target, 'wb') as f:
            f.write(data)
        return target
    except Exception as e:
        xbmc.log(f'TiTanX Download Fehler: {e}', xbmc.LOGWARNING)
        return ''


def _optimize_png(src, target, size=(256, 256), max_kb=80):
    """Speichert Icons als kleine 256x256 PNG. Ziel: ca. 20-60 KB, max. ca. 80 KB."""
    try:
        from PIL import Image
        img = Image.open(src).convert('RGBA')
        img.thumbnail(size, Image.LANCZOS)
        canvas = Image.new('RGBA', size, (0, 0, 0, 0))
        x = (size[0] - img.width) // 2
        y = (size[1] - img.height) // 2
        canvas.paste(img, (x, y), img)
        canvas.save(target, 'PNG', optimize=True)
        return target
    except Exception as e:
        xbmc.log(f'TiTanX PNG Optimierung nicht moeglich: {e}', xbmc.LOGWARNING)
        try:
            shutil.copy(src, target)
            return target
        except Exception:
            return ''


def save_channel_images(meta, slug):
    _ensure_dirs()
    icon_rel = ''
    banner_rel = ''

    icon_url = meta.get('icon_url', '')
    if icon_url:
        tmp = os.path.join(ICON_DIR, slug + '_source')
        final_icon = os.path.join(ICON_DIR, slug + '.png')
        if _download_file(icon_url, tmp):
            if _optimize_png(tmp, final_icon):
                icon_rel = os.path.join('icons', slug + '.png')
            try:
                os.remove(tmp)
            except Exception:
                pass

    banner_url = meta.get('banner_url', '')
    if banner_url:
        final_banner = os.path.join(BANNER_DIR, slug + '.jpg')
        if _download_file(banner_url, final_banner):
            banner_rel = os.path.join('banners', slug + '.jpg')

    return icon_rel, banner_rel


def add_channel_from_url(url, genre_id):
    """Fuegt einen Kanal per URL, Handle oder UC-ID hinzu."""
    from resources.lib.api import get_channel_metadata, resolve_handle_to_id

    handle, channel_id = extract_handle_or_id(url)
    if not channel_id and handle:
        channel_id = resolve_handle_to_id(handle)
    if not channel_id:
        return False, 'Kanal-ID konnte nicht ermittelt werden.'

    meta = get_channel_metadata(channel_id) or {}
    name = meta.get('title') or handle or channel_id
    slug = slugify(name)
    icon_rel, banner_rel = save_channel_images(meta, slug)

    channels = load_user_channels()
    for ch in channels:
        if ch.get('id') == channel_id:
            ch.update({
                'name': name,
                'genre': genre_id,
                'handle': handle or ch.get('handle', ''),
                'icon': icon_rel or ch.get('icon', ''),
                'banner': banner_rel or ch.get('banner', ''),
                'description': meta.get('description', ch.get('description', '')),
            })
            save_user_channels(channels)
            return True, 'Kanal aktualisiert.'

    channels.append({
        'id': channel_id,
        'name': name,
        'genre': genre_id,
        'handle': handle,
        'icon': icon_rel,
        'banner': banner_rel,
        'description': meta.get('description', ''),
        'enabled': True,
        'user_added': True,
    })
    save_user_channels(channels)
    return True, 'Kanal hinzugefuegt.'


def delete_user_channel(channel_id):
    channels = load_user_channels()
    new_channels = [c for c in channels if c.get('id') != channel_id]
    save_user_channels(new_channels)
    return len(new_channels) != len(channels)


def move_user_channel(channel_id, genre_id):
    channels = load_user_channels()
    ok = False
    for ch in channels:
        if ch.get('id') == channel_id:
            ch['genre'] = genre_id
            ok = True
            break
    save_user_channels(channels)
    return ok


def export_backup():
    _ensure_dirs()
    try:
        shutil.copy(CHANNELS_JSON, BACKUP_JSON)
        return BACKUP_JSON
    except Exception:
        return ''


def import_backup():
    _ensure_dirs()
    if not os.path.exists(BACKUP_JSON):
        return False
    try:
        shutil.copy(BACKUP_JSON, CHANNELS_JSON)
        return True
    except Exception:
        return False


def search_youtube_channels(query, max_results=10):
    """Sucht YouTube-Kanaele per Schlagwort und liefert Treffer fuer die Auswahl."""
    from resources.lib.api import _get, has_api_key
    if not query or not has_api_key():
        return []
    data = _get('search', {
        'part': 'snippet',
        'q': query,
        'type': 'channel',
        'maxResults': max_results,
        'order': 'relevance',
        'relevanceLanguage': 'de',
    }, ttl=15 * 60)
    if not data:
        return []

    results = []
    for item in data.get('items', []):
        sn = item.get('snippet', {})
        cid = item.get('id', {}).get('channelId', '')
        if not cid:
            continue
        thumbs = sn.get('thumbnails', {})
        icon_url = (thumbs.get('high') or thumbs.get('medium') or thumbs.get('default') or {}).get('url', '')
        results.append({
            'id': cid,
            'name': sn.get('channelTitle') or sn.get('title') or cid,
            'handle': '',
            'description': sn.get('description', ''),
            'icon_url': icon_url,
            'banner_url': '',
        })
    return results


def add_channel_from_search_result(result, genre_id):
    """Fuegt einen Kanal aus der Suchtrefferliste hinzu."""
    channel_id = result.get('id', '')
    if not channel_id:
        return False, 'Kanal-ID fehlt.'

    meta = {
        'title': result.get('name', channel_id),
        'description': result.get('description', ''),
        'icon_url': result.get('icon_url', ''),
        'banner_url': result.get('banner_url', ''),
    }

    # Falls moeglich, vollstaendige Metadaten nachladen.
    try:
        from resources.lib.api import get_channel_metadata
        full = get_channel_metadata(channel_id) or {}
        if full:
            meta.update(full)
    except Exception:
        pass

    name = meta.get('title') or result.get('name') or channel_id
    slug = slugify(name)
    icon_rel, banner_rel = save_channel_images(meta, slug)

    channels = load_user_channels()
    for ch in channels:
        if ch.get('id') == channel_id:
            ch.update({
                'name': name,
                'genre': genre_id,
                'icon': icon_rel or ch.get('icon', ''),
                'banner': banner_rel or ch.get('banner', ''),
                'description': meta.get('description', ch.get('description', '')),
            })
            save_user_channels(channels)
            return True, 'Kanal aktualisiert.'

    channels.append({
        'id': channel_id,
        'name': name,
        'genre': genre_id,
        'handle': result.get('handle', ''),
        'icon': icon_rel,
        'banner': banner_rel,
        'description': meta.get('description', ''),
        'enabled': True,
        'user_added': True,
    })
    save_user_channels(channels)
    return True, 'Kanal hinzugefuegt.'
