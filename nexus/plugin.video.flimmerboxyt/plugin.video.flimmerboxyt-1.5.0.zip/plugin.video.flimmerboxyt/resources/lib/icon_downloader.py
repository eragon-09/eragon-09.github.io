"""
Icon-Downloader fuer FlimmerBoxYT – TiTanX Lab
Laedt Kanal-Profilbilder per YouTube API in Batches von 50
um API-Kontingent zu schonen (50 Channels = 1 Unit statt 50).
"""
import os, re, json
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
from urllib.request import urlopen, Request

ADDON    = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
# Gespeichert in userdata/addon_data/ – bleibt bei Updates erhalten
ICON_DIR = xbmcvfs.translatePath(
    f'special://userdata/addon_data/{ADDON_ID}/channels/')
YT_API   = 'https://www.googleapis.com/youtube/v3'


def _slugify(name):
    text = (name or '').lower()
    repl = {'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss',
            'á': 'a',  'à': 'a',  'é': 'e',  'è': 'e'}
    for a, b in repl.items():
        text = text.replace(a, b)
    return re.sub(r'[^a-z0-9]+', '_', text).strip('_') or 'channel'


def _get_api_key():
    try:
        k = ADDON.getSetting('youtube_api_key').strip()
        if k:
            return k
    except Exception:
        pass
    return 'AIzaSyDnlJ0e_CZlLoZm7CMNnO41xInZgVFyObo'


def _fetch_icons_batch(channel_ids, api_key):
    """
    Holt Icons fuer bis zu 50 Kanaele in EINEM API-Call.
    Gibt dict {channel_id: thumbnail_url} zurueck.
    """
    ids_str  = ','.join(channel_ids)
    req_url  = (f"{YT_API}/channels"
                f"?part=snippet&id={ids_str}&key={api_key}"
                f"&fields=items(id,snippet/thumbnails)")
    result = {}
    try:
        r    = urlopen(Request(req_url,
                               headers={'Accept': 'application/json'}),
                       timeout=15)
        data = json.loads(r.read().decode())
        for item in data.get('items', []):
            cid    = item.get('id', '')
            thumbs = item.get('snippet', {}).get('thumbnails', {})
            for size in ('high', 'medium', 'default'):
                url = thumbs.get(size, {}).get('url', '')
                if url:
                    result[cid] = url
                    break
    except Exception as e:
        xbmc.log(f'FlimmerBoxYT batch fetch error: {e}', xbmc.LOGWARNING)
    return result


def _download_image(url, path):
    """Laedt Bild herunter, speichert als JPG 256x256 max 80KB."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        r    = urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=15)
        data = r.read()
        try:
            from PIL import Image
            import io
            img = Image.open(io.BytesIO(data)).convert('RGB')
            img = img.resize((256, 256), Image.LANCZOS)
            for quality in (85, 75, 65, 55):
                buf = io.BytesIO()
                img.save(buf, 'JPEG', quality=quality, optimize=True)
                if buf.tell() <= 81920:  # 80KB
                    break
            with open(path, 'wb') as f:
                f.write(buf.getvalue())
        except Exception:
            # Fallback ohne PIL – direkt speichern
            with open(path, 'wb') as f:
                f.write(data)
        return os.path.getsize(path) > 0
    except Exception as e:
        xbmc.log(f'FlimmerBoxYT icon save error: {e}', xbmc.LOGWARNING)
        return False


def download_all_icons():
    """Laedt alle Kanal-Icons in Batches von 50 herunter."""
    from resources.lib.channels import BUILTIN_CHANNELS

    api_key  = _get_api_key()
    channels = [c for c in BUILTIN_CHANNELS
                if c.get('id', '').startswith('UC')]

    # Bereits vorhandene überspringen
    to_download = []
    skipped     = 0
    for ch in channels:
        slug = _slugify(ch.get('name', ''))
        path = os.path.join(ICON_DIR, f'{slug}.jpg')
        if os.path.exists(path) and os.path.getsize(path) > 0:
            skipped += 1
        else:
            to_download.append(ch)

    if not to_download:
        xbmcgui.Dialog().ok('FlimmerBoxYT Icons',
                            f'Alle {skipped} Icons bereits vorhanden.')
        return

    total   = len(to_download)
    success = 0
    failed  = 0
    BATCH   = 50

    dialog = xbmcgui.DialogProgress()
    dialog.create('FlimmerBoxYT', f'Lade {total} Kanal-Icons...')

    # Batches von 50 verarbeiten
    for batch_start in range(0, total, BATCH):
        if dialog.iscanceled():
            break

        batch    = to_download[batch_start:batch_start + BATCH]
        id_map   = {ch['id']: ch for ch in batch}
        pct      = int(batch_start / total * 100)

        dialog.update(pct,
            f'Batch {batch_start//BATCH + 1} von {(total-1)//BATCH + 1} '
            f'({batch_start+1}-{min(batch_start+BATCH, total)} / {total})')

        # Ein API-Call fuer alle 50
        icon_urls = _fetch_icons_batch(list(id_map.keys()), api_key)

        # Icons herunterladen
        for ch_id, ch in id_map.items():
            slug = _slugify(ch.get('name', ''))
            path = os.path.join(ICON_DIR, f'{slug}.jpg')
            url  = icon_urls.get(ch_id, '')
            if url and _download_image(url, path):
                success += 1
            else:
                failed += 1

        xbmc.sleep(200)  # kurze Pause zwischen Batches

    dialog.close()

    msg = (f'{success} heruntergeladen\n'
           f'{skipped} bereits vorhanden\n'
           f'{failed} Fehler')
    xbmcgui.Dialog().ok('FlimmerBoxYT Icons', msg)
    xbmc.log(f'FlimmerBoxYT Icons: {msg.replace(chr(10), " | ")}',
             xbmc.LOGINFO)
