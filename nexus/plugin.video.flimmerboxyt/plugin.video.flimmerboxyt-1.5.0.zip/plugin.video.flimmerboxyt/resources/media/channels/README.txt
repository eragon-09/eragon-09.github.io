Lokale Kanalicons
Empfohlene Groesse: 256x256 PNG
Dateiname z.B. national_geographic.png, terra_x.png usw.
Diese Struktur vermeidet spaetere API-Aufrufe fuer Kanalbilder.
