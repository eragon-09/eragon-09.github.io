# -*- coding: utf-8 -*-
"""
Titan Core Mod — lokale Portal/MAC-Integration.

Integrierte Funktionen aus plugin.program.local.portal.mac.switcher:
- lokale JSON-Portalquelle automatisch erkennen
- MAC-Ablaufdatum anzeigen und abgelaufene MACs filtern
- Zufalls-MAC nur aus Einträgen mit > 30 Tagen Restlaufzeit
- letzte lokale Portal/MAC-Auswahl persistent speichern
- optionale PVR-Stalker-Aktualisierung
"""
from __future__ import absolute_import, division, unicode_literals

import datetime
import json
import os
import random
import re
import urllib.request
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# Addon ID
STALKER_ID = "plugin.video.titanmacvodedition"
TITLE = "Titan Core Mod"

# Local switcher sources
DATA_ID = "script.portal.mac.converter"
PORTAL_DIR_CANDIDATES = [
    "special://profile/addon_data/%s/2_JSON_Export" % DATA_ID,
    "special://userdata/addon_data/%s/2_JSON_Export" % DATA_ID,
    "special://home/userdata/addon_data/%s/2_JSON_Export" % DATA_ID,
    "special://home/addon_data/%s/2_JSON_Export" % DATA_ID,
    "special://profile/addon_data/%s/portal_mac_list_out" % DATA_ID,
    "special://userdata/addon_data/%s/portal_mac_list_out" % DATA_ID,
]
LOCAL_TOKEN_DIR = "special://profile/addon_data/%s" % STALKER_ID
LOCAL_TOKEN_PATH = "%s/last_local_selection.json" % LOCAL_TOKEN_DIR
PVR_DIR_CANDIDATES = [
    "special://profile/addon_data/pvr.stalker",
    "special://userdata/addon_data/pvr.stalker",
]

_URL_RE = re.compile(r"^https?://", re.I)
_MAC_RE = re.compile(r"^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")

# State
selected_portal = None
selected_portal_url = None
selected_server_index = None
selected_server_id = None
selected_mac = None
selected_mac_label = None
selected_mac_exp = None
selected_source = None  # 'remote' or 'local'
selected_local_file = None
selected_local_cfg = None


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (STALKER_ID, msg), level)
    except Exception:
        pass


def _val_error(msg: str):
    xbmcgui.Dialog().ok(TITLE, msg)


def _exists(path: str) -> bool:
    try:
        if xbmcvfs.exists(path):
            return True
        fs = xbmcvfs.translatePath(path)
        return bool(fs) and os.path.exists(fs)
    except Exception:
        return False


def _ensure_dir(special_dir: str):
    try:
        if not xbmcvfs.exists(special_dir):
            xbmcvfs.mkdirs(special_dir)
    except Exception:
        fs = xbmcvfs.translatePath(special_dir)
        if fs and not os.path.exists(fs):
            os.makedirs(fs, exist_ok=True)


def _read_text(path: str) -> str:
    try:
        f = xbmcvfs.File(path, "r")
        data = f.read()
        f.close()
        return data
    except Exception:
        return ""


def _write_text(path: str, data: str):
    fs_path = xbmcvfs.translatePath(path)
    parent = os.path.dirname(fs_path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    f = xbmcvfs.File(path, "w")
    f.write(data)
    f.close()


def _cachebust(url: str) -> str:
    sep = '&' if '?' in url else '?'
    return "%s%sts=%d" % (url, sep, random.randrange(1_000_000_000))


def _is_valid_url(u: str) -> bool:
    try:
        return isinstance(u, str) and u.lower().startswith(("http://", "https://")) and "://" in u and len(u.split("://", 1)[1]) > 0
    except Exception:
        return False


def _hostname_from_url(url: str) -> str:
    try:
        return urlparse(url).hostname or url
    except Exception:
        return url or "—"


def _hostname_from_filename(filename: str) -> str:
    if filename and filename.lower().endswith(".json"):
        return filename[:-5]
    return filename or "—"


def _days_left(exp_str: str):
    if not exp_str:
        return None
    try:
        exp_date = datetime.datetime.strptime(exp_str, "%Y-%m-%d").date()
        return (exp_date - datetime.date.today()).days
    except Exception:
        return None


def _exp_display(exp_str: str) -> str:
    days = _days_left(exp_str)
    if days is None:
        return "[COLOR grey]kein Datum[/COLOR]"
    try:
        dt = datetime.datetime.strptime(exp_str, "%Y-%m-%d")
        readable = dt.strftime("%d.%m.%Y")
    except Exception:
        readable = exp_str

    if days > 60:
        color = "lime"
    elif days > 30:
        color = "orange"
    else:
        color = "red"
    return "[COLOR %s]bis %s[/COLOR]" % (color, readable)


def _mac_desc(mac: str, exp_str: str) -> str:
    return "%s  %s" % (mac, _exp_display(exp_str)) if exp_str else "%s  [COLOR grey]kein Datum[/COLOR]" % mac



# -----------------------------
# Local switcher helpers
# -----------------------------
def _resolve_portal_dir() -> Optional[str]:
    for p in PORTAL_DIR_CANDIDATES:
        if _exists(p):
            _log("Lokaler Portal-Ordner gefunden: %s" % p)
            return p
    return None


def _valid_macs(cfg) -> List[Dict[str, str]]:
    today = datetime.date.today()
    out = []
    for m in cfg.get("macs", []):
        if isinstance(m, dict):
            mac = (m.get("mac") or "").strip()
            exp = (m.get("exp") or "").strip()
            if not mac or not _MAC_RE.match(mac):
                continue
            if exp:
                try:
                    if datetime.datetime.strptime(exp, "%Y-%m-%d").date() < today:
                        continue
                except Exception:
                    pass
            out.append({"mac": mac, "exp": exp})
        elif isinstance(m, str):
            s = m.strip()
            if s and _MAC_RE.match(s):
                out.append({"mac": s, "exp": ""})
    return out


def _load_local_cfg(portal_dir: str, filename: str):
    try:
        raw = _read_text("%s/%s" % (portal_dir, filename))
        cfg = json.loads(raw)
        url = (cfg.get("portal") or "").strip()
        if not url:
            return None, "Feld 'portal' fehlt"
        macs = _valid_macs(cfg)
        if not macs:
            return None, "Keine gültigen oder nicht abgelaufenen MACs"
        cfg["_portal"] = url
        cfg["_macs"] = macs
        cfg["_hostname"] = _hostname_from_url(url)
        return cfg, None
    except Exception as e:
        return None, str(e)


def _load_all_local_cfgs(portal_dir: str):
    try:
        _dirs, files = xbmcvfs.listdir(portal_dir)
    except Exception:
        return [], [], []
    files = sorted(f for f in files if f.lower().endswith(".json"))
    labels = []
    cfgs = []
    for fn in files:
        cfg, err = _load_local_cfg(portal_dir, fn)
        hostname = _hostname_from_filename(fn)
        if cfg:
            labels.append("%s  [COLOR grey](%d MACs)[/COLOR]" % (hostname, len(cfg["_macs"])))
            cfgs.append(cfg)
        else:
            labels.append("[COLOR orange]%s – %s[/COLOR]" % (hostname, err))
            cfgs.append(None)
    return files, labels, cfgs


def _save_local_token(selected_file: Optional[str], selected_portal_url: Optional[str], selected_mac: Optional[str], selected_mac_exp: Optional[str] = None):
    try:
        _ensure_dir(LOCAL_TOKEN_DIR)
        _write_text(
            LOCAL_TOKEN_PATH,
            json.dumps({
                "selected_file": selected_file or "",
                "selected_portal_url": selected_portal_url or "",
                "selected_mac": selected_mac or "",
                "selected_mac_exp": selected_mac_exp or "",
            }, indent=2),
        )
    except Exception as e:
        _log("Konnte lokalen Token nicht speichern: %s" % e, xbmc.LOGWARNING)


def _load_local_token(portal_dir: Optional[str]):
    if not portal_dir or not _exists(LOCAL_TOKEN_PATH):
        return None
    try:
        data = json.loads(_read_text(LOCAL_TOKEN_PATH) or "{}")
        sf = (data.get("selected_file") or "").strip()
        sm = (data.get("selected_mac") or "").strip()
        sme = (data.get("selected_mac_exp") or "").strip()
        if not sf:
            return None
        cfg, _ = _load_local_cfg(portal_dir, sf)
        if not cfg:
            return None
        return {
            "selected_file": sf,
            "selected_portal_url": cfg["_portal"],
            "selected_mac": sm or None,
            "selected_mac_exp": sme or None,
            "cfg": cfg,
        }
    except Exception:
        return None


# -----------------------------
# Settings / state helpers
# -----------------------------
def _persist_settings(server_url: Optional[str] = None, mac: Optional[str] = None):
    try:
        a = xbmcaddon.Addon(id=STALKER_ID)
        if server_url is not None:
            a.setSetting("server_address", server_url)
        if mac is not None:
            a.setSetting("mac_address", mac)
    except Exception:
        pass


def _clear_mac_state():
    global selected_mac, selected_mac_label, selected_mac_exp
    selected_mac = None
    selected_mac_label = None
    selected_mac_exp = None
    _persist_settings(mac="")


def _addon_data_path():
    try:
        return xbmcvfs.translatePath("special://profile/addon_data/%s/" % STALKER_ID)
    except Exception:
        return ""


def clear_portal_cache_files():
    base = _addon_data_path()
    if not base:
        return

    # Delete token and portal EPG cache files
    for fn in ("token.json", "epg.json"):
        p = base + fn
        try:
            if xbmcvfs.exists(p):
                xbmcvfs.delete(p)
        except Exception:
            pass

    # Delete all zap context files (zap_*.json)
    try:
        import glob
        for zap_file in glob.glob(os.path.join(base, "zap_*.json")):
            try:
                os.remove(zap_file)
            except Exception:
                pass
    except Exception:
        pass

    # Clear in-memory EPG cache (portal)
    try:
        from .api import clear_epg_cache  # correct relative import
        clear_epg_cache()
    except Exception:
        pass

    # Clear XMLTV cache (disk + memory) – XMLTV is portal-specific via channel mapping
    try:
        from .xmltv import clear_xmltv_cache
        clear_xmltv_cache()
    except Exception:
        pass


def _reset_runtime_state():
    try:
        from .globals import G
        G.init_globals()
    except Exception:
        pass
    try:
        from .auth import Auth
        Auth().clear_cache()
    except Exception:
        pass


def _go_home(portal_name=None, mac=None):
    try:
        if portal_name:
            msg = portal_name
            if mac:
                msg = "%s\nMAC: %s" % (portal_name, mac)
            xbmcgui.Dialog().notification(TITLE, msg, xbmcgui.NOTIFICATION_INFO, 3500)
    except Exception:
        pass
    # Brief pause so Kodi flushes the written settings to disk before the
    # new plugin process starts and reads them via xbmcaddon.Addon(id=...).
    xbmc.sleep(300)
    _reset_runtime_state()
    try:
        xbmc.executebuiltin("Container.Update(plugin://%s/,replace)" % STALKER_ID)
    except Exception:
        pass


def manual_clear_cache():
    try:
        confirmed = xbmcgui.Dialog().yesno(TITLE, "Willst du wirklich den Cache löschen?")
    except Exception:
        confirmed = True
    if not confirmed:
        return

    # clear_portal_cache_files already handles: token, epg, zap files, XMLTV disk+memory, in-memory EPG
    clear_portal_cache_files()
    _reset_runtime_state()

    try:
        xbmcgui.Dialog().notification(TITLE, "Cache vollständig gelöscht (EPG, Token, XMLTV, Zapping)", xbmcgui.NOTIFICATION_INFO, 3500)
    except Exception:
        pass

    try:
        xbmc.executebuiltin("Container.Update(plugin://%s/,replace)" % STALKER_ID)
    except Exception:
        try:
            xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass


def _rehydrate_selection_from_settings():
    global selected_portal, selected_portal_url, selected_server_index, selected_server_id
    global selected_source, selected_local_file, selected_local_cfg, selected_mac_exp

    portal_dir = _resolve_portal_dir()
    token = _load_local_token(portal_dir)
    if token and token.get("selected_portal_url"):
        selected_source = "local"
        selected_local_file = token.get("selected_file")
        selected_local_cfg = token.get("cfg")
        selected_portal_url = token.get("selected_portal_url")
        selected_portal = token.get("cfg", {}).get("_hostname") or _hostname_from_url(selected_portal_url)
        selected_mac_exp = token.get("selected_mac_exp")
        return True

    try:
        stored = xbmcaddon.Addon(id=STALKER_ID).getSetting("server_address")
    except Exception:
        stored = ""
    if not stored:
        return False

    selected_source = "manual"
    selected_portal_url = stored
    selected_portal = _hostname_from_url(stored) or "Manuelles Portal"
    selected_server_index = None
    selected_server_id = None
    selected_local_file = None
    selected_local_cfg = None
    return True


# -----------------------------
# Public actions
# -----------------------------
def choose_server():
    global selected_portal, selected_portal_url, selected_server_index, selected_server_id
    global selected_source, selected_local_file, selected_local_cfg

    portal_dir = _resolve_portal_dir()
    if not portal_dir:
        xbmcgui.Dialog().ok(TITLE, "Kein Portal-Export vom Portal MAC Converter gefunden.")
        return

    files, labels, cfgs = _load_all_local_cfgs(portal_dir)
    if not files:
        xbmcgui.Dialog().ok(TITLE, "Keine gültigen lokalen Portaleinträge gefunden.")
        return

    idx = xbmcgui.Dialog().select("Portal wählen", labels)
    if idx == -1:
        return
    cfg = cfgs[idx]
    if not cfg:
        xbmcgui.Dialog().ok(TITLE, "Ungültiger lokaler Portal-Eintrag.")
        return

    selected_source = "local"
    selected_local_file = files[idx]
    selected_local_cfg = cfg
    selected_portal = cfg.get("_hostname") or _hostname_from_filename(files[idx])
    selected_portal_url = cfg.get("_portal")
    selected_server_index = None
    selected_server_id = None
    clear_portal_cache_files()
    _persist_settings(server_url=selected_portal_url)
    _clear_mac_state()
    _save_local_token(selected_local_file, selected_portal_url, None, None)
    # Do NOT navigate home yet – user must select a MAC before any API call is made.
    xbmcgui.Dialog().notification(
        TITLE,
        'Portal gesetzt: {}  →  Bitte jetzt MAC wählen!'.format(selected_portal),
        xbmcgui.NOTIFICATION_INFO, 5000
    )



def choose_mac():
    global selected_mac, selected_mac_label, selected_portal, selected_portal_url, selected_server_index, selected_server_id
    global selected_source, selected_local_file, selected_local_cfg, selected_mac_exp

    if selected_portal_url is None:
        if not _rehydrate_selection_from_settings():
            xbmcgui.Dialog().ok(TITLE, "Bitte zuerst ein Portal wählen!")
            return

    if selected_source == "local":
        portal_dir = _resolve_portal_dir()
        cfg = selected_local_cfg
        if (not cfg) and portal_dir and selected_local_file:
            cfg, _ = _load_local_cfg(portal_dir, selected_local_file)
        if not cfg and portal_dir:
            token = _load_local_token(portal_dir)
            if token:
                cfg = token.get("cfg")
                selected_local_file = token.get("selected_file")
                selected_portal_url = token.get("selected_portal_url")
                selected_portal = cfg.get("_hostname") if cfg else selected_portal
        if not cfg:
            xbmcgui.Dialog().ok(TITLE, "Kein lokales Portal gewählt oder JSON nicht gefunden.")
            return

        mac_items = cfg.get("_macs", [])
        if not mac_items:
            xbmcgui.Dialog().ok(TITLE, "Keine gültigen MACs oder kein Portal gewählt.")
            return

        long_macs = [m for m in mac_items if _days_left(m.get("exp")) is None or (_days_left(m.get("exp")) or 999) > 30]
        random_label = '[B][COLOR lime]Zufällige MAC[/COLOR][/B]'
        if not long_macs:
            random_label = '[COLOR grey]Zufällige MAC[/COLOR]'

        labels = [random_label] + [_mac_desc(m.get("mac", ""), m.get("exp", "")) for m in mac_items]
        idx = xbmcgui.Dialog().select("MAC wählen", labels)
        if idx == -1:
            return
        if idx == 0:
            if not long_macs:
                xbmcgui.Dialog().ok(TITLE, "Keine MAC mit mehr als 30 Tagen Restlaufzeit verfügbar.")
                return
            choice = random.choice(long_macs)
        else:
            choice = mac_items[idx - 1]

        selected_mac = choice.get("mac")
        selected_mac_exp = choice.get("exp") or None
        selected_mac_label = _mac_desc(selected_mac, selected_mac_exp or "")
        clear_portal_cache_files()
        _persist_settings(server_url=selected_portal_url, mac=selected_mac)
        _save_local_token(selected_local_file, selected_portal_url, selected_mac, selected_mac_exp)
        _go_home(portal_name=selected_portal or cfg.get("_hostname"), mac=selected_mac)
        return

def apply_pvr():
    portal_url = selected_portal_url
    mac = selected_mac
    if not portal_url or not mac:
        try:
            addon = xbmcaddon.Addon(id=STALKER_ID)
            portal_url = portal_url or addon.getSetting("server_address")
            mac = mac or addon.getSetting("mac_address")
        except Exception:
            pass

    if not portal_url or not mac:
        xbmcgui.Dialog().ok(TITLE, "Bitte zuerst Portal und MAC wählen.")
        return

    xml_content = (
        '<settings version="2">'
        '<setting id="kodi_addon_instance_enabled">true</setting>'
        '<setting id="mac">%s</setting>'
        '<setting id="server">%s</setting>'
        '<setting id="time_zone">Europe/Berlin</setting>'
        '</settings>'
    ) % (mac, portal_url)

    written_any = False
    for d in PVR_DIR_CANDIDATES:
        if _exists(d):
            _dirs, files = xbmcvfs.listdir(d)
            for f in files:
                if f.startswith("instance-settings-") and f.endswith(".xml"):
                    _write_text("%s/%s" % (d, f), xml_content)
                    written_any = True
                    _log("PVR geschrieben: %s/%s" % (d, f))

    if not written_any:
        fallback = "%s/instance-settings-1.xml" % PVR_DIR_CANDIDATES[0]
        _write_text(fallback, xml_content)
        written_any = True
        _log("PVR Fallback geschrieben: %s" % fallback)

    if written_any:
        try:
            xbmc.executebuiltin("UpdateLibrary(video)")
            xbmc.executebuiltin("Addon.Enable(pvr.stalker)")
        except Exception:
            pass
        xbmcgui.Dialog().notification(TITLE, "PVR aktualisiert", xbmcgui.NOTIFICATION_INFO, 3000)



def activate():
    if not selected_portal_url:
        xbmcgui.Dialog().ok(TITLE, "Bitte zuerst Portal wählen!")
        return
    if not selected_mac:
        xbmcgui.Dialog().ok(TITLE, "Bitte passenden Zugang (MAC) wählen!")
        return
    try:
        stalker = xbmcaddon.Addon(id=STALKER_ID)
        stalker.setSetting("server_address", selected_portal_url)
        stalker.setSetting("mac_address", selected_mac)
        xbmcgui.Dialog().ok("Aktivieren", "Connect:\n%s\nMAC %s gesetzt" % (selected_portal, selected_mac))
    except Exception:
        xbmcgui.Dialog().ok("Aktivieren", "Connect:\n%s\nMAC %s gesetzt" % (selected_portal, selected_mac))
