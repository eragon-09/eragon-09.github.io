"""Module to initializes global setting for the plugin"""

from __future__ import absolute_import, division, unicode_literals
import os
import sys
from urllib.parse import urlencode, urlsplit
import dataclasses
import xbmcaddon
import xbmcvfs
from .loggers import Logger

ADDON_ID = 'plugin.video.titanmacvodedition'


@dataclasses.dataclass
class PortalConfig:
    """Portal config"""
    mac_cookie: str = None
    portal_url: str = None
    device_id: str = None
    device_id_2: str = None
    signature: str = None
    serial_number: str = None
    portal_base_url: str = None
    server_address: str = None
    alternative_context_path: bool = False


@dataclasses.dataclass
class AddOnConfig:
    """Addon config"""
    url: str = None
    addon_id: str = None
    name: str = None
    handle: str = None
    addon_data_path: str = None
    max_page_limit: int = 6
    max_retries: int = 3
    token_path: str = None


class GlobalVariables:
    """Class initializes global settings used by the plugin"""

    def __init__(self):
        """Init class"""
        self.__is_addd_on_first_run = None
        self.addon_config = AddOnConfig()
        self.portal_config = PortalConfig()

    @staticmethod
    def _get_addon():
        """Always return a fresh Addon instance using the explicit addon ID.
        xbmcaddon.Addon() without an ID can return a stale cached instance
        in the service context and will not reflect settings written by other
        processes (e.g. choose_server / choose_mac in the plugin process)."""
        return xbmcaddon.Addon(id=ADDON_ID)

    def init_globals(self):
        """Init global settings.

        Note:
        - Addon metadata is initialized once.
        - Portal/MAC related settings are refreshed every run so portal/mac
          switches take effect without requiring a Kodi restart.
        """
        self.__is_addd_on_first_run = self.__is_addd_on_first_run is None
        self.addon_config.url = sys.argv[0] if sys.argv else ''

        if self.__is_addd_on_first_run:
            Logger.debug("First run, loading global variables")
            addon = self._get_addon()
            self.addon_config.addon_id = addon.getAddonInfo('id')
            self.addon_config.name = addon.getAddonInfo('name')
            self.addon_config.addon_data_path = addon.getAddonInfo('path')
            token_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
            if not xbmcvfs.exists(token_path):
                xbmcvfs.mkdirs(token_path)
            self.addon_config.token_path = token_path
            # sys.argv[1] (plugin handle) only exists in plugin mode, not in service mode
            self.addon_config.handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1

        # Dynamic portal settings – always refresh so portal/MAC changes are picked up
        self.__refresh_portal_settings()

    def __refresh_portal_settings(self):
        """Reload settings that may change during a Kodi session."""
        addon = self._get_addon()
        self.portal_config.mac_cookie = 'mac=' + addon.getSetting('mac_address')
        self.portal_config.device_id = addon.getSetting('device_id')
        self.portal_config.device_id_2 = addon.getSetting('device_id_2')
        self.portal_config.signature = addon.getSetting('signature')
        self.portal_config.serial_number = addon.getSetting('serial_number')
        self.portal_config.alternative_context_path = addon.getSetting('alternative_context_path') == 'true'
        self.__set_portal_addresses(addon)

    def get_handle(self):
        """Get addon handle"""
        return self.addon_config.handle

    def get_custom_thumb_path(self, thumb_file_name):
        """Get thumb file path"""
        return os.path.join(self.addon_config.addon_data_path, 'resources', 'media', thumb_file_name)

    def get_plugin_url(self, params):
        """Get plugin url"""
        return '{}?{}'.format(self.addon_config.url, urlencode(params))

    def __get_portal_base_url(self):
        """Get portal base url"""
        split_url = urlsplit(self.portal_config.server_address)
        return split_url.scheme + '://' + split_url.netloc

    def __set_portal_addresses(self, addon):
        """Set portal urls"""
        self.portal_config.server_address = addon.getSetting('server_address')
        self.portal_config.portal_base_url = self.__get_portal_base_url()

        if not self.portal_config.server_address or not self.portal_config.portal_base_url:
            if not self.portal_config.server_address:
                Logger.error("Setting 'server_address' is empty. Please select/set a portal URL.")
            else:
                Logger.error("Invalid 'server_address' (missing scheme/host): {}".format(
                    self.portal_config.server_address))
            self.portal_config.portal_url = None
            return

        self.portal_config.portal_url = self.get_portal_url()

    def get_portal_url(self):
        """Get portal url"""
        context_path = '/portal.php' if self.portal_config.alternative_context_path else '/server/load.php'
        portal_url = self.portal_config.portal_base_url + '/stalker_portal' + context_path
        if self.portal_config.server_address.endswith('/c/'):
            portal_url = self.portal_config.server_address.replace('/c/', '') + context_path
        elif self.portal_config.server_address.endswith('/c'):
            portal_url = self.portal_config.server_address.replace('/c', '') + context_path
        return portal_url


G = GlobalVariables()
