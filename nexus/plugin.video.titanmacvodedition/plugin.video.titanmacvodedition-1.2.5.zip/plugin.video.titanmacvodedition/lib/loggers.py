"""Logger class"""
from __future__ import absolute_import, division, unicode_literals
import xbmc
import xbmcaddon

_ADDON_ID = 'plugin.video.titanmacvodedition'


class Logger:
    """Logger – debug() only writes when debug_logging is enabled in settings."""

    @staticmethod
    def _debug_enabled():
        try:
            return xbmcaddon.Addon(_ADDON_ID).getSettingBool('debug_logging')
        except Exception:
            try:
                return xbmcaddon.Addon(_ADDON_ID).getSetting('debug_logging').lower() in ('true', '1')
            except Exception:
                return False

    @staticmethod
    def log(message, level=xbmc.LOGDEBUG):
        xbmc.log('{}: {}'.format(_ADDON_ID, message), level)

    @staticmethod
    def info(message):
        Logger.log(message, xbmc.LOGINFO)

    @staticmethod
    def error(message):
        Logger.log(message, xbmc.LOGERROR)

    @staticmethod
    def warn(message):
        Logger.log(message, xbmc.LOGWARNING)

    @staticmethod
    def debug(message):
        if Logger._debug_enabled():
            Logger.log(message, xbmc.LOGDEBUG)
