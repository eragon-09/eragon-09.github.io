"""Module for auth"""
from __future__ import absolute_import, division, unicode_literals
import os
import json
import dataclasses
import requests
import xbmcvfs
import xbmcgui
from .globals import G
from .loggers import Logger
from .utils import get_request_timeout


@dataclasses.dataclass
class Token:
    """Token"""
    value: str = None


class Auth:
    """Auth API"""

    __TOKEN_FILE = 'token.json'

    def __init__(self):
        self.__token_path = os.path.join(G.addon_config.token_path, self.__TOKEN_FILE)
        self.__token = Token()
        self.__load_cache()
        self.__url = G.portal_config.portal_url
        self.__mac_cookie = G.portal_config.mac_cookie
        self.__referrer = G.portal_config.server_address

    def get_token(self, refresh_token):
        """Get Token"""
        Logger.debug('Token path {}'.format(self.__token_path))
        if self.__token.value:
            if refresh_token:
                self.__refresh_token()
            return self.__token.value
        self.clear_cache()
        Logger.debug('Getting token from {}'.format(self.__url))
        response = requests.get(url=self.__url,
                                headers={'Cookie': self.__mac_cookie, 'X-User-Agent': 'Model: MAG250; Link: WiFi', 'Referrer': self.__referrer,
                                         'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'},
                                params={'type': 'stb', 'action': 'handshake'},
                                timeout=get_request_timeout()
                                )
        if response.status_code != 200 or response.text.find('Authorization failed') != -1:
            Logger.error('Error getting token, statusCode={}'.format(response.status_code))
            Logger.debug('Token Response {}'.format(response.text))
            xbmcgui.Dialog().notification(
                G.addon_config.name or 'TitanMacVOD',
                'Token-Fehler (HTTP {}). Portal prüfen.'.format(response.status_code),
                xbmcgui.NOTIFICATION_ERROR, 5000)
            return ''
        try:
            parsed = response.json()
            token = (parsed.get('js') or {}).get('token') or ''
            if not token:
                Logger.error('Handshake returned no token. Response: {}'.format(response.text[:200]))
                xbmcgui.Dialog().notification(
                    G.addon_config.name or 'TitanMacVOD',
                    'Kein Token erhalten. Portal oder MAC prüfen.',
                    xbmcgui.NOTIFICATION_ERROR, 5000)
                return ''
            self.__token.value = token
        except Exception as exc:
            Logger.error('Token JSON parse error: {}  body={}'.format(exc, response.text[:200]))
            xbmcgui.Dialog().notification(
                G.addon_config.name or 'TitanMacVOD',
                'Ungültige Portal-Antwort beim Token-Abruf.',
                xbmcgui.NOTIFICATION_ERROR, 5000)
            return ''
        self.__refresh_token()
        self.__save_cache()
        return self.__token.value

    def clear_cache(self):
        """Clear token from cache"""
        self.__token = Token()
        if xbmcvfs.exists(self.__token_path):
            xbmcvfs.delete(self.__token_path)

    def __refresh_token(self):
        """Refresh token"""
        Logger.debug('Refreshing token')
        requests.get(url=self.__url,
                     headers={'Cookie': self.__mac_cookie, 'SN': G.portal_config.serial_number, 'Authorization': 'Bearer ' + self.__token.value,
                              'X-User-Agent': 'Model: MAG250; Link: WiFi', 'Referrer': self.__referrer,
                              'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'},
                     params={
                         'type': 'stb',
                         'action': 'get_profile',
                         'hd': '1',
                         'auth_second_step': '0',
                         'num_banks': '1',
                         'stb_type': 'MAG250',
                         'image_version': '216',
                         'hw_version': '1.7-BD-00',
                         'not_valid_token': '0',
                         'device_id': G.portal_config.device_id,
                         'device_id2': G.portal_config.device_id_2,
                         'signature': G.portal_config.signature,
                         'sn': G.portal_config.serial_number,
                         'ver': 'ImageDescription:%200.2.18-r23-pub-254;%20ImageDate:%20Wed%20Aug%2029%2010:49:26'
                                '%20EEST%202018;%20PORTAL%20version:%205.1.1;%20API%20Version:%20JS%20API'
                                '%20version:%20328;%20STB%20API%20version:%20134;%20Player%20Engine%20version'
                                ':%200x566'
                     },
                     timeout=get_request_timeout()
                     )
        requests.get(url=self.__url,
                     headers={'Cookie': self.__mac_cookie, 'SN': G.portal_config.serial_number, 'Authorization': 'Bearer ' + self.__token.value,
                              'X-User-Agent': 'Model: MAG250; Link: WiFi', 'Referrer': self.__referrer,
                              'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'},
                     params={
                         'type': 'watchdog', 'action': 'get_events',
                         'init': '0', 'cur_play_type': '1', 'event_active_id': '0'
                     },
                     timeout=get_request_timeout()
                     )

    def __load_cache(self):
        """Load token from disk cache."""
        Logger.debug('Loading token from cache')
        try:
            with xbmcvfs.File(self.__token_path, 'r') as f:
                data = json.loads(f.read())
            self.__token.value = data.get('value') or ''
        except (IOError, TypeError, ValueError):
            Logger.warn('We could not use the cache since it is invalid or non-existent.')

    def __save_cache(self):
        """Store token in disk cache."""
        Logger.debug('Saving token to cache')
        try:
            with xbmcvfs.File(self.__token_path, 'w') as f:
                json.dump({'value': self.__token.value}, f, indent=2)
        except Exception as exc:
            Logger.warn('Could not save token cache: {}'.format(exc))
