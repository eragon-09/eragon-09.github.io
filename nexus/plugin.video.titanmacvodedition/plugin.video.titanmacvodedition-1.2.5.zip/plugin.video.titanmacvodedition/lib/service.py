# -*- coding: utf-8 -*-
"""Background service – EPG refresh + PlayerMonitor with zap window handling."""

from __future__ import absolute_import, division, unicode_literals

from urllib.parse import urlsplit, parse_qsl, urlencode
import xbmc
from xbmc import Monitor, Player, getInfoLabel
from .loggers import Logger
from .utils import get_int_value, get_next_info_and_send_signal
from .api import get_epg_data, epg_caches, get_next_epg_refresh_seconds
from .globals import G
from .xmltv import get_epg_source, get_xmltv_url, load_xmltv

ADDON_ID = 'plugin.video.titanmacvodedition'


def _close_playlist_window():
    """Close MyPlaylist/OSD window and activate fullscreen. Main-thread safe."""
    try:
        closed_any = False
        for win_id in ('10028', '10025'):
            if xbmc.getCondVisibility('Window.IsActive({})'.format(win_id)):
                xbmc.executebuiltin('Action(Back)')
                xbmc.sleep(150)
                closed_any = True
        # Only switch to fullscreen if we actually closed a window and player is running
        if closed_any and xbmc.Player().isPlaying():
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    except Exception as exc:
        Logger.warn('_close_playlist_window failed: {}'.format(exc))


class BackgroundService(Monitor):
    """EPG background refresh service."""

    def _wait_for_portal(self, timeout_s=60, poll_s=5):
        """Wait until both portal_url AND mac_address are configured.
        Returns True when ready, False if timed out or abort requested."""
        elapsed = 0
        while elapsed < timeout_s:
            G.init_globals()
            mac = (G.portal_config.mac_cookie or '').replace('mac=', '').strip()
            if G.portal_config.portal_url and mac:
                return True
            Logger.debug('Service: portal or MAC not set yet, retrying in {}s'.format(poll_s))
            if self.waitForAbort(poll_s):
                return False
            elapsed += poll_s
        Logger.warn('Service: portal/MAC still not set after {}s, skipping initial EPG load'.format(timeout_s))
        return False

    def run(self):
        Logger.debug('Service started')

        # Wait for portal to be configured, then do initial EPG load
        if self._wait_for_portal(timeout_s=60, poll_s=5):
            try:
                get_epg_data()
                Logger.debug('EPG startup refresh finished')
            except Exception as exc:
                Logger.error('EPG startup refresh failed: {}'.format(exc))

            # Load XMLTV if configured
            if get_epg_source() in ('xmltv', 'merge') and get_xmltv_url():
                try:
                    load_xmltv(force=False)
                    Logger.debug('XMLTV EPG startup load finished')
                except Exception as exc:
                    Logger.warn('XMLTV startup load failed: {}'.format(exc))

        while not self.abortRequested():
            # Periodic EPG refresh
            try:
                wait_s = get_next_epg_refresh_seconds(
                    default_seconds=600, min_seconds=120, max_seconds=900)
            except Exception:
                wait_s = 600

            if self.waitForAbort(int(wait_s)):
                break

            # Re-read settings so portal/MAC changes take effect without restart
            G.init_globals()
            mac = (G.portal_config.mac_cookie or '').replace('mac=', '').strip()
            if not G.portal_config.portal_url or not mac:
                Logger.debug('Service: portal or MAC not set, skipping EPG refresh')
                continue
            try:
                get_epg_data()
                Logger.debug('EPG background refresh done')
            except Exception as exc:
                Logger.error('EPG background refresh failed: {}'.format(exc))

        Logger.debug('Service stopped')


class PlayerMonitor(Player):
    """Monitors playback: UpNext signals, stream retry, zap window close."""

    def __init__(self):
        Player.__init__(self)
        self.__path = ''
        self.__listen = False
        self.__av_started = False

    def onPlayBackStarted(self):
        self.__path = getInfoLabel('Player.FilenameAndPath')
        self.__av_started = False
        if self.__path.startswith('plugin://{}/'.format(ADDON_ID)):
            self.__listen = True
            Logger.debug('PlayerMonitor: plugin playback started')
        else:
            self.__listen = False
        # Close playlist/OSD window on every new stream (plugin:// and http://)
        _close_playlist_window()

    def onAVChange(self):
        """Called when Kodi switches stream in playlist (zapping)."""
        Logger.debug('PlayerMonitor: AV changed – closing playlist window')
        _close_playlist_window()

    def onAVStarted(self):
        if not self.__listen:
            return
        Logger.debug('PlayerMonitor: AV started')
        self.__av_started = True
        params = dict(parse_qsl(urlsplit(self.__path).query))
        episode_no = get_int_value(params, 'series')
        total_episodes = get_int_value(params, 'total_episodes')
        if episode_no != 0 and episode_no < total_episodes:
            params['series'] = episode_no + 1
            next_url = '{}?{}'.format(
                'plugin://{}/'.format(ADDON_ID), urlencode(params))
            try:
                get_next_info_and_send_signal(params, next_url)
            except Exception as exc:
                Logger.warn('UpNext signal failed: {}'.format(exc))

    def onPlayBackError(self):
        if not self.__listen:
            return
        self.__av_started = False
        self.__listen = False
        Logger.debug('PlayerMonitor: playback error')

    def onPlayBackEnded(self):
        if not self.__listen:
            return
        Logger.debug('PlayerMonitor: playback ended')
        self.__listen = False
        self.__av_started = False

    def onPlayBackStopped(self):
        if not self.__listen:
            return
        self.__listen = False
        if not self.__av_started:
            params = dict(parse_qsl(urlsplit(self.__path).query))
            if 'cmd' in params and params.get('use_cmd', '0') == '0':
                Logger.debug('PlayerMonitor: no AV on stop – retrying with use_cmd=1')
                xbmc.executebuiltin('Dialog.Close(all, true)')
                xbmc.executebuiltin('PlayMedia({})'.format(self.__path + '&use_cmd=1'))
                return
        self.__av_started = False
        Logger.debug('PlayerMonitor: playback stopped')


def run():
    """Service entry point."""
    G.init_globals()
    monitor = BackgroundService()
    player = PlayerMonitor()  # noqa: F841 – kept alive intentionally
    monitor.run()
