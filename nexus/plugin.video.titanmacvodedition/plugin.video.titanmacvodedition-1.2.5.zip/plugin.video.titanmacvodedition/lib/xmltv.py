# -*- coding: utf-8 -*-
"""
XMLTV EPG provider for Titan Stalker VOD Client.

Fetches an XMLTV feed (URL or local file), parses it, and converts the
data into the same dict format that the portal EPG uses:

    { channel_id: [ {name, t_time, t_time_to, descr, start_timestamp,
                     stop_timestamp, ...}, ... ] }

The channel_id used as key is the portal channel ID.  Matching between
XMLTV channel names / tvg-ids and portal channel IDs is done via a
configurable mapping (JSON string in settings) plus a fuzzy name fallback.

All existing EPG functions (short_epg_from_dict, get_epg_dict, …) are
unchanged – this module only provides an alternative/additional data source.
"""

from __future__ import absolute_import, division, unicode_literals

import os
import re
import gzip
import json
import time
import threading
from datetime import datetime

import requests
import xbmcaddon
import xbmcvfs

from .loggers import Logger

# ---------------------------------------------------------------------------
# Module-level cache
# ---------------------------------------------------------------------------

_xmltv_mem = {}          # parsed XMLTV dict in portal format
_xmltv_loaded_ts = 0
_xmltv_lock = threading.Lock()

_ADDON_ID = 'plugin.video.titanmacvodedition'


# ---------------------------------------------------------------------------
# Settings helpers
# ---------------------------------------------------------------------------

def _addon():
    return xbmcaddon.Addon(_ADDON_ID)


def get_epg_source():
    """Return 'portal', 'xmltv', or 'merge'."""
    try:
        raw = (_addon().getSetting('epg_source') or '0').strip()
        return {'0': 'portal', '1': 'xmltv', '2': 'merge'}.get(raw, 'portal')
    except Exception:
        return 'portal'


def get_xmltv_url():
    try:
        return (_addon().getSetting('xmltv_url') or '').strip()
    except Exception:
        return ''


def get_xmltv_refresh_hours():
    """Return refresh interval in seconds (setting is enum 0-3 = 6/12/24/48h)."""
    try:
        raw = (_addon().getSetting('xmltv_refresh') or '1').strip()
        hours = [6, 12, 24, 48]
        idx = int(raw) if raw.isdigit() else 1
        return hours[idx if 0 <= idx < len(hours) else 1] * 3600
    except Exception:
        return 12 * 3600


def get_tvg_mapping():
    """Return dict {tvg-id-or-name: portal_channel_id} from settings JSON."""
    try:
        raw = (_addon().getSetting('xmltv_mapping') or '').strip()
        if not raw:
            return {}
        return json.loads(raw)
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# File paths
# ---------------------------------------------------------------------------

def _xmltv_cache_path():
    try:
        profile = xbmcvfs.translatePath(
            'special://profile/addon_data/{}/'.format(_ADDON_ID))
        if not xbmcvfs.exists(profile):
            xbmcvfs.mkdirs(profile)
        return os.path.join(profile, 'xmltv_cache.xml.gz')
    except Exception:
        return ''


def _xmltv_dict_path():
    try:
        profile = xbmcvfs.translatePath(
            'special://profile/addon_data/{}/'.format(_ADDON_ID))
        return os.path.join(profile, 'xmltv_epg.json')
    except Exception:
        return ''


# ---------------------------------------------------------------------------
# XMLTV download
# ---------------------------------------------------------------------------

def _fetch_xmltv(url):
    """Download XMLTV from URL (supports http/https and local file://).
    Returns raw bytes or None."""
    if not url:
        return None
    try:
        if url.startswith('file://') or os.path.exists(url):
            path = url.replace('file://', '')
            with open(path, 'rb') as f:
                return f.read()

        from .utils import get_request_timeout
        resp = requests.get(url, timeout=get_request_timeout(60),
                            headers={'User-Agent': 'TitanStalkerVOD/1.0'})
        if resp.status_code == 200:
            return resp.content
        Logger.warn('XMLTV fetch failed, HTTP {}'.format(resp.status_code))
        return None
    except Exception as exc:
        Logger.error('XMLTV fetch error: {}'.format(exc))
        return None


# ---------------------------------------------------------------------------
# XMLTV parser  (stdlib xml.etree – no extra deps)
# ---------------------------------------------------------------------------

def _parse_xmltv_time(s):
    """Parse XMLTV timestamp like '20240407203000 +0200' → Unix timestamp."""
    if not s:
        return None
    try:
        s = s.strip()
        # Split off timezone
        parts = s.split()
        dt_str = parts[0]
        tz_str = parts[1] if len(parts) > 1 else '+0000'

        dt = datetime.strptime(dt_str, '%Y%m%d%H%M%S')
        # Convert timezone offset to seconds
        sign = 1 if tz_str[0] != '-' else -1
        tz_str = tz_str.lstrip('+-')
        tz_h = int(tz_str[:2]) if len(tz_str) >= 2 else 0
        tz_m = int(tz_str[2:4]) if len(tz_str) >= 4 else 0
        tz_offset = sign * (tz_h * 3600 + tz_m * 60)

        # epoch = local dt interpreted as UTC, then subtract tz offset
        import calendar
        epoch = calendar.timegm(dt.timetuple()) - tz_offset
        return int(epoch)
    except Exception:
        return None


def _ts_to_hhmm(ts):
    """Convert Unix timestamp to 'HH:MM' local time string."""
    if ts is None:
        return ''
    try:
        return datetime.fromtimestamp(ts).strftime('%H:%M')
    except Exception:
        return ''


def _parse_xmltv_bytes(data):
    """Parse raw XMLTV bytes → dict {xmltv_channel_id: [events]}.

    Each event: {name, t_time, t_time_to, start_timestamp, stop_timestamp,
                 descr, genre, icon}
    """
    try:
        import xml.etree.ElementTree as ET

        # Decompress if gzip
        if data[:2] == b'\x1f\x8b':
            import io
            with gzip.GzipFile(fileobj=io.BytesIO(data)) as gz:
                data = gz.read()

        root = ET.fromstring(data)
    except Exception as exc:
        Logger.error('XMLTV parse error: {}'.format(exc))
        return {}

    result = {}

    for prog in root.iter('programme'):
        ch_id = prog.get('channel', '')
        start_ts = _parse_xmltv_time(prog.get('start'))
        stop_ts  = _parse_xmltv_time(prog.get('stop'))

        title_el = prog.find('title')
        title = (title_el.text or '').strip() if title_el is not None else ''

        desc_el = prog.find('desc')
        desc = (desc_el.text or '').strip() if desc_el is not None else ''

        cat_el = prog.find('category')
        genre = (cat_el.text or '').strip() if cat_el is not None else ''

        icon_el = prog.find('icon')
        icon = icon_el.get('src', '') if icon_el is not None else ''

        event = {
            'name':            title,
            't_time':          _ts_to_hhmm(start_ts),
            't_time_to':       _ts_to_hhmm(stop_ts),
            'start_timestamp': start_ts,
            'stop_timestamp':  stop_ts,
            'descr':           desc,
            'genre':           genre,
            'icon':            icon,
        }

        result.setdefault(ch_id, []).append(event)

    # Sort each channel's events by start time
    for ch_id in result:
        result[ch_id].sort(key=lambda e: e.get('start_timestamp') or 0)

    Logger.debug('XMLTV parsed: {} channels, {} events total'.format(
        len(result), sum(len(v) for v in result.values())))
    return result


# ---------------------------------------------------------------------------
# Channel matching
# ---------------------------------------------------------------------------

def _normalise(s):
    """Lowercase, strip punctuation/spaces for fuzzy matching."""
    return re.sub(r'[^a-z0-9]', '', (s or '').lower())


def _build_portal_lookup(portal_channels):
    """Build {normalised_name: portal_id} from a list of portal channel dicts."""
    lookup = {}
    for ch in (portal_channels or []):
        name = ch.get('name') or ch.get('title') or ''
        pid  = str(ch.get('id') or ch.get('epg_id') or '')
        if name and pid:
            lookup[_normalise(name)] = pid
    return lookup


def _match_channels(xmltv_dict, portal_channels, user_mapping):
    """Convert xmltv_dict {xmltv_id: events} → {portal_id: events}.

    Matching priority:
    1. user_mapping  {xmltv_id_or_name → portal_id}
    2. exact tvg-id == portal_id
    3. fuzzy name match
    """
    portal_lookup = _build_portal_lookup(portal_channels)
    result = {}

    for xid, events in xmltv_dict.items():
        portal_id = None

        # 1. User mapping (by xmltv channel id)
        if xid in user_mapping:
            portal_id = str(user_mapping[xid])

        # 2. Try xmltv channel id directly as portal id
        if not portal_id and xid in [str(ch.get('id') or '') for ch in (portal_channels or [])]:
            portal_id = xid

        # 3. Fuzzy name match using the first event's channel display name
        if not portal_id:
            norm_xid = _normalise(xid)
            # Try user mapping by normalised name
            for k, v in user_mapping.items():
                if _normalise(k) == norm_xid:
                    portal_id = str(v)
                    break

        if not portal_id:
            norm_xid = _normalise(xid)
            portal_id = portal_lookup.get(norm_xid)

        if portal_id:
            result[portal_id] = events
        # else: no match found – skip silently

    Logger.debug('XMLTV matched {}/{} channels to portal'.format(
        len(result), len(xmltv_dict)))
    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_xmltv(portal_channels=None, force=False):
    """Fetch, parse and cache the XMLTV feed.

    Returns dict in portal EPG format {portal_id: [events]} or {}.
    Uses disk cache to avoid re-downloading on every startup.
    """
    global _xmltv_mem, _xmltv_loaded_ts

    with _xmltv_lock:
        url = get_xmltv_url()
        if not url:
            return {}

        dict_path = _xmltv_dict_path()
        refresh_s  = get_xmltv_refresh_hours()

        # Serve from disk cache if fresh enough
        if not force and dict_path and os.path.exists(dict_path):
            try:
                age = time.time() - os.path.getmtime(dict_path)
                if age <= refresh_s:
                    with open(dict_path, 'r', encoding='utf-8') as f:
                        _xmltv_mem = json.load(f)
                    _xmltv_loaded_ts = int(time.time())
                    Logger.debug('XMLTV loaded from disk cache (age {:.0f}s)'.format(age))
                    return _xmltv_mem
            except Exception:
                pass

        Logger.info('XMLTV: downloading from {}'.format(url))
        raw = _fetch_xmltv(url)
        if not raw:
            # Return stale cache rather than nothing
            if _xmltv_mem:
                return _xmltv_mem
            if dict_path and os.path.exists(dict_path):
                try:
                    with open(dict_path, 'r', encoding='utf-8') as f:
                        _xmltv_mem = json.load(f)
                    return _xmltv_mem
                except Exception:
                    pass
            return {}

        xmltv_dict = _parse_xmltv_bytes(raw)
        user_mapping = get_tvg_mapping()
        matched = _match_channels(xmltv_dict, portal_channels or [], user_mapping)

        # Persist to disk
        if dict_path:
            try:
                tmp = dict_path + '.tmp'
                with open(tmp, 'w', encoding='utf-8') as f:
                    json.dump(matched, f, ensure_ascii=False)
                os.replace(tmp, dict_path)
            except Exception as exc:
                Logger.warn('XMLTV dict save failed: {}'.format(exc))

        _xmltv_mem = matched
        _xmltv_loaded_ts = int(time.time())
        return matched


def get_xmltv_dict():
    """Return cached XMLTV dict or load from disk (respecting refresh interval)."""
    global _xmltv_mem
    with _xmltv_lock:
        if _xmltv_mem:
            return _xmltv_mem
        dict_path = _xmltv_dict_path()
        if dict_path and os.path.exists(dict_path):
            try:
                age = time.time() - os.path.getmtime(dict_path)
                refresh_s = get_xmltv_refresh_hours()
                if age <= refresh_s:
                    # Disk cache is fresh – load it without re-downloading
                    with open(dict_path, 'r', encoding='utf-8') as f:
                        _xmltv_mem = json.load(f)
                    Logger.debug('XMLTV dict loaded from disk cache (age {:.0f}s)'.format(age))
                    return _xmltv_mem
            except Exception:
                pass
        return {}


def clear_xmltv_cache():
    """Remove XMLTV in-memory and disk cache."""
    global _xmltv_mem, _xmltv_loaded_ts
    with _xmltv_lock:
        _xmltv_mem = {}
        _xmltv_loaded_ts = 0
        for p in (_xmltv_cache_path(), _xmltv_dict_path()):
            try:
                if p and os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass


def merge_epg_dicts(portal_dict, xmltv_dict):
    """Merge portal and XMLTV EPG dicts.

    Portal data takes priority. XMLTV fills in channels missing from portal.
    """
    merged = dict(portal_dict or {})
    for ch_id, events in (xmltv_dict or {}).items():
        key_str = str(ch_id)
        if key_str not in merged and ch_id not in merged:
            merged[key_str] = events
    return merged
