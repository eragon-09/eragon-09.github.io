"""
Compatible with Kodi 19.x "Matrix" and above
"""
from __future__ import absolute_import, division, unicode_literals
import re
import math
from urllib.parse import parse_qsl
import xbmc
import xbmcgui
import xbmcplugin
try:
    import xbmcaddon
except Exception:
    xbmcaddon = None
from .globals import G
from .utils import ask_for_input, get_int_value, ask_for_category_selection
from .country_filter import get_country_tokens, filter_categories_for_country_groups
from .api import Api
from .loggers import Logger
from .api import get_epg_data, epg_caches, epg_path, get_epg_dict, short_epg_from_dict, clear_epg_cache
from .xmltv import load_xmltv, clear_xmltv_cache, get_epg_source
import hashlib
import json
import threading
import time
import os


def _strip_kodi_markup(s):
    """Remove common Kodi markup tags so list labels don't show raw closing tags."""
    try:
        if s is None:
            return ''
        s = str(s)
        # remove bold tags
        s = s.replace('[B]', '').replace('[/B]', '')
        # remove color tags
        s = re.sub(r'\[COLOR=[^\]]*\]', '', s, flags=re.IGNORECASE)
        s = re.sub(r'\[/COLOR\]', '', s, flags=re.IGNORECASE)
        return s.strip()
    except Exception:
        return str(s or '').strip()


# ---------------------------------------------------------------------------
# Zapping context helpers
# ---------------------------------------------------------------------------

def _zap_context_path(ctx_key):
    base = getattr(G.addon_config, 'token_path', '') or ''
    if not base:
        return ''
    return os.path.join(base, 'zap_{}.json'.format(ctx_key))


def _save_zap_context(ctx_key, payload):
    try:
        path = _zap_context_path(ctx_key)
        if not path:
            return False
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(payload or {}, fh, ensure_ascii=False)
        return True
    except Exception as exc:
        Logger.error('save zap context failed: {}'.format(exc))
        return False


def _load_zap_context(ctx_key):
    try:
        path = _zap_context_path(ctx_key)
        if not path or not os.path.exists(path):
            return None
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else None
    except Exception as exc:
        Logger.error('load zap context failed: {}'.format(exc))
        return None


def _build_zap_key(params):
    raw = '|'.join([
        str(params.get('category_id', '')),
        str(params.get('category', '')),
        str(params.get('page', '1')),
        str(params.get('search_term', '')),
        str(params.get('fav', '0')),
    ])
    return hashlib.md5(raw.encode('utf-8')).hexdigest()


def _channel_payload(video, epg_text=''):
    return {
        'name': video.get('name', ''),
        'cmd': video.get('cmd', ''),
        'logo': video.get('logo', ''),
        'id': video.get('id', ''),
        'epg_id': video.get('id', ''),
        'use_http_tmp_link': video.get('use_http_tmp_link', 0),
        'use_load_balancing': video.get('use_load_balancing', 0),
        'epg_text': epg_text or '',
    }


def _remaining_minutes_from_range(start_s, end_s):
    try:
        from datetime import datetime, timedelta
        now = datetime.now()
        sh, sm = [int(x) for x in str(start_s).split(':', 1)]
        eh, em = [int(x) for x in str(end_s).split(':', 1)]
        start_dt = now.replace(hour=sh, minute=sm, second=0, microsecond=0)
        end_dt = now.replace(hour=eh, minute=em, second=0, microsecond=0)
        if end_dt <= start_dt:
            end_dt += timedelta(days=1)
        if now < start_dt:
            remaining = int((end_dt - start_dt).total_seconds() // 60)
        else:
            remaining = int((end_dt - now).total_seconds() // 60)
        return max(0, remaining)
    except Exception:
        return None


def _build_zap_label_with_now(channel_name, now_line, max_len=150):
    try:
        base = str(channel_name or '').strip()
        clean = _strip_kodi_markup(now_line)
        if not clean:
            return base
        import re as _re
        m = _re.match(r'^(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*:\s*(.+)$', clean)
        if not m:
            core = '{} [COLOR=gray]•[/COLOR] {}'.format(base, clean)
            if len(core) > max_len - 1:
                core = _strip_kodi_markup(core)[:max_len - 1] + '…'
            return core
        start_s, end_s, title = m.groups()
        remaining = _remaining_minutes_from_range(start_s, end_s)
        body = '{} [COLOR=gray]•[/COLOR] [COLOR=white]{} - {}[/COLOR] [COLOR=gray]•[/COLOR] {}'.format(
            base, start_s, end_s, title.strip())
        if len(body) > max_len - 1:
            body = _strip_kodi_markup(body)[:max_len - 1] + '…'
        if remaining is not None:
            body += '  [COLOR=gold]{} min[/COLOR]'.format(remaining)
        return body
    except Exception:
        return str(channel_name or '')


def _epg_event_details(epgid, line=None):
    """Return dict for current and following EPG events from the cached portal EPG."""
    try:
        epg_dict = get_epg_dict() or {}
        items = epg_dict.get(str(epgid)) or epg_dict.get(int(epgid))
    except Exception:
        items = None
    if not items:
        return {'current': None, 'next': []}

    now_ts = int(time.time())

    def _to_int(v):
        try:
            return int(v)
        except Exception:
            return None

    def _parse_hhmm(s):
        s = str(s or '').strip()
        if ':' not in s:
            return None
        try:
            hh, mm = s.split(':', 1)
            return int(hh), int(mm)
        except Exception:
            return None

    def _event_bounds(ev):
        st = (_to_int(ev.get('start_timestamp')) or _to_int(ev.get('start')) or
              _to_int(ev.get('time')) or _to_int(ev.get('begin_timestamp')))
        en = (_to_int(ev.get('stop_timestamp')) or _to_int(ev.get('end_timestamp')) or
              _to_int(ev.get('end')) or _to_int(ev.get('time_to')) or
              _to_int(ev.get('end_time')) or _to_int(ev.get('finish_timestamp')))
        if st is None and ev.get('t_time'):
            parsed = _parse_hhmm(ev.get('t_time'))
            if parsed:
                hh, mm = parsed
                now = time.localtime(now_ts)
                st = int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, hh, mm, 0, 0, 0, -1)))
        if en is None and ev.get('t_time_to'):
            parsed = _parse_hhmm(ev.get('t_time_to'))
            if parsed:
                hh, mm = parsed
                now = time.localtime(now_ts)
                en = int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, hh, mm, 0, 0, 0, -1)))
                if st and en <= st:
                    en += 86400
        return st, en

    def _desc(ev):
        for key in ('descr', 'description', 'plot', 'text', 'info'):
            val = ev.get(key)
            if val:
                return str(val).strip()
        return ''

    norm = []
    for ev in items:
        if not isinstance(ev, dict):
            continue
        st, en = _event_bounds(ev)
        norm.append((st, en, ev))
    norm.sort(key=lambda x: (x[0] if x[0] is not None else 10 ** 18))

    current = None
    for st, en, ev in norm:
        if st is None:
            continue
        if en is not None and st <= now_ts < en:
            current = (st, en, ev)
            break

    if current is None and line:
        wanted = _strip_kodi_markup(line)
        for st, en, ev in norm:
            built = '{} - {}: {}'.format(ev.get('t_time') or '', ev.get('t_time_to') or '', ev.get('name') or '')
            if _strip_kodi_markup(built) == wanted:
                current = (st, en, ev)
                break

    if current is None and norm:
        current = norm[0]

    next_items = []
    seen = False
    for st, en, ev in norm:
        if current and (st, en, ev) == current:
            seen = True
            continue
        if not seen:
            continue
        next_items.append((st, en, ev))
        if len(next_items) >= 2:
            break

    def _pack(tup):
        if not tup:
            return None
        st, en, ev = tup
        return {
            'start': str(ev.get('t_time') or ''),
            'end': str(ev.get('t_time_to') or ''),
            'title': str(ev.get('name') or '').strip(),
            'desc': _desc(ev),
            'st_ts': st,
            'en_ts': en,
        }

    return {
        'current': _pack(current),
        'next': [_pack(x) for x in next_items if _pack(x)],
    }


def _highlight_epg_plot(epg_text, epgid=None):
    """Build the info-box plot: JETZT / time | noch X min / title / desc / DANACH."""
    try:
        if not epg_text or 'Keine Informationen' in str(epg_text):
            return str(epg_text or '')
        lines = [l.strip() for l in str(epg_text).split('\n') if l.strip()]
        if not lines:
            return str(epg_text)

        details = _epg_event_details(epgid, lines[0]) if epgid else {'current': None, 'next': []}
        current  = details.get('current') if isinstance(details, dict) else None
        upcoming = details.get('next')    if isinstance(details, dict) else []

        if not current:
            return '[B][COLOR=yellow]JETZT[/COLOR][/B]\n{}'.format('\n'.join(lines))

        rem = None
        if current.get('start') and current.get('end'):
            rem = _remaining_minutes_from_range(current['start'], current['end'])

        start = current.get('start', '')
        end   = current.get('end', '')
        time_str = '{} - {}'.format(start, end).strip(' -') if (start or end) else ''
        if rem is not None and rem >= 0:
            header = '{} | noch {} min'.format(time_str, rem) if time_str else 'noch {} min'.format(rem)
        else:
            header = time_str

        title = current.get('title', '').strip()
        desc  = current.get('desc', '').strip()

        parts = ['[B][COLOR=yellow]JETZT[/COLOR][/B]']
        if header:
            parts.append('[B]{}[/B]'.format(header))
        if title:
            parts.append(title)
        if desc:
            parts.append('')
            parts.append(desc)

        if upcoming:
            parts.append('')
            parts.append('[B][COLOR=cyan]DANACH[/COLOR][/B]')
            for ev in upcoming[:2]:
                ev_start = ev.get('start', '')
                ev_end   = ev.get('end', '')
                ev_title = ev.get('title', '').strip()
                rng = '{} - {}'.format(ev_start, ev_end).strip(' -') if (ev_start or ev_end) else ''
                if rng and ev_title:
                    parts.append('{} | {}'.format(rng, ev_title))
                elif ev_title:
                    parts.append(ev_title)
                elif rng:
                    parts.append(rng)

        return '\n'.join(parts)
    except Exception:
        return str(epg_text or '')



def _extract_now_next(epg_text):
    """Return (now_line, next_line) from the 1-3 line EPG text."""
    try:
        if not epg_text or 'Keine Informationen' in str(epg_text):
            return '', ''
        lines = [l.strip() for l in str(epg_text).split('\n') if l.strip()]
        if not lines:
            return '', ''
        now_line = lines[0]
        next_line = lines[1] if len(lines) > 1 else ''
        return now_line, next_line
    except Exception:
        return '', ''


def _build_now_in_label(channel_name, now_line, max_len=90):
    """Put NOW into the main label (usually rendered larger by skin)."""
    try:
        if not now_line:
            return channel_name
        # Keep it readable; many skins truncate label anyway.
        now_clean = _strip_kodi_markup(now_line)
        combined = f"{channel_name}  [COLOR=yellow]• Jetzt:[/COLOR] {now_clean}"
        if len(combined) > max_len:
            return combined[:max_len - 1] + "…"
        return combined
    except Exception:
        return channel_name


def _build_next_label2(next_line, max_len=90):
    """Put NEXT into label2 (usually smaller)."""
    try:
        if not next_line:
            return ''
        next_clean = _strip_kodi_markup(next_line)
        combined = f"[COLOR=cyan]Danach:[/COLOR] {next_clean}"
        if len(combined) > max_len:
            return combined[:max_len - 1] + "…"
        return combined
    except Exception:
        return ''




def _get_favoriten_icon():
    try:
        addon_path = xbmcaddon.Addon().getAddonInfo('path') if xbmcaddon else ''
    except Exception:
        addon_path = ''
    return os.path.join(addon_path, 'resources', 'media', 'favoriten.png')

def _LSTR(id):
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getLocalizedString(id)
    except Exception:
        return ''


class StalkerAddon:
    @staticmethod
    def __is_adult_category(title):
        try:
            t = (title or '').lower()
        except Exception:
            t = ''
        adult_tokens = [
            'adult', 'xxx', 'xxl', '18+', '18 +',
            'erotik', 'erotic', 'porno', 'porn', 'hardcore'
        ]
        return any(tok in t for tok in adult_tokens)

    @staticmethod
    def __require_pin():
        # Returns True if access is allowed (parental control off or correct PIN)
        try:
            if not xbmcaddon:
                return True
            _addon = xbmcaddon.Addon()
            try:
                pc_enabled = _addon.getSettingBool('parental_control_enabled')
            except Exception:
                pc_enabled = _addon.getSetting('parental_control_enabled') in ('true', 'True', '1')
            if not pc_enabled:
                return True
            try:
                stored_pin = _addon.getSettingString('pin')
            except Exception:
                stored_pin = _addon.getSetting('pin')
            stored_pin = (stored_pin or '').strip()
            if not stored_pin:
                xbmcgui.Dialog().ok(
                    _addon.getLocalizedString(32013) or 'Adult section',
                    _addon.getLocalizedString(32014) or 'Enter pin code'
                )
                return False
            entered = xbmcgui.Dialog().numeric(
                0,
                _addon.getLocalizedString(32014) or 'Enter pin code'
            )
            if (entered or '').strip() == stored_pin:
                return True
            xbmcgui.Dialog().notification(
                'PIN',
                _addon.getLocalizedString(32021) or 'Wrong PIN',
                xbmcgui.NOTIFICATION_ERROR,
                3000
            )
            return False
        except Exception as e:
            Logger.error('PIN check failed: {}'.format(e))
            return False

    """Stalker Addon"""
    @staticmethod
    def __toggle_favorites(video_id, add, _type):
        """Remove/add favorites and refresh"""
        Logger.debug('Toggle Favorites video_id={}, add={}, _type={}'.format(video_id, add, _type))
        if add:
            Api.add_favorites(video_id, _type)
        else:
            Api.remove_favorites(video_id, _type)
        xbmc.executebuiltin('Container.Refresh')

    @staticmethod
    def __play_video(params):
        """Play video"""
        Logger.debug('Play video {}'.format(params))
        stream_url = Api.get_vod_stream_url(params['video_id'], params['series'], params.get('cmd', ''), params.get('use_cmd', '0'))
        play_item = xbmcgui.ListItem(path=stream_url)
        video_info = play_item.getVideoInfoTag()
        title = params.get('title', '')
        video_info.setTitle(title)
        video_info.setOriginalTitle(title)
        video_info.setMediaType('movie')
        episode_no = get_int_value(params, 'series')
        if episode_no > 0:
            video_info.setEpisode(episode_no)
            video_info.setSeason(get_int_value(params, 'season_no'))
            video_info.setMediaType('episode')
            video_info.setTvShowTitle(title)
        xbmcplugin.setResolvedUrl(G.get_handle(), True, listitem=play_item)

    @staticmethod
    def __play_tv(params):
        """Play TV Channel with background zap playlist for Next/Prev."""
        Logger.debug('Play TV {}'.format(params))

        # Step 1: resolve and play the selected channel immediately
        stream_url = Api.get_tv_stream_url(params)
        if not stream_url:
            Logger.error('Could not resolve stream for {}'.format(params.get('name', '')))
            xbmcplugin.setResolvedUrl(G.get_handle(), False, xbmcgui.ListItem())
            return

        item = xbmcgui.ListItem(path=stream_url)
        item.setProperty('IsPlayable', 'true')
        try:
            info = item.getVideoInfoTag()
            title = params.get('name', '')
            info.setTitle(title)
            info.setOriginalTitle(title)
            info.setDuration(0)
            if params.get('epg_text'):
                info.setPlot(_highlight_epg_plot(params.get('epg_text'), params.get('epg_id')))
        except Exception:
            pass
        if params.get('logo'):
            item.setArt({'icon': params['logo'], 'thumb': params['logo'], 'clearlogo': params['logo']})

        # Step 2: build full zap playlist in background thread
        ctx_key = params.get('ctx', '')
        idx = get_int_value(params, 'idx')
        ctx = _load_zap_context(ctx_key) if ctx_key else None
        channels = ctx.get('channels') if isinstance(ctx, dict) else None

        if channels:
            def _build_zap():
                try:
                    player = xbmc.Player()
                    # Wait up to 4s for playback to start, then abort if Kodi is shutting down
                    for _ in range(40):
                        if player.isPlaying():
                            break
                        if xbmc.Monitor().abortRequested():
                            return
                        xbmc.sleep(100)

                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    playlist.clear()
                    pos = 0
                    resolved_idx = 0
                    for i, ch in enumerate(channels):
                        if xbmc.Monitor().abortRequested():
                            return
                        # Use plugin:// URL so Kodi resolves the stream on demand (no pre-fetching).
                        # Pre-resolving all URLs caused the thread to run for minutes with large channel lists.
                        plugin_url = G.get_plugin_url({
                            'action': 'tv_play',
                            'idx': str(i),
                            'cmd': ch.get('cmd', ''),
                            'use_http_tmp_link': ch.get('use_http_tmp_link', 0),
                            'use_load_balancing': ch.get('use_load_balancing', 0),
                            'name': ch.get('name', ''),
                            'logo': ch.get('logo', ''),
                            'epg_text': ch.get('epg_text', ''),
                            'epg_id': str(ch.get('epg_id', '')),
                            'ctx': ctx_key,
                        })
                        now_line, _ = _extract_now_next(ch.get('epg_text', ''))
                        zap_label = _build_zap_label_with_now(ch.get('name', ''), now_line)
                        li = xbmcgui.ListItem(label=zap_label, path=plugin_url)
                        li.setProperty('IsPlayable', 'true')
                        # StopDownloading prevents Kodi from doing remote Stat() calls on logos,
                        # which can block for up to 30s per image if the logo server is unreachable.
                        li.setProperty('StopDownloading', 'true')
                        try:
                            info2 = li.getVideoInfoTag()
                            info2.setTitle(zap_label)
                            info2.setOriginalTitle(ch.get('name', ''))
                            info2.setDuration(0)
                            if ch.get('epg_text'):
                                info2.setPlot(_highlight_epg_plot(ch.get('epg_text'), ch.get('epg_id')))
                        except Exception:
                            pass
                        if ch.get('logo'):
                            # Only set icon – skip thumb/clearlogo to avoid extra Stat() calls per item
                            li.setArt({'icon': ch['logo']})
                        playlist.add(plugin_url, li)
                        if i == idx:
                            resolved_idx = pos
                        pos += 1
                    # Do NOT call Dialog.Close or ActivateWindow here –
                    # the PlayerMonitor.onAVChange in service.py handles window management
                    # and calling it from this thread causes video flicker.
                except Exception as exc:
                    Logger.warn('Background zap playlist build failed: {}'.format(exc))

            t = threading.Thread(target=_build_zap, daemon=True, name='zap-playlist')
            t.start()

        xbmcplugin.setResolvedUrl(G.get_handle(), True, listitem=item)

    @staticmethod
    def __list_tv_genres():
        """List the TV channel genres"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return

        # EPG cache is handled by lib/api.py (TTL + refresh). We only ensure a cache file exists.
        try:
            if not epg_path or not os.path.exists(epg_path):
                get_epg_data()
        except Exception:
            pass



        Logger.debug('List TV Genres')
        xbmcplugin.setPluginCategory(G.get_handle(), 'TiTan TV')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        # Inserted: Live TV - My Favorites (country groups) at top of TV CHANNELS menu
        list_item = xbmcgui.ListItem(label=_LSTR(32104) or 'Live TV - My Favorites')
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'tv_country_favorites'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='TV FAVORITES')
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'tv_favorites', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option
        list_item = xbmcgui.ListItem(label='TV SEARCH')
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png')})
        url = G.get_plugin_url({'action': 'tv_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        try:
            genres = Api.get_tv_genres()
            for genre in genres:
                list_item = xbmcgui.ListItem(label=genre['title'].upper())
                fav_url = G.get_plugin_url({'action': 'tv_listing', 'category': genre['title'], 'category_id': genre['id'], 'page': 1,
                                            'update_listing': False, 'search_term': '', 'fav': 1})
                search_url = G.get_plugin_url({'action': 'tv_search', 'category': genre['title'], 'category_id': genre['id'], 'fav': 0})
                list_item.addContextMenuItems(
                    [('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
                url = G.get_plugin_url({'action': 'tv_listing', 'category': genre['title'].upper(), 'category_id': genre['id'], 'page': 1,
                                        'update_listing': False})
                xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        except Exception as exc:
            Logger.error('__list_tv_genres failed: {}'.format(exc))
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    
    def __list_tv_country_favorites(self):
        """List country group genres (DE/AT/CH) under TV Channels -> Live TV - My Favorites"""
        Logger.debug('List TV Country Favorites (DE/AT/CH)')
        xbmcplugin.setPluginCategory(G.get_handle(), _LSTR(32104) or 'Live TV - My Favorites')
        xbmcplugin.setContent(G.get_handle(), 'videos')

        try:
            genres = Api.get_tv_genres()
        except Exception as e:
            Logger.error('Failed to get TV genres: {}'.format(e))
            genres = []

        tokens = get_country_tokens()
        try:
            if xbmcaddon:
                addon = xbmcaddon.Addon()
                try:
                    extra = addon.getSettingString('extra_country_tokens')
                except Exception:
                    extra = addon.getSetting('extra_country_tokens')
                extra_tokens = {t.strip().upper() for t in (extra or '').split(',') if t.strip()}
                tokens |= extra_tokens
        except Exception as e:
            Logger.debug('No extra_country_tokens setting or failed to read it: {}'.format(e))

        filtered = filter_categories_for_country_groups(genres, tokens=tokens)
        Logger.debug('Country favorites candidates found: {}'.format([g.get('title') for g in filtered]))

        for genre in filtered:
            try:
                title = (genre.get('title') or genre.get('name') or genre.get('alias') or genre.get('abbr') or '').strip()
                disp = (title or '').upper()
                list_item = xbmcgui.ListItem(label=disp)
                fav_url = G.get_plugin_url({'action': 'tv_listing', 'category': title, 'category_id': genre['id'], 'page': 1,
                                            'update_listing': False, 'search_term': '', 'fav': 1})
                search_url = G.get_plugin_url({'action': 'tv_search', 'category': title, 'category_id': genre['id'], 'fav': 0})
                list_item.addContextMenuItems([('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
                url = G.get_plugin_url({'action': 'tv_listing', 'category': title, 'category_id': genre['id'], 'page': 1,
                                        'update_listing': False})
                xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
            except Exception as ie:
                Logger.error('Error building list item for genre: {}'.format(ie))

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=True, cacheToDisc=False)

    @staticmethod
    def __list_vod_country_favorites():
        """List VOD categories that match country group tokens (DE/AT/CH)"""
        Logger.debug('List VOD Country Favorites (DE/AT/CH)')
        xbmcplugin.setPluginCategory(G.get_handle(), _LSTR(32105) or 'VOD - My Favorites')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        # Gruppensuche innerhalb der Ländergruppen-Favoriten
        list_item = xbmcgui.ListItem(label='[COLOR FF32CD32]Gruppensuche[/COLOR]')
        url = G.get_plugin_url({'action': 'vod_fav_group_search'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)


        try:
            categories = Api.get_vod_categories()
        except Exception as e:
            Logger.error('Failed to get VOD categories: {}'.format(e))
            categories = []

        tokens = get_country_tokens()
        try:
            if xbmcaddon:
                addon = xbmcaddon.Addon()
                try:
                    extra = addon.getSettingString('extra_country_tokens')
                except Exception:
                    extra = addon.getSetting('extra_country_tokens')
                extra_tokens = {t.strip().upper() for t in (extra or '').split(',') if t.strip()}
                tokens |= extra_tokens
        except Exception as e:
            Logger.debug('No extra_country_tokens setting or failed to read it: {}'.format(e))

        filtered = filter_categories_for_country_groups(categories, tokens=tokens)

        for category in filtered:
            try:
                title = (category.get('title') or category.get('name') or category.get('alias') or category.get('abbr') or '').strip()
                disp = (title or '').upper()
                list_item = xbmcgui.ListItem(label=disp)
                fav_url = G.get_plugin_url({'action': 'vod_listing', 'category': title, 'category_id': category['id'], 'page': 1,
                                            'update_listing': False, 'search_term': '', 'fav': 1})
                search_url = G.get_plugin_url({'action': 'vod_search', 'category': title, 'category_id': category['id'], 'fav': 0})
                list_item.addContextMenuItems([('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
                url = G.get_plugin_url({'action': 'vod_listing', 'category': title, 'category_id': category['id'], 'page': 1,
                                        'update_listing': False, 'search_term': '', 'fav': 0})
                xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
            except Exception as ie:
                Logger.error('Error building list item for category: {}'.format(ie))

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=True, cacheToDisc=False)

    @staticmethod
    def __list_series_country_favorites():
        """List SERIES categories that match country group tokens (DE/AT/CH)"""
        Logger.debug('List SERIES Country Favorites (DE/AT/CH)')
        xbmcplugin.setPluginCategory(G.get_handle(), _LSTR(32106) or 'Serien - My Favorites')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        # Gruppensuche innerhalb der Ländergruppen-Favoriten
        list_item = xbmcgui.ListItem(label='[COLOR FF32CD32]Gruppensuche[/COLOR]')
        url = G.get_plugin_url({'action': 'series_fav_group_search'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)


        try:
            categories = Api.get_series_categories()
        except Exception as e:
            Logger.error('Failed to get Series categories: {}'.format(e))
            categories = []

        tokens = get_country_tokens()
        try:
            if xbmcaddon:
                addon = xbmcaddon.Addon()
                try:
                    extra = addon.getSettingString('extra_country_tokens')
                except Exception:
                    extra = addon.getSetting('extra_country_tokens')
                extra_tokens = {t.strip().upper() for t in (extra or '').split(',') if t.strip()}
                tokens |= extra_tokens
        except Exception as e:
            Logger.debug('No extra_country_tokens setting or failed to read it: {}'.format(e))

        filtered = filter_categories_for_country_groups(categories, tokens=tokens)

        for category in filtered:
            try:
                title = (category.get('title') or category.get('name') or category.get('alias') or category.get('abbr') or '').strip()
                disp = (title or '').upper()
                list_item = xbmcgui.ListItem(label=disp)
                fav_url = G.get_plugin_url({'action': 'series_listing', 'category': title, 'category_id': category['id'], 'page': 1,
                                            'update_listing': False, 'search_term': '', 'fav': 1})
                search_url = G.get_plugin_url({'action': 'series_search', 'category': title, 'category_id': category['id'], 'fav': 0})
                list_item.addContextMenuItems([('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
                url = G.get_plugin_url({'action': 'series_listing', 'category': title, 'category_id': category['id'], 'page': 1,
                                        'update_listing': False, 'search_term': '', 'fav': 0})
                xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
            except Exception as ie:
                Logger.error('Error building list item for category: {}'.format(ie))

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=True, cacheToDisc=False)

    @staticmethod
    def __list_vod_categories():
        """List vod categories"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        Logger.debug('List VOD Categories')
        xbmcplugin.setPluginCategory(G.get_handle(), 'TiTan VOD')
        xbmcplugin.setContent(G.get_handle(), 'videos')

        # VOD - My Favorites (Ländergruppen DE/AT/CH)
        list_item = xbmcgui.ListItem(label=_LSTR(32105) or 'VOD - My Favorites')
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'vod_country_favorites'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='VOD FAVORITES')
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'vod_favorites', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option
        list_item = xbmcgui.ListItem(label='VOD SEARCH')
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png')})
        url = G.get_plugin_url({'action': 'vod_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        categories = Api.get_vod_categories()
        for category in categories:
            list_item = xbmcgui.ListItem(label=category['title'])
            fav_url = G.get_plugin_url({'action': 'vod_listing', 'category': category['title'], 'category_id': category['id'], 'page': 1,
                                        'update_listing': False, 'search_term': '', 'fav': 1})
            search_url = G.get_plugin_url({'action': 'vod_search', 'category': category['title'], 'category_id': category['id'], 'fav': 0})
            list_item.addContextMenuItems([('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
            url = G.get_plugin_url({'action': 'vod_listing', 'category': category['title'], 'category_id': category['id'], 'page': 1,
                                    'update_listing': False, 'search_term': '', 'fav': 0})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_series_categories():
        """List series categories"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        Logger.debug('List Series Categories')
        xbmcplugin.setPluginCategory(G.get_handle(), 'TiTan Serien')
        xbmcplugin.setContent(G.get_handle(), 'videos')

        # Serien - My Favorites (Ländergruppen DE/AT/CH)
        list_item = xbmcgui.ListItem(label=_LSTR(32106) or 'Serien - My Favorites')
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'series_country_favorites'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='SERIES FAVORITES')
        list_item.setArt({'icon': _get_favoriten_icon(), 'thumb': _get_favoriten_icon(), 'poster': _get_favoriten_icon()})
        url = G.get_plugin_url({'action': 'series_favorites', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option
        list_item = xbmcgui.ListItem(label='SERIES SEARCH')
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png')})
        url = G.get_plugin_url({'action': 'series_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        categories = Api.get_series_categories()
        for category in categories:
            list_item = xbmcgui.ListItem(label=category['title'])
            fav_url = G.get_plugin_url({'action': 'series_listing', 'category': category['title'], 'category_id': category['id'], 'page': 1,
                                        'update_listing': False, 'search_term': '', 'fav': 1})
            search_url = G.get_plugin_url({'action': 'series_search', 'category': category['title'], 'category_id': category['id'], 'fav': 0})
            list_item.addContextMenuItems([('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
            url = G.get_plugin_url({'action': 'series_listing', 'category': category['title'], 'category_id': category['id'], 'page': 1,
                                    'update_listing': False, 'search_term': '', 'fav': 0})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_channels(params):
        """List the TV Channels"""
        Logger.debug('List Channels {}'.format(params))
        search_term = params.get('search_term', '')
        page = params['page']
        plugin_category = 'TV - ' + params['category'] if params.get('fav', '0') != '1' else 'TV - ' + params['category'] + ' - FAVORITES'
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        # 'files' prevents Kodi from treating the channel list as an auto-advancing playlist
        xbmcplugin.setContent(G.get_handle(), 'files')
        videos = Api.get_tv_channels(params['category_id'], page, search_term, params.get('fav', 0))
        StalkerAddon.__create_tv_listing(videos, params)

    @staticmethod
    def __create_tv_listing(videos, params):
        update_listing = params['update_listing']
        epg_dict = get_epg_dict()
        channels = []
        directory_items = []
        ctx_key = _build_zap_key(params)

        for idx, video in enumerate(videos['data']):
            label = video['name']
            epgid = video['id']

            # epg_caches stores a tuple (raw_text, plot_text, now_line, next_line)
            # to avoid re-computing the expensive _highlight_epg_plot per channel per call
            if epgid not in epg_caches:
                raw = short_epg_from_dict(epgid, epg_dict)
                now_line, next_line = _extract_now_next(raw)
                plot = _highlight_epg_plot(raw, epgid)
                epg_caches[epgid] = (raw, plot, now_line, next_line)
            cached = epg_caches[epgid]
            if isinstance(cached, tuple):
                epg_text, plot_text, now_line, next_line = cached
            else:
                # Legacy: plain string from old cache
                epg_text = cached
                now_line, next_line = _extract_now_next(epg_text)
                plot_text = _highlight_epg_plot(epg_text, epgid)

            channels.append(_channel_payload(video, epg_text))

            if video.get('fav', 0) == 1:
                label = label + ' ★'
            label_main = _build_now_in_label(label, now_line)
            label2 = _build_next_label2(next_line)
            list_item = xbmcgui.ListItem(label=label_main, label2=label2 or label)
            video_info = list_item.getVideoInfoTag()
            video_info.setPlot(plot_text)
            video_info.setPlaycount(0)
            list_item.setProperty('IsPlayable', 'true')
            if video.get('fav', 0) == 1:
                url = G.get_plugin_url({'action': 'remove_fav', 'video_id': video['id'], '_type': 'itv'})
                list_item.addContextMenuItems([('Remove from favorites', f'RunPlugin({url}, False)')])
            else:
                url = G.get_plugin_url({'action': 'add_fav', 'video_id': video['id'], '_type': 'itv'})
                list_item.addContextMenuItems([('Add to favorites', f'RunPlugin({url}, False)')])
            if 'logo' in video:
                # Only set icon – thumb and clearlogo trigger extra Stat() calls per item
                # which can block for 30s each if the logo server is unreachable.
                list_item.setArt({'icon': video['logo']})
            url = G.get_plugin_url({
                'action': 'tv_play',
                'idx': str(idx),
                'cmd': video['cmd'],
                'use_http_tmp_link': video.get('use_http_tmp_link', 0),
                'use_load_balancing': video.get('use_load_balancing', 0),
                'name': video['name'],
                'logo': video.get('logo', ''),
                'epg_text': epg_text or '',
                'epg_id': str(epgid),
                'ctx': ctx_key,
            })
            directory_items.append((url, list_item, False))

        # Save zap context for Next/Prev channel switching
        if channels:
            _save_zap_context(ctx_key, {
                'category': params.get('category', ''),
                'channels': channels,
            })

        total_items = get_int_value(videos, 'total_items')
        item_count = len(directory_items)
        if total_items > item_count:
            StalkerAddon.__add_navigation_items(params, videos, directory_items)
            item_count = len(directory_items)
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, item_count)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=update_listing == 'True', cacheToDisc=False)

    @staticmethod
    def __list_vod(params):
        """List videos for a category"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        category_title = params.get('category') if isinstance(params, dict) else None
        if StalkerAddon.__is_adult_category(category_title):
            if not StalkerAddon.__require_pin():
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)
                return
        Logger.debug('List VOD {}'.format(params))
        search_term = params.get('search_term', '')
        plugin_category = 'VOD - ' + params['category'] if params.get('fav', '0') != '1' else 'VOD - ' + params['category'] + ' - FAVORITES'
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        try:
            videos = Api.get_videos(params['category_id'], params['page'], search_term, params.get('fav', 0))
            StalkerAddon.__create_video_listing(videos, params)
        except Exception as exc:
            Logger.error('__list_vod failed: {}'.format(exc))
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)

    @staticmethod
    def __list_vod_favorites(params):
        """List Favorites Channels"""
        Logger.debug('List VOD Favorites {}'.format(params))
        xbmcplugin.setPluginCategory(G.get_handle(), 'VOD FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        videos = Api.get_vod_favorites(params['page'])
        StalkerAddon.__create_video_listing(videos, params)

    @staticmethod
    def __list_series_favorites(params):
        """List Favorites Channels"""
        xbmcplugin.setPluginCategory(G.get_handle(), 'SERIES FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        series = Api.get_series_favorites(params['page'])
        StalkerAddon.__create_series_listing(series, params)

    @staticmethod
    def __list_tv_favorites(params):
        """List Favorites Channels"""
        Logger.debug('List TV favorites {}'.format(params))
        xbmcplugin.setPluginCategory(G.get_handle(), 'TV FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'files')
        videos = Api.get_tv_favorites(params['page'])
        StalkerAddon.__create_tv_listing(videos, params)

    @staticmethod
    def __list_series(params):
        """List series"""
        if not G.portal_config.portal_url:
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'Bitte zuerst Portal-URL in den Einstellungen setzen.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)
            return
        category_title = params.get('category') if isinstance(params, dict) else None
        if StalkerAddon.__is_adult_category(category_title):
            if not StalkerAddon.__require_pin():
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)
                return
        Logger.debug('List Series {}'.format(params))
        search_term = params.get('search_term', '')
        plugin_category = 'SERIES - ' + params['category'] if params.get('fav', '0') != '1' else 'SERIES - ' + params['category'] + ' - FAVORITES'
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        try:
            series = Api.get_series(params['category_id'], params['page'], search_term, params.get('fav', 0))
            StalkerAddon.__create_series_listing(series, params)
        except Exception as exc:
            Logger.error('__list_series failed: {}'.format(exc))
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False)

    @staticmethod
    def __list_season(params):
        """List season"""
        xbmcplugin.setPluginCategory(G.get_handle(), params['name'])
        xbmcplugin.setContent(G.get_handle(), 'videos')
        seasons = Api.get_seasons(params['video_id'])
        directory_items = []
        for season in seasons['data']:
            label = season['name']
            list_item = xbmcgui.ListItem(label=label, label2=label)
            match = re.match("^Season [0-9]+$", season['name'])
            name = params['name'] + ' ' + season['name']
            if match:
                temp = season['name'].split(' ')
                name = params['name'] + ' S' + temp[-1]
            url = G.get_plugin_url({'action': 'sub_folder', 'video_id': season['id'], 'start': season['series'][0],
                                    'end': season['series'][-1], 'name': name, 'poster_url': params['poster_url']})
            video_info = list_item.getVideoInfoTag()
            video_info.setMediaType('season')
            video_info.setTitle(season['name'])
            video_info.setOriginalTitle(season['name'])
            video_info.setSortTitle(season['name'])
            video_info.setPlot(season.get('description', ''))
            video_info.setPlotOutline(season.get('description', ''))
            actors = [xbmc.Actor(actor) for actor in season['actors'].split(',') if actor]  # pylint: disable=maybe-no-member
            video_info.setCast(actors)
            list_item.setArt({'poster': params['poster_url']})
            directory_items.append((url, list_item, True))
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, len(seasons['data']))
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __create_video_listing(videos, params):
        """Create paginated listing"""
        update_listing = params['update_listing']
        item_count = len(videos['data'])
        directory_items = []
        for video in videos['data']:
            label = video['name'] if video.get('hd', 1) == 1 else video['name'] + ' (SD)'
            if video.get('fav', 0) == 1:
                label = label + ' ★'
            list_item = xbmcgui.ListItem(label=label, label2=label)
            if video.get('fav', 0) == 1:
                url = G.get_plugin_url({'action': 'remove_fav', 'video_id': video['id'], '_type': 'vod'})
                list_item.addContextMenuItems([('Remove from favorites', f'RunPlugin({url}, False)')])
            else:
                url = G.get_plugin_url({'action': 'add_fav', 'video_id': video['id'], '_type': 'vod'})
                list_item.addContextMenuItems([('Add to favorites', f'RunPlugin({url}, False)')])

            is_folder = False
            poster_url = None
            if 'screenshot_uri' in video and isinstance(video['screenshot_uri'], str):
                if video['screenshot_uri'].startswith('http'):
                    poster_url = video['screenshot_uri']
                else:
                    poster_url = G.portal_config.portal_base_url + video['screenshot_uri']
            video_info = list_item.getVideoInfoTag()
            if video['series']:
                url = G.get_plugin_url({'action': 'sub_folder', 'video_id': video['id'], 'start': video['series'][0], 'end': video['series'][-1],
                                        'name': video['name'], 'poster_url': poster_url})
                is_folder = True
                video_info.setMediaType('season')
            else:
                url = G.get_plugin_url({'action': 'play', 'video_id': video['id'], 'series': 0, 'title': video['name'], 'cmd': video.get('cmd', '')})
                time = get_int_value(video, 'time')
                if time != 0:
                    video_info.setDuration(time * 60)
                video_info.setMediaType('movie')
                list_item.setProperty('IsPlayable', 'true')

            video_info.setTitle(video['name'])
            video_info.setOriginalTitle(video['name'])
            video_info.setSortTitle(video['name'])
            if 'country' in video:
                video_info.setCountries([video['country']])
            video_info.setDirectors([video['director']])
            video_info.setPlot(video.get('description', ''))
            video_info.setPlotOutline(video.get('description', ''))
            actors = [xbmc.Actor(actor) for actor in video['actors'].split(',') if actor]  # pylint: disable=maybe-no-member
            video_info.setCast(actors)
            video_info.setLastPlayed(video['last_played'])
            video_info.setDateAdded(video['added'])
            year = get_int_value(video, 'year')
            if year != 0:
                video_info.setYear(year)
            list_item.setArt({'poster': poster_url})
            directory_items.append((url, list_item, is_folder))
        # Add navigation items
        total_items = get_int_value(videos, 'total_items')
        if total_items > item_count:
            StalkerAddon.__add_navigation_items(params, videos, directory_items)
            item_count = item_count + 2
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, item_count)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=update_listing == 'True', cacheToDisc=False)

    @staticmethod
    def __create_series_listing(series, params):
        """Create paginated listing"""
        update_listing = params['update_listing']
        item_count = len(series['data'])
        directory_items = []
        for video in series['data']:
            label = video['name'] if video.get('hd', 1) == 1 else video['name'] + ' (SD)'
            if video.get('fav', 0) == 1:
                label = label + ' ★'
            list_item = xbmcgui.ListItem(label=label, label2=label)
            if video.get('fav', 0) == 1:
                url = G.get_plugin_url({'action': 'remove_fav', 'video_id': video['id'], '_type': 'series'})
                list_item.addContextMenuItems([('Remove from favorites', f'RunPlugin({url}, False)')])
            else:
                url = G.get_plugin_url({'action': 'add_fav', 'video_id': video['id'], '_type': 'series'})
                list_item.addContextMenuItems([('Add to favorites', f'RunPlugin({url}, False)')])

            poster_url = None
            if 'screenshot_uri' in video and isinstance(video['screenshot_uri'], str):
                if video['screenshot_uri'].startswith('http'):
                    poster_url = video['screenshot_uri']
                else:
                    poster_url = G.portal_config.portal_base_url + video['screenshot_uri']
            video_info = list_item.getVideoInfoTag()
            url = G.get_plugin_url({'action': 'season_listing', 'video_id': video['id'], 'name': video['name'], 'poster_url': poster_url})
            video_info.setMediaType('season')

            video_info.setTitle(video['name'])
            video_info.setOriginalTitle(video['name'])
            video_info.setSortTitle(video['name'])
            if 'country' in video:
                video_info.setCountries([video['country']])
            video_info.setDirectors([video['director']])
            video_info.setPlot(video.get('description', ''))
            video_info.setPlotOutline(video.get('description', ''))
            actors = [xbmc.Actor(actor) for actor in video['actors'].split(',') if actor]  # pylint: disable=maybe-no-member
            video_info.setCast(actors)
            video_info.setLastPlayed(video['last_played'])
            video_info.setDateAdded(video['added'])
            year = get_int_value(video, 'year')
            if year != 0:
                video_info.setYear(year)
            list_item.setArt({'poster': poster_url})
            directory_items.append((url, list_item, True))
        # Add navigation items
        total_items = get_int_value(series, 'total_items')
        if total_items > item_count:
            StalkerAddon.__add_navigation_items(params, series, directory_items)
            item_count = item_count + 2
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, item_count)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=update_listing == 'True',
                                  cacheToDisc=False)

    @staticmethod
    def __add_navigation_items(params, videos, directory_items):
        """Add navigation list items"""
        page = int(params['page'])
        total_items = get_int_value(videos, 'total_items')
        max_page_items = get_int_value(videos, 'max_page_items')
        total_pages = int(math.ceil(float(total_items) / float(max_page_items)))
        _max_page_limit = G.addon_config.max_page_limit
        if _max_page_limit > 1:
            total_pages = total_pages if (total_pages % _max_page_limit) == 0 else total_pages + _max_page_limit - (
                    total_pages % _max_page_limit)
        label = '<< Last Page' if page == 1 else '<< Previous Page'
        list_item = xbmcgui.ListItem(label)
        list_item.setArt({'thumb': G.get_custom_thumb_path('pagePrevious.png')})
        list_item.setProperty('specialsort', 'top')
        prev_page = total_pages - _max_page_limit + 1 if page == 1 else page - _max_page_limit
        params.update({'page': prev_page, 'update_listing': True})
        url = G.get_plugin_url(params)
        directory_items.insert(0, (url, list_item, True))

        label = 'First Page >>' if page == total_pages - _max_page_limit + 1 else 'Next Page >>'
        list_item = xbmcgui.ListItem(label)
        list_item.setArt({'thumb': G.get_custom_thumb_path('pageNext.png')})
        list_item.setProperty('specialsort', 'bottom')
        next_page = 1 if page == total_pages - _max_page_limit + 1 else page + _max_page_limit
        params.update({'page': next_page, 'update_listing': True})
        url = G.get_plugin_url(params)
        directory_items.append((url, list_item, True))

    @staticmethod
    def __list_episodes(params):
        """List episodes for a series"""
        name = params['name']
        xbmcplugin.setPluginCategory(G.get_handle(), name)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        temp = name.split(' ')
        match = re.match("^S[0-9]+$", temp[-1])
        season = None
        if match:
            season = int(match.string[1:])
            name = ' '.join(temp[:-1])
        start = get_int_value(params, 'start')
        end = get_int_value(params, 'end')
        for episode_no in range(start, end + 1):
            list_item = xbmcgui.ListItem(label='Episode ' + str(episode_no))
            video_info = list_item.getVideoInfoTag()
            video_info.setTitle(name)
            video_info.setOriginalTitle(name)
            if match:
                video_info.setEpisode(episode_no)
                video_info.setSeason(season)
                video_info.setSortSeason(season)
                video_info.setMediaType('episode')
                video_info.setTvShowTitle(name)
            else:
                video_info.setMediaType('movie')
            list_item.setProperties({'IsPlayable': 'true'})
            list_item.setArt({'poster': params['poster_url']})
            url = G.get_plugin_url({'action': 'play', 'video_id': params['video_id'], 'series': episode_no, 'season_no': season,
                                    'title': name, 'total_episodes': end, 'poster_url': params['poster_url']})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    def __search_vod(self, params):
        """Search for videos"""
        Logger.debug('Search VOD {}'.format(params))

        # If the category is missing, show the category selection popup
        if not params.get('category'):
            categories = Api.get_vod_categories()
            selected_category = ask_for_category_selection(categories, 'VOD Category')
            if not selected_category:
                # User cancelled category selection - end directory properly
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
                return
            params.update({
                'category': selected_category['title'],
                'category_id': selected_category['id']
            })

        search_term = ask_for_input(params['category'])
        if search_term:
            params.update({'action': 'vod_listing', 'update_listing': False, 'search_term': search_term, 'page': 1})
            is_context = str(params.get('isContextMenuSearch', 'true')).lower() == 'true'
            if is_context:
                url = G.get_plugin_url(params)
                func_str = f'Container.Update({url})'
                xbmc.executebuiltin(func_str)
            else:
                self.__list_vod(params)

    @staticmethod
    def __search_series(params):
        """Search for videos"""

        # If the category is missing, show the category selection popup
        if not params.get('category'):
            categories = Api.get_series_categories()
            selected_category = ask_for_category_selection(categories, 'Series Category')
            if not selected_category:
                # User cancelled category selection - end directory properly
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
                return
            params.update({
                'category': selected_category['title'],
                'category_id': selected_category['id']
            })

        search_term = ask_for_input(params['category'])
        if search_term:
            params.update({'action': 'series_listing', 'update_listing': False, 'search_term': search_term, 'page': 1})
            url = G.get_plugin_url(params)
            func_str = f'Container.Update({url})'
            xbmc.executebuiltin(func_str)

    
    def __vod_favorites_group_search(self, params):
        """Search across VOD categories filtered by country-group favorites (DE/AT/CH)."""
        Logger.debug('VOD Favorites Group Search {}'.format(params))
        tokens = get_country_tokens()
        try:
            if xbmcaddon:
                addon = xbmcaddon.Addon()
                try:
                    extra = addon.getSettingString('extra_country_tokens')
                except Exception:
                    extra = addon.getSetting('extra_country_tokens')
                extra_tokens = {t.strip().upper() for t in (extra or '').split(',') if t.strip()}
                tokens |= extra_tokens
        except Exception as e:
            Logger.debug('No extra_country_tokens setting or failed to read it: {}'.format(e))

        search_term = ask_for_input(_LSTR(32100) or 'Meine Favoriten')
        if not search_term:
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
            return

        try:
            categories = Api.get_vod_categories()
        except Exception as e:
            Logger.error('Failed to get VOD categories: {}'.format(e))
            categories = []

        fav_categories = filter_categories_for_country_groups(categories, tokens=tokens)

        combined = []
        seen_ids = set()
        for c in fav_categories:
            try:
                videos = Api.get_videos(c['id'], 1, search_term, 0)
                for v in videos.get('data', []):
                    vid = v.get('id') or v.get('video_id') or v.get('vod_id')
                    if vid in seen_ids:
                        continue
                    seen_ids.add(vid)
                    # Prefix with category title so results stay understandable
                    try:
                        ctitle = (c.get('title') or c.get('name') or '').strip()
                        if ctitle:
                            v['name'] = f"[{ctitle}] {v.get('name', '')}"
                    except Exception:
                        pass
                    combined.append(v)
            except Exception as e:
                Logger.error('Group search failed for category {}: {}'.format(c.get('id'), e))

        results = {
            'data': combined,
            'total_items': len(combined),
            'max_page_items': max(1, len(combined)),
            'page': 1
        }

        params = dict(params or {})
        params.update({'category': _LSTR(32100) or 'Meine Favoriten', 'category_id': 0, 'page': 1, 'update_listing': False, 'search_term': search_term, 'fav': 0})
        xbmcplugin.setPluginCategory(G.get_handle(), f"TiTan VOD - {_LSTR(32100) or 'Meine Favoriten'} - {search_term}")
        xbmcplugin.setContent(G.get_handle(), 'videos')
        StalkerAddon.__create_video_listing(results, params)

    def __series_favorites_group_search(self, params):
        """Search across SERIES categories filtered by country-group favorites (DE/AT/CH)."""
        Logger.debug('SERIES Favorites Group Search {}'.format(params))
        tokens = get_country_tokens()
        try:
            if xbmcaddon:
                addon = xbmcaddon.Addon()
                try:
                    extra = addon.getSettingString('extra_country_tokens')
                except Exception:
                    extra = addon.getSetting('extra_country_tokens')
                extra_tokens = {t.strip().upper() for t in (extra or '').split(',') if t.strip()}
                tokens |= extra_tokens
        except Exception as e:
            Logger.debug('No extra_country_tokens setting or failed to read it: {}'.format(e))

        search_term = ask_for_input(_LSTR(32100) or 'Meine Favoriten')
        if not search_term:
            xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
            return

        try:
            categories = Api.get_series_categories()
        except Exception as e:
            Logger.error('Failed to get SERIES categories: {}'.format(e))
            categories = []

        fav_categories = filter_categories_for_country_groups(categories, tokens=tokens)

        combined = []
        seen_ids = set()
        for c in fav_categories:
            try:
                series = Api.get_series(c['id'], 1, search_term, 0)
                for s in series.get('data', []):
                    sid = s.get('id') or s.get('video_id') or s.get('series_id')
                    if sid in seen_ids:
                        continue
                    seen_ids.add(sid)
                    try:
                        ctitle = (c.get('title') or c.get('name') or '').strip()
                        if ctitle:
                            s['name'] = f"[{ctitle}] {s.get('name', '')}"
                    except Exception:
                        pass
                    combined.append(s)
            except Exception as e:
                Logger.error('Group search failed for category {}: {}'.format(c.get('id'), e))

        results = {
            'data': combined,
            'total_items': len(combined),
            'max_page_items': max(1, len(combined)),
            'page': 1
        }

        params = dict(params or {})
        params.update({'category': _LSTR(32100) or 'Meine Favoriten', 'category_id': 0, 'page': 1, 'update_listing': False, 'search_term': search_term, 'fav': 0})
        xbmcplugin.setPluginCategory(G.get_handle(), f"TiTan Serien - {_LSTR(32100) or 'Meine Favoriten'} - {search_term}")
        xbmcplugin.setContent(G.get_handle(), 'videos')
        StalkerAddon.__create_series_listing(results, params)

    def __search_tv(self, params):
        """Search for videos"""

        # If the category is missing, show the category selection popup
        if not params.get('category'):
            genres = Api.get_tv_genres()
            selected_genre = ask_for_category_selection(genres, 'TV Genre')
            if not selected_genre:
                # User cancelled category selection - end directory properly
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
                return
            params.update({
                'category': selected_genre['title'],
                'category_id': selected_genre['id']
            })

        search_term = ask_for_input(params['category'])
        if search_term:
            params.update({'action': 'tv_listing', 'update_listing': False, 'search_term': search_term, 'page': 1})
            is_context = str(params.get('isContextMenuSearch', 'true')).lower() == 'true'
            if is_context:
                url = G.get_plugin_url(params)
                func_str = f'Container.Update({url})'
                xbmc.executebuiltin(func_str)
            else:
                self.__list_channels(params)

    @staticmethod
    def __list_main_menu():
        """List main menu"""
        media = xbmcaddon.Addon().getAddonInfo('path')
        media = os.path.join(media, 'resources', 'media')

        # Hauptmenü in gewünschter Reihenfolge
        list_item = xbmcgui.ListItem(label='[B][COLOR FFFFC107]TiTan[/COLOR] [COLOR FFFF4500]TV[/COLOR][/B]')
        list_item.setArt({'icon': os.path.join(media, 'tv.png'), 'thumb': os.path.join(media, 'tv.png'), 'poster': os.path.join(media, 'tv.png')})
        url = G.get_plugin_url({'action': 'tv', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='[B][COLOR FFFFC107]TiTan[/COLOR] [COLOR FFFF4500]VoD[/COLOR][/B]')
        list_item.setArt({'icon': os.path.join(media, 'vod.png'), 'thumb': os.path.join(media, 'vod.png'), 'poster': os.path.join(media, 'vod.png')})
        url = G.get_plugin_url({'action': 'vod', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Only show Serien if portal AND MAC are configured – avoids token errors
        # when the user has selected a portal but not yet chosen a MAC.
        mac_set = bool(G.portal_config.mac_cookie and
                       G.portal_config.mac_cookie != 'mac=' and
                       G.portal_config.mac_cookie != 'mac=')
        if G.portal_config.portal_url and mac_set:
            try:
                series_categories = Api.get_series_categories()
            except Exception:
                series_categories = []
        else:
            series_categories = []
        if isinstance(series_categories, list) and len(series_categories) > 0:
            list_item = xbmcgui.ListItem(label='[B][COLOR FFFFC107]TiTan[/COLOR] [COLOR FFFF4500]Serien[/COLOR][/B]')
            list_item.setArt({'icon': os.path.join(media, 'serien.png'), 'thumb': os.path.join(media, 'serien.png'), 'poster': os.path.join(media, 'serien.png')})
            url = G.get_plugin_url({'action': 'series', 'page': 1, 'update_listing': False})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='[COLOR FF32CD32]Portal wählen[/COLOR]')
        list_item.setArt({'icon': os.path.join(media, 'server.png'), 'thumb': os.path.join(media, 'server.png'), 'poster': os.path.join(media, 'server.png')})
        url = G.get_plugin_url({'action': 'choose_server'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        mac_val = (G.portal_config.mac_cookie or '').replace('mac=', '').strip()
        mac_label = '[COLOR FF32CD32]MAC wählen[/COLOR]' if mac_val else '[COLOR FFFF6600]MAC wählen  ⚠ keine MAC gesetzt![/COLOR]'
        list_item = xbmcgui.ListItem(label=mac_label)
        list_item.setArt({'icon': os.path.join(media, 'mac.png'), 'thumb': os.path.join(media, 'mac.png'), 'poster': os.path.join(media, 'mac.png')})
        url = G.get_plugin_url({'action': 'choose_mac'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        list_item = xbmcgui.ListItem(label='[COLOR FF32CD32]Liste in PVR Laden[/COLOR]')
        list_item.setArt({'icon': os.path.join(media, 'pvr.png'), 'thumb': os.path.join(media, 'pvr.png'), 'poster': os.path.join(media, 'pvr.png')})
        url = G.get_plugin_url({'action': 'apply_pvr'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        list_item = xbmcgui.ListItem(label='[COLOR FFA9A9A9]Cache löschen[/COLOR]')
        list_item.setArt({'icon': os.path.join(media, 'cache.png'), 'thumb': os.path.join(media, 'cache.png'), 'poster': os.path.join(media, 'cache.png')})
        url = G.get_plugin_url({'action': 'clear_cache'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        list_item = xbmcgui.ListItem(label='[COLOR FFA9A9A9]Einstellungen[/COLOR]')
        list_item.setArt({'icon': os.path.join(media, 'settings.png'), 'thumb': os.path.join(media, 'settings.png'), 'poster': os.path.join(media, 'settings.png')})
        url = G.get_plugin_url({'action': 'open_settings'})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    # --- Parental Control / PIN Handling ---

    def __handle_pc_disable(self):
        try:
            if not xbmcaddon:
                return
            _addon = xbmcaddon.Addon()
            try:
                stored_pin = _addon.getSettingString('pin')
            except Exception:
                stored_pin = _addon.getSetting('pin')
            stored_pin = (stored_pin or '').strip()
            entered = xbmcgui.Dialog().numeric(
                0,
                _addon.getLocalizedString(32020) or 'Enter current PIN to disable parental control'
            )
            if (entered or '').strip() == stored_pin:
                try:
                    _addon.setSettingBool('parental_control_enabled', False)
                except Exception:
                    _addon.setSetting('parental_control_enabled', 'false')
                xbmcgui.Dialog().notification(
                    'Info',
                    _addon.getLocalizedString(32035) or 'Parental control disabled',
                    xbmcgui.NOTIFICATION_INFO,
                    2000
                )
            else:
                xbmcgui.Dialog().notification(
                    'PIN',
                    _addon.getLocalizedString(32021) or 'Wrong PIN',
                    xbmcgui.NOTIFICATION_ERROR,
                    3000
                )
        except Exception as e:
            Logger.error('pc_disable error: {}'.format(e))

    def __handle_pin_change(self):
        try:
            if not xbmcaddon:
                return
            _addon = xbmcaddon.Addon()
            new1 = xbmcgui.Dialog().numeric(
                0,
                _addon.getLocalizedString(32032) or 'Enter new PIN'
            )
            new2 = xbmcgui.Dialog().numeric(
                0,
                _addon.getLocalizedString(32033) or 'Confirm new PIN'
            )
            if (new1 or '').strip() != (new2 or '').strip():
                xbmcgui.Dialog().notification(
                    'PIN',
                    _addon.getLocalizedString(32034) or 'PINs do not match',
                    xbmcgui.NOTIFICATION_ERROR,
                    3000
                )
                return
            try:
                _addon.setSettingString('pin', (new1 or '').strip())
            except Exception:
                _addon.setSetting('pin', (new1 or '').strip())
            xbmcgui.Dialog().notification(
                'PIN',
                _addon.getLocalizedString(32023) or 'PIN successfully changed',
                xbmcgui.NOTIFICATION_INFO,
                2000
            )
        except Exception as e:
            Logger.error('pin_change error: {}'.format(e))

    def __handle_pc_enable(self):
        try:
            if not xbmcaddon:
                return
            _addon = xbmcaddon.Addon()
            try:
                _addon.setSettingBool('parental_control_enabled', True)
            except Exception:
                _addon.setSetting('parental_control_enabled', 'true')
            xbmcgui.Dialog().notification(
                'Info',
                _addon.getLocalizedString(32036) or 'Parental control enabled',
                xbmcgui.NOTIFICATION_INFO,
                2000
            )
        except Exception as e:
            Logger.error('pc_enable error: {}'.format(e))

    def __handle_epg_refresh(self):
        try:
            clear_epg_cache()
            try:
                get_epg_data()
            except Exception:
                pass
            xbmcgui.Dialog().notification(
                'EPG', 'EPG aktualisiert', xbmcgui.NOTIFICATION_INFO, 2000)
            try:
                xbmc.executebuiltin('Action(Back)')
            except Exception:
                pass
            xbmc.executebuiltin('Container.Refresh')
        except Exception as exc:
            Logger.error('epg_refresh error: {}'.format(exc))

    @staticmethod
    def __handle_xmltv_refresh():
        """Manual XMLTV reload triggered from settings."""
        clear_xmltv_cache()
        try:
            load_xmltv(force=True)
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'XMLTV EPG geladen.',
                xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as exc:
            Logger.error('XMLTV refresh failed: {}'.format(exc))
            xbmcgui.Dialog().notification(
                'TitanMacVOD', 'XMLTV Fehler: {}'.format(exc),
                xbmcgui.NOTIFICATION_ERROR, 4000)

    def router(self, param_string):
        """Route calls"""
        params = dict(parse_qsl(param_string))
        if params and 'action' in params:
            if params['action'] == 'tv':
                self.__list_tv_genres()
            elif params['action'] == 'vod':
                self.__list_vod_categories()
            elif params['action'] == 'series':
                self.__list_series_categories()
            elif params['action'] == 'vod_favorites':
                self.__list_vod_favorites(params)
            elif params['action'] == 'series_favorites':
                self.__list_series_favorites(params)
            elif params['action'] == 'tv_favorites':
                self.__list_tv_favorites(params)
            elif params['action'] == 'tv_country_favorites':
                self.__list_tv_country_favorites()
            elif params['action'] == 'tv_listing':
                self.__list_channels(params)
            elif params['action'] == 'vod_listing':
                self.__list_vod(params)
            elif params['action'] == 'series_listing':
                self.__list_series(params)
            elif params['action'] == 'season_listing':
                self.__list_season(params)
            elif params['action'] == 'sub_folder':
                self.__list_episodes(params)
            elif params['action'] == 'play':
                self.__play_video(params)
            elif params['action'] == 'tv_play':
                self.__play_tv(params)
            elif params['action'] == 'vod_search':
                self.__search_vod(params)
            elif params['action'] == 'series_search':
                self.__search_series(params)
            elif params['action'] == 'tv_search':
                self.__search_tv(params)
            elif params['action'] == 'vod_country_favorites':
                self.__list_vod_country_favorites()
            elif params['action'] == 'series_country_favorites':
                self.__list_series_country_favorites()
            
            elif params['action'] == 'vod_fav_group_search':
                self.__vod_favorites_group_search(params)
            elif params['action'] == 'series_fav_group_search':
                self.__series_favorites_group_search(params)
            elif params['action'] == 'pc_disable':
                self.__handle_pc_disable()
            elif params['action'] == 'pc_enable':
                self.__handle_pc_enable()
            elif params['action'] == 'pin_change':
                self.__handle_pin_change()
            elif params['action'] == 'epg_refresh':
                self.__handle_epg_refresh()
            elif params['action'] == 'xmltv_refresh':
                self.__handle_xmltv_refresh()
            elif params['action'] == 'open_settings':
                xbmcaddon.Addon().openSettings()
            elif params['action'] == 'remove_fav':
                self.__toggle_favorites(params['video_id'], False, params['_type'])
            elif params['action'] == 'add_fav':
                self.__toggle_favorites(params['video_id'], True, params['_type'])
            elif params['action'] == 'choose_server':

                from . import core_entry as default_module

                default_module.choose_server()

            elif params['action'] == 'choose_mac':

                from . import core_entry as default_module

                default_module.choose_mac()

            elif params['action'] == 'apply_pvr':

                from . import core_entry as default_module

                default_module.apply_pvr()

            elif params['action'] == 'clear_cache':

                from . import core_entry as default_module

                default_module.manual_clear_cache()

            else:
                raise ValueError('Invalid param string: {}!'.format(param_string))
        else:
            self.__list_main_menu()


def run(argv):
    """Run"""
    G.init_globals()
    stalker_addon = StalkerAddon()
    stalker_addon.router(argv[2][1:])
