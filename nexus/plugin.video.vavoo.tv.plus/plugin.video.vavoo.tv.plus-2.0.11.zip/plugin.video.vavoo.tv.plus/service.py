# -*- coding: utf-8 -*-
"""Aktualisiert die ausdrücklich ausgewählten Länder beim Kodi-Start."""
import os
import json
import hashlib
import xbmcgui
import sys
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon(id="plugin.video.vavoo.tv.plus")
PREFIX = "[Vavoo TV Plus Startup] "
MAX_ATTEMPTS = 3
RETRY_SECONDS = (15, 30)


def log(message, level=xbmc.LOGINFO):
    xbmc.log(PREFIX + str(message), level)


def list_fingerprint(channels):
    """Stable digest of channel names and their source URLs, independent of dict ordering."""
    canonical = []
    for name, urls in channels.items():
        canonical.append((str(name), sorted(str(url) for url in urls)))
    payload = json.dumps(sorted(canonical), ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def read_snapshots(path):
    try:
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def save_snapshots(path, data):
    temp = path + ".tmp"
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, sort_keys=True)
    os.replace(temp, path)


def refresh(monitor):
    selected = ADDON.getSetting("selected_countries").strip()
    if not selected:
        log("Keine Länder explizit ausgewählt; Aktualisierung übersprungen.")
        return
    lib = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))
    if lib not in sys.path:
        sys.path.insert(0, lib)
    import vavoo_api as api

    codes = api.parse_country_codes(selected)
    if not codes:
        log("Keine gültige Länderauswahl gefunden.", xbmc.LOGWARNING)
        return
    # Die verfügbare Länderliste kann bei Netzwerkausfall auf Fallback-Daten zurückgreifen.
    try:
        countries = api.get_available_countries()
    except Exception as exc:
        log("Länderkatalog nicht erreichbar: %s" % exc, xbmc.LOGWARNING)
        countries = []
    known = {api.country_to_code(country).upper(): country for country in countries}
    names = []
    for code in codes:
        name = known.get(str(code).upper(), code)
        if name not in names:
            names.append(name)

    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    os.makedirs(profile, exist_ok=True)
    snapshot_path = os.path.join(profile, "startup_country_snapshots.json")
    snapshots = read_snapshots(snapshot_path)
    changed_countries = []
    for country in names:
        if monitor.abortRequested():
            return
        for attempt in range(1, MAX_ATTEMPTS + 1):
            if monitor.abortRequested():
                return
            try:
                # strict_refresh verhindert, dass alte Cache-Daten als neuer Download gelten.
                channels = api.fetch_channels_for_group(country, force=True, strict_refresh=True)
                log("%s: %d Sender frisch geladen (Versuch %d)." % (country, len(channels), attempt))
                fingerprint = list_fingerprint(channels)
                previous = snapshots.get(str(country))
                if previous is not None and previous != fingerprint:
                    changed_countries.append(str(country))
                    log("%s: Senderliste hat sich geändert." % country)
                elif previous is None:
                    log("%s: Erste Vergleichsbasis gespeichert; kein Änderungsalarm." % country)
                snapshots[str(country)] = fingerprint
                try:
                    save_snapshots(snapshot_path, snapshots)
                except OSError as exc:
                    log("Vergleichsbasis konnte nicht gespeichert werden: %s" % exc, xbmc.LOGWARNING)
                break
            except Exception as exc:
                log("%s: Versuch %d/%d fehlgeschlagen: %s; vorhandener Cache bleibt erhalten." %
                    (country, attempt, MAX_ATTEMPTS, exc), xbmc.LOGWARNING)
                if attempt == MAX_ATTEMPTS:
                    log("%s: Kein frisches Update; bisherige Liste bleibt erhalten." % country, xbmc.LOGWARNING)
                elif monitor.waitForAbort(RETRY_SECONDS[attempt - 1]):
                    return
    if changed_countries and not monitor.abortRequested():
        message = "Bitte Favo-Liste aktualisieren! Senderlisten geändert: " + ", ".join(changed_countries[:4])
        if len(changed_countries) > 4:
            message += " (+%d weitere)" % (len(changed_countries) - 4)
        xbmcgui.Dialog().notification("Vavoo TV Plus", message, xbmcgui.NOTIFICATION_INFO, 9000, False)
        log("Favoriten-Hinweis angezeigt: %s" % ", ".join(changed_countries))


def main():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(10):
        return
    try:
        if ADDON.getSetting("refresh_selected_on_startup").lower() not in ("true", "1", "yes"):
            log("Automatische Aktualisierung deaktiviert.")
            return
        refresh(monitor)
    except Exception as exc:
        log("Startaktualisierung fehlgeschlagen: %s" % exc, xbmc.LOGERROR)


if __name__ == "__main__":
    import threading
    lib = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))
    sys.path.insert(0, lib)
    import vod_comfort
    threading.Thread(target=main, daemon=True).start()
    vod_comfort.run(xbmc.Monitor())
