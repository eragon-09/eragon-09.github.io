# -*- coding: utf-8 -*-
"""Settings menu view."""
from .runtime import get
from utils import strings


def show():
    xbmcplugin = get("xbmcplugin")
    xbmcgui = get("xbmcgui")
    handle = get("HANDLE")
    set_info = get("_set_info_tag")
    build_url = get("build_url")

    xbmcplugin.setContent(handle, "files")
    items = [
        (strings.SETTINGS_COUNTRY_GROUPS, "country_select", False),
        (strings.SETTINGS_CONFIGURATION, "config_menu", True),
        ("Über Vavoo TV Plus", "release_information", False),
    ]
    for label, action, is_folder in items:
        li = xbmcgui.ListItem(label)
        set_info(li, label)
        xbmcplugin.addDirectoryItem(handle, build_url(action=action), li, is_folder)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
