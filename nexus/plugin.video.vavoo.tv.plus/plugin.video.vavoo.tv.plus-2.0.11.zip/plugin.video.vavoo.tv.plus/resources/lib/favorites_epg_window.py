# -*- coding: utf-8 -*-
"""Vavoo TV Guide: zeitproportionale, fernbedienbare Multi-EPG (1080p).

Das Fenster bringt alle Texturen selbst mit (resources/skins/Default/media) und
sieht deshalb unter jedem Kodi-Skin gleich aus. Raster, Fokusrahmen und
Jetzt-Linie werden hier dynamisch gezeichnet, die Kopf- und Infoleiste steht in
FavoritesEPG.xml.
"""
import datetime
import math
import os
import re
import threading

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.vavoo.tv.plus')
MEDIA = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'skins', 'Default', 'media')


def _tex(name):
    return os.path.join(MEDIA, name)


# ── Geometrie (1080p) ────────────────────────────────────────────────────────
ROWS = 10                       # Sender pro Seite
LEFT = 12                       # linker Rand der Senderspalte
GRID_X, GRID_W = 350, 1560      # Raster: x-Start und Breite
TOP, ROW_H = 256, 56            # erste Zeile, Zeilenhöhe
PX_PER_MIN = 7.6                # 30 min = 228 px
VIEW_MIN = int(GRID_W / PX_PER_MIN)   # sichtbare Minuten (~205)
LEAD_MIN = 15                   # Vorlauf links vor dem ersten Zeitstempel
STEP_MIN = 30                   # Scroll-Schritt
RULER_Y = 176                   # Uhrzeiten in der Zeitleiste
LINE_TOP, LINE_BOTTOM = 218, 846

OFFSET_MIN, OFFSET_MAX = -48, 96    # Scrollgrenze in 30-min-Schritten

WEEKDAYS = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag']

# Kodi-Aktions-IDs
ACT_LEFT, ACT_RIGHT, ACT_UP, ACT_DOWN = 1, 2, 3, 4
ACT_PAGE_UP, ACT_PAGE_DOWN = 5, 6
ACT_CLOSE = (9, 10, 92, 216)    # PARENT_DIR, PREVIOUS_MENU, NAV_BACK, BACKSPACE

HEADER_IDS = (10, 11, 12, 13)


def _programmes(api, channel):
    """Findet die EPG-Einträge eines Senders (tvg_id, Name, normalisiert, EPG-Mapping)."""
    cache = api._epg_cache
    lookup = getattr(api, '_epg_lookup', {})

    def norm(value):
        return re.sub(r'[^a-z0-9]', '', (value or '').lower())

    for key in (channel.get('tvg_id'), channel.get('name')):
        if not key:
            continue
        if key in cache:
            return cache[key]
        found = lookup.get(norm(key))
        if found in cache:
            return cache[found]
    try:
        mapped = api.get_channel_epg_id(channel.get('name', ''))
        if mapped and mapped in cache:
            return cache[mapped]
    except Exception:
        pass
    return []


class FavoritesEPG(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.gf = kwargs['groups_module']
        self.api = kwargs['api']
        self.groups = self.gf.load_groups()
        self.group_index = -1          # -1 = Alle Favoriten
        self.start_url = kwargs.get('start_url', '')
        start_file = kwargs.get('start_file', '')
        for i, g in enumerate(self.groups):     # Start direkt in der gewünschten Gruppe
            if start_file and g.get('file') == start_file:
                self.group_index = i
                break
        self.offset = 0                # in 30-min-Schritten
        self.page = 0
        self.channels = []
        self.chosen = None
        self.dynamic = []              # alle dynamisch erzeugten Controls
        self.rows = []                 # pro sichtbarer Zeile: {'channel','progs','cells'}
        self.cellmap = {}              # controlId -> (row, col)
        self.selected_row = 0
        self.selected_col = 0
        self.sel_time = None           # Zeitanker für Auf/Ab-Navigation
        self.view_start = None
        self.view_end = None
        self.row_hl = self.now_line = self.now_marker = None
        self.frame = []
        self._progs = {}
        self._pending = []
        self._sel_key = None
        self._stop = threading.Event()
        self.utc_shift = datetime.datetime.utcnow() - datetime.datetime.now()

    # ── Lebenszyklus ────────────────────────────────────────────────────────
    def onInit(self):
        self._load_channels()
        if self.start_url:                      # gewünschten Sender vorauswählen
            for i, ch in enumerate(self.channels):
                if ch.get('url') == self.start_url:
                    self.page, self.selected_row = divmod(i, ROWS)
                    break
            self.start_url = ''
        self.sel_time = datetime.datetime.now()
        self._render()
        self._focus_cell()
        if not getattr(self, '_ticker', None):
            self._ticker = threading.Thread(target=self._tick, daemon=True)
            self._ticker.start()

    def close(self):
        self._stop.set()
        super().close()

    def _tick(self):
        """Uhr und Jetzt-Linie alle 15 s nachführen."""
        while not self._stop.wait(15):
            try:
                self._update_clock()
                self._place_now()
            except Exception:
                continue    # z. B. während eines Neuaufbaus; nächster Takt klappt wieder

    # ── Daten ───────────────────────────────────────────────────────────────
    def _load_channels(self):
        groups = self.groups if self.group_index == -1 else [self.groups[self.group_index]]
        self.channels = []
        seen = set()
        for group in groups:
            for channel in self.gf.load_group_channels(group['file']):
                if not channel.get('name') or not channel.get('url'):
                    continue
                if self.group_index == -1 and channel['url'] in seen:
                    continue
                seen.add(channel['url'])
                self.channels.append(channel)
        self.page = 0
        self.selected_row = 0
        self.selected_col = 0

    def _local_progs(self, channel):
        """EPG-Liste eines Senders in Ortszeit, sortiert (pro Sender gecacht)."""
        key = channel.get('url') or channel.get('name')
        if key not in self._progs:
            out = []
            for start, stop, title, desc in _programmes(self.api, channel):
                if start and stop:
                    out.append((start - self.utc_shift, stop - self.utc_shift, title or '', desc or ''))
            out.sort(key=lambda p: p[0])
            self._progs[key] = out
        return self._progs[key]

    # ── Zeichnen ────────────────────────────────────────────────────────────
    def _clear(self):
        if self.dynamic:
            self.removeControls(self.dynamic)
        self.dynamic = []
        self.rows = []
        self.cellmap = {}
        self.frame = []
        self._pending = []
        self._sel_key = None
        self.row_hl = self.now_line = self.now_marker = None

    def _add(self, control):
        # Controls sammeln und am Ende in EINEM Aufruf hinzufügen (viel schneller als einzeln)
        self._pending.append(control)
        return control

    def _flush(self):
        if self._pending:
            self.addControls(self._pending)
            self.dynamic.extend(self._pending)
            self._pending = []

    def _label(self, x, y, w, h, text, color='FFE5EAF2', font='font13', align=4):
        return self._add(xbmcgui.ControlLabel(x, y, w, h, str(text), font=font,
                                              textColor=color, alignment=align))

    def _rect(self, x, y, w, h, color, texture='white.png'):
        return self._add(xbmcgui.ControlImage(x, y, w, h, _tex(texture), colorDiffuse=color))

    def _x(self, t):
        return GRID_X + int((t - self.view_start).total_seconds() / 60 * PX_PER_MIN)

    def _tick0(self, now):
        base = now.replace(minute=(now.minute // 30) * 30, second=0, microsecond=0)
        return base - datetime.timedelta(minutes=30) + datetime.timedelta(minutes=STEP_MIN * self.offset)

    def _render(self):
        self._clear()
        now = datetime.datetime.now().replace(microsecond=0)
        tick0 = self._tick0(now)
        self.view_start = tick0 - datetime.timedelta(minutes=LEAD_MIN)
        self.view_end = self.view_start + datetime.timedelta(minutes=VIEW_MIN)

        name = 'Alle Favoriten' if self.group_index == -1 else self.groups[self.group_index]['name']
        self.getControl(10).setLabel(name)
        total_pages = max(1, (len(self.channels) + ROWS - 1) // ROWS)
        self.getControl(30).setLabel('Seite {}/{} · {} Sender'.format(
            self.page + 1, total_pages, len(self.channels)))
        self._update_clock()

        # Zeitleiste mit Teilstrichen
        for i in range(7):
            t = tick0 + datetime.timedelta(minutes=30 * i)
            x = self._x(t)
            if GRID_X - 40 <= x <= GRID_X + GRID_W + 20:
                self._label(x - 70, RULER_Y, 140, 30, t.strftime('%H:%M'), 'FFFFFFFF', align=2)
                self._rect(x - 1, RULER_Y + 32, 2, 12, 'FF9AA8BD')

        # Zeilen-Highlight des gewählten Senders (liegt unter den Sendernamen)
        self.row_hl = self._rect(LEFT - 4, TOP, GRID_X - LEFT - 2, ROW_H - 2, 'FFD40F1F')

        page_channels = self.channels[self.page * ROWS:(self.page + 1) * ROWS]
        for row, channel in enumerate(page_channels):
            y = TOP + row * ROW_H
            self._rect(LEFT, y + ROW_H - 1, GRID_X - LEFT - 6, 1, 'FF28344A')
            if channel.get('logo'):
                self._add(xbmcgui.ControlImage(LEFT + 10, y + 7, 56, 42, channel['logo'], aspectRatio=2))
            self._label(LEFT + 78, y, GRID_X - LEFT - 96, ROW_H - 2, channel.get('name', ''),
                        'FFFFFFFF', align=4)

            progs = self._local_progs(channel)
            visible = [p for p in progs if p[1] > self.view_start and p[0] < self.view_end]
            if not visible:
                visible = [(self.view_start, self.view_end, 'Keine EPG-Daten', '')]
            cells = []
            for start, stop, title, desc in visible:
                a = max(self.view_start, start)
                b = min(self.view_end, stop)
                x = self._x(a)
                w = self._x(b) - x - 4
                if w < 14:
                    continue
                has_data = title != 'Keine EPG-Daten'
                if has_data and stop <= now:
                    skin, text_color = 'cell_gray', 'FFB4BDC9'      # abgelaufen: Schiefergrau
                elif has_data and start <= now:
                    skin, text_color = 'cell_green', 'FFFFFFFF'     # läuft gerade
                else:
                    skin, text_color = 'cell_blue', 'FFFFFFFF'      # kommt noch
                btn = xbmcgui.ControlButton(
                    x, y + 3, w, ROW_H - 6, title or 'Ohne Titel',
                    focusTexture=_tex(skin + '_focus.png'), noFocusTexture=_tex(skin + '.png'),
                    textOffsetX=14, alignment=4, font='font13',
                    textColor=text_color, focusedColor='FFFFFFFF')
                self._add(btn)
                cells.append({'btn': btn, 'prog': (start, stop, title, desc)})
            self.rows.append({'channel': channel, 'progs': progs, 'cells': cells})

        # Jetzt-Linie, Marke und Fokusrahmen (über allem) anlegen, dann alles auf einmal hinzufügen
        self.now_line = self._rect(0, LINE_TOP, 3, LINE_BOTTOM - LINE_TOP, 'FFFF263D')
        self.now_marker = self._add(xbmcgui.ControlImage(0, LINE_TOP - 14, 18, 14, _tex('now_marker.png')))
        self.frame = [self._rect(0, 0, 1, 1, 'FFFFFFFF') for _ in range(4)]
        self._flush()

        # Eigene Navigation: Kodi soll den Fokus nicht selbst verschieben
        for r, row in enumerate(self.rows):
            for c, cell in enumerate(row['cells']):
                b = cell['btn']
                b.setNavigation(b, b, b, b)
                self.cellmap[b.getId()] = (r, c)
        for f in self.frame:
            f.setVisible(False)
        self._place_now()

    def _place_now(self):
        if not (self.now_line and self.now_marker and self.view_start):
            return
        now = datetime.datetime.now()
        visible = self.view_start <= now <= self.view_end
        if visible:
            x = self._x(now)
            self.now_line.setPosition(x - 1, LINE_TOP)
            self.now_marker.setPosition(x - 9, LINE_TOP - 14)
        self.now_line.setVisible(visible)
        self.now_marker.setVisible(visible)

    def _update_clock(self):
        now = datetime.datetime.now()
        self.getControl(31).setLabel('{} · {}'.format(WEEKDAYS[now.weekday()], now.strftime('%d.%m.%Y')))
        self.getControl(32).setLabel(now.strftime('%H:%M') + ' Uhr')

    def _place_frame(self, btn):
        x, y = btn.getX(), btn.getY()
        w, h = btn.getWidth(), btn.getHeight()
        t = 3
        parts = [(x, y, w, t), (x, y + h - t, w, t), (x, y, t, h), (x + w - t, y, t, h)]
        for ctl, (px, py, pw, ph) in zip(self.frame, parts):
            ctl.setPosition(px, py)
            ctl.setWidth(pw)
            ctl.setHeight(ph)
            ctl.setVisible(True)

    # ── Auswahl und Infoleiste ──────────────────────────────────────────────
    def _select(self, row, col):
        if not (0 <= row < len(self.rows)) or not self.rows[row]['cells']:
            return
        cells = self.rows[row]['cells']
        col = max(0, min(col, len(cells) - 1))
        key = cells[col]['btn'].getId()
        if key == self._sel_key:      # schon ausgewählt (onFocus nach setFocus): nichts doppelt tun
            return
        self._sel_key = key
        self.selected_row, self.selected_col = row, col
        if self.row_hl:
            self.row_hl.setPosition(LEFT - 4, TOP + row * ROW_H)
        if self.frame:
            self._place_frame(cells[col]['btn'])
        self._details()

    def _details(self):
        if not self.rows:
            self._set_info('Keine Sender', '', '', None, '', '')
            return
        row = self.rows[self.selected_row]
        cells = row['cells']
        if not cells:
            return
        start, stop, title, desc = cells[min(self.selected_col, len(cells) - 1)]['prog']
        channel = row['channel']
        now = datetime.datetime.now()
        times = '{} – {}'.format(start.strftime('%H:%M'), stop.strftime('%H:%M'))
        if title == 'Keine EPG-Daten':
            times = ''
        elif start <= now < stop:
            left = max(1, int((stop - now).total_seconds() // 60))
            times += '  ·  läuft, noch {} Min.'.format(left)
        nxt_time = nxt_title = ''
        for s, e, t, _d in row['progs']:
            if s >= stop:
                nxt_time = '{} – {}'.format(s.strftime('%H:%M'), e.strftime('%H:%M'))
                nxt_title = t
                break
        self._set_info(title or 'Ohne Titel', times,
                       (desc or 'Keine Beschreibung vorhanden')[:320] if title != 'Keine EPG-Daten' else '',
                       channel, nxt_time, nxt_title)

    def _set_info(self, title, times, desc, channel, nxt_time, nxt_title):
        self.getControl(40).setLabel(title)
        self.getControl(41).setLabel(times)
        self.getControl(42).setText(desc)
        self.getControl(43).setImage((channel or {}).get('logo') or '', False)
        self.getControl(44).setLabel((channel or {}).get('name', ''))
        self.getControl(51).setLabel(nxt_time)
        self.getControl(52).setLabel(nxt_title)

    def _cell_index_at(self, row, t):
        cells = self.rows[row]['cells']
        if not cells:
            return -1
        for i, cell in enumerate(cells):
            s, e = cell['prog'][0], cell['prog'][1]
            if s <= t < e:
                return i
        return min(range(len(cells)),
                   key=lambda i: abs((cells[i]['prog'][0] - t).total_seconds()))

    def _focus_cell(self):
        """Fokus auf die Sendung der gewählten Zeile zum Zeitanker setzen."""
        if not self.rows:
            self.setFocusId(10)
            return
        self.selected_row = max(0, min(self.selected_row, len(self.rows) - 1))
        idx = self._cell_index_at(self.selected_row, self.sel_time or datetime.datetime.now())
        if idx < 0:
            self.setFocusId(10)
            return
        self._select(self.selected_row, idx)
        self.setFocus(self.rows[self.selected_row]['cells'][idx]['btn'])

    def _focus_live_cell(self):
        """Vertikal immer die jetzt laufende Sendung fokussieren.

        Links/Rechts dürfen die Zeitposition verändern; Hoch/Runter stellt
        den Jetzt-Bezug wieder her. Ohne EPG wird die Ersatzkachel gewählt.
        """
        now = datetime.datetime.now().replace(microsecond=0)
        self.sel_time = now
        if self.offset != 0 or not (self.view_start <= now < self.view_end):
            self.offset = 0
            self._rerender()
        else:
            self._focus_cell()

    def _anchor(self, prog):
        return max(prog[0], self.view_start) + datetime.timedelta(seconds=1)

    def _rerender(self, focus_cell=True):
        self.offset = max(OFFSET_MIN, min(OFFSET_MAX, self.offset))
        self._render()
        if focus_cell:
            self._focus_cell()

    # ── Eingaben ────────────────────────────────────────────────────────────
    def onFocus(self, controlId):
        # Maus oder direkter Fokuswechsel: Auswahl nachziehen
        if controlId in self.cellmap:
            row, col = self.cellmap[controlId]
            self.sel_time = self._anchor(self.rows[row]['cells'][col]['prog'])
            self._select(row, col)

    def onClick(self, controlId):
        if controlId == 10:
            options = ['Alle Favoriten'] + [g['name'] for g in self.groups]
            choice = xbmcgui.Dialog().select('Sendergruppe wählen', options,
                                             preselect=self.group_index + 1)
            if choice >= 0:
                self.group_index = choice - 1
                self._load_channels()
                self._rerender(focus_cell=False)
            self.setFocusId(10)
        elif controlId in (11, 13):
            self.offset += -2 if controlId == 11 else 2
            self.sel_time = None
            self._rerender(focus_cell=False)
            self.setFocusId(controlId)
        elif controlId == 12:
            self.offset = 0
            self.sel_time = datetime.datetime.now()
            self._rerender(focus_cell=False)
            self.setFocusId(12)
        elif controlId in self.cellmap:
            row, _col = self.cellmap[controlId]
            self.chosen = self.rows[row]['channel']
            self.close()

    def onAction(self, action):
        code = action.getId()
        if code in ACT_CLOSE:
            self.close()
            return
        if code not in (ACT_LEFT, ACT_RIGHT, ACT_UP, ACT_DOWN, ACT_PAGE_UP, ACT_PAGE_DOWN):
            return
        focus = self.getFocusId()
        if focus in HEADER_IDS:
            if code == ACT_DOWN:
                self._focus_live_cell()
            return
        if focus not in self.cellmap:
            return
        row, col = self.cellmap[focus]
        cells = self.rows[row]['cells']
        cur = cells[col]['prog']

        if code == ACT_RIGHT:
            if col + 1 < len(cells):
                nxt = cells[col + 1]['prog']
                self.sel_time = self._anchor(nxt)
                limit = self.view_end - datetime.timedelta(minutes=25)
                if nxt[0] >= limit:      # Block liegt kaum noch im Bild: weiterscrollen
                    need = (nxt[0] - limit).total_seconds() / 60
                    self.offset += max(1, int(math.ceil(need / STEP_MIN)))
                    self.sel_time = nxt[0] + datetime.timedelta(seconds=1)
                    self._rerender()
                else:
                    self._select(row, col + 1)
                    self.setFocus(cells[col + 1]['btn'])
            else:
                self.sel_time = self.view_end + datetime.timedelta(seconds=1)
                self.offset += 1
                self._rerender()
        elif code == ACT_LEFT:
            if col > 0 and cells[col - 1]['prog'][1] > self.view_start:
                prev = cells[col - 1]['prog']
                self.sel_time = self._anchor(prev)
                self._select(row, col - 1)
                self.setFocus(cells[col - 1]['btn'])
            else:
                self.sel_time = max(cur[0], self.view_start) - datetime.timedelta(minutes=1)
                self.offset -= 1
                self._rerender()
        elif code == ACT_UP:
            if row > 0:
                self.selected_row = row - 1
                self._focus_live_cell()
            elif self.page > 0:
                self.page -= 1
                self.selected_row = ROWS - 1
                self.sel_time = datetime.datetime.now().replace(microsecond=0)
                self.offset = 0
                self._rerender()
            else:
                self.setFocusId(10)
        elif code == ACT_DOWN:
            if row + 1 < len(self.rows):
                self.selected_row = row + 1
                self._focus_live_cell()
            elif (self.page + 1) * ROWS < len(self.channels):
                self.page += 1
                self.selected_row = 0
                self.sel_time = datetime.datetime.now().replace(microsecond=0)
                self.offset = 0
                self._rerender()
        elif code == ACT_PAGE_DOWN and (self.page + 1) * ROWS < len(self.channels):
            self.page += 1
            self.selected_row = 0
            self.sel_time = datetime.datetime.now().replace(microsecond=0)
            self.offset = 0
            self._rerender()
        elif code == ACT_PAGE_UP and self.page > 0:
            self.page -= 1
            self.selected_row = 0
            self.sel_time = datetime.datetime.now().replace(microsecond=0)
            self.offset = 0
            self._rerender()
