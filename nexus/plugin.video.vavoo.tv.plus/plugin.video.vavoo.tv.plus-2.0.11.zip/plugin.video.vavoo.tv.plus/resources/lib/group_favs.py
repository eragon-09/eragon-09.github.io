# -*- coding: utf-8 -*-
"""
group_favs.py
"""

import os
import re
import json
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

from utils.io import atomic_write_json, atomic_write_text
from utils import logger as _logger

ADDON    = xbmcaddon.Addon()

# ---------------------------------------------------------------------------
# Pfade
# ---------------------------------------------------------------------------

def _profile_dir():
    return xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

def _groups_json_path():
    return os.path.join(_profile_dir(), "groups.json")

def _favgroups_dir():
    d = os.path.join(_profile_dir(), "favgroups")
    os.makedirs(d, exist_ok=True)
    return d

def _group_m3u_path(filename):
    return os.path.join(_favgroups_dir(), filename)

def _backup_zip_path():
    import datetime
    date = datetime.date.today().strftime("%Y-%m-%d")
    return os.path.join(_profile_dir(), f"VavooTV-Gruppen-Backup-{date}.zip")

# ---------------------------------------------------------------------------
# Favo-Icons
# ---------------------------------------------------------------------------

from favorites import group_icons as _group_icons

# Kompatibilitaetsnamen fuer bestehende Aufrufer innerhalb und ausserhalb
# dieses Moduls. Die Implementierung liegt zentral in favorites/group_icons.py.
_addon_icons_dir = _group_icons.addon_icons_dir
_user_icons_dir = _group_icons.user_icons_dir
_stem = _group_icons.group_stem
_addon_default_icon = _group_icons.addon_default_icon
_find_icon_in_dir = _group_icons.find_icon_in_dir
get_group_icon = _group_icons.get_group_icon
get_group_icon_optional = _group_icons.get_group_icon_optional
_init_group_icon = _group_icons.init_group_icon
_rename_group_icon = _group_icons.rename_group_icon
_delete_group_icon = _group_icons.delete_group_icon

# ---------------------------------------------------------------------------
# Gruppen-Konfiguration laden / speichern
# ---------------------------------------------------------------------------

DEFAULT_GROUPS = [
    {"name": "TV Spielfilm HD", "file": "tv_spielfilm_favoriten_hd.m3u"},
    {"name": "Private",         "file": "private.m3u"},
    {"name": "Serien",          "file": "serien.m3u"},
    {"name": "Kids",            "file": "kids.m3u"},
    {"name": "Sky",             "file": "sky.m3u"},
    {"name": "Cinema TV",       "file": "cinema_tv.m3u"},
    {"name": "Cinedome",        "file": "cinedome.m3u"},
    {"name": "Sky Box Office",  "file": "sky_box.m3u"},
    {"name": "BlueTV",          "file": "bluetv.m3u"},
    {"name": "Popcorn TV",      "file": "popcorn.m3u"},
    {"name": "Sport",           "file": "sport.m3u"},
    {"name": "Bundesliga",      "file": "bundesliga.m3u"},
    {"name": "DAZN",            "file": "dazn.m3u"},
    {"name": "Pluto TV",        "file": "pluto_tv.m3u"},
    {"name": "Rakuten TV",      "file": "rakuten_tv.m3u"},
    {"name": "Doku",            "file": "doku.m3u"},
    {"name": "News",            "file": "news.m3u"},
    {"name": "Musik",           "file": "musik.m3u"},
]

def _addon_favgroups_dir():
    """M3U-Dateien die mit dem Addon ausgeliefert werden (resources/favgroups/)."""
    try:
        addon_path = xbmcaddon.Addon().getAddonInfo("path")
        return os.path.join(xbmcvfs.translatePath(addon_path), "resources", "favgroups")
    except Exception:
        return ""

# Alte Default-Dateinamen – werden bei Migration entfernt wenn leer
_LEGACY_DEFAULT_FILES = {
    "oeffentlich.m3u", "doku.m3u", "sport.m3u",
    "news.m3u", "musik.m3u", "kinder.m3u",
}

def _migrate_groups(groups):
    """
    Einmalige Migration beim Update auf 1.3.x:
    – Entfernt leere Legacy-Gruppen (oeffentlich, doku, sport, news, musik, kinder)
    – Benennt 'Film & Serien' → 'Filme' und 'Kinder' → 'Kids' wenn leer
    – Fügt fehlende neue Default-Gruppen (Bundesliga, Kids) hinzu wenn noch
      gar keine Sender-Daten existieren
    Gefüllte Gruppen werden NIEMALS verändert.
    """
    changed = False
    result = []

    for g in groups:
        fname = g.get("file", "")
        name  = g.get("name", "")

        # Legacy-Gruppe: nur entfernen wenn die M3U-Datei leer oder nicht
        # vorhanden ist
        if fname in _LEGACY_DEFAULT_FILES:
            channels = load_group_channels(fname)
            if not channels:
                # Datei aufräumen
                path = _group_m3u_path(fname)
                if os.path.exists(path):
                    try:
                        os.remove(path)
                    except Exception:
                        pass
                changed = True
                continue  # Gruppe nicht übernehmen

        # "Film & Serien" → "Filme" (nur wenn leer)
        if fname == "filme.m3u" and name == "Film & Serien":
            if not load_group_channels(fname):
                g = dict(g)
                g["name"] = "Filme"
                changed = True

        # "Kinder" → "Kids" (nur wenn leer)
        if fname == "kinder.m3u" and name == "Kinder":
            if not load_group_channels(fname):
                g = dict(g)
                g["name"] = "Kids"
                g["file"] = "kids.m3u"
                changed = True

        result.append(g)

    # Fehlende neue Defaults hinzufügen wenn noch nicht vorhanden
    existing_files = {g["file"] for g in result}
    for default in DEFAULT_GROUPS:
        if default["file"] not in existing_files:
            result.append(default)
            save_group_channels(default["file"], [])
            changed = True

    if changed:
        save_groups(result)

    return result


def load_groups():
    """Lädt Gruppen-Konfiguration. Erstellt Defaults wenn nicht vorhanden."""
    path = _groups_json_path()
    if os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                groups = json.load(f)
            # Migration bei jedem Laden prüfen (günstig da nur Dateinamen verglichen)
            return _migrate_groups(groups)
        except Exception:
            pass
    # Erster Start – M3Us aus resources/favgroups/ in addon_data kopieren
    addon_fav_dir = _addon_favgroups_dir()
    groups_to_register = []
    epg_url = ADDON.getSetting("epg_url").strip()

    for g in DEFAULT_GROUPS:
        fname = g["file"]
        dest  = _group_m3u_path(fname)
        src_file = os.path.join(addon_fav_dir, fname) if addon_fav_dir else ""

        if not os.path.exists(dest):
            if src_file and os.path.exists(src_file):
                # Mitgelieferte M3U kopieren
                try:
                    import shutil as _sh
                    _sh.copy2(src_file, dest)
                except Exception:
                    save_group_channels(fname, [], epg_url)
            else:
                save_group_channels(fname, [], epg_url)

        _init_group_icon(fname)
        groups_to_register.append(g)

    save_groups(groups_to_register)
    return groups_to_register[:]

def save_groups(groups):
    """Speichert die Gruppen-Konfiguration atomar."""
    try:
        atomic_write_json(_groups_json_path(), groups, indent=2)
        return True
    except Exception as exc:
        _logger.error("save_groups error: %s" % exc)
        return False

def _make_filename(name):
    """Erstellt sicheren Dateinamen aus Gruppenname."""
    s = name.lower()
    s = re.sub(r'[äöüÄÖÜ]', lambda m: {'ä':'ae','ö':'oe','ü':'ue','Ä':'ae','Ö':'oe','Ü':'ue'}[m.group()], s)
    s = re.sub(r'[^a-z0-9]', '_', s)
    s = re.sub(r'_+', '_', s).strip('_')
    return f"{s}.m3u"

# ---------------------------------------------------------------------------
# M3U lesen / schreiben
# ---------------------------------------------------------------------------

def load_group_channels(filename):
    """
    Liest eine Gruppen-M3U und gibt Liste von Dicts zurück:
      {"name": ..., "url": ..., "logo": ..., "tvg_id": ...}
    """
    path = _group_m3u_path(filename)
    from favorites.geil_migration import migrate, migrate_cinema
    migrate_cinema(path, os.path.join(_addon_favgroups_dir(), "cinema_mapping.json"))
    migrate(path, os.path.join(_addon_favgroups_dir(), "geil_mapping.json"))
    if not os.path.exists(path):
        return []

    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            lines = f.read().splitlines()
    except Exception:
        return []

    channels      = []
    current_ext   = None
    pending_vavoo = None

    for line in lines:
        line = line.strip()
        if not line or line.startswith("#EXTM3U"):
            continue

        if line.startswith("#EXTINF:"):
            current_ext   = line
            pending_vavoo = None
            continue

        if line.startswith("##VAVOO-URL:"):
            pending_vavoo = line[12:].strip()
            continue

        if line.startswith("#"):
            continue

        if current_ext is not None:
            # Name
            m = re.search(r',(.+)$', current_ext)
            name = m.group(1).strip() if m else ""

            # tvg-logo
            m_logo = re.search(r'tvg-logo="([^"]*)"', current_ext)
            logo   = m_logo.group(1).strip() if m_logo else ""

            # tvg-id
            m_id  = re.search(r'tvg-id="([^"]*)"', current_ext)
            tvgid = m_id.group(1).strip() if m_id else ""

            # URL
            if pending_vavoo:
                url = pending_vavoo
            elif line.startswith("plugin://"):
                try:
                    from urllib.parse import parse_qs, urlparse, unquote_plus
                    qs  = parse_qs(urlparse(line).query)
                    url = unquote_plus(qs["url"][0]) if "url" in qs else line
                except Exception:
                    url = line
            else:
                url = line

            if name and url:
                channels.append({
                    "name":   name,
                    "url":    url,
                    "logo":   logo,
                    "tvg_id": tvgid,
                })

            current_ext   = None
            pending_vavoo = None

    return channels


def move_channel(filename, channel_name, direction):
    """
    Verschiebt einen Sender in der Gruppe um eine Position.
    direction: "up" oder "down"
    Gibt True zurück wenn erfolgreich.
    """
    channels = load_group_channels(filename)
    idx = next((i for i, ch in enumerate(channels) if ch.get("name") == channel_name), -1)
    if idx < 0:
        return False
    if direction == "up" and idx == 0:
        return False
    if direction == "down" and idx == len(channels) - 1:
        return False
    swap = idx - 1 if direction == "up" else idx + 1
    channels[idx], channels[swap] = channels[swap], channels[idx]
    save_group_channels(filename, channels)
    return True


def remove_channel_from_group(filename, channel_name):
    """Entfernt einen Sender aus der Gruppe."""
    channels = load_group_channels(filename)
    new_channels = [ch for ch in channels if ch.get("name") != channel_name]
    if len(new_channels) == len(channels):
        return False
    save_group_channels(filename, new_channels)
    return True


def save_group_channels(filename, channels, epg_url=""):
    """Speichert Kanal-Liste als M3U-Datei."""
    from urllib.parse import quote_plus as _qp

    lines = [f'#EXTM3U url-tvg="{epg_url}"' if epg_url else "#EXTM3U", ""]

    for ch in channels:
        name   = ch.get("name", "")
        url    = ch.get("url", "")
        logo   = ch.get("logo", "")
        tvg_id = ch.get("tvg_id", "")
        if not name or not url:
            continue

        safe = name.replace('"', "'")
        plugin_url = (
            f"plugin://plugin.video.vavoo/"
            f"?action=play&name={_qp(name)}&url={_qp(url)}"
        )

        extinf = (
            f'#EXTINF:-1'
            f' tvg-name="{safe}"'
            f' tvg-id="{tvg_id}"'
            f' tvg-logo="{logo}"'
            f',{safe}'
        )
        lines.append(extinf)
        lines.append(f"##VAVOO-URL:{url}")
        lines.append(plugin_url)
        lines.append("")

    try:
        atomic_write_text(_group_m3u_path(filename), "\n".join(lines))
        return True
    except Exception as exc:
        _logger.error("save_group_channels error: %s" % exc)
        return False



# ---------------------------------------------------------------------------
# Separate Metadaten fuer bevorzugte Quellen und Aktualisierungsstatus.
# Diese Daten werden NICHT in die M3U geschrieben und beeinflussen weder
# tvg-id noch EPG-Zuordnung oder sichtbaren Sendernamen.
# ---------------------------------------------------------------------------

_SOURCE_META_CACHE = {"signature": None, "data": None}


def _source_meta_path():
    return os.path.join(_profile_dir(), "favorite_source_meta.json")


def _source_meta_signature(path):
    try:
        stat = os.stat(path)
        return stat.st_mtime_ns, stat.st_size
    except OSError:
        return None

def _source_meta_key(filename, channel):
    """Stabiler Metadaten-Schlüssel unabhängig von der veränderlichen EPG-ID."""
    name = (channel.get("name") or "").strip()
    return "%s|%s" % (os.path.basename(filename), _sync_name_key(name))


def _migrate_source_meta_keys(data):
    """Überführt alte ``Datei|EPG-ID|Name``-Schlüssel in das stabile Format."""
    if not isinstance(data, dict):
        return {}, False
    migrated = {}
    changed = False
    for raw_key, raw_entry in data.items():
        key = str(raw_key or "")
        parts = key.split("|")
        if len(parts) >= 3:
            new_key = "%s|%s" % (parts[0], parts[-1])
            changed = True
        else:
            new_key = key
        entry = raw_entry if isinstance(raw_entry, dict) else {}
        previous = migrated.get(new_key)
        if not isinstance(previous, dict):
            migrated[new_key] = dict(entry)
            continue
        previous_stamp = str(previous.get("updated_at") or previous.get("last_update") or "")
        entry_stamp = str(entry.get("updated_at") or entry.get("last_update") or "")
        if entry_stamp >= previous_stamp:
            merged = dict(previous)
            merged.update(entry)
        else:
            merged = dict(entry)
            merged.update(previous)
        migrated[new_key] = merged
        changed = True
    return migrated, changed


def load_source_meta():
    """Lädt Quellen-Metadaten mit leichtem Signatur-Cache."""
    try:
        path = _source_meta_path()
        signature = _source_meta_signature(path)
        if signature is None:
            _SOURCE_META_CACHE.update(signature=None, data={})
            return {}
        if (
            _SOURCE_META_CACHE.get("signature") == signature
            and isinstance(_SOURCE_META_CACHE.get("data"), dict)
        ):
            return dict(_SOURCE_META_CACHE["data"])
        with open(path, "r", encoding="utf-8") as handle:
            raw = json.load(handle)
        data, changed = _migrate_source_meta_keys(raw)
        if changed:
            save_source_meta(data)
        else:
            _SOURCE_META_CACHE.update(signature=signature, data=dict(data))
        return dict(data)
    except Exception as exc:
        _logger.warning("source meta load error: %s" % exc)
        return {}


def save_source_meta(data):
    """Speichert Quellen-Metadaten atomar und aktualisiert den RAM-Cache."""
    try:
        path = _source_meta_path()
        atomic_write_json(path, data, indent=2, sort_keys=True)
        _SOURCE_META_CACHE.update(
            signature=_source_meta_signature(path),
            data=dict(data) if isinstance(data, dict) else {},
        )
        return True
    except Exception as exc:
        _logger.warning("source meta save error: %s" % exc)
        return False


def get_source_meta(filename, channel):
    return load_source_meta().get(_source_meta_key(filename, channel), {})


def set_source_meta(filename, channel, **values):
    import time
    data = load_source_meta()
    key = _source_meta_key(filename, channel)
    entry = data.get(key, {}) if isinstance(data.get(key, {}), dict) else {}
    entry.update({k: v for k, v in values.items() if v is not None})
    entry["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    data[key] = entry
    return save_source_meta(data)


def clear_preferred_source(filename, channel):
    """Entfernt nur die bevorzugte Quelle aus den separaten Metadaten.

    Verlauf und letzter Status bleiben erhalten. M3U und EPG-Daten werden
    nicht angefasst.
    """
    data = load_source_meta()
    key = _source_meta_key(filename, channel)
    entry = data.get(key)
    if not isinstance(entry, dict):
        return True
    for field in (
        "preferred_catalog_name", "preferred_url",
        "preferred_country", "preferred_quality"
    ):
        entry.pop(field, None)
    if entry:
        data[key] = entry
    else:
        data.pop(key, None)
    return save_source_meta(data)

# ---------------------------------------------------------------------------
# Favoriten-M3Us mit dem aktuellen Vavoo-Katalog synchronisieren
# ---------------------------------------------------------------------------

from favorites import sync_engine as _sync_engine

# Kompatibilitaetsnamen fuer bestehende Aufrufer. Die eigentliche
# Synchronisationslogik liegt in favorites/sync_engine.py.
_sync_name_key = _sync_engine.sync_name_key
_candidate_score = _sync_engine.candidate_score

def sync_group_channels(filename, live_channels, api_module=None, max_candidates=0, validation_timeout=7,
                        validate_streams=True, defective_only=False,
                        progress_callback=None, group_index=1, group_total=1,
                        global_offset=0, global_total=0, only_index=None):
    return _sync_engine.sync_group_channels(
        filename, live_channels, api_module=api_module,
        max_candidates=max_candidates, validation_timeout=validation_timeout,
        validate_streams=validate_streams, defective_only=defective_only,
        progress_callback=progress_callback, group_index=group_index,
        group_total=group_total, global_offset=global_offset,
        global_total=global_total, only_index=only_index,
        load_group_channels=load_group_channels,
        load_source_meta=load_source_meta,
        source_meta_key=_source_meta_key,
        save_source_meta=save_source_meta,
        profile_dir=_profile_dir,
        group_m3u_path=_group_m3u_path,
        save_group_channels=save_group_channels,
    )

# ---------------------------------------------------------------------------
# EPG-ID Matching gegen guide.xml
# ---------------------------------------------------------------------------

def _match_epg_id(channel_name, epg_cache):
    """Nur eindeutige EPG-Treffer; keine Teilstring-Verwechslungen."""
    if not epg_cache:
        return ""
    from vavoo_api import get_channel_epg_id
    expected = get_channel_epg_id(channel_name)
    if expected:
        for epg_id in epg_cache:
            if epg_id.casefold() == expected.casefold():
                return epg_id
    # Ohne verifizierte ID nur einen exakten, eindeutigen Namensvergleich.
    def norm(value):
        value = re.sub(r"\.(de|at|ch)$", "", value.lower().strip())
        value = re.sub(r"(?:uhd|fhd|hd)$", "", value)
        return re.sub(r"[^a-z0-9]", "", value)
    wanted = norm(channel_name)
    matches = [key for key in epg_cache if norm(key) == wanted]
    return matches[0] if len(matches) == 1 else ""

# ---------------------------------------------------------------------------
# Gruppen-Verwaltung (UI-Aktionen)
# ---------------------------------------------------------------------------

from favorites import groups as _groups_actions


def group_create(addon_name):
    """Kompatibilitaets-Wrapper fuer das Erstellen einer Gruppe."""
    return _groups_actions.create_group(
        addon_name,
        load_groups=load_groups,
        save_groups=save_groups,
        make_filename=_make_filename,
        save_group_channels=save_group_channels,
        init_group_icon=_init_group_icon,
    )


def group_set_icon(addon_name, group_file, loop=False):
    """Eigenes Icon fuer eine Favoritengruppe setzen."""
    import shutil as _sh

    any_set = False
    current_file = group_file
    while True:
        png_path = xbmcgui.Dialog().browse(
            1, "Icon auswählen (PNG)", "files", ".png", False, False, ""
        )
        if not png_path or not png_path.lower().endswith(".png"):
            break

        dest = os.path.join(_user_icons_dir(), _stem(current_file) + ".png")
        try:
            if not xbmcvfs.copy(png_path, dest):
                _sh.copy2(png_path, dest)
            any_set = True
            xbmcgui.Dialog().notification(
                addon_name, "Icon gesetzt", xbmcgui.NOTIFICATION_INFO, 1500
            )
        except Exception as exc:
            xbmcgui.Dialog().notification(
                addon_name, "Fehler: {}".format(exc), xbmcgui.NOTIFICATION_ERROR, 3000
            )
            break

        if not xbmcgui.Dialog().yesno(
            addon_name,
            "Möchten Sie weitere Icons anpassen?",
            nolabel="Nein",
            yeslabel="Ja",
        ):
            break

        groups = load_groups()
        idx = xbmcgui.Dialog().select("Gruppe auswählen:", [g["name"] for g in groups])
        if idx < 0:
            break
        current_file = groups[idx]["file"]

    if any_set and xbmcgui.Dialog().yesno(
        addon_name,
        "Thumbnail-Cache wird geleert. Icons erscheinen nach einem Kodi-Neustart. Jetzt neu starten?",
        nolabel="Später",
        yeslabel="Jetzt neu starten",
    ):
        xbmc.executebuiltin("RestartApp")

    return any_set


def group_rename(addon_name, group_file="", group_name=""):
    """Kompatibilitaets-Wrapper fuer das Umbenennen einer Gruppe."""
    return _groups_actions.rename_group(
        addon_name,
        group_file,
        group_name,
        load_groups=load_groups,
        save_groups=save_groups,
    )


def group_remove(addon_name, group_file="", group_name=""):
    """Kompatibilitaets-Wrapper fuer das Entfernen einer Gruppe."""
    return _groups_actions.remove_group(
        addon_name,
        group_file,
        group_name,
        load_groups=load_groups,
        save_groups=save_groups,
        group_m3u_path=_group_m3u_path,
        delete_group_icon=_delete_group_icon,
    )


def group_move(addon_name, group_file, direction):
    """Kompatibilitaets-Wrapper fuer das Verschieben einer Gruppe."""
    return _groups_actions.move_group(
        group_file,
        direction,
        load_groups=load_groups,
        save_groups=save_groups,
    )


# ---------------------------------------------------------------------------
# Sender-Verwaltung
# ---------------------------------------------------------------------------

from favorites import channel_actions as _channel_actions


def channel_add_single(addon_name, group_file, channel_name, channel_url,
                       channel_logo="", epg_cache=None):
    """Kompatibilitaets-Wrapper: einzelnen Sender hinzufuegen."""
    return _channel_actions.add_single(
        addon_name,
        group_file,
        channel_name,
        channel_url,
        channel_logo,
        epg_cache,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        match_epg_id=_match_epg_id,
        addon=ADDON,
    )


def channel_add_to_group_dialog(addon_name, channel_name, channel_url,
                                channel_logo="", epg_cache=None):
    """Kompatibilitaets-Wrapper: Zielgruppe auswaehlen."""
    return _channel_actions.add_to_group_dialog(
        addon_name,
        channel_name,
        channel_url,
        channel_logo,
        epg_cache,
        load_groups=load_groups,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        match_epg_id=_match_epg_id,
        addon=ADDON,
    )


def channel_add_multi(addon_name, group_file, group_name, epg_cache=None):
    """Kompatibilitaets-Wrapper: mehrere Sender auswaehlen."""
    return _channel_actions.add_multi(
        addon_name,
        group_file,
        group_name,
        epg_cache,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        match_epg_id=_match_epg_id,
        addon=ADDON,
    )


def channel_rename(addon_name, group_file, channel_idx):
    """Kompatibilitaets-Wrapper: Sender umbenennen."""
    return _channel_actions.rename(
        addon_name,
        group_file,
        channel_idx,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        addon=ADDON,
    )


def channel_remove(addon_name, group_file, channel_idx):
    """Kompatibilitaets-Wrapper: Sender entfernen."""
    return _channel_actions.remove(
        addon_name,
        group_file,
        channel_idx,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        addon=ADDON,
    )


def channel_move(group_file, channel_idx, direction):
    """Kompatibilitaets-Wrapper: Sender innerhalb der Gruppe verschieben."""
    return _channel_actions.move(
        group_file,
        channel_idx,
        direction,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        addon=ADDON,
    )


def channel_move_to_group(addon_name, src_file, channel_idx, epg_cache=None):
    """Kompatibilitaets-Wrapper: Sender in eine andere Gruppe verschieben."""
    return _channel_actions.move_to_group(
        addon_name,
        src_file,
        channel_idx,
        epg_cache,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        load_groups=load_groups,
        match_epg_id=_match_epg_id,
        addon=ADDON,
    )


# ---------------------------------------------------------------------------
# Import / Export
# ---------------------------------------------------------------------------

from favorites import import_export as _import_export


def backup_all_groups(addon_name):
    """Kompatibilitäts-Wrapper: alle Favoritengruppen sichern."""
    return _import_export.backup_all_groups(
        addon_name,
        load_groups=load_groups,
        groups_json_path=_groups_json_path,
        group_m3u_path=_group_m3u_path,
        backup_zip_path=_backup_zip_path,
    )


def _parse_m3u_channels(text):
    """Kompatibilitäts-Wrapper für den M3U-Parser."""
    return _import_export.parse_m3u_channels(text)


def sync_bundled_m3u():
    """Übernimmt neue Listen und ersetzt ausschließlich leere Platzhalter."""
    return _import_export.sync_bundled_m3u(
        favgroups_dir=_favgroups_dir,
        addon_favgroups_dir=_addon_favgroups_dir,
    )


def update_standard_groups(addon_name):
    """Prüft die mitgelieferten Standardgruppen und zeigt einen Bericht."""
    return _import_export.update_standard_groups(
        addon_name,
        favgroups_dir=_favgroups_dir,
        addon_favgroups_dir=_addon_favgroups_dir,
    )


def _scan_unregistered_m3u():
    """Kompatibilitäts-Wrapper für den Ordnerscan."""
    return _import_export.scan_unregistered_m3u(
        favgroups_dir=_favgroups_dir,
        load_groups=load_groups,
        addon_favgroups_dir=_addon_favgroups_dir,
    )


def register_unregistered_m3u(addon_name):
    """Kompatibilitäts-Wrapper: externe M3U-Dateien registrieren."""
    return _import_export.register_unregistered_m3u(
        addon_name,
        favgroups_dir=_favgroups_dir,
        load_groups=load_groups,
        save_groups=save_groups,
        init_group_icon=_init_group_icon,
        addon_favgroups_dir=_addon_favgroups_dir,
    )


def _vfs_read_text(file_path):
    """Kompatibilitäts-Wrapper für Kodi-VFS-Lesezugriffe."""
    return _import_export.vfs_read_text(file_path)


def _normalize_folder(folder):
    """Kompatibilitäts-Wrapper für Ordnerpfade."""
    return _import_export.normalize_folder(folder)


def import_m3u_multi(addon_name, epg_cache=None):
    """Kompatibilitäts-Wrapper: mehrere M3U-Dateien importieren."""
    return _import_export.import_m3u_multi(
        addon_name,
        epg_cache,
        addon=ADDON,
        load_groups=load_groups,
        save_groups=save_groups,
        make_filename=_make_filename,
        save_group_channels=save_group_channels,
        init_group_icon=_init_group_icon,
    )


def import_m3u_from_file(addon_name, epg_cache=None, target_group_file=""):
    """Kompatibilitäts-Wrapper: einzelne M3U-Datei importieren."""
    return _import_export.import_m3u_from_file(
        addon_name,
        epg_cache,
        addon=ADDON,
        load_groups=load_groups,
        save_groups=save_groups,
        make_filename=_make_filename,
        save_group_channels=save_group_channels,
        load_group_channels=load_group_channels,
        init_group_icon=_init_group_icon,
        group_m3u_path=_group_m3u_path,
        match_epg_id=_match_epg_id,
        target_group_file=target_group_file,
    )


def _merge_channels_into_group(addon_name, group_file, new_channels, epg_cache=None):
    """Kompatibilitäts-Wrapper: Sender in eine Gruppe übernehmen."""
    return _import_export.merge_channels_into_group(
        addon_name,
        group_file,
        new_channels,
        epg_cache,
        addon=ADDON,
        load_group_channels=load_group_channels,
        save_group_channels=save_group_channels,
        match_epg_id=_match_epg_id,
    )


def scan_and_notify(addon_name):
    """Kompatibilitäts-Wrapper: neue M3U-Dateien melden."""
    return _import_export.scan_and_notify(
        addon_name,
        favgroups_dir=_favgroups_dir,
        load_groups=load_groups,
        addon_favgroups_dir=_addon_favgroups_dir,
    )


def m3u_scan_signature():
    """Signatur aller relevanten M3U-Dateien für die Änderungserkennung."""
    return _import_export.m3u_scan_signature(
        favgroups_dir=_favgroups_dir,
        addon_favgroups_dir=_addon_favgroups_dir,
    )
