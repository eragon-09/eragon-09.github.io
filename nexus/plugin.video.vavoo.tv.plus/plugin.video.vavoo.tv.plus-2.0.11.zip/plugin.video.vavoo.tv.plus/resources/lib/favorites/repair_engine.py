# -*- coding: utf-8 -*-
"""Reparatur- und Aktualisierungsabläufe für Favoritensender.

Dieses Modul enthält die Kodi-Dialog- und Kataloglogik für komplette
Favoritengruppen, einzelne Sender und die manuelle Quellenauswahl. Die
M3U-Synchronisation selbst bleibt in :mod:`favorites.sync_engine`.
"""

import os
import shutil
import time

import xbmc
import xbmcgui


def sync_favorite_groups(group_file="", force_reload=True, mode="quick", *,
                         addon_name, api_module, group_favs,
                         get_active_countries, append_internal_log):
    """Synchronisiert oder repariert Favoriten-M3Us.

    ``mode="quick"`` aktualisiert technische Daten ohne Streamtests.
    ``mode="repair"`` prüft alle Favoriten mit Streamtest und Fallback.
    ``mode="defects"`` prüft und repariert nur defekte bestehende Streams.
    """
    all_countries = api_module.get_available_countries()
    countries = get_active_countries(all_countries)

    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, "Aktueller Senderkatalog wird geladen ...")

    live_channels = {}
    try:
        for country_pos, country in enumerate(countries, 1):
            if progress.iscanceled():
                progress.close()
                return False
            pct = int(((country_pos - 1) / max(len(countries), 1)) * 10)
            progress.update(pct, f"Senderliste {country_pos} von {len(countries)}\n{country}")
            current = _repair_catalog(api_module, country, force_reload)
            for name, urls in current.items():
                live_channels.setdefault(name, [])
                for url in (urls if isinstance(urls, list) else [urls]):
                    if not url:
                        continue
                    item = {
                        "url": url,
                        "country": str(country),
                        "quality": "",
                    }
                    if not any(existing.get("url") == url for existing in live_channels[name] if isinstance(existing, dict)):
                        live_channels[name].append(item)

        if not live_channels:
            progress.close()
            xbmcgui.Dialog().ok(
                addon_name,
                "Aktualisierung nicht möglich: Kein aktueller Senderkatalog geladen.",
            )
            return False

        groups = group_favs.load_groups()
        if group_file:
            groups = [g for g in groups if g.get("file") == group_file]
        if not groups:
            progress.close()
            return False

        group_counts = []
        for group in groups:
            try:
                group_counts.append(len(group_favs.load_group_channels(group["file"])))
            except Exception:
                group_counts.append(0)
        total_senders = sum(group_counts)
        completed_before = 0
        canceled = False

        totals = {
            "total": 0,
            "updated": 0,
            "unchanged": 0,
            "missing": 0,
            "fallbacks": 0,
            "unreachable": 0,
            "errors": 0,
        }

        def update_progress(info):
            if progress.iscanceled():
                return False
            global_index = max(1, int(info.get("global_index", 1)))
            global_total = max(1, int(info.get("global_total", total_senders or 1)))
            pct = 10 + int(((global_index - 1) / global_total) * 89)
            group_idx = info.get("group_index", 1)
            group_total = info.get("group_total", len(groups))
            channel_idx = info.get("channel_index", 1)
            channel_total = info.get("channel_total", 1)
            name = info.get("channel_name", "") or "Unbekannter Sender"
            line1 = f"Favoritenliste {group_idx} von {group_total}"
            line2 = f"Sender {channel_idx} von {channel_total}: {name}"
            if info.get("phase") == "candidate" and info.get("candidate_total", 0):
                line2 += (
                    f"  |  Quelle {info.get('candidate_index', 1)} von "
                    f"{info.get('candidate_total', 1)}"
                )
            progress.update(min(pct, 99), f"{line1}\n{line2}")
            return not progress.iscanceled()

        for group_pos, group in enumerate(groups, 1):
            if progress.iscanceled():
                canceled = True
                break
            stats = group_favs.sync_group_channels(
                group["file"], live_channels, api_module,
                max_candidates=0 if mode == "quick" else 3,
                validation_timeout=4 if mode == "defects" else 7,
                validate_streams=(mode != "quick"),
                defective_only=(mode == "defects"),
                progress_callback=update_progress,
                group_index=group_pos,
                group_total=len(groups),
                global_offset=completed_before,
                global_total=total_senders,
            )
            if stats.get("canceled"):
                canceled = True
                break
            completed_before += group_counts[group_pos - 1]
            for key in (
                "total", "updated", "unchanged", "missing", "fallbacks", "unreachable"
            ):
                totals[key] += stats.get(key, 0)
            if stats.get("error"):
                totals["errors"] += 1

        if canceled:
            progress.close()
            xbmcgui.Dialog().notification(
                addon_name,
                "Aktualisierung abgebrochen – aktuelle Gruppe nicht gespeichert",
                xbmcgui.NOTIFICATION_WARNING,
                3500,
            )
            return False

        progress.update(
            100,
            f"Favoritenaktualisierung abgeschlossen\n{total_senders} Sender verarbeitet",
        )
    finally:
        try:
            progress.close()
        except Exception:
            pass

    summary_title = (
        "Schnelle Aktualisierung abgeschlossen.\n\n" if mode == "quick" else
        "Defekte Sender geprüft und repariert.\n\n" if mode == "defects" else
        "Favoriten geprüft und repariert.\n\n"
    )
    append_internal_log(
        f"Favoriten-Sync ({mode}) abgeschlossen: {totals['total']} Sender, "
        f"{totals['updated']} geändert, {totals['fallbacks']} Fallbacks"
    )
    xbmcgui.Dialog().ok(
        addon_name,
        summary_title
        + f"Sender insgesamt: {totals['total']}\n"
        + f"Geändert: {totals['updated']}\n"
        + f"Bereits aktuell: {totals['unchanged']}\n"
        + f"Nicht gefunden (beibehalten): {totals['missing']}\n"
        + f"Fallback verwendet: {totals['fallbacks']}\n"
        + f"Kein erreichbarer Stream (beibehalten): {totals['unreachable']}\n"
        + f"Fehler/Zurückgesetzt: {totals['errors']}\n\n"
        + "Gruppen- und Senderreihenfolge bleiben unverändert.",
    )
    return True


def sync_single_favorite(group_file, channel_index, mode="quick", *,
                         addon_name, api_module, group_favs,
                         get_active_countries):
    """Aktualisiert genau einen Favoritensender ohne Positionsänderung."""
    try:
        channel_index = int(channel_index)
    except (TypeError, ValueError):
        return False

    channels = group_favs.load_group_channels(group_file)
    if channel_index < 0 or channel_index >= len(channels):
        xbmcgui.Dialog().ok(addon_name, "Sender konnte nicht gefunden werden.")
        return False
    channel_name = channels[channel_index].get("name", "Unbekannter Sender")

    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, f"Sender wird vorbereitet ...\n{channel_name}")
    live_channels = {}
    stats = {}
    try:
        countries = get_active_countries(api_module.get_available_countries())
        for pos, country in enumerate(countries, 1):
            if progress.iscanceled():
                return False
            pct = int(((pos - 1) / max(len(countries), 1)) * 30)
            progress.update(pct, f"Senderliste {pos} von {len(countries)}\n{country}")
            current = _repair_catalog(api_module, country, True)
            for name, urls in current.items():
                live_channels.setdefault(name, [])
                for url in (urls if isinstance(urls, list) else [urls]):
                    if not url:
                        continue
                    item = {
                        "url": url,
                        "country": str(country),
                        "quality": "",
                    }
                    if not any(existing.get("url") == url for existing in live_channels[name] if isinstance(existing, dict)):
                        live_channels[name].append(item)

        def one_progress(info):
            if progress.iscanceled():
                return False
            msg = f"Sender: {channel_name}"
            if info.get("phase") == "candidate" and info.get("candidate_total", 0):
                msg += (
                    f"\nQuelle {info.get('candidate_index', 1)} von "
                    f"{info.get('candidate_total', 1)} wird geprüft"
                )
            else:
                msg += "\nAktuelle Daten werden gesucht"
            progress.update(60 if mode == "quick" else 70, msg)
            return not progress.iscanceled()

        stats = group_favs.sync_group_channels(
            group_file, live_channels, api_module,
            max_candidates=0 if mode == "quick" else 3,
            validation_timeout=7,
            validate_streams=(mode != "quick"),
            defective_only=False,
            progress_callback=one_progress,
            global_total=1,
            only_index=channel_index,
        )
        if stats.get("canceled") or progress.iscanceled():
            return False
        progress.update(100, f"Sender abgeschlossen\n{channel_name}")
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if stats.get("updated"):
        message = "Sender wurde aktualisiert."
        if stats.get("fallbacks"):
            message += "\nEine alternative Quelle wurde verwendet."
    elif stats.get("missing"):
        message = (
            "Kein passender Sender im aktuellen Katalog gefunden.\n"
            "Der bisherige Eintrag bleibt erhalten."
        )
    elif stats.get("unreachable"):
        message = (
            "Keine funktionierende Ersatzquelle gefunden.\n"
            "Der bisherige Eintrag bleibt erhalten."
        )
    else:
        message = "Der Sender ist bereits aktuell."
    xbmcgui.Dialog().ok(addon_name, f"{channel_name}\n\n{message}")
    return True


def manual_select_single_favorite(group_file, channel_index, *, addon_name,
                                  api_module, group_favs,
                                  get_active_countries, append_internal_log):
    """Lässt den Benutzer einen Katalogtreffer für einen Favoriten wählen."""
    try:
        channel_index = int(channel_index)
    except (TypeError, ValueError):
        return False

    channels = group_favs.load_group_channels(group_file)
    if channel_index < 0 or channel_index >= len(channels):
        xbmcgui.Dialog().ok(addon_name, "Sender konnte nicht gefunden werden.")
        return False

    current = channels[channel_index]
    channel_name = current.get("name", "Unbekannter Sender")
    current_epg = (current.get("tvg_id") or "").strip().lower()
    name_key = group_favs._sync_name_key(channel_name)

    progress = xbmcgui.DialogProgress()
    progress.create(addon_name, f"Passende Sender werden gesucht ...\n{channel_name}")
    candidates = []
    seen = set()
    try:
        countries = get_active_countries(api_module.get_available_countries())
        for pos, country in enumerate(countries, 1):
            if progress.iscanceled():
                return False
            pct = int((pos / max(len(countries), 1)) * 100)
            progress.update(pct, f"Senderliste {pos} von {len(countries)}\n{country}")
            catalog = _repair_catalog(api_module, country, True)
            for live_name, urls in catalog.items():
                try:
                    live_epg = api_module.get_channel_epg_id(live_name) or ""
                except Exception:
                    live_epg = ""
                if not name_key or group_favs._sync_name_key(live_name) != name_key:
                    continue
                try:
                    logo = api_module.get_channel_logo(live_name) or current.get("logo", "")
                except Exception:
                    logo = current.get("logo", "")
                for url in (urls if isinstance(urls, list) else [urls]):
                    url = (url or "").strip()
                    marker = (live_name, url)
                    if not url or marker in seen:
                        continue
                    seen.add(marker)
                    lower = live_name.lower()
                    quality = (
                        "UHD/4K" if ("uhd" in lower or "4k" in lower) else
                        "FHD" if ("fhd" in lower or "full hd" in lower) else
                        "HD" if (" hd" in " " + lower or lower.endswith("hd")) else
                        "SD"
                    )
                    candidates.append({
                        "name": live_name,
                        "url": url,
                        "country": str(country),
                        "tvg_id": live_epg,
                        "logo": logo,
                        "quality": quality,
                    })
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if not candidates:
        xbmcgui.Dialog().ok(
            addon_name,
            f"{channel_name}\n\nKeine passenden Sender im aktuellen Katalog gefunden.",
        )
        return False

    candidates.sort(
        key=lambda entry: (
            group_favs._candidate_score(entry.get("name", ""), channel_name),
            entry.get("country", ""),
            entry.get("name", ""),
        ),
        reverse=True,
    )
    labels = ["Bisherigen Eintrag unverändert lassen"]
    for entry in candidates:
        epg = entry.get("tvg_id") or "keine EPG-ID"
        labels.append(
            f"{entry.get('name', '')}  |  {entry.get('country', '')}  |  "
            f"{entry.get('quality', 'SD')}  |  {epg}"
        )

    choice = xbmcgui.Dialog().select(
        f"Sender auswählen: {channel_name}", labels, preselect=0
    )
    if choice <= 0:
        return False

    selected = candidates[choice - 1]
    confirm = xbmcgui.Dialog().yesno(
        addon_name,
        f"Diesen Sender setzen?\n\n"
        f"Favorit: {channel_name}\n"
        f"Auswahl: {selected.get('name', '')}\n"
        f"Land: {selected.get('country', '')}\n"
        f"Qualität: {selected.get('quality', '')}\n"
        f"EPG-ID: {selected.get('tvg_id') or '-'}",
    )
    if not confirm:
        return False

    backup = ""
    try:
        backup_dir = os.path.join(group_favs._profile_dir(), "sync_backups")
        os.makedirs(backup_dir, exist_ok=True)
        src = group_favs._group_m3u_path(group_file)
        stem, ext = os.path.splitext(os.path.basename(group_file))
        backup = os.path.join(
            backup_dir,
            f"{stem}_{time.strftime('%Y%m%d-%H%M%S')}{ext or '.m3u'}",
        )
        shutil.copy2(src, backup)
    except Exception as exc:
        xbmc.log(
            f"[VavooTV] manual selection backup error: {exc}",
            xbmc.LOGWARNING,
        )

    current["url"] = selected.get("url", current.get("url", ""))
    current["logo"] = selected.get("logo", current.get("logo", ""))
    current["tvg_id"] = selected.get("tvg_id", current.get("tvg_id", ""))
    if not group_favs.save_group_channels(group_file, channels):
        if backup:
            try:
                shutil.copy2(backup, group_favs._group_m3u_path(group_file))
            except Exception:
                pass
        xbmcgui.Dialog().ok(addon_name, "Der Sender konnte nicht gespeichert werden.")
        return False

    group_favs.set_source_meta(
        group_file,
        current,
        preferred_catalog_name=selected.get("name", ""),
        preferred_url=selected.get("url", ""),
        preferred_country=selected.get("country", ""),
        preferred_quality=selected.get("quality", ""),
        last_catalog_name=selected.get("name", ""),
        last_url=selected.get("url", ""),
        last_country=selected.get("country", ""),
        last_quality=selected.get("quality", ""),
        last_update=time.strftime("%Y-%m-%d %H:%M:%S"),
        last_status="manuell gewählt",
    )

    append_internal_log(
        f"Quelle manuell gesetzt: {channel_name} -> {selected.get('name', '')} "
        f"({selected.get('country', '')}, {selected.get('quality', '')})"
    )
    xbmcgui.Dialog().ok(
        addon_name,
        f"{channel_name}\n\nGesetzt wurde:\n{selected.get('name', '')}\n"
        f"{selected.get('country', '')} | {selected.get('quality', '')}",
    )
    return True


def _repair_catalog(api_module, country, force):
    catalog = api_module.fetch_channels_for_group(country, force=force) or {}
    if country != "Germany":
        return catalog
    import json
    from pathlib import Path
    from favorites.sync_engine import sync_name_key
    try:
        rows = json.loads((Path(__file__).resolve().parents[2] / "favgroups" / "geil_sources.json").read_text(encoding="utf-8"))
        result = dict(catalog)
        identities = {sync_name_key(n) for n in catalog}
        for name, url in rows:
            if sync_name_key(name) not in identities:
                result.setdefault(name, []).append(url)
        return result
    except (OSError, ValueError):
        return catalog
