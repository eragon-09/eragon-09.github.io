# -*- coding: utf-8 -*-
"""Action router for Vavoo TV Plus.

This module contains routing only. Runtime functions are injected by addon.py,
while feature implementations are progressively maintained in dedicated modules.
"""


def configure(namespace):
    """Inject the add-on runtime namespace without importing addon.py recursively."""
    for name, value in namespace.items():
        if not name.startswith("__"):
            globals()[name] = value


def route(params):
    action = params.get("action", "")

    if not action:
        main_menu()

    elif action == "live_tv":
        live_tv_menu()
    elif action == "grp_back":
        xbmc.executebuiltin("Action(ParentDir)")
    elif action == "favorites_manager":
        favorites_manager_menu()
    elif action == "favorites_help":
        favorites_help()
    elif action == "favorites_backups":
        favorites_backup_menu()
    elif action == "favorites_backup_info":
        favorites_backup_info()
    elif action == "favorites_backup_create":
        favorites_backup_create()
    elif action == "favorites_backup_restore":
        favorites_backup_restore()
    elif action == "favorites_source_manager":
        favorites_source_manager()
    elif action == "favorites_channel_info":
        favorites_channel_info()
    elif action == "favorites_maintenance":
        favorites_maintenance_menu()
    elif action == "favorites_maintenance_scan":
        favorites_maintenance_scan()
    elif action == "favorites_maintenance_report":
        favorites_show_last_report()
    elif action == "favorites_activity_log":
        favorites_show_activity_log()
    elif action == "favorites_activity_log_clear":
        favorites_clear_activity_log()
    elif action == "movies_index":
        movies_index()
    elif action == "series_index":
        series_index()
    elif action == "settings_menu":
        settings_menu()
    elif action == "release_information":
        show_release_information()
    elif action == "settings":
        ADDON.openSettings()
        xbmc.executebuiltin("Container.Refresh")

    elif action == "country_select":
        country_select()
    elif action == "config_menu":
        config_menu()
    elif action == "config_epg_url":
        config_epg_url()
    elif action == "do_load_epg":
        do_load_epg()
    elif action == "do_refresh_countries":
        do_refresh_countries()
    elif action == "do_refresh_channels":
        do_refresh_channels()

    elif action == "favorites_epg":
        show_favorites_epg(params)
    elif action == "live_favorites":
        live_favorites()
    elif action == "live_countries":
        live_countries(params.get("countries", ""))
    elif action == "live_genres":
        live_genres(params.get("countries", ""))
    elif action == "live_az":
        live_az(params.get("countries", ""))

    elif action == "channels":
        show_channels(params.get("group", "Germany"))
    elif action == "channels_flat":
        group    = params.get("group", "Germany")
        channels = api.fetch_channels_for_group(group)
        if channels:
            _render_channel_list(channels)
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, f"Keine Kanäle für '{group}'.")
    elif action == "az_channels":
        letter        = params.get("letter", "")
        countries_param = params.get("countries", "")
        all_countries = api.get_available_countries()
        countries     = _parse_countries_param(countries_param, all_countries)
        all_channels  = {}
        for country in countries:
            all_channels.update(api.fetch_channels_for_group(country))
        bucket = {n: u for n, u in all_channels.items()
                  if (n[0].upper() if n else "#") == letter}
        if bucket:
            _render_channel_list(bucket)
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, f"Keine Kanäle unter '{letter}'.")
    elif action == "genre_channels":
        show_genre_channels(params.get("genre", ""), params.get("countries", "Germany"))
    elif action == "play":
        play_channel(params.get("url", ""), params.get("name", ""), params.get("tvg_id", ""), params.get("logo", ""))
    elif action == "play_item":
        play_channel_resolved(params.get("url", ""), params.get("name", ""), params.get("tvg_id", ""), params.get("logo", ""))

    elif action == "fav_add_multi":
        _favorites_add_multiselect()
    elif action == "fav_add_marker":
        _favorites_add_marker()
    elif action == "fav_add":
        name = params.get("name", "")
        url  = params.get("url", "")
        if name and url:
            added = _fav_add(name, url)
            msg   = f"Hinzugefuegt: {name}" if added else f"Bereits vorhanden: {name}"
            xbmcgui.Dialog().notification(ADDON_NAME, msg,
                                          xbmcgui.NOTIFICATION_INFO, 2000)
    elif action == "fav_remove":
        _fav_remove(params.get("idx", -1))
        xbmc.executebuiltin("Container.Refresh")
    elif action == "fav_move":
        _fav_move(params.get("idx", -1), params.get("direction", "up"))
        xbmc.executebuiltin("Container.Refresh")

    elif action == "grp_play":
        grp_play(params.get("file", ""), params.get("gname", ""))
    elif action == "grp_show":
        grp_show(params.get("file", ""), params.get("gname", ""))
    elif action == "grp_search":
        grp_search(params.get("file", ""), params.get("gname", ""))
    elif action == "grp_export_m3u":
        export_favorite_group_m3u(params.get("file", ""), params.get("gname", ""))
    elif action == "grp_create":
        if gf.group_create(ADDON_NAME):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_set_icon":
        if gf.group_set_icon(ADDON_NAME, params.get("file", "")):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_rename":
        file  = params.get("file", "")
        gname = params.get("gname", "")
        if gf.group_rename(ADDON_NAME, file, gname):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_remove":
        file  = params.get("file", "")
        gname = params.get("gname", "")
        if gf.group_remove(ADDON_NAME, file, gname):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_move":
        if gf.group_move(ADDON_NAME, params.get("file", ""), params.get("direction", "up")):
            xbmc.executebuiltin("Container.Refresh")
    elif action.startswith("ctx_"):
        context_actions(params)
    elif action == "grp_sync_quick":
        if _sync_favorite_groups(params.get("file", ""), mode="quick"):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_sync_repair":
        if _sync_favorite_groups(params.get("file", ""), mode="repair"):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_sync_defects":
        if _sync_favorite_groups(params.get("file", ""), mode="defects"):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_sync_all_quick":
        if _sync_favorite_groups("", mode="quick"):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_sync_all_repair":
        if _sync_favorite_groups("", mode="repair"):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_sync_all_defects":
        if _sync_favorite_groups("", mode="defects"):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_update_standard_groups":
        if gf.update_standard_groups(ADDON_NAME):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_backup":
        gf.backup_all_groups(ADDON_NAME)
    elif action == "grp_import_m3u":
        epg_cache = api._epg_cache if hasattr(api, "_epg_cache") else {}
        if gf.import_m3u_from_file(ADDON_NAME, epg_cache, target_group_file=params.get("file", "")):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_import_m3u_multi":
        epg_cache = api._epg_cache if hasattr(api, "_epg_cache") else {}
        if gf.import_m3u_multi(ADDON_NAME, epg_cache):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_scan_m3u":
        if gf.register_unregistered_m3u(ADDON_NAME):
            xbmc.executebuiltin("Container.Refresh")
    elif action in ("grp_add_multi", "grp_catalog_picker", "grp_catalog_search"):
        grp_catalog_picker(params.get("file", ""), params.get("gname", ""),
                           params.get("country", ""), params.get("q", ""),
                           ask=action == "grp_catalog_search")
    elif action == "grp_catalog_toggle":
        grp_catalog_toggle(params.get("file", ""), params.get("name", ""), params.get("url", ""))
    elif action == "grp_ch_add":
        name = params.get("name", "")
        url  = params.get("url", "")
        if name and url:
            epg_cache = api._epg_cache if hasattr(api, "_epg_cache") else {}
            gf.channel_add_to_group_dialog(ADDON_NAME, name, url, "", epg_cache)
    elif action == "grp_ch_sync_quick":
        if _sync_single_favorite(params.get("file", ""), params.get("idx", -1), mode="quick"):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_ch_sync_repair":
        if _sync_single_favorite(params.get("file", ""), params.get("idx", -1), mode="repair"):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_ch_select_manual":
        if _manual_select_single_favorite(params.get("file", ""), params.get("idx", -1)):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_ch_source_info":
        _show_single_favorite_source_info(params.get("file", ""), params.get("idx", -1))
    elif action == "grp_ch_rename":
        if gf.channel_rename(ADDON_NAME, params.get("file", ""), params.get("idx", -1)):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_ch_remove":
        if gf.channel_remove(ADDON_NAME, params.get("file", ""), params.get("idx", -1)):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_ch_move":
        if gf.channel_move(params.get("file", ""), params.get("idx", -1),
                           params.get("direction", "up")):
            xbmc.executebuiltin("Container.Refresh")
    elif action == "grp_ch_move_to":
        epg_cache = api._epg_cache if hasattr(api, "_epg_cache") else {}
        if gf.channel_move_to_group(ADDON_NAME, params.get("file", ""),
                                    params.get("idx", -1), epg_cache):
            xbmc.executebuiltin("Container.Refresh")

    elif action == "vod_collections":
        collections_index()
    elif action == "vod_collections_search":
        collections_index(True)
    elif action == "vod_collection":
        show_collection(params)
    elif action == "comfort_menu":
        comfort_menu(params.get("mode","continue"))
    elif action == "comfort_change":
        comfort.change(params)
    elif action == "vod_list":
        show_vod_list(params.get("id", "movie.popular"), params.get("cursor"))
    elif action == "vod_seasons":
        show_vod_seasons(params.get("id", ""), params.get("n", ""), params.get("tmdb", ""))
    elif action == "vod_episodes":
        show_vod_episodes(params.get("id", ""), params.get("n", ""), params.get("tmdb", ""),
                          params.get("s", 1), params.get("ecount", 10))
    elif action == "vod_genres":
        show_vod_genres(params.get("id", "movie.popular"))
    elif action == "vod_search":
        vod_search(params.get("id", "movie.popular"))
    elif action == "play_vod":
        play_vod(params.get("id", ""), params.get("n", ""), params.get("tmdb", ""),
                 params.get("s"), params.get("e"), params.get("ep_id", ""), params.get("poster", ""), params.get("plot", ""), params.get("auto")=="1", params.get("restart")=="1", params.get("ep_name", ""))

    elif action == "run_wizard":
        action_run_wizard()
    elif action == "export_m3u":
        export_m3u(params.get("group", ""))
    elif action == "export_favorites_m3u":
        export_favorites_m3u()
    elif action == "reload_logo_m3u":
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Logo-M3U wird neu geladen …")
        api.build_m3u_logo_index(force=True)
        progress.close()
        xbmcgui.Dialog().notification(ADDON_NAME, "Logo-M3U neu geladen",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
    elif action == "refresh_countries":
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Aktualisiere Länderliste …")
        api.get_available_countries(force=True)
        progress.close()
        xbmc.executebuiltin("Container.Refresh")
    elif action == "refresh_channels":
        group = params.get("group", "")
        if group:
            progress = xbmcgui.DialogProgress()
            progress.create(ADDON_NAME, f"Aktualisiere {group} …")
            api.fetch_channels_for_group(group, force=True)
            progress.close()
        xbmc.executebuiltin("Container.Refresh")

    else:
        api.log(f"Unbekannte Action: {action}", xbmc.LOGWARNING)
        main_menu()

