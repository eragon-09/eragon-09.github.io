#!/usr/bin/env python3
import xbmcaddon, xbmcgui
from lib.sxmanager_addon import sxmanagerService
from lib.sxcheck_gui import show_domain_check
from lib.sxstatus_gui import show_domain_status

class sxmanagerGUI(xbmcgui.WindowXMLDialog):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw)
        self.addon=xbmcaddon.Addon('script.module.sxManager')
        self.service=sxmanagerService()

    def onInit(self):
        self.update_status_labels()

    def onClick(self,c):
        if c==104: show_domain_status()
        elif c==109: show_domain_check()
        elif c==105:
            self.addon.openSettings(); self.update_status_labels()
        elif c==107: self.close()

    def update_status_labels(self):
        def local_state(addon_id):
            try:
                xbmcaddon.Addon(addon_id); return 'LOKAL BEREIT'
            except Exception: return 'NICHT INSTALLIERT'
        try:
            self.getControl(202).setLabel('xShip: ' + local_state('plugin.video.xship'))
            self.getControl(203).setLabel('xStream: ' + local_state('plugin.video.xstream'))
        except Exception: pass

def show_gui():
    addon=xbmcaddon.Addon('script.module.sxManager'); path=addon.getAddonInfo('path')
    w=sxmanagerGUI('script-sxmanager.xml',path,'Default','1080i'); w.doModal(); del w
