#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import threading
import xbmc, xbmcgui, xbmcaddon
from lib.sxmanager_addon import sxmanagerService


class sxStatusProgressGUI(xbmcgui.WindowXMLDialog):
    """Immediate sxManager wait window while current domains are diagnosed."""
    def __init__(self, *args, **kwargs):
        self.service = kwargs.pop('service', None) or sxmanagerService()
        self.rows = []
        super().__init__(*args, **kwargs)

    def onInit(self):
        try:
            self.getControl(302).setPercent(15.0)
        except Exception:
            pass
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        try:
            self.rows = self.service.diagnose_current_domains()
            try:
                self.getControl(302).setPercent(100.0)
            except Exception:
                pass
        except Exception as e:
            self.service.logger.error('Domain status progress error: %s' % e)
            self.rows = []
        xbmc.sleep(120)
        self.close()

    def onAction(self, action):
        # The short status scan intentionally cannot be cancelled halfway,
        # so its result window always receives a complete data set.
        pass


class sxDomainStatusGUI(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.service = kwargs.pop('service', None) or sxmanagerService()
        self.rows = kwargs.pop('rows', [])
        super().__init__(*args, **kwargs)

    def onInit(self):
        self._fill()
        try: self.setFocusId(100)
        except Exception: pass

    def _fill(self):
        lst = self.getControl(100)
        lst.reset()
        for x in self.rows:
            provider = x.get('provider', '-')
            domain = x.get('url', '-')
            source = 'xShip' if x.get('type') == 'xship' else 'xStream'
            state = x.get('diagnostic_status', 'OFFLINE')
            code = x.get('http_status')
            detail = x.get('diagnostic_detail', '')
            if state == 'ONLINE':
                state_display = '[COLOR lime]●  ONLINE[/COLOR]'
            elif state == 'CLOUDFLARE':
                state_display = '[COLOR orange]●  CLOUDFLARE[/COLOR]'
            else:
                state_display = '[COLOR red]●  OFFLINE[/COLOR]'
            http = ('HTTP %s' % code) if code else (detail or 'Fehler')
            li = xbmcgui.ListItem(label=provider)
            li.setProperty('source', source)
            li.setProperty('domain', domain)
            li.setProperty('state_display', state_display)
            li.setProperty('http', http)
            lst.addItem(li)
        try:
            self.getControl(202).setLabel('%d aktuell verwendete Domains' % len(self.rows))
        except Exception:
            pass

    def _move(self, delta):
        try:
            lst = self.getControl(100)
            count = lst.size()
            if not count: return
            pos = max(0, min(count - 1, lst.getSelectedPosition() + delta))
            lst.selectItem(pos)
            self.setFocusId(100)
        except Exception:
            pass

    def onClick(self, cid):
        if cid == 301:
            self.close()
        elif cid == 310:
            self._move(-1)
        elif cid == 311:
            self._move(1)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247):
            self.close()


def show_domain_status():
    service = sxmanagerService()
    addon = xbmcaddon.Addon('script.module.sxManager')
    path = addon.getAddonInfo('path')

    # Show feedback immediately; the network diagnosis runs in its worker thread.
    wait = sxStatusProgressGUI('script-sxstatusprogress.xml', path, 'Default', '1080i', service=service)
    wait.doModal()
    rows = wait.rows
    del wait

    w = sxDomainStatusGUI('script-sxdomainstatus.xml', path, 'Default', '1080i', service=service, rows=rows)
    w.doModal(); del w
