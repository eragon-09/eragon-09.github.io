#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""sxManager core - xShip/XStream only."""
import json, os, shutil, time, traceback, socket
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.parse import urlparse
from urllib.error import HTTPError, URLError
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
from lib.logger import sxmanagerLogger

# Hardcoded remote source disabled. A URL can still be entered manually in the addon settings.
DEFAULT_REMOTE_URL = ''

class BaseSettings:
    def __init__(self, logger, path, prefix):
        self.logger, self.path, self.prefix = logger, xbmcvfs.translatePath(path), prefix
        self.data = None
    def load(self):
        import xml.etree.ElementTree as ET
        try:
            if not os.path.exists(self.path): return False
            self.tree = ET.parse(self.path); self.root = self.tree.getroot(); return True
        except Exception as e: self.logger.error('Settings load error: %s' % e); return False
    def get_setting(self, sid):
        if not sid.startswith(self.prefix): return None
        for n in self.root.findall('.//setting'):
            if n.get('id') == sid: return n.get('value', n.text or '')
        return None
    def set_setting(self, sid, value):
        if not sid.startswith(self.prefix): return False
        for n in self.root.findall('.//setting'):
            if n.get('id') == sid:
                if 'value' in n.attrib: n.set('value', str(value))
                else: n.text = str(value)
                return True
        return False
    def save(self):
        try: self.tree.write(self.path, encoding='utf-8', xml_declaration=True); return True
        except Exception as e: self.logger.error('Settings save error: %s' % e); return False
    def backup(self, addon_type=''):
        try:
            if not os.path.exists(self.path): return False
            dst = self.path + '.' + datetime.now().strftime('%Y%m%d%H%M%S') + '.backup'
            shutil.copy2(self.path, dst); return True
        except Exception as e: self.logger.error('Backup error: %s' % e); return False
    def list_backups(self, addon_type=''):
        folder, base = os.path.dirname(self.path), os.path.basename(self.path)
        if not os.path.isdir(folder): return []
        return sorted([os.path.join(folder,n) for n in os.listdir(folder) if n.startswith(base+'.') and n.endswith('.backup')], reverse=True)
    def restore_backup(self, path):
        try: shutil.copy2(path, self.path); return True
        except Exception: return False
    def delete_backup(self, path):
        try: os.remove(path); return True
        except Exception: return False

class XShipSettings(BaseSettings):
    def __init__(self, logger, addon=None): super().__init__(logger, 'special://home/userdata/addon_data/plugin.video.xship/settings.xml', 'provider.')
class XStreamSettings(BaseSettings):
    def __init__(self, logger, addon=None): super().__init__(logger, 'special://home/userdata/addon_data/plugin.video.xstream/settings.xml', 'plugin_')

class RemoteConfig:
    def __init__(self, logger, url): self.logger, self.url = logger, url
    def fetch(self):
        # No remote request unless the user explicitly configured a URL.
        if not (self.url or '').strip():
            self.logger.info('Remote config disabled: no URL configured')
            return None
        try:
            req=Request(self.url); req.add_header('User-Agent','sxManager/1.0.6'); req.add_header('Accept','application/json')
            with urlopen(req, timeout=15) as r: data=json.loads(r.read().decode('utf-8'))
            return data if isinstance(data,dict) else None
        except Exception as e: self.logger.error('Remote config error: %s' % e); return None
    def get_addon_settings(self, addon_type):
        cfg=self.fetch() or {}; return cfg.get({'xship':'XShipSettings','xstream':'XStreamSettings'}.get(addon_type,''), {})
    def fetch_for_domain_check(self):
        cfg=self.fetch() or {}; out=[]
        for key, typ in (('XShipSettings','xship'),('XStreamSettings','xstream')):
            for sid,url in (cfg.get(key,{}) or {}).items():
                if url: out.append({'id':sid,'url':url,'type':typ,'status':'unchecked','response_time':0,'error':None})
        return out

class DomainSync:
    def __init__(self, logger, settings, remote, addon_type): self.logger,self.settings,self.remote,self.addon_type=logger,settings,remote,addon_type
    def _run(self, empty_only=False):
        remote=self.remote.get_addon_settings(self.addon_type)
        if not remote or not self.settings.load(): return False,0
        count=0
        for sid,new in remote.items():
            old=self.settings.get_setting(sid)
            if old is None: continue
            if empty_only and str(old).strip(): continue
            if old != new and self.settings.set_setting(sid,new): count += 1
        if count and not self.settings.save(): return False,0
        return True,count
    def sync_with_empty_fill(self): return self._run(False)
    def fill_empty_domains(self): return self._run(True)

class sxmanagerService:
    def __init__(self):
        self.addon=xbmcaddon.Addon('script.module.sxManager'); self.logger=sxmanagerLogger('script.module.sxManager'); self.monitor=xbmc.Monitor()
        url=self.get_string_setting('remote_url','').strip() or DEFAULT_REMOTE_URL
        self.remote_config=RemoteConfig(self.logger,url)
        self.xship_settings=XShipSettings(self.logger,self.addon); self.xstream_settings=XStreamSettings(self.logger,self.addon)
        self.xship_domain_sync=DomainSync(self.logger,self.xship_settings,self.remote_config,'xship'); self.xstream_domain_sync=DomainSync(self.logger,self.xstream_settings,self.remote_config,'xstream')
        self.last_sync_times={'xship':0,'xstream':0}
    def get_string_setting(self,k,d=''):
        v=self.addon.getSetting(k); return v if v!='' else d
    def get_bool_setting(self,k,d=False):
        v=self.addon.getSetting(k); return d if v=='' else v.lower()=='true'
    def get_int_setting(self,k,d=0):
        try: return int(float(self.addon.getSetting(k)))
        except: return d
    def set_string_setting(self,k,v): self.addon.setSetting(k,str(v))
    def update_backup_counts(self):
        self.set_string_setting('backups_xship',len(self.xship_settings.list_backups())); self.set_string_setting('backups_xstream',len(self.xstream_settings.list_backups()))
    def sync_now(self, addon_type='all'):
        total=0; ok=False; now=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        for typ, settings, sync, status_prefix in [('xship',self.xship_settings,self.xship_domain_sync,'xShip'),('xstream',self.xstream_settings,self.xstream_domain_sync,'XStream')]:
            if addon_type not in (typ,'all'): continue
            if self.get_bool_setting('backup_enabled_'+('xship' if typ=='xship' else 'XStream'),True): settings.backup(typ)
            success,changes=sync.sync_with_empty_fill(); ok = ok or success; total += changes
            self.set_string_setting('last_check_status_'+status_prefix,'OK' if success else 'FEHLER')
            if success:
                self.set_string_setting('last_sync_'+status_prefix,now); self.set_string_setting('domains_synced_'+status_prefix,changes); self.last_sync_times[typ]=time.time()
        self.update_backup_counts(); return ok,total
    def fill_empty_only(self, addon_type='all'):
        total=0; ok=False
        for typ,sync in [('xship',self.xship_domain_sync),('xstream',self.xstream_domain_sync)]:
            if addon_type in (typ,'all'):
                success,changes=sync.fill_empty_domains(); ok=ok or success; total+=changes
        return ok,total
    def _definition_path(self, addon_id):
        """Return the installed add-on's settings definition, if available."""
        try:
            addon_path = xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('path'))
            for rel in (os.path.join('resources', 'settings.xml'), os.path.join('resources', 'settings', 'settings.xml')):
                candidate = os.path.join(addon_path, rel)
                if os.path.exists(candidate):
                    return candidate
        except Exception as e:
            self.logger.error('Definition path error for %s: %s' % (addon_id, e))
        return ''

    @staticmethod
    def _domain_setting_id(typ, sid):
        return ((typ == 'xship' and sid.startswith('provider.') and sid.endswith('.domain')) or
                (typ == 'xstream' and sid.startswith('plugin_') and sid.endswith('.domain')))

    @staticmethod
    def _provider_from_id(typ, sid):
        if typ == 'xship':
            return sid[len('provider.'):-len('.domain')]
        return sid[len('plugin_'):-len('.domain')]

    @staticmethod
    def _split_values(raw):
        if not raw:
            return []
        return [v.strip() for v in str(raw).split('|') if v.strip()]

    @staticmethod
    def _looks_like_endpoint(value):
        value=(value or '').strip()
        if not value or ' ' in value:
            return False
        host=(urlparse(value if '://' in value else 'https://'+value).hostname or '').strip()
        return bool(host and ('.' in host or host.replace(':','').isdigit()))

    def _read_definition_map(self, typ, addon_id):
        """Read domain metadata from old and new Kodi settings definitions."""
        import xml.etree.ElementTree as ET
        result={}
        path=self._definition_path(addon_id)
        if not path:
            return result
        try:
            root=ET.parse(path).getroot()
            for n in root.findall('.//setting'):
                sid=n.get('id','')
                if not self._domain_setting_id(typ,sid):
                    continue
                stype=(n.get('type','text') or 'text').lower()
                vals=self._split_values(n.get('values',''))
                # Kodi's newer settings schema may store selectable values as <option> nodes.
                if not vals:
                    for opt in n.findall('.//option'):
                        value=(opt.get('value') or opt.text or '').strip()
                        if value and value not in vals:
                            vals.append(value)
                default=(n.get('default','') or '').strip()
                if not default:
                    d=n.find('./default')
                    if d is not None:
                        default=(d.text or '').strip()
                result[sid]={'type':stype, 'values':vals, 'default':default, 'definition_path':path}
        except Exception as e:
            self.logger.error('Definition load error %s: %s' % (path,e))
        return result

    def _local_domain_entries(self):
        """Collect configured and defined domain candidates from xShip and xStream."""
        out=[]
        configs=(('xship',self.xship_settings,'plugin.video.xship'),('xstream',self.xstream_settings,'plugin.video.xstream'))
        for typ, settings, addon_id in configs:
            defs=self._read_definition_map(typ,addon_id)
            if not settings.load():
                continue
            user={}
            for n in settings.root.findall('.//setting'):
                sid=n.get('id','')
                if self._domain_setting_id(typ,sid):
                    user[sid]=(n.get('value',n.text or '') or '').strip()
            for sid in sorted(set(defs)|set(user)):
                if not self._domain_setting_id(typ,sid):
                    continue
                meta=defs.get(sid,{'type':'text','values':[],'default':''})
                raw=user.get(sid,'')
                values=list(meta.get('values') or [])
                current=''
                current_index=None
                # Kodi enum settings store the selected index in userdata/settings.xml.
                if values and raw.isdigit():
                    idx=int(raw)
                    if 0 <= idx < len(values):
                        current=values[idx]; current_index=idx
                elif self._looks_like_endpoint(raw):
                    current=raw
                elif values and str(meta.get('default','')).isdigit():
                    idx=int(meta['default'])
                    if 0 <= idx < len(values):
                        current=values[idx]; current_index=idx
                elif self._looks_like_endpoint(meta.get('default','')):
                    current=meta['default']
                candidates=[]
                for v in ([current] if current else []) + values:
                    if self._looks_like_endpoint(v) and v not in candidates:
                        candidates.append(v)
                if not candidates:
                    continue
                provider=self._provider_from_id(typ,sid)
                for v in candidates:
                    out.append({'id':sid,'provider':provider,'url':v,'type':typ,
                                'source':'current' if v==current else 'defined',
                                'is_current':v==current,'setting_type':meta.get('type','text'),
                                'enum_values':values,'current_index':current_index,
                                'status':'unchecked','response_time':0,'error':None,
                                'final_url':'','redirect_domain':''})
        return out

    def _check_one_domain(self, item):
        domain=item['url'].strip()
        parsed=urlparse(domain if '://' in domain else 'https://'+domain)
        original=(parsed.hostname or domain).lower()
        timeout=max(5,self.get_int_setting('timeout',10)); started=time.time(); last_error=''
        schemes=(parsed.scheme,) if parsed.scheme in ('http','https') else ('https','http')
        hostpart=domain.split('://',1)[-1]
        for scheme in schemes:
            try:
                req=Request('%s://%s' % (scheme,hostpart),headers={'User-Agent':'Mozilla/5.0 (Kodi sxManager/1.0.6)'})
                with urlopen(req,timeout=timeout) as r:
                    final=r.geturl(); code=getattr(r,'status',200)
                host=(urlparse(final).hostname or '').lower()
                item.update(status='online',response_time=int((time.time()-started)*1000),final_url=final,http_status=code)
                if host and host != original: item['redirect_domain']=host
                return item
            except HTTPError as e:
                final=e.geturl(); host=(urlparse(final).hostname or '').lower()
                item.update(status='online',response_time=int((time.time()-started)*1000),final_url=final,http_status=e.code)
                if host and host != original: item['redirect_domain']=host
                return item
            except (URLError,socket.timeout,TimeoutError,OSError) as e: last_error=str(e)
            except Exception as e: last_error=str(e); break
        item.update(status='offline',response_time=int((time.time()-started)*1000),error=last_error)
        return item

    def check_domains_availability(self):
        """Check all candidates defined by xShip/xStream plus their configured values."""
        domains=self._local_domain_entries()
        return [self._check_one_domain(d) for d in domains]

    def _write_candidate(self, settings, item, candidate):
        """Write safely: selectable settings get an index; free text gets the hostname."""
        vals=item.get('enum_values') or []
        stype=(item.get('setting_type') or 'text').lower()
        if vals:
            if candidate not in vals:
                self.logger.info('Not writing %s: %s is not a defined selectable value' % (item.get('id'), candidate))
                return False
            return settings.set_setting(item['id'],str(vals.index(candidate)))
        if stype in ('enum','select','list'):
            self.logger.info('Not writing %s: selectable setting has no resolvable values' % item.get('id'))
            return False
        return settings.set_setting(item['id'],candidate)

    def apply_candidate_updates(self, selections):
        """Apply selected candidates. selections: one checked item per setting with target_domain."""
        total=0
        for typ,settings in (('xship',self.xship_settings),('xstream',self.xstream_settings)):
            changes=[d for d in selections if d.get('type')==typ and d.get('target_domain')]
            if not changes or not settings.load(): continue
            settings.backup(typ); changed=0
            for d in changes:
                if self._write_candidate(settings,d,d['target_domain']): changed+=1
            if changed and settings.save(): total+=changed
        self.update_backup_counts(); return total

    def best_candidate_updates(self, domains):
        """Suggest a reachable alternative only when the current candidate is offline."""
        groups={}
        for d in domains: groups.setdefault((d['type'],d['id']),[]).append(d)
        updates=[]
        for key,items in groups.items():
            current=next((d for d in items if d.get('is_current')),None)
            if current and current.get('status')=='online': continue
            # Prefer alternatives that are explicitly defined by the installed add-on.
            target=next((d for d in items if d.get('status')=='online' and not d.get('is_current') and d.get('source')=='defined'),None)
            if target is None:
                target=next((d for d in items if d.get('status')=='online' and not d.get('is_current')),None)
            if target:
                proposal=dict(target); proposal['target_domain']=target['url']; proposal['old_domain']=current['url'] if current else ''
                updates.append(proposal)
        return updates

    def apply_redirect_updates(self, domains):
        # Kept for compatibility with older GUI code.
        selections=[]
        for d in domains:
            if d.get('redirect_domain'):
                x=dict(d); x['target_domain']=d['redirect_domain']; selections.append(x)
        return self.apply_candidate_updates(selections)
    def auto_check_current_domains(self, addon_type='all'):
        """Background health check: current domain first, alternatives only on failure."""
        entries=self._local_domain_entries()
        groups={}
        for item in entries:
            if addon_type not in (item.get('type'),'all'):
                continue
            groups.setdefault((item.get('type'),item.get('id')),[]).append(item)

        changes=[]; checked=0; failed=0
        for (_typ,_sid),items in groups.items():
            if self.monitor.abortRequested():
                break
            current=next((x for x in items if x.get('is_current')),None)
            if not current:
                continue
            checked += 1
            current=self._check_one_domain(dict(current))
            if current.get('status') == 'online':
                continue
            failed += 1
            # Only after the active domain failed do we test its installed/defined fallbacks.
            for candidate in items:
                if candidate.get('is_current'):
                    continue
                tested=self._check_one_domain(dict(candidate))
                if tested.get('status') == 'online':
                    tested['target_domain']=tested.get('url','')
                    tested['old_domain']=current.get('url','')
                    changes.append(tested)
                    break

        applied=self.apply_candidate_updates(changes) if changes else 0
        now=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        types=('xship','xstream') if addon_type=='all' else (addon_type,)
        for typ in types:
            prefix='xShip' if typ=='xship' else 'XStream'
            self.set_string_setting('last_sync_'+prefix,now)
            self.set_string_setting('last_check_status_'+prefix,'GEWECHSELT' if any(x.get('type')==typ for x in changes) else ('OFFLINE' if failed else 'OK'))
            self.set_string_setting('domains_synced_'+prefix,sum(1 for x in changes if x.get('type')==typ))
            self.last_sync_times[typ]=time.time()

        if applied and self.get_bool_setting('show_notifications',True) and self.get_bool_setting('notify_on_changes',True):
            xbmcgui.Dialog().notification('sxManager', '%d Domain%s automatisch aktualisiert' % (applied, '' if applied==1 else 's'), self.addon.getAddonInfo('icon'), 4000)
        self.logger.info('Automatic local domain check: checked=%d failed=%d applied=%d' % (checked,failed,applied))
        return applied

    def run(self):
        # Automatic mode is local-only: check active domains after Kodi login.
        # Alternatives are contacted only when the active domain is unreachable.
        ax=self.get_bool_setting('auto_sync_xShip',True); ast=self.get_bool_setting('auto_sync_XStream',True)
        ix=self.get_int_setting('check_interval_xShip',5)*86400; ist=self.get_int_setting('check_interval_XStream',5)*86400
        if (ax or ast) and not self.monitor.waitForAbort(10):
            self.auto_check_current_domains('all' if ax and ast else ('xship' if ax else 'xstream'))
        while not self.monitor.abortRequested():
            now=time.time()
            if ax and now-self.last_sync_times['xship']>=ix:
                self.auto_check_current_domains('xship')
            if ast and now-self.last_sync_times['xstream']>=ist:
                self.auto_check_current_domains('xstream')
            if self.monitor.waitForAbort(300): break
