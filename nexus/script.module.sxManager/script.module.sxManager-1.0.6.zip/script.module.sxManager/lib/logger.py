#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
from datetime import datetime


class sxmanagerLogger:
    """Verbesserte Logging-Klasse für sxManager"""
    
    def __init__(self, addon_or_id):
        """Initialisiere Logger mit Addon oder Addon-ID"""
        if isinstance(addon_or_id, str):
            self.addon_id = addon_or_id
            try:
                self.addon = xbmcaddon.Addon(addon_or_id)
            except:
                self.addon = None
                self.debug_enabled = False
                return
        else:
            self.addon = addon_or_id
            self.addon_id = addon_or_id.getAddonInfo('id')
        
        try:
            self.debug_enabled = self.addon.getSetting('debug_mode') == 'true'
        except:
            self.debug_enabled = False
    
    def _log(self, message, level=xbmc.LOGDEBUG):
        """Schreibe Log-Nachricht"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        formatted_message = f'[{self.addon_id}] [{timestamp}] {message}'
        xbmc.log(formatted_message, level)
    
    def debug(self, message):
        """Debug-Level Log"""
        if self.debug_enabled:
            self._log(f'DEBUG: {message}', xbmc.LOGDEBUG)
    
    def info(self, message):
        """Info-Level Log"""
        self._log(f'INFO: {message}', xbmc.LOGINFO)
    
    def warning(self, message):
        """Warning-Level Log"""
        self._log(f'WARNING: {message}', xbmc.LOGWARNING)
    
    def error(self, message):
        """Error-Level Log"""
        self._log(f'ERROR: {message}', xbmc.LOGERROR)
    
    def domain_check(self, message):
        """Domain-Check spezifisches Logging"""
        self._log(f'DOMAIN CHECK: {message}', xbmc.LOGINFO)