#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import threading
import xbmc, xbmcgui, xbmcaddon
from lib.sxmanager_addon import sxmanagerService


class sxDomainProgressGUI(xbmcgui.WindowXMLDialog):
    """Small sxManager-native progress window; no Kodi DialogProgress artwork."""
    def __init__(self, *args, **kwargs):
        self.service = kwargs.pop('service', None) or sxmanagerService()
        self.domains = []
        self.cancelled = False
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('sx.progress', '0')
        self.setProperty('sx.progress.text', 'Domain-Einstellungen werden eingelesen ...')
        self._set_progress(0)
        threading.Thread(target=self._worker, daemon=True).start()


    def _set_progress(self, value):
        # Window.Property() is not a reliable source for Kodi's progress control.
        # Drive the ControlProgress directly so the green fill really grows.
        value = max(0, min(100, int(value)))
        self.setProperty('sx.progress', str(value))
        try:
            self.getControl(302).setPercent(float(value))
        except Exception:
            pass

    def _worker(self):
        try:
            entries = self.service._local_domain_entries()
            total = max(1, len(entries))
            checked = []
            for pos, item in enumerate(entries, 1):
                if self.cancelled:
                    break
                self._set_progress(int((pos * 100) / total))
                self.setProperty('sx.progress.text', 'Prüfe %d / %d   %s' % (pos, total, item.get('url', '')))
                checked.append(self.service._check_one_domain(item))
            self.domains = checked
            self._set_progress(100)
            self.setProperty('sx.progress.text', 'Prüfung abgeschlossen')
        except Exception as e:
            self.service.logger.error('Domain progress error: %s' % e)
        xbmc.sleep(150)
        self.close()

    def onClick(self, control_id):
        if control_id == 301:
            self.cancelled = True
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247):
            self.cancelled = True
            self.close()


class sxDomainCheckGUI(xbmcgui.WindowXMLDialog):
    """Centered sxManager result window with explicit alternative selection."""
    def __init__(self, *args, **kwargs):
        self.service = kwargs.pop('service', None) or sxmanagerService()
        self.domains = kwargs.pop('domains', [])
        self.filter_type = 'xship'
        self.updates = []
        self.visible_rows = []
        super().__init__(*args, **kwargs)

    def onInit(self):
        if not any(d.get('type') == 'xship' for d in self.domains):
            self.filter_type = 'xstream'
        self._render()

    def _set_label(self, cid, text):
        try: self.getControl(cid).setLabel(text)
        except Exception: pass

    def _is_writable_alternative(self, d):
        if not d or d.get('is_current') or d.get('status') != 'online':
            return False
        vals = d.get('enum_values') or []
        stype = (d.get('setting_type') or 'text').lower()
        if vals:
            return d.get('url') in vals
        return stype not in ('enum', 'select', 'list')

    def _available_alternatives(self):
        return [d for d in self.visible_rows if self._is_writable_alternative(d)]

    def _selected_row(self):
        try:
            pos = self.getControl(100).getSelectedPosition()
            if 0 <= pos < len(self.visible_rows):
                return self.visible_rows[pos]
        except Exception:
            pass
        return None

    def _alternative_for_selection(self):
        selected = self._selected_row()
        if self._is_writable_alternative(selected):
            return selected
        # If the active/current row is selected, prefer a reachable alternative
        # belonging to the same setting/provider.
        if selected:
            for d in self.visible_rows:
                if d.get('id') == selected.get('id') and self._is_writable_alternative(d):
                    return d
        return None

    def _refresh_selection_ui(self):
        alternatives = self._available_alternatives()
        chosen = self._alternative_for_selection()
        try: self.getControl(300).setEnabled(bool(alternatives))
        except Exception: pass
        if chosen:
            provider = chosen.get('provider', chosen.get('id', ''))
            self._set_label(203, '%s: %s ist erreichbar und kann übernommen werden.' %
                            (provider, chosen.get('url', '')))
        elif alternatives:
            self._set_label(203, 'Erreichbare Alternative markieren und anschließend übernehmen.')
        else:
            self._set_label(203, 'Keine übernehmbare Alternative in diesem Bereich verfügbar.')

    def _render(self):
        online = sum(1 for d in self.domains if d.get('status') == 'online')
        offline = sum(1 for d in self.domains if d.get('status') == 'offline')
        self.updates = self.service.best_candidate_updates(self.domains)
        proposals = len(self.updates)
        summary = '%d Domains   |   %d online   |   %d offline' % (len(self.domains), online, offline)
        if proposals:
            summary += '   |   %d Vorschlag%s' % (proposals, '' if proposals == 1 else 'e')
        self._set_label(202, summary)
        self._set_label(210, 'XSHIP' if self.filter_type == 'xship' else 'xShip')
        self._set_label(211, 'XSTREAM' if self.filter_type == 'xstream' else 'xStream')
        self._fill_list()
        self._refresh_selection_ui()

    def _fill_list(self):
        try:
            lst = self.getControl(100); lst.reset()
            self.visible_rows = [d for d in self.domains if d.get('type') == self.filter_type]
            if not self.visible_rows:
                li = xbmcgui.ListItem(label='Keine Domain-Einträge gefunden')
                li.setProperty('domain', ''); li.setProperty('detail', '')
                li.setProperty('status_icon', 'offline.png'); li.setProperty('state', '')
                lst.addItem(li); return
            last_provider = None
            for d in self.visible_rows:
                provider = d.get('provider', d.get('id', ''))
                show_provider = provider if provider != last_provider else ''
                last_provider = provider
                current = 'AKTUELL' if d.get('is_current') else 'Alternative'
                code = ('HTTP %s' % d.get('http_status')) if d.get('http_status') else ''
                redirect = (' -> %s' % d.get('redirect_domain')) if d.get('redirect_domain') else ''
                detail = '  |  '.join(x for x in (current, code) if x) + redirect
                li = xbmcgui.ListItem(label=show_provider)
                li.setProperty('domain', d.get('url', ''))
                li.setProperty('detail', detail)
                li.setProperty('status_icon', 'online.png' if d.get('status') == 'online' else 'offline.png')
                li.setProperty('state', 'ONLINE' if d.get('status') == 'online' else 'OFFLINE')
                lst.addItem(li)
        except Exception as e:
            self.service.logger.error('Domain window render error: %s' % e)

    def onClick(self, cid):
        if cid == 301:
            self.close()
        elif cid in (210, 211):
            self.filter_type = 'xship' if cid == 210 else 'xstream'
            self._render()
            try: self.setFocusId(100)
            except Exception: pass
        elif cid == 100:
            self._refresh_selection_ui()
        elif cid == 300:
            target = self._alternative_for_selection()
            if target is None:
                alternatives = self._available_alternatives()
                target = alternatives[0] if alternatives else None
            if target:
                proposal = dict(target)
                proposal['target_domain'] = target.get('url', '')
                n = self.service.apply_candidate_updates([proposal])
                if n:
                    xbmcgui.Dialog().notification('sxManager', '%s übernommen' % target.get('url', ''),
                                                  xbmcaddon.Addon('script.module.sxManager').getAddonInfo('icon'), 2500)
                    # Nach erfolgreicher Übernahme den Domain-Dialog schließen.
                    # Beim nächsten Domain Check werden die Werte frisch eingelesen.
                    self.close()
                else:
                    xbmcgui.Dialog().notification('sxManager', 'Alternative konnte nicht übernommen werden',
                                                  xbmcaddon.Addon('script.module.sxManager').getAddonInfo('icon'), 2500)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247):
            self.close()
            return
        # Navigation changes the selected list item; refresh the proposal panel
        # shortly afterwards without changing the domain-check logic itself.
        if action.getId() in (1, 2, 3, 4, 5, 6):
            xbmc.sleep(20)
            self._refresh_selection_ui()

def show_domain_check():
    service = sxmanagerService()
    addon = xbmcaddon.Addon('script.module.sxManager')
    path = addon.getAddonInfo('path')
    p = sxDomainProgressGUI('script-sxdomainprogress.xml', path, 'Default', '1080i', service=service)
    p.doModal(); domains = p.domains; cancelled = p.cancelled; del p
    if cancelled: return
    w = sxDomainCheckGUI('script-sxdomaincheck.xml', path, 'Default', '1080i', service=service, domains=domains)
    w.doModal(); del w
