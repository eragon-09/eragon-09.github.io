#!/usr/bin/env python3
import xbmc, xbmcgui, xbmcaddon
from lib.sxmanager_addon import sxmanagerService
from lib.sxcheck_gui import show_domain_check

class sxmanagerGUI(xbmcgui.WindowXMLDialog):
    def __init__(self,*a,**kw): super().__init__(*a,**kw); self.addon=xbmcaddon.Addon('script.module.sxManager'); self.service=sxmanagerService()
    def onInit(self): self.update_status_labels()
    def onClick(self,c):
        if c==100: self.do_sync('xship')
        elif c==101: self.do_sync('xstream')
        elif c==103: self.do_sync('all')
        elif c==104: self.show_status()
        elif c==105: self.addon.openSettings(); self.update_status_labels()
        elif c==106: self.show_backup_dialog()
        elif c==108: self.do_fill_empty()
        elif c==109: show_domain_check()
        elif c==107: self.close()
    def do_sync(self,t):
        names={'xship':'xShip','xstream':'XStream','all':'beide Add-ons'}
        if not xbmcgui.Dialog().yesno('sxManager','Domain-Synchronisation für %s starten?'%names[t]): return
        ok,n=self.service.sync_now(t); xbmcgui.Dialog().ok('sxManager',('%s Domain(s) aktualisiert'%n) if ok else 'Synchronisation fehlgeschlagen'); self.update_status_labels()
    def do_fill_empty(self):
        c=xbmcgui.Dialog().select('Leere Domains füllen',['xShip','XStream','Beide Add-ons'])
        if c<0:return
        t=['xship','xstream','all'][c]; ok,n=self.service.fill_empty_only(t); xbmcgui.Dialog().ok('sxManager','%s leere Domain(s) gefüllt'%n if ok else 'Vorgang fehlgeschlagen')
    def show_status(self):
        s='xShip: %s | %s\nXStream: %s | %s' % (self.service.get_string_setting('last_check_status_xShip','-'),self.service.get_string_setting('last_sync_xShip','Nie'),self.service.get_string_setting('last_check_status_XStream','-'),self.service.get_string_setting('last_sync_XStream','Nie'))
        xbmcgui.Dialog().textviewer('sxManager Status',s)
    def update_status_labels(self):
        try:
            # The old FEHLER value belongs to the disabled remote synchronizer.
            # sxManager 1.0.6 now uses the installed xShip/xStream settings for
            # the Domain Check, so the main window reports local readiness.
            def local_state(addon_id):
                try:
                    xbmcaddon.Addon(addon_id)
                    return 'LOKAL BEREIT'
                except Exception:
                    return 'NICHT INSTALLIERT'
            self.getControl(202).setLabel('xShip: ' + local_state('plugin.video.xship'))
            self.getControl(203).setLabel('xStream: ' + local_state('plugin.video.xstream'))
            self.getControl(205).setLabel('Backups: xShip=%d | XStream=%d'%(len(self.service.xship_settings.list_backups()),len(self.service.xstream_settings.list_backups())))
        except: pass
    def show_backup_dialog(self):
        c=xbmcgui.Dialog().select('Backup-Verwaltung',['xShip Backup erstellen','XStream Backup erstellen'])
        if c==0: ok=self.service.xship_settings.backup('xship')
        elif c==1: ok=self.service.xstream_settings.backup('xstream')
        else:return
        xbmcgui.Dialog().notification('sxManager','Backup erstellt' if ok else 'Backup fehlgeschlagen')

def show_gui():
    addon=xbmcaddon.Addon('script.module.sxManager'); path=addon.getAddonInfo('path')
    w=sxmanagerGUI('script-sxmanager.xml',path,'Default','1080i'); w.doModal(); del w
